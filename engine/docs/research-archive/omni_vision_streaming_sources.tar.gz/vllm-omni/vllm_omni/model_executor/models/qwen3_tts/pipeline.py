# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Qwen3-TTS pipeline: Talker (text → RVQ codec) → Code2Wav (codec → audio).

Chunked vs end-to-end mode is dispatched from ``deploy.async_chunk``.
"""

from vllm_omni.config.stage_config import (
    PipelineConfig,
    StageExecutionType,
    StagePipelineConfig,
)
from vllm_omni.outputs.output_modality import (
    TensorAccumulationStrategy,
    register_key_accumulation_strategy,
)

_PROC = "vllm_omni.model_executor.stage_input_processors.qwen3_tts"

# The talker's codec-frame keys are not waveform chunks, so they must not go
# through the AUDIO modality's waveform-tuned default (CONCAT_LAST) whenever
# a stage carrying them consolidates its output under that modality (e.g. an
# AUDIO-typed final stage that forwards them directly instead of routing
# through code2wav): ``codes.audio`` grows one row per decode step along
# dim 0, and ``codes.ref`` re-emits the constant reference-context matrix
# unchanged at every step.
register_key_accumulation_strategy("codes.audio", TensorAccumulationStrategy.CONCAT_DIM0)
register_key_accumulation_strategy("codes.ref", TensorAccumulationStrategy.REPLACE)

QWEN3_TTS_PIPELINE = PipelineConfig(
    model_type="qwen3_tts",
    default_deploy_config_name="qwen3_tts.yaml",
    # Pipeline-level default; the code2wav stage overrides per-stage below.
    model_arch="Qwen3TTSTalkerForConditionalGeneration",
    stages=(
        StagePipelineConfig(
            stage_id=0,
            model_stage="qwen3_tts",
            execution_type=StageExecutionType.LLM_AR,
            input_sources=(),
            owns_tokenizer=True,
            engine_output_type="latent",
            async_chunk_process_next_stage_input_func=(f"{_PROC}.talker2code2wav_async_chunk"),
            custom_process_next_stage_input_func=f"{_PROC}.talker2code2wav_full_payload",
            sampling_constraints={
                "detokenize": False,
                "stop_token_ids": [2150],
            },
        ),
        StagePipelineConfig(
            stage_id=1,
            model_stage="code2wav",
            execution_type=StageExecutionType.LLM_GENERATION,
            input_sources=(0,),
            final_output=True,
            final_output_type="audio",
            engine_output_type="audio",
            model_arch="Qwen3TTSCode2Wav",
            # ``sync_process_input_func`` is the only input-proc override for
            # this stage in sync (non-async-chunk) mode: a length-only
            # ``_token_only`` placeholder.  The bulk codec payload itself
            # ships via the worker connector from stage 0's
            # ``talker2code2wav_full_payload`` producer.  Under async_chunk
            # mode no pre-stage processing is needed -- chunks deliver
            # directly to the consumer.
            sync_process_input_func=f"{_PROC}.talker2code2wav_token_only",
            sampling_constraints={"detokenize": True},
            extras={"tts_args": {"max_instructions_length": 500}},
            requires_full_payload_input=True,
        ),
    ),
)
