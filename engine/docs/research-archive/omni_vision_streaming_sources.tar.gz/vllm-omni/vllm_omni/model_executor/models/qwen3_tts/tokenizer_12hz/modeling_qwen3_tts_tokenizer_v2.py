# Copyright 2026 The Qwen team, Alibaba Group and the HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""PyTorch Qwen3TTSTokenizerV2 model."""

import copy
import inspect
import math
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from transformers import MimiConfig, MimiModel
from transformers.activations import ACT2FN
from transformers.cache_utils import Cache, DynamicCache
from transformers.integrations import use_kernel_forward_from_hub
from transformers.masking_utils import create_causal_mask, create_sliding_window_causal_mask
from transformers.modeling_flash_attention_utils import FlashAttentionKwargs
from transformers.modeling_layers import GradientCheckpointingLayer
from transformers.modeling_outputs import BaseModelOutputWithPast
from transformers.modeling_rope_utils import ROPE_INIT_FUNCTIONS, dynamic_rope_update
from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS, PreTrainedModel
from transformers.processing_utils import Unpack
from transformers.utils import ModelOutput, auto_docstring, logging
from transformers.utils.deprecation import deprecate_kwarg

from vllm_omni.model_executor.models.common.snake_activation import SnakeBeta

from .configuration_qwen3_tts_tokenizer_v2 import (
    Qwen3TTSTokenizerV2Config,
    Qwen3TTSTokenizerV2DecoderConfig,
)

logger = logging.get_logger(__name__)


def _default_rope_init(config, device=None, seq_len=None, layer_type=None):
    """Vanilla sinusoidal RoPE (no scaling).

    transformers>=5.0 removed the 'default' entry from
    ``ROPE_INIT_FUNCTIONS`` (see ``modeling_rope_utils.py`` in
    huggingface/transformers), but the speech tokenizer config still
    declares ``rope_type="default"``. This reimplements the original
    behaviour.
    """
    head_dim = getattr(config, "head_dim", config.hidden_size // config.num_attention_heads)
    inv_freq = 1.0 / (
        config.rope_theta ** (torch.arange(0, head_dim, 2, dtype=torch.float32, device=device) / head_dim)
    )
    return inv_freq, 1.0


@dataclass
@auto_docstring
class Qwen3TTSTokenizerV2EncoderOutput(ModelOutput):
    r"""
    audio_codes (`List[torch.LongTensor]`):
        Discrete code embeddings computed using `model.encode`, each tensor has shape (codes_length_i, num_quantizers).
    """

    audio_codes: list[torch.LongTensor] = None


@dataclass
@auto_docstring
class Qwen3TTSTokenizerV2DecoderOutput(ModelOutput):
    r"""
    audio_values (`List[torch.FloatTensor]`):
        Decoded audio values, obtained using the decoder part of Qwen3TTSTokenizerV1.
        Each tensor has shape (segment_length_i).
    """

    audio_values: list[torch.FloatTensor] = None


def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    """Applies Rotary Position Embedding to the query and key tensors.

    Args:
        q (`torch.Tensor`): The query tensor.
        k (`torch.Tensor`): The key tensor.
        cos (`torch.Tensor`): The cosine part of the rotary embedding.
        sin (`torch.Tensor`): The sine part of the rotary embedding.
        position_ids (`torch.Tensor`, *optional*):
            Deprecated and unused.
        unsqueeze_dim (`int`, *optional*, defaults to 1):
            The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
            sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
            that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
            k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
            cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
            the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
    Returns:
        `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
    """
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
    """
    This is the equivalent of torch.repeat_interleave(x, dim=1, repeats=n_rep). The hidden states go from (batch,
    num_key_value_heads, seqlen, head_dim) to (batch, num_attention_heads, seqlen, head_dim)
    """
    batch, num_key_value_heads, slen, head_dim = hidden_states.shape
    if n_rep == 1:
        return hidden_states
    hidden_states = hidden_states[:, :, None, :, :].expand(batch, num_key_value_heads, n_rep, slen, head_dim)
    return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)


def eager_attention_forward(
    module: nn.Module,
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attention_mask: torch.Tensor | None,
    scaling: float,
    dropout: float = 0.0,
    **kwargs,
):
    key_states = repeat_kv(key, module.num_key_value_groups)
    value_states = repeat_kv(value, module.num_key_value_groups)

    attn_weights = torch.matmul(query, key_states.transpose(2, 3)) * scaling
    if attention_mask is not None:
        causal_mask = attention_mask[:, :, :, : key_states.shape[-2]]
        attn_weights = attn_weights + causal_mask

    attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query.dtype)
    attn_weights = nn.functional.dropout(attn_weights, p=dropout, training=module.training)
    attn_output = torch.matmul(attn_weights, value_states)
    attn_output = attn_output.transpose(1, 2).contiguous()

    return attn_output, attn_weights


@auto_docstring
class Qwen3TTSTokenizerV2DecoderPreTrainedModel(PreTrainedModel):
    config: Qwen3TTSTokenizerV2DecoderConfig
    base_model_prefix = "model"
    supports_gradient_checkpointing = True
    _skip_keys_device_placement = "past_key_values"
    _supports_flash_attn = True
    _supports_sdpa = True
    _can_compile_fullgraph = False
    _supports_attention_backend = True


class Qwen3TTSTokenizerV2CausalConvNet(nn.Module):
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        dilation=1,
        stride=1,
        groups=1,
    ):
        super().__init__()
        self.conv = nn.Conv1d(
            in_channels,
            out_channels,
            kernel_size,
            stride=stride,
            dilation=dilation,
            groups=groups,
        )
        self.stride = stride
        self.kernel_size = (kernel_size - 1) * dilation + 1
        self.dilation = dilation
        self.padding = self.kernel_size - self.stride

    def _get_extra_padding_for_conv1d(self, hidden_state: torch.Tensor) -> int:
        # Cache the result per input length — under cudagraph capture the set of lengths
        # is fixed, so the LUT converges quickly and replaces the math.ceil call per replay.
        length = hidden_state.shape[-1]
        cache = self.__dict__.get("_pad_lut")
        if cache is None:
            cache = {}
            self.__dict__["_pad_lut"] = cache
        cached = cache.get(length)
        if cached is not None:
            return cached
        n_frames = (length - self.kernel_size + self.padding) / self.stride + 1
        ideal_length = (math.ceil(n_frames) - 1) * self.stride + (self.kernel_size - self.padding)
        extra_padding = ideal_length - length
        cache[length] = extra_padding
        return extra_padding

    def forward(self, hidden_state):
        extra_padding = self._get_extra_padding_for_conv1d(hidden_state)
        hidden_state = F.pad(hidden_state, (self.padding, extra_padding), mode="constant", value=0)
        return self.conv(hidden_state).contiguous()


class Qwen3TTSTokenizerV2CausalTransConvNet(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1):
        super().__init__()
        self.conv = nn.ConvTranspose1d(in_channels, out_channels, kernel_size, stride=stride)

        pad = kernel_size - stride
        self.left_pad = 0
        self.right_pad = int(pad)

    def forward(self, hidden_state):
        hidden_state = self.conv(hidden_state)
        if self.right_pad > 0:
            hidden_state = hidden_state[..., : hidden_state.shape[-1] - self.right_pad]
        return hidden_state.contiguous()


class Qwen3TTSTokenizerV2ConvNeXtBlock(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.dwconv = Qwen3TTSTokenizerV2CausalConvNet(
            dim,
            dim,
            kernel_size=7,
            groups=dim,
            dilation=1,
        )
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pwconv1 = nn.Linear(dim, 4 * dim)
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.gamma = nn.Parameter(1e-6 * torch.ones(dim))

    def forward(self, hidden_states):
        input = hidden_states

        hidden_states = self.dwconv(hidden_states)
        hidden_states = hidden_states.permute(0, 2, 1)
        hidden_states = self.norm(hidden_states)
        hidden_states = self.pwconv1(hidden_states)
        hidden_states = self.act(hidden_states)
        hidden_states = self.pwconv2(hidden_states)

        hidden_states = self.gamma * hidden_states

        hidden_states = hidden_states.permute(0, 2, 1)

        hidden_states = input + hidden_states

        return hidden_states


class Qwen3TTSTokenizerV2DecoderRotatoryEmbedding(nn.Module):
    inv_freq: torch.Tensor  # fix linting for `register_buffer`

    def __init__(self, config: Qwen3TTSTokenizerV2DecoderConfig, device=None):
        super().__init__()
        # BC: "rope_type" was originally "type"
        if hasattr(config, "rope_scaling") and isinstance(config.rope_scaling, dict):
            self.rope_type = config.rope_scaling.get("rope_type", config.rope_scaling.get("type"))
        else:
            self.rope_type = "default"
        self.max_seq_len_cached = config.max_position_embeddings
        self.original_max_seq_len = config.max_position_embeddings

        self.config = config

        if self.rope_type in ROPE_INIT_FUNCTIONS:
            self.rope_init_fn = ROPE_INIT_FUNCTIONS[self.rope_type]
        elif self.rope_type == "default":
            self.rope_init_fn = _default_rope_init
        else:
            raise ValueError(
                f"Unsupported rope_type '{self.rope_type}'. Expected one of {list(ROPE_INIT_FUNCTIONS)} or 'default'."
            )

        inv_freq, self.attention_scaling = self.rope_init_fn(self.config, device)
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self.original_inv_freq = self.inv_freq

    @torch.no_grad()
    @dynamic_rope_update  # power user: used with advanced RoPE types (e.g. dynamic rope)
    def forward(self, x, position_ids):
        inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1).to(x.device)
        position_ids_expanded = position_ids[:, None, :].float()

        device_type = x.device.type if isinstance(x.device.type, str) and x.device.type != "mps" else "cpu"
        with torch.autocast(device_type=device_type, enabled=False):  # Force float32
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * self.attention_scaling
            sin = emb.sin() * self.attention_scaling

        return cos.to(dtype=x.dtype), sin.to(dtype=x.dtype)


class Qwen3TTSTokenizerV2DecoderAttention(nn.Module):
    """Multi-headed attention from 'Attention Is All You Need' paper"""

    def __init__(self, config: Qwen3TTSTokenizerV2DecoderConfig, layer_idx):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.head_dim = getattr(config, "head_dim", config.hidden_size // config.num_attention_heads)
        self.num_key_value_groups = config.num_attention_heads // config.num_key_value_heads
        self.scaling = self.head_dim**-0.5
        self.attention_dropout = config.attention_dropout
        self.is_causal = True

        self.q_proj = nn.Linear(
            config.hidden_size, config.num_attention_heads * self.head_dim, bias=config.attention_bias
        )
        self.k_proj = nn.Linear(
            config.hidden_size, config.num_key_value_heads * self.head_dim, bias=config.attention_bias
        )
        self.v_proj = nn.Linear(
            config.hidden_size, config.num_key_value_heads * self.head_dim, bias=config.attention_bias
        )
        self.o_proj = nn.Linear(
            config.num_attention_heads * self.head_dim, config.hidden_size, bias=config.attention_bias
        )
        self.q_norm = nn.Identity()
        self.k_norm = nn.Identity()
        self.sliding_window = config.sliding_window

    @deprecate_kwarg("past_key_value", new_name="past_key_values", version="4.58")
    def forward(
        self,
        hidden_states: torch.Tensor,
        position_embeddings: tuple[torch.Tensor, torch.Tensor],
        attention_mask: torch.Tensor | None,
        past_key_values: Cache | None = None,
        cache_position: torch.LongTensor | None = None,
        **kwargs: Unpack[FlashAttentionKwargs],
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        input_shape = hidden_states.shape[:-1]
        hidden_shape = (*input_shape, -1, self.head_dim)

        query_states = self.q_norm(self.q_proj(hidden_states).view(hidden_shape)).transpose(1, 2)
        key_states = self.k_norm(self.k_proj(hidden_states).view(hidden_shape)).transpose(1, 2)
        value_states = self.v_proj(hidden_states).view(hidden_shape).transpose(1, 2)

        cos, sin = position_embeddings
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)

        if past_key_values is not None:
            # sin and cos are specific to RoPE models; cache_position needed for the static cache
            cache_kwargs = {"sin": sin, "cos": cos, "cache_position": cache_position}
            key_states, value_states = past_key_values.update(key_states, value_states, self.layer_idx, cache_kwargs)

        attention_interface: Callable = eager_attention_forward
        if self.config._attn_implementation != "eager":
            attention_interface = ALL_ATTENTION_FUNCTIONS[self.config._attn_implementation]

        attn_output, attn_weights = attention_interface(
            self,
            query_states,
            key_states,
            value_states,
            attention_mask,
            dropout=0.0 if not self.training else self.attention_dropout,
            scaling=self.scaling,
            sliding_window=self.sliding_window,  # diff with Llama
            **kwargs,
        )

        attn_output = attn_output.reshape(*input_shape, -1).contiguous()
        attn_output = self.o_proj(attn_output)
        return attn_output, attn_weights


class Qwen3TTSTokenizerV2DecoderMlp(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.intermediate_size = config.intermediate_size
        self.gate_proj = nn.Linear(self.hidden_size, self.intermediate_size, bias=False)
        self.up_proj = nn.Linear(self.hidden_size, self.intermediate_size, bias=False)
        self.down_proj = nn.Linear(self.intermediate_size, self.hidden_size, bias=False)
        self.act_fn = ACT2FN[config.hidden_act]

    def forward(self, x):
        down_proj = self.down_proj(self.act_fn(self.gate_proj(x)) * self.up_proj(x))
        return down_proj


@use_kernel_forward_from_hub("RMSNorm")
class Qwen3TTSTokenizerV2DecoderRMSNorm(nn.Module):
    def __init__(self, hidden_size, eps: float = 1e-6) -> None:
        """
        Qwen3TTSTokenizerV2DecoderRMSNorm is equivalent to T5LayerNorm
        """
        super().__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.variance_epsilon = eps

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        input_dtype = hidden_states.dtype
        hidden_states = hidden_states.to(torch.float32)
        variance = hidden_states.pow(2).mean(-1, keepdim=True)
        hidden_states = hidden_states * torch.rsqrt(variance + self.variance_epsilon)
        return self.weight * hidden_states.to(input_dtype)

    def extra_repr(self):
        return f"{tuple(self.weight.shape)}, eps={self.variance_epsilon}"


class Qwen3TTSTokenizerV2DecoderLayerScale(nn.Module):
    """Layer scale from [Touvron et al 2021] (https://huggingface.co/papers/2103.17239).
    This rescales diagonally the residual outputs close to 0, with a learnt scale.
    """

    def __init__(self, config):
        super().__init__()
        channels = config.hidden_size
        initial_scale = config.layer_scale_initial_scale
        self.scale = nn.Parameter(torch.full((channels,), initial_scale, requires_grad=True))

    def forward(self, x: torch.Tensor):
        return self.scale * x


class Qwen3TTSTokenizerV2DecoderTransformerLayer(GradientCheckpointingLayer):
    def __init__(self, config: Qwen3TTSTokenizerV2DecoderConfig, layer_idx):
        super().__init__()
        self.hidden_size = config.hidden_size
        self.self_attn = Qwen3TTSTokenizerV2DecoderAttention(config, layer_idx)
        self.mlp = Qwen3TTSTokenizerV2DecoderMlp(config)
        self.input_layernorm = Qwen3TTSTokenizerV2DecoderRMSNorm(config.hidden_size, config.rms_norm_eps)
        self.post_attention_layernorm = Qwen3TTSTokenizerV2DecoderRMSNorm(config.hidden_size, config.rms_norm_eps)
        self.self_attn_layer_scale = Qwen3TTSTokenizerV2DecoderLayerScale(config)
        self.mlp_layer_scale = Qwen3TTSTokenizerV2DecoderLayerScale(config)
        self.attention_type = "sliding_attention"

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
        position_ids: torch.LongTensor | None = None,
        past_key_values: Cache | None = None,
        use_cache: bool | None = False,
        cache_position: torch.LongTensor | None = None,
        **kwargs,
    ) -> tuple[torch.FloatTensor, tuple[torch.FloatTensor, torch.FloatTensor] | None]:
        """
        Args:
            hidden_states (`torch.FloatTensor`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`torch.FloatTensor`, *optional*):
                attention mask of size `(batch_size, sequence_length)` if flash attention is used or `(batch_size, 1,
                query_sequence_length, key_sequence_length)` if default attention is used.
            use_cache (`bool`, *optional*):
                If set to `True`, `past_key_values` key value states are returned and can be used to speed up decoding
                (see `past_key_values`).
            past_key_values (`Tuple(torch.FloatTensor)`, *optional*): cached past key and value projection states
            cache_position (`torch.LongTensor` of shape `(sequence_length)`, *optional*):
                Indices depicting the position of the input sequence tokens in the sequence
            kwargs (`dict`, *optional*):
                Arbitrary kwargs to be ignored, used for FSDP and other methods that injects code
                into the model
        """
        residual = hidden_states

        hidden_states = self.input_layernorm(hidden_states)

        # Self Attention
        hidden_states, _ = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            use_cache=use_cache,
            cache_position=cache_position,
            **kwargs,
        )
        hidden_states = residual + self.self_attn_layer_scale(hidden_states)

        # Fully Connected
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + self.mlp_layer_scale(hidden_states)

        return hidden_states


@auto_docstring
class Qwen3TTSTokenizerV2DecoderTransformerModel(Qwen3TTSTokenizerV2DecoderPreTrainedModel):
    _can_record_outputs = {
        "hidden_states": Qwen3TTSTokenizerV2DecoderTransformerLayer,
        "attentions": Qwen3TTSTokenizerV2DecoderAttention,
    }

    def __init__(self, config: Qwen3TTSTokenizerV2DecoderConfig):
        super().__init__(config)
        self.layers = nn.ModuleList(
            [
                Qwen3TTSTokenizerV2DecoderTransformerLayer(config, layer_idx)
                for layer_idx in range(config.num_hidden_layers)
            ]
        )
        self.norm = Qwen3TTSTokenizerV2DecoderRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.rotary_emb = Qwen3TTSTokenizerV2DecoderRotatoryEmbedding(config=config)
        self.gradient_checkpointing = False
        self.has_sliding_layers = "sliding_attention" in self.config.layer_types
        self.window_size = config.sliding_window

        self.input_proj = nn.Linear(config.latent_dim, config.hidden_size)
        self.output_proj = nn.Linear(config.hidden_size, config.latent_dim)

        # Initialize weights and apply final processing
        self.post_init()

    # Note: @check_model_inputs decorator removed for vLLM compatibility
    # The decorator causes "unexpected keyword argument 'inputs_embeds'" error
    @auto_docstring
    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        position_ids=None,
        past_key_values=None,
        inputs_embeds=None,
        use_cache=None,
        cache_position=None,
        **kwargs,
    ) -> BaseModelOutputWithPast:
        r"""
        cache_position (`torch.LongTensor` of shape `(sequence_length)`, *optional*):
            Indices depicting the position of the input sequence tokens in the sequence. Used to update the cache.
        """
        if input_ids is not None:
            raise ValueError("input_ids is not expected")
        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)

        inputs_embeds = self.input_proj(inputs_embeds)

        if use_cache and past_key_values is None:
            past_key_values = DynamicCache(config=self.config)

        if cache_position is None:
            past_seen_tokens = past_key_values.get_seq_length() if past_key_values is not None else 0
            cache_position = torch.arange(
                past_seen_tokens,
                past_seen_tokens + inputs_embeds.shape[1],
                device=inputs_embeds.device,
            )

        if position_ids is None:
            position_ids = cache_position.unsqueeze(0)

        hidden_states = inputs_embeds

        if not isinstance(causal_mask_mapping := attention_mask, dict):
            mask_kwargs = {
                "config": self.config,
                "attention_mask": attention_mask,
                "past_key_values": past_key_values,
                "position_ids": position_ids,
            }
            sig = inspect.signature(create_causal_mask)
            if "input_embeds" in sig.parameters:
                mask_kwargs["input_embeds"] = inputs_embeds
                mask_kwargs["cache_position"] = cache_position
            else:
                mask_kwargs["inputs_embeds"] = inputs_embeds
            causal_mask_mapping = {"full_attention": create_causal_mask(**mask_kwargs)}
            if self.has_sliding_layers:
                causal_mask_mapping["sliding_attention"] = create_sliding_window_causal_mask(**mask_kwargs)

        # create position embeddings to be shared across the decoder layers
        position_embeddings = self.rotary_emb(hidden_states, position_ids)

        for decoder_layer in self.layers[: self.config.num_hidden_layers]:
            hidden_states = decoder_layer(
                hidden_states,
                attention_mask=causal_mask_mapping[decoder_layer.attention_type],
                position_ids=position_ids,
                past_key_values=past_key_values,
                use_cache=use_cache,
                cache_position=cache_position,
                position_embeddings=position_embeddings,
                **kwargs,
            )

        hidden_states = self.norm(hidden_states)
        hidden_states = self.output_proj(hidden_states)
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=past_key_values if use_cache else None,
        )


class Qwen3TTSTokenizerV2DecoderDecoderResidualUnit(nn.Module):
    def __init__(self, dim: int = 16, dilation: int = 1):
        super().__init__()

        self.act1 = SnakeBeta(dim)
        self.conv1 = Qwen3TTSTokenizerV2CausalConvNet(dim, dim, kernel_size=7, dilation=dilation)
        self.act2 = SnakeBeta(dim)
        self.conv2 = Qwen3TTSTokenizerV2CausalConvNet(dim, dim, kernel_size=1)

    def forward(self, hidden_state):
        residual = hidden_state

        hidden_state = self.act1(hidden_state)
        hidden_state = self.conv1(hidden_state)
        hidden_state = self.act2(hidden_state)
        hidden_state = self.conv2(hidden_state)
        return hidden_state + residual


class Qwen3TTSTokenizerV2DecoderDecoderBlock(Qwen3TTSTokenizerV2DecoderPreTrainedModel):
    def __init__(self, config: Qwen3TTSTokenizerV2DecoderConfig, layer_idx):
        super().__init__(config)
        in_dim = config.decoder_dim // 2**layer_idx
        out_dim = config.decoder_dim // 2 ** (layer_idx + 1)
        upsample_rate = config.upsample_rates[layer_idx]

        block = [
            SnakeBeta(in_dim),
            Qwen3TTSTokenizerV2CausalTransConvNet(in_dim, out_dim, 2 * upsample_rate, upsample_rate),
        ]

        for dilation in (1, 3, 9):
            block.append(Qwen3TTSTokenizerV2DecoderDecoderResidualUnit(out_dim, dilation))

        self.block = nn.ModuleList(block)

    def forward(self, hidden):
        for block in self.block:
            hidden = block(hidden)
        return hidden


class EuclideanCodebook(nn.Module):
    def __init__(
        self,
        dim: int,
        codebook_size: int,
        epsilon: float = 1e-5,
    ):
        super().__init__()
        self.dim = dim
        self.codebook_size = codebook_size
        self.epsilon = epsilon

        self.cluster_usage = nn.Parameter(torch.ones(codebook_size))
        self.embedding_sum = nn.Parameter(torch.zeros(codebook_size, dim))

    def decode(self, codes: torch.Tensor) -> torch.Tensor:
        embedding = self.embedding_sum / self.cluster_usage.clamp(min=self.epsilon)[:, None]
        quantized = F.embedding(codes, embedding)
        return quantized


class VectorQuantization(nn.Module):
    def __init__(
        self,
        dim: int,
        codebook_size: int,
        codebook_dim: int | None = None,
        epsilon: float = 1e-5,
    ):
        super().__init__()
        if codebook_dim is None:
            codebook_dim = dim

        requires_projection = codebook_dim != dim

        self.project_out = nn.Linear(codebook_dim, dim) if requires_projection else nn.Identity()
        self.epsilon = epsilon
        self._codebook = EuclideanCodebook(dim=codebook_dim, codebook_size=codebook_size, epsilon=epsilon)
        self.codebook_size = codebook_size

    def decode(self, codes: torch.Tensor) -> torch.Tensor:
        quantized = self._codebook.decode(codes)
        quantized = self.project_out(quantized)
        quantized = quantized.transpose(1, 2)
        return quantized


class ResidualVectorQuantization(nn.Module):
    def __init__(self, *, num_quantizers: int, **kwargs):
        super().__init__()
        self.layers = nn.ModuleList([VectorQuantization(**kwargs) for _ in range(num_quantizers)])

    def decode(self, codes: torch.Tensor) -> torch.Tensor:
        quantized = torch.zeros([1], device=codes.device)[0]
        for idx, layer_codes in enumerate(codes):
            layer = self.layers[idx]
            assert isinstance(layer, VectorQuantization)
            quantized = quantized + layer.decode(layer_codes)
        return quantized


class ResidualVectorQuantizer(nn.Module):
    def __init__(
        self,
        dimension: int = 128,
        input_dimension: int | None = None,
        output_dimension: int | None = None,
        n_q: int = 8,
        q_dropout: bool = False,
        no_quantization_rate: float = 0.0,
        bins: int = 1024,
        decay: float = 0.99,
        force_projection: bool = False,
    ):
        super().__init__()
        self.max_n_q = n_q
        self.n_q = n_q
        self.q_dropout = q_dropout
        self.no_quantization_rate = no_quantization_rate
        self.dimension = dimension
        self.input_dimension = input_dimension or dimension
        self.output_dimension = output_dimension or dimension
        self.bins = bins
        self.decay = decay
        self.input_proj: torch.nn.Module
        self.output_proj: torch.nn.Module
        if self.input_dimension == self.dimension and not force_projection:
            self.input_proj = torch.nn.Identity()
        else:
            self.input_proj = torch.nn.Conv1d(self.input_dimension, self.dimension, 1, bias=False)
        if self.output_dimension == self.dimension and not force_projection:
            self.output_proj = torch.nn.Identity()
        else:
            self.output_proj = torch.nn.Conv1d(self.dimension, self.output_dimension, 1, bias=False)
        self.vq = ResidualVectorQuantization(dim=self.dimension, codebook_size=self.bins, num_quantizers=self.n_q)

    def decode(self, codes: torch.Tensor) -> torch.Tensor:
        codes = codes.transpose(0, 1)
        quantized = self.vq.decode(codes)
        quantized = self.output_proj(quantized)
        return quantized


class SplitResidualVectorQuantizer(nn.Module):
    """Residual Vector Quantizer with separate projections for the first quantizer and the rest.

    Args:
        n_q (int): Number of residual vector quantizers used.
        n_q_semantic (int): Number of residual vector quantizers used for the semantic quantizer.
        **kwargs: Arguments to the constructor of `ResidualVectorQuantizer` that are shared between both.
    """

    def __init__(
        self,
        *,
        n_q: int = 8,
        n_q_semantic: int = 1,
        **kwargs: Any,
    ):
        super().__init__()
        assert n_q > n_q_semantic, (
            f"Number of quantizers {n_q} must be larger than the number of semantic quantizers {n_q_semantic}."
        )
        self.max_n_q = n_q
        self.n_q_semantic = n_q_semantic
        self.n_q_acoustic = n_q - n_q_semantic
        q_dropout = kwargs.pop("q_dropout", False)
        self.rvq_first = ResidualVectorQuantizer(n_q=n_q_semantic, force_projection=True, q_dropout=False, **kwargs)
        self.rvq_rest = ResidualVectorQuantizer(
            n_q=n_q - n_q_semantic,
            force_projection=True,
            q_dropout=q_dropout,
            **kwargs,
        )

    def decode(self, codes: torch.Tensor) -> torch.Tensor:
        """Decode the given codes to the quantized representation."""
        # codes is [B, K, T], with T frames, K nb of codebooks.
        quantized = self.rvq_first.decode(codes[:, : self.n_q_semantic])
        if codes.shape[1] > self.n_q_semantic:
            quantized += self.rvq_rest.decode(codes[:, self.n_q_semantic :])
        return quantized


_CONV_CONTEXT_FRAME = 2
_DOWNSTREAM_CONTEXT_FRAME = 12


class Qwen3TTSTokenizerV2Decoder(Qwen3TTSTokenizerV2DecoderPreTrainedModel):
    def __init__(self, config: Qwen3TTSTokenizerV2DecoderConfig):
        super().__init__(config)
        self.total_upsample = np.prod(config.upsample_rates + config.upsampling_ratios)
        self.upsample_factor = np.prod(config.upsampling_ratios)
        self.pre_transformer = Qwen3TTSTokenizerV2DecoderTransformerModel._from_config(config)

        self.quantizer = SplitResidualVectorQuantizer(
            dimension=config.codebook_dim // 2,
            n_q=config.num_quantizers,
            n_q_semantic=1,
            bins=config.codebook_size,
            input_dimension=config.codebook_dim,
            output_dimension=config.codebook_dim,
        )

        self.pre_conv = Qwen3TTSTokenizerV2CausalConvNet(
            config.codebook_dim,
            config.latent_dim,
            kernel_size=3,
        )

        upsample = []
        for factor in config.upsampling_ratios:
            upsample.append(
                nn.ModuleList(
                    [
                        Qwen3TTSTokenizerV2CausalTransConvNet(config.latent_dim, config.latent_dim, factor, factor),
                        Qwen3TTSTokenizerV2ConvNeXtBlock(config.latent_dim),
                    ]
                )
            )
        self.upsample = nn.ModuleList(upsample)

        decoder = [Qwen3TTSTokenizerV2CausalConvNet(config.latent_dim, config.decoder_dim, 7)]
        for i in range(len(config.upsample_rates)):
            decoder.append(Qwen3TTSTokenizerV2DecoderDecoderBlock(config, i))
        output_dim = config.decoder_dim // 2 ** len(config.upsample_rates)
        decoder += [
            SnakeBeta(output_dim),
            Qwen3TTSTokenizerV2CausalConvNet(output_dim, 1, 7),
        ]
        self.decoder = nn.ModuleList(decoder)

        self.post_init()

        # CUDA Graph support
        self._cudagraph_enabled = False
        self._cudagraph_wrapper = None

    def model_local_kv_specs(self):
        """Declare this decoder's attention KV.

        Only the async-chunk path holds KV. In stateless mode the decoder runs
        ``_forward_exact``, which calls ``pre_transformer`` without
        ``use_cache`` and allocates no cache at all, so declaring a per-request
        cache there invents memory that does not exist. The previous revision
        did exactly that and reported over a gigabyte for stateless
        deployments; the one before it hung the declaration off the CUDA-graph
        wrapper and so reported zero under ``enforce_eager``, where the eager
        async-chunk path does allocate. Both mistakes come from tying this to
        the wrong condition.

        Two entries when async-chunk is on: the retained per-request cache, and
        the working copy ``_decode_icl_first_chunk`` deep-copies from it, which
        is live at the same time.

        The wrapper, when present, adds the graph-resident copies. It is a
        plain object rather than a submodule, so the module-tree walk cannot
        reach it; this is the hop it needs.
        """
        from vllm_omni.model_executor.models.model_local_kv import (
            ModelLocalKVScope,
            RowDriver,
            spec_from_hf_config,
        )

        config = self.config
        try:
            dtype = next(self.parameters()).dtype
        except StopIteration:  # parameterless stub, only reachable in tests
            return []

        window = int(getattr(config, "sliding_window", 0) or 0)
        if window <= 1:
            return []

        specs = []
        wrapper = getattr(self, "_cudagraph_wrapper", None)
        # async_chunk is the wrapper's record of the mode; without a wrapper the
        # decoder has not been told, and only the stateless path is reachable.
        if wrapper is not None and getattr(wrapper, "async_chunk", False):
            common = dict(
                config=config,
                dtype=dtype,
                physical_capacity_positions=window - 1,
                capacity_source=f"sliding_window({window}) - 1",
                rows=RowDriver.MAX_NUM_SEQS,
            )
            specs.append(
                spec_from_hf_config(
                    name="codec_decoder_request",
                    scope=ModelLocalKVScope.REQUEST,
                    allocation_note="retained across chunks of one request",
                    **common,
                )
            )
            specs.append(
                spec_from_hf_config(
                    name="codec_decoder_working_copy",
                    scope=ModelLocalKVScope.INVOCATION,
                    allocation_note="deep-copied from the retained cache each chunk; live alongside it",
                    **common,
                )
            )
        if wrapper is not None:
            specs.extend(wrapper.model_local_kv_specs())
        return specs

    def precompute_snake_caches(self):
        """Precompute exp(alpha) and 1/(exp(beta)+eps) for all SnakeBeta modules."""
        count = 0
        for module in self.modules():
            if isinstance(module, SnakeBeta):
                module.precompute_exp_cache()
                count += 1
        if count > 0:
            logger.info("Precomputed exp caches for %d SnakeBeta activations", count)

    def enable_cudagraph(
        self,
        capture_batch_sizes: list[int] | None = None,
        stateless_capture_sizes: list[int] | None = None,
        device: torch.device | None = None,
        codec_chunk_frames: int = 0,
        codec_left_context_frames: int = 0,
        initial_codec_chunk_frames: int = 1,
        codec_chunk_ramp: list[int] | None = None,
        async_chunk: bool = True,
        decode_chunk_size: int = 300,
        decode_left_context: int = 25,
    ):
        # from ..cuda_graph_decoder_wrapper import CUDAGraphDecoderWrapper
        from ..segmented_graph_wrapper import CUDAGraphDecoderWrapper

        if device is None:
            device = next(self.parameters()).device
        if device.type != "cuda":
            logger.warning("Cannot enable CUDA Graph: decoder is not on a CUDA device (got %s)", device)
            return

        self._cudagraph_wrapper = CUDAGraphDecoderWrapper(
            decoder=self,
            capture_batch_sizes=capture_batch_sizes,
            stateless_capture_sizes=stateless_capture_sizes,
            num_quantizers=self.config.num_quantizers,
            enabled=True,
            async_chunk=async_chunk,
            initial_chunk_frames=initial_codec_chunk_frames,
            codec_chunk_frames=codec_chunk_frames or 25,
            codec_chunk_ramp=codec_chunk_ramp,
            decode_chunk_size=decode_chunk_size,
            decode_left_context=decode_left_context,
        )
        self._incremental_chunk_frames = codec_chunk_frames or 25
        self._incremental_chunk_ramp = list(codec_chunk_ramp or ())
        self._cudagraph_wrapper.warmup(
            device,
            dtype=torch.long,
        )
        self._cudagraph_enabled = True
        logger.info(
            "CUDA Graph enabled for decoder: batch_sizes=%s seq_lens=%s",
            self._cudagraph_wrapper.capture_batch_sizes,
            (
                self._cudagraph_wrapper.icl_capture_sizes
                if async_chunk
                else self._cudagraph_wrapper.stateless_capture_sizes
            ),
        )

    def _forward_exact(self, codes):
        hidden = self.quantizer.decode(codes)
        hidden = self.pre_conv(hidden).transpose(1, 2)

        hidden = self.pre_transformer(inputs_embeds=hidden).last_hidden_state
        hidden = hidden.permute(0, 2, 1)
        for blocks in self.upsample:
            for block in blocks:
                hidden = block(hidden)

        wav = hidden
        for block in self.decoder:
            wav = block(wav)
        return wav.clamp(min=-1, max=1)

    def _decode_icl_first_chunk(
        self,
        codes,
        caches,
        prefix_frames,
        prefix_cache=None,
        prefix_hidden_mask=None,
        prefix_attention_mask=None,
        suffix_attention_mask=None,
    ):
        # The CUDA graph path may left-pad a shorter request prefix to the
        # captured sliding-window length.  Keep the decoder's physical layout
        # separate from the request metadata so eager fallbacks slice the
        # cached tensors at the correct boundary.
        caches["decoder_prefix_frames"] = prefix_frames
        hidden = self.quantizer.decode(codes)
        if prefix_hidden_mask is not None:
            hidden = hidden * prefix_hidden_mask
        caches.update({"ref_hidden": hidden[:, :, :prefix_frames]})
        caches.update({"suffix_quantized": hidden[:, :, prefix_frames:]})

        hidden = self.pre_conv(hidden).transpose(1, 2)
        caches.update({"ref_conv": hidden[:, :prefix_frames, :]})
        caches.update({"suffix_conv": hidden[:, prefix_frames:, :]})

        if hidden.shape[1] < prefix_frames:
            raise ValueError(
                "Qwen3-TTS ICL prefix cache requires at least prefix_frames inputs, "
                f"got prefix_frames={prefix_frames}, total_frames={hidden.shape[1]}"
            )
        prefix_result = self.pre_transformer(
            inputs_embeds=hidden[:, :prefix_frames, :],
            attention_mask=prefix_attention_mask,
            past_key_values=prefix_cache,
            use_cache=True,
        )

        prefix_cache = prefix_result.past_key_values
        working_cache = copy.deepcopy(prefix_cache)

        suffix_result = self.pre_transformer(
            inputs_embeds=hidden[:, prefix_frames:, :],
            attention_mask=suffix_attention_mask,
            past_key_values=working_cache,
            use_cache=True,
        )

        prefix_hidden = prefix_result.last_hidden_state
        if prefix_attention_mask is not None:
            prefix_hidden = prefix_hidden * prefix_attention_mask.unsqueeze(-1)
        hidden = torch.cat(
            [
                prefix_hidden,
                suffix_result.last_hidden_state,
            ],
            dim=1,
        )
        caches.update({"past_key_values": prefix_cache})
        caches.update({"prefix_hidden": prefix_hidden})

        hidden = hidden.permute(0, 2, 1)

        for blocks in self.upsample:
            for block in blocks:
                hidden = block(hidden)
        wav = hidden

        for block in self.decoder:
            wav = block(wav)
        wav = wav.clamp(min=-1, max=1)
        return wav

    def _decode_xvec_first_chunk(self, codes: torch.Tensor, caches: dict) -> torch.Tensor:
        """Initialize prefixless incremental state from the first codec chunk."""
        hidden = self.quantizer.decode(codes)
        caches["decoder_prefix_frames"] = 0
        caches["ref_hidden"] = hidden[:, :, :0]
        caches["suffix_quantized"] = hidden

        hidden = self.pre_conv(hidden).transpose(1, 2)
        caches["ref_conv"] = hidden[:, :0, :]
        caches["suffix_conv"] = hidden

        empty_prefix_cache = caches.get("past_key_values")
        if empty_prefix_cache is None:
            empty_prefix_cache = DynamicCache(config=self.config)
            head_dim = getattr(
                self.config,
                "head_dim",
                self.config.hidden_size // self.config.num_attention_heads,
            )
            empty_prefix_cache.early_initialization(
                batch_size=int(codes.shape[0]),
                num_heads=self.config.num_key_value_heads,
                head_dim=head_dim,
                dtype=hidden.dtype,
                device=hidden.device,
            )
        working_cache = copy.deepcopy(empty_prefix_cache)
        suffix_hidden = self.pre_transformer(
            inputs_embeds=hidden,
            past_key_values=working_cache,
            use_cache=True,
        ).last_hidden_state
        caches["past_key_values"] = empty_prefix_cache
        caches["prefix_hidden"] = suffix_hidden[:, :0, :]

        hidden = suffix_hidden.permute(0, 2, 1)
        for blocks in self.upsample:
            for block in blocks:
                hidden = block(hidden)
        wav = hidden
        for block in self.decoder:
            wav = block(wav)
        caches["suffix_frames"] = int(codes.shape[-1])
        return wav.clamp(min=-1, max=1)

    def _decode_suffix(
        self,
        new_codes: torch.Tensor,
        old_quantized: torch.Tensor,
        old_conv: torch.Tensor,
        caches: dict,
        prefix_frames: int,
        new_frames: int,
        rolling: bool,
        attention_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        ref_hidden = caches["ref_hidden"]
        conv_context = torch.cat([ref_hidden, old_quantized], dim=-1)[:, :, -_CONV_CONTEXT_FRAME:]
        suffix_cache_length = int(self.config.sliding_window)

        new_quantized = self.quantizer.decode(new_codes)
        new_conv_input = torch.cat([conv_context, new_quantized], dim=-1)
        new_conv = self.pre_conv(new_conv_input)
        new_conv = new_conv[:, :, -new_codes.shape[-1] :].transpose(1, 2)

        if rolling:
            boundary_input = torch.cat(
                [ref_hidden[:, :, -_CONV_CONTEXT_FRAME:], old_quantized[:, :, :_CONV_CONTEXT_FRAME]],
                dim=-1,
            )
            boundary_conv = self.pre_conv(boundary_input)
            boundary_conv = boundary_conv[:, :, -_CONV_CONTEXT_FRAME:].transpose(1, 2)
            suffix_conv = torch.cat([boundary_conv, old_conv, new_conv], dim=1)
        else:
            suffix_conv = torch.cat([old_conv, new_conv], dim=1)

        next_quantized = torch.cat([old_quantized, new_quantized], dim=-1)[:, :, -suffix_cache_length:]
        next_conv = suffix_conv[:, -(suffix_cache_length - _CONV_CONTEXT_FRAME) :, :]

        hidden = torch.cat([caches["ref_conv"], suffix_conv], dim=1)
        hidden = hidden.transpose(1, 2).contiguous().transpose(1, 2)
        working_cache = copy.deepcopy(caches["past_key_values"])
        suffix_hidden = self.pre_transformer(
            inputs_embeds=hidden[:, prefix_frames:, :],
            attention_mask=attention_mask,
            past_key_values=working_cache,
            use_cache=True,
        ).last_hidden_state
        hidden = torch.cat([caches["prefix_hidden"], suffix_hidden], dim=1)

        required_frames = min(hidden.shape[1], new_frames + _DOWNSTREAM_CONTEXT_FRAME)
        hidden = hidden[:, -required_frames:, :].permute(0, 2, 1)
        for blocks in self.upsample:
            for block in blocks:
                hidden = block(hidden)

        wav = hidden
        for block in self.decoder:
            wav = block(wav)
        wav = wav[..., -new_frames * self.total_upsample :].clamp(min=-1, max=1)
        return wav, next_quantized, next_conv

    def _is_suffix_cache_rolling(self, previous_suffix_frames: int, cached_frames: int) -> bool:
        suffix_cache_length = int(self.config.sliding_window)
        return previous_suffix_frames >= suffix_cache_length and cached_frames == suffix_cache_length

    def decode_suffix(self, new_codes, caches, prefix_frames):
        previous_suffix_frames = int(caches.get("suffix_frames", caches["suffix_quantized"].shape[-1]))
        cached_frames = int(caches["suffix_quantized"].shape[-1])
        suffix_cache_length = int(self.config.sliding_window)
        rolling = self._is_suffix_cache_rolling(previous_suffix_frames, cached_frames)
        retained_frames = suffix_cache_length if rolling else previous_suffix_frames
        new_frames = int(new_codes.shape[-1])
        max_new_frames = int(getattr(self, "_incremental_chunk_frames", 25))
        if not 0 < new_frames <= max_new_frames:
            raise ValueError(
                f"Qwen3-TTS incremental decode expected 1..{max_new_frames} new frames, got new_frames={new_frames}"
            )

        attention_mask = torch.ones(
            new_codes.shape[0],
            prefix_frames + retained_frames + new_frames,
            dtype=torch.bool,
            device=new_codes.device,
        )
        attention_mask[:, : int(caches.get("prefix_pad_frames", 0))] = 0
        output, next_quantized, next_conv = self._decode_suffix(
            new_codes,
            caches["suffix_quantized"],
            caches["suffix_conv"],
            caches,
            prefix_frames,
            new_frames,
            rolling,
            attention_mask=attention_mask,
        )
        caches["suffix_quantized"] = next_quantized
        caches["suffix_conv"] = next_conv
        caches["suffix_frames"] = retained_frames + new_frames
        return output

    def forward(self, codes, caches=None):
        if codes.shape[1] != self.config.num_quantizers:
            raise ValueError(f"Expected {self.config.num_quantizers} layer of codes, got {codes.shape[1]}")

        if caches is None or caches.get("_is_dummy_run", False):
            return self._forward_exact(codes)

        prefix_frames = int(caches["prefix_frames"])
        if prefix_frames < 0:
            raise ValueError(
                "Qwen3-TTS ICL prefix cache received invalid frame counts: "
                f"prefix_frames={prefix_frames}, total_frames={codes.shape[-1]}"
            )

        if "suffix_quantized" not in caches:
            if codes.shape[-1] < prefix_frames:
                raise ValueError(
                    "Qwen3-TTS ICL first chunk is shorter than its prefix: "
                    f"prefix_frames={prefix_frames}, total_frames={codes.shape[-1]}"
                )
            if prefix_frames == 0:
                return self._decode_xvec_first_chunk(codes, caches)
            return self._decode_icl_first_chunk(codes, caches, prefix_frames)
        else:
            decoder_prefix_frames = int(caches.get("decoder_prefix_frames", prefix_frames))
            return self.decode_suffix(codes, caches, decoder_prefix_frames)

    def chunked_decode(
        self,
        codes,
        caches=None,
        chunk_size=300,
        left_context_size=25,
    ):
        # Use CUDA graph if enabled
        if self._cudagraph_enabled and self._cudagraph_wrapper is not None:
            return self._cudagraph_wrapper.chunked_decode_with_cudagraph(
                codes,
                caches=caches,
                chunk_size=chunk_size,
                left_context_size=left_context_size,
            )

        # Original implementation (eager mode)
        wavs = []
        start_index = 0
        while start_index < codes.shape[-1]:
            end_index = min(start_index + chunk_size, codes.shape[-1])
            context_size = left_context_size if start_index - left_context_size > 0 else start_index
            codes_chunk = codes[..., start_index - context_size : end_index]
            is_first_stateful_chunk = caches is not None and "suffix_quantized" not in caches
            wav_chunk = self(codes_chunk, caches)
            if caches is not None:
                if is_first_stateful_chunk:
                    logical_prefix_frames = int(caches["prefix_frames"])
                    suffix_frames = codes_chunk.shape[-1] - logical_prefix_frames
                    wav_chunk = wav_chunk[..., -suffix_frames * self.total_upsample :]
                wavs.append(wav_chunk)
            else:
                wavs.append(wav_chunk[..., context_size * self.total_upsample :])
            start_index = end_index
        output = torch.cat(wavs, dim=-1)
        return output

    def batched_request_decode(
        self,
        codes_list: list[torch.Tensor],
        request_caches: list[dict[str, Any]],
        *,
        prefix_length: int,
        initial_chunk_frames: int,
        codec_chunk_frames: int,
        transitions_by_mode: dict[str, dict[int, int]],
        decode_icl_prefix_batch: Callable[[list[torch.Tensor], list[dict[str, Any]]], list[torch.Tensor] | None] | None,
        decode_xvec_prefix_batch: Callable[[list[torch.Tensor], list[dict[str, Any]]], list[torch.Tensor] | None]
        | None,
        decode_suffix_batch: Callable[
            [str, int, list[torch.Tensor], list[dict[str, Any]], list[int]], list[torch.Tensor] | None
        ]
        | None,
        decode_fallback: Callable[[torch.Tensor, dict[str, Any]], torch.Tensor],
        backend_max_batch_size: int = 0,
    ) -> list[torch.Tensor]:
        """Group stateful requests once, then execute them with a supplied backend.

        The grouping policy is shared by CUDA Graph and eager execution.  A
        backend may decline a grouped decode by returning ``None``; requests in
        that group are then decoded individually through ``decode_fallback``.
        """
        if len(codes_list) != len(request_caches):
            raise ValueError("codes_list and request_caches must have the same length")

        if torch.cuda.is_available() and torch.cuda.is_current_stream_capturing():
            return [self._forward_exact(codes) for codes in codes_list]

        outputs: list[torch.Tensor | None] = [None] * len(codes_list)
        groups: dict[tuple[str, int], list[int]] = {}
        for index, (codes, cache) in enumerate(zip(codes_list, request_caches, strict=True)):
            if "suffix_quantized" not in cache:
                prefix_frames = int(cache["prefix_frames"])
                suffix_frames = int(codes.shape[-1]) - prefix_frames
                if prefix_frames == 0:
                    phase = "xvec_first"
                elif 0 < prefix_frames <= prefix_length and suffix_frames == initial_chunk_frames:
                    phase = "icl_prefix"
                else:
                    phase = "eager"
                groups.setdefault((phase, 0), []).append(index)
                continue

            request_kv = cache["past_key_values"]
            decoder_prefix = int(cache.get("decoder_prefix_frames", cache["prefix_frames"]))
            mode = "xvec" if decoder_prefix == 0 else "icl"
            expected_kv_length = 0 if mode == "xvec" else prefix_length
            if decoder_prefix != expected_kv_length or request_kv.get_seq_length() != expected_kv_length:
                groups.setdefault(("eager", 0), []).append(index)
                continue

            previous = int(cache.get("suffix_frames", cache["suffix_quantized"].shape[-1]))
            rolling = self._is_suffix_cache_rolling(previous, int(cache["suffix_quantized"].shape[-1]))
            target = (
                prefix_length + codec_chunk_frames
                if rolling
                else next(
                    (target for target, source in transitions_by_mode[mode].items() if source == previous),
                    None,
                )
            )
            new_frames = int(codes.shape[-1])
            if target is None or not 0 < new_frames <= codec_chunk_frames:
                groups.setdefault(("eager", 0), []).append(index)
            else:
                groups.setdefault((f"suffix:{mode}", target), []).append(index)

        for (phase, target), indices in groups.items():
            group_splits = (
                [
                    indices[start : start + backend_max_batch_size]
                    for start in range(0, len(indices), backend_max_batch_size)
                ]
                if backend_max_batch_size > 0
                else [indices]
            )
            for split_indices in group_splits:
                group_codes = [codes_list[index] for index in split_indices]
                group_caches = [request_caches[index] for index in split_indices]
                group_outputs: list[torch.Tensor] | None = None
                if phase == "icl_prefix" and decode_icl_prefix_batch is not None:
                    group_outputs = decode_icl_prefix_batch(group_codes, group_caches)
                elif phase == "xvec_first" and decode_xvec_prefix_batch is not None:
                    group_outputs = decode_xvec_prefix_batch(group_codes, group_caches)
                elif phase.startswith("suffix:") and decode_suffix_batch is not None:
                    mode = phase.removeprefix("suffix:")
                    new_frames = [int(codes.shape[-1]) for codes in group_codes]
                    group_outputs = decode_suffix_batch(mode, target, group_codes, group_caches, new_frames)

                if group_outputs is None:
                    group_outputs = [
                        decode_fallback(codes_list[index], request_caches[index]) for index in split_indices
                    ]
                for index, output in zip(split_indices, group_outputs, strict=True):
                    outputs[index] = output

        if any(output is None for output in outputs):
            raise RuntimeError("stateful batched decode did not produce an output for every request")
        return [output for output in outputs if output is not None]

    @staticmethod
    def _batch_dynamic_caches(request_caches: list[DynamicCache]) -> DynamicCache:
        batched_cache = copy.deepcopy(request_caches[0])
        for batched_layer, request_layers in zip(
            batched_cache.layers,
            zip(*(cache.layers for cache in request_caches), strict=True),
            strict=True,
        ):
            if any(layer.keys is None or layer.values is None for layer in request_layers):
                if not all(layer.keys is None and layer.values is None for layer in request_layers):
                    raise ValueError("Cannot batch partially initialized request KV caches")
                batched_layer.keys = None
                batched_layer.values = None
                continue
            batched_layer.keys = torch.cat([layer.keys for layer in request_layers], dim=0)
            batched_layer.values = torch.cat([layer.values for layer in request_layers], dim=0)
        return batched_cache

    @staticmethod
    def _slice_dynamic_cache(cache: DynamicCache, row: int) -> DynamicCache:
        request_cache = copy.deepcopy(cache)
        for layer in request_cache.layers:
            if layer.keys is not None:
                layer.keys = layer.keys[row : row + 1].clone()
            if layer.values is not None:
                layer.values = layer.values[row : row + 1].clone()
        return request_cache

    @staticmethod
    def _cache_tensors_are_batchable(request_caches: list[dict[str, Any]], keys: tuple[str, ...]) -> bool:
        return all(
            key in cache
            and cache[key].shape[1:] == request_caches[0][key].shape[1:]
            and cache[key].dtype == request_caches[0][key].dtype
            and cache[key].device == request_caches[0][key].device
            for cache in request_caches
            for key in keys
        )

    def _decode_icl_prefix_eager_batch(
        self,
        codes_list: list[torch.Tensor],
        request_caches: list[dict[str, Any]],
        *,
        prefix_length: int,
        initial_chunk_frames: int,
    ) -> list[torch.Tensor] | None:
        batch_size = len(codes_list)
        total_frames = prefix_length + initial_chunk_frames
        batched_codes = codes_list[0].new_zeros((batch_size, codes_list[0].shape[1], total_frames))
        hidden_mask = torch.ones((batch_size, 1, total_frames), dtype=self.dtype, device=batched_codes.device)
        prefix_mask = torch.ones((batch_size, prefix_length), dtype=torch.bool, device=batched_codes.device)
        suffix_mask = torch.ones((batch_size, total_frames), dtype=torch.bool, device=batched_codes.device)
        prefix_pads: list[int] = []
        for row, (codes, cache) in enumerate(zip(codes_list, request_caches, strict=True)):
            prefix_frames = int(cache["prefix_frames"])
            suffix_frames = int(codes.shape[-1]) - prefix_frames
            if not 0 < prefix_frames <= prefix_length or suffix_frames != initial_chunk_frames:
                return None
            prefix_pad = prefix_length - prefix_frames
            prefix_pads.append(prefix_pad)
            batched_codes[row, :, prefix_pad:prefix_length].copy_(codes[0, :, :prefix_frames])
            batched_codes[row, :, prefix_length:].copy_(codes[0, :, prefix_frames:])
            hidden_mask[row, :, :prefix_pad] = 0
            prefix_mask[row, :prefix_pad] = 0
            suffix_mask[row, :prefix_pad] = 0

        batched_cache: dict[str, Any] = {}
        output = self._decode_icl_first_chunk(
            batched_codes,
            batched_cache,
            prefix_length,
            prefix_hidden_mask=hidden_mask,
            prefix_attention_mask=prefix_mask,
            suffix_attention_mask=suffix_mask,
        )
        outputs: list[torch.Tensor] = []
        for row, (cache, prefix_pad) in enumerate(zip(request_caches, prefix_pads, strict=True)):
            for key in ("ref_hidden", "ref_conv", "prefix_hidden", "suffix_quantized", "suffix_conv"):
                cache[key] = batched_cache[key][row : row + 1].clone()
            cache["past_key_values"] = self._slice_dynamic_cache(batched_cache["past_key_values"], row)
            cache["decoder_prefix_frames"] = prefix_length
            cache["prefix_pad_frames"] = prefix_pad
            cache["suffix_frames"] = initial_chunk_frames
            outputs.append(output[row : row + 1, :, -initial_chunk_frames * self.total_upsample :].clone())
        return outputs

    def _decode_xvec_prefix_eager_batch(
        self,
        codes_list: list[torch.Tensor],
        request_caches: list[dict[str, Any]],
        *,
        initial_chunk_frames: int,
    ) -> list[torch.Tensor] | None:
        if any(int(codes.shape[-1]) != initial_chunk_frames for codes in codes_list):
            return None
        batched_codes = torch.cat(codes_list, dim=0)
        batched_cache: dict[str, Any] = {}
        output = self._decode_xvec_first_chunk(batched_codes, batched_cache)
        outputs: list[torch.Tensor] = []
        for row, cache in enumerate(request_caches):
            for key in ("ref_hidden", "ref_conv", "prefix_hidden", "suffix_quantized", "suffix_conv"):
                cache[key] = batched_cache[key][row : row + 1].clone()
            cache["past_key_values"] = self._slice_dynamic_cache(batched_cache["past_key_values"], row)
            cache["decoder_prefix_frames"] = 0
            cache["suffix_frames"] = initial_chunk_frames
            outputs.append(output[row : row + 1].clone())
        return outputs

    def _decode_suffix_eager_batch(
        self,
        mode: str,
        target_frames: int,
        codes_list: list[torch.Tensor],
        request_caches: list[dict[str, Any]],
        new_frames_list: list[int],
        *,
        prefix_length: int,
        codec_chunk_frames: int,
        transitions_by_mode: dict[str, dict[int, int]],
    ) -> list[torch.Tensor] | None:
        tensor_keys = ("ref_hidden", "ref_conv", "prefix_hidden", "suffix_quantized", "suffix_conv")
        if not self._cache_tensors_are_batchable(request_caches, tensor_keys):
            return None
        previous_frames = transitions_by_mode[mode].get(target_frames)
        if previous_frames is None:
            return None
        expected_new_frames = target_frames - previous_frames
        if any(not 0 < new_frames <= expected_new_frames for new_frames in new_frames_list):
            return None

        batched_codes = codes_list[0].new_zeros((len(codes_list), codes_list[0].shape[1], expected_new_frames))
        for row, (codes, new_frames) in enumerate(zip(codes_list, new_frames_list, strict=True)):
            batched_codes[row, :, :new_frames].copy_(codes[0, :, -new_frames:])
        batched_cache = {
            key: torch.cat([cache[key] for cache in request_caches], dim=0)
            for key in ("ref_hidden", "ref_conv", "prefix_hidden")
        }
        try:
            batched_cache["past_key_values"] = self._batch_dynamic_caches(
                [cache["past_key_values"] for cache in request_caches]
            )
        except ValueError:
            return None
        attention_mask = torch.ones(
            len(codes_list),
            (prefix_length if mode == "icl" else 0) + previous_frames + expected_new_frames,
            dtype=torch.bool,
            device=batched_codes.device,
        )
        if mode == "icl":
            for row, cache in enumerate(request_caches):
                attention_mask[row, : int(cache.get("prefix_pad_frames", 0))] = 0
        old_quantized = torch.cat([cache["suffix_quantized"] for cache in request_caches], dim=0)
        old_conv = torch.cat([cache["suffix_conv"] for cache in request_caches], dim=0)
        rolling = self._is_suffix_cache_rolling(previous_frames, int(old_quantized.shape[-1]))
        output, next_quantized, next_conv = self._decode_suffix(
            batched_codes,
            old_quantized,
            old_conv,
            batched_cache,
            prefix_length if mode == "icl" else 0,
            expected_new_frames,
            rolling,
            attention_mask=attention_mask,
        )

        outputs: list[torch.Tensor] = []
        for row, (cache, new_frames) in enumerate(zip(request_caches, new_frames_list, strict=True)):
            outputs.append(output[row : row + 1, :, : new_frames * self.total_upsample].clone())
            if new_frames == expected_new_frames:
                cache["suffix_quantized"] = next_quantized[row : row + 1].clone()
                cache["suffix_conv"] = next_conv[row : row + 1].clone()
                cache["suffix_frames"] = target_frames
        return outputs

    def batched_chunked_decode(
        self,
        codes,
        lengths,
        caches=None,
        chunk_size=300,
        left_context_size=25,
        max_batch_size=0,
    ):
        if (
            self._cudagraph_enabled
            and self._cudagraph_wrapper is not None
            and hasattr(self._cudagraph_wrapper, "batched_chunked_decode_with_cudagraph")
        ):
            return self._cudagraph_wrapper.batched_chunked_decode_with_cudagraph(
                codes,
                lengths,
                caches=caches,
                chunk_size=chunk_size,
                left_context_size=left_context_size,
                max_batch_size=max_batch_size,
            )

        if caches is not None:
            prefix_length = int(getattr(self.config, "sliding_window", 0) or 0)
            initial_codec_chunk_frames = int(getattr(self, "_initial_codec_chunk_frames", 1))
            codec_chunk_frames = int(getattr(self, "_incremental_chunk_frames", 25))
            chunk_ramp = list(getattr(self, "_incremental_chunk_ramp", ()) or ())
            initial_chunk_frames = int(chunk_ramp[0]) if chunk_ramp else initial_codec_chunk_frames
            transitions: dict[int, int] = {}
            previous = initial_chunk_frames
            for new_frames in chunk_ramp[1:]:
                if previous >= prefix_length:
                    break
                target = previous + int(new_frames)
                transitions[target] = previous
                previous = target
            while previous < prefix_length:
                target = previous + codec_chunk_frames
                transitions[target] = previous
                previous = target
            transitions[prefix_length + codec_chunk_frames] = prefix_length
            codes_list = [codes[row : row + 1, :, :length] for row, length in enumerate(lengths)]
            outputs = self.batched_request_decode(
                codes_list,
                caches,
                prefix_length=prefix_length,
                initial_chunk_frames=initial_chunk_frames,
                codec_chunk_frames=codec_chunk_frames,
                transitions_by_mode={"icl": transitions, "xvec": transitions},
                decode_icl_prefix_batch=lambda group_codes, group_caches: self._decode_icl_prefix_eager_batch(
                    group_codes,
                    group_caches,
                    prefix_length=prefix_length,
                    initial_chunk_frames=initial_chunk_frames,
                ),
                decode_xvec_prefix_batch=lambda group_codes, group_caches: self._decode_xvec_prefix_eager_batch(
                    group_codes,
                    group_caches,
                    initial_chunk_frames=initial_chunk_frames,
                ),
                decode_suffix_batch=lambda mode, target, group_codes, group_caches, new_frames: (
                    self._decode_suffix_eager_batch(
                        mode,
                        target,
                        group_codes,
                        group_caches,
                        new_frames,
                        prefix_length=prefix_length,
                        codec_chunk_frames=codec_chunk_frames,
                        transitions_by_mode={"icl": transitions, "xvec": transitions},
                    )
                ),
                decode_fallback=lambda request_codes, cache: self.chunked_decode(
                    request_codes,
                    caches=cache,
                    chunk_size=chunk_size,
                    left_context_size=left_context_size,
                ),
                backend_max_batch_size=max_batch_size,
            )
            return [output[0] for output in outputs]

        from ..cuda_graph_decoder_wrapper import _batched_chunked_decode

        padded = _batched_chunked_decode(
            codes,
            lengths,
            decode_fn=self,
            total_upsample=self.total_upsample,
            chunk_size=chunk_size,
            left_context_size=left_context_size,
            max_batch_size=max_batch_size,
        )
        return [padded[row, :, : length * self.total_upsample] for row, length in enumerate(lengths)]


class Qwen3TTSTokenizerV2Encoder(MimiModel):
    def __init__(self, config: MimiConfig):
        super().__init__(config)
        self.config = config

        self.upsample = None
        self.decoder_transformer = None
        self.decoder = None

        self.post_init()


@auto_docstring
class Qwen3TTSTokenizerV2PreTrainedModel(PreTrainedModel):
    config: Qwen3TTSTokenizerV2Config
    base_model_prefix = "model"
    supports_gradient_checkpointing = True
    _skip_keys_device_placement = "past_key_values"
    _supports_flash_attn = True
    _supports_sdpa = True
    _can_compile_fullgraph = False
    _supports_attention_backend = True


@auto_docstring(
    custom_intro="""
    The Qwen3TTSTokenizerV2 model.
    """
)
class Qwen3TTSTokenizerV2Model(Qwen3TTSTokenizerV2PreTrainedModel):
    def __init__(self, config: Qwen3TTSTokenizerV2Config):
        super().__init__(config)
        self.config = config

        self.encoder_valid_num_quantizers = config.encoder_valid_num_quantizers

        self.input_sample_rate = config.input_sample_rate
        self.output_sample_rate = config.output_sample_rate

        self.decode_upsample_rate = config.decode_upsample_rate
        self.encode_downsample_rate = config.encode_downsample_rate

        self.encoder = Qwen3TTSTokenizerV2Encoder._from_config(self.config.encoder_config)
        self.decoder = Qwen3TTSTokenizerV2Decoder._from_config(self.config.decoder_config)

        self.post_init()

    def get_model_type(self):
        return self.config.model_type

    def get_input_sample_rate(self):
        return self.input_sample_rate

    def get_output_sample_rate(self):
        return self.output_sample_rate

    def get_encode_downsample_rate(self):
        return self.encode_downsample_rate

    def get_decode_upsample_rate(self):
        return self.decode_upsample_rate

    def encode(
        self,
        input_values: torch.Tensor,
        padding_mask: torch.Tensor | None = None,
        return_dict: bool | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor | None] | Qwen3TTSTokenizerV2EncoderOutput:
        """
        Encodes the input audio waveform into discrete codes.

        Args:
            input_values (`torch.Tensor` of shape `(batch_size, sequence_length)`):
                Float values of the input audio waveform.
            padding_mask (`torch.Tensor` of shape `(batch_size, sequence_length)`):
                Indicates which inputs are to be ignored due to padding,
                where elements are either 1 for *not masked* or 0 for *masked*.
            return_dict (`bool`, *optional*):
                Whether or not to return a [`~utils.ModelOutput`] instead of a plain tuple.
        """
        return_dict = return_dict if return_dict is not None else self.config.return_dict

        encoded_frames = self.encoder.encode(input_values=input_values.unsqueeze(1), return_dict=True)
        audio_codes = encoded_frames.audio_codes[:, : self.encoder_valid_num_quantizers]
        audio_codes = [
            code[..., : -(-mask.sum() // self.encode_downsample_rate)].transpose(0, 1)
            for code, mask in zip(audio_codes, padding_mask)
        ]

        if not return_dict:
            return (audio_codes,)

        return Qwen3TTSTokenizerV2EncoderOutput(audio_codes)

    def decode(
        self,
        audio_codes: torch.Tensor,
        return_dict: bool | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor] | Qwen3TTSTokenizerV2DecoderOutput:
        """
        Decodes the given frames into an output audio waveform.

        Note that the output might be a bit bigger than the input. In that case, any extra steps at the end can be
        trimmed.

        Args:
            audio_codes (`torch.LongTensor`  of shape `(batch_size, codes_length, num_quantizers)`, *optional*):
                Discrete code embeddings computed using `model.encode`.
            return_dict (`bool`, *optional*):
                Whether or not to return a [`~utils.ModelOutput`] instead of a plain tuple.

        """
        return_dict = return_dict if return_dict is not None else self.config.return_dict
        audio_lengths = (audio_codes[..., 0] > -1).sum(1) * self.decode_upsample_rate

        audio_codes = torch.clamp(audio_codes, min=0)
        audio_values = self.decoder.chunked_decode(audio_codes.transpose(1, 2)).squeeze(1)

        audio_values = [a[:length] for a, length in zip(audio_values, audio_lengths)]

        if not return_dict:
            return (audio_values,)

        return Qwen3TTSTokenizerV2DecoderOutput(audio_values)


__all__ = ["Qwen3TTSTokenizerV2Model", "Qwen3TTSTokenizerV2PreTrainedModel"]
