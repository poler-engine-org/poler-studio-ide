=================================================================
FILE: pyscf/ao2mo/r_outcore.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
import tempfile import numpy import h5py from pyscf import lib from pyscf import gto from pyscf.lib import logger from pyscf.ao2mo import _ao2mo from pyscf.ao2mo import outcore from pyscf import config
IOBLK_SIZE = getattr(config, 'ao2mo_outcore_ioblk_size', 256)  # 256 MB IOBUF_WORDS = getattr(config, 'ao2mo_outcore_iobuf_words', 1e8)  # 1.6 GB IOBUF_ROW_MIN = getattr(config, 'ao2mo_outcore_row_min', 160) MAX_MEMORY = getattr(config, 'ao2mo_outcore_max_memory', 4000)  # 4GB
def full(mol, mo_coeff, erifile, dataname='eri_mo', intor='int2e_spinor', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN): general(mol, (mo_coeff,)*4, erifile, dataname, intor, aosym, comp, max_memory, ioblk_size, verbose) return erifile
def general(mol, mo_coeffs, erifile, dataname='eri_mo', intor='int2e_spinor', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN): time_0pass = (logger.process_clock(), logger.perf_counter()) log = logger.new_logger(mol, verbose) if '_spinor' not in intor: log.warn('r_ao2mo requires spinor integrals.\n' 'Suffix _spinor is added to %s', intor) intor = intor + '_spinor' intor, comp = gto.moleintor._get_intor_and_comp(mol._add_suffix(intor), comp) klsame = iden_coeffs(mo_coeffs[2], mo_coeffs[3])
transform e1
swapfile will be overwritten if exists.
def half_e1(mol, mo_coeffs, swapfile, intor='int2e_spinor', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, ao2mopt=None): time0 = (logger.process_clock(), logger.perf_counter()) log = logger.new_logger(mol, verbose)
def full_iofree(mol, mo_coeff, intor='int2e_spinor', aosym='s4', comp=None, verbose=logger.WARN, **kwargs): erifile = tempfile.NamedTemporaryFile(dir=lib.param.TMPDIR) general(mol, (mo_coeff,)*4, erifile.name, dataname='eri_mo', intor=intor, aosym=aosym, comp=comp, verbose=verbose) with h5py.File(erifile.name, 'r') as feri: return numpy.asarray(feri['eri_mo'])
def general_iofree(mol, mo_coeffs, intor='int2e_spinor', aosym='s4', comp=None, verbose=logger.WARN, **kwargs): erifile = tempfile.NamedTemporaryFile(dir=lib.param.TMPDIR) general(mol, mo_coeffs, erifile.name, dataname='eri_mo', intor=intor, aosym=aosym, comp=comp, verbose=verbose) with h5py.File(erifile.name, 'r') as feri: return numpy.asarray(feri['eri_mo'])
def iden_coeffs(mo1, mo2): return (id(mo1) == id(mo2)) 
or (mo1.shape==mo2.shape and numpy.allclose(mo1,mo2))
def prange(start, end, step): for i in range(start, end, step): yield i, min(i+step, end)
def guess_e1bufsize(max_memory, ioblk_size, nij_pair, nao_pair, comp): mem_words = max_memory * 1e6 / 16
part of the max_memory is used to hold the AO integrals.  The iobuf is the
buffer to temporary hold the transformed integrals before streaming to disk.
iobuf is then divided to small blocks (ioblk_words) and streamed to disk.
def guess_e2bufsize(ioblk_size, nrows, ncols): e2buflen = int(min(ioblk_size*1e6/16/ncols, nrows)) e2buflen = max(e2buflen//IOBUF_ROW_MIN, 1) * IOBUF_ROW_MIN chunks = (IOBUF_ROW_MIN, ncols) return e2buflen, chunks
def _count_naopair(mol, nao): ao_loc = mol.ao_loc_2c() nao_pair = 0 for i in range(mol.nbas): di = int(ao_loc[i+1] - ao_loc[i]) for j in range(i+1): dj = int(ao_loc[j+1] - ao_loc[j]) nao_pair += di * dj return nao_pair
del (MAX_MEMORY)
=================================================================
FILE: pyscf/ao2mo/_ao2mo.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2018 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
import ctypes import _ctypes import numpy from pyscf import lib from pyscf.gto.moleintor import make_cintopt, make_loc, ascint3 from pyscf.scf import _vhf
libao2mo = lib.load_library('libao2mo') def _fpointer(name): return ctypes.c_void_p(_ctypes.dlsym(libao2mo._handle, name))
class AO2MOpt: def init(self, mol, intor, prescreen='CVHFnoscreen', qcondname=None): intor = ascint3(intor) self._this = ctypes.POINTER(_vhf._CVHFOpt)() #print self._this.contents, expect ValueError: NULL pointer access self._intor = intor
if out is not None, transform AO to MO in-place
def nr_e1fill(intor, sh_range, atm, bas, env, aosym='s1', comp=1, ao2mopt=None, out=None): assert (aosym in ('s4', 's2ij', 's2kl', 's1')) intor = ascint3(intor) c_atm = numpy.asarray(atm, dtype=numpy.int32, order='C') c_bas = numpy.asarray(bas, dtype=numpy.int32, order='C') c_env = numpy.asarray(env, order='C') natm = ctypes.c_int(c_atm.shape[0]) nbas = ctypes.c_int(c_bas.shape[0]) ao_loc = make_loc(bas, intor) nao = int(ao_loc[-1])
def nr_e1(eri, mo_coeff, orbs_slice, aosym='s1', mosym='s1', out=None): assert (eri.flags.c_contiguous) assert (aosym in ('s4', 's2ij', 's2kl', 's1')) assert (mosym in ('s2', 's1')) mo_coeff = numpy.asfortranarray(mo_coeff) assert (mo_coeff.dtype == numpy.double) nao = mo_coeff.shape[0] i0, i1, j0, j1 = orbs_slice icount = i1 - i0 jcount = j1 - j0 ij_count = icount * jcount
if out is not None, transform AO to MO in-place
ao_loc has nbas+1 elements, last element in ao_loc == nao
def nr_e2(eri, mo_coeff, orbs_slice, aosym='s1', mosym='s1', out=None, ao_loc=None): assert (eri.flags.c_contiguous) assert (aosym in ('s4', 's2ij', 's2kl', 's2', 's1')) assert (mosym in ('s2', 's1')) mo_coeff = numpy.asfortranarray(mo_coeff) assert (mo_coeff.dtype == numpy.double) nao = mo_coeff.shape[0] k0, k1, l0, l1 = orbs_slice kc = k1 - k0 lc = l1 - l0 kl_count = kc * lc
if out is not None, transform AO to MO in-place
def r_e1(intor, mo_coeff, orbs_slice, sh_range, atm, bas, env, tao, aosym='s1', comp=1, ao2mopt=None, out=None): assert (aosym in ('s4', 's2ij', 's2kl', 's1', 'a2ij', 'a2kl', 'a4ij', 'a4kl', 'a4')) intor = ascint3(intor) mo_coeff = numpy.asarray(mo_coeff, dtype=numpy.complex128, order='F') i0, i1, j0, j1 = orbs_slice icount = i1 - i0 jcount = j1 - j0 ij_count = icount * jcount
if out is not None, transform AO to MO in-place
ao_loc has nbas+1 elements, last element in ao_loc == nao
def r_e2(eri, mo_coeff, orbs_slice, tao, ao_loc, aosym='s1', out=None): assert (eri.flags.c_contiguous) assert (aosym in ('s4', 's2ij', 's2kl', 's1', 'a2ij', 'a2kl', 'a4ij', 'a4kl', 'a4')) mo_coeff = numpy.asarray(mo_coeff, dtype=numpy.complex128, order='F') nao = mo_coeff.shape[0] k0, k1, l0, l1 = orbs_slice kc = k1 - k0 lc = l1 - l0 kl_count = kc * lc
=================================================================
FILE: pyscf/ao2mo/semi_incore.py
=================================================================
#!/usr/bin/env python
Copyright 2018-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Bryan Lau 
Qiming Sun 
""" Created on Thu May 17 11:05:22 2018
@author: Bryan Lau
A module that will do on-disk transformation of two electron integrals, and also return specific slices of (o)ccupied and (v)irtual ones needed for post HF
Comparing to the full in-memory transformation (see incore.py) which holds all intermediates in memory, this version uses less memory but performs slow due to IO overhead. """
import ctypes import numpy import h5py from pyscf import lib from pyscf.lib import logger from pyscf.ao2mo.incore import iden_coeffs, _conc_mos from pyscf.ao2mo.outcore import _load_from_h5g from pyscf.ao2mo import _ao2mo
IOBLK_SIZE = 128  # MB
def general(eri, mo_coeffs, erifile, dataname='eri_mo', ioblk_size=IOBLK_SIZE, compact=True, verbose=logger.NOTE): '''For the given four sets of orbitals, transfer arbitrary spherical AO integrals to MO integrals on disk. Args: eri : 8-fold reduced eri vector mo_coeffs : 4-item list of ndarray Four sets of orbital coefficients, corresponding to the four indices of (ij|kl) erifile : str or h5py File or h5py Group object To store the transformed integrals, in HDF5 format. Kwargs dataname : str The dataset name in the erifile (ref the hierarchy of HDF5 format http://www.hdfgroup.org/HDF5/doc1.6/UG/09_Groups.html).  By assigning different dataname, the existed integral file can be reused.  If the erifile contains the dataname, the new integrals data will overwrite the old one. ioblk_size : float or int The block size for IO, large block size may not improve performance compact : bool When compact is True, depending on the four orbital sets, the returned MO integrals has (up to 4-fold) permutation symmetry. If it's False, the function will abandon any permutation symmetry, and return the "plain" MO integrals
if name == 'main': import tempfile from pyscf import gto, scf, ao2mo # set verbose to 7 to get detailed timing info, otherwise 0 verbose = 0
=================================================================
FILE: pyscf/ao2mo/addons.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
import ctypes import numpy import h5py from pyscf import lib
libao2mo = lib.load_library('libao2mo')
class load: '''load 2e integrals from hdf5 file
def restore(symmetry, eri, norb, tao=None): r'''Convert the 2e integrals (in Chemist's notation) between different level of permutation symmetry (8-fold, 4-fold, or no symmetry)
def _convert(origsym, targetsym, eri, norb): fn = getattr(libao2mo, 'AO2MOrestore_nr%sto%s'%(origsym,targetsym)) npair = norb*(norb+1)//2 if targetsym == '1': eri1 = numpy.empty((norb,norb,norb,norb), dtype=eri.dtype) elif targetsym == '4': eri1 = numpy.empty((npair,npair), dtype=eri.dtype) elif targetsym == '8': eri1 = numpy.empty(npair*(npair+1)//2, dtype=eri.dtype)
def _stand_sym_code(sym): if isinstance(sym, int): return str(sym) elif 's' == sym[0]: return sym[1:] else: return sym
=================================================================
FILE: pyscf/ao2mo/outcore.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2021 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
import numpy import h5py from pyscf import gto from pyscf import lib from pyscf.lib import logger from pyscf.ao2mo import _ao2mo from pyscf.ao2mo import incore from pyscf import config
IOBLK_SIZE = getattr(config, 'ao2mo_outcore_ioblk_size', 256)  # 256 MB IOBUF_WORDS = getattr(config, 'ao2mo_outcore_iobuf_words', 1e8)  # 800 MB IOBUF_ROW_MIN = getattr(config, 'ao2mo_outcore_row_min', 160) MAX_MEMORY = getattr(config, 'ao2mo_outcore_max_memory', 2000)  # 2GB
def full(mol, mo_coeff, erifile, dataname='eri_mo', intor='int2e', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, compact=True): r'''Transfer arbitrary spherical AO integrals to MO integrals for given orbitals
def general(mol, mo_coeffs, erifile, dataname='eri_mo', intor='int2e', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, compact=True): r'''For the given four sets of orbitals, transfer arbitrary spherical AO integrals to MO integrals on the fly.
if nij_pair > nkl_pair:
log.warn('low efficiency for AO to MO trans!')
transform e1
swapfile will be overwritten if exists.
def half_e1(mol, mo_coeffs, swapfile, intor='int2e', aosym='s4', comp=1, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, compact=True, ao2mopt=None): r'''Half transform arbitrary spherical AO integrals to MO integrals for the given two sets of orbitals
The buffer to hold AO integrals in C code, see line (@)
def load_from_h5g(h5group, row0, row1, out=None):nkeys = len(h5group)dat = h5group['0']ncol = sum(h5group[str(key)].shape[-1] for key in range(nkeys))if dat.ndim == 2:out = numpy.ndarray((row1-row0, ncol), dat.dtype, buffer=out)col1 = 0for key in range(nkeys):col0, col1 = col1, col1 + h5group[str(key)].shape[1]if col1 > col0:h5group[str(key)].read_direct(out, dest_sel=numpy.s[:,col0:col1], source_sel=numpy.s_[row0:row1]) else:  # multiple components out = numpy.ndarray((dat.shape[0], row1-row0, ncol), dat.dtype, buffer=out) col1 = 0 for key in range(nkeys): col0, col1 = col1, col1 + h5group[str(key)].shape[2] if col1 > col0: h5group[str(key)].read_direct(out, dest_sel=numpy.s_[:,:,col0:col1], source_sel=numpy.s_[:,row0:row1]) return out
def _transpose_to_h5g(h5group, key, dat, blksize, chunks=None): nrow, ncol = dat.shape dset = h5group.create_dataset(key, (ncol,nrow), 'f8', chunks=chunks) for col0, col1 in prange(0, ncol, blksize): dset[col0:col1] = lib.transpose(dat[:,col0:col1])
def full_iofree(mol, mo_coeff, intor='int2e', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, compact=True): r'''Transfer arbitrary spherical AO integrals to MO integrals for given orbitals This function is a wrap for :func:ao2mo.outcore.general.  It's not really IO free.  The returned MO integrals are held in memory.  For backward compatibility, it is used to replace the non-existed function direct.full_iofree.
def general_iofree(mol, mo_coeffs, intor='int2e', aosym='s4', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, compact=True): r'''For the given four sets of orbitals, transfer arbitrary spherical AO integrals to MO integrals on the fly.  This function is a wrap for :func:ao2mo.outcore.general.  It's not really IO free.  The returned MO integrals are held in memory.  For backward compatibility, it is used to replace the non-existed function direct.general_iofree.
def iden_coeffs(mo1, mo2): return (id(mo1) == id(mo2)) 
or (mo1.shape==mo2.shape and numpy.allclose(mo1,mo2))
def prange(start, end, step): for i in range(start, end, step): yield i, min(i+step, end)
def guess_e1bufsize(max_memory, ioblk_size, nij_pair, nao_pair, comp): mem_words = max(1, max_memory * 1e6 / 8)
part of the max_memory is used to hold the AO integrals.  The iobuf is the
buffer to temporary hold the transformed integrals before streaming to disk.
iobuf is then divided to small blocks (ioblk_words) and streamed to disk.
def guess_e2bufsize(ioblk_size, nrows, ncols): e2buflen = int(min(ioblk_size*1e6/8/ncols, nrows)) e2buflen = max(e2buflen//IOBUF_ROW_MIN, 1) * IOBUF_ROW_MIN chunks = (IOBUF_ROW_MIN, ncols) return e2buflen, chunks
based on the size of buffer, dynamic range of AO-shells for each buffer
def guess_shell_ranges(mol, aosym, max_iobuf, max_aobuf=None, ao_loc=None, compress_diag=True): if ao_loc is None: ao_loc = mol.ao_loc_nr() max_iobuf = max(1, max_iobuf) ao_loc_long = ao_loc.astype(numpy.int64) dims = ao_loc_long[1:] - ao_loc_long[:-1] dijs = (dims.reshape(-1,1) * dims) nbas = dijs.shape[0]
def _stand_sym_code(sym): if isinstance(sym, int): return 's%d' % sym elif 's' == sym[0] or 'a' == sym[0]: return sym else: return 's' + sym
def balance_segs(segs_lst, blksize, start_id=0, stop_id=None): loc = numpy.append(0, numpy.cumsum(segs_lst)) return balance_partition(loc, blksize, start_id, stop_id) def balance_partition(ao_loc, blksize, start_id=0, stop_id=None): if stop_id is None: stop_id = len(ao_loc) - 1 else: stop_id = min(stop_id, start_id+len(ao_loc)-1) displs = lib.misc._blocksize_partition(ao_loc[start_id:stop_id+1], blksize) displs = [i+start_id for i in displs] tasks = [] for i0, i1 in zip(displs[:-1],displs[1:]): tasks.append((i0, i1, int(ao_loc[i1]-ao_loc[i0]))) return tasks
del (MAX_MEMORY)
if name == 'main': from pyscf import scf from pyscf.ao2mo import addons mol = gto.Mole() mol.verbose = 5 #mol.output = 'out_outcore' mol.atom = [ ["O" , (0. , 0.     , 0.)], [1   , (0. , -0.757 , 0.587)], [1   , (0. , 0.757  , 0.587)]]
=================================================================
FILE: pyscf/ao2mo/incore.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
import sys import numpy import ctypes from pyscf import lib from pyscf.lib import logger from pyscf.ao2mo import _ao2mo
BLOCK = 56
def full(eri_ao, mo_coeff, verbose=0, compact=True, **kwargs): r'''MO integral transformation for the given orbital.
It consumes two times of the memory needed by MO integrals
def general(eri_ao, mo_coeffs, verbose=0, compact=True, **kwargs): r'''For the given four sets of orbitals, transfer the 8-fold or 4-fold 2e AO integrals to MO integrals.
transform e1
if nij_pair > nkl_pair:
log.warn('low efficiency for AO to MO trans!')
transform e2
def half_e1(eri_ao, mo_coeffs, compact=True): r'''Given two set of orbitals, half transform the (ij| pair of 8-fold or 4-fold AO integrals (ij|kl)
def iden_coeffs(mo1, mo2): return (id(mo1) == id(mo2) or (mo1.shape==mo2.shape and abs(mo1-mo2).max() < 1e-13))
def _conc_mos(moi, moj, compact=False): if numpy.result_type(moi, moj) != numpy.double: compact = False nmoi = moi.shape[1] nmoj = moj.shape[1] if compact and iden_coeffs(moi, moj): ijmosym = 's2' nij_pair = nmoi * (nmoi+1) // 2 moij = numpy.asarray(moi, order='F') ijshape = (0, nmoi, 0, nmoi) else: ijmosym = 's1' nij_pair = nmoi * nmoj moij = numpy.asarray(numpy.hstack((moi,moj)), order='F') ijshape = (0, nmoi, nmoi, nmoi+nmoj) return ijmosym, nij_pair, moij, ijshape
if name == 'main': from pyscf import scf from pyscf import gto mol = gto.Mole() mol.verbose = 5 mol.output = 'out_h2o' mol.atom = [ ["O" , (0. , 0.     , 0.)], [1   , (0. , -0.757 , 0.587)], [1   , (0. , 0.757  , 0.587)]]
=================================================================
FILE: pyscf/ao2mo/nrr_outcore.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2018 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
''' ao2mo of scalar integrals to complex MO integrals for GHF orbitals '''
import time import tempfile import numpy import h5py import ctypes import _ctypes from pyscf import lib from pyscf import gto from pyscf.lib import logger from pyscf.ao2mo import _ao2mo from pyscf.ao2mo import outcore from pyscf import config from pyscf.gto.moleintor import make_cintopt, make_loc, ascint3
libao2mo = lib.load_library('libao2mo') def _fpointer(name): return ctypes.c_void_p(_ctypes.dlsym(libao2mo._handle, name))
IOBLK_SIZE = getattr(config, 'ao2mo_outcore_ioblk_size', 256)  # 256 MB IOBUF_WORDS = getattr(config, 'ao2mo_outcore_iobuf_words', 1e8)  # 1.6 GB IOBUF_ROW_MIN = getattr(config, 'ao2mo_outcore_row_min', 160) MAX_MEMORY = getattr(config, 'ao2mo_outcore_max_memory', 4000)  # 4GB
def full(mol, mo_coeff, erifile, dataname='eri_mo', intor='int2e_sph', motype='ghf', aosym='s1', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN): general(mol, (mo_coeff,)*4, erifile, dataname, intor, motype, aosym, comp, max_memory, ioblk_size, verbose) return erifile
def general(mol, mo_coeffs, erifile, dataname='eri_mo', intor='int2e_sph', motype='ghf', aosym='s1', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.debug): time_0pass = (logger.process_clock(), logger.perf_counter()) log = logger.new_logger(mol, verbose) intor, comp = gto.moleintor._get_intor_and_comp(mol._add_suffix(intor), comp) klsame = iden_coeffs(mo_coeffs[2], mo_coeffs[3])
transform e1
def full_iofree(mol, mo_coeff, dataname='eri_mo', intor='int2e_sph', motype='ghf', aosym='s1', comp=None, verbose=logger.debug, **kwargs): erifile = tempfile.NamedTemporaryFile(dir=lib.param.TMPDIR) general(mol, (mo_coeff,)*4, erifile.name, dataname='eri_mo', intor=intor, motype=motype, aosym=aosym, comp=comp, verbose=verbose) with h5py.File(erifile.name, 'r') as feri: return numpy.asarray(feri['eri_mo'])
def general_iofree(mol, mo_coeffs, dataname='eri_mo', intor='int2e_sph', motype='ghf', aosym='s1', comp=None, verbose=logger.debug, **kwargs): erifile = tempfile.NamedTemporaryFile(dir=lib.param.TMPDIR) general(mol, mo_coeffs, erifile.name, dataname='eri_mo', intor=intor, motype=motype, aosym=aosym, comp=comp, verbose=verbose) with h5py.File(erifile.name, 'r') as feri: return numpy.asarray(feri['eri_mo'])
swapfile will be overwritten if exists.
mo_coeffs contains two sets of mos, one is alpha back transformed, one is beta back transformed.
def half_e1(mol, mo_coeffs, swapfile, intor='int2e_sph', aosym='s1', comp=None, max_memory=MAX_MEMORY, ioblk_size=IOBLK_SIZE, verbose=logger.WARN, ao2mopt=None): time0 = (logger.process_clock(), logger.perf_counter()) log = logger.new_logger(mol, verbose)
The buffer to hold AO integrals in C code
if out is not None, transform AO to MO in-place
def r_e1(intor, mo_a, mo_b, orbs_slice, sh_range, atm, bas, env, tao, aosym='s1', comp=1, ao2mopt=None, out=None): assert(aosym in ('s4', 's2ij', 's2kl', 's1', 'a2ij', 'a2kl', 'a4ij', 'a4kl', 'a4')) intor = ascint3(intor) mo_a = numpy.asarray(mo_a, dtype=numpy.complex128, order='F') mo_b = numpy.asarray(mo_b, dtype=numpy.complex128, order='F') i0, i1, j0, j1 = orbs_slice icount = i1 - i0 jcount = j1 - j0 ij_count = icount * jcount
def iden_coeffs(mo1, mo2): return (id(mo1) == id(mo2)) 
or (mo1.shape==mo2.shape and numpy.allclose(mo1,mo2))
def prange(start, end, step): for i in range(start, end, step): yield i, min(i+step, end)
def guess_e1bufsize(max_memory, ioblk_size, nij_pair, nao_pair, comp): mem_words = max_memory * 1e6 / 16
part of the max_memory is used to hold the AO integrals.  The iobuf is the
buffer to temporary hold the transformed integrals before streaming to disk.
iobuf is then divided to small blocks (ioblk_words) and streamed to disk.
def guess_e2bufsize(ioblk_size, nrows, ncols): e2buflen = int(min(ioblk_size*1e6/16/ncols, nrows)) e2buflen = max(e2buflen//IOBUF_ROW_MIN, 1) * IOBUF_ROW_MIN chunks = (IOBUF_ROW_MIN, ncols) return e2buflen, chunks
def _count_naopair(mol, nao): ao_loc = mol.ao_loc_2c() nao_pair = 0 for i in range(mol.nbas): di = int(ao_loc[i+1] - ao_loc[i]) for j in range(i+1): dj = int(ao_loc[j+1] - ao_loc[j]) nao_pair += di * dj return nao_pair
del(MAX_MEMORY)
=================================================================
FILE: pyscf/ao2mo/init.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2018 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
'''General Integral transformation module
Simple usage::
'''
import tempfile import numpy import h5py from pyscf import gto from pyscf.ao2mo import incore from pyscf.ao2mo import outcore from pyscf.ao2mo import r_outcore from pyscf.ao2mo.addons import load, restore
def full(eri_or_mol, mo_coeff, erifile=None, dataname='eri_mo', intor='int2e', *args, **kwargs): r'''MO integral transformation. The four indices (ij|kl) are transformed with the same set of orbitals.
def general(eri_or_mol, mo_coeffs, erifile=None, dataname='eri_mo', intor='int2e', *args, **kwargs): r'''Given four sets of orbitals corresponding to the four MO indices, transfer arbitrary spherical AO integrals to MO integrals.
def kernel(eri_or_mol, mo_coeffs, erifile=None, dataname='eri_mo', intor='int2e', *args, **kwargs): r'''Transfer arbitrary spherical AO integrals to MO integrals, for given orbitals or four sets of orbitals.  See also :func:ao2mo.full and :func:ao2mo.general.
def get_ao_eri(mol): '''2-electron integrals in AO basis''' return mol.intor('int2e', aosym='s4')
get_mo_eri = kernel
=================================================================
FILE: pyscf/scf/hf.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
''' Hartree-Fock '''
import sys import tempfile
from functools import reduce import numpy import scipy.linalg import h5py from pyscf import gto from pyscf import lib from pyscf.lib import logger from pyscf.scf import diis from pyscf.scf import _vhf from pyscf.scf import chkfile from pyscf.scf import dispersion from pyscf.scf import smearing from pyscf.data import nist from pyscf import config
WITH_META_LOWDIN = getattr(config, 'scf_analyze_with_meta_lowdin', True) PRE_ORTH_METHOD = getattr(config, 'scf_analyze_pre_orth_method', 'ANO') MO_BASE = getattr(config, 'MO_BASE', 1) TIGHT_GRAD_CONV_TOL = getattr(config, 'scf_hf_kernel_tight_grad_conv_tol', True) MUTE_CHKFILE = getattr(config, 'scf_hf_SCF_mute_chkfile', False)
remove_overlap_zero_eigenvalue = getattr(config, 'scf_hf_remove_overlap_zero_eigenvalue', True) overlap_zero_eigenvalue_threshold = getattr(config, 'scf_hf_overlap_zero_eigenvalue_threshold', 1e-6)
def kernel(mf, conv_tol=1e-10, conv_tol_grad=None, dump_chk=True, dm0=None, callback=None, conv_check=True, **kwargs): '''kernel: the SCF driver.
You see this error message because of the API updates in pyscf v0.11. Keyword argument "init_dm" is replaced by "dm0"''') log = logger.new_logger(mf) cput0 = log.init_timer() if conv_tol_grad is None: conv_tol_grad = numpy.sqrt(conv_tol) log.info('Set gradient conv threshold to %g', conv_tol_grad)
def energy_elec(mf, dm=None, h1e=None, vhf=None): r'''Electronic part of Hartree-Fock energy, for given core hamiltonian and HF potential
def energy_tot(mf, dm=None, h1e=None, vhf=None): r'''Total Hartree-Fock energy, electronic part plus nuclear repulsion See :func:scf.hf.energy_elec for the electron part
def get_hcore(mol): '''Core Hamiltonian
def get_ovlp(mol): '''Overlap matrix ''' return mol.intor_symmetric('int1e_ovlp')
def init_guess_by_minao(mol): '''Generate initial guess density matrix based on ANO basis, then project the density matrix to the basis set defined by mol
coreshl defines the core shells to be removed in the initial guess
Compared to ANO valence basis, to check whether the ECP basis set has
reasonable AO-character contraction.  The ANO valence AO should have
significant overlap to ECP basis if the ECP basis has AO-character.
normalize electron number
s = mol.intor_symmetric('int1e_ovlp')
dm = mol.nelectron / (dms).sum()
def init_guess_by_1e(mol): '''Generate initial guess density matrix from core hamiltonian
def init_guess_by_atom(mol): '''Generate initial guess density matrix from superposition of atomic HF density matrix.  The atomic HF is occupancy averaged RHF
def init_guess_by_huckel(mol): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def init_guess_by_mod_huckel(mol): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def Kgwh(Ei, Ej, updated_rule=False): '''Computes the generalized Wolfsberg-Helmholtz parameter'''
def _init_guess_huckel_orbitals(mol, updated_rule = False): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def init_guess_by_chkfile(mol, chkfile_name, project=None): '''Read the HF results from checkpoint file, then project it to the basis defined by mol
def init_guess_by_sap(mol, sap_basis, **kwargs): '''Generate initial guess density matrix from a superposition of atomic potentials (SAP), doi:10.1021/acs.jctc.8b01089. This is the Gaussian fit implementation, see doi:10.1063/5.0004046.
def get_init_guess(mol, key='minao', **kwargs): '''Generate density matrix for initial guess
eigenvalue of d is 1
def level_shift(s, d, f, factor): r'''Apply level shift :math:\Delta to virtual orbitals
def damping(f, f_prev, factor): return f*(1-factor) + f_prev*factor
def make_sap(mol, sap_basis): '''Superposition of atomic potentials (SAP) potential matrix
full density matrix for RHF
def make_rdm1(mo_coeff, mo_occ, **kwargs): '''One-particle density matrix in AO representation
def make_rdm2(mo_coeff, mo_occ, **kwargs): '''Two-particle density matrix in AO representation
to make the density matrix consistent with the density matrix obtained from post-HF methods,
################################################
for general DM
hermi = 0 : arbitrary
hermi = 1 : hermitian
hermi = 2 : anti-hermitian
################################################ def dot_eri_dm(eri, dm, hermi=0, with_j=True, with_k=True): '''Compute J, K matrices in terms of the given 2-electron integrals and density matrix:
def get_jk(mol, dm, hermi=1, vhfopt=None, with_j=True, with_k=True, omega=None): '''Compute J, K matrices for all input density matrices
def get_veff(mol, dm, dm_last=None, vhf_last=None, hermi=1, vhfopt=None): '''Hartree-Fock potential matrix for the given density matrix
def get_fock(mf, h1e=None, s1e=None, vhf=None, dm=None, cycle=-1, diis=None, diis_start_cycle=None, level_shift_factor=None, damp_factor=None, fock_last=None): '''F = h^{core} + V^{HF}
def get_occ(mf, mo_energy=None, mo_coeff=None): '''Label the occupancies for each orbital
def get_grad(mo_coeff, mo_occ, fock_ao): '''RHF orbital gradients
def analyze(mf, verbose=logger.DEBUG, with_meta_lowdin=WITH_META_LOWDIN, origin=None, **kwargs): '''Analyze the given SCF object:  print orbital energies, occupancies; print orbital coefficients; Mulliken population analysis; Diople moment. ''' from pyscf.lo import orth from pyscf.tools import dump_mat mo_energy = mf.mo_energy mo_occ = mf.mo_occ mo_coeff = mf.mo_coeff log = logger.new_logger(mf, verbose)
def dump_scf_summary(mf, verbose=logger.DEBUG): if not mf.scf_summary: return
def mulliken_pop(mol, dm, s=None, verbose=logger.DEBUG): r'''Mulliken population analysis
def mulliken_meta(mol, dm, verbose=logger.DEBUG, pre_orth_method=PRE_ORTH_METHOD, s=None): '''Mulliken population analysis, based on meta-Lowdin AOs. In the meta-lowdin, the AOs are grouped in three sets: core, valence and Rydberg, the orthogonalization are carried out within each subsets.
mulliken_pop_meta_lowdin_ao = mulliken_meta
def check_linear_dependency(s, log=None): e, v = scipy.linalg.eigh(s) if log is not None: abs_e = abs(e) emax = abs_e.max() emin = abs_e.min() c = emax / emin log.debug('cond(S) = %s', c) if c > 1e10: log.warn('Singularity detected in the overlap matrix. ' 'SCF may be inaccurate and difficult to converge.') if remove_overlap_zero_eigenvalue: mask = e > overlap_zero_eigenvalue_threshold x = v[:,mask] / numpy.sqrt(e[mask]) else: x = v / numpy.sqrt(e) return x
def canonical_orthogonalization(s): return check_linear_dependency(s)
def eig(h, s, overwrite=False): '''Solver for generalized eigenvalue problem
def adjust_phase(c): '''Make the largest component of each eigenvector real and positive ''' idx = numpy.argmax(numpy.abs(c), axis=0) if c.dtype == numpy.float64: c[:,c[idx,numpy.arange(c.shape[1])]<0] *= -1 else: phase = c[idx,numpy.arange(c.shape[1])] phase /= numpy.abs(phase) c *= phase.conj() return c
def canonicalize(mf, mo_coeff, mo_occ, fock=None): '''Canonicalization diagonalizes the Fock matrix within occupied, open, virtual subspaces separatedly (without change occupancy). ''' if fock is None: dm = mf.make_rdm1(mo_coeff, mo_occ) fock = mf.get_fock(dm=dm) coreidx = mo_occ == 2 viridx = mo_occ == 0 openidx = ~(coreidx | viridx) mo = numpy.empty_like(mo_coeff) mo_e = numpy.empty(mo_occ.size) for idx in (coreidx, openidx, viridx): if numpy.count_nonzero(idx) > 0: orb = mo_coeff[:,idx] f1 = reduce(numpy.dot, (orb.conj().T, fock, orb)) e, c = scipy.linalg.eigh(f1) mo[:,idx] = numpy.dot(orb, c) mo_e[idx] = e mo = adjust_phase(mo) return mo_e, mo
def dip_moment(mol, dm, unit='Debye', origin=None, verbose=logger.NOTE, **kwargs): r''' Dipole moment calculation
def quad_moment(mol, dm, unit='DebyeAngstrom', origin=None, verbose=logger.NOTE, **kwargs): r''' Calculates traceless quadrupole moment tensor.
def uniq_var_indices(mo_occ): ''' Indices of the unique variables for the orbital-gradients (or orbital-rotation) matrix. ''' occidxa = mo_occ>0 occidxb = mo_occ==2 viridxa = ~occidxa viridxb = ~occidxb mask = (viridxa[:,None] & occidxa) | (viridxb[:,None] & occidxb) return mask
def pack_uniq_var(x, mo_occ): ''' Extract the unique variables from the full orbital-gradients (or orbital-rotation) matrix ''' idx = uniq_var_indices(mo_occ) return x[idx]
def unpack_uniq_var(dx, mo_occ): ''' Fill the full orbital-gradients (or orbital-rotation) matrix with the unique variables. ''' nmo = len(mo_occ) idx = uniq_var_indices(mo_occ)
def as_scanner(mf): '''Generating a scanner/solver for HF PES.
class SCF_Scanner(lib.SinglePointScanner): def init(self, mf_obj): self.dict.update(mf_obj.dict) self._last_mol_fp = mf_obj.mol.ao_loc
class SCF(lib.StreamObject): '''SCF base class.   non-relativistic RHF.
##################################################
don't modify the following attributes, they are not input options
employing the updated GWH rule from doi:10.1021/ja00480a005.''') mo_energy, mo_coeff = _init_guess_huckel_orbitals(mol, updated_rule=True) mo_occ = self.get_occ(mo_energy, mo_coeff) return self.make_rdm1(mo_coeff, mo_occ)
This is the Gaussian fit version as described in doi:10.1063/5.0004046.''') if isinstance(sap_basis, str): atoms = [coord[0] for coord in mol._atom] sapbas = {} for atom in set(atoms): single_element_bs = load(sap_basis, atom) if isinstance(single_element_bs, dict): sapbas[atom] = numpy.asarray(single_element_bs[atom][0][1:], dtype=float) else: sapbas[atom] = numpy.asarray(single_element_bs[0][1:], dtype=float) logger.note(self, f'Found SAP basis {sap_basis.split("/")[-1]}') elif isinstance(sap_basis, dict): sapbas = {} for key in sap_basis: sapbas[key] = numpy.asarray(sap_basis[key][0][1:], dtype=float) else: logger.error(self, 'sap_basis is of an unexpected datatype.') return init_guess_by_sap(mol, sap_basis=sapbas, **kwargs)
class KohnShamDFT: '''A mock DFT base class
class RHF(SCF): doc = SCF.doc
def _hf1e_scf(mf, args):logger.info(mf, '\n')logger.info(mf, '******* 1 electron system ********') mf.converged = True h1e = mf.get_hcore(mf.mol) s1e = mf.get_ovlp(mf.mol) mf.mo_energy, mf.mo_coeff = mf.eig(h1e, s1e) mf.mo_occ = mf.get_occ(mf.mo_energy, mf.mo_coeff) mf.e_tot = mf.mo_energy[mf.mo_occ>0][0].real + mf.mol.energy_nuc() if mf.chkfile: mf.dump_chk(mf.chkfile) mf._finalize() return mf.e_tot
del (WITH_META_LOWDIN, PRE_ORTH_METHOD)
=================================================================
FILE: pyscf/scf/diis.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2018 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
""" DIIS """
from functools import reduce import numpy import scipy.linalg import scipy.optimize from pyscf import lib from pyscf.lib import logger
DEBUG = False
J. Mol. Struct. 114, 31-34 (1984); DOI:10.1016/S0022-2860(84)87198-7
PCCP, 4, 11 (2002); DOI:10.1039/B108658H
GEDIIS, JCTC, 2, 835 (2006); DOI:10.1021/ct050275a
C2DIIS, IJQC, 45, 31 (1993); DOI:10.1002/qua.560450106
SCF-EDIIS, JCP 116, 8255 (2002); DOI:10.1063/1.1470195
error vector = SDF-FDS
error vector = F_ai ~ (S-SDS)*S^{-1}FDS = FDS - SDFDS ~ FDS-SDF in converge
class CDIIS(lib.diis.DIIS): def init(self, mf=None, filename=None, Corth=None): lib.diis.DIIS.init(self, mf, filename) self.rollback = 0 self.space = 8 self.Corth = Corth self.damp = 0
SCFDIIS = SCF_DIIS = DIIS = CDIIS
def get_err_vec_orig(s, d, f): '''error vector = SDF - FDS''' if isinstance(f, numpy.ndarray) and f.ndim == 2: sdf = reduce(lib.dot, (s,d,f)) errvec = (sdf.conj().T - sdf).ravel()
def get_err_vec_orth(s, d, f, Corth): '''error vector in orthonormal basis = C.T.conj() (SDF - FDS) C''' if isinstance(f, numpy.ndarray) and f.ndim == 2: sdf = reduce(lib.dot, (Corth.conj().T, s, d, f, Corth)) # Symmetry information to reduce numerical error in DIIS (issue #1524) if hasattr(Corth, 'orbsym'): orbsym = Corth.orbsym sdf[orbsym[:,None] != orbsym] = 0 errvec = (sdf.conj().T - sdf).ravel()
def get_err_vec(s, d, f, Corth=None): if Corth is None: return get_err_vec_orig(s, d, f) else: return get_err_vec_orth(s, d, f, Corth)
class EDIIS(lib.diis.DIIS): '''SCF-EDIIS Ref: JCP 116, 8255 (2002); DOI:10.1063/1.1470195 ''' def update(self, s, d, f, mf, h1e, vhf, *args, **kwargs): if self._head >= self.space: self._head = 0 if not self._buffer: shape = (self.space,) + f.shape self._buffer['dm'  ] = numpy.zeros(shape, dtype=f.dtype) self._buffer['fock'] = numpy.zeros(shape, dtype=f.dtype) self._buffer['etot'] = numpy.zeros(self.space) self._buffer['dm'  ][self._head] = d self._buffer['fock'][self._head] = f self._buffer['etot'][self._head] = mf.energy_elec(d, h1e, vhf)[0] self._head += 1
def ediis_minimize(es, ds, fs): nx = es.size nao = ds.shape[-1] ds = ds.reshape(nx,-1,nao,nao) fs = fs.reshape(nx,-1,nao,nao) df = numpy.einsum('inpq,jnqp->ij', ds, fs).real diag = df.diagonal() df = diag[:,None] + diag - df - df.T
class ADIIS(lib.diis.DIIS): ''' Ref: JCP 132, 054109 (2010); DOI:10.1063/1.3304922 ''' def update(self, s, d, f, mf, h1e, vhf, *args, **kwargs): if self._head >= self.space: self._head = 0 if not self._buffer: shape = (self.space,) + f.shape self._buffer['dm'  ] = numpy.zeros(shape, dtype=f.dtype) self._buffer['fock'] = numpy.zeros(shape, dtype=f.dtype) self._buffer['dm'  ][self._head] = d self._buffer['fock'][self._head] = f
def adiis_minimize(ds, fs, idnewest): nx = ds.shape[0] nao = ds.shape[-1] ds = ds.reshape(nx,-1,nao,nao) fs = fs.reshape(nx,-1,nao,nao) df = numpy.einsum('inpq,jnqp->ij', ds, fs).real d_fn = df[:,idnewest] dn_f = df[idnewest] dn_fn = df[idnewest,idnewest] dd_fn = d_fn - dn_fn df = df - d_fn[:,None] - dn_f + dn_fn
=================================================================
FILE: pyscf/gto/mole.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2021 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
''' Mole class and helper functions to handle parameters and attributes for GTO integrals. This module serves the interface to the integral library libcint. '''
import os import sys import types import re
import json import ctypes import numpy import numpy as np import h5py import scipy.special import scipy.linalg import contextlib import threading from pyscf import lib from pyscf.lib import param from pyscf.data import elements from pyscf.lib import logger from pyscf.gto import cmd_args from pyscf.gto import basis from pyscf.gto import moleintor from pyscf.gto.eval_gto import eval_gto from pyscf.gto.ecp import core_configuration from pyscf import config
from pyscf.data.elements import ELEMENTS, ELEMENTS_PROTON, 
_rm_digit, charge, _symbol, _std_symbol, _atom_symbol, is_ghost_atom, 
_std_symbol_without_ghost
from pyscf.lib.exceptions import BasisNotFoundError, PointGroupSymmetryError import warnings
for _atm, _bas, _env
CHARGE_OF  = 0 PTR_COORD  = 1 NUC_MOD_OF = 2 PTR_ZETA   = 3 PTR_FRAC_CHARGE = 4 PTR_RADIUS = 5 ATM_SLOTS  = 6 ATOM_OF    = 0 ANG_OF     = 1 NPRIM_OF   = 2 NCTR_OF    = 3 RADI_POWER = 3 # for ECP KAPPA_OF   = 4 SO_TYPE_OF = 4 # for ECP PTR_EXP    = 5 PTR_COEFF  = 6 BAS_SLOTS  = 8
pointer to env
PTR_EXPCUTOFF   = 0 PTR_COMMON_ORIG = 1 PTR_RINV_ORIG   = 4 PTR_RINV_ZETA   = 7 PTR_RANGE_OMEGA = 8 PTR_F12_ZETA    = 9 PTR_GTG_ZETA    = 10 NGRIDS          = 11 PTR_GRIDS       = 12 AS_RINV_ORIG_ATOM = 17 AS_ECPBAS_OFFSET = 18 AS_NECPBAS      = 19 PTR_ENV_START   = 20
parameters from libcint
NUC_POINT = 1 NUC_GAUSS = 2
nucleus with fractional charges. It can be used to mimic MM particles
NUC_FRAC_CHARGE = 3 NUC_ECP = 4  # atoms with pseudo potential
BASE = getattr(config, 'BASE', 0) NORMALIZE_GTO = getattr(config, 'NORMALIZE_GTO', True) DISABLE_EVAL = getattr(config, 'DISABLE_EVAL', False) ARGPARSE = getattr(config, 'ARGPARSE', False) DUMPINPUT = getattr(config, 'DUMPINPUT', True)
with open(os.path.abspath(os.path.join(file, '..', 'basis', 'bse_meta.json')), 'r') as f: BSE_META = json.load(f) del f
def M(*args, **kwargs): r'''This is a shortcut to build up Mole object.
def gaussian_int(n, alpha): r'''int_0^inf x^n exp(-alpha x^2) dx''' n1 = (n + 1) * .5 return scipy.special.gamma(n1) / (2. * alpha**n1)
def gto_norm(l, expnt): r'''Normalized factor for GTO radial part   :math:g=r^l e^{-\alpha r^2}
def cart2sph(l, c_tensor=None, normalized=None): ''' Cartesian to real spherical transformation matrix
def cart2spinor_kappa(kappa, l=None, normalized=None): '''Cartesian to spinor transformation matrix for kappa
cart2j_kappa = cart2spinor_kappa
def cart2spinor_l(l, normalized=None): '''Cartesian to spinor transformation matrix for angular moment l
cart2j_l = cart2spinor_l
def sph2spinor_kappa(kappa, l=None): '''Real spherical to spinor transformation matrix for kappa''' from pyscf.symm.sph import sph2spinor ua, ub = sph2spinor(l) if kappa < 0: l = -kappa - 1 ua = ua[:,l2:]ub = ub[:,l2:] elif kappa > 0: l = kappa ua = ua[:,:l2]ub = ub[:,:l2] else: assert (l is not None) assert (l <= 12) return ua, ub
def sph2spinor_l(l): '''Real spherical to spinor transformation matrix for angular moment l''' return sph2spinor_kappa(0, l)
def ao_rotation_matrix(mol, orientation): '''Matrix u to rotate AO basis to a new orientation.
def atom_types(atoms, basis=None, magmom=None): '''symmetry inequivalent atoms''' atmgroup = {} for ia, a in enumerate(atoms): if 'GHOST' in a[0].upper(): a = ['X'+a[0][5:]] + list(a[1:]) if a[0] in atmgroup: atmgroup[a[0]].append(ia) elif basis is None: atmgroup[a[0]] = [ia] else: stdsymb = _std_symbol(a[0]) if a[0] in basis: if stdsymb in basis and basis[a[0]] == basis[stdsymb]: if stdsymb in atmgroup: atmgroup[stdsymb].append(ia) else: atmgroup[stdsymb] = [ia] else: atmgroup[a[0]] = [ia] elif stdsymb in atmgroup: atmgroup[stdsymb].append(ia) else: atmgroup[stdsymb] = [ia]
def format_atom(atoms, origin=0, axes=None, unit=getattr(config, 'UNIT', 'Ang')): '''Convert the input :attr:Mole.atom to the internal data format. Including, changing the nuclear charge to atom symbol, converting the coordinates to AU, rotate and shift the molecule. If the :attr:~Mole.atom is a string, it takes ";" and "\n" for the mark to separate atoms;  "," and arbitrary length of blank space to separate the individual terms for an atom.  Blank line will be ignored.
#TODO: sort exponents def format_basis(basis_tab, sort_basis=True): '''Convert the input :attr:Mole.basis to the internal data format.
def _generate_basis_converter(): def nparray_to_list(item): val = [] for x in item: if isinstance(x, (tuple, list)): val.append(nparray_to_list(x)) elif isinstance(x, numpy.ndarray): val.append(x.tolist()) else: val.append(x) return val
def uncontracted_basis(_basis): '''Uncontract internal format _basis
uncontract = uncontracted_basis contract = contracted_basis = basis.to_general_contraction
def to_uncontracted_cartesian_basis(mol): '''Decontract the basis of a Mole or a Cell.  Returns a Mole (Cell) object with uncontracted Cartesian basis and a list of coefficients that transform the uncontracted basis to the original basis. Each element in the coefficients list corresponds to one shell of the original Mole (Cell).
def decontract_basis(mol, atoms=None, to_cart=False, aggregate=False): '''Decontract the basis of a Mole or a Cell.  Returns a Mole (Cell) object with the uncontracted basis environment and a list of coefficients that transform the uncontracted basis to the original basis. Each element in the coefficients list corresponds to one shell of the original Mole (Cell).
def format_ecp(ecp_tab): r'''Convert the input :attr:ecp (dict) to the internal data format::
def format_pseudo(pseudo_tab): r'''Convert the input :attr:pseudo (dict) to the internal data format::
transform etb to basis format
def expand_etb(l, n, alpha, beta): r'''Generate the exponents of even tempered basis for :attr:Mole.basis. .. math::
def expand_etbs(etbs): r'''Generate even tempered basis.  See also :func:expand_etb
etbs = expand_etbs
concatenate two mol
def conc_env(atm1, bas1, env1, atm2, bas2, env2): r'''Concatenate two Mole's integral parameters.  This function can be used to construct the environment for cross integrals like
def conc_mol(mol1, mol2): '''Concatenate two Mole objects. ''' if not mol1._built: logger.warn(mol1, 'Warning: object %s not initialized. Initializing %s', mol1, mol1) mol1.build() if not mol2._built: logger.warn(mol2, 'Warning: object %s not initialized. Initializing %s', mol2, mol2) mol2.build()
<bas-of-mol1|intor|bas-of-mol2>
def intor_cross(intor, mol1, mol2, comp=None, grids=None): r'''1-electron integrals from two molecules like
append (charge, pointer to coordinates, nuc_mod) to _atm
def make_atm_env(atom, ptr=0, nuclear_model=NUC_POINT, nucprop={}): '''Convert the internal format :attr:Mole._atom to the format required by libcint integrals ''' nuc_charge = charge(atom[0]) if nuclear_model == NUC_POINT: zeta = 0 elif nuclear_model == NUC_GAUSS: zeta = dyall_nuc_mod(nuc_charge, nucprop) else:  # callable(nuclear_model) zeta = nuclear_model(nuc_charge, nucprop) nuclear_model = NUC_GAUSS
append (atom, l, nprim, nctr, kappa, ptr_exp, ptr_coeff, 0) to bas
absorb normalization into GTO contraction coefficients
def make_bas_env(basis_add, atom_id=0, ptr=0): '''Convert :attr:Mole.basis to the argument bas for libcint integrals ''' _bas = [] _env = [] for b in basis_add: angl = b[0] if angl > 14: sys.stderr.write('Warning: integral library does not support basis ' 'with angular momentum > 14\n')
def _nomalize_contracted_ao(l, es, cs): #ee = numpy.empty((nprim,nprim)) #for i in range(nprim): #    for j in range(i+1): #        ee[i,j] = ee[j,i] = gaussian_int(angl2+2, es[i]+es[j])#s1 = 1/numpy.sqrt(numpy.einsum('pi,pq,qi->i', cs, ee, cs))ee = es.reshape(-1,1) + es.reshape(1,-1)ee = gaussian_int(l2+2, ee) s1 = 1. / numpy.sqrt(numpy.einsum('pi,pq,qi->i', cs, ee, cs)) return numpy.einsum('pi,i->pi', cs, s1)
def make_env(atoms, basis, pre_env=[], nucmod={}, nucprop={}): '''Generate the input arguments for libcint library based on internal format :attr:Mole._atom and :attr:Mole._basis ''' _atm = [] _bas = [] _env = [pre_env] ptr_env = len(pre_env)
def make_ecp_env(mol, _atm, ecp, pre_env=[]): '''Generate the input arguments _ecpbas for ECP integrals ''' _env = [] ptr_env = len(pre_env)
def tot_electrons(mol): '''Total number of electrons for the given molecule
def copy(mol, deep=True): '''Deepcopy of the given :class:Mole object
def pack(mol): '''Pack the input args of :class:Mole to a dict.
def unpack(moldic): '''Unpack a dict which is packed by :func:pack, to generate the input arguments for :class:Mole object. ''' mol = Mole() mol.dict.update(moldic) return mol
def dumps(mol): '''Serialize Mole object to a JSON formatted str. ''' exclude_keys = {'output', 'stdout', '_keys', '_ctx_lock', # Constructing in function loads 'symm_orb', 'irrep_id', 'irrep_name'} moldic = dict(mol.dict) for k in exclude_keys: if k in moldic: del (moldic[k]) for k in moldic: if isinstance(moldic[k], (numpy.ndarray, numpy.generic)): moldic[k] = moldic[k].tolist() moldic['atom'] = repr(mol.atom) moldic['basis']= repr(mol.basis) moldic['ecp' ] = repr(mol.ecp) moldic['pseudo'] = repr(mol.pseudo)
def loads(molstr): '''Deserialize a str containing a JSON document to a Mole object. ''' # the numpy function array is used by eval function from numpy import array  # noqa moldic = json.loads(molstr) mol = Mole() mol.dict.update(moldic) mol.atom = eval(mol.atom) mol.basis= eval(mol.basis) mol.ecp  = eval(mol.ecp) if 'pseudo' in moldic: # backward compatibility with old dumps function, which does not have # the pseudo attribute mol.pseudo  = eval(mol.pseudo) mol._atm = numpy.array(mol._atm, dtype=numpy.int32) mol._bas = numpy.array(mol._bas, dtype=numpy.int32) mol._env = numpy.array(mol._env, dtype=numpy.double) mol._ecpbas = numpy.array(mol._ecpbas, dtype=numpy.int32)
def len_spinor(l, kappa): '''The number of spinor associated with given angular momentum and kappa.  If kappa is 0, return 4l+2 ''' if kappa == 0: n = (l * 4 + 2) elif kappa < 0: n = (l * 2 + 2) else: n = (l * 2) return n
def len_cart(l): '''The number of Cartesian function associated with given angular momentum. ''' return (l + 1) * (l + 2) // 2
def npgto_nr(mol, cart=None): '''Total number of primitive spherical GTOs for the given :class:Mole object''' if cart is None: cart = mol.cart l = mol._bas[:,ANG_OF] if cart: return int(((l+1)(l+2)//2 * mol._bas[:,NPRIM_OF]).sum())else:return int(((l2+1) * mol._bas[:,NPRIM_OF]).sum()) def nao_nr(mol, cart=None): '''Total number of contracted GTOs for the given :class:Mole object''' if cart is None: cart = mol.cart if cart: return nao_cart(mol) else: return int(((mol._bas[:,ANG_OF]2+1) * mol._bas[:,NCTR_OF]).sum())def nao_cart(mol):'''Total number of contracted cartesian GTOs for the given :class:Mole object'''l = mol._bas[:,ANG_OF]return int(((l+1)(l+2)//2 * mol._bas[:,NCTR_OF]).sum())
nao_id0:nao_id1 corresponding to bas_id0:bas_id1
def nao_nr_range(mol, bas_id0, bas_id1): '''Lower and upper boundary of contracted spherical basis functions associated with the given shell range
def nao_2c(mol): '''Total number of contracted spinor GTOs for the given :class:Mole object''' l = mol._bas[:,ANG_OF] kappa = mol._bas[:,KAPPA_OF] dims = (l*4+2) * mol._bas[:,NCTR_OF] dims[kappa<0] = (l[kappa<0] * 2 + 2) * mol._bas[kappa<0,NCTR_OF] dims[kappa>0] = (l[kappa>0] * 2) * mol._bas[kappa>0,NCTR_OF] return int(dims.sum())
nao_id0:nao_id1 corresponding to bas_id0:bas_id1
def nao_2c_range(mol, bas_id0, bas_id1): '''Lower and upper boundary of contracted spinor basis functions associated with the given shell range
def ao_loc_nr(mol, cart=None): '''Offset of every shell in the spherical basis function spectrum
def ao_loc_2c(mol): '''Offset of every shell in the spinor basis function spectrum
def time_reversal_map(mol): r'''The index to map the spinor functions and its time reversal counterpart. The returned indices have positive or negative values.  For the i-th basis function, if the returned j = idx[i] < 0, it means :math:T|i\rangle = -|j\rangle, otherwise :math:T|i\rangle = |j\rangle ''' tao = [] i = 0 for b in mol._bas: l = b[ANG_OF] if b[KAPPA_OF] == 0: djs = (l * 2, l * 2 + 2) elif b[KAPPA_OF] > 0: djs = (l * 2,) else: djs = (l * 2 + 2,) if l % 2 == 0: for n in range(b[NCTR_OF]): for dj in djs: for m in range(0, dj, 2): tao.append(-(i + dj - m)) tao.append(  i + dj - m - 1) i += dj else: for n in range(b[NCTR_OF]): for dj in djs: for m in range(0, dj, 2): tao.append(  i + dj - m) tao.append(-(i + dj - m - 1)) i += dj return numpy.asarray(tao, dtype=numpy.int32)
CHECK_GEOM = getattr(config, 'gto_mole_check_geom', True)
def classical_coulomb_energy(mol, charges=None, coords=None): '''Compute nuclear repulsion energy (AU) or static Coulomb energy
energy_nuc = classical_coulomb_energy
def inter_distance(mol, coords=None): ''' Inter-particle distance array ''' if coords is None: coords = mol.atom_coords() rr = numpy.linalg.norm(coords.reshape(-1,1,3) - coords, axis=2) rr[numpy.diag_indices_from(rr)] = 0 return rr
def sph_labels(mol, fmt=True, base=BASE): '''Labels for spherical GTO functions
spheric_labels = spherical_labels = sph_labels
def cart_labels(mol, fmt=True, base=BASE): '''Labels of Cartesian GTO functions
def ao_labels(mol, fmt=True, base=BASE): '''Labels of AO basis functions
def spinor_labels(mol, fmt=True, base=BASE): ''' Labels of spinor GTO functions ''' count = numpy.zeros((mol.natm, 9), dtype=int) label = [] for ib in range(mol.nbas): ia = mol.bas_atom(ib) l = mol.bas_angular(ib) kappa = mol.bas_kappa(ib) strl = param.ANGULAR[l] nc = mol.bas_nctr(ib) symb = mol.atom_symbol(ia) nelec_ecp = mol.atom_nelec_core(ia) if nelec_ecp == 0 or l > 3: shl_start = count[ia,l]+l+1 else: coreshl = core_configuration(nelec_ecp, atom_symbol=_std_symbol(symb)) shl_start = coreshl[l]+count[ia,l]+l+1 count[ia,l] += nc for n in range(shl_start, shl_start+nc): if kappa >= 0: for m in range(-l2+1, l2, 2): label.append((ia+base, symb, '%d%s%d/2' % (n, strl, l2-1),'%d/2'%m))if kappa <= 0:for m in range(-l2-1, l2+2, 2):label.append((ia+base, symb, '%d%s%d/2' % (n, strl, l2+1), '%d/2'%m))
def search_ao_label(mol, label): '''Find the index of the AO basis function based on the given ao_label
def _aolabels2baslst(mol, aolabels_or_baslst, base=BASE): if callable(aolabels_or_baslst): baslst = [i for i,x in enumerate(mol.ao_labels(base=base)) if aolabels_or_baslst(x)] elif isinstance(aolabels_or_baslst, str): aolabels = re.sub(' +', ' ', aolabels_or_baslst.strip(), count=1) aolabels = re.compile(aolabels) baslst = [i for i,s in enumerate(mol.ao_labels(base=base)) if re.search(aolabels, s)] elif len(aolabels_or_baslst) > 0 and isinstance(aolabels_or_baslst[0], str): aolabels = [re.compile(re.sub(' +', ' ', x.strip(), count=1)) for x in aolabels_or_baslst] baslst = [i for i,t in enumerate(mol.ao_labels(base=base)) if any(re.search(x, t) for x in aolabels)] else: baslst = [i-base for i in aolabels_or_baslst] return numpy.asarray(baslst, dtype=int)
def search_shell_id(mol, atm_id, l): '''Search the first basis/shell id (not the basis function id) which matches the given atom-id and angular momentum
def search_ao_nr(mol, atm_id, l, m, atmshell): '''Search the first basis function id (not the shell id) which matches the given atom-id, angular momentum magnetic angular momentum, principal shell.
def search_ao_r(mol, atm_id, l, j, m, atmshell): raise RuntimeError('TODO') #TODO:    ibf = 0 #TODO:    for ib in range(len(mol._bas)): #TODO:        ia = mol.bas_atom(ib) #TODO:        l1 = mol.bas_angular(ib) #TODO:        nc = mol.bas_nctr(ib) #TODO:        k = mol.bas_kappa(bas_id) #TODO:        degen = len_spinor(l1, k) #TODO:        if ia == atm_id and l1 == l and k == kappa: #TODO:            if atmshell > nc+l1: #TODO:                atmshell = atmshell - nc #TODO:            else: #TODO:                return ibf + (atmshell-l1-1)*degen + (degen+m) #TODO:        ibf += degen
def offset_2c_by_atom(mol): '''2-component AO offset for each atom.  Return a list, each item of the list gives (start-shell-id, stop-shell-id, start-AO-id, stop-AO-id) ''' return aoslice_by_atom(mol, mol.ao_loc_2c())
def aoslice_by_atom(mol, ao_loc=None): '''AO offsets for each atom.  Return a list, each item of the list gives (start-shell-id, stop-shell-id, start-AO-id, stop-AO-id) ''' if ao_loc is None: ao_loc = mol.ao_loc_nr()
offset_nr_by_atom = aoslice_by_atom
def same_basis_set(mol1, mol2): '''Check whether two molecules use the same basis sets. The two molecules can have different geometry. ''' atomtypes1 = atom_types(mol1._atom, mol1._basis) atomtypes2 = atom_types(mol2._atom, mol2._basis) if set(atomtypes1.keys()) != set(atomtypes2.keys()): return False for k in atomtypes1: if len(atomtypes1[k]) != len(atomtypes2[k]): return False elif mol1._basis.get(k, None) != mol2._basis.get(k, None): return False return True
def same_mol(mol1, mol2, tol=1e-5, cmp_basis=True, ignore_chiral=False): '''Compare the two molecules whether they have the same structure.
is_same_mol = same_mol
def chiral_mol(mol1, mol2=None): '''Detect whether the given molecule is chiral molecule or two molecules are chiral isomers. ''' if mol2 is None: mol2 = mol1.copy() ptr_coord = mol2._atm[:,PTR_COORD] mol2._env[ptr_coord  ] *= -1 mol2._env[ptr_coord+1] *= -1 mol2._env[ptr_coord+2] *= -1 return (not same_mol(mol1, mol2, ignore_chiral=False) and same_mol(mol1, mol2, ignore_chiral=True))
def inertia_moment(mol, mass=None, coords=None): if mass is None: mass = mol.atom_mass_list() if coords is None: coords = mol.atom_coords() mass_center = numpy.einsum('i,ij->j', mass, coords)/mass.sum() coords = coords - mass_center im = numpy.einsum('i,ij,ik->jk', mass, coords, coords) im = numpy.eye(3) * im.trace() - im return im
def atom_mass_list(mol, isotope_avg=False, mass_table=None): '''A list of mass for all atoms in the molecule
def condense_to_shell(mol, mat, compressor='max'): '''The given matrix is first partitioned to blocks, based on AO shell as delimiter. Then call compressor function to abstract each block.
def get_overlap_cond(mol, shls_slice=None): '''Overlap magnitudes measured by -log(overlap) between two shells
def tostring(mol, format='raw'): '''Convert molecular geometry to a string of the required format.
def tofile(mol, filename, format=None): '''Write molecular geometry to a file of the required format.
def fromfile(filename, format=None): '''Read molecular geometry from a file (in testing)
def fromstring(string, format='xyz'): '''Convert the string of the specified format to internal format (in testing)
def is_au(unit): '''Return whether the unit is recognized as A.U. or not ''' return isinstance(unit, str) and unit.upper().startswith(('B', 'AU'))
def _length_in_au(unit): '''Converts the input unit string into its length in A.U.''' if isinstance(unit, str): if is_au(unit): unit = 1. else: unit = 1/param.BOHR else: unit = 1./unit return unit
MoleBase handles three layers of basis data: input, internal format, libcint arguments.
The relationship of the three layers are
.atom (input) <=>  ._atom (for python) <=> ._atm (for libcint)
.basis (input) <=> ._basis (for python) <=> ._bas (for libcint)
input layer does not talk to libcint directly.  Data are held in python
internal format layer.  Most of methods defined in this class only operates
on the internal format.  Exceptions are make_env, make_atm_env, make_bas_env,
set_common_orig_, set_rinv_orig_ which are used to manipulate the libcint arguments.
class MoleBase(lib.StreamObject): '''Basic class to hold molecular structure, integrals and global options
##################################################
don't modify the following private variables, they are not input options
class Mole(MoleBase): '''A Mole object to hold the basic information of a molecule. '''
def _parse_default_basis(basis, uniq_atoms): if isinstance(basis, (str, tuple, list)): # default basis for all atoms _basis = {a: basis for a in uniq_atoms} elif 'default' in basis: default_basis = basis['default'] _basis = {a: default_basis for a in uniq_atoms} _basis.update(basis) del _basis['default'] else: _basis = basis return _basis
def _parse_nuc_mod(str_or_int_or_fn): nucmod = NUC_POINT if callable(str_or_int_or_fn): nucmod = str_or_int_or_fn elif (isinstance(str_or_int_or_fn, str) and str_or_int_or_fn[0].upper() == 'G'): # 'gauss_nuc' nucmod = NUC_GAUSS elif str_or_int_or_fn != 0: nucmod = NUC_GAUSS return nucmod
def update_from_cmdargs(mol): try: # Detect whether in Ipython shell IPYTHON  # noqa: F821 return except Exception: pass
def from_zmatrix(atomstr): '''>>> a = """H H 1 2.67247631453057 H 1 4.22555607338457 2 50.7684795164077 H 1 2.90305235726773 2 79.3904651036893 3 6.20854462618583""" >>> for x in zmat2cart(a): print(x) ['H', array([ 0.,  0.,  0.])] ['H', array([ 2.67247631,  0.        ,  0.        ])] ['H', array([ 2.67247631,  0.        ,  3.27310166])] ['H', array([ 0.53449526,  0.30859098,  2.83668811])] ''' from pyscf.symm import rotation_mat atomstr = atomstr.replace(';','\n').replace(',',' ') symbols = [] coord = [] min_items_per_line = 1 for line_id, line in enumerate(atomstr.splitlines()): line = line.strip() if line and line[0] != '#': rawd = line.split() if len(rawd) < min_items_per_line: raise ValueError('Zmatrix format error at L%d %s' % (line_id, line))
zmat2cart = zmat = from_zmatrix
def cart2zmat(coord): '''>>> c = numpy.array(( (0.000000000000,  1.889726124565,  0.000000000000), (0.000000000000,  0.000000000000, -1.889726124565), (1.889726124565, -1.889726124565,  0.000000000000), (1.889726124565,  0.000000000000,  1.133835674739))) >>> print(cart2zmat(c)) 1 1 2.67247631453057 1 4.22555607338457 2 50.7684795164077 1 2.90305235726773 2 79.3904651036893 3 6.20854462618583 ''' zstr = [] zstr.append('1') if len(coord) > 1: r1 = coord[1] - coord[0] nr1 = numpy.linalg.norm(r1) zstr.append('1 %.15g' % nr1) if len(coord) > 2: r2 = coord[2] - coord[0] nr2 = numpy.linalg.norm(r2) a = numpy.arccos(numpy.dot(r1,r2)/(nr1nr2))zstr.append('1 %.15g 2 %.15g' % (nr2, a180/numpy.pi)) if len(coord) > 3: o0, o1, o2 = coord[:3] p0, p1, p2 = 1, 2, 3 for k, c in enumerate(coord[3:]): r0 = c - o0 nr0 = numpy.linalg.norm(r0) r1 = o1 - o0 nr1 = numpy.linalg.norm(r1) a1 = numpy.arccos(numpy.dot(r0,r1)/(nr0*nr1)) b0 = numpy.cross(r0, r1) nb0 = numpy.linalg.norm(b0)
def dyall_nuc_mod(nuc_charge, nucprop={}): ''' Generate the nuclear charge distribution parameter zeta rho(r) = nuc_charge * Norm * exp(-zeta * r^2)
def filatov_nuc_mod(nuc_charge, nucprop={}): ''' Generate the nuclear charge distribution parameter zeta rho(r) = nuc_charge * Norm * exp(-zeta * r^2)
def fakemol_for_charges(coords, expnt=1e16): r''' Construct a fake Mole object representing charges located at the given coordinates.
def fakemol_for_cgtf_charge(coord, expnt=1e16, contr_coeff=1): r''' Constructs a "fake" Mole object that has a Gaussian charge distribution at the specified coordinate (coord). The charge can be given as a linear combination of Gaussians with exponents (expnt) and contraction coefficients (contr_coeff). Note, every Gaussian within the cgtf is normalized to 1: \int N \exp(-\mathrm{expnt}, r^2), d^3r = 1
def classify_ecp_pseudo(mol, ecp, pp): ''' Check whether ecp keywords are presented in pp and whether pp keywords are presented in ecp.  The return (ecp, pp) should have only the ecp keywords and pp keywords in each dict. The "misplaced" ecp/pp keywords have the lowest priority. E.g., if an atom is defined in ecp, the same ecp atom found in pp does NOT replace the definition in ecp, and vise versa. ''' def classify(ecp, pp_alias): if isinstance(ecp, str): if basis._format_pseudo_name(ecp)[0] in pp_alias: return {}, {'default': str(ecp)} elif isinstance(ecp, dict): ecp_as_pp = {} for atom in ecp: key = ecp[atom] if (isinstance(key, str) and basis._format_pseudo_name(key)[0] in pp_alias): ecp_as_pp[atom] = str(key) if ecp_as_pp: ecp_left = dict(ecp) for atom in ecp_as_pp: ecp_left.pop(atom) return ecp_left, ecp_as_pp return ecp, {} ecp_left, ecp_as_pp = classify(ecp, basis.PP_ALIAS) pp_left , pp_as_ecp = classify(pp, basis.ALIAS)
def bse_predefined_ecp(basis_name, elements): '''Find ECP names for a given list of atoms from BSE database ''' ecp = ecp_atoms = None if not isinstance(basis_name, str): return ecp, ecp_atoms pyscf_basis_alias = basis._format_basis_name(basis_name).lower() basis_meta = BSE_META.get(pyscf_basis_alias) if basis_meta: if isinstance(elements, (str, int)): elements = [elements] ecp_elements = basis_meta[1] if ecp_elements: unique_atoms = {charge(a) for a in set(elements)} ecp_atoms = unique_atoms.intersection(ecp_elements) if ecp_atoms: ecp = basis_meta[0] # standard format basis set name return ecp, ecp_atoms
def extract_pgto_params(mol, op='diffuse'): '''A helper function to extract exponents and contraction coefficients of the most diffuse or compact primitive GTOs for each shell. These exponents and coefficients are typically used in estimating rcut and Ecut for PBC methods. ''' op = op[:7] # in previous versions, op was spelled as diffused if op != 'diffuse' and op != 'compact': raise RuntimeError(f'Unsupported operation {op}')
def most_diffuse_pgto(mol): ''' Returns the exponent, normalization factor and angular momentum of the most diffuse primitive GTO ''' exps, cs = extract_pgto_params(mol, 'diffuse') ls = mol._bas[:,ANG_OF] r2 = np.log(cs2 / mol.precision * 10ls + 1e-200) / exps idx = r2.argmax() return exps[idx], cs[idx], ls[idx]
class _MoleLazyCallAdapter: '''Adapter for API updates. Should be removed in future''' def init(self, fn, name): self.fn = fn self.name = name
=================================================================
FILE: pyscf/gto/moleintor.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2018,2021 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
''' A low level interface to libcint library. It's recommended to use the Mole.intor method to drive the integral evaluation functions. '''
import warnings import ctypes import numpy from pyscf import lib
libcgto = lib.load_library('libcgto')
ANG_OF     = 1 NPRIM_OF   = 2 NCTR_OF    = 3 KAPPA_OF   = 4 PTR_EXP    = 5 PTR_COEFF  = 6 BAS_SLOTS  = 8 NGRIDS     = 11 PTR_GRIDS  = 12
def getints(intor_name, atm, bas, env, shls_slice=None, comp=None, hermi=0, aosym='s1', ao_loc=None, cintopt=None, out=None): r'''1e and 2e integral generator.
def _get_intor_and_comp(intor_name, comp=None): intor_name = ascint3(intor_name) if comp is None: try: if '_spinor' in intor_name: fname = intor_name.replace('_spinor', '') comp = _INTOR_FUNCTIONS[fname][1] else: fname = intor_name.replace('_sph', '').replace('_cart', '') comp = _INTOR_FUNCTIONS[fname][0] except KeyError: warnings.warn('Function %s not found.  Set its comp to 1' % intor_name) comp = 1 return intor_name, comp
_INTOR_FUNCTIONS = { # Functiona name            : (comp-for-scalar, comp-for-spinor) 'int1e_ovlp'                : (1, 1), 'int1e_nuc'                 : (1, 1), 'int1e_kin'                 : (1, 1), 'int1e_ia01p'               : (3, 3), 'int1e_giao_irjxp'          : (3, 3), 'int1e_cg_irxp'             : (3, 3), 'int1e_giao_a11part'        : (9, 9), 'int1e_cg_a11part'          : (9, 9), 'int1e_a01gp'               : (9, 9), 'int1e_igkin'               : (3, 3), 'int1e_igovlp'              : (3, 3), 'int1e_ignuc'               : (3, 3), 'int1e_pnucp'               : (1, 1), 'int1e_z'                   : (1, 1), 'int1e_zz'                  : (1, 1), 'int1e_r'                   : (3, 3), 'int1e_r2'                  : (1, 1), 'int1e_r4'                  : (1, 1), 'int1e_rr'                  : (9, 9), 'int1e_rrr'                 : (27, 27), 'int1e_rrrr'                : (81, 81), 'int1e_z_origj'             : (1, 1), 'int1e_zz_origj'            : (1, 1), 'int1e_r_origj'             : (3, 3), 'int1e_rr_origj'            : (9, 9), 'int1e_r2_origj'            : (1, 1), 'int1e_r4_origj'            : (1, 1), 'int1e_p4'                  : (1, 1), 'int1e_prinvp'              : (1, 1), 'int1e_prinvxp'             : (3, 3), 'int1e_pnucxp'              : (3, 3), 'int1e_irp'                 : (9, 9), 'int1e_irrp'                : (27, 27), 'int1e_irpr'                : (27, 27), 'int1e_ggovlp'              : (9, 9), 'int1e_ggkin'               : (9, 9), 'int1e_ggnuc'               : (9, 9), 'int1e_grjxp'               : (9, 9), 'int2e'                     : (1, 1), 'int2e_ig1'                 : (3, 3), 'int2e_gg1'                 : (9, 9), 'int2e_g1g2'                : (9, 9), 'int2e_ip1v_rc1'            : (9, 9), 'int2e_ip1v_r1'             : (9, 9), 'int2e_ipvg1_xp1'           : (9, 9), 'int2e_ipvg2_xp1'           : (9, 9), 'int2e_p1vxp1'              : (3, 3), 'int1e_inuc_rcxp'           : (3, 3), 'int1e_inuc_rxp'            : (3, 3), 'int1e_sigma'               : (12,3), 'int1e_spsigmasp'           : (12,3), 'int1e_srsr'                : (4, 1), 'int1e_sr'                  : (4, 1), 'int1e_srsp'                : (4, 1), 'int1e_spsp'                : (4, 1), 'int1e_sp'                  : (4, 1), 'int1e_spnucsp'             : (4, 1), 'int1e_sprinvsp'            : (4, 1), 'int1e_srnucsr'             : (4, 1), 'int1e_sprsp'               : (12,3), 'int1e_govlp'               : (3, 3), 'int1e_gnuc'                : (3, 3), 'int1e_cg_sa10sa01'         : (36,9), 'int1e_cg_sa10sp'           : (12,3), 'int1e_cg_sa10nucsp'        : (12,3), 'int1e_giao_sa10sa01'       : (36,9), 'int1e_giao_sa10sp'         : (12,3), 'int1e_giao_sa10nucsp'      : (12,3), 'int1e_sa01sp'              : (12,3), 'int1e_spgsp'               : (12,3), 'int1e_spgnucsp'            : (12,3), 'int1e_spgsa01'             : (36,9), 'int2e_spsp1'               : (4, 1), 'int2e_spsp1spsp2'          : (16,1), 'int2e_srsr1'               : (4, 1), 'int2e_srsr1srsr2'          : (16,1), 'int2e_cg_sa10sp1'          : (12,3), 'int2e_cg_sa10sp1spsp2'     : (48,3), 'int2e_giao_sa10sp1'        : (12,3), 'int2e_giao_sa10sp1spsp2'   : (48,3), 'int2e_g1'                  : (12,3), 'int2e_spgsp1'              : (12,3), 'int2e_g1spsp2'             : (12,3), 'int2e_spgsp1spsp2'         : (48,3), 'int2e_pp1'                 : (1, 1), 'int2e_pp2'                 : (1, 1), 'int2e_pp1pp2'              : (1, 1), 'int1e_spspsp'              : (4, 1), 'int1e_spnuc'               : (4, 1), 'int2e_spv1'                : (4, 1), 'int2e_vsp1'                : (4, 1), 'int2e_spsp2'               : (4, 1), 'int2e_spv1spv2'            : (16,1), 'int2e_vsp1spv2'            : (16,1), 'int2e_spv1vsp2'            : (16,1), 'int2e_vsp1vsp2'            : (16,1), 'int2e_spv1spsp2'           : (16,1), 'int2e_vsp1spsp2'           : (16,1), 'int1e_ipovlp'              : (3, 3), 'int1e_ipkin'               : (3, 3), 'int1e_ipnuc'               : (3, 3), 'int1e_iprinv'              : (3, 3), 'int1e_rinv'                : (1, 1), 'int1e_ipspnucsp'           : (12,3), 'int1e_ipsprinvsp'          : (12,3), 'int1e_ippnucp'             : (3, 3), 'int1e_ipprinvp'            : (3, 3), 'int2e_ip1'                 : (3, 3), 'int2e_ip2'                 : (3, 3), 'int2e_ipspsp1'             : (12,3), 'int2e_ip1spsp2'            : (12,3), 'int2e_ipspsp1spsp2'        : (48,3), 'int2e_ipsrsr1'             : (12,3), 'int2e_ip1srsr2'            : (12,3), 'int2e_ipsrsr1srsr2'        : (48,3), 'int2e_ssp1ssp2'            : (16,1), 'int2e_ssp1sps2'            : (16,1), 'int2e_sps1ssp2'            : (16,1), 'int2e_sps1sps2'            : (16,1), 'int2e_cg_ssa10ssp2'        : (48,3), 'int2e_giao_ssa10ssp2'      : (18,3), 'int2e_gssp1ssp2'           : (18,3), 'int2e_gauge_r1_ssp1ssp2'   : (None, 1), 'int2e_gauge_r1_ssp1sps2'   : (None, 1), 'int2e_gauge_r1_sps1ssp2'   : (None, 1), 'int2e_gauge_r1_sps1sps2'   : (None, 1), 'int2e_gauge_r2_ssp1ssp2'   : (None, 1), 'int2e_gauge_r2_ssp1sps2'   : (None, 1), 'int2e_gauge_r2_sps1ssp2'   : (None, 1), 'int2e_gauge_r2_sps1sps2'   : (None, 1), 'int1e_ipipovlp'            : (9, 9), 'int1e_ipovlpip'            : (9, 9), 'int1e_ipipkin'             : (9, 9), 'int1e_ipkinip'             : (9, 9), 'int1e_ipipnuc'             : (9, 9), 'int1e_ipnucip'             : (9, 9), 'int1e_ipiprinv'            : (9, 9), 'int1e_iprinvip'            : (9, 9), 'int2e_ipip1'               : (9, 9), 'int2e_ipvip1'              : (9, 9), 'int2e_ip1ip2'              : (9, 9), 'int1e_ipippnucp'           : (9, 9), 'int1e_ippnucpip'           : (9, 9), 'int1e_ipipprinvp'          : (9, 9), 'int1e_ipprinvpip'          : (9, 9), 'int1e_ipipspnucsp'         : (36,9), 'int1e_ipspnucspip'         : (36,9), 'int1e_ipipsprinvsp'        : (36,9), 'int1e_ipsprinvspip'        : (36,9), 'int3c2e'                   : (1, 1), 'int3c2e_ip1'               : (3, 3), 'int3c2e_ip2'               : (3, 3), 'int3c2e_pvp1'              : (1, 1), 'int3c2e_pvxp1'             : (3, 3), 'int2c2e_ip1'               : (3, 3), 'int2c2e_ip2'               : (3, 3), 'int3c2e_ig1'               : (3, 3), 'int3c2e_spsp1'             : (4, 1), 'int3c2e_ipspsp1'           : (12,3), 'int3c2e_spsp1ip2'          : (12,3), 'int3c2e_ipip1'             : (9, 9), 'int3c2e_ipip2'             : (9, 9), 'int3c2e_ipvip1'            : (9, 9), 'int3c2e_ip1ip2'            : (9, 9), 'int2c2e_ip1ip2'            : (9, 9), 'int2c2e_ipip1'             : (9, 9), 'int3c1e'                   : (1, 1), 'int3c1e_ip1'               : (3, 3), 'int3c1e_p2'                : (1, 1), 'int3c1e_iprinv'            : (3, 3), 'int2c2e'                   : (1, 1), 'int2e_yp'                  : (1, 1), 'int2e_stg'                 : (1, 1), 'int2e_coulerf'             : (1, 1), "int1e_grids"               : (1, 1), "int1e_grids_ip"            : (3, 3), "int1e_grids_spvsp"         : (4, 1), 'ECPscalar'                 : (1, None), 'ECPscalar_ipnuc'           : (3, None), 'ECPscalar_iprinv'          : (3, None), 'ECPscalar_ignuc'           : (3, None), 'ECPscalar_iprinvip'        : (9, None), 'ECPso'                     : (3, 1), }
def getints2c(intor_name, atm, bas, env, shls_slice=None, comp=1, hermi=0, ao_loc=None, cintopt=None, out=None): atm = numpy.asarray(atm, dtype=numpy.int32, order='C') bas = numpy.asarray(bas, dtype=numpy.int32, order='C') env = numpy.asarray(env, dtype=numpy.double, order='C') natm = atm.shape[0] nbas = bas.shape[0] if shls_slice is None: shls_slice = (0, nbas, 0, nbas) else: assert (shls_slice[1] <= nbas and shls_slice[3] <= nbas) if ao_loc is None: ao_loc = make_loc(bas, intor_name)
def getints3c(intor_name, atm, bas, env, shls_slice=None, comp=1, aosym='s1', ao_loc=None, cintopt=None, out=None): atm = numpy.asarray(atm, dtype=numpy.int32, order='C') bas = numpy.asarray(bas, dtype=numpy.int32, order='C') env = numpy.asarray(env, dtype=numpy.double, order='C') natm = atm.shape[0] nbas = bas.shape[0] if shls_slice is None: shls_slice = (0, nbas, 0, nbas, 0, nbas) if 'ssc' in intor_name or 'spinor' in intor_name: bas = numpy.asarray(numpy.vstack((bas,bas)), dtype=numpy.int32) shls_slice = (0, nbas, 0, nbas, nbas, nbas*2) nbas = bas.shape[0] else: assert (shls_slice[1] <= nbas and shls_slice[3] <= nbas and shls_slice[5] <= nbas)
def getints4c(intor_name, atm, bas, env, shls_slice=None, comp=1, aosym='s1', ao_loc=None, cintopt=None, out=None): aosym = _stand_sym_code(aosym) atm = numpy.asarray(atm, dtype=numpy.int32, order='C') bas = numpy.asarray(bas, dtype=numpy.int32, order='C') env = numpy.asarray(env, dtype=numpy.double, order='C') c_atm = atm.ctypes.data_as(ctypes.c_void_p) c_bas = bas.ctypes.data_as(ctypes.c_void_p) c_env = env.ctypes.data_as(ctypes.c_void_p) natm = atm.shape[0] nbas = bas.shape[0] ao_loc = make_loc(bas, intor_name)
def getints_by_shell(intor_name, shls, atm, bas, env, comp=1): r'''For given 2, 3 or 4 shells, interface for libcint to get 1e, 2e, 2-center-2e or 3-center-2e integrals
def make_loc(bas, key): if 'cart' in key: l = bas[:,ANG_OF] dims = (l+1)*(l+2)//2 * bas[:,NCTR_OF] elif 'sph' in key: dims = (bas[:,ANG_OF]2+1) * bas[:,NCTR_OF]else:  # spinorl = bas[:,ANG_OF]k = bas[:,KAPPA_OF]dims = (l4+2) * bas[:,NCTR_OF] dims[k<0] = (l[k<0] * 2 + 2) * bas[k<0,NCTR_OF] dims[k>0] = (l[k>0] * 2    ) * bas[k>0,NCTR_OF]
def make_cintopt(atm, bas, env, intor): intor = intor.replace('_sph','').replace('_cart','').replace('_spinor','') c_atm = numpy.asarray(atm, dtype=numpy.int32, order='C') c_bas = numpy.asarray(bas, dtype=numpy.int32, order='C') c_env = numpy.asarray(env, dtype=numpy.double, order='C') natm = c_atm.shape[0] nbas = c_bas.shape[0] cintopt = ctypes.cast(lib.c_null_ptr(), _cintoptHandler) cintopt.intor = intor
class _cintoptHandler(ctypes.c_void_p): def del(self): try: if self.intor[:3] == 'ECP': libcgto.ECPdel_optimizer(ctypes.byref(self)) else: libcgto.CINTdel_optimizer(ctypes.byref(self)) except AttributeError: pass
def _stand_sym_code(sym): if isinstance(sym, int): return 's%d' % sym elif sym[0] in 'sS': return sym.lower() else: return 's' + sym.lower()
def ascint3(intor_name): '''convert cint2 function name to cint3 function name''' if intor_name.startswith('cint'): intor_name = intor_name[1:] if not intor_name.endswith(('_sph', '_cart', '_spinor', '_ssc')): intor_name = intor_name + '_spinor' return intor_name
if name == 'main': from pyscf import gto mol = gto.Mole() mol.verbose = 0 mol.output = None
=================================================================
FILE: pyscf/pbc/ao2mo/eris.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
''' This ao2mo module is kept for backward compatibility.  It's recommended to use pyscf.pbc.df module to get 2e MO integrals '''
import numpy as np from pyscf.pbc import df from pyscf import lib from pyscf.pbc.dft.gen_grid import gen_uniform_grids from pyscf.pbc.dft.numint import eval_ao from pyscf.pbc import tools from pyscf.lib import logger
einsum = lib.einsum
def general(cell, mo_coeffs, kpts=None, compact=False): '''pyscf-style wrapper to get MO 2-el integrals.''' if kpts is not None: assert len(kpts) == 4 return get_mo_eri(cell, mo_coeffs, kpts) #return df.FFTDF(cell).ao2mo(mo_coeffs, kpts, compact)
def get_mo_eri(cell, mo_coeffs, kpts=None): '''Convenience function to return MO 2-el integrals.''' mo_coeff12 = mo_coeffs[:2] mo_coeff34 = mo_coeffs[2:] if kpts is None: kpts12 = kpts34 = q = None else: kpts12 = kpts[:2] kpts34 = kpts[2:] q = kpts12[0] - kpts12[1] #q = kpts34[1] - kpts34[0] if q is None: q = np.zeros(3)
def get_mo_pairs_G(cell, mo_coeffs, kpts=None, q=None): '''Calculate forward (G|ij) FFT of all MO pairs.
def get_mo_pairs_invG(cell, mo_coeffs, kpts=None, q=None): '''Calculate "inverse" (ij|G) FFT of all MO pairs.
def assemble_eri(cell, orb_pair_invG1, orb_pair_G2, q=None, verbose=logger.INFO): '''Assemble 4-index electron repulsion integrals.
#def get_mo_eri(cell, mo_coeffs, kpts=None):
'''Convenience function to return MO 2-el integrals.'''
return general(cell, mo_coeffs, kpts)
#def get_mo_pairs_G(cell, mo_coeffs, kpts=None):
'''Calculate forward (G|ij) FFT of all MO pairs.
TODO: - Implement simplifications for real orbitals.
Args:
mo_coeff: length-2 list of (nao,nmo) ndarrays
The two sets of MO coefficients to use in calculating the
product |ij).
Returns:
mo_pairs_G : (ngrids, nmoi*nmoj) ndarray
The FFT of the real-space MO pairs.
'''
return df.FFTDF(cell).get_mo_pairs(mo_coeffs, kpts)
#def get_mo_pairs_invG(cell, mo_coeffs, kpts=None):
'''Calculate "inverse" (ij|G) FFT of all MO pairs.
TODO: - Implement simplifications for real orbitals.
Args:
mo_coeff: length-2 list of (nao,nmo) ndarrays
The two sets of MO coefficients to use in calculating the
product |ij).
Returns:
mo_pairs_invG : (ngrids, nmoi*nmoj) ndarray
The inverse FFTs of the real-space MO pairs.
'''
if kpts is None: kpts = numpy.zeros((2,3))
mo_pairs_G = df.FFTDF(cell).get_mo_pairs((mo_coeffs[1],mo_coeffs[0]),
(kpts[1],kpts[0]))
nmo0 = mo_coeffs[0].shape[1]
nmo1 = mo_coeffs[1].shape[1]
mo_pairs_invG = mo_pairs_G.T.reshape(nmo1,nmo0,-1).transpose(1,0,2).conj()
mo_pairs_invG = mo_pairs_invG.reshape(nmo0*nmo1,-1).T
return mo_pairs_invG
def get_ao_pairs_G(cell, kpts=None): '''Calculate forward (G|ij) and "inverse" (ij|G) FFT of all AO pairs.
def get_ao_eri(cell, kpts=None): '''Convenience function to return AO 2-el integrals.''' if kpts is not None: assert len(kpts) == 4 return df.FFTDF(cell).get_eri(kpts)
if name == 'main': from pyscf.pbc import gto as pgto cell = pgto.Cell() cell.atom = 'He 1. .5 .5; He .1 1.3 2.1' cell.basis = 'ccpvdz' cell.a = np.eye(3) * 4. cell.mesh = [11]*3 cell.build() print(get_ao_eri(cell).shape)
=================================================================
FILE: pyscf/pbc/ao2mo/init.py
=================================================================
Copyright 2014-2018 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
from .eris import *
=================================================================
FILE: pyscf/pbc/scf/hf.py
=================================================================
#!/usr/bin/env python
Copyright 2014-2024 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Authors: Garnet Chan 
Timothy Berkelbach 
Qiming Sun 
''' Hartree-Fock for periodic systems at a single k-point
See Also: pyscf.pbc.scf.khf.py : Hartree-Fock for periodic systems with k-point sampling '''
import sys
import numpy as np import scipy.linalg import h5py from pyscf.scf import hf as mol_hf from pyscf import lib from pyscf.lib import logger from pyscf.data import nist from pyscf.pbc import gto from pyscf.pbc import tools from pyscf.pbc.gto.pseudo import get_pp from pyscf.pbc.scf import addons from pyscf.pbc.scf import smearing from pyscf.pbc import df from pyscf.pbc.scf.rsjk import RangeSeparatedJKBuilder from pyscf.pbc.lib.kpts_helper import gamma_point from pyscf import config from pyscf.soscf import newton_ah
INVALID_ORBITAL_ENERGY = 1e30
def get_ovlp(cell, kpt=np.zeros(3)): '''Get the overlap AO matrix. ''' precision = cell.precision * 1e-6 rcut = max(cell.rcut, gto.estimate_rcut(cell, precision)) with lib.temporary_env(cell, rcut=rcut, precision=precision): # Avoid pbcopt's prescreening in the lattice sum, for better accuracy s = cell.pbc_intor('int1e_ovlp', hermi=0, kpts=kpt, pbcopt=lib.c_null_ptr()) s = np.asarray(s) hermi_error = abs(s - np.rollaxis(s.conj(), -1, -2)).max() if hermi_error > cell.precision and hermi_error > 1e-12: logger.warn(cell, '%.4g error found in overlap integrals. ' 'cell.precision  or  cell.rcut  can be adjusted to ' 'improve accuracy.', hermi_error) return s
def get_hcore(cell, kpt=np.zeros(3)): '''Get the core Hamiltonian AO matrix. ''' return SCF(cell).get_hcore(kpt=kpt)
def get_t(cell, kpt=np.zeros(3)): '''Get the kinetic energy AO matrix. ''' return cell.pbc_intor('int1e_kin', hermi=1, kpts=kpt)
def get_nuc(cell, kpt=np.zeros(3)): '''Get the bare periodic nuc-el AO matrix, with G=0 removed.
def get_j(cell, dm, hermi=1, vhfopt=None, kpt=np.zeros(3), kpts_band=None): '''Get the Coulomb (J) AO matrix for the given density matrix.
def get_jk(mf, cell, dm, hermi=1, vhfopt=None, kpt=np.zeros(3), kpts_band=None, with_j=True, with_k=True, omega=None, **kwargs): '''Get the Coulomb (J) and exchange (K) AO matrices for the given density matrix.
def get_bands(mf, kpts_band, cell=None, dm=None, kpt=None): '''Get energy bands at the given (arbitrary) 'band' k-points.
def init_guess_by_chkfile(cell, chkfile_name, project=None, kpt=None): '''Read the HF results from checkpoint file, then project it to the basis defined by cell
get_fock = mol_hf.get_fock get_occ = mol_hf.get_occ get_grad = mol_hf.get_grad make_rdm1 = mol_hf.make_rdm1 energy_elec = mol_hf.energy_elec
def eigh_with_canonical_orth(h, s): nkpts = len(h) nao = h[0].shape[0] mo_energy = np.empty((nkpts, nao)) mo_coeff = np.empty((nkpts, nao, nao), dtype=h.dtype) for k in range(nkpts): x = mol_hf.canonical_orthogonalization(s[k]) nmo_k = x.shape[1] xhx = x.conj().T.dot(h[k]).dot(x) e, c = scipy.linalg.eigh(xhx) mo_energy[k,:nmo_k] = e mo_coeff[k,:,:nmo_k] = x.dot(c) if nmo_k < nao: mo_energy[k,nmo_k:] = INVALID_ORBITAL_ENERGY mo_coeff[k,:,nmo_k:] = 0 return mo_energy, mo_coeff
def dip_moment(cell, dm, unit='Debye', verbose=logger.NOTE, grids=None, rho=None, kpt=np.zeros(3), origin=None): ''' Dipole moment in the cell (is it well defined)?
def _search_dipole_gauge_origin(cell, grids, rho, log): '''Optimize the position of the unit cell in crystal. With a proper unit cell, the nuclear charge center and the electron density center can be placed at the same point (zero net dipole). This function returns the coordinates of the center of the unit cell. ''' from pyscf.pbc.dft import gen_grid a = cell.lattice_vectors() b = np.linalg.inv(a).T charges = cell.atom_charges() coords  = cell.atom_coords() nelec = np.dot(rho, grids.weights)
def get_rho(mf, dm=None, grids=None, kpt=None): '''Compute density in real space ''' from pyscf.pbc.dft import gen_grid from pyscf.pbc.dft import numint if dm is None: dm = mf.make_rdm1() if getattr(dm, 'ndim', None) != 2:  # UHF dm = dm[0] + dm[1] if grids is None: grids = gen_grid.UniformGrids(mf.cell) if kpt is None: kpt = mf.kpt ni = numint.NumInt() return ni.get_rho(mf.cell, dm, grids, kpt, mf.max_memory)
def _dip_correction(mf): '''Makov-Payne corrections for charged systems.''' from pyscf.pbc import tools from pyscf.pbc.dft import gen_grid log = logger.new_logger(mf) cell = mf.cell a = cell.lattice_vectors() b = np.linalg.inv(a).T
def makov_payne_correction(mf): '''Makov-Payne correction (Phys. Rev. B, 51, 4014) ''' cell = mf.cell logger.note(mf, 'Makov-Payne correction for charged 3D PBC systems') # PRB 51 (1995), 4014 # PRB 77 (2008), 115139 if cell.dimension != 3: logger.warn(mf, 'Correction for low-dimension PBC systems' 'is not available.') return 0
def gen_response(mf, mo_coeff=None, mo_occ=None, singlet=None, hermi=0, max_memory=None, with_nlc=True): cell = mf.cell kpt = mf.kpt if (singlet is None or singlet) and hermi != 2: def vind(dm1): vj, vk = mf.get_jk(cell, dm1, hermi=hermi, kpt=kpt) return vj - .5 * vk else: def vind(dm1): return -.5 * mf.get_k(cell, dm1, hermi=hermi, kpt=kpt) return vind
class SCF(mol_hf.SCF): '''SCF base class adapted for PBCs.
class KohnShamDFT: '''A mock DFT base class
class RHF(SCF): '''PBC RHF at a single point (default: gamma point). '''
def _format_jks(vj, dm, kpts_band): if kpts_band is None: vj = vj.reshape(dm.shape) elif kpts_band.ndim == 1:  # a single k-point on bands vj = vj.reshape(dm.shape) elif getattr(dm, "ndim", 0) == 2: vj = vj[0] return vj
def normalize_dm_(mf, dm, s1e=None): ''' Scale density matrix to make it produce the correct number of electrons. ''' cell = mf.cell if s1e is None: s1e = mf.get_ovlp(cell) ne = lib.einsum('ij,ji->', dm, s1e).real if abs(ne - cell.nelectron) > 0.01: logger.debug(mf, 'Big error detected in the electron number ' 'of initial guess density matrix (Ne/cell = %g)!\n' '  This can cause huge error in Fock matrix and ' 'lead to instability in SCF for low-dimensional ' 'systems.\n  DM is normalized wrt the number ' 'of electrons %s', ne, cell.nelectron) dm *= cell.nelectron / ne return dm