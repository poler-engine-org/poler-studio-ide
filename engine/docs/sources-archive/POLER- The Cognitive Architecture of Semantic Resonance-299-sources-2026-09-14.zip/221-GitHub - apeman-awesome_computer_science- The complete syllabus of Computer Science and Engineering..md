> Source: https://github.com/apeman/awesome_computer_science

GitHub - apeman/awesome_computer_science: The complete syllabus of Computer Science and Engineering. Roadmap, Checklist for Beginners.
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
apeman / awesome_computer_science Public
Notifications You must be signed in to change notification settings
Fork 51
Star 529
The complete syllabus of Computer Science and Engineering. Roadmap, Checklist for Beginners.
License
MPL-2.0 license
529 stars 51 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 1
Pull requests 0
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
apeman/awesome_computer_science
main
1 Branch 0 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
MPL-2.0 license
🧠 Computer Science and Engineering Roadmap and Checklist
Complete syllabus of Computer Science and Engineering (UG), structured as a practical checklist.
📚 Overview
Computer Science is divided into 4 parts:
Computer Science 1 – Hardware & Engineering
Computer Science 2 – Programming & Core CS
Computer Science 3 – Daily / Systems CS
Computer Science 4 – Real-World Applications
📘 Discrete Mathematics PDF is required for understanding graphs
📐 Mathematics Syllabus
☁ Cloud computing basics are covered under Computer Networks
📑 Table of Contents
Computer Science 1
Digital Electronics
Computer Organization and Architecture
Theory of Computation and Automata
Computer Science 2
Compiler Design
Programming
Data Structures
Algorithms
Artificial Intelligence
Computer Science 3
Design and Analysis of Algorithms
Operating Systems
Computer Networks
DBMS and SQL
Software Engineering
Computer Science 4
Cryptography
Machine Learning
Computer Graphics
Web Development
Computer Science - 1
Digital Electronics
[-] Boolean Algebra
Number Systems
Arithmetic Operations
1's & 2's Complement
Karnaugh Maps [-] Hardware
Logic Gates
Flip-Flops & Latches
Adder / Subtractor
Encoder / Decoder
Multiplexer / Demultiplexer
Integrated Circuits
Printed Circuit Boards
Computer Organization and Architecture
[-] Computer Organization
Address Bus, Data Bus
ROM, EPROM, RAM
Memory Hierarchy & Cache
Virtual Memory
Secondary Storage
PLDs & Controllers
Input / Output Devices [-] Computer Architecture
Stack & Registers
Endianness
Floating Point Numbers
Addressing Modes
Pipelining
Interrupts
RISC vs CISC
aarch64, x86 / AMD64, MIPS, RISC-V
Assembly Language
Theory of Computation and Automata
[-] Automata and Languages
NFA
DFA
Regular Expressions
Context-Free Grammars
Pushdown Automata
Turing Machines
Decidability
Reducibility
P vs NP
Computer Science - 2
Compiler Design
[-] Lexical Analysis [-] Syntax Analysis [-] Type Checking [-] Intermediate Code Generation [-] Optimization [-] Code Generation [-] Assembly & Linking [-] Memory Management [-] Interpreters [-] Golang Specification
Programming
[-] C
Data Types & Type Conversion
Operators & Precedence
Functions & Scope
Control Flow
Arrays, Strings, Pointers
Structs, Union, Enum
Dynamic Memory
File I/O
math.h [-] C++
Namespaces
Classes & Objects
Access Control
Constructors & Destructors
Inheritance & Polymorphism
Templates
Data Structures
[-] Arrays [-] Linked Lists [-] Skip Lists [-] Hash Tables [-] Stack, Queue, Set [-] Trees
BST, AVL, Splay
Red-Black Trees
Segment Trees
Tries [-] Graphs
Adjacency Matrix
Adjacency List
Algorithms
[-] Searching (Binary Search, Priority Queue) [-] Sorting (Merge, Quick, Insertion, Selection) [-] BFS / DFS [-] Dijkstra [-] Bellman-Ford [-] Minimum Spanning Trees [-] Time & Space Complexity
Artificial Intelligence
[-] Knowledge Representation [-] First Order Logic [-] State Space Search [-] Hill Climbing [-] Simulated Annealing [-] A* [-] Min-Max [-] Bayes Theorem [-] Neural Networks [-] Gradient Descent [-] CNNs [-] Backpropagation
Computer Science - 3
DBMS and SQL
[-] SQL
DDL, DML, DQL, DCL, TCL
Joins
Subqueries
Aggregate Functions
Window Functions [-] DBMS
ER Model
Keys & Constraints
Normal Forms
Indexing
Transactions
ACID / BASE
SQL Injection
NoSQL
Operating Systems
[-] Boot Process [-] Processes & Threads [-] IPC [-] Scheduling Algorithms [-] Deadlocks & Synchronization [-] Memory Management [-] Virtual Memory [-] File Systems [-] OS Security [-] Unix Commands
Computer Networks
[-] OSI & TCP/IP Layers [-] Flow & Congestion Control [-] Routing Algorithms [-] UDP & Sockets [-] IPv4 / IPv6 [-] BGP & OSPF [-] HTTP, FTP, DNS, SMTP [-] Cloud Computing Basics
Software Engineering
[-] SDLC Models [-] Cost Estimation [-] COCOMO [-] Risk Management [-] Requirements Engineering [-] Design Principles [-] Testing & QA
Computer Science - 4
Cryptography and Network Security
[-] Encryption Algorithms [-] Hashing [-] Key Distribution [-] Digital Signatures [-] Compression [-] Firewalls [-] Steganography [-] SSL / TLS
Data Science and Machine Learning
[-] Bias & Variance [-] Supervised Learning [-] Unsupervised Learning [-] k-NN [-] Clustering [-] Image Processing
Web Development
[-] Frontend
HTML5
CSS3
JavaScript
Browser APIs
Accessibility [-] Backend
Go / Python
Git Internals
Message Queues
Computer Graphics
[-] OpenGL Basics [-] Rendering [-] Shading [-] Texturing [-] Ray Tracing [-] Ray Casting
Projects
👉 https://github.com/apeman/awesome_computer_science/blob/master/what-should-i-code.md
License
Mozilla Public License
About
The complete syllabus of Computer Science and Engineering. Roadmap, Checklist for Beginners.
Topics
css computer-science ui-design cryptography cloud compression programming computer-vision algorithms graphics game-development artificial-intelligence data-structures assembly-language database-management awesome-list operating-systems browsers compiler-design computer-networks
Resources
Readme
License
MPL-2.0 license
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
529 stars
Watchers
5 watching
Forks
51 forks
Report repository
Contributors 3
 apeman The Enlightened
 Tyuzu Tyuzu
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.