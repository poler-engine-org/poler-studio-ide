> Source: https://github.com/JuliaGraphs/JuliaGraphs-meta/issues/9

Community call - 2023.09.28 · Issue #9 · JuliaGraphs/JuliaGraphs-meta
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
GitHub Stars
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
JuliaGraphs / JuliaGraphs-meta Public
Notifications You must be signed in to change notification settings
Fork 2
Star 7
Code
Issues 8
Pull requests 0
Actions
Projects
Security and quality 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security and quality
Insights
Community call - 2023.09.28 #9
New issue
Copy link
New issue
Copy link
Open
Open
Community call - 2023.09.28 #9
Copy link
Description
gdalle
opened on Sep 28, 2023
Last edited by gdalle
Member
Issue body actions
Agenda
[x] Taking notes [x]  Introduction round: people and their projects [x]  Latest news: new website, GraphsBase.jl [x]  Organization guidelines ( ColPrac?) [x]  Release Graphs v1.9 together [x]  Open floor [x]  Future meetings To pick up a draggable item, press the space bar. While dragging, use the arrow keys to move the item. Press space again to drop the item in its new position, or press escape to cancel.
See main objectives at the bottom
Activity
gdalle commented on Sep 28, 2023
gdalle
on Sep 28, 2023
Last edited by gdalle
Member Author
More actions
Taking notes
One issue per meeting
Introduction round
Guillaume Dalle: EPFL. Works on graph machine learning and combinatorial optimization. Maintainer of the organization.
Matt Fishman: Flatiron institute: Works on quantum physics and tensor networks. Needs standardized options graphs with labels and metadata, have developed their own in the meantime.
Joseph Tindall: Same as Matt.
Filippos Christou: University of Stuttgart. Works on optical networks. Have developed NestedGraphs.jl and AttributeGraphs.jl
Aurora Rossi: Université Côte d'Azur. Works on temporal graphs, did GSoC on GraphNeuralNetworks.jl, contributed to Graphs.jl and GraphsOptim.jl.
Henrik Wolf : Dresden and Copenhagen. Works at the intersection of physics and complex systems, mobility. Interested in MetaGraphs.jl
Hector Perez: Carnegie Mellon. Works on operations research with RelationalAI.
Miscellaneous
Recruiting students with GSoC is a good idea
gdalle commented on Sep 28, 2023
gdalle
on Sep 28, 2023
Last edited by gdalle
Member Author
More actions
Latest news
GraphsBase.jl
will be breaking but the goal is to adapt all algorithms from Graphs.jl
core idea: vertices can be arbitrary, metadata is supported
interface design is a hard question and needs feedback
PRs are open for review ( Interface as simple as possible GraphsBase.jl#13)
will replace at least SimpleWeightedGraphs.jl and MetaGraphs(Next).jl
should hopefully support multigraphs (see WrappedMultigraphs.jl for inspiration?)
where to put vertex and edge metadata?
open issues in the new repo to discuss these things
gdalle commented on Sep 28, 2023
gdalle
on Sep 28, 2023
Last edited by gdalle
Member Author
More actions
Organization guidelines
ColPrac is a good start
waiting for review is frustrating on the dev side
waiting for answers on issues is frustrating on the user side
some PRs are bad
some PRs are easy to merge (eg. docs improvement)
problem of popularity: are there enough PRs to begin with?
does it matter if PRs and issues just sit there?
categorizing importance: bug fix > new feature
should the reviewer understand the algorithm?
more stringent with other things like tests
what if there's a bug and the original author has disappeared?
Test correctness against networkx Graphs.jl#287 could be good for correctness but raises the barrier to contribution a lot
add a little "please contribute even if you're a beginner"
leave the easy stuff for new people with "good first issue" (ambiguous wording)
reviews are valuable even from people without merge rights
gdalle commented on Sep 28, 2023
gdalle
on Sep 28, 2023
Member Author
More actions
Future meetings
Once per month is a good frequency
gdalle commented on Sep 28, 2023
gdalle
on Sep 28, 2023
Last edited by gdalle
Member Author
More actions
Main objectives in the coming weeks
Vote on ColPrac in Adopt ColPrac? #10
Lower the contribution barrier (categorize issues and PRs, invite beginners, review carefully but not too demandingly)
Give feedback and suggestions for the nascent GraphsBase.jl interface in the repo's issues
filchristou commented on Sep 29, 2023
filchristou
on Sep 29, 2023
More actions
I just realized that there is a community calendar. It might be a good idea to broadcast the event details there.
gdalle commented on Sep 29, 2023
gdalle
on Sep 29, 2023
Member Author
More actions
I tried but I'm still waiting to hear about who's in charge of it now (the page still says to contact Logan)
Sign up for free to join this conversation on GitHub. Already have an account? Sign in to comment
Metadata
Metadata
Assignees
No one assigned
Labels
No labels
No labels
Type
No type
Fields
Give feedback
No fields configured for issues without a type.
Projects
No projects
Milestone
No milestone
Relationships
None yet
Development
No branches or pull requests
Participants
 
Issue actions
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.