> Source: https://www.nist.gov/srd

Standard Reference Data | NIST
Skip to main content 
An official website of the United States government
Here's how you know
Here's how you know 
Official websites use .gov
A .gov website belongs to an official government organization in the United States. 
Secure .gov websites use HTTPS
A lock ( A locked padlock ) or https:// means you've safely connected to the .gov website. Share sensitive information only on official, secure websites.
https://www.nist.gov/srd 
Search NIST 
Menu
Close
Publications
What We Do
All Topics
Advanced communications
Artificial intelligence
Bioscience
Buildings and construction
Chemistry
Cybersecurity and Privacy
Electronics
Energy
Environment
Fire
Forensic science
Health
Information technology
Infrastructure
Manufacturing
Materials
Mathematics and statistics
Metrology
Nanotechnology
Neutron research
Performance excellence
Physics
Public safety
Quantum information science
Resilience
Standards
Transportation
Labs & Major Programs
Assoc Director of Laboratory Programs
Laboratories
Communications Technology Laboratory
Engineering Laboratory
Information Technology Laboratory
Material Measurement Laboratory
Physical Measurement Laboratory
User Facilities
NIST Center for Neutron Research
CNST NanoFab
Research Test Beds
Research Projects
Tools & Instruments
Major Programs
Baldrige Performance Excellence Program
CHIPS for America Initiative
Manufacturing Extension Partnership (MEP)
Office of Advanced Manufacturing
Special Programs Office
Technology Partnerships Office
Services & Resources
Measurements and Standards
Calibration Services
Laboratory Accreditation (NVLAP)
Quality System
Standard Reference Materials (SRMs)
Standard Reference Instruments (SRIs)
Standards.gov
Time Services
Office of Weights and Measures
Software
Data
Chemistry WebBook
National Vulnerability Database
Physical Reference Data
Standard Reference Data (SRD)
Storefront
License & Patents
Computer Security Resource Center (CSRC)
NIST Research Library
News & Events
News
Events
Blogs
NIST In Focus
Feature Stories
Awards
Video Gallery
Image Gallery
Media Contacts
About NIST
About Us
Leadership
Organization Structure
Budget & Planning
Contact Us
Visit
Careers
Student programs
Work with NIST
History
NIST Digital Archives
NIST Museum
NIST and the Nobel
Educational Resources
Standard Reference Data
For over 50 years, NIST has developed and distributed Standard Reference Data in Chemistry, Engineering, Fluids and Condensed Phases, Material Sciences, Mathematical and Computer Sciences and Physics..
SHOP Expand or Collapse
SRD Online Subscriptions
Special Database Catalog
SRD Catalog
Free SRD
SRD Sorted by Topic
Public Law
SRD Definition
Critical Evaluation Criteria
Journal of Physical and Chemical Reference Data
National Standard Reference Data Series
Related Data Products and Links Expand or Collapse
Curated Data Collections
Special Databases and Special Software
NIST Public Data
International Metrology Resource Registry
NIST Mass Spectral Libraries, 2026 Edition
NIST INORGANIC CRYSTAL STRUCTURE DATABASE (ICSD) SRD3
REFPROP: NIST Reference Fluid Thermodynamic and Transport Properties
New Database 
Crystal Structure Database, for more information visit https://icsd.nist.gov
NIST produces the Nation's Standard Reference Data (SRD). These data are assessed by experts and are trustworthy such that people can use the data with confidence and base significant decisions on the data. NIST provides 49 free SRD databases and 41 fee-based SRD databases. SRD must be compliant with rigorous critical evaluation criteria. Send questions to data@nist.gov or call 1(844) 374-0183 (Toll Free).
Popular Data Products 
Recent Update. NIST ICSD SRD3 is currently available, visit https://icsd.nist.gov
REFPROP: Reference Fluid Thermodynamic and Transport Properties FAQ
NIST26: NIST Mass Spectral Libraries, 2026 Edition MS Data Center
ICSD: The NIST Inorganic Crystal Structure Database (ICSD) is a comprehensive collection of crystal structure data of inorganic compounds containing more than 210,000 entries and covering the literature from 1913.
TDE: NIST ThermoDataEngine
PIV Cards: NIST Test Personal Identity Verification Card
PED: NIST-ACers Phase Equilibria Diagram Database 6.0. demo and PED Editor
SESSA: NIST Simulation of Electron Spectra for Surface Analysis. Now Free!
Special Databases - Biometrics
Selected NIST-Recommended Practice Guides in Material Sciences
Download NIST Simulation of Electron Spectra for Surface Analysis at no cost. The surface databases provide data for surface analysis by Auger-electron spectroscopy (AES) and X-ray photoelectron spectroscopy (XPS). In addition, the NIST Electron Elastic-Scattering Cross-Section Database (SRD 64) and the NIST Database of Cross Sections for Inner-Shell Ionization by Electron or Positron Impact (SRD 164) provide data for Monte Carlo simulations of electron transport in matter and for applications in atomic physics, plasma physics, radiation physics, and materials analysis by electron-probe microanalysis.
SRD Customer Support 
100 Bureau Drive, Stop 6410
Gaithersburg, MD 20899-6410
Tel: 1(844) 374-0183 (Toll Free)
e-mail data@nist.gov 
Data Portals
Mass Spectrometry Data Center
Physical Reference Data Portal
Chemistry WebBook
Atomic Spectroscopy Databases
Thermodynamics Research Center
Standard Reference Materials®
Calibration Services
NIST Software
NIST on GitHub 
Popular Links
Exhibits at Upcoming Conferences
Office of Data and Informatics
Material Measurement Laboratory
Physical Measurement Laboratory
Was this page helpful?
HEADQUARTERS
100 Bureau Drive
Gaithersburg, MD 20899
301-975-2000
Webmaster | Contact Us | Our Other Offices
X.com Facebook LinkedIn Instagram YouTube Giphy RSS Feed Mailing List
How are we doing? Feedback
Site Privacy
Accessibility
Privacy Program
Copyright & Disclaimers
Vulnerability Disclosure
No Fear Act Policy
FOIA
Environmental Policy
Scientific Integrity
Information Quality Standards
Commerce.gov
Science.gov
USA.gov
Vote.gov
Back to top