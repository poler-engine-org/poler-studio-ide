> Source: https://wiki.cachyos.org/features/kernel/

Attention Required! | Cloudflare
Please enable cookies.
Sorry, you have been blocked
You are unable to access cachyos.org
Why have I been blocked?
This website is using a security service to protect itself from online attacks. The action you just performed triggered the security solution. There are several actions that could trigger this block including submitting a certain word or phrase, a SQL command or malformed data.
What can I do to resolve this?
You can email the site owner to let them know you were blocked. Please include what you were doing when this page came up and the Cloudflare Ray ID found at the bottom of this page.
Cloudflare Ray ID: 9d3dd813bc7b35b5
• Your IP: Click to reveal 66.102.6.74
• Performance & security by Cloudflare