COMBINED DOCUMENT
Dynamics of Disordered Quantum Systems withTwo- and Three-Dimensional Tensor Networks
Joseph Tindall et al. — Science 392, 868 (2026)
Supplementary Materials + All 63 Referenced Documents
DOI: 10.1126/science.adx2728
This document combines the original Supplementary Materials with the content of all 63 references cited therein.Each document is separated by a divider with its reference number and full citation.Source content was extracted from publicly accessible web pages (arXiv, publisher sites, GitHub, etc.).
TABLE OF CONTENTS
[0]  ORIGINAL DOCUMENT: Supplementary Materials (Tindall et al., 2026)
[1]  Ref [1]: X. Mi et al. — Time-crystalline eigenstate order on a quantum processor (Nature 601, 531-536, 2022)
[2]  Ref [2]: M. Iqbal et al. — Topological order from measurements and feed-forward on a trapped ion quantum computer (Commun. Phys. 7, 205, 2024)
[3]  Ref [3]: A. Keesling et al. — Quantum Kibble-Zurek mechanism and critical dynamics on a programmable Rydberg simulator (Nature 568, 207-211, 2019)
[4]  Ref [4]: M. Buzzi et al. — Photomolecular high-temperature superconductivity (Phys. Rev. X 10, 031028, 2020)
[5]  Ref [5]: P. Frey, S. Rachel — Realization of a discrete time crystal on 57 qubits of a quantum computer (Sci. Adv. 8, eabm7652, 2022)
[6]  Ref [6]: Q. Guo et al. — Stark many-body localization on a superconducting quantum processor (Phys. Rev. Lett. 127, 240502, 2021)
[7]  Ref [7]: J. Smith et al. — Many-body localization in a quantum simulator with programmable random disorder (Nat. Phys. 12, 907-911, 2016)
[8]  Ref [8]: M. Schiró, M. Fabrizio — Time-dependent mean field theory for quench dynamics in correlated electron systems (Phys. Rev. Lett. 105, 076401, 2010)
[9]  Ref [9]: K. Ido, T. Ohgoe, M. Imada — Time-dependent many-variable variational Monte Carlo method (Phys. Rev. B 92, 245106, 2015)
[10]  Ref [10]: M. Yang, S. R. White — Time-dependent variational principle with ancillary Krylov subspace (Phys. Rev. B 102, 094315, 2020)
[11]  Ref [11]: K. Donatella et al. — Dynamics with autoregressive neural quantum states (Phys. Rev. A 108, 022210, 2023)
[12]  Ref [12]: I. L. Gutiérrez, C. B. Mendl — Real time evolution with neural-network quantum states (Quantum 6, 627, 2022)
[13]  Ref [13]: B. Kloss et al. — Studying dynamics in two-dimensional quantum lattices using tree tensor network states (SciPost Phys. 9, 070, 2020)
[14]  Ref [14]: S. Paeckel et al. — Time-evolution methods for matrix-product states (Ann. Phys. 411, 167998, 2019)
[15]  Ref [15]: J. Wurtz, A. Polkovnikov, D. Sels — Cluster truncated Wigner approximation in strongly interacting systems (Ann. Phys. 395, 341-365, 2018)
[16]  Ref [16]: R. Khasseh et al. — Discrete truncated Wigner approach to dynamical phase transitions in Ising models (Phys. Rev. B 102, 014303, 2020)
[17]  Ref [17]: A. Sinibaldi et al. — Unbiasing time-dependent Variational Monte Carlo by projected quantum evolution (Quantum 7, 1131, 2023)
[18]  Ref [18]: F. Arute et al. — Quantum supremacy using a programmable superconducting processor (Nature 574, 505-510, 2019)
[19]  Ref [19]: A. Morvan et al. — Phase transitions in random circuit sampling (Nature 634, 328-333, 2024)
[20]  Ref [20]: A. D. King et al. — Beyond-classical computation in quantum simulation (Science 388, 199-204, 2025)
[21]  Ref [21]: S. Ebadi et al. — Quantum phases of matter on a 256-atom programmable quantum simulator (Nature 595, 227-232, 2021)
[22]  Ref [22]: Y. Kim et al. — Evidence for the utility of quantum computing before fault tolerance (Nature 618, 500-505, 2023)
[23]  Ref [23]: F. Pan, P. Zhang — Simulation of quantum circuits using the big-batch tensor network method (Phys. Rev. Lett. 128, 030501, 2022)
[24]  Ref [24]: J. Gray, S. Kourtis — Hyper-optimized tensor network contraction (Quantum 5, 410, 2021)
[25]  Ref [25]: T. Ayral et al. — Density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity (PRX Quantum 4, 020304, 2023)
[26]  Ref [26]: T. Schuster et al. — A polynomial-time classical algorithm for noisy quantum circuits (Phys. Rev. X 15, 041018, 2025)
[27]  Ref [27]: J. Robledo-Moreno et al. — Chemistry beyond the scale of exact diagonalization on a quantum-centric supercomputer (Sci. Adv. 11, eadu9991, 2025)
[28]  Ref [28]: J. Tindall et al. — Efficient tensor network simulation of IBM's Eagle Kicked Ising experiment (PRX Quantum 5, 010308, 2024)
[29]  Ref [29]: T. Begušić, J. Gray, G. K.-L. Chan — Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance (Sci. Adv. 10, eadk4321, 2024)
[30]  Ref [30]: M. S. Rudolph, E. Fontana, Z. Holmes, L. Cincio — Classical surrogate simulation of quantum systems with LOWESA (arXiv:2308.09109, 2023)
[31]  Ref [31]: M. S. Rudolph, J. Tindall — Simulating and sampling from quantum circuits with 2D tensor networks (arXiv:2507.11424, 2025)
[32]  Ref [32]: N. Schuch et al. — Computational complexity of projected entangled pair states (Phys. Rev. Lett. 98, 140506, 2007)
[33]  Ref [33]: J. Haferkamp et al. — Contracting projected entangled pair states is average-case hard (Phys. Rev. Res. 2, 013010, 2020)
[34]  Ref [34]: R. Alkabetz, I. Arad — Tensor networks contraction and the belief propagation algorithm (Phys. Rev. Res. 3, 023073, 2021)
[35]  Ref [35]: J. Tindall, M. Fishman — Gauging tensor networks with belief propagation (SciPost Phys. 15, 222, 2023)
[36]  Ref [36]: G. Vidal — Efficient simulation of one-dimensional quantum many-body systems (Phys. Rev. Lett. 93, 040502, 2004)
[37]  Ref [37]: H. C. Jiang et al. — Accurate determination of tensor network state of quantum lattice models in two dimensions (Phys. Rev. Lett. 101, 090603, 2008)
[38]  Ref [38]: M. Lubasch et al. — Algorithms for finite projected entangled pair states (Phys. Rev. B 90, 064425, 2014)
[39]  Ref [39]: H. N. Phien et al. — Infinite projected entangled pair states algorithm improved (Phys. Rev. B 92, 035142, 2015)
[40]  Ref [40]: Supplementary materials are available online
[41]  Ref [41]: I. A. Luchnikov et al. — Large-scale quantum annealing simulation with tensor networks and belief propagation (arXiv:2409.12240, 2024)
[42]  Ref [42]: F. Verstraete, J. I. Cirac — Renormalization algorithms for quantum-many body systems in two and higher dimensions (arXiv:cond-mat/0407066, 2004)
[43]  Ref [43]: G. Evenbly et al. — Loop series expansions for tensor networks (arXiv:2409.03108, 2024)
[44]  Ref [44]: D. B. Johnson — Finding all the elementary circuits of a directed graph (SIAM J. Comput. 4, 77-84, 1975)
[45]  Ref [45]: J. Fairbanks et al. — JuliaGraphs/Graphs.jl: An optimized graphs package for the Julia programming language (2021)
[46]  Ref [46]: J. Haegeman et al. — Time-dependent variational principle for quantum lattices (Phys. Rev. Lett. 107, 070601, 2011)
[47]  Ref [47]: A. D. King et al. — Quantum critical dynamics in a 5,000-qubit programmable spin glass (Nature 617, 61-66, 2023)
[48]  Ref [48]: K. Trachenko, A. Zaccone — Slow stretched-exponential and fast compressed-exponential relaxation (J. Phys. Condens. Matter 33, 315101, 2021)
[49]  Ref [49]: Z. W. Wu et al. — Stretched and compressed exponentials in the relaxation dynamics of a metallic glass-forming melt (Nat. Commun. 9, 5334, 2018)
[50]  Ref [50]: M. Bernaschi et al. — The quantum transition of the two-dimensional Ising spin glass (Nature 631, 749-754, 2024)
[51]  Ref [51]: Y. Kato, S. Onoda — Numerical evidence of quantum melting of spin ice (Phys. Rev. Lett. 115, 077202, 2015)
[52]  Ref [52]: J. Tindall, M. Rudolph — TensorNetworkQuantumSimulator.jl (2025)
[53]  Ref [53]: J. Tindall et al. — Data for: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks (Dryad, 2025)
[54]  Ref [54]: S. Sahu, B. Swingle — Efficient tensor network simulation of quantum many-body physics on sparse graphs (arXiv:2206.04701, 2022)
[55]  Ref [55]: S. S. Jahromi, R. Orús — Universal tensor-network algorithm for any infinite lattice (Phys. Rev. B 99, 195105, 2019)
[56]  Ref [56]: P. Pippan et al. — Efficient matrix-product state method for periodic boundary conditions (Phys. Rev. B 81, 081103, 2010)
[57]  Ref [57]: C. Guo, D. Poletti, I. Arad — Block belief propagation algorithm for two-dimensional tensor networks (Phys. Rev. B 108, 125111, 2023)
[58]  Ref [58]: G. Vidal — Efficient classical simulation of slightly entangled quantum computations (Phys. Rev. Lett. 91, 147902, 2003)
[59]  Ref [59]: Y. Zhou et al. — What limits the simulation of quantum computers? (Phys. Rev. X 10, 041038, 2020)
[60]  Ref [60]: S.-B. B. Lee et al. — Scalable projected entangled-pair state representation of random quantum circuit states (Phys. Rev. Res. 7, 033252, 2025)
[61]  Ref [61]: L. Mauron, G. Carleo — Challenging the quantum advantage frontier with large-scale classical simulations of annealing dynamics (arXiv:2503.08247, 2025)
[62]  Ref [62]: J. Bezanson et al. — Julia: A Fresh Approach to Numerical Computing (SIAM Rev. 59, 65-98, 2017)
[63]  Ref [63]: M. Fishman, S. R. White, E. M. Stoudenmire — The ITensor Software Library for tensor network calculations (arXiv:2007.14822, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ORIGINAL DOCUMENT: Tindall et al. — Dynamics of disordered quantum systems with two- and three-dimensional tensor networks (Supplementary Materials, Science 392, 868, 2026)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Source: science.adx2728_sm (1).pdf — Full text extraction
DOI: 10.1126/science.adx2728 | Science 392, 868 (2026)
Supplementary Materials forDynamics of disordered quantum systems with two- and three-dimensional tensornetworksJoseph Tindall et al.Corresponding authors: Joseph Tindall, jtindall@flatironinstitute.org; Dries Sels, dsels@bu.eduScience 392, 868 (2026)DOI: 10.1126/science.adx2728The PDF file includes:Materials and MethodsSupplementary TextFigs. S1 to S5References
TensorNetworkMethodologyHere we outline our tensor network-based simulation approach in detail. We model the wavefunc-tion under the time-dependent Hamiltonian 𝐻(𝑠) in Eq. 1 as a tensor network of low-rank tensorswhose structure mimics that of the underlying lattice geometry - i.e. for every pair of neighboringpoints in the lattice there exists a virtual edge or bond between the corresponding tensors in thetensornetwork.Inthecaseofthedimerizedcubiclattice,wepairthedimerstogetherintoasingletensor with two physical legs, effectively realizing a regular cubic tensor network. This removesthe inherent loops that form from couplings in the 𝑧-direction between the spins in the dimers andthusmakethestructuremore“tree-like”.Belief Propagation and Loop Corrections: In this work we use belief propagation (34,35,54)andextensionsthereoftoevolvethetensornetworkstate|𝜓⟩andcomputeobservables.Forevolvingthestateweuseregular(non-corrected)beliefpropagationduetoitsefficiencyandsimplicity,whichis equivalent to performing gate evolution with the standard simple update method (34,35,37,55)butreformulatedinamoregeneralizableframework.Onemethodweuseforcomputingobservablesis loop-corrected belief propagation (43) to improve the accuracy of our results beyond the beliefpropagationapproximation.Bothtasksrelyoncomputing“messagetensors”whichformrank-oneprojectorstothevirtualbasisdefinedontheedgesofatensornetwork T whoseverticesrepresenteitherindividualtensorsorgroupsoftensors.Infig.S1weillustratethebeliefpropagationalgorithmfor an example network T where the vertices of the network T may represent individual tensors𝑣or collections of tensors. In the case of a norm network, defined as T = ⟨𝜓|𝜓⟩, the verticesrepresentuncontractedpairsofbraandkettensorsfrom|𝜓⟩,thatisT 𝑣 = 𝜓 𝑣 𝜓 𝑣 ∗.Messagetensorsaredefined along the edges of the norm network whose indices match the virtual indices connectingthe corresponding bra and ket tensors on each end of the edge. A self-consistent update rule isdefinedforeachmessagetensoras(cid:214)𝑀 𝑣→𝑣′ = (cid:169) (cid:173) 𝑀 𝑣′′→𝑣 (cid:170) (cid:174) T 𝑣 (S1)𝑣′′∈{neighbors(𝑣)/𝑣′}(cid:171) (cid:172)and this rule is iterated until convergence of the message tensors. Imposing the normalizationconditionS2
𝑀 𝑣→𝑣′ · 𝑀 𝑣′→𝑣 = 1 is helpful both for numerical stability and for later computations with themessagetensors.For T = ⟨𝜓|𝜓⟩,asingleiterationthatupdateseverymessagescalesas O(𝑁𝜒𝑧+1)in time where 𝑁 is the number of tensors in |𝜓⟩, 𝑧 is the maximum coordination of the verticesof the graph, and 𝜒 is the maximum dimension of the virtual indices in |𝜓⟩. Convergence of themessagetensorsistypicallyexponentiallyfastinthenumberofiterations.The resulting message tensors can be used in a variety of ways. For instance, they can be usedto perform a truncation following a two-site update with a gate 𝐺ˆ on a neighboring pair of sites in|𝜓⟩ (35).Thisisthemethodweadoptinourtime-evolutionprotocolduetoitsnumericalefficiencyandsimplicity.Messagetensorscanalsobeusedtocomputelocalandnon-localobservables⟨𝑂⟩.Atthesimplest,butmostapproximate,levelonejustplacesthemessagetensorsobtainedfrom ⟨𝜓|𝜓⟩incident to the region of support of 𝑂, inserts 𝑂, and contracts the tensors to obtain the expectedvalue of 𝑂. If the network is unnormalized the result can be divided by the same contraction butwithout 𝑂 inserted. Alternatively, belief propagation can be run directly on the network ⟨𝜓|𝑂|𝜓⟩,grouping together the local bra, ket, and operator tensors, and then the resulting message tensorscanbeusedtoapproximatethecontractionofthewholenetworkviatheformula(cid:16) (cid:17)(cid:206) (cid:0)𝜓 𝑂 𝜓∗(cid:1)(cid:206) 𝑀𝑣∈verts 𝑣 𝑣 𝑣 𝑣′∈neighbors(𝑣) 𝑣′→𝑣⟨𝜓|𝑂|𝜓⟩ = , (S2)(cid:206) 𝑀 · 𝑀𝑒∈edges 𝑒 reverse(𝑒)which is more appropriate in the case of non-local observables with a large region of support. Ifthe network is unnormalized an equivalent contraction should be done on the network ⟨𝜓|𝜓⟩ andusedasadivisor.Bothoftheaboveapproaches,however,donotaccountfortheloopsinthelatticeandthusmakeafairlysevereapproximationforcorrelatedstatesandtensornetworkswithalargerdensityofsmallloops. Nonetheless, the messages obtained from belief propagation can be used as a basis fromwhich to expand the contraction of a tensor network as a multi-dimensional sum which contains“loop-corrected”terms(43).In the loop-corrected approach the contraction of the target tensor network T (with tensors ortensor groups 𝑇 ,𝑇 ,...𝑇 ) upon which message tensors have been computed is written as a sum1 2 𝑁over 2𝑁 edges configurations involving the placement of either a rank-1 projector P 𝑒 = 𝑀 ←𝑒− ⊗ 𝑀 →−𝑒 oran antiprojector I− P on each of the edges 𝑒 of the network. Specifically, letting S denote some𝑒S3
subsetofthesetofedges 𝐸,wecandefinetheterm(cid:32) 𝐿 (cid:33) (cid:32) (cid:33)(cid:214) (cid:214) (cid:214)𝑊 S = 𝑇 𝑖 (I−P 𝑒 ) (cid:169) (cid:173) P 𝑒 (cid:170) (cid:174) , (S3)𝑣=1 𝑒∈S 𝑒∈𝐸/S(cid:171) (cid:172)involving the placement of |S| antiprojectors in the specified configuration and 𝑁 − |S| pro-edgesjectorsontheremainingedgesofthenetwork.Then,thefullcontractionofthenetworkisgivenbythesum𝑁edges∑︁ ∑︁T = 𝑊 , (S4)S𝑖=0 S∈(𝐸)𝑖where (cid:0)𝐸(cid:1) denotes the set of all subsets of the edges of the tensor network of size 𝑖. It is helpful𝑖to note that, due to the fixed point condition on the converged message tensors (see Eq. S2), theterm𝑊 is zero if there exists any vertex 𝑣 for which only one antiprojector is incident. Since theSmagnitude of a single term 𝑊 should generically decay exponentially with |𝑆|, an efficient, butSpotentially highly accurate, approximation for the contraction of the network can then be found bysumming up all nonzero configurations with some maximum threshold number of 𝑙 ≪ 𝑁max edgesantiprojectors,thatis𝑙max∑︁ ∑︁T ≈ 𝑊 . (S5)S𝑖=0 S∈(𝐸)𝑖SupplementaryFigureS1Cshowstheloopcorrectionprocedureforanexampletensornetwork,illustrating all the nonzero𝑊 terms that form the sum in Eq. S4. This is the approach we take for𝑠computing“loop-corrected”observablessuchas⟨𝜓|𝜎𝑧𝜎𝑧 |𝜓⟩⟨𝜎𝑧𝜎𝑧 ⟩ = 𝑖 𝑗 , (S6)𝑖 𝑗 ⟨𝜓|𝜓⟩for any 𝑖, 𝑗 from the tensor networks |𝜓⟩ we obtain in this work. While ⟨𝜎𝑧𝜎𝑧 ⟩ can be computed𝑖 𝑗via separate loop-corrected contractions of the numerator and denominator in Eq. S6, we find thatfindingBPfixedpointsoftensornetworkssuchas ⟨𝜓|𝜎𝑧𝜎𝑧 |𝜓⟩ whicharenotpositive-definite(i.e.𝑖 𝑗they are not of the form 𝑂 = 𝑋𝑋†) can be difficult. Thus it is beneficial to first recast ⟨𝜎𝑧𝜎𝑧 ⟩ in𝑖 𝑗termsofacombinationofobservableswhichareallpositive-definite:⟨𝜓|𝑃↑𝑃↑ |𝜓⟩ + ⟨𝜓|𝑃↓𝑃↓ |𝜓⟩ − ⟨𝜓|𝑃↑𝑃↓ |𝜓⟩ − ⟨𝜓|𝑃↓𝑃↑ |𝜓⟩ ⟨𝜓|𝑃↑𝑃↑ |𝜓⟩ − ⟨𝜓|𝑃↓𝑃↑ |𝜓⟩⟨𝜎𝑧𝜎𝑧⟩ =𝑖 𝑗 𝑖 𝑗 𝑖 𝑗 𝑖 𝑗=𝑖 𝑗 𝑖 𝑗𝑖 𝑗 ⟨𝜓|𝑃↑𝑃↑ |𝜓⟩ + ⟨𝜓|𝑃↓𝑃↓ |𝜓⟩ + ⟨𝜓|𝑃↑𝑃↓ |𝜓⟩ + ⟨𝜓|𝑃↓𝑃↑ |𝜓⟩ ⟨𝜓|𝑃↑𝑃↑ |𝜓⟩ + ⟨𝜓|𝑃↓𝑃↑ |𝜓⟩𝑖 𝑗 𝑖 𝑗 𝑖 𝑗 𝑖 𝑗 𝑖 𝑗 𝑖 𝑗(S7)S4
where 𝑃↑ and 𝑃↓ are the projectors to spin up and spin down respectively on the given site and𝑖 𝑖the last equality follows only due to the Z 2 symmetry of the wavefunction ((i.e (cid:0)(cid:206) 𝑖 𝜎 𝑖 𝑥(cid:1) |𝜓⟩ = |𝜓⟩)which we find to be well preserved during our TN-based evolution despite no explicit encoding ofsymmetries into the tensors. We note that such symmetries could be encoded directly at the leveloftheindividualtensors,andpotentiallyimprovetheefficiencyofourcalculations—somethingweleaveforfuturework.We thus compute ⟨𝜎𝑧𝜎𝑧 ⟩ by using loop corrections to contract the two positive definite tensor𝑖 𝑗networks ⟨𝜓|𝑃↑𝑃↑ |𝜓⟩ and ⟨𝜓|𝑃↓𝑃↑ |𝜓⟩ and substituting into Eq. S7. In the case the Z symmetry𝑖 𝑗 𝑖 𝑗 2is not present, loop corrections can be used to approximate the contraction of the four networksfrom Eq. S7 instead. For each network, we group together tensors associated with each site andthen run belief propagation over the resulting partitioned network (whose vertices represent thecorresponding groups of tensors) to obtain converged message tensors. We use a well-establishedgraphical loop counting algorithm (44,45) to enumerate short loops in our networks and thencompose the loops together to efficiently enumerate all configurations for which 𝑊 is nonzero𝑆and the number of antiprojectors is less than some amount 𝑙 . We contract these configurations,maxsomething which can be done in a fully parallelizable manner, and add them up to form a loop-correctedapproximationfor ⟨𝜎𝑧𝜎𝑧 ⟩.Inthemaintextweshowourresultsusingdifferentvaluesof𝑖 𝑗𝑙 .Thecomputationalscalingofthisapproachdependson𝑙 andthecoordinationnumber𝑧ofmax maxthe underlying lattice. Evaluating T = ⟨𝜓|𝑂|𝜓⟩ (where 𝑂 is a product of local spin-1/2 operatorsand tensors sharing site indices are grouped together) with 𝑙 max = 0, for instance, can be achievedin O(𝑁𝜒𝑧+1) time. Meanwhile, the next order correction will involve 𝑙 being set to the size ofmaxthe shortest loop in the tensor network and its evaluation scales in time linearly in the loop lengthand as O(𝑁𝜒𝑧+2) + O(𝑁𝜒6) with the bond dimension and system size—although we remark thatif the loop is sufficiently large, methods like randomized SVD or Krylov solvers can be used toaccelerate the scaling to O(𝑚𝑁𝜒𝑧+1) where 𝑚 is the number of dominant eigenmodes targeted inthedecomposition(56).Whileinthisworkwerunloop-correctedbeliefpropagationtoobtainmessagesandcontracttheconfigurations in each network separately, Eq. S4 holds forarbitrary message tensors provided thenormalization condition 𝑀 𝑒 · 𝑀 reverse(e) = 1 holds. More efficient ways to obtain multiple observ-ables at once via loop corrections could be achieved by using a consistent set of message tensorsS5
(saythosefrom ⟨𝜓|𝜓⟩ or ⟨𝜓|𝑂′|𝜓⟩ where𝑂′issomesubsetofthelocaloperatorsthatmakeupthefull operator 𝑂) across the expansion of the different observables {⟨𝜓|𝑂 |𝜓⟩,⟨𝜓|𝑂 |𝜓⟩,...} that1 2need to be measured. Therefore, we could cache certain loop contractions which appear multipletimesintheexpansionofvariousobservables.Carewouldneedtobetaken,however,toensurethemessage tensors used still form a good basis for each of the individual networks ⟨𝜓|𝑂 |𝜓⟩, which𝑖islikelytobethecaseonlyifthesupportoftherelevantobservableissmall.Cylindrical MPS Message Passing: For the case of a cylindrical tensor network we find, forsufficientlylargecylindersizes,thatcylindricalmessagepassingisamoreeffectivemethodthanloopcorrections for computing two-point observables in the network. This method can still be viewedasavariantofbeliefpropagation(seealsoRef.(57)whichintroducesarelatedhybridizationoftheboundary MPS and BP algorithms) where the network has been partitioned via its columns into aring and MPS messages leaving a column are iteratively updated as the truncated product of theincoming message to that column and the column itself (see fig. S2A). Upon convergence the twoMPS messages incident to a column form an approximation for the derivative of the network withrespect to that column. The degree of the approximation depends on two factors: the maximumvirtualbonddimensionallowedintheMPSmessagetensorsandthecircumferenceofthecylinder.Thelatterisanerrorthatoccursduetotheperiodicboundaryinthesystem,withtheMPSmessageseffectivelyignoringthecorrelationswhichflowaroundthecircumferenceofthecylinder.Thiserrorwill generically decay exponentially in the circumference of the cylinder (see Fig. 3 of the maintext),makingthemethodhighlyeffectiveforlargecylinders.TocomputeaMPSmessageupdate,wetaketheoutgoingmessage |𝑀 ⟩ fromacolumnof𝑐→𝑐+1tensors T tobetheonewithafixedvirtualdimension 𝑅 thatmaximizesthecostfunction𝑐⟨𝑀 |T|𝑀 ⟩𝐶 =𝑐−1→𝑐 𝑐 𝑐→𝑐+1. (S8)√︁⟨𝑀 |𝑀 ⟩𝑐→𝑐+1 𝑐→𝑐+1Assuming the incoming message is fixed, we set the orthogonality center of |𝑀 ⟩ to the𝑐→𝑐+1tensor on a given site 𝑠 and then differentiate the cost function with respect to that tensor. Anupdate of that tensor that maximizes the cost function should then be equal to the contractionof ⟨𝑀 |T|𝑀 ⟩ with the tensor removed (see fig. S2B). The fitting can thus be done by𝑐−1→𝑐 𝑐 𝑐→𝑐+1forming an initial guess for |𝑀 ⟩, iteratively moving the orthogonality center up and down𝑐→𝑐+1S6
the MPS, and replacing the tensor with the derivative of ⟨𝑀 |T|𝑀 ⟩ with respect to that𝑐−1→𝑐 𝑐 𝑐→𝑐+1tensor. The cost function should then converge and the next MPS can be updated until they allconverge. For the cylindrical tensor network T = ⟨𝜓|𝑂|𝜓⟩, where𝑂 is a product of local spin-1/2operators, identifying the optimal contract order of the tensors leads to a computational scaling intime of O(𝑅3𝜒5) if 𝑅 ≤ 𝜒 and O(𝑅2𝜒6) + O(𝑅3𝜒4) if 𝑅 > 𝜒. In this work we set 𝑅 = 2𝜒 forour desired accuracy, giving a scaling of O(𝑁𝜒8). This approach generalizes immediately to anytensor network T which forms an open-boundary or half-periodic planar lattice, with the scalingincreasingwiththecoordinationnumber 𝑧 ofthelattice.This MPS message passing method can be exploited further to efficiently compute multi-pointcorrelatorsinthesystemandwedosointhiswork.Specifically,considerthegoalofcomputingthesetof𝑁 two-pointcorrelators{⟨𝜎𝑧𝜎𝑧 ⟩,⟨𝜎𝑧𝜎𝑧 ⟩,⟨𝜎𝑧𝜎𝑧 ⟩...⟨𝜎𝑧𝜎𝑧 ⟩}betweensite𝑖andtheremain-𝑖 1 𝑖 2 𝑖 3 𝑖 𝑁ingsitesinthelattice.ByperformingourcorrelatedMPSmessagepassingonthepositive-definitenetwork ⟨𝜓|𝑃↑ |𝜓⟩, where 𝑃↑ is the spin up projector on site𝑖, and then systematically zig-zagging𝑖 𝑖through the columns with the incident MPS messages inserted, we can extract all the one-site re-duceddensitymatrices,conditionedontheprojectionofsite𝑖 tospinup.InthesystemathandthewavefunctionisZ 2 symmetric(i.e (cid:0)(cid:206) 𝑖 𝜎 𝑖 𝑥(cid:1) |𝜓⟩ = |𝜓⟩)andsothisinformationisallthatisrequiredto compute the set {⟨𝜎𝑧𝜎𝑧 ⟩,⟨𝜎𝑧𝜎𝑧 ⟩,⟨𝜎𝑧𝜎𝑧 ⟩...⟨𝜎𝑧𝜎𝑧 ⟩} in linear time. This method can then be𝑖 1 𝑖 2 𝑖 3 𝑖 𝑁reapplied for each site𝑖 to compute all two-point correlators in O(𝑁2) time. This approach can begeneralisedtocaseswithouttheZ symmetrybyinsertionoftheoperator𝜎𝑧insteadoftheprojector.2 𝑖Gate evolution: The tensor network at renormalized time 𝑠 = 𝑡 is evolved by a discrete time𝑡𝑎step𝛿𝑡 viatheapplicationofaseriesofone-andtwo-sitegateswhichstemfroma2ndorderTrotterdecompositionofthefullpropagator𝑈(𝑠) = exp(−i𝐻(𝑠)𝛿𝑡) ≈𝑈 X (𝑠)𝑈 ZZ (𝑠)𝑈 X (𝑠) (S9)with𝐿 (cid:18) 𝛿𝑡 (cid:19)(cid:214)𝑈 X (𝑠) = exp −i 2 Γ(𝑠)𝜎 𝑖 𝑥 (S10)𝑖=1and(cid:214)𝑈 ZZ (𝑠) = exp(−i𝛿𝑡J(𝑠)𝜎 𝑖 𝑧𝜎 𝑗 𝑧 ). (S11)⟨𝑖,𝑗⟩S7
The time step 𝛿𝑡 = 0.01ns we use is enough for the Trotter error to remain sufficiently low for theaccuracyneededinthiswork.The one-site gates in Eq. S10 can be applied directly to the tensor network without any lossof fidelity or change in the message tensors. Meanwhile, all the two site gates in Eq. S11 act onneighboring tensors in the network and thus we can efficiently use belief propagation-computedenvironments (see fig. S1B for an illustration on how to compute these environments) to truncatethe virtual bond between the corresponding neighboring tensors upon applying the gate. This isequivalent to applying the gate using the standard simple update algorithm (34–37,58). The totaltime complexity for the simulation of the dynamics is thus O (cid:0)𝑁𝜒𝑧+1𝑡 𝑎 (cid:1) where 𝑁 is the number𝛿𝑡of qubits, 𝜒 is the maximum bond dimension allowed in the simulation, and 𝑧 is the maximumcoordinationnumberoftheverticesintheunderlyinglattice(4forcylindrical,4fordiamondcubic,and6forthedimerizedcubic).Toinitializethesysteminthegroundstateof𝐻(0)werunimaginarytime evolution with the same simple update procedure as we do for the dynamics. As the groundstate has only very small correlations (J(0) ≫ Γ(0)) this is sufficient to obtain a highly accurateinitialstate.Thefinaltruncationthatweperforminthecylindricallatticecasebeforemeasuringobservablesis done via belief propagation (35). Note that to obtain the highest accuracy truncation under theBPapproximation,onecanre-runbeliefpropagationtoobtainconvergedmessagetensorsandusethose to perform the truncation, though for small truncation errors and Trotter step sizes the finalmessagesobtainedfromtheevolutionmaybesufficientlyconvergedalready.Systemsizescalinganalysisforthree-dimensionaldiamondsimulationsHere we provide extensive data and analysis for tensor network simulations on diamond latticesranginginsizefrom18qubits(𝐿 𝑥 ×𝐿 𝑦 ×𝐿 𝑧 = 3×3×8)to900qubits(𝐿 𝑥 ×𝐿 𝑦 ×𝐿 𝑧 = 12×12×24).Due to the linear scaling with system size of our simulations for a fixed annealing time and bonddimension,suchsystemsizesarepossiblewithmoderatecomputationalresources.Moreover,thereareseveralmetricswecanefficientlycomputethatattesttothe“quality”ofthesimulation.Thefirstoftheseistheaveragegateerror𝜖 whichwecomputefollowingthetimeevolutionof𝑔S8
thetensornetworkvia1𝑛 𝑛(cid:214)𝜖 𝑔 = (cid:169) (cid:173) 1− (1−𝜖 𝑔 )(cid:170) (cid:174) (S12)𝑔=1(cid:171) (cid:172)wheretheproductisoverall 𝑛 two-qubitgatesappliedtothetensornetworkduringthesimulationand 𝜖 isdefinedastheindividualgateerror𝑔𝜒′∑︁𝜖 𝑔 = 𝜎 𝑖 2, (S13)𝑖=𝜒+1i.e.thesumofthesquareofthediscardedsingularvaluesduringtheSVDperformedfollowingtheapplication of a gate 𝐺ˆ (where the normalization (cid:205)𝜒′ 𝜎2 = 1 is enforced) to the tensor network𝑖=1 𝑖representation of the state |𝜓 ⟩. On a tree tensor network, 𝜖 is precisely the individual gate𝑡−𝛿𝑡 𝑔error(59),1− |⟨𝜓𝑡|𝐺ˆ |𝜓𝑡−𝛿𝑡⟩|2 whileonaloopynetworkitisagoodapproximation(31,60).Our second metric is based on the strength of the first order loop corrections in the tensornetwork following evolution. Specifically we take a random sample of 𝑁 two-point correlators⟨𝜎𝑧𝜎𝑧 ⟩ wherethepairofsites𝑖 and 𝑗 areseparatedbyafixedpathlength 𝑑 andcompute𝑖 𝑗(cid:205) |⟨𝜎𝑧𝜎𝑧 ⟩ − ⟨𝜎𝑧𝜎𝑧 ⟩ |𝜖 BP (𝑑) = 100· (𝑖,𝑗) (cid:205) 𝑖 𝑗 | 𝑙 ⟨ m 𝜎 ax= 𝑧𝜎 6 𝑧 ⟩ 𝑖 | 𝑗 𝑙 max=0 , dist(𝑖, 𝑗) = 𝑑 (S14)(𝑖,𝑗) 𝑖 𝑗 𝑙 max=6which is a relative measure (as a percentage) of how much the smallest loops in the lattice affectcorrelatorsatthegivendistance 𝑑.Infig.S3Aweshowhowtheaveragegateerrorscaleswithsystemsizein3Ddiamondlatticesfor several annealing times (𝑡 ∈ {4ns,7ns,15ns}) and bond dimensions (𝜒 ∈ {8,16,32}). In all𝑎cases increasing the bond dimension leads to systematically lower gate errors while increasing theannealingtimeleadstolargergateerrors,whichisalsoobservedforthecylindricallatticeinfig.2ofthemaintext.Mostnotable,however,istheclearsaturationofgateerrorforsystemsizesof∼ 100qubits and beyond. This data indicates that increasing system size beyond this point does not leadto lower accuracy in terms of gate errors or local fidelity of the tensor network. It should be notedthat this saturation trend seems consistent with the saturation trend that appears to be emerging intheground-truth-basederrorsplottedinFig.3Bofthemaintextandthusprovidesstrongevidencethatfixedaccuracyresultscanbeobtainedwithlinearresourcesforafixedannealingtime.In fig. S3B we show how the deviation between the BP and first-order loop-corrected resultsfor third nearest neighbor correlators (𝑑 = 3) varies with system size. Again, after a short initialS9
increasewithsystemsize,theloopcorrelationsappeartosaturatewithsystemsize,suggestingthatat fixed annealing times loop effects are stable with increasing system size. This means that wedo not require increasing orders of loop corrections with system size to compute a correlator to adesiredaccuracy.Finally, in fig. S4 we provide walltimes for 3D diamond simulations as a function of systemsize. In fig. S4A we provide timings for CPU-based simulations of the BP-based time evolution,demonstrating clear linear scaling with system size for fixed bond dimension and annealing time.Meanwhile, in fig. S4B we provide timing data for measuring a single randomly selected 𝑧 − 𝑧correlator on both a CPU and GPU for several bond dimensions. Again, all results show clearlinear scaling with system size. Notably, there is a dramatic speedup obtained by using a GPU totake the measurement at larger bond dimensions, reaching a 10× speedup for 𝜒 = 32 on the givendiamondlattices.BoththecontractionsnecessarytoconvergetheBPmessagetensorsandcontractthenecessaryloopsareperformedontherespectivehardware.DetailsofKibbleZurekcollapsesIn fig. 4B of the main text we show collapse of both the spin glass order parameter and distance-dependent correlation function for diamond and cylindrical lattices respectively. Here we providefurtherdetailsonthecollapseperformedandhowwedeterminetheKibble-Zurekexponent 𝜇 andnon-trivialfittingparameter𝑟.Inthecylindricalcase,acylindricaltensornetworkapproachisused,withabeliefpropagation-based time evolution protocol of the Trotterized circuit implemented with a maximum bond di-mension 𝜒 BP = 32. The final state is truncated down, with BP, to bond dimension 𝜒 = 8 and MPSmessagepassingwithaMPSrankof 𝑅 = 16isusedtocalculatetherelevant 𝑧 −𝑧 correlators.Wecalculatethecorrelationfunction𝐶(𝑑) = |⟨𝜎𝑧𝜎𝑧 ⟩ − ⟨𝜎𝑧 ⟩⟨𝜎𝑧 ⟩| , (S15)𝑖 𝑗 𝑖 𝑗 dist(𝑖,𝑗)=𝑑wheretheaverageistakenovertendisorderrealizationsanddist(𝑖, 𝑗) isdefinedasthelengthofthepath(i.e.theManhattandistance)betweenthequbits𝑖 and 𝑗.Weonlyconsiderqubitsthatliealongthesamecolumninthecylinder,ignorethequbitsattheendofeachcolumn,andensureoneofthequbits in the correlator is in the center of the column to minimize boundary effects. We find that,S10
foragivenannealingtimeandcylindersize,thecorrelationfunctionfitsacompressedexponentialfunction(48,49)𝐶(𝑑) ∼ 𝑎0exp(−𝑎1𝑑𝛼) with𝛼 > 1overmoderatedistances(𝑑 < 10).Weobserve𝛼 ∼ 1.3.Upon rescaling the distance as 𝑑˜ = 𝑡 − 𝜇 1 𝑑 where 𝜇 is the Kibble-Zurek exponent we then𝑎observe the anticipated collapse of the correlation function (3). The Kibble-Zurek exponent wasvery recently estimated in Ref. (50) with extensive Monte Carlo simulations of the correspondingclassicalmodelin2+1D.Avalueof 𝜇 = 2.6±0.3wasobtainedforthefinite-sizesystemsstudiedwhilescalingargumentsledtoanestimationof 𝜇 = 3.17±0.41inthethermodynamiclimit.Hereweobtainavaluefor 𝜇 foragivencylindersizebyfindingthevaluewherethedatagivesthe best fit (in terms of the sum of the absolute values of the relative residuals) to the compressedexponential: 𝐶(𝑑˜ ) ∼ 𝑎 exp(−𝑎 𝑑˜𝛼) where 𝑎 , 𝑎 , and 𝛼 are free fitting parameters determined0 1 0 1fromaleast-squaresfitting.Weseeacollapseovermanyordersofmagnitudeandthecurvefittingthedataexcellently.Forthelargestcylinder(18×18)weobtainabestfittothedisorder-averageddatawith 𝜇 ≈ 2.75whichisconsistentwiththefinite-sizepredictionofRef.(50)andfromthecollapseoftheBindercumulantforthethreelargestcylindersinRef.(20)whichyielded 𝜇 = 2.67±0.29.Inthediamondcase,adiamondtensornetworkapproachisused,withabeliefpropagation-basedtime evolution protocol of the Trotterized circuit implemented with a maximum bond dimension𝜒 = 16.Loopcorrectionswith 𝑙 max = 6isusedtocalculatetherelevant 𝑧 −𝑧 correlators.Foreachannealingtimeandsystemsize,thespinglassorderparameter⟨𝑞2⟩ = 2 (cid:205) ⟨𝜎𝑧𝜎𝑧 ⟩2 is estimated from a random sample of 500 of the correlators. Data is𝑁(𝑁−1) 𝑖<𝑗 𝑖 𝑗thenaveragedover5independentdisorderrealizations.Weconsidertherangeofsystemsizes√︃𝐿 𝑥 ,𝐿 𝑦 ,𝐿 𝑧 = (8,8,8),(8,8,12),(8,8,12),(10,10,16), with 𝐿 = 3 𝐿 𝑥 𝐿 4 𝑦 𝐿 𝑧 the cube root of thenumberofqubits.Collapse is then performed by rescaling ⟨𝑞2⟩ with 𝐿𝑟 and the annealing time 𝑡 with 𝐿−𝜇. We𝑎use a value of 𝜇 = 2.85 from the literature on 3D Ising Spin glasses (20,47) and determine thenon-trivialparameter𝑟 ≈ 0.17byidentifyingthevalueof𝑟 whichbestcollapses(i.e.minimizestheresidualinaleast-squaresfitting)thedatatoastraightlineinthe(𝑥,𝑦) = (cid:0)log(⟨𝑞2⟩𝐿𝑟),log(𝑡 𝑎 𝐿−𝜇) (cid:1)plane.S11
OffsettingTruncationsDuringTimeEvolutionInoursimulationsofthedynamicsofEq.1forthecylindricalspin-glassweuseabonddimensionduringtheevolutionof 𝜒 BP = 32beforetruncatingtoalowerbonddimension 𝜒 < 32toenabletheuseofmoreaccuratecorrectionsofbeliefpropagationtomeasureobservables(whosecomputationalscaling is higher than uncorrected belief propagation). We find this “overshooting” of the bond-dimensionwithbeliefpropagationbasedsimpleupdatehighlyeffectiveincomparisontokeepingthebond-dimension constant and lower throughout the simulation, i.e. identical for both the evolutionandmeasurementphasesofthesimulation.This is shown explicitly in fig. S5 where we provide a comparison of the final error 𝜖 of the𝑐simulation for 𝜒 BP = 32 and 𝜒 BP = 𝜒, where 𝜒 is the bond dimension of the state at two differentannealing times on the 8 × 8 cylindrical lattice. The effect of maintaining a larger value of 𝜒BPduring the evolution is clear and leads to a large error reduction. This mode of simulation can beseenas“offsetting”significanttruncationsuntilthefinalstateisobtained,wherethetruncationcanthenbedonemorefaithfullywithrespecttothedesiredstate.Inthecaseofthethree-dimensionallattices,thelowestordersofloopcorrectionsaregenerallymoreaffordablethanMPSmessagepassingwith𝑅 = O(𝜒) onthecylinderandthuswefindwecanobtainmaintainaconsistent,relativelyhigh,bonddimensionduringtheevolutionanddonotneedto perform a final truncation to enable the use of loop corrections—although we still anticipateusingalarger 𝜒 mayleadtoanimprovementintheerror.BPComplementaryWorkFollowing the initial release of this paper, we became aware of a complementary effort whichfocussed on classically simulating the 𝑡 𝑎 = 7ns quenches on 𝑁 ≤ 128 diamond lattices withtime-dependentvariationalMonteCarlo(61).SoftwareAll of our simulations were performed using the TensorNetworkQuantumSimulator.jl (52)library, an open-source and publicly available Julia (62) package for quantum simulation withgeneraltensornetworksbuiltontopof ITensors.jl(63).S12
Figure S1: (A) Tensor network on a simple 5-vertex graph. The vertices may represent individualtensors or groups of tensors. (B) Belief propagation involves defining message tensors along bothdirections of the edges of the norm network with the indices of the message tensors matchingthe virtual indices of the bra and ket tensors along that edge. An update rule is defined for everymessagetensorastheproductofthemessagesincidenttothevertexthemessageisleavingandthetensors on the vertex. This rule is iterated until all messages are converged, with a normalizationrule imposed for numerical stability. (C) The outer product of the two message tensors on anedge of T form a projector P to a rank-1 subspace. The full contraction of the network can then𝑒be written as a sum over all 2𝑁 edges configurations involving either a projector or its antiprojectorI − P . Only the nonzero terms are shown: any configuration where there exists a vertex where𝑒onlyoneantiprojectorisincidentiszero.Thecontractionofthenetworkcanthenbeapproximatedby summing configurations up to a certain number of antiprojectors, with the term with zeroantiprojectorscorrespondingtotheuncorrectedbeliefpropagationresult.S13
FigureS2:(A)Matrixproductstatemessagepassingonacylindricaltensornetwork.Thetensorsinthenetworkcouldrepresentsingletensorsorgroupsoftensors.Matrixproductstatesarerepeatedlypassed around the cylinder a finite number of times until they converge. (B) One-site optimizationprocedure for the matrix product state message passing. An initial matrix product state is usedas a guess for the outgoing MPS from the product of an incoming matrix product state and thecolumn. The tensor on the orthogonality center of the outgoing MPS can be updated with thederivativeofthecorrespondingMPS-MPO-MPSnetworkwithrespecttothattensor.Byrepeatedlysweeping up and down the MPS, moving the orthogonality center and caching contractions of theMPS-MPO-MPS structure, the sites of the outgoing MPS can be efficiently optimized one-by-oneuntilconvergenceofthecostfunction.S14
Figure S3: Error metrics for tensor network simulations of 3D diamond inputs across a range ofincreasingsystemsizes.Eachcolumnshowsadifferentannealingtime.(A)Averagetwo-qubitgateerror (see Eq. S12) versus system size and for various bond dimensions. (B) Averaged relativedifference (as a percentage) (see Eq. S14) between belief propagation (𝑙 max = 0) and first order(𝑙 max = 6) loop corrections for third nearest neighbor correlators. Given the fast saturation ofthe results with system size, we choose not to run the 𝜒 = 32 results for larger system sizes forenvironmental reasons, though we emphasize that the calculations scale only linearly with systemsizeforagivenbonddimension.S15
Figure S4: Walltimes for tensor network simulations of 3D diamond inputs across a range ofincreasing system sizes. Dotted lines represent linear fits. (A) Two different annealing times (leftand right panel) and CPU walltime for BP-based time evolution for simulating the time-evolution(𝑠 = 0to𝑠 = 0.6).Walltimesarebasedonmulti-threadedsimulationsusing8coresofasingleIntelIcelakeCPUandaveragedover5disorderinstances.(B)Walltimesformeasuringasinglerandomlychosen𝑧−𝑧 correlatorfrom3Dtensornetworksofvariousbonddimensions(left,center,andrightpanel). In all cases 32-bit floating point precision is used and the tensor network is that obtainedwithBP-basedsimpleupdatefollowinganannealingprotocolwith𝑡 𝑎 = 7ns.CPUwalltimeisbasedonamultithreadedsimulationusing8coresofasingleIntelXeonGold6244CPU.GPUwalltimeisbasedonasimulationusinganNvidiaRTXA6000GPU.ForlargebonddimensionswemeasureatenfoldspeedupwhenusingtheGPUversustheCPU.S16
Figure S5: Error 𝜖 𝑐 —see Eq. 2—from two-dimensional tensor network simulations of a quantumannealingprotocolforadisordered8×8cylindricalspinglass.Thesame𝑁 = 20disorderrealizationare used as in Ref. (20). Error bars correspond to double the standard error on the mean. We run aBP-based evolution protocol of the Trotterized circuit with a maximum bond dimension 𝜒 andBP(in the case 𝜒 > 𝜒) truncate down, with BP, to a final state of bond dimension 𝜒 before usingBPcylindricalboundaryMPSwithaMPSrankof 𝑅 = 2𝜒 tocalculate ⟨𝜎𝑧𝜎𝑧 ⟩ ∀𝑖, 𝑗.𝑖 𝑗S17
References and notes1. X. Mi, M. Ippoliti, C. Quintana, A. Greene, Z. Chen, J. Gross, F. Arute, K. Arya, J. Atalaya,R. Babbush, J. C. Bardin, J. Basso, A. Bengtsson, A. Bilmes, A. Bourassa, L. Brill, M.Broughton, B. B. Buckley, D. A. Buell, B. Burkett, N. Bushnell, B. Chiaro, R. Collins,W. Courtney, D. Debroy, S. Demura, A. R. Derk, A. Dunsworth, D. Eppens, C. Erickson,E. Farhi, A. G. Fowler, B. Foxen, C. Gidney, M. Giustina, M. P. Harrigan, S. D.Harrington, J. Hilton, A. Ho, S. Hong, T. Huang, A. Huff, W. J. Huggins, L. B. Ioffe, S.V. Isakov, J. Iveland, E. Jeffrey, Z. Jiang, C. Jones, D. Kafri, T. Khattar, S. Kim, A.Kitaev, P. V. Klimov, A. N. Korotkov, F. Kostritsa, D. Landhuis, P. Laptev, J. Lee, K.Lee, A. Locharla, E. Lucero, O. Martin, J. R. McClean, T. McCourt, M. McEwen, K. C.Miao, M. Mohseni, S. Montazeri, W. Mruczkiewicz, O. Naaman, M. Neeley, C. Neill, M.Newman, M. Y. Niu, T. E. O’Brien, A. Opremcak, E. Ostby, B. Pato, A. Petukhov, N. C.Rubin, D. Sank, K. J. Satzinger, V. Shvarts, Y. Su, D. Strain, M. Szalay, M. D.Trevithick, B. Villalonga, T. White, Z. J. Yao, P. Yeh, J. Yoo, A. Zalcman, H. Neven, S.Boixo, V. Smelyanskiy, A. Megrant, J. Kelly, Y. Chen, S. L. Sondhi, R. Moessner, K.Kechedzhi, V. Khemani, P. Roushan, Time-crystalline eigenstate order on a quantumprocessor. Nature 601, 531–536 (2022). doi:10.1038/s41586-021-04257-w Medline2. M. Iqbal, N. Tantivasadakarn, T. M. Gatterman, J. A. Gerber, K. Gilmore, D. Gresh, A.Hankin, N. Hewitt, C. V. Horst, M. Matheny, T. Mengle, B. Neyenhuis, A. Vishwanath,M. Foss-Feig, R. Verresen, H. Dreyer, Topological order from measurements and feed-forward on a trapped ion quantum computer. Commun. Phys. 7, 205 (2024).doi:10.1038/s42005-024-01698-33. A. Keesling, A. Omran, H. Levine, H. Bernien, H. Pichler, S. Choi, R. Samajdar, S. Schwartz,P. Silvi, S. Sachdev, P. Zoller, M. Endres, M. Greiner, V. Vuletić, M. D. Lukin, QuantumKibble-Zurek mechanism and critical dynamics on a programmable Rydberg simulator.Nature 568, 207–211 (2019). doi:10.1038/s41586-019-1070-1 Medline4. M. Buzzi, D. Nicoletti, M. Fechner, N. Tancogne-Dejean, M. A. Sentef, A. Georges, T.Biesner, E. Uykur, M. Dressel, A. Henderson, T. Siegrist, J. A. Schlueter, K. Miyagawa,K. Kanoda, M.-S. Nam, A. Ardavan, J. Coulthard, J. Tindall, F. Schlawin, D. Jaksch, A.Cavalleri, Photomolecular high-temperature superconductivity. Phys. Rev. X 10, 031028(2020). doi:10.1103/PhysRevX.10.0310285. P. Frey, S. Rachel, Realization of a discrete time crystal on 57 qubits of a quantum computer.Sci. Adv. 8, eabm7652 (2022). doi:10.1126/sciadv.abm7652 Medline6. Q. Guo, C. Cheng, H. Li, S. Xu, P. Zhang, Z. Wang, C. Song, W. Liu, W. Ren, H. Dong, R.Mondaini, H. Wang, Stark many-body localization on a superconducting quantumprocessor. Phys. Rev. Lett. 127, 240502 (2021). doi:10.1103/PhysRevLett.127.240502Medline7. J. Smith, A. Lee, P. Richerme, B. Neyenhuis, P. W. Hess, P. Hauke, M. Heyl, D. A. Huse, C.Monroe, Many-body localization in a quantum simulator with programmable randomdisorder. Nat. Phys. 12, 907–911 (2016). doi:10.1038/nphys3783
8. M. Schiró, M. Fabrizio, Time-dependent mean field theory for quench dynamics in correlatedelectron systems. Phys. Rev. Lett. 105, 076401 (2010).doi:10.1103/PhysRevLett.105.076401 Medline9. K. Ido, T. Ohgoe, M. Imada, Time-dependent many-variable variational Monte Carlo methodfor nonequilibrium strongly correlated electron systems. Phys. Rev. B Condens. MatterMater. Phys. 92, 245106 (2015). doi:10.1103/PhysRevB.92.24510610. M. Yang, S. R. White, Time-dependent variational principle with ancillary Krylov subspace.Phys. Rev. B 102, 094315 (2020). doi:10.1103/PhysRevB.102.09431511. K. Donatella, Z. Denis, A. Le Boité, C. Ciuti, Dynamics with autoregressive neural quantumstates: Application to critical quench dynamics. Phys. Rev. A 108, 022210 (2023).doi:10.1103/PhysRevA.108.02221012. I. L. Gutiérrez, C. B. Mendl, Real time evolution with neural-network quantum states.Quantum) 6, 627 (2022). doi:10.22331/q-2022-01-20-62713. B. Kloss, D. R. Reichman, Y. Bar Lev, Studying dynamics in two-dimensional quantumlattices using tree tensor network states. SciPost Phys. 9, 070 (2020).doi:10.21468/SciPostPhys.9.5.07014. S. Paeckel, T. Köhler, A. Swoboda, S. R. Manmana, U. Schollwöck, C. Hubig, Time-evolution methods for matrix-product states. Ann. Phys. 411, 167998 (2019).doi:10.1016/j.aop.2019.16799815. J. Wurtz, A. Polkovnikov, D. Sels, Cluster truncated Wigner approximation in stronglyinteracting systems. Ann. Phys. 395, 341–365 (2018). doi:10.1016/j.aop.2018.06.00116. R. Khasseh, A. Russomanno, M. Schmitt, M. Heyl, R. Fazio, Discrete truncated Wignerapproach to dynamical phase transitions in Ising models after a quantum quench. Phys.Rev. B 102, 014303 (2020). doi:10.1103/PhysRevB.102.01430317. A. Sinibaldi, C. Giuliani, G. Carleo, F. Vicentini, Unbiasing time-dependent VariationalMonte Carlo by projected quantum evolution. Quantum (Vienna) 7, 1131 (2023).doi:10.22331/q-2023-10-10-113118. F. Arute, K. Arya, R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F.G. S. L. Brandao, D. A. Buell, B. Burkett, Y. Chen, Z. Chen, B. Chiaro, R. Collins, W.Courtney, A. Dunsworth, E. Farhi, B. Foxen, A. Fowler, C. Gidney, M. Giustina, R.Graff, K. Guerin, S. Habegger, M. P. Harrigan, M. J. Hartmann, A. Ho, M. Hoffmann, T.Huang, T. S. Humble, S. V. Isakov, E. Jeffrey, Z. Jiang, D. Kafri, K. Kechedzhi, J. Kelly,P. V. Klimov, S. Knysh, A. Korotkov, F. Kostritsa, D. Landhuis, M. Lindmark, E.Lucero, D. Lyakh, S. Mandrà, J. R. McClean, M. McEwen, A. Megrant, X. Mi, K.Michielsen, M. Mohseni, J. Mutus, O. Naaman, M. Neeley, C. Neill, M. Y. Niu, E.Ostby, A. Petukhov, J. C. Platt, C. Quintana, E. G. Rieffel, P. Roushan, N. C. Rubin, D.Sank, K. J. Satzinger, V. Smelyanskiy, K. J. Sung, M. D. Trevithick, A. Vainsencher, B.Villalonga, T. White, Z. J. Yao, P. Yeh, A. Zalcman, H. Neven, J. M. Martinis, Quantumsupremacy using a programmable superconducting processor. Nature 574, 505–510(2019). doi:10.1038/s41586-019-1666-5 Medline19. A. Morvan, B. Villalonga, X. Mi, S. Mandrà, A. Bengtsson, P. V. Klimov, Z. Chen, S. Hong,C. Erickson, I. K. Drozdov, J. Chau, G. Laun, R. Movassagh, A. Asfaw, L. T. A. N.
Brandão, R. Peralta, D. Abanin, R. Acharya, R. Allen, T. I. Andersen, K. Anderson, M.Ansmann, F. Arute, K. Arya, J. Atalaya, J. C. Bardin, A. Bilmes, G. Bortoli, A. Bourassa,J. Bovaird, L. Brill, M. Broughton, B. B. Buckley, D. A. Buell, T. Burger, B. Burkett, N.Bushnell, J. Campero, H.-S. Chang, B. Chiaro, D. Chik, C. Chou, J. Cogan, R. Collins, P.Conner, W. Courtney, A. L. Crook, B. Curtin, D. M. Debroy, A. D. T. Barba, S. Demura,A. D. Paolo, A. Dunsworth, L. Faoro, E. Farhi, R. Fatemi, V. S. Ferreira, L. F. Burgos, E.Forati, A. G. Fowler, B. Foxen, G. Garcia, É. Genois, W. Giang, C. Gidney, D. Gilboa,M. Giustina, R. Gosula, A. G. Dau, J. A. Gross, S. Habegger, M. C. Hamilton, M.Hansen, M. P. Harrigan, S. D. Harrington, P. Heu, M. R. Hoffmann, T. Huang, A. Huff,W. J. Huggins, L. B. Ioffe, S. V. Isakov, J. Iveland, E. Jeffrey, Z. Jiang, C. Jones, P.Juhas, D. Kafri, T. Khattar, M. Khezri, M. Kieferová, S. Kim, A. Kitaev, A. R. Klots, A.N. Korotkov, F. Kostritsa, J. M. Kreikebaum, D. Landhuis, P. Laptev, K.-M. Lau, L.Laws, J. Lee, K. W. Lee, Y. D. Lensky, B. J. Lester, A. T. Lill, W. Liu, W. P. Livingston,A. Locharla, F. D. Malone, O. Martin, S. Martin, J. R. McClean, M. McEwen, K. C.Miao, A. Mieszala, S. Montazeri, W. Mruczkiewicz, O. Naaman, M. Neeley, C. Neill, A.Nersisyan, M. Newman, J. H. Ng, A. Nguyen, M. Nguyen, M. Y. Niu, T. E. O’Brien, S.Omonije, A. Opremcak, A. Petukhov, R. Potter, L. P. Pryadko, C. Quintana, D. M.Rhodes, C. Rocque, E. Rosenberg, N. C. Rubin, N. Saei, D. Sank, K. Sankaragomathi, K.J. Satzinger, H. F. Schurkus, C. Schuster, M. J. Shearn, A. Shorter, N. Shutty, V. Shvarts,V. Sivak, J. Skruzny, W. C. Smith, R. D. Somma, G. Sterling, D. Strain, M. Szalay, D.Thor, A. Torres, G. Vidal, C. V. Heidweiller, T. White, B. W. K. Woo, C. Xing, Z. J.Yao, P. Yeh, J. Yoo, G. Young, A. Zalcman, Y. Zhang, N. Zhu, N. Zobrist, E. G. Rieffel,R. Biswas, R. Babbush, D. Bacon, J. Hilton, E. Lucero, H. Neven, A. Megrant, J. Kelly,P. Roushan, I. Aleiner, V. Smelyanskiy, K. Kechedzhi, Y. Chen, S. Boixo, Phasetransitions in random circuit sampling. Nature 634, 328–333 (2024). doi:10.1038/s41586-024-07998-6 Medline20. A. D. King, A. Nocera, M. M. Rams, J. Dziarmaga, R. Wiersema, W. Bernoudy, J.Raymond, N. Kaushal, N. Heinsdorf, R. Harris, K. Boothby, F. Altomare, M. Asad, A. J.Berkley, M. Boschnak, K. Chern, H. Christiani, S. Cibere, J. Connor, M. H. Dehn, R.Deshpande, S. Ejtemaee, P. Farre, K. Hamer, E. Hoskinson, S. Huang, M. W. Johnson, S.Kortas, E. Ladizinsky, T. Lanting, T. Lai, R. Li, A. J. R. MacDonald, G. Marsden, C. C.McGeoch, R. Molavi, T. Oh, R. Neufeld, M. Norouzpour, J. Pasvolsky, P. Poitras, G.Poulin-Lamarre, T. Prescott, M. Reis, C. Rich, M. Samani, B. Sheldan, A. Smirnov, E.Sterpka, B. Trullas Clavera, N. Tsai, M. Volkmann, A. M. Whiticar, J. D. Whittaker, W.Wilkinson, J. Yao, T. J. Yi, A. W. Sandvik, G. Alvarez, R. G. Melko, J. Carrasquilla, M.Franz, M. H. Amin, Beyond-classical computation in quantum simulation. Science 388,199–204 (2025). Medline21. S. Ebadi, T. T. Wang, H. Levine, A. Keesling, G. Semeghini, A. Omran, D. Bluvstein, R.Samajdar, H. Pichler, W. W. Ho, S. Choi, S. Sachdev, M. Greiner, V. Vuletić, M. D.Lukin, Quantum phases of matter on a 256-atom programmable quantum simulator.Nature 595, 227–232 (2021). doi:10.1038/s41586-021-03582-4 Medline22. Y. Kim, A. Eddins, S. Anand, K. X. Wei, E. van den Berg, S. Rosenblatt, H. Nayfeh, Y. Wu,M. Zaletel, K. Temme, A. Kandala, Evidence for the utility of quantum computing beforefault tolerance. Nature 618, 500–505 (2023). doi:10.1038/s41586-023-06096-3 Medline
23. F. Pan, P. Zhang, Simulation of quantum circuits using the big-batch tensor network method.Phys. Rev. Lett. 128, 030501 (2022). doi:10.1103/PhysRevLett.128.030501 Medline24. J. Gray, S. Kourtis, Hyper-optimized tensor network contraction. Quantum (Vienna) 5, 410(2021). doi:10.22331/q-2021-03-15-41025. T. Ayral, T. Louvet, Y. Zhou, C. Lambert, E. M. Stoudenmire, X. Waintal, Density-matrixrenormalization group algorithm for simulating quantum circuits with a finite fidelity.PRX Quantum 4, 020304 (2023). doi:10.1103/PRXQuantum.4.02030426. T. Schuster, C. Yin, X. Gao, N. Y. Yao, A polynomial-time classical algorithm for noisyquantum circuits. Phys. Rev. X 15, 041018 (2025). doi:10.1103/xct1-7kf227. J. Robledo-Moreno, M. Motta, H. Haas, A. Javadi-Abhari, P. Jurcevic, W. Kirby, S. Martiel,K. Sharma, S. Sharma, T. Shirakawa, I. Sitdikov, R.-Y. Sun, K. J. Sung, M. Takita, M. C.Tran, S. Yunoki, A. Mezzacapo, Chemistry beyond the scale of exact diagonalization ona quantum-centric supercomputer. Sci. Adv. 11, eadu9991 (2025).doi:10.1126/sciadv.adu9991 Medline28. J. Tindall, M. Fishman, E. M. Stoudenmire, D. Sels, Efficient tensor network simulation ofIBM’s Eagle Kicked Ising experiment. PRX Quantum 5, 010308 (2024).doi:10.1103/PRXQuantum.5.01030829. T. Begušić, J. Gray, G. K.-L. Chan, Fast and converged classical simulations of evidence forthe utility of quantum computing before fault tolerance. Sci. Adv. 10, eadk4321 (2024).doi:10.1126/sciadv.adk4321 Medline30. M. S. Rudolph, E. Fontana, Z. Holmes, L. Cincio, Classical surrogate simulation of quantumsystems with LOWESA. arXiv:2308.09109 [quant-ph] (2023).31. M. S. Rudolph, J. Tindall, Simulating and sampling from quantum circuits with 2D tensornetworks. arXiv:2507.11424 [quant-ph] (2025).32. N. Schuch, M. M. Wolf, F. Verstraete, J. I. Cirac, Computational complexity of projectedentangled pair states. Phys. Rev. Lett. 98, 140506 (2007).doi:10.1103/PhysRevLett.98.140506 Medline33. J. Haferkamp, D. Hangleiter, J. Eisert, M. Gluza, Contracting projected entangled pair statesis average-case hard. Phys. Rev. Res. 2, 013010 (2020).doi:10.1103/PhysRevResearch.2.01301034. R. Alkabetz, I. Arad, Tensor networks contraction and the belief propagation algorithm.Phys. Rev. Res. 3, 023073 (2021). doi:10.1103/PhysRevResearch.3.02307335. J. Tindall, M. Fishman, Gauging tensor networks with belief propagation. SciPost Phys. 15,222 (2023). doi:10.21468/SciPostPhys.15.6.22236. G. Vidal, Efficient simulation of one-dimensional quantum many-body systems. Phys. Rev.Lett. 93, 040502 (2004). doi:10.1103/PhysRevLett.93.040502 Medline37. H. C. Jiang, Z. Y. Weng, T. Xiang, Accurate determination of tensor network state ofquantum lattice models in two dimensions. Phys. Rev. Lett. 101, 090603 (2008).doi:10.1103/PhysRevLett.101.090603 Medline
38. M. Lubasch, J. I. Cirac, M.-C. Bañuls, Algorithms for finite projected entangled pair states.Phys. Rev. B Condens. Matter Mater. Phys. 90, 064425 (2014).doi:10.1103/PhysRevB.90.06442539. H. N. Phien, J. A. Bengua, H. D. Tuan, P. Corboz, R. Orús, Infinite projected entangled pairstates algorithm improved: Fast full update and gauge fixing. Phys. Rev. B Condens.Matter Mater. Phys. 92, 035142 (2015). doi:10.1103/PhysRevB.92.03514240. Supplementary materials are available online.41. I. A. Luchnikov, E. S. Tiunov, T. Haug, L. Aolita, Large-scale quantum annealing simulationwith tensor networks and belief propagation. arXiv:2409.12240 [quant-ph] (2024).42. F. Verstraete, J. I. Cirac, Renormalization algorithms for quantum-many body systems in twoand higher dimensions. arXiv:cond-mat/0407066 [cond-mat.str-el] (2004).43. G. Evenbly, N. Pancotti, A. Milsted, J. Gray, G. K.-L. Chan, Loop series expansions fortensor networks. arXiv:2409.03108 [quant-ph] (2024).44. D. B. Johnson, Finding all the elementary circuits of a directed graph. SIAM J. Comput. 4,77–84 (1975). doi:10.1137/020400745. J. Fairbanks, M. Besancon, S. Simon, J. Hoffiman, N. Eubank, S. Karpinski,“JuliaGraphs/Graphs.jl: An optimized graphs package for the Julia programminglanguage” (2021); https://github.com/JuliaGraphs/Graphs.jl/.46. J. Haegeman, J. I. Cirac, T. J. Osborne, I. Pižorn, H. Verschelde, F. Verstraete, Time-dependent variational principle for quantum lattices. Phys. Rev. Lett. 107, 070601 (2011).doi:10.1103/PhysRevLett.107.070601 Medline47. A. D. King, J. Raymond, T. Lanting, R. Harris, A. Zucca, F. Altomare, A. J. Berkley, K.Boothby, S. Ejtemaee, C. Enderud, E. Hoskinson, S. Huang, E. Ladizinsky, A. J. R.MacDonald, G. Marsden, R. Molavi, T. Oh, G. Poulin-Lamarre, M. Reis, C. Rich, Y.Sato, N. Tsai, M. Volkmann, J. D. Whittaker, J. Yao, A. W. Sandvik, M. H. Amin,Quantum critical dynamics in a 5,000-qubit programmable spin glass. Nature 617, 61–66(2023). doi:10.1038/s41586-023-05867-2 Medline48. K. Trachenko, A. Zaccone, Slow stretched-exponential and fast compressed-exponentialrelaxation from local event dynamics. J. Phys. Condens. Matter 33, 315101 (2021).doi:10.1088/1361-648X/ac04cd Medline49. Z. W. Wu, W. Kob, W.-H. Wang, L. Xu, Stretched and compressed exponentials in therelaxation dynamics of a metallic glass-forming melt. Nat. Commun. 9, 5334 (2018).doi:10.1038/s41467-018-07759-w Medline50. M. Bernaschi, I. González-Adalid Pemartín, V. Martín-Mayor, G. Parisi, The quantumtransition of the two-dimensional Ising spin glass. Nature 631, 749–754 (2024).doi:10.1038/s41586-024-07647-y Medline51. Y. Kato, S. Onoda, Numerical evidence of quantum melting of spin ice: Quantum-to-classical crossover. Phys. Rev. Lett. 115, 077202 (2015).doi:10.1103/PhysRevLett.115.077202 Medline
52.J. Tindall, M. Rudolph, “TensorNetworkQuantumSimulator.jl” (2025);https://github.com/JoeyT1994/TensorNetworkQuantumSimulator.53.J. Tindall, A. Mello, M. Fishman, E. M. Stoudenmire, D. Sels, Data for: Dynamics ofdisordered quantum systems with two- and three-dimensional tensor networks, Dryad(2025); https://doi.org/10.5061/dryad.7d7wm388g.54.S. Sahu, B. Swingle, Efficient tensor network simulation of quantum many-body physics onsparse graphs. arXiv:2206.04701 [quant-ph] (2022).55.S. S. Jahromi, R. Orús, Universal tensor-network algorithm for any infinite lattice. Phys. Rev.B 99, 195105 (2019). doi:10.1103/PhysRevB.99.19510556.P. Pippan, S. R. White, H. G. Evertz, Efficient matrix-product state method for periodicboundary conditions. Phys. Rev. B Condens. Matter Mater. Phys. 81, 081103 (2010).doi:10.1103/PhysRevB.81.08110357.C. Guo, D. Poletti, I. Arad, Block belief propagation algorithm for two-dimensional tensornetworks. Phys. Rev. B 108, 125111 (2023). doi:10.1103/PhysRevB.108.12511158.G. Vidal, Efficient classical simulation of slightly entangled quantum computations. Phys.Rev. Lett. 91, 147902 (2003). doi:10.1103/PhysRevLett.91.147902 Medline59.Y. Zhou, E. M. Stoudenmire, X. Waintal, What limits the simulation of quantum computers?Phys. Rev. X 10, 041038 (2020). doi:10.1103/PhysRevX.10.04103860.S.-B. B. Lee, H. R. Choi, D. D. Ohm, S.-S. B. Lee, Scalable projected entangled-pair staterepresentation of random quantum circuit states. Phys. Rev. Res. 7, 033252 (2025).doi:10.1103/rzgm-cywf61.L. Mauron, G. Carleo, Challenging the quantum advantage frontier with large-scale classicalsimulations of annealing dynamics. arXiv:2503.08247 [quant-ph] (2025).62.J. Bezanson, A. Edelman, S. Karpinski, V. B. Shah, Julia: A Fresh Approach to NumericalComputing. SIAM Rev. 59, 65–98 (2017). doi:10.1137/14100067163.M. Fishman, S. R. White, E. M. Stoudenmire, The ITensor Software Library for tensornetwork calculations. arXiv:2007.14822 [cs.MS] (2022).
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [1]: X. Mi et al. — Time-crystalline eigenstate order on a quantum processor (Nature 601, 531-536, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Time-crystalline eigenstate order on a quantum processor
URL: https://doi.org/10.1038/s41586-021-04257-w
Time-crystalline eigenstate order on a quantum processor | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
articles
article
Time-crystalline eigenstate order on a quantum processor
Download PDF
Download PDF
Article
Open access
Published: 30 November 2021
Time-crystalline eigenstate order on a quantum processor
Xiao Mi  ORCID: orcid.org/0000-0003-0507-0211 1 na1 ,
Matteo Ippoliti 2 na1 ,
Chris Quintana 1 ,
Ami Greene 1 ,
Zijun Chen 1 ,
Jonathan Gross 1 ,
Frank Arute 1 ,
Kunal Arya 1 ,
Juan Atalaya 1 ,
Ryan Babbush 1 ,
Joseph C. Bardin  ORCID: orcid.org/0000-0002-6523-6730 1 , 3 ,
Joao Basso  ORCID: orcid.org/0000-0001-5547-691X 1 ,
Andreas Bengtsson 1 ,
Alexander Bilmes 1 ,
Alexandre Bourassa 1 , 4 ,
Leon Brill 1 ,
Michael Broughton 1 ,
Bob B. Buckley 1 ,
David A. Buell 1 ,
Brian Burkett  ORCID: orcid.org/0000-0001-8474-6317 1 ,
Nicholas Bushnell 1 ,
Benjamin Chiaro 1 ,
Roberto Collins 1 ,
William Courtney 1 ,
Dripto Debroy 1 ,
Sean Demura  ORCID: orcid.org/0000-0003-3727-7380 1 ,
Alan R. Derk 1 ,
Andrew Dunsworth 1 ,
Daniel Eppens  ORCID: orcid.org/0000-0001-7134-5733 1 ,
Catherine Erickson 1 ,
Edward Farhi 1 ,
Austin G. Fowler 1 ,
Brooks Foxen 1 ,
Craig Gidney 1 ,
Marissa Giustina 1 ,
Matthew P. Harrigan  ORCID: orcid.org/0000-0001-9412-0553 1 ,
Sean D. Harrington  ORCID: orcid.org/0000-0003-0521-8378 1 ,
Jeremy Hilton 1 ,
Alan Ho 1 ,
Sabrina Hong 1 ,
Trent Huang 1 ,
Ashley Huff 1 ,
William J. Huggins  ORCID: orcid.org/0000-0003-2735-1380 1 ,
L. B. Ioffe 1 ,
Sergei V. Isakov 1 ,
Justin Iveland 1 ,
Evan Jeffrey 1 ,
Zhang Jiang 1 ,
Cody Jones 1 ,
Dvir Kafri 1 ,
Tanuj Khattar 1 ,
Seon Kim 1 ,
Alexei Kitaev 1 ,
Paul V. Klimov 1 ,
Alexander N. Korotkov 1 , 5 ,
Fedor Kostritsa 1 ,
David Landhuis  ORCID: orcid.org/0000-0001-9804-2185 1 ,
Pavel Laptev 1 ,
Joonho Lee 1 , 6 ,
Kenny Lee 1 ,
Aditya Locharla 1 ,
Erik Lucero 1 ,
Orion Martin 1 ,
Jarrod R. McClean  ORCID: orcid.org/0000-0002-2809-0509 1 ,
Trevor McCourt 1 ,
Matt McEwen  ORCID: orcid.org/0000-0002-9544-141X 1 , 7 ,
Kevin C. Miao 1 ,
Masoud Mohseni 1 ,
Shirin Montazeri  ORCID: orcid.org/0000-0002-7124-4585 1 ,
Wojciech Mruczkiewicz  ORCID: orcid.org/0000-0002-8497-6363 1 ,
Ofer Naaman  ORCID: orcid.org/0000-0002-7760-9186 1 ,
Matthew Neeley  ORCID: orcid.org/0000-0002-5548-0051 1 ,
Charles Neill  ORCID: orcid.org/0000-0001-8509-9836 1 ,
Michael Newman 1 ,
Murphy Yuezhen Niu 1 ,
Thomas E. O’Brien 1 ,
Alex Opremcak 1 ,
Eric Ostby 1 ,
Balint Pato 1 ,
Andre Petukhov 1 ,
Nicholas C. Rubin 1 ,
Daniel Sank 1 ,
Kevin J. Satzinger  ORCID: orcid.org/0000-0001-5865-0813 1 ,
Vladimir Shvarts 1 ,
Yuan Su 1 ,
Doug Strain 1 ,
Marco Szalay 1 ,
Matthew D. Trevithick 1 ,
Benjamin Villalonga 1 ,
Theodore White 1 ,
Z. Jamie Yao 1 ,
Ping Yeh  ORCID: orcid.org/0000-0003-0837-1028 1 ,
Juhwan Yoo 1 ,
Adam Zalcman  ORCID: orcid.org/0000-0002-2585-2424 1 ,
Hartmut Neven 1 ,
Sergio Boixo  ORCID: orcid.org/0000-0002-1090-7584 1 ,
Vadim Smelyanskiy 1 ,
Anthony Megrant  ORCID: orcid.org/0000-0002-6371-6140 1 ,
Julian Kelly  ORCID: orcid.org/0000-0002-2596-2121 1 ,
Yu Chen 1 ,
S. L. Sondhi 8 , 9 ,
Roderich Moessner 10 ,
Kostyantyn Kechedzhi 1 ,
Vedika Khemani  ORCID: orcid.org/0000-0003-2653-0555 2 &
…
Pedram Roushan 1  Show authors
Nature
volume 601 , pages 531–536 ( 2022 ) Cite this article
98k Accesses
319 Citations
1154 Altmetric
Metrics details
Abstract
Quantum many-body systems display rich phase structure in their low-temperature equilibrium states 1 . However, much of nature is not in thermal equilibrium. Remarkably, it was recently predicted that out-of-equilibrium systems can exhibit novel dynamical phases 2 , 3 , 4 , 5 , 6 , 7 , 8 that may otherwise be forbidden by equilibrium thermodynamics, a paradigmatic example being the discrete time crystal (DTC) 7 , 9 , 10 , 11 , 12 , 13 , 14 , 15 . Concretely, dynamical phases can be defined in periodically driven many-body-localized (MBL) systems via the concept of eigenstate order 7 , 16 , 17 . In eigenstate-ordered MBL phases, the entire many-body spectrum exhibits quantum correlations and long-range order, with characteristic signatures in late-time dynamics from all initial states. It is, however, challenging to experimentally distinguish such stable phases from transient phenomena, or from regimes in which the dynamics of a few select states can mask typical behaviour. Here we implement tunable controlled-phase (CPHASE) gates on an array of superconducting qubits to experimentally observe an MBL-DTC and demonstrate its characteristic spatiotemporal response for generic initial states 7 , 9 , 10 . Our work employs a time-reversal protocol to quantify the impact of external decoherence, and leverages quantum typicality to circumvent the exponential cost of densely sampling the eigenspectrum. Furthermore, we locate the phase transition out of the DTC with an experimental finite-size analysis. These results establish a scalable approach to studying non-equilibrium phases of matter on quantum processors.
Similar content being viewed by others
Many-body localization in the infinite-interaction limit and the discontinuous eigenstate phase transition
Article  Open access  03 December 2022
Equilibration of topological defects near the deconfined quantum multicritical point
Article  Open access  10 April 2025
All-optical dissipative discrete time crystals
Article  Open access  14 February 2022
Main
In an equilibrium setting, quantum phases of matter are classified by long-range order or broken symmetries in low-temperature states (Fig. 1a ). The existence of ordered phases in periodically driven (Floquet) systems, on the other hand, is counterintuitive: as energy is not conserved, one expects thermalization to a featureless maximum-entropy state that is incompatible with quantum order. However, this heat death is averted in the presence of many-body localization, where strong disorder causes the emergence of an extensive number of local conservation laws that prevent thermalization 18 , 19 , 20 , 21 , 22 , 23 , making it possible to stabilize intrinsically dynamical phases 7 .
Fig. 1: Order in eigenstates.
The alternative text for this image may have been generated using AI.  Full size image
a , Equilibrium phases are characterized by long-range order in low-energy eigenstates of time-independent Hamiltonians (for example, an Ising ferromagnet with a pair of degenerate ground states that resemble ‘Schrödinger cats’ of polarized states). b , Thermalizing Floquet systems typically have no ordered states in the spectrum. c , In MBL Floquet systems, every eigenstate can show order. In MBL-DTC, every eigenstate resembles a long-range ordered ‘Schrödinger cat’ of a random configuration of spins and its inversion, with even/odd superpositions split by π.
Dynamics in a Floquet system is governed by a unitary time evolution operator, whose eigenvalues lie on the unit circle. While the entire Floquet spectrum is featureless in a thermalizing phase (Fig. 1b ), an MBL Floquet phase can have an order parameter associated with each eigenstate. As an example, in the spatiotemporally ordered MBL-DTC, the spectrum has a distinctive pattern of pairing between long-range ordered ‘Schrödinger cat’ eigenstates whose eigenvalues are separated by an angle π (refs.  7 , 9 , 10 ; Fig. 1c ). This pairing manifests as a stable subharmonic response, wherein local observables show period-doubled oscillations that spontaneously break the discrete time translation symmetry of the drive for infinitely long times. The unique combination of spatial long-range order and time translation symmetry breaking in an isolated dissipation-free quantum many-body system is the hallmark of the MBL-DTC.
Experimentally observing a non-equilibrium phase such as the MBL-DTC is a challenge owing to limited programmability, coherence and size of noisy intermediate-scale quantum hardware. Subharmonic response, by itself, is not a unique attribute of the MBL-DTC; rather, it is a feature of many dynamical phenomena whose study has a rich history 24 (also Ch. 8 in ref.  12 ). Most recently, interesting DTC-like dynamical signatures have been observed in a range of quantum platforms from trapped ions 25 to nitrogen vacancy centres 26 to NMR spins 27 , 28 . However, each of these platforms lacks one or more necessary conditions for stabilizing an MBL-DTC 12 , 29 , either owing to an absence of the requisite type of disorder 25 , 27 or owing to the interactions being too long ranged 26 , 27 , 28 . The observed signatures, instead, have been shown to arise from slow thermalization 26 , 30 , effectively mean-field dynamics 28 , or prethermal dynamics from special initial states 12 , 29 , 31 , 32 , and are separated from the MBL-DTC by a spectral phase transition where eigenstate order disappears. Thus, despite the recent progress, observing an MBL-DTC remains an outstanding challenge 12 , 29 .
Here we perform the following necessary benchmarks for experimentally establishing an eigenstate-ordered non-equilibrium phase of matter: drive parameters are varied to demonstrate stability of the phase in an extended parameter region and across disorder realizations; the limitations of finite size and finite coherence time are addressed, respectively, by varying system size and verifying that any decay of the subharmonic response is consistent with purely extrinsic decoherence assessed in an independent experiment; the existence of spatiotemporal order across the entire spectrum is established. The flexibility of our quantum processor, combined with the scalable experimental protocols devised in the following, allows us to fulfil these criteria and observe an MBL-DTC.
The experiment is conducted on an open-ended, linear chain of \(L=20\) superconducting transmon qubits ( \({Q}_{1}\) to \({Q}_{20}\) ) that are isolated from a two-dimensional grid. We drive the qubits via a time-periodic (Floquet) circuit \({\hat{U}}_{{\rm{F}}}^{t}\) with \(t\) identical cycles (Fig. 2a ) of \({\hat{U}}_{{\rm{F}}}\) :
$${\hat{U}}_{{\rm{F}}}=\mathop{\underbrace{{{\rm{e}}}^{-\frac{i}{2}\sum _{i}{h}_{i}{\hat{Z}}_{i}}}}\limits_{{\rm{longitudinal}}\,{\rm{fields}}}\,\mathop{\underbrace{{{\rm{e}}}^{-\frac{i}{4}\sum _{i}{\varphi }_{i}{\hat{Z}}_{i}{\hat{Z}}_{i+1}}}}\limits_{{\rm{Ising}}\,{\rm{interaction}}}\,\mathop{\underbrace{{{\rm{e}}}^{-\frac{i}{2}{\rm{\pi }}g\sum _{i}{\hat{X}}_{i}}}}\limits_{x\,{\rm{rotation}}\,{\rm{by}}\,{\rm{\pi }}g}$$
(1)
where \({\hat{X}}_{i}\) and \({\hat{Z}}_{i}\) are Pauli operators. Each angle \({\varphi }_{i}\) \(({h}_{i})\) is sampled randomly from \([-1.5{\rm{\pi }},-0.5{\rm{\pi }}]\) \(([-{\rm{\pi }},{\rm{\pi }}])\) for every realization of the circuit. Overall, \({\hat{U}}_{{\rm{F}}}\) implements an interacting Ising model that is periodically ‘kicked’ by a transverse pulse that rotates all qubits by \({\rm{\pi }}g\) about the \(x\)  axis. In this work, \(g\) is tuned within the range \([0.5,\,1.0]\) to explore the DTC phase and its transition into a thermal phase. At \(g=1\) , the model implements a \({\rm{\pi }}\) pulse that exactly flips all qubits (in the \(z\)  basis) and returns them to the initial state over two periods. A key signature of the DTC is the presence of robust period doubling, (that is, extending over a finite extent in parameter space, even as \(g\) is tuned away from \(1\) , and for all initial states). Strong Ising interactions, which produce long-range spatial order, are essential for this robustness 7 , 10 . This is in contrast to a system of decoupled qubits \((\varphi =0)\) that rotate by a continuously varying angle \({\rm{\pi }}g\) every period instead of being locked at period doubling. Prior theoretical work 29 has shown that model ( 1 ) is expect the range \(g > {g}_{{\rm{c}}}\) , and transition to a thermal phase at a critical value \({g}_{{\rm{c}}}\approx 0.84\) .
Fig. 2: Observing an MBL-DTC.
The alternative text for this image may have been generated using AI.  Full size image
a , The experimental circuit composed of \(t\) identical cycles of the unitary \({\hat{U}}_{{\rm{F}}}\) . The local polarization of each qubit, ⟨ \(\hat{Z}(t)\) ⟩ , is measured at the end. In the following panels, we investigate a number of disorder instances each with a different random bit-string initial state. b , Experimental values of ⟨ \(\hat{Z}(t)\) ⟩ measured at Q 11 . Data are shown for five representative circuit instances deep in the thermal ( g  = 0.60; left... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [2]: M. Iqbal et al. — Topological order from measurements and feed-forward on a trapped ion quantum computer (Commun. Phys. 7, 205, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Topological order from measurements and feed-forward on a trapped ion quantum computer
URL: https://doi.org/10.1038/s42005-024-01698-3
Topological order from measurements and feed-forward on a trapped ion quantum computer | Communications Physics
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
Reviews & Analysis
News & Comment
Collections
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Aims & Scope
Journal Information
Open Access Fees and Funding
Journal Metrics
Editors
Editorial Board
Calls for Papers
Editorial Values Statement
Editorial policies
Referees
Conferences
Contact
Publish with us
Publish with us
For authors
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
communications physics
articles
article
Topological order from measurements and feed-forward on a trapped ion quantum computer
Download PDF
Download PDF
Article
Open access
Published: 25 June 2024
Topological order from measurements and feed-forward on a trapped ion quantum computer
Mohsin Iqbal 1 ,
Nathanan Tantivasadakarn  ORCID: orcid.org/0000-0001-5295-2124 2 ,
Thomas M. Gatterman 3 ,
Justin A. Gerber  ORCID: orcid.org/0000-0002-3140-4935 3 ,
Kevin Gilmore  ORCID: orcid.org/0000-0002-8230-7000 3 ,
Dan Gresh 3 ,
Aaron Hankin 3 ,
Nathan Hewitt 3 ,
Chandler V. Horst 3 ,
Mitchell Matheny 3 ,
Tanner Mengle 3 ,
Brian Neyenhuis 3 ,
Ashvin Vishwanath  ORCID: orcid.org/0000-0002-6306-2263 4 ,
Michael Foss-Feig 3 ,
Ruben Verresen  ORCID: orcid.org/0000-0002-0385-7363 4 &
…
Henrik Dreyer  ORCID: orcid.org/0000-0002-1480-6406 1  Show authors
Communications Physics
volume 7 , Article number: 205 ( 2024 ) Cite this article
7606 Accesses
80 Citations
16 Altmetric
Metrics details
Abstract
Quantum systems evolve in time in one of two ways: through the Schrödinger equation or wavefunction collapse. So far, deterministic control of quantum many-body systems in the lab has focused on the former, due to the probabilistic nature of measurements. This imposes serious limitations: preparing long-range entangled states, for example, requires extensive circuit depth if restricted to unitary dynamics. In this work, we use mid-circuit measurement and feed-forward to implement deterministic non-unitary dynamics on Quantinuum’s H1 programmable ion-trap quantum computer. Enabled by these capabilities, we demonstrate a constant-depth procedure for creating a toric code ground state in real-time. In addition to reaching high stabilizer fidelities, we create a non-Abelian defect whose presence is confirmed by transmuting anyons via braiding. This work clears the way towards creating complex topological orders in the lab and exploring deterministic non-unitary dynamics via measurement and feed-forward.
Similar content being viewed by others
Non-Abelian braiding of graph vertices in a superconducting processor
Article  Open access  11 May 2023
Dynamical topology of chiral and nonreciprocal state transfers in a non-Hermitian quantum system
Article  Open access  07 March 2025
Non-Abelian topological order and anyons on a trapped-ion processor
Article
14 February 2024
Introduction
Long-range entangled quantum states are central to different branches of modern physics. They appear as error correction codes in quantum information 1 , emerge as topologically ordered phases in condensed matter, and play a role in lattice gauge theories of high energy physics 2 . Quantum computers and simulators provide new means of exploring such states and tackling their open questions 3 . A number of quantum algorithms have been designed for these devices, many of which can be decomposed into two steps: a state preparation step and a processing step, in which e.g., unitary dynamics is applied 4 , 5 . For short-range entangled states, the adiabatic theorem guarantees an (approximate) encoding circuit whose depth is independent of the system size. In contrast, long-range entangled states require circuits of extensive depth for their preparation 6 due to finite Lieb-Robinson velocities, which bound the spread of correlation in unitary dynamics 7 . The stakes are further increased by emerging evidence that scalable digital quantum simulation of (short- or long-range entangled) fermionic systems requires long-range entangled state preparation 8 , 9 , 10 , 11 . This situation is problematic: coherence time is a precious resource for near-term quantum computers and simulators and it should not be exhausted during state preparation.
Fortunately, there is a loophole to these constraints imposed by unitarity and locality. Introducing measurement during state preparation violates the assumption of unitarity, such that correlations can be generated instantaneously across the whole system. However, since measurements are random, deterministic state preparation requires conditional quantum gates to be applied based on the outcome of the mid-circuit measurement—a capability known as feed-forward. In effect, measurement allows one to push all the non-constant depth into the classical channel, which is effectively ‘free’ due to the large speed of light and the comparably much larger cost of quantum gates.
The deterministic preparation of an excitation-free state is important for the quantum simulation of topologically ordered systems with non-error corrected devices, but is also a common prerequisite for quantum error correction protocols that realize universal gate sets 12 . Moreover, feed-forward is indispensable for the efficient preparation of certain non-Abelian states involving multiple layers of measurement 13 , 14 , 15 , 16 , 17 , 18 .
In summary, to prepare long-range entangled states deterministically and in constant (quantum) depth, one requires feed-forward, mid-circuit measurement and entangling gates, all with high fidelity and fast compared to the coherence time of the platform.
While individual elements of this triad have been demonstrated 10 , 19 , 20 , 21 , 22 , 23 , 24 , 25 , 26 , 27 , 28 , 29 , combining all of these ingredients in one platform to deterministically create long-range entangled states has proven elusive since the inception of this idea more than a decade ago 10 , 30 , 31 .
Here, we demonstrate the deterministic, high-fidelity preparation of long-range entangled quantum states using a protocol with constant depth (as conceptually represented in Fig. 1 ), using Quantinuum’s H1 programmable ion-trap quantum computer 32 . The quantum computer contains 20 qubits encoded in two hyperfine states of 171 Yb + ions and is based on the quantum charge-coupled device architecture 33 , 34 . Crucially, the qubit ions in this architecture are mobile. While cross-talk can be a formidable challenge for mid-circuit measurement-based protocols, we will see that the ability to move qubits far apart during mid-circuit measurements transforms cross-talk into a negligible source of error (compared to the two-qubit gate error). To certify this, we measure fidelities and entanglement entropies of a “toric code” ground state on periodic boundaries. A remarkable property of this entangled state is that it admits localized deformations behaving like emergent particles which are neither bosonic or fermionic 35 . These are called Abelian anyons, due to their exchange statistics being described by commuting phase factors. In addition, we also create the toric code state with two lattice defects, called non-Abelian Ising defects 36 , 37 which we use to demonstrate anyon transmutation and braiding interferometry.
Fig. 1: Schematic representation of the toric code ground state from wavefunction collapse.
The alternative text for this image may have been generated using AI.  Full size image
We initialize a system of trapped-ion qubits (encoded in hyperfine states of 171 Yb + ) in a product state where all stabilizers B p  =  Z ⊗ 4  = 1 (blue) are satisfied. We measure A p  =  X ⊗ 4 on every other plaquette, randomly leading to A p  = 1 (gold) or A p  = −1 (black, denoting an e -anyon). We use feed-forward to pair up and annihilate the e -anyons in real time, deterministically producing a clean toric code wavefunction using a finite-depth circuit and nonlocal classical processing.
Results
Toric code preparation with feed-forward
We target the ground state of Kitaev’s toric code Hamiltonian 35 . For notational convenience, we represent the qubits as living on the vertices of a square lattice 38 , described by
$$H=-\sum\limits_{p\in {{{{{{{\mathcal{A}}}}}}}}}{A}_{p}-\sum\limits_{p\in {{{{{{{\mathcal{B}}}}}}}}}{B}_{p},$$
(1)
where the operators A  =  X ⊗ 4 and B  =  Z ⊗ 4 are products of Pauli operators that act on the four-qubit plaquettes of the square lattice and \({{{{{{{\mathcal{A}}}}}}}}\) and \({{{{{{{\mathcal{B}}}}}}}}\) denote the sets of X -type and Z -type plaquettes (cf. Fig. 2 a). In the ground state, A p  =  B p  = 1 for all plaquettes. Any excited plaquette corresponds to one of the aforementioned anyons: A p  = −1 ( B p  = −1) is typically called an e -anyon ( m -anyon). Enabled by the effective all-to-all connectivity of the ion-trap, we implement periodic boundary conditions.
Fig. 2: Toric code ground state preparation.
The alternative text for this image may have been generated using AI.  Full size image
a Definition of the stabilizer operators (1) on the unraveled torus. Numbers denote the different ions and specify the boundary conditions. Plaquettes are labeled by their upper left qubits. The state comprises 4 × 4 qubits and periodic boundary conditions. b Logical Z string operators are Z hori  =  Z 0 Z 1 Z 2 Z 3 ( Z vert  =  Z 0 Z 4 Z 8 Z 12 ) and their vertical (horizontal) translations. \(\overline{{Z}^{{{{{{{{\rm{hori}}}}}}}}}}\) and \(\overline{{Z}^{{{{{{{{\rm{vert}}}}}}}}}}\) denote expectation values of the logical string operators, averaged over translations. c Expectation values of the stabilizers obtained from collapsing the wavefunction in the single-qubit X - and Z -bases. Error bars denote one standard error on the mean. d Entanglement entropy measurement on 2 × 2 (top) and 2 × 3 regions (bottom). Colored bars denote \({S}_{X}^{(2)}\) for different subsystems of a region with shapes as shown in the inset and γ is defined in Eq. ( 2 ). Dashed lines show exact values. Error bars denote one standard error on the mean. The maximum error in the estimates of \({S}_{X}^{(2)}\) for 2 × 2 (2 × 3) regions is ±0.056 (±0.091). Hatched white bars denote average topological entanglement entropies.
This Hamiltonian realizes \({{\mathbb{Z}}}_{2}\) topological order 39 , 40 , with four ground states—while these all satisfy 〈 A p 〉 = 〈 B p 〉 = 1, they can be distinguished by logical string operators that wrap around the torus.
To be specific, we target the unique ground state with logical expectation values \(\left\langle {Z}^{{{{{{{{\rm{hori}}}}}}}}}\right\rangle =\left\langle {Z}^{{{{{{{{\rm{vert}}}}}}}}}\right\rangle =1\) , as defined in Fig. 2 . The expectation value of the string and commuting plaquette operators certify the quality of the state preparation, with an average of +1 indicating perfect ground state preparation.
To prepare the ground state deterministically and in constant depth, we use a three-step procedure: First, all ions are initialized in \(\left\vert 0\right\rangle\) , such that \(\langle {B}_{p}\rangle =1\) . Second, we measure the A p operator on all odd plaquettes, effectively implementing the projectors \(({\mathbb{I}}\pm {X}^{\otimes 4})/2\) with equal probability. This can be done with or without ancillae and we choose to demonstrate both strategies, preparing plaquettes 4, 6, 12, and 14 with an ancilla-free procedure while the measurements on plaquettes 1, 3, 9, and 11 are performed with one ancilla each (Methods, see also Fig. 2 for our labeling convention). Finally, we apply conditional single-qubit Z gates to flip all plaquettes at which A p  = −1 has been measured, which one can physically interpret as pairing up and annihilating the e -anyons. To find the location at which the conditional Z -gates must be applied, we use a simple lookup-table decoder (Methods).
The topology of the toric code requires anyonic defects to come in pairs; however, errors in the syndrome measurement process can result in measuring an odd number of excitations. Therefore, we employ a state preparation strategy—common to many quantum error correction or repeat-until-success protocols—in which odd defect numbers are heralded and the associated data is discarded. We note that unlike post-selection on each plaquette individually, the fraction of retained data is not exponentially small in the system size; thus we can view the discarding of erroneous runs as a scalable part of the state preparation procedure itself, and we report fidelities constructed from the retained data in the main text (see Supplementary Fig. 3 for the raw data).
We test the quality of the state prepared in the above manner in two ways. First, we measure the expectation values of the X ⊗ 4 and Z ⊗ 4 stabilizers by performing destructive single-qubit measurements in the X - and Z -basis. Their average plays the role of the energy density of ( 1 ) and is closely related to the overlap with the ground state manifold 41 . We report an energy density of −0.929 ± 0.004, indicating that a ground state has been prepared with high fidelity. The expectation value of the two logical string operators averaged over translations is close to 1 and equal up to statistical fluctuations, \(\overline{{... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [3]: A. Keesling et al. — Quantum Kibble-Zurek mechanism and critical dynamics on a programmable Rydberg simulator (Nature 568, 207-211, 2019)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Quantum Kibble–Zurek mechanism and critical dynamics on a programmable Rydberg simulator
URL: https://doi.org/10.1038/s41586-019-1070-1
Quantum Kibble–Zurek mechanism and critical dynamics on a programmable Rydberg simulator | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Subscribe
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Subscribe
Sign up for alerts
RSS feed
nature
letters
article
Letter
Published: 01 April 2019
Quantum Kibble–Zurek mechanism and critical dynamics on a programmable Rydberg simulator
Alexander Keesling 1 ,
Ahmed Omran 1 ,
Harry Levine 1 ,
Hannes Bernien 1 ,
Hannes Pichler 1 , 2 ,
Soonwon Choi 1 ,
Rhine Samajdar 1 ,
Sylvain Schwartz 3 ,
Pietro Silvi 4 , 5 ,
Subir Sachdev 1 ,
Peter Zoller 4 , 5 ,
Manuel Endres 6 ,
Markus Greiner 1 ,
Vladan Vuletić 7 &
…
Mikhail D. Lukin 1  Show authors
Nature
volume 568 , pages 207–211 ( 2019 ) Cite this article
19k Accesses
514 Citations
104 Altmetric
Metrics details
Abstract
Quantum phase transitions (QPTs) involve transformations between different states of matter that are driven by quantum fluctuations 1 . These fluctuations play a dominant part in the quantum critical region surrounding the transition point, where the dynamics is governed by the universal properties associated with the QPT. Although time-dependent phenomena associated with classical, thermally driven phase transitions have been extensively studied in systems ranging from the early Universe to Bose–Einstein condensates 2 , 3 , 4 , 5 , understanding critical real-time dynamics in isolated, non-equilibrium quantum systems remains a challenge 6 . Here we use a Rydberg atom quantum simulator with programmable interactions to study the quantum critical dynamics associated with several distinct QPTs. By studying the growth of spatial correlations when crossing the QPT, we experimentally verify the quantum Kibble–Zurek mechanism (QKZM) 7 , 8 , 9 for an Ising-type QPT, explore scaling universality and observe corrections beyond QKZM predictions. This approach is subsequently used to measure the critical exponents associated with chiral clock models 10 , 11 , providing new insights into exotic systems that were not previously understood and opening the door to precision studies of critical phenomena, simulations of lattice gauge theories 12 , 13 and applications to quantum optimization 14 , 15 .
Access through your institution
Buy or subscribe
This is a preview of subscription content, access via your institution
Access options
Access through your institution
Access Nature and 54 other Nature Portfolio journals
Get Nature+, our best-value online-access subscription
$32.99 / 30 days
cancel any time
Learn more
Subscribe to this journal
Receive 52 print issues and online access
$199.00 per year
only $3.83 per issue
Learn more
Buy this article
Purchase on SpringerLink
Instant access to the full article PDF.
USD 39.95
Prices may be subject to local taxes which are calculated during checkout
Additional access options:
Log in
Learn about institutional subscriptions
Read our FAQs
Contact customer support
Fig. 1: Quantum Kibble–Zurek mechanism and phase diagram.
The alternative text for this image may have been generated using AI.
Fig. 2: QKZM for a QPT into the \({{\mathbb{Z}}}_{2}\) -ordered phase.
The alternative text for this image may have been generated using AI.
Fig. 3: Universality of spatial correlations.
The alternative text for this image may have been generated using AI.
Fig. 4: Power-law scaling for different interactions.
The alternative text for this image may have been generated using AI.
Similar content being viewed by others
Characterizing a non-equilibrium phase transition on a quantum computer
Article
11 September 2023
Tricritical Kibble-Zurek scaling in Rydberg atom ladders
Article  Open access  26 November 2025
Quantum quench dynamics of geometrically frustrated Ising models
Article  Open access  30 December 2024
Data availability
The data that support the findings of this study are available from the corresponding author on reasonable request.
References
Sachdev, S. Quantum Phase Transitions 2nd edn (Cambridge Univ. Press, Cambridge, 2009).
MATH
Google Scholar
Kibble, T. W. B. Topology of cosmic domains and strings. J. Phys. Math. Gen . 9 , 1387–1398 (1976).
Article  ADS
Google Scholar
Zurek, W. H. Cosmological experiments in superfluid helium? Nature 317 , 505–508 (1985).
Article  ADS  CAS
Google Scholar
del Campo, A. & Zurek, W. H. Universality of phase transition dynamics: topological defects from symmetry breaking. Int. J. Mod. Phys. A 29 , 1430018 (2014).
Article
Google Scholar
Navon, N., Gaunt, A. L., Smith, R. P. & Hadzibabic, Z. Critical dynamics of spontaneous symmetry breaking in a homogenous Bose gas. Science 347 , 167–170 (2015).
Article  ADS  CAS
Google Scholar
Polkovnikov, A., Sengupta, K., Silva, A. & Vengalattore, M. Nonequilibrium dynamics of closed interacting quantum systems. Rev. Mod. Phys . 83 , 863–883 (2011).
Article  ADS
Google Scholar
Polkovnikov, A. Universal adiabatic dynamics in the vicinity of a quantum critical point. Phys. Rev. B 72 , 161201 (2005).
Article  ADS
Google Scholar
Zurek, W. H., Dorner, U. & Zoller, P. Dynamics of a quantum phase transition. Phys. Rev. Lett . 95 , 105701 (2005).
Article  ADS
Google Scholar
Dziarmaga, J. Dynamics of a quantum phase transition: exact solution of the quantum ising model. Phys. Rev. Lett . 95 , 245701 (2005).
Article  ADS
Google Scholar
Huse, D. A. & Fisher, M. E. Domain walls and the melting of commensurate surface phases. Phys. Rev. Lett . 49 , 793–796 (1982).
Article  ADS  CAS
Google Scholar
Ostlund, S. Incommensurate and commensurate phases in asymmetric clock models. Phys. Rev. B 24 , 398–405 (1981).
Article  ADS  MathSciNet  CAS
Google Scholar
Tagliacozzo, L., Celi, A., Orland, P., Mitchel, M. W. & Lewenstein, M. Simulation of non-Abelian gauge theories with optical lattices. Nat. Commun . 4 , 2615 (2013).
Article  ADS  CAS
Google Scholar
Weimer, H., Müller, M., Lesanovsky, I., Zoller, P. & Büchler, H. P. A Rydberg quantum simulator. Nat. Phys . 6 , 382–388 (2010).
Article  CAS
Google Scholar
Farhi, E., Goldstone, J., Gutmann, S. & Spiser, M. Quantum computation by adiabatic evolution. Preprint at https://arxiv.org/abs/quant-ph/0001106 (2000).
Gardas, B., Dziarmaga, J., Zurek, W. H. & Zwolak, M. Defects in quantum computers. Sci. Rep . 8 , 4539 (2018).
Article  ADS  PubMed
Google Scholar
Anquez, M. et al. Quantum Kibble–Zurek mechanism in a spin-1 Bose–Einstein condensate. Phys. Rev. Lett . 116 , 155301 (2016).
Article  ADS  CAS
Google Scholar
Clark, L. W., Feng, L. & Chin, C. Universal space-time scaling symmetry in the dynamics of bosons across a quantum phase transition. Science 354 , 606–610 (2016).
Article  ADS  MathSciNet  CAS
Google Scholar
Endres, M. et al. The ‘Higgs’ amplitude mode at the two-dimensional superfluid/Mott insulator transition. Nature 487 , 454–458 (2012).
Article  ADS  CAS
Google Scholar
Chen, D., White, M., Borries, C. & deMarco, B. Quantum quench of an atomic Mott insulator. Phys. Rev. Lett . 106 , 235304 (2011).
Article  ADS
Google Scholar
Braun, S. et al. Emergence of coherence and the dynamics of quantum phase transitions. Proc. Natl Acad. Sci . 112 , 3641–3646 (2015).
ADS  CAS
Google Scholar
Bernien, H. et al. Probing many-body dynamics on a 51-atom quantum simulator. Nature 551 , 579–584 (2017).
Article  ADS  CAS
Google Scholar
Kolodrubetz, M., Clark, B. K. & Huse, D. A. Nonequilibrium dynamical critical scaling of the quantum Ising chain. Phys. Rev. Lett . 109 , 015701 (2012).
Article  ADS
Google Scholar
Cherng, R. W. & Levitov, L. S. Entropy and correlation functions of a driven quantum spin chain. Phys. Rev. A 73 , 043614 (2006).
Article  ADS
Google Scholar
Fendley, P., Sengupta, K. & Sachdev, S. Competing density-wave orders in a one-dimensional hard-boson model. Phys. Rev. B 69 , 075106 (2004).
Article  ADS
Google Scholar
Samajdar, R., Choi, S., Pichler, H., Lukin, M. D. & Sachdev, S. Numerical study of the chiral Z 3 quantum phase transition in one spatial dimension. Phys. Rev. A 98 , 023614 (2018).
Article  ADS  CAS
Google Scholar
Whitsitt, S., Samajdar, R. & Sachdev, S. Quantum field theory for the chiral clock transition in one spatial dimension. Phys. Rev. B 98 , 205118 (2018).
Article  ADS  CAS
Google Scholar
Chepiga, N. & Mila, F. Floating phase versus chiral transition in a 1D hard-boson model. Phys. Rev. Lett . 122 , 017205 (2019).
Article  ADS
Google Scholar
Haldane, F. D. M., Bak, P. & Bohr, T. Phase diagrams of surface structures from Bethe-ansatz solutions of the quantum sine-Gordon model. Phys. Rev. B 28 , 2743 (1983).
Article  ADS
Google Scholar
Dutta, A. et al. Quantum Phase Transitions in Transverse Field Spin Models: From Statistical Physics to Quantum Information (Cambridge Univ. Press, Cambridge, 2015).
Book
Google Scholar
Moessner, R., Sondhi, S. L. & Fradkin, E. Short-ranged resonating valence bond physics, quantum dimer models, and Ising gauge theories. Phys. Rev. B 65 , 024504 (2001).
Article  ADS
Google Scholar
Barredo, D., Lienhard, V., de Léséleuc, S., Lahaye, T. & Browaeys, A. Synthetic three-dimensional atomic structures assembled atom by atom. Nature 561 , 79–82 (2018).
Article  ADS  CAS
Google Scholar
Kumar, A., Wu, T.-Y., Giraldo Mejia, F. & Weiss, D. S. Sorting ultracold atoms in a three-dimensional optical lattice in a realization of Maxwell’s demon. Nature 561 , 83–87 (2018).
Article  ADS  CAS
Google Scholar
Pichler, H., Wang, S.-T., Zhou, L., Choi, S. & Lukin, M. D. Quantum optimization for maximum independent set using Rydberg atom arrays. Preprint at https://arxiv.org/abs/1808.10816 (2018).
Endres, M. et al. Atom-by-atom assembly of defect-free one-dimensional cold atom arrays. Science 354 , 1024–1027 (2016).
Article  ADS  CAS
Google Scholar
Levine, H. et al. High-fidelity control and entanglement of Rydberg-atom qubits. Phys. Rev. Lett . 121 , 123603 (2018).
Article  ADS  CAS
Google Scholar
White, S. R. Density matrix formulation for quantum renormalization groups. Phys. Rev. Lett . 69 , 2863–2866 (1992).
Article  ADS  CAS
Google Scholar
White, S. R. Density-matrix algorithms for quantum renormalization groups. Phys. Rev. B 48 , 10345–10356 (1993).
Article  ADS  CAS
Google Scholar
Östlund, S. & Rommer, S. Thermodynamic limit of density matrix renormalization. Phys. Rev. Lett . 75 , 3537–3540 (1995).
Article  ADS
Google Scholar
Rommer, S. & Östlund, S. Class of ansatz wave functions for one-dimensional spin systems and their relation to the density matrix renormalization group. Phys. Rev. B 55 , 2164–2181 (1997).
Article  ADS
Google Scholar
Dukelsky, J., Martin-Delgado, M. A., Nishino, T. & Sierra, G. Equivalence of the variational matrix product method and the density matrix renormalization group applied to spin chains. Europhys. Lett . 43 , 457–462 (1998).
Article  ADS  CAS
Google Scholar
Peschel, I., Wang, X., Kaulke, M. & Hallberg, K. (eds) Density-Matrix Renormalization (Springer, Berlin, 1999).
McCulloch, I. P. Infinite size density matrix renormalization group, revisited. Preprint at https://arxiv.org/abs/0804.2509 (2008).
Pirvu, B., Murg, V., Cirac, J. I. & Verstraete, F. Matrix product operator representations. New J. Phys . 12 , 025012 (2010).
Article  ADS  MathSciNet
Google Scholar
Schollwöck, U. The density-matrix renormalization group. Rev. Mod. Phys . 77 , 259–315 (2005).
Article  ADS  MathSciNet
Google Scholar
Schollwöck, U. The density-matrix renormalization group: a short introduction. Phil. Trans. R. Soc. A 369 , 2643–2661 (2011).
Article  ADS  MathSciNet
Google Scholar
Gerster, M., Haggenmiller, B., Tschirsich, F., Silvi, P. & Montangero, S. Dynamical Ginzburg criterion for the quantum-classical crossover of the Kibble–Zurek mechanism. Preprint at https://arxiv.org/abs/1807.10611 (2018).
Jaschke, D., Maeda, K., Whalen, J. D., Wall, M. L. & Carr, L. D. Critical phenomena and Kibble–Zurek scaling in the long-range quantum Ising chain. New J. Phys . 19 , 033032 (2017).
Article  ADS
Google Scholar
Huse, D. A. Simple three-state model with infinitely many phases. Phys. Rev. B 24 , 5180–5194 (1981).
Article  ADS  MathSciNet
Google Scholar
Zhuang, Y., Changlani, H. J., Tubman, N. M. & Hughes, T. L. Phase diagram of the Z 3 parafermionic chain with chiral interactions. Phys. Rev. B 92 , 035154 (2015).
Article  ADS
Google Scholar
Huse, D. A., Szpilka, A. M. & Fisher, M. E. Melting and wetting transitions in the three-state chiral clock model. Physica A 121 , 363–398 (1983).
... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [4]: M. Buzzi et al. — Photomolecular high-temperature superconductivity (Phys. Rev. X 10, 031028, 2020)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Photomolecular High-Temperature Superconductivity
URL: https://doi.org/10.1103/PhysRevX.10.031028
Photomolecular High-Temperature Superconductivity | Phys. Rev. X
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Subjects
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review X
Highlights
Recent
Subjects
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Reuse & Permissions
It is not necessary to obtain permission to reuse thisarticle or its components as it is available under the terms ofthe Creative Commons Attribution 4.0 International license.This license permits unrestricted use, distribution, andreproduction in any medium, provided attribution to the author(s) andthe published article's title, journal citation, and DOI aremaintained. Please note that some figures may have been included withpermission from other third parties. It is your responsibility toobtain the proper permission from the rights holder directly forthese figures.
Open Access
Photomolecular High-Temperature Superconductivity
M. Buzzi 1,* , D. Nicoletti 1 , M. Fechner 1 , N. Tancogne-Dejean 1 , M. A. Sentef 1 , A. Georges 2,3 , T. Biesner 4 , E. Uykur 4 , M. Dressel 4 et al.  open icon
close icon
A. Henderson 5 , T. Siegrist 5 , J. A. Schlueter 5,6 , K. Miyagawa 7 , K. Kanoda 7 , M.-S. Nam 8 , A. Ardavan 8 , J. Coulthard 8 , J. Tindall 8 , F. Schlawin 8 , D. Jaksch 8 , and A. Cavalleri 1,8,†
1 Max Planck Institute for the Structure and Dynamics of Matter, 22761 Hamburg, Germany
2 Center for Computational Quantum Physics (CCQ), The Flatiron Institute, New York, New York 10010, USA
3 Collège de France, 11 place Marcelin Berthelot, 75005 Paris, France
4 1. Physikalisches Institut, Universität Stuttgart, 70569 Stuttgart, Germany
5 National High Magnetic Field Laboratory, 1800 East Paul Dirac Drive, Tallahassee, Florida 32310, USA
6 Division of Material Research, National Science Foundation, Alexandria, Virginia 22314, USA
7 Department of Applied Physics, University of Tokyo, 7-3-1 Hongo, Bunkyo-ku, Tokyo 113-8656, Japan
8 Department of Physics, Clarendon Laboratory, University of Oxford, Oxford OX1 3PU, United Kingdom
* michele.buzzi@mpsd.mpg.de
† andrea.cavalleri@mpsd.mpg.de
PDF Share open icon
close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. X 10 , 031028 – Published 6 August, 2020
DOI:https://doi.org/10.1103/PhysRevX.10.031028
Export Citation
140
Show metrics open icon
close icon
See more details
Picked up by 6 news outlets
Blogged by 1
Posted by 14 X users
On 1 Facebook pages
92 readers on Mendeley
140
CITATIONS
Abstract
The properties of organic conductors are often tuned by the application of chemical or external pressure, which change orbital overlaps and electronic bandwidths while leaving the molecular building blocks virtually unperturbed. Here, we show that, unlike any other method, light can be used to manipulate the local electronic properties at the molecular sites, giving rise to new emergent properties. Targeted molecular excitations in the charge-transfer salt 𝜅 − ( B E D T − T T F ) 2 ⁢ C u ⁡ [ N ⁢ ( C N ) 2 ] ⁢ B r induce a colossal increase in carrier mobility and the opening of a superconducting optical gap. Both features track the density of quasiparticles of the equilibrium metal and can be observed up to a characteristic coherence temperature 𝑇 * ≃ 5 0     K , far higher than the equilibrium transition temperature 𝑇 𝑪 = 1 2 . 5     K . Notably, the large optical gap achieved by photoexcitation is not observed in the equilibrium superconductor, pointing to a light-induced state that is different from that obtained by cooling. First-principles calculations and model Hamiltonian dynamics predict a transient state with long-range pairing correlations, providing a possible physical scenario for photomolecular superconductivity.
Physics Subject Headings (PhySH)
Superconductivity
Molecular solids
Unconventional superconductors
Infrared spectroscopy
Time-resolved infrared spectroscopy
Popular Summary
High-temperature superconductivity is found in a wide variety of organic conductors—synthetic metals composed of molecular building blocks whose nature and arrangement fully determine the material’s properties. Typically, these properties are altered by the use of chemical substitutions or by the application of external pressure. These approaches affect only the mutual arrangement of the molecular building blocks, leaving their intrinsic nature unchanged. Here, we use ultrafast midinfrared laser pulses to directly manipulate the molecular building blocks and induce transient superconductivity at a temperature much higher than that found at equilibrium.
In our experiment, we focus on the organic superconductor 𝜅 − ( B E D T − T T F ) 2 ⁢ C ⁢ u ⁡ [ N ⁡ ( C ⁢ N ) 2 ] ⁢ B ⁢ r . This compound has a superconducting transition temperature of 12.5 K, the highest for this family of superconductors. Using femtosecond midinfrared laser pulses tuned to excite specific molecular vibrational modes, we induce transient superconductivity at temperatures as high as 50 K. This change in behavior arises from how the laser pulses modulate the local molecular wave function and with it the electronic interactions in the solid.
This discovery provides a possible physical scenario for photomolecular superconductivity and a new way of tuning electronic ground states in solids.
Article Text
Supplemental Material
References (38)
T. Ishiguro, K. Yamaji, and G. Saito, Organic Superconductors , 2nd ed. (Springer-Verlag Berlin Heidelberg, 1998).
D. Jérome, The Physics of Organic Superconductors, Science 252 , 1509 (1991) .
M. Lang and J. Mueller, Organic Superconductors, arXiv:cond-mat/0302157 .
A. Ardavan, S. Brown, S. Kagoshima, K. Kanoda, K. Kuroki, H. Mori, M. Ogata, S. Uji, and J. Wosnitza, Recent Topics of Organic Superconductors, J. Phys. Soc. Jpn. 81 , 011004 (2012) .
A. Fortunelli and A. Painelli, On the Ab Initio Evaluation of Hubbard Parameters. II. The Crystal, J. Chem. Phys. 106 , 8051 (1997) .
H. C. Kandpal, I. Opahle, Y. Z. Zhang, H. O. Jeschke, and R. Valentí, Revision of Model Parameters for -Type Charge Transfer Salts: An Ab Initio Study, Phys. Rev. Lett. 103 , 067004 (2009) .
R. H. McKenzie, A Strongly Correlated Electron Model for the Layered Organic Superconductors , Comments Condens. Matter Phys. 18 , 309 (1998), https://arxiv.org/abs/cond-mat/9802198 .
H. Kino and H. Fukuyama, Phase Diagram of Two-Dimensional Organic Conductors: , J. Phys. Soc. Jpn. 65 , 2158 (1996) .
See Supplemental Material at http://link.aps.org/supplemental/10.1103/PhysRevX.10.031028 for sample preparation, determination of equilibrium and transient optical properties, fitting models, extended data sets, and ab initio calculations.
J. E. Eldridge, K. Kornelsen, H. H. Wang, J. M. Williams, A. V. S. Crouch, and D. M. Watkins, Infrared Optical Properties of the 12 K Organic Superconductor , Solid State Commun. 79 , 583 (1991) .
D. Faltermeier, J. Barz, M. Dumm, M. Dressel, N. Drichko, B. Petrov, V. Semkin, R. Vlasova, C. Meźière, and P. Batail, Bandwidth-Controlled Mott Transition in : Optical Studies of Localized Charge Excitations, Phys. Rev. B 76 , 165113 (2007) .
M. Dumm, D. Faltermeier, N. Drichko, M. Dressel, C. Mézière, and P. Batail, Bandwidth-Controlled Mott Transition in : Optical Studies of Correlated Carriers, Phys. Rev. B 79 , 195106 (2009) .
M. Dressel, M. Dumm, N. Drichko, C. Méziere, and P. Batail, Coherent Particle Response of Two-Dimensional Organic Conductors upon Crossing the Mott Transition, J. Phys. Conf. Ser. 200 , 012029 (2010) .
J. J. McGuire, T. Rõõm, A. Pronin, T. Timusk, J. A. Schlueter, M. E. Kelly, and A. M. Kini, Incoherent Interplane Conductivity of , Phys. Rev. B 64 , 094503 (2001) .
J. E. Eldridge, C. C. Homes, J. M. Williams, A. M. Kini, and H. H. Wang, The Assignment of the Normal Modes of the BEDT-TTF Electron-Donor Molecule Using the Infrared and Raman Spectra of Several Isotopic Analogs, Spectrochim. Acta, Part A 51 , 947 (1995) .
J. E. Eldridge, Y. Xie, H. H. Wang, J. M. Williams, A. M. Kini, and J. A. Schlueter, Electron-Phonon Effects in the Organic Superconductor , Spectrochim. Acta, Part A 52 , 45 (1996) .
M. Maksimuk, K. Yakushi, H. Taniguchi, K. Kanoda, and A. Kawamoto, The Stretching Vibrations of and Its Isotope Analogues, J. Phys. Soc. Jpn. 70 , 3728 (2001) .
D. Fausti, R. I. Tobey, N. Dean, S. Kaiser, A. Dienst, M. C. Hoffmann, S. Pyon, T. Takayama, H. Takagi, and A. Cavalleri, Light-Induced Superconductivity in a Stripe-Ordered Cuprate, Science 331 , 189 (2011) .
W. Hu, S. Kaiser, D. Nicoletti, C. R. Hunt, I. Gierz, M. C. Hoffmann, M. Le Tacon, T. Loew, B. Keimer, and A. Cavalleri, Optically Enhanced Coherent Transport in by Ultrafast Redistribution of Interlayer Coupling, Nat. Mater. 13 , 705 (2014) .
S. Kaiser et al. Optically Induced Coherent Transport Far above in Underdoped , Phys. Rev. B 89 , 184516 (2014) .
M. Mitrano et al. , Possible Light-Induced Superconductivity in at High Temperature, Nature (London) 530 , 461 (2016) .
D. Nicoletti, E. Casandruc, Y. Laplace, V. Khanna, C. R. Hunt, S. Kaiser, S. S. Dhesi, G. D. Gu, J. P. Hill, and A. Cavalleri, Optically Induced Superconductivity in Striped by Polarization-Selective Excitation in the Near Infrared, Phys. Rev. B 90 , 100503 (2014) .
A. Cantaluppi, M. Buzzi, G. Jotzu, D. Nicoletti, M. Mitrano, D. Pontiroli, M. Riccò, A. Perucchi, P. Di Pietro, and A. Cavalleri, Pressure Tuning of Light-Induced Superconductivity in , Nat. Phys. 14 , 837 (2018) .
W. Zimmermann, E. H. Brandt, M. Bauer, E. Seider, and L. Genzel, Optical Conductivity of BCS Superconductors with Arbitrary Purity, Physica C (Amsterdam) 183 , 99 (1991) .
M. Dressel and G. Grüner, Electrodynamics of Solids (Cambridge University Press, Cambridge, England, 2002).
A. Kawamoto, K. Miyagawa, Y. Nakazawa, and K. Kanoda, NMR Study of Layered Organic Superconductors Based on BEDT-TTF Molecules, Phys. Rev. Lett. 74 , 3455 (1995) .
S. Kaiser et al. , Optical Properties of a Vibrationally Modulated Solid State Mott Insulator, Sci. Rep. 4 , 3823 (2015) .
R. Singla et al. , THz-Frequency Modulation of the Hubbard U in an Organic Mott Insulator, Phys. Rev. Lett. 115 , 187401 (2015) .
F. Peronaci, O. Parcollet, and M. Schirò, Enhancement of Local Pairing Correlations in Periodically Driven Mott Insulators. arXiv:1904.00857 (2019).
J. Tindall, B. Buča, J. R. Coulthard, and D. Jaksch, Heating-Induced Long-Range Pairing in the Hubbard Model, Phys. Rev. Lett. 123 , 030603 (2019) .
J. Li, D. Golez, P. Werner, and M. Eckstein, Long-Range -Pairing in Photodoped Mott Insulators, arXiv:1908.08693 .
A. Nava, C. Giannetti, A. Georges, E. Tosatti, and M. Fabrizio, Cooling Quasiparticles in Fullerides by Excitonic Mid-infrared Absorption, Nat. Phys. 14 , 154 (2018) .
H. Dehghani, Z. M. Raines, V. M. Galitski, and M. Hafezi, Optical Enhancement of Superconductivity via Targeted Destruction of Charge Density Waves, Phys. Rev. B 101 , 224506 (2020) .
A. Sheikhan and C. Kollath, Dynamically Enhanced Unconventional Superconducting Correlations in a Hubbard Ladder, arXiv:1902.07947 .
Y. J. Uemura, Dynamic Superconductivity Responses in Photoexcited Optical Conductivity and Nernst Effect, Phys. Rev. Mater. 3 , 104801 (2019) .
M. S. Nam, A. Ardavan, S. J. Blundell, and J. A. Schlueter, Fluctuating Superconductivity in Organic Molecular Metals Close to the Mott Transition, Nature (London) 449 , 584 (2007) .
D. M. Kennes, E. Y. Wilner, D. R. Reichman, and A. J. Millis, Transient Superconductivity from Electronic Squeezing of Optically Pumped Phonons, Nat. Phys. 13 , 479 (2017) .
M. A. Sentef, Light-Enhanced Electron-Phonon Coupling from Nonlinear Electron-Phonon Coupling, Phys. Rev. B 95 , 205111 (2017) .
Outline Information
Citing Articles (87)
Abstract
Popular Summary
Article Text
ACKNOWLEDGMENTS
Supplemental Material
References
Phys. Rev. X 10 , 031028 – Published 6 August, 2020
Vol. 10, Iss. 3 — July - September 2020
Received 27 April 2020
Revised 4 June 2020
Accepted 5 June 2020
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevX.10.031028
Published by the American Physical Society under the terms of the Creative Commons Attribution 4.0 International license. Further distribution of this work must maintain attribution to the author(s) and the published article’s title, journal citation, and DOI. Open access publication funded by the Max Planck Society.
Published by the American Physical Society
Outline Information
Outline
Citing Articles (87)
Abstract
Popular Summary
Article Text
ACKNOWLEDGMENTS
Supplemental Material
References
Information
Phys. Rev. X 10 , 031028 – Published 6 August, 2020
Vol. 10, Iss. 3 — July - September 2020
Received 27 April 2020
Revised 4 June 2020
Accepted 5 June 2020
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevX.10.031028
Published by the American Physical Society under the terms of the Creative Commons Attribution 4.0 International license. Further distribution of this work must maintain attribution to the author(s) and the published article’s title, journal citation, and DOI. Open access publication funded by the Max Planck Society.
Published by the American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Information for Authors Submit a Manuscript Publication Rights Article Publication Charge Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Information for Authors
Submit a Manuscript
Publication Rights
Article Publication Charge
Policies & Prac... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [5]: P. Frey, S. Rachel — Realization of a discrete time crystal on 57 qubits of a quantum computer (Sci. Adv. 8, eabm7652, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Realization of a discrete time crystal on 57 qubits of a quantum computer
URL: https://doi.org/10.1126/sciadv.abm7652
[2105.06632] Realization of a discrete time crystal on 57 qubits of a quantum computer
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2105.06632
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2105.06632 (quant-ph)
[Submitted on 14 May 2021 ( v1 ), last revised 17 Jan 2022 (this version, v3)]
Title: Realization of a discrete time crystal on 57 qubits of a quantum computer
Authors: Philipp Frey , Stephan Rachel
View a PDF of the paper titled Realization of a discrete time crystal on 57 qubits of a quantum computer, by Philipp Frey and 1 other authors
View PDF
Abstract: Novel dynamical phases that violate ergodicity have been a subject of extensive research in recent years. A periodically driven system is naively expected to lose all memory of its initial state due to thermalization, yet this can be avoided in the presence of many-body localization. A discrete time crystal represents a driven system whose local observables spontaneously break time translation symmetry and retain memory of the initial state indefinitely. Here we report the observation of a discrete time crystal on a chain consisting of 57 superconducting qubits on a state--of--the--art quantum computer. We probe random initial states and compare the cases of vanishing and finite disorder to distinguish many-body localization from pre-thermal dynamics. We further report results on the dynamical phase transition between the discrete time crystal and a thermal regime, which is observed via critical fluctuations in the system's sub-harmonic frequency response and a significant speed-up of spin depolarisation.
Comments:  v3: Details regarding process tomography and additional interactions added
Subjects:
Quantum Physics (quant-ph) ; Mesoscale and Nanoscale Physics (cond-mat.mes-hall); Strongly Correlated Electrons (cond-mat.str-el)
Cite as:  arXiv:2105.06632 [quant-ph]
(or  arXiv:2105.06632v3 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2105.06632
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Sci. Adv. 8, eabm7652 (2022)
Submission history From: Philipp Frey [ view email ]  [v1]  Fri, 14 May 2021 04:05:14 UTC (878 KB)
[v2]  Thu, 9 Sep 2021 15:24:00 UTC (1,447 KB)
[v3]  Mon, 17 Jan 2022 02:50:26 UTC (1,669 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Realization of a discrete time crystal on 57 qubits of a quantum computer, by Philipp Frey and 1 other authors
View PDF
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2021-05
Change to browse by:
cond-mat  cond-mat.mes-hall  cond-mat.str-el
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [6]: Q. Guo et al. — Stark many-body localization on a superconducting quantum processor (Phys. Rev. Lett. 127, 240502, 2021)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Stark Many-Body Localization on a Superconducting Quantum Processor
URL: https://doi.org/10.1103/PhysRevLett.127.240502
Stark Many-Body Localization on a Superconducting Quantum Processor | Phys. Rev. Lett.
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review Letters
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Stark Many-Body Localization on a Superconducting Quantum Processor
Qiujiang Guo 1,* , Chen Cheng 2,3,* , Hekang Li 1,* , Shibo Xu 1 , Pengfei Zhang 1 , Zhen Wang 1 , Chao Song 1 , Wuxin Liu 1 , Wenhui Ren 1 et al.  open icon
close icon
Hang Dong 1 , Rubem Mondaini 3,† , and H. Wang 1,‡
1 Department of Physics and Hangzhou Innovation Center, Interdisciplinary Center for Quantum Information, Zhejiang Province Key Laboratory of Quantum Technology and Device, Zhejiang University, Hangzhou 310027, China
2 School of Physical Science and Technology, Lanzhou University, Lanzhou 730000, China
3 Beijing Computational Science Research Center, Beijing 100094, China
* These authors contributed equally to this work.
† rmondaini@csrc.ac.cn
‡ hhwang@zju.edu.cn
PDF Share open icon
close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. Lett. 127 , 240502 – Published 10 December, 2021
DOI:https://doi.org/10.1103/PhysRevLett.127.240502
Export Citation
112
Show metrics open icon
close icon
See more details
Picked up by 1 news outlets
Blogged by 1
Posted by 5 X users
Reddited by 1
72 readers on Mendeley
112
CITATIONS
Abstract
Quantum emulators, owing to their large degree of tunability and control, allow the observation of fine aspects of closed quantum many-body systems, as either the regime where thermalization takes place or when it is halted by the presence of disorder. The latter, dubbed many-body localization (MBL) phenomenon, describes the nonergodic behavior that is dynamically identified by the preservation of local information and slow entanglement growth. Here, we provide a precise observation of this same phenomenology in the case where the quenched on-site energy landscape is not disordered, but rather linearly varied, emulating the Stark MBL. To this end, we construct a quantum device composed of 29 functional superconducting qubits, faithfully reproducing the relaxation dynamics of a nonintegrable spin model. At large Stark potentials, local observables display periodic Bloch oscillations, a manifesting characteristic of the fragmentation of the Hilbert space in sectors that conserve dipole moments. The flexible programmability of our quantum emulator highlights its potential in helping the understanding of nontrivial quantum many-body problems, in direct complement to simulations in classical computers.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Physics Subject Headings (PhySH)
Dynamical phase transitions
Many-body localization
Nonequilibrium statistical mechanics
Quantum information with solid state qubits
Quantum quench
Quantum simulation
Superconducting qubits
Matrix product states
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
Supplemental Material (Subscription Required)
References (Subscription Required)
Outline Information
Citing Articles (90)
Abstract
Article Text
Supplemental Material
References
Phys. Rev. Lett. 127 , 240502 – Published 10 December, 2021
Vol. 127, Iss. 24 — 10 December 2021
Received 30 July 2021
Accepted 8 November 2021
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevLett.127.240502
© 2021 American Physical Society
Outline Information
Outline
Citing Articles (90)
Abstract
Article Text
Supplemental Material
References
Information
Phys. Rev. Lett. 127 , 240502 – Published 10 December, 2021
Vol. 127, Iss. 24 — 10 December 2021
Received 30 July 2021
Accepted 8 November 2021
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevLett.127.240502
© 2021 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science SCOAP 3 Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
SCOAP 3
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 1079-7114 (online), 0031-9007 (print). ©2026 American Physical Society. All rights reserved.  Physical Review Letters™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [7]: J. Smith et al. — Many-body localization in a quantum simulator with programmable random disorder (Nat. Phys. 12, 907-911, 2016)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Many-body localization in a quantum simulator with programmable random disorder
URL: https://doi.org/10.1038/nphys3783
Many-body localization in a quantum simulator with programmable random disorder | Nature Physics
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
Reviews & Analysis
News & Comment
Current issue
Collections
Subjects
Follow us on Facebook
Follow us on X
Subscribe
Sign up for alerts
RSS feed
About the journal
About the journal
Aims & Scope
Journal Information
Journal Metrics
Our publishing models
About the Editors
Reviews Cross-Journal Editorial Team
Research Cross-Journal Editorial Team
Editorial Values Statement
Editorial Policies
Content Types
Web Feeds
Contact
Publish with us
Publish with us
Submission Guidelines
For Reviewers
Language editing services
Open access funding
Submit manuscript
Subscribe
Sign up for alerts
RSS feed
nature
nature physics
letters
article
Letter
Published: 06 June 2016
Many-body localization in a quantum simulator with programmable random disorder
J. Smith 1 ,
A. Lee 1 ,
P. Richerme 2 ,
B. Neyenhuis 1 ,
P. W. Hess  ORCID: orcid.org/0000-0003-2985-4221 1 ,
P. Hauke 3 , 4 ,
M. Heyl 3 , 4 , 5 ,
D. A. Huse 6 &
…
C. Monroe 1  Show authors
Nature Physics
volume 12 , pages 907–911 ( 2016 ) Cite this article
20k Accesses
882 Citations
38 Altmetric
Metrics details
Abstract
When a system thermalizes it loses all memory of its initial conditions. Even within a closed quantum system, subsystems usually thermalize using the rest of the system as a heat bath. Exceptions to quantum thermalization have been observed, but typically require inherent symmetries 1 , 2 or noninteracting particles in the presence of static disorder 3 , 4 , 5 , 6 . However, for strong interactions and high excitation energy there are cases, known as many-body localization (MBL), where disordered quantum systems can fail to thermalize 7 , 8 , 9 , 10 . We experimentally generate MBL states by applying an Ising Hamiltonian with long-range interactions and programmable random disorder to ten spins initialized far from equilibrium. Using experimental and numerical methods we observe the essential signatures of MBL: initial-state memory retention, Poissonian distributed energy level spacings, and evidence of long-time entanglement growth. Our platform can be scaled to more spins, where a detailed modelling of MBL becomes impossible.
Access through your institution
Buy or subscribe
This is a preview of subscription content, access via your institution
Access options
Access through your institution
Subscribe to this journal
Receive 12 print issues and online access
$259.00 per year
only $21.58 per issue
Learn more
Buy this article
Purchase on SpringerLink
Instant access to the full article PDF.
USD 39.95
Prices may be subject to local taxes which are calculated during checkout
Additional access options:
Log in
Learn about institutional subscriptions
Read our FAQs
Contact customer support
Figure 1: An interacting spin model with random disorder.
The alternative text for this image may have been generated using AI.
Figure 2: Emergence of a MBL state.
The alternative text for this image may have been generated using AI.
Figure 3: The Hamming distance (HD).
The alternative text for this image may have been generated using AI.
Figure 4: Quantum Fisher information (QFI).
The alternative text for this image may have been generated using AI.
Similar content being viewed by others
Observation of Stark many-body localization without disorder
Article
17 November 2021
Screening the Coulomb interaction leads to a prethermal regime in two-dimensional bad conductors
Article  Open access  02 November 2023
Quantum avalanches in \(\mathbb {Z}_2\) -preserving interacting Ising Majorana chain
Article  Open access  19 December 2025
References
Kinoshita, T., Wenger, T. & Weiss, D. S. A quantum Newton’s cradle. Nature 440 , 900–903 (2006).
Article  ADS
Google Scholar
Gring, M. et al. Relaxation and prethermalization in an isolated quantum system. Science 337 , 1318–1322 (2012).
Article  ADS
Google Scholar
Anderson, P. W. Absence of diffusion in certain random lattices. Phys. Rev. 109 , 1492–1505 (1958).
Article  ADS
Google Scholar
Wiersma, D. S., Bartolini, P., Lagendijk, A. & Righini, R. Localization of light in a disordered medium. Nature 390 , 671–673 (1997).
Article  ADS
Google Scholar
Billy, J. et al. Direct observation of Anderson localization of matter waves in a controlled disorder. Nature 453 , 891–894 (2008).
Article  ADS
Google Scholar
Roati, G. et al. Anderson localization of a non-interacting Bose–Einstein condensate. Nature 453 , 895–898 (2008).
Article  ADS
Google Scholar
Basko, D. M., Aleiner, I. L. & Altshuler, B. L. Possible experimental manifestations of the many-body localization. Phys. Rev. B 76 , 052203 (2007).
Article  ADS
Google Scholar
Oganesyan, V. & Huse, D. A. Localization of interacting fermions at high temperature. Phys. Rev. B 75 , 155111 (2007).
Article  ADS
Google Scholar
Pal, A. & Huse, D. A. Many-body localization phase transition. Phys. Rev. B 82 , 174411 (2010).
Article  ADS
Google Scholar
Serbyn, M., Papić, Z. & Abanin, D. A. Local conservation laws and the structure of the many-body localized states. Phys. Rev. Lett. 111 , 127201 (2013).
Article  ADS
Google Scholar
Yao, N. et al. Many-body localization in dipolar systems. Phys. Rev. Lett. 113 , 243002 (2014).
Article  ADS
Google Scholar
Kondov, S., McGehee, W., Xu, W. & DeMarco, B. Disorder-induced localization in a strongly correlated atomic hubbard gas. Phys. Rev. Lett. 114 , 083002 (2015).
Article  ADS
Google Scholar
Schreiber, M. et al. Observation of many-body localization of interacting fermions in a quasi-random optical lattice. Science 349 , 842–845 (2015).
Article  ADS  MathSciNet
Google Scholar
Mølmer, K. & Sørensen, A. Multiparticle entanglement of hot trapped ions. Phys. Rev. Lett. 82 , 1835–1838 (1999).
Article  ADS
Google Scholar
Islam, R. et al. Emergence and frustration of magnetism with variable-range interactions in a quantum simulator. Science 340 , 583–587 (2013).
Article  ADS
Google Scholar
Wu, Y.-L. & Das Sarma, S. Understanding analog quantum simulation dynamics in coupled ion-trap qubits. Phys. Rev. A 93 , 022332 (2016).
Article  ADS
Google Scholar
Richerme, P. et al. Non-local propagation of correlations in quantum systems with long-range interactions. Nature 511 , 198–201 (2014).
Article  ADS
Google Scholar
Jurcevic, P. et al. Quasiparticle engineering and entanglement propagation in a quantum many-body system. Nature 511 , 202–205 (2014).
Article  ADS
Google Scholar
Deutsch, J. M. Quantum statistical mechanics in a closed system. Phys. Rev. A 43 , 2046–2049 (1991).
Article  ADS
Google Scholar
Srednicki, M. Chaos and quantum thermalization. Phys. Rev. E 50 , 888–901 (1994).
Article  ADS
Google Scholar
Rigol, M., Dunjko, V. & Olshanii, M. Thermalization and its mechanism for generic isolated quantum systems. Nature 452 , 854–858 (2008).
Article  ADS
Google Scholar
Hauke, P. & Heyl, M. Many-body localization and quantum ergodicity in disordered long-range Ising models. Phys. Rev. B 92 , 134204 (2015).
Article  ADS
Google Scholar
Burin, A. L. Localization in a random XY model with long-range interactions: intermediate case between single-particle and many-body problems. Phys. Rev. B 92 , 104428 (2015).
Article  ADS
Google Scholar
Nandkishore, R. & Huse, D. A. Many-body localization and thermalization in quantum statistical mechanics. Annu. Rev. Condens. Matter Phys. 6 , 15–38 (2015).
Article  ADS
Google Scholar
Bardarson, J. H., Pollmann, F. & Moore, J. E. Unbounded growth of entanglement in models of many-body localization. Phys. Rev. Lett. 109 , 017202 (2012).
Article  ADS
Google Scholar
Pino, M. Entanglement growth in many-body localized systems with long-range interactions. Phys. Rev. B 90 , 174204 (2014).
Article  ADS
Google Scholar
Haeffner, H. et al. Scalable multiparticle entanglement of trapped ions. Nature 438 , 643–646 (2005).
Article  ADS
Google Scholar
Helstrom, C. W. Quantum Detection and Estimation Theory (Academic, 1976).
MATH
Google Scholar
Braunstein, S. L. & Caves, C. M. Statistical distance and the geometry of quantum states. Phys. Rev. Lett. 72 , 3439–3443 (1994).
Article  ADS  MathSciNet
Google Scholar
Pezzé, L. & Smerzi, A. in Proc. Int. School Phys. (eds Tino, G. & Kasevich, M.) 691–741 (IOS Press, 2014).
Google Scholar
Download references
Acknowledgements
We thank L. Duan, Z.-X. Gong, T. Grover, C. Laumann, S. Wang, N. Yao and J. Zhang for helpful discussions. This work is supported by the ARO Atomic and Molecular Physics Program, the AFOSR MURI on Quantum Measurement and Verification, the IARPA MQCO Program, and the NSF Physics Frontier Center at JQI. M.H. acknowledges the Deutsche Akademie der Naturforscher Leopoldina (grant No. LPDS 2013-07 and LPDR 2015-01) and P.H. acknowledges the EU IP SIQS, the SFB FoQuS (FWF Project No. F4016-N23) and the ERC synergy grant UQUAM.
Author information
Authors and Affiliations
Department of Physics and National Institute of Standards and Technology, Joint Quantum Institute, University of Maryland, College Park, Maryland 20742, USA
J. Smith, A. Lee, B. Neyenhuis, P. W. Hess & C. Monroe
Department of Physics, Indiana University, Bloomington, Indiana 47405, USA
P. Richerme
Institute for Quantum Optics and Quantum Information of the Austrian Academy of Sciences, 6020 Innsbruck, Austria
P. Hauke & M. Heyl
Institute for Theoretical Physics, University of Innsbruck, 6020 Innsbruck, Austria
P. Hauke & M. Heyl
Physik Department, Technische Universität München, 85747 Garching, Germany
M. Heyl
Physics Department, Princeton University, Princeton, New Jersey 08544, USA
D. A. Huse
Authors  J. Smith
View author publications
Search author on: PubMed Google Scholar
A. Lee
View author publications
Search author on: PubMed Google Scholar
P. Richerme
View author publications
Search author on: PubMed Google Scholar
B. Neyenhuis
View author publications
Search author on: PubMed Google Scholar
P. W. Hess
View author publications
Search author on: PubMed Google Scholar
P. Hauke
View author publications
Search author on: PubMed Google Scholar
M. Heyl
View author publications
Search author on: PubMed Google Scholar
D. A. Huse
View author publications
Search author on: PubMed Google Scholar
C. Monroe
View author publications
Search author on: PubMed Google Scholar
Contributions
J.S., A.L., P.R., B.N., P.W.H. and C.M. performed the experimental work and P.H., M.H. and D.A.H. performed the theoretical work. All authors contributed to the preparation of this manuscript.
Corresponding author
Correspondence to J. Smith .
Ethics declarations
Competing interests
The authors declare no competing financial interests.
Supplementary information
Supplementary information (download PDF )
Supplementary information (PDF 2397 kb)
Rights and permissions
Reprints and permissions
About this article
Cite this article
Smith, J., Lee, A., Richerme, P. et al. Many-body localization in a quantum simulator with programmable random disorder. Nature Phys 12 , 907–911 (2016). https://doi.org/10.1038/nphys3783
Download citation
Received : 11 December 2015
Accepted : 09 May 2016
Published : 06 June 2016
Issue date : October 2016
DOI : https://doi.org/10.1038/nphys3783
Share this article
Anyone you share the following link with will be able to read this content: Get shareable link
Sorry, a shareable link is not currently available for this article.
Copy shareable link to clipboard
Provided by the Springer Nature SharedIt content-sharing initiative
Subjects
Phase transitions and critical phenomena
Quantum information
Quantum simulation
This article is cited by
Emergence of highly coherent two-level systems in a noisy and dense quantum network
A. Beckert
M. Grimm
G. Aeppli
Nature Physics (2024)
Theory of localization-hindered thermalization in nonlinear multimode photonics
Alba Y. Ramos
Cheng Shi
Tsampikos Kottos
Communications Physics (2023)
Reviving product states in the disordered Heisenberg chain
Henrik Wilming
Tobias J. Osborne
Christoph Karrasch
Nature Communications (2023)
Down-conversion of a single photon as a probe of many-body localization
Nitish Mehta
Roman Kuzmin
Vladimir E. Manucharyan
Nature (2023)
Engineering random spin models with atoms in a high-finesse cavity
Nick Sauerwein
Francesca Orsi
Jean-Philippe Brantut
Nature Physics (2023)
Access through your institution
Buy or subscribe
Associated content
Localization goes long
Chris R. Laumann
Norman Y. Yao
Nature Physics
News & Views
01 Aug 2016
Sections
Figures
References
Abstract
References
Acknowledgements
Author information
Ethics declarations
Supplementary information
Rights and permissions
About this article
This article is cited by
Figure 1: An interacting spin model with random disorder.
Figure 2: Emergence of a MBL state.
Figure 3: The Hamming distance (HD).
Figure 4: Quantum Fisher information (QFI).
Kinoshita, T., Wenger, T. & Weiss, D. S. A quantum Newton’s cradle. Natur... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [8]: M. Schiró, M. Fabrizio — Time-dependent mean field theory for quench dynamics in correlated electron systems (Phys. Rev. Lett. 105, 076401, 2010)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Time-Dependent Mean Field Theory for Quench Dynamics in correlated electron systems
URL: https://doi.org/10.1103/PhysRevLett.105.076401
[1005.0992] Time-Dependent Mean Field Theory for Quench Dynamics in correlated electron systems
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:1005.0992
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Strongly Correlated Electrons
arXiv:1005.0992 (cond-mat)
[Submitted on 6 May 2010 ( v1 ), last revised 9 Sep 2010 (this version, v2)]
Title: Time-Dependent Mean Field Theory for Quench Dynamics in correlated electron systems
Authors: Marco Schiró , Michele Fabrizio
View a PDF of the paper titled Time-Dependent Mean Field Theory for Quench Dynamics in correlated electron systems, by Marco Schir\'o and 1 other authors
View PDF
Abstract: A simple and very flexible variational approach to the out-of-equilibrium quantum dynamics in strongly correlated electron systems is introduced through a time-dependent Gutzwiller wavefunction. As an application, we study the simple case of a sudden change of the interaction in the fermionic Hubbard model and find at the mean field level an extremely rich behaviour. In particular, a dynamical transition between small and large quantum quench regimes is found to occur at half-filling, in accordance with the analysis of Eckstein {\sl et al.}, Phys. Rev. Lett. {\bf 103}, 056403 (2009), obtained by dynamical mean field theory, that turns into a crossover at any finite doping.
Comments:  4 pages, 2 figures, published version
Subjects:
Strongly Correlated Electrons (cond-mat.str-el) ; Quantum Gases (cond-mat.quant-gas)
Cite as:  arXiv:1005.0992 [cond-mat.str-el]
(or  arXiv:1005.0992v2 [cond-mat.str-el] for this version)
https://doi.org/10.48550/arXiv.1005.0992
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Lett. 105, 076401 (2010)
Related DOI :
https://doi.org/10.1103/PhysRevLett.105.076401
Focus to learn more
DOI(s) linking to related resources
Submission history From: Marco Schiró [ view email ]  [v1]  Thu, 6 May 2010 13:03:38 UTC (51 KB)
[v2]  Thu, 9 Sep 2010 18:55:15 UTC (58 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Time-Dependent Mean Field Theory for Quench Dynamics in correlated electron systems, by Marco Schir\'o and 1 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.str-el
< prev
|  next >
new  |  recent  | 2010-05
Change to browse by:
cond-mat  cond-mat.quant-gas
References & Citations
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [9]: K. Ido, T. Ohgoe, M. Imada — Time-dependent many-variable variational Monte Carlo method (Phys. Rev. B 92, 245106, 2015)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Time-dependent many-variable variational Monte Carlo method for nonequilibrium strongly correlated electron systems
URL: https://doi.org/10.1103/PhysRevB.92.245106
Time-dependent many-variable variational Monte Carlo method for nonequilibrium strongly correlated electron systems | Phys. Rev. B
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review B
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Time-dependent many-variable variational Monte Carlo method for nonequilibrium strongly correlated electron systems
Kota Ido , Takahiro Ohgoe , and Masatoshi Imada  open icon
close icon
Department of Applied Physics, University of Tokyo, 7-3-1 Hongo, Bunkyo-ku, Tokyo 113-8656, Japan
PDF Share open icon
close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. B 92 , 245106 – Published 7 December, 2015
DOI:https://doi.org/10.1103/PhysRevB.92.245106
Export Citation
50
Show metrics open icon
close icon
See more details
Posted by 1 X users
51 readers on Mendeley
50
CITATIONS
Abstract
We develop a time-dependent variational Monte Carlo (t-VMC) method for quantum dynamics of strongly correlated electrons. The t-VMC method has been recently applied to bosonic systems and quantum spin systems. Here we propose a time-dependent trial wave function with many variational parameters, which is suitable for nonequilibrium strongly correlated electron systems. As the trial state, we adopt the generalized pair-product wave function with correlation factors and quantum-number projections. This trial wave function has been proven to accurately describe ground states of strongly correlated electron systems. To show the accuracy and efficiency of our trial wave function in nonequilibrium states as well, we present our benchmark results for relaxation dynamics during and after interaction quench protocols of fermionic Hubbard models. We find that our trial wave function well reproduces the exact results for the time evolution of physical quantities such as energy, momentum distribution, spin structure factor, and superconducting correlations. These results show that the t-VMC with our trial wave function offers an efficient and accurate way to study challenging problems of nonequilibrium dynamics in strongly correlated electron systems.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (39)
Abstract
Article Text
References
Phys. Rev. B 92 , 245106 – Published 7 December, 2015
Vol. 92, Iss. 24 — 15 December 2015
Received 1 July 2015
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.92.245106
©2015 American Physical Society
Outline Information
Outline
Citing Articles (39)
Abstract
Article Text
References
Information
Phys. Rev. B 92 , 245106 – Published 7 December, 2015
Vol. 92, Iss. 24 — 15 December 2015
Received 1 July 2015
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.92.245106
©2015 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 2469-9969 (online), 2469-9950 (print). ©2026 American Physical Society. All rights reserved.  Physical Review B™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [10]: M. Yang, S. R. White — Time-dependent variational principle with ancillary Krylov subspace (Phys. Rev. B 102, 094315, 2020)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Time-dependent variational principle with ancillary Krylov subspace
URL: https://doi.org/10.1103/PhysRevB.102.094315
Time-dependent variational principle with ancillary Krylov subspace | Phys. Rev. B
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review B
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Time-dependent variational principle with ancillary Krylov subspace
Mingru Yang * and Steven R. White  open icon
close icon
Department of Physics and Astronomy, University of California, Irvine, California 92697, USA
* mingruy@uci.edu
PDF Share open icon
close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. B 102 , 094315 – Published 29 September, 2020
DOI:https://doi.org/10.1103/PhysRevB.102.094315
Export Citation
134
Show metrics open icon
close icon
See more details
Posted by 1 X users
58 readers on Mendeley
134
CITATIONS
Abstract
We propose an improved scheme to do the time-dependent variational principle (TDVP) in finite matrix product states (MPSs) for two-dimensional systems or one-dimensional systems with long-range interactions. We present a method to represent the time-evolving state in a MPS with its basis enriched by state averaging with global Krylov vectors. We show that the projection error is significantly reduced so precise time evolution can still be obtained even if a larger time step is used. Combined with the one-site TDVP, our approach provides a way to dynamically increase the bond dimension while still preserving unitarity for real-time evolution. Our method can be more accurate and exhibit slower bond dimension growth than the conventional two-site TDVP.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Physics Subject Headings (PhySH)
Quantum metrology
Density matrix renormalization group
Matrix product states
Tensor network methods
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (106)
Abstract
Article Text
References
Phys. Rev. B 102 , 094315 – Published 29 September, 2020
Vol. 102, Iss. 9 — 1 September 2020
Received 5 July 2020
Revised 1 September 2020
Accepted 2 September 2020
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.102.094315
©2020 American Physical Society
Outline Information
Outline
Citing Articles (106)
Abstract
Article Text
References
Information
Phys. Rev. B 102 , 094315 – Published 29 September, 2020
Vol. 102, Iss. 9 — 1 September 2020
Received 5 July 2020
Revised 1 September 2020
Accepted 2 September 2020
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.102.094315
©2020 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 2469-9969 (online), 2469-9950 (print). ©2026 American Physical Society. All rights reserved.  Physical Review B™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [11]: K. Donatella et al. — Dynamics with autoregressive neural quantum states (Phys. Rev. A 108, 022210, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Dynamics with autoregressive neural quantum states: application to critical quench dynamics
URL: https://doi.org/10.1103/PhysRevA.108.022210
[2209.03241] Dynamics with autoregressive neural quantum states: application to critical quench dynamics
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2209.03241
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2209.03241 (quant-ph)
[Submitted on 7 Sep 2022 ( v1 ), last revised 22 Aug 2023 (this version, v2)]
Title: Dynamics with autoregressive neural quantum states: application to critical quench dynamics
Authors: Kaelan Donatella , Zakari Denis , Alexandre Le Boité , Cristiano Ciuti
View a PDF of the paper titled Dynamics with autoregressive neural quantum states: application to critical quench dynamics, by Kaelan Donatella and 3 other authors
View PDF
Abstract: Despite very promising results, capturing the dynamics of complex quantum systems with neural-network ansätze has been plagued by several problems, one of which being stochastic noise that makes the dynamics unstable and highly dependent on some regularization hyperparameters. We present an alternative general scheme that enables one to capture long-time dynamics of quantum systems in a stable fashion, provided the neural-network ansatz is normalized, which can be ensured by the autoregressive property of the chosen ansatz. We then apply the scheme to time-dependent quench dynamics by investigating the Kibble-Zurek mechanism in the two-dimensional quantum Ising model. We find an excellent agreement with exact dynamics for small systems and are able to recover scaling laws in agreement with other variational methods.
Comments:  Final published version
Subjects:
Quantum Physics (quant-ph) ; Other Condensed Matter (cond-mat.other); Computational Physics (physics.comp-ph)
Cite as:  arXiv:2209.03241 [quant-ph]
(or  arXiv:2209.03241v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2209.03241
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. A 108, 022210 (2023)
Related DOI :
https://doi.org/10.1103/PhysRevA.108.022210
Focus to learn more
DOI(s) linking to related resources
Submission history From: Cristiano Ciuti [ view email ]  [v1]  Wed, 7 Sep 2022 15:50:00 UTC (1,226 KB)
[v2]  Tue, 22 Aug 2023 14:54:54 UTC (2,230 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Dynamics with autoregressive neural quantum states: application to critical quench dynamics, by Kaelan Donatella and 3 other authors
View PDF
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2022-09
Change to browse by:
cond-mat  cond-mat.other  physics  physics.comp-ph
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [12]: I. L. Gutiérrez, C. B. Mendl — Real time evolution with neural-network quantum states (Quantum 6, 627, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Real time evolution with neural-network quantum states
URL: https://doi.org/10.22331/q-2022-01-20-627
Real time evolution with neural-network quantum states – Quantum
Skip to content
the open journal for quantum science
Menu
Papers
Perspectives
Instructions
For authors
For referees
For editors
For authors of Views
Editorial policies
People
About
News
Mission and structure
Tools and open source
Code of Conduct
Outreach
Press
Contact
Real time evolution with neural-network quantum states
Real time evolution with neural-network quantum states
Irene López Gutiérrez and Christian B. Mendl
Technische Universität München, Department of Informatics and Institute for Advanced Study, Boltzmannstraße 3, 85748 Garching, GermanyTechnische Universität Dresden, Institute of Scientific Computing, Zellescher Weg 12-14, 01069 Dresden, Germany
Published: 2022-01-20, volume 6 , page 627
Eprint: arXiv:1912.08831v4
Doi: https://doi.org/10.22331/q-2022-01-20-627
Citation: Quantum 6, 627 (2022).
Get full text pdf Read on arXiv Vanity
Find this paper interesting or want to discuss? Scite or leave a comment on SciRate .
Abstract
A promising application of neural-network quantum states is to describe the time dynamics of many-body quantum systems. To realize this idea, we employ neural-network quantum states to approximate the implicit midpoint rule method, which preserves the symplectic form of Hamiltonian dynamics. We ensure that our complex-valued neural networks are holomorphic functions, and exploit this property to efficiently compute gradients. Application to the transverse-field Ising model on a one- and two-dimensional lattice exhibits an accuracy comparable to the stochastic configuration method proposed in [Carleo and Troyer, Science 355, 602-606 (2017)], but does not require computing the (pseudo-)inverse of a matrix.
Featured image: Overlap error (top row) and transverse magnetization (bottom row) of the real time evolution governed by the Ising Hamiltonian on a 3 × 3 lattice after a quench of h. Each column corresponds to a different value of h after the quench, starting from “infinite” h.
Popular summary
Numerical simulation plays an important role for the analysis and understanding of quantum systems. An inherent difficulty stems from the exponential growth of the system's Hilbert space dimension with respect to its size. In particular, the long time dynamics of a quantum system, and the associated entanglement growth, precludes the efficient representation of the statevector by tensor network methods in general.
In this work, we approach the problem using machine learning methods, as proposed in [Carleo and Troyer, Science 355, 602-606 (2017)]. The statevector is approximated by a neural network, and the time evolution of the system is realized by changes in the network parameters. Our main contribution is a translation of well-established numerical integration methods to the optimization of the network weights. We construct a cost function based on the implicit midpoint method as a concrete example, and minimize it with gradient descent. Compared with the previously proposed stochastic reconfiguration method, our approach does not require a possibly ill-conditioned matrix inversion.
The paper describes the mathematical details of the optimization and provides numerical examples of the time dynamics governed by the Ising model, on a 1D lattice with 20 sites and a small 2D lattice. We find the accuracies achieved by our method to be on par with stochastic reconfiguration. The remaining error in the simulations points towards limits of the expressibility of the neural network ansatze themselves, which could be improved in future works.
► BibTeX data  @article{Gutierrez2022realtimeevolution, doi = {10.22331/q-2022-01-20-627}, url = {https://doi.org/10.22331/q-2022-01-20-627}, title = {Real time evolution with neural-network quantum states}, author = {Guti{\'{e}}rrez, Irene L{\'{o}}pez and Mendl, Christian B.}, journal = {{Quantum}}, issn = {2521-327X}, publisher = {{Verein zur F{\"{o}}rderung des Open Access Publizierens in den Quantenwissenschaften}}, volume = {6}, pages = {627}, month = jan, year = {2022}}  ► References
[1] V. Alba and P. Calabrese. Entanglement and thermodynamics after a quantum quench in integrable systems. PNAS, 114: 7947–7951, 2017. 10.1073/​pnas.1703516114.  https:/​/​doi.org/​10.1073/​pnas.1703516114
[2] H. W. J. Blöte and Y. Deng. Cluster Monte Carlo simulation of the transverse Ising model. Phys. Rev. E, 66: 066110, 2002. 10.1103/​PhysRevE.66.066110.  https:/​/​doi.org/​10.1103/​PhysRevE.66.066110
[3] A. Borin and D. A. Abanin. Approximating power of machine-learning ansatz for quantum many-body states. Phys. Rev. B, 101, 2020. 10.1103/​PhysRevB.101.195141.  https:/​/​doi.org/​10.1103/​PhysRevB.101.195141
[4] P. Calabrese and J. Cardy. Evolution of entanglement entropy in one-dimensional systems. J. Stat. Mech.: Theory Exp., 2005: P04010, 2005. 10.1088/​1742-5468/​2005/​04/​p04010.  https:/​/​doi.org/​10.1088/​1742-5468/​2005/​04/​p04010
[5] G. Carleo and M. Troyer. Solving the quantum many-body problem with artificial neural networks. Science, 355: 602–606, 2017. 10.1126/​science.aag2302.  https:/​/​doi.org/​10.1126/​science.aag2302
[6] G. Carleo, F. Becca, M. Schiró, and M. Fabrizio. Localization and glassy dynamics of many-body quantum systems. Sci. Rep., 2: 243, 2012. 10.1038/​srep00243.  https:/​/​doi.org/​10.1038/​srep00243
[7] G. Carleo, F. Becca, L. Sanchez-Palencia, S. Sorella, and M. Fabrizio. Light-cone effect and supersonic correlations in one- and two-dimensional bosonic superfluids. Phys. Rev. A, 89: 031602, 2014. 10.1103/​PhysRevA.89.031602.  https:/​/​doi.org/​10.1103/​PhysRevA.89.031602
[8] S. R. Clark. Unifying neural-network quantum states and correlator product states via tensor networks. J. Phys. A Math. Theor., 51: 135301, 2018. 10.1088/​1751-8121/​aaaaf2.  https:/​/​doi.org/​10.1088/​1751-8121/​aaaaf2
[9] S. Czischek, M. Gärttner, and T. Gasenzer. Quenches near Ising quantum criticality as a challenge for artificial neural networks. Phys. Rev. B, 98: 024311, 2018. 10.1103/​PhysRevB.98.024311.  https:/​/​doi.org/​10.1103/​PhysRevB.98.024311
[10] A. J. Daley, C. Kollath, U. Schollwöck, and G. Vidal. Time-dependent density-matrix renormalization-group using adaptive effective Hilbert spaces. J. Stat. Mech. Theory Exp., 2004: P04005, 2004. 10.1088/​1742-5468/​2004/​04/​p04005.  https:/​/​doi.org/​10.1088/​1742-5468/​2004/​04/​p04005
[11] D. Deng, X. Li, and S. Das Sarma. Quantum entanglement in neural network states. Phys. Rev. X, 7: 021021, 2017. 10.1103/​PhysRevX.7.021021.  https:/​/​doi.org/​10.1103/​PhysRevX.7.021021
[12] X. Gao and L.-M. Duan. Efficient representation of quantum many-body states with deep neural networks. Nat. Commun., 8: 662, 2017. 10.1038/​s41467-017-00705-2.  https:/​/​doi.org/​10.1038/​s41467-017-00705-2
[13] I. Glasser, N. Pancotti, M. August, I. D. Rodriguez, and J. I. Cirac. Neural-network quantum states, string-bond states, and chiral topological states. Phys. Rev. X, 8: 011006, 2018. 10.1103/​PhysRevX.8.011006.  https:/​/​doi.org/​10.1103/​PhysRevX.8.011006
[14] E. Hairer, C. Lubich, and G. Wanner. Geometric Numerical Integration. Structure-Preserving Algorithms for Ordinary Differential Equations. Springer-Verlag Berlin Heidelberg, 2006. 10.1007/​3-540-30666-8.  https:/​/​doi.org/​10.1007/​3-540-30666-8
[15] A. Hirose. Complex-Valued Neural Networks. Springer-Verlag Berlin Heidelberg, 2012. 10.1007/​978-3-642-27632-3.  https:/​/​doi.org/​10.1007/​978-3-642-27632-3
[16] M. Hochbruck and C. Lubich. Error analysis of Krylov methods in a nutshell. SIAM J. Sci. Comput., 19 (2): 695–701, 1998. 10.1137/​S1064827595290450.  https:/​/​doi.org/​10.1137/​S1064827595290450
[17] R. Kaubruegger, L. Pastori, and J. C. Budich. Chiral topological phases from artificial neural networks. Phys. Rev. B, 97: 195136, 2018. 10.1103/​PhysRevB.97.195136.  https:/​/​doi.org/​10.1103/​PhysRevB.97.195136
[18] D. P. Kingma and J. Ba. Adam: A method for stochastic optimization. In 3rd International Conference for Learning Representations, San Diego, 2015.
[19] Y. Levine, O. Sharir, N. Cohen, and A. Shashua. Quantum entanglement in deep learning architectures. Phys. Rev. Lett., 122: 065301, 2019. 10.1103/​PhysRevLett.122.065301.  https:/​/​doi.org/​10.1103/​PhysRevLett.122.065301
[20] J. Liesen and P. Tichý. Convergence analysis of Krylov subspace methods. GAMM-Mitteilungen, 27: 153–173, 2004. 10.1002/​gamm.201490008.  https:/​/​doi.org/​10.1002/​gamm.201490008
[21] Y. Nomura, A. S. Darmawan, Y. Yamaji, and M. Imada. Restricted Boltzmann machine learning for solving strongly correlated quantum systems. Phys. Rev. B, 96: 205152, 2017. 10.1103/​PhysRevB.96.205152.  https:/​/​doi.org/​10.1103/​PhysRevB.96.205152
[22] L. Pastori, R. Kaubruegger, and J. C. Budich. Generalized transfer matrix states from artificial neural networks. Phys. Rev. B, 99: 165123, 2019. 10.1103/​PhysRevB.99.165123.  https:/​/​doi.org/​10.1103/​PhysRevB.99.165123
[23] D. Poulin, A. Qarry, R. Somma, and F. Verstraete. Quantum simulation of time-dependent Hamiltonians and the convenient illusion of Hilbert space. Phys. Rev. Lett., 106: 170501, 2011. 10.1103/​PhysRevLett.106.170501.  https:/​/​doi.org/​10.1103/​PhysRevLett.106.170501
[24] M. Schmitt and M. Heyl. Quantum dynamics in transverse-field Ising models from classical networks. SciPost Phys., 4: 013, 2018. 10.21468/​SciPostPhys.4.2.013.  https:/​/​doi.org/​10.21468/​SciPostPhys.4.2.013
[25] M. Schmitt and M. Heyl. Quantum many-body dynamics in two dimensions with artificial neural networks. Phys. Rev. Lett., 125: 100503, 2020. 10.1103/​PhysRevLett.125.100503.  https:/​/​doi.org/​10.1103/​PhysRevLett.125.100503
[26] U. Schollwöck. The density-matrix renormalization group. Rev. Mod. Phys., 77: 259–315, 2005. 10.1103/​RevModPhys.77.259.  https:/​/​doi.org/​10.1103/​RevModPhys.77.259
[27] U. Schollwöck. The density-matrix renormalization group in the age of matrix product states. Ann. Phys., 326: 96–192, 2011. 10.1016/​j.aop.2010.09.012.  https:/​/​doi.org/​10.1016/​j.aop.2010.09.012
[28] A. Shrestha and A. Mahmood. Review of deep learning algorithms and architectures. IEEE Access, 7: 53040–53065, 2019. 10.1109/​ACCESS.2019.2912200.  https:/​/​doi.org/​10.1109/​ACCESS.2019.2912200
[29] S. Sorella. Generalized Lanczos algorithm for variational quantum Monte Carlo. Phys. Rev. B, 64: 024512, 2001. 10.1103/​PhysRevB.64.024512.  https:/​/​doi.org/​10.1103/​PhysRevB.64.024512
[30] S. Suzuki, J. Inoue, and B. K. Chakrabarti. Quantum Ising Phases and Transitions in Transverse Ising Models. Springer, Berlin, Heidelberg, 2013. ISBN 978-3-642-33039-1. 10.1007/​978-3-642-33039-1.  https:/​/​doi.org/​10.1007/​978-3-642-33039-1
[31] C. Trabelsi, O. Bilaniuk, Y. Zhang, D. Serdyuk, S. Subramanian, J. F. Santos, S. Mehri, N. Rostamzadeh, Y. Bengio, and C. J. Pal. Deep complex networks. In International Conference on Learning Representations, 2018. URL https:/​/​openreview.net/​forum?id=H1T2hmZAb.  https:/​/​openreview.net/​forum?id=H1T2hmZAb
[32] V. N. Vapnik. An overview of statistical learning theory. IEEE Trans. Neural Netw., 10: 988–999, 1999. 10.1109/​72.788640.  https:/​/​doi.org/​10.1109/​72.788640
[33] G. Vidal. Efficient simulation of one-dimensional quantum many-body systems. Phys. Rev. Lett., 93: 040502, 2004. 10.1103/​PhysRevLett.93.040502.  https:/​/​doi.org/​10.1103/​PhysRevLett.93.040502
[34] S. R. White and A. E. Feiguin. Real-time evolution using the density matrix renormalization group. Phys. Rev. Lett., 93: 076401, 2004. 10.1103/​PhysRevLett.93.076401.  https:/​/​doi.org/​10.1103/​PhysRevLett.93.076401
Cited by
[1] John M. Martyn, Khadijeh Najafi, and Di Luo, "Variational Neural-Network Ansatz for Continuum Quantum Field Theory", Physical Review Letters 131 8, 081601 (2023) .
[2] Jannes Nys, Gabriel Pescia, Alessandro Sinibaldi, and Giuseppe Carleo, "Ab-initio variational wave functions for the time-dependent many-electron Schrödinger equation", Nature Communications 15 1, 9404 (2024) .
[3] Vinit Singh, Amandeep Singh Bhatia, Mandeep Kaur Saggi, Manas Sajjan, and Sabre Kais, "Quantum machine learning for complex systems: paradigms, applications, and challenges", Academia Quantum 3 2(2026) .
[4] Joseph Tindall, Antonio Francesco Mello, Matthew Fishman, E. Miles Stoudenmire, and Dries Sels, "Dynamics of disordered quantum systems with two- and three-dimensional tensor networks", Science 392 6800, 868 (2026) .
[5] Markus Schmitt and Moritz Reh, "jVMC: Versatile and performant variational Monte Carlo leveraging automated differentiation and GPU acceleration", SciPost Physics Codebases 2 (2022) .
[6] S. J. Thomson and J. Eisert, "Unravelling quantum dynamics using flow equations", Nature Physics 20 9, 1401 (2024) .
[7] Liam Bernheimer, Hristiana Atanasova, and Guy Cohen, "Determinant- and derivative-free quantum Monte Carlo within the stochastic representation of wavefunctions", Reports on Progress in Physics 87 11, 118001 (2024) .
[8] Jie Liu and Xin Wang, "Hamiltonian learning via inverse physics-informed neural networks", Physical Review Research 7 4, 043137 (2025) .
[9] Zheyu Wu, Remmy Zen, Heitor P. Casagrande, Dario Poletti, and Stéphane Bressan, "Supervised training of neural-network quantum states for the next-nearest neighbor Ising model", Computer Physics Communications 300, 109169 (2024) .
[10] Claudia Artiaco, Christoph Fleckenstein, David Aceituno Chávez, Thomas Klein Kvorning, and Jens H. Bardarson, "Efficient Large-Scale Many-Body Quantum Dynamics via Local-Information Time Evolution", PRX Quantum 5 2, 020352 (2024) .
[11] Ryui Kaneko and Ippei Danshita, "Dynamics of correlation spreading in low-dimensional transverse-field Ising models", Physical Review A 108 2, 023301 (2023) .
[12] Alessandro Sinibaldi, Douglas Hendry, Filippo Vicentini, and Giuseppe Carleo, "Time-Dependent Neural Galerkin Method for Quantum Dynamics", Physical Review Letters 136 12, 120402 (2026) .
[13] Shaojun Gui, Tak-San Ho, and Herschel Rabitz, "Discrete real-time learning of quantum-state subspace evolution of many-body systems in the presence of time-dependent control fields", Physical Review A 110 5, 052412 (2024) .
[14] Debanjan Konar, Dheeraj Peddireddy, Bijaya K. Panigrahi, and Vaneet Aggarwal, "Tensor ring optimized quantum-enhanced tensor neural networks", Quantum Machine Intelligence 7 1, 57 (2025) .
[15] Damian Hofmann, Giammarco Fabiani, Johan Mentink, Giuseppe Carleo, and Michael Sentef, "Role of stochastic noise and generalization error in the time propagation of neural-network quantum states", SciPost Physics 12 5, 165 (2022) .
[16] Wenxuan Zhang, Xiansong Xu, Zheyu Wu, Vinitha Balachandran, and Dario Poletti, "Ground state search by local and sequential updates of neural network quantum states", Physical... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [13]: B. Kloss et al. — Studying dynamics in two-dimensional quantum lattices using tree tensor network states (SciPost Phys. 9, 070, 2020)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Studying dynamics in two-dimensional quantum lattices using tree tensor network states
URL: https://doi.org/10.21468/SciPostPhys.9.5.070
[2003.08944] Studying dynamics in two-dimensional quantum lattices using tree tensor network states
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:2003.08944
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Strongly Correlated Electrons
arXiv:2003.08944 (cond-mat)
[Submitted on 19 Mar 2020 ( v1 ), last revised 18 Jul 2020 (this version, v3)]
Title: Studying dynamics in two-dimensional quantum lattices using tree tensor network states
Authors: Benedikt Kloss , Yevgeny Bar Lev , David R. Reichman
View a PDF of the paper titled Studying dynamics in two-dimensional quantum lattices using tree tensor network states, by Benedikt Kloss and 2 other authors
View PDF
Abstract: We analyze and discuss convergence properties of a numerically exact algorithm tailored to study the dynamics of interacting two-dimensional lattice systems. The method is based on the application of the time-dependent variational principle in a manifold of binary and quaternary Tree Tensor Network States. The approach is found to be competitive with existing matrix product state approaches. We discuss issues related to the convergence of the method, which could be relevant to a broader set of numerical techniques used for the study of two-dimensional systems.
Comments:  11 pages, 10 figures
Subjects:
Strongly Correlated Electrons (cond-mat.str-el) ; Quantum Physics (quant-ph)
Cite as:  arXiv:2003.08944 [cond-mat.str-el]
(or  arXiv:2003.08944v3 [cond-mat.str-el] for this version)
https://doi.org/10.48550/arXiv.2003.08944
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  SciPost Phys. 9, 070 (2020)
Related DOI :
https://doi.org/10.21468/SciPostPhys.9.5.070
Focus to learn more
DOI(s) linking to related resources
Submission history From: Yevgeny Bar Lev [ view email ]  [v1]  Thu, 19 Mar 2020 18:00:00 UTC (770 KB)
[v2]  Thu, 2 Apr 2020 20:55:33 UTC (693 KB)
[v3]  Sat, 18 Jul 2020 16:10:30 UTC (2,104 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Studying dynamics in two-dimensional quantum lattices using tree tensor network states, by Benedikt Kloss and 2 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.str-el
< prev
|  next >
new  |  recent  | 2020-03
Change to browse by:
cond-mat  quant-ph
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [14]: S. Paeckel et al. — Time-evolution methods for matrix-product states (Ann. Phys. 411, 167998, 2019)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Time-evolution methods for matrix-product states
URL: https://doi.org/10.1016/j.aop.2019.167998
[1901.05824] Time-evolution methods for matrix-product states
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:1901.05824
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Strongly Correlated Electrons
arXiv:1901.05824 (cond-mat)
[Submitted on 17 Jan 2019 ( v1 ), last revised 14 Nov 2019 (this version, v3)]
Title: Time-evolution methods for matrix-product states
Authors: Sebastian Paeckel , Thomas Köhler , Andreas Swoboda , Salvatore R. Manmana , Ulrich Schollwöck , Claudius Hubig
View a PDF of the paper titled Time-evolution methods for matrix-product states, by Sebastian Paeckel and 4 other authors
View PDF
Abstract: Matrix-product states have become the de facto standard for the representation of one-dimensional quantum many body states. During the last few years, numerous new methods have been introduced to evaluate the time evolution of a matrix-product state. Here, we will review and summarize the recent work on this topic as applied to finite quantum systems. We will explain and compare the different methods available to construct a time-evolved matrix-product state, namely the time-evolving block decimation, the MPO $W^\mathrm{II}$ method, the global Krylov method, the local Krylov method and the one- and two-site time-dependent variational principle. We will also apply these methods to four different representative examples of current problem settings in condensed matter physics.
Comments:  Content identical to final journal version, plus a table of contents and minus some formatting errors
Subjects:
Strongly Correlated Electrons (cond-mat.str-el) ; Statistical Mechanics (cond-mat.stat-mech); Quantum Physics (quant-ph)
Cite as:  arXiv:1901.05824 [cond-mat.str-el]
(or  arXiv:1901.05824v3 [cond-mat.str-el] for this version)
https://doi.org/10.48550/arXiv.1901.05824
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Annals of Physics 411, 167998 (2019)
Related DOI :
https://doi.org/10.1016/j.aop.2019.167998
Focus to learn more
DOI(s) linking to related resources
Submission history From: Claudius Hubig [ view email ]  [v1]  Thu, 17 Jan 2019 15:07:10 UTC (6,225 KB)
[v2]  Mon, 18 Feb 2019 13:49:05 UTC (6,073 KB)
[v3]  Thu, 14 Nov 2019 08:20:05 UTC (6,076 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Time-evolution methods for matrix-product states, by Sebastian Paeckel and 4 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.str-el
< prev
|  next >
new  |  recent  | 2019-01
Change to browse by:
cond-mat  cond-mat.stat-mech  quant-ph
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [15]: J. Wurtz, A. Polkovnikov, D. Sels — Cluster truncated Wigner approximation in strongly interacting systems (Ann. Phys. 395, 341-365, 2018)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Cluster Truncated Wigner Approximation in Strongly Interacting Systems
URL: https://doi.org/10.1016/j.aop.2018.06.001
[1804.10217] Cluster Truncated Wigner Approximation in Strongly Interacting Systems
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:1804.10217
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:1804.10217 (quant-ph)
[Submitted on 26 Apr 2018]
Title: Cluster Truncated Wigner Approximation in Strongly Interacting Systems
Authors: Jonathan Wurtz , Anatoli Polkovnikov , Dries Sels
View a PDF of the paper titled Cluster Truncated Wigner Approximation in Strongly Interacting Systems, by Jonathan Wurtz and 2 other authors
View PDF
Abstract: We present a general method by which linear quantum Hamiltonian dynamics with exponentially many degrees of freedom is replaced by approximate classical nonlinear dynamics with the number of degrees of freedom (phase space dimensionality) scaling polynomially in the system size. This method is based on generalization of the truncated Wigner approximation (TWA) to a higher dimensional phase space, where phase space variables are associated with a complete set of quantum operators spanning finite size clusters. The method becomes asymptotically exact with the increasing cluster size. The crucial feature of TWA is fluctuating initial conditions, which we approximate by a Gaussian distribution. We show that such fluctuations dramatically increase accuracy of TWA over traditional cluster mean field approximations. In this way we can treat on equal footing quantum and thermal fluctuations as well as compute entanglement and various equal and non-equal time correlation functions. The main limitation of the method is exponential scaling of the phase space dimensionality with the cluster size, which can be significantly reduced by using the language of Schwinger bosons and can likely be further reduced by truncating the local Hilbert space variables. We demonstrate the power of this method analyzing dynamics in various spin chains with and without disorder and show that we can capture such phenomena as long time hydrodynamic relaxation, many-body localization and the ballistic spread of entanglement.
Comments:  17 pages, 9 figures
Subjects:
Quantum Physics (quant-ph) ; Quantum Gases (cond-mat.quant-gas)
Cite as:  arXiv:1804.10217 [quant-ph]
(or  arXiv:1804.10217v1 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.1804.10217
Focus to learn more
arXiv-issued DOI via DataCite
Related DOI :
https://doi.org/10.1016/j.aop.2018.06.001
Focus to learn more
DOI(s) linking to related resources
Submission history From: Jonathan Wurtz [ view email ]  [v1]  Thu, 26 Apr 2018 18:01:18 UTC (570 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Cluster Truncated Wigner Approximation in Strongly Interacting Systems, by Jonathan Wurtz and 2 other authors
View PDF
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2018-04
Change to browse by:
cond-mat  cond-mat.quant-gas
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [16]: R. Khasseh et al. — Discrete truncated Wigner approach to dynamical phase transitions in Ising models (Phys. Rev. B 102, 014303, 2020)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Discrete truncated Wigner approach to dynamical phase transitions in Ising models after a quantum quench
URL: https://doi.org/10.1103/PhysRevB.102.014303
[2004.09812] Discrete truncated Wigner approach to dynamical phase transitions in Ising models after a quantum quench
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:2004.09812
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Quantum Gases
arXiv:2004.09812 (cond-mat)
[Submitted on 21 Apr 2020 ( v1 ), last revised 7 Jul 2020 (this version, v2)]
Title: Discrete truncated Wigner approach to dynamical phase transitions in Ising models after a quantum quench
Authors: Reyhaneh Khasseh , Angelo Russomanno , Markus Schmitt , Markus Heyl , Rosario Fazio
View a PDF of the paper titled Discrete truncated Wigner approach to dynamical phase transitions in Ising models after a quantum quench, by Reyhaneh Khasseh and 4 other authors
View PDF
Abstract: By means of the discrete truncated Wigner approximation we study dynamical phase transitions arising in the steady state of transverse-field Ising models after a quantum quench. Starting from a fully polarized ferromagnetic initial condition these transitions separate a phase with nonvanishing magnetization along the ordering direction from a symmetric phase upon increasing the transverse field. We consider two paradigmatic cases, a one-dimensional long-range model with power-law interactions $\propto 1/r^{\alpha}$ decaying algebraically as a function of distance $r$ and a two-dimensional system with short-range nearest-neighbour interactions. In the former case we identify dynamical phase transitions for $\alpha \lesssim 2$ and we extract the critical exponents from a data collapse of the steady state magnetization for up to 1200 lattice sites. We find identical exponents for $\alpha \lesssim 0.5$, suggesting that the dynamical transitions in this regime fall into the same universality class as the nonergodic mean-field limit. The two-dimensional Ising model is believed to be thermalizing, which we also confirm using exact diagonalization for small system sizes. Thus, the dynamical transition is expected to correspond to the thermal phase transition, which is consistent with our data upon comparing to equilibrium quantum Monte-Carlo simulations. We further test the accuracy of the discrete truncated Wigner approximation by comparing against numerically exact methods such as exact diagonalization, tensor network as well as artificial neural network states and we find good quantitative agreement on the accessible time scales. Finally, our work provides an additional contribution to the understanding of the range and the limitations of qualitative and quantitative applicability of the discrete truncated Wigner approximation.
Comments:  16 pages, 19 figures, version published in Physical Review B
Subjects:
Quantum Gases (cond-mat.quant-gas) ; Statistical Mechanics (cond-mat.stat-mech); Quantum Physics (quant-ph)
Cite as:  arXiv:2004.09812 [cond-mat.quant-gas]
(or  arXiv:2004.09812v2 [cond-mat.quant-gas] for this version)
https://doi.org/10.48550/arXiv.2004.09812
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. B 102, 014303 (2020)
Related DOI :
https://doi.org/10.1103/PhysRevB.102.014303
Focus to learn more
DOI(s) linking to related resources
Submission history From: Angelo Russomanno [ view email ]  [v1]  Tue, 21 Apr 2020 08:20:15 UTC (4,035 KB)
[v2]  Tue, 7 Jul 2020 13:44:43 UTC (4,313 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Discrete truncated Wigner approach to dynamical phase transitions in Ising models after a quantum quench, by Reyhaneh Khasseh and 4 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.quant-gas
< prev
|  next >
new  |  recent  | 2020-04
Change to browse by:
cond-mat  cond-mat.stat-mech  quant-ph
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [17]: A. Sinibaldi et al. — Unbiasing time-dependent Variational Monte Carlo by projected quantum evolution (Quantum 7, 1131, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Unbiasing time-dependent Variational Monte Carlo by projected quantum evolution
URL: https://doi.org/10.22331/q-2023-10-10-1131
Unbiasing time-dependent Variational Monte Carlo by projected quantum evolution – Quantum
Skip to content
the open journal for quantum science
Menu
Papers
Perspectives
Instructions
For authors
For referees
For editors
For authors of Views
Editorial policies
People
About
News
Mission and structure
Tools and open source
Code of Conduct
Outreach
Press
Contact
Unbiasing time-dependent Variational Monte Carlo by projected quantum evolution
Unbiasing time-dependent Variational Monte Carlo by projected quantum evolution  Alessandro Sinibaldi 1,2 , Clemens Giuliani 1,2 , Giuseppe Carleo 1,2 , and Filippo Vicentini 1,2,3  1 Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland 2 Center for Quantum Science and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland 3 CPHT, CNRS, École polytechnique, Institut Polytechnique de Paris, 91120 Palaiseau, France
Published: 2023-10-10, volume 7 , page 1131  Eprint: arXiv:2305.14294v3  Doi: https://doi.org/10.22331/q-2023-10-10-1131  Citation: Quantum 7, 1131 (2023).  Get full text pdf Read on arXiv Vanity Comment on Fermat's library  Find this paper interesting or want to discuss? Scite or leave a comment on SciRate .
Abstract We analyze the accuracy and sample complexity of variational Monte Carlo approaches to simulate the dynamics of many-body quantum systems classically. By systematically studying the relevant stochastic estimators, we are able to: (i) prove that the most used scheme, the time-dependent Variational Monte Carlo (tVMC), is affected by a systematic statistical bias or exponential sample complexity when the wave function contains some (possibly approximate) zeros, an important case for fermionic systems and quantum information protocols; (ii) show that a different scheme based on the solution of an optimization problem at each time step is free from such problems; (iii) improve the sample complexity of this latter approach by several orders of magnitude with respect to previous proofs of concept. Finally, we apply our advancements to study the high-entanglement phase in a protocol of non-Clifford unitary dynamics with local random measurements in 2D, first benchmarking on small spin lattices and then extending to large systems.
Featured image: Sketch of the failure of the tVMC when the state features zeros (red) and of the dynamics generated by the p-tVMC algorithm (blue). In p-tVMC, the optimization problem to solve consists in minimizing a distance in the Hilbert space, which is the infidelity I I (as shown in the right panel).
Popular summary  Monte Carlo variational methods are a powerful class of numerical techniques to simulate many-body quantum systems. While these algorithms have delivered state-of-the-art results for ground state search of frustrated and high-dimensional problems, variational calculations have yet to provide significant improvements over existing approaches for time evolution. Variational methods to simulate the quantum dynamics on classical or quantum hardware either integrate an explicit system of equations for the wave function parameters, the so-called time-dependent Variational Principle (TDVP), or implicitly solve a time-step optimization problem.
In this article, we first show that the classical implementation of TDVP, known as time-dependent Variational Monte Carlo (tVMC), can be affected by a statistical bias or an exponential sampling complexity when the wave function contains possibly approximate nodes. Second, we derive an extension of the implicit scheme that lowers its computational cost by several orders of magnitude and we name it projected tVMC (p-tVMC). In the final part, we apply the p-tVMC to investigate a system evolving via non-Clifford unitary dynamics with local random measurements in 2D, which is a paradigmatic model for entanglement phase transition that cannot be fully studied with other state-of-the-art techniques.
► BibTeX data
@article{Sinibaldi2023unbiasingtime,
doi = {10.22331/q-2023-10-10-1131},
url = {https://doi.org/10.22331/q-2023-10-10-1131},
title = {Unbiasing time-dependent {V}ariational {M}onte {C}arlo by projected quantum evolution},
author = {Sinibaldi, Alessandro and Giuliani, Clemens and Carleo, Giuseppe and Vicentini, Filippo},
journal = {{Quantum}},
issn = {2521-327X},
publisher = {{Verein zur F{\"{o}}rderung des Open Access Publizierens in den Quantenwissenschaften}},
volume = {7},
pages = {1131},
month = oct,
year = {2023}
} ► References
[1] I. M. Georgescu, S. Ashhab, and F. Nori. ``Quantum simulation''. Rev. Mod. Phys. 86, 153–185 (2014). doi: 10.1103/​RevModPhys.86.153.
https:/​/​doi.org/​10.1103/​RevModPhys.86.153
[2] F. Minganti, I. I. Arkhipov, A. Miranowicz, and F. Nori. ``Continuous dissipative phase transitions with or without symmetry breaking''. New Journal of Physics 23, 122001 (2021). doi: 10.1088/​1367-2630/​ac3db8.
https:/​/​doi.org/​10.1088/​1367-2630/​ac3db8
[3] M. A. Nielsen and I. L. Chuang. ``Quantum computation and quantum information: 10th anniversary edition''. Cambridge University Press. (2010). doi: 10.1017/​CBO9780511976667.
https:/​/​doi.org/​10.1017/​CBO9780511976667
[4] B. Skinner, J. Ruhman, and A. Nahum. ``Measurement-induced phase transitions in the dynamics of entanglement''. Phys. Rev. X 9, 031009 (2019). doi: 10.1103/​PhysRevX.9.031009.
https:/​/​doi.org/​10.1103/​PhysRevX.9.031009
[5] Y. Li, X. Chen, and M. P. A. Fisher. ``Measurement-driven entanglement transition in hybrid quantum circuits''. Phys. Rev. B 100, 134306 (2019). doi: 10.1103/​PhysRevB.100.134306.
https:/​/​doi.org/​10.1103/​PhysRevB.100.134306
[6] Q. Tang and W. Zhu. ``Measurement-induced phase transition: A case study in the nonintegrable model by density-matrix renormalization group calculations''. Phys. Rev. Res. 2, 013022 (2020). doi: 10.1103/​PhysRevResearch.2.013022.
https:/​/​doi.org/​10.1103/​PhysRevResearch.2.013022
[7] X. Turkeshi, R. Fazio, and M. Dalmonte. ``Measurement-induced criticality in ( 2 + 1 ) ( 2 + 1 ) -dimensional hybrid quantum circuits''. Phys. Rev. B 102, 014315 (2020). doi: 10.1103/​PhysRevB.102.014315.
https:/​/​doi.org/​10.1103/​PhysRevB.102.014315
[8] X. Turkeshi, A. Biella, R. Fazio, M. Dalmonte, and M. Schiró. ``Measurement-induced entanglement transitions in the quantum ising chain: From infinite to zero clicks''. Phys. Rev. B 103, 224210 (2021). doi: 10.1103/​PhysRevB.103.224210.
https:/​/​doi.org/​10.1103/​PhysRevB.103.224210
[9] A. Lavasani, Y. Alavirad, and M. Barkeshli. ``Topological order and criticality in ( 2 + 1 ) D ( 2 + 1 ) D monitored random quantum circuits''. Phys. Rev. Lett. 127, 235701 (2021). doi: 10.1103/​PhysRevLett.127.235701.
https:/​/​doi.org/​10.1103/​PhysRevLett.127.235701
[10] O. Lunt, M. Szyniszewski, and A. Pal. ``Measurement-induced criticality and entanglement clusters: A study of one-dimensional and two-dimensional clifford circuits''. Phys. Rev. B 104, 155111 (2021). doi: 10.1103/​PhysRevB.104.155111.
https:/​/​doi.org/​10.1103/​PhysRevB.104.155111
[11] H. Liu, T. Zhou, and X. Chen. ``Measurement-induced entanglement transition in a two-dimensional shallow circuit''. Phys. Rev. B 106, 144311 (2022). doi: 10.1103/​PhysRevB.106.144311.
https:/​/​doi.org/​10.1103/​PhysRevB.106.144311
[12] X. Turkeshi, M. Dalmonte, R. Fazio, and M. Schiró. ``Entanglement transitions from stochastic resetting of non-hermitian quasiparticles''. Phys. Rev. B 105, L241114 (2022). doi: 10.1103/​PhysRevB.105.L241114.
https:/​/​doi.org/​10.1103/​PhysRevB.105.L241114
[13] P. Sierant, M. Schiró, M. Lewenstein, and X. Turkeshi. ``Measurement-induced phase transitions in ( d + 1 ) ( d + 1 ) -dimensional stabilizer circuits''. Phys. Rev. B 106, 214316 (2022). doi: 10.1103/​PhysRevB.106.214316.
https:/​/​doi.org/​10.1103/​PhysRevB.106.214316
[14] J. C. Hoke et al. ``Quantum information phases in space-time: measurement-induced entanglement and teleportation on a noisy quantum processor'' (2023). arXiv:2303.04792.
arXiv:2303.04792
[15] S. R. White. ``Density matrix formulation for quantum renormalization groups''. Phys. Rev. Lett. 69, 2863–2866 (1992). doi: 10.1103/​PhysRevLett.69.2863.
https:/​/​doi.org/​10.1103/​PhysRevLett.69.2863
[16] R. Orús. ``A practical introduction to tensor networks: Matrix product states and projected entangled pair states''. Annals of physics 349, 117–158 (2014). doi: 10.1016/​j.aop.2014.06.013.
https:/​/​doi.org/​10.1016/​j.aop.2014.06.013
[17] D. Ceperley and B. Alder. ``Quantum monte carlo''. Science 231, 555–560 (1986). doi: 10.1126/​science.231.4738.555.
https:/​/​doi.org/​10.1126/​science.231.4738.555
[18] W. M. C. Foulkes, L. Mitas, R. J. Needs, and G. Rajagopal. ``Quantum monte carlo simulations of solids''. Rev. Mod. Phys. 73, 33–83 (2001). doi: 10.1103/​RevModPhys.73.33.
https:/​/​doi.org/​10.1103/​RevModPhys.73.33
[19] M. Troyer and U.-J. Wiese. ``Computational complexity and fundamental limitations to fermionic quantum monte carlo simulations''. Phys. Rev. Lett. 94, 170201 (2005). doi: 10.1103/​PhysRevLett.94.170201.
https:/​/​doi.org/​10.1103/​PhysRevLett.94.170201
[20] K. Choo, A. Mezzacapo, and G. Carleo. ``Fermionic neural-network states for ab-initio electronic structure''. Nature Communications 11 (2020). doi: 10.1038/​s41467-020-15724-9.
https:/​/​doi.org/​10.1038/​s41467-020-15724-9
[21] D. Pfau, J. S. Spencer, A. G. D. G. Matthews, and W. M. C. Foulkes. ``Ab initio solution of the many-electron schrödinger equation with deep neural networks''. Phys. Rev. Research 2, 033429 (2020). doi: 10.1103/​PhysRevResearch.2.033429.
https:/​/​doi.org/​10.1103/​PhysRevResearch.2.033429
[22] Y. Nomura, A. S. Darmawan, Y. Yamaji, and M. Imada. ``Restricted boltzmann machine learning for solving strongly correlated quantum systems''. Phys. Rev. B 96, 205152 (2017). doi: 10.1103/​PhysRevB.96.205152.
https:/​/​doi.org/​10.1103/​PhysRevB.96.205152
[23] J. Stokes, J. R. Moreno, E. A. Pnevmatikakis, and G. Carleo. ``Phases of two-dimensional spinless lattice fermions with first-quantized deep neural-network quantum states''. Phys. Rev. B 102, 205122 (2020). doi: 10.1103/​PhysRevB.102.205122.
https:/​/​doi.org/​10.1103/​PhysRevB.102.205122
[24] J. Nys and G. Carleo. ``Variational solutions to fermion-to-qubit mappings in two spatial dimensions''. Quantum 6, 833 (2022). doi: 10.22331/​q-2022-10-13-833.
https:/​/​doi.org/​10.22331/​q-2022-10-13-833
[25] K. Choo, T. Neupert, and G. Carleo. ``Two-dimensional frustrated J 1 {-} J 2 J 1 {-} J 2 model studied with neural network quantum states''. Phys. Rev. B 100, 125124 (2019). doi: 10.1103/​PhysRevB.100.125124.
https:/​/​doi.org/​10.1103/​PhysRevB.100.125124
[26] O. Sharir, Y. Levine, N. Wies, G. Carleo, and A. Shashua. ``Deep autoregressive models for the efficient variational simulation of many-body quantum systems''. Phys. Rev. Lett. 124, 020503 (2020). doi: 10.1103/​PhysRevLett.124.020503.
https:/​/​doi.org/​10.1103/​PhysRevLett.124.020503
[27] D. Wu et al. ``Variational benchmarks for quantum many-body problems'' (2023) arXiv:2302.04919.
arXiv:2302.04919
[28] W. L. McMillan. ``Ground state of liquid H e 4 H e 4 ''. Phys. Rev. 138, A442–A451 (1965). doi: 10.1103/​PhysRev.138.A442.
https:/​/​doi.org/​10.1103/​PhysRev.138.A442
[29] X. Yuan, S. Endo, Q. Zhao, Y. Li, and S. C. Benjamin. ``Theory of variational quantum simulation''. Quantum 3, 191 (2019). doi: 10.22331/​q-2019-10-07-191.
https:/​/​doi.org/​10.22331/​q-2019-10-07-191
[30] G. Carleo, F. Becca, M. Schiró, and M. Fabrizio. ``Localization and glassy dynamics of many-body quantum systems''. Scientific Reports 2 (2012). doi: 10.1038/​srep00243.
https:/​/​doi.org/​10.1038/​srep00243
[31] G. Carleo, L. Cevolani, L. Sanchez-Palencia, and M. Holzmann. ``Unitary dynamics of strongly interacting bose gases with the time-dependent variational monte carlo method in continuous space''. Phys. Rev. X 7, 031026 (2017). doi: 10.1103/​PhysRevX.7.031026.
https:/​/​doi.org/​10.1103/​PhysRevX.7.031026
[32] B. Jónsson, B. Bauer, and G. Carleo. ``Neural-network states for the classical simulation of quantum computing'' (2018). arXiv:1808.05232.
arXiv:1808.05232
[33] M. Medvidović and G. Carleo. ``Classical variational simulation of the quantum approximate optimization algorithm''. npj Quantum Information 7, 1–7 (2021). doi: 10.1038/​s41534-021-00440-z.
https:/​/​doi.org/​10.1038/​s41534-021-00440-z
[34] S. Barison, F. Vicentini, and G. Carleo. ``An efficient quantum algorithm for the time evolution of parameterized circuits''. Quantum 5, 512 (2021). doi: 10.22331/​q-2021-07-28-512.
https:/​/​doi.org/​10.22331/​q-2021-07-28-512
[35] K. Donatella, Z. Denis, A. Le Boité, and C. Ciuti. ``Dynamics with autoregressive neural quantum states: Application to critical quench dynamics''. Phys. Rev. A 108, 022210 (2023). doi: 10.1103/​PhysRevA.108.022210.
https:/​/​doi.org/​10.1103/​PhysRevA.108.022210
[36] I. L. Gutiérrez and C. B. Mendl. ``Real time evolution with neural-network quantum states''. Quantum 6, 627 (2022). doi: 10.22331/​q-2022-01-20-627.
https:/​/​doi.org/​10.22331/​q-2022-01-20-627
[37] M. Schmitt and M. Heyl. ``Quantum many-body dynamics in two dimensions with artificial neural networks''. Phys. Rev. Lett. 125, 100503 (2020). doi: 10.1103/​PhysRevLett.125.100503.
https:/​/​doi.org/​10.1103/​PhysRevLett.125.100503
[38] R. Verdel, M. Schmitt, Y.-P. Huang, P. Karpov, and M. Heyl. ``Variational classical networks for dynamics in interacting quantum matter''. Phys. Rev. B 103, 165103 (2021). doi: 10.1103/​PhysRevB.103.165103.
https:/​/​doi.org/​10.1103/​PhysRevB.103.165103
[39] M. Schmitt, M. M. Rams, J. Dziarmaga, M. Heyl, and W. H. Zurek. ``Quantum phase transition dynamics in the two-dimensional transverse-field ising model''. Science Advances 8, eabl6850 (2022). doi: 10.1126/​sciadv.abl6850.
https:/​/​doi.org/​10.1126/​sciadv.abl6850
[40] M. V. den Nest. ``Simulating quantum computers with probabilistic methods'' (2010). arXiv:0911.1624.
arXiv:0911.1624
[41] N. Moiseyev. ``Non-hermitian quantum mechanics''. Cambridge University Press. (2011). doi: 10.1017/​CBO9780511976186.
https:/​/​doi.org/​10.1017/​CBO9780511976186
[42] S. Haroche and J.-M. Raimond. ``Exploring the Quantum: Atoms, Cavities, and Photons''. Oxford University Press. (2006). doi: 10.1093/​acprof:oso/​9780198509141.001.0001.
https:/​/​doi.org/​10.1093/​acprof:oso/​9780198509141.001.0001
[43] A. McLachlan. ``A variational solution of the time-dependent schrodinger equation''. Molecular Physics 8, 39–44 (1964). doi: 10.1080/​00268976400100041.
https:/​/​doi.org/​10.1080/​00268976400100041
[44] J. Stokes, J. Izaac, N. Killoran, and G. Carleo. ``Quantum Natural Gradient''. Quantum 4, 269 (2020). doi: 10.22331/​q-2020-05-25-269.
https:/​/​doi.org/​10.22331/​q-2020-05-25-269
[45] C.-Y. Park and M. J. Kastoryano. ``Geometry of learning neural quantum states''. Phys. Rev. Res. 2, 023232 (2020). doi: 10.1103/​PhysRevResearch.2.023232.
https:/​/​doi.org/​10.1103/​PhysRevResearch.2.023232
[46] L. Hackl, T. Guaita, T. Shi, J. Haegeman, E. Demler, and J. I. Cirac. ``Geometry of variational methods: dynamics of closed quantum systems''. SciPost Phys. 9, 048 (2020). doi: 10.21468/​SciPostPhys.9.4.048.
https:/​/​doi.org/​10.21468/​SciPostPhys.9.4.048
[47] G. Carleo and M. Troyer. ``Solving the quantum many-body problem with artificial neural networks''. Science 355, 602–606 (2017). doi: 10.1126/​science.aag2302.
https:/​/​doi.org/​10.1126/​science.aag2302
[48] D. Luo and B. K. Clark. ``Backflow transformations via neural networks for quantum many-body wave functions''. Phys. Rev. Lett. 122, 226401 (2019). doi: 10.1103/​PhysRevLett.122.226401.
https:/​/​doi.org/​10.1103/​PhysRevLett.122.226401
[49] K. Mølmer, Y. Castin, and J. Dalibard. ``Monte carlo wave-function method in quantum optics''. J. Opt. Soc. Am. B 10, 524–538 (1993). doi: 10.1364/​JOSAB.10.000524.
https:/​/​doi.org/​10.1364/​JOSAB.10.000524
[50] H. M. Wiseman and G. J. Milburn. ``Quantum measurement and control''. Cambridge University Press. (2009). doi: 10.1017/​CBO9780511813948.
https:/​/​doi.org/​10.1017/​CBO9780511813948
[51] F. Minganti, D. Huybrechts, C. Elouard, F. Nori, and I. I. Arkhipov. ``Creating and controlling exceptional points of non-hermitian hamiltonians via homodyne lindbladian invariance''. Phys. Rev. A 106, 042210 (2022). doi: 10.1103/​PhysRevA.106.042210.
https:/​/​doi.org/​10.1103/​PhysRevA.106.042210
[52] S. Sorella, M. Casula, and D. Rocca. ``Weak binding between two aromatic rings: Feeling the van der Waals attraction by quantum Monte Carlo methods''. The Journal of Chemical Physics 127 (2007). doi: 10.1063/​1.2746035.
https:/​/​doi.org/​10.1063/​1.2746035
[53] F. Vicentini, A. Biella, N. Regnault, and C. Ciuti. ``Variational neural-network ansatz for steady states in open quantum systems''. Phys. Rev. Lett. 122, 250503 (2019). doi: 10.1103/​PhysRevLett.122.250503.
https:/​/​doi.org/​10.1103/​PhysRevLett.122.250503
[54] M. J. Hartmann and G. Carleo. ``Neural-network approach to dissipative quantum many-body dynamics''. Phys. Rev. Lett. 122, 250502 (2019). doi: 10.1103/​PhysRevLett.122.250502.
https:/​/​doi.org/​10.1103/​PhysRevLett.122.250502
[55] A. Nagy and V. Savona. ``Variational quantum monte carlo method with a neural-network ansatz for open quantum systems''. Phys. Rev. Lett. 122, 250501 (2019). doi: 10.1103/​PhysRevLett.122.250501.
https:/​/​doi.org/​10.1103/​PhysRevLett.122.250501
[56] M. Reh, M. Schmitt, and M. Gärttner. ``Time-dependent variational principle for open quantum systems with artificial neural networks''. Phys. Rev. Lett. 127, 230501 (2021). doi: 10.1103/​PhysRevLett.127.230501.
https:/​/​doi.org/​10.1103/​PhysRevLett.127.230501
[57] I. Sutskever, J. Martens, G. Dahl, and G. Hinton. ``On the importance of initialization and momentum in deep learning''. In S. Dasgupta and D. McAllester, editors, Proceedings of the 30th International Conference on Machine Learning. Volume 28 of Proceedings of Machine Learning Research, pages 1139–1147. Atlanta, Georgia, USA (2013). PMLR. url: https:/​/​proceedings.mlr.press/​v28/​sutskever13.html.
https:/​/​proceedings.mlr.press/​v28/​sutskever13.html
[58] D. P. Kingma and J. Ba. ``Adam: A method for stochastic optimization'' (2017). arXiv:1412.6980.
arXiv:1412.6980
[59] S.-i. Amari. ``Natural Gradient Works Efficiently in Learning''. Neural Computation 10, 251–276 (1998). doi: 10.1162/​089976698300017746.
https:/​/​doi.org/​10.1162/​089976698300017746
[60] S. Sorella. ``Wave function optimization in the variational monte carlo method''. Phys. Rev. B 71, 241103 (2005). doi: 10.1103/​PhysRevB.71.241103.
https:/​/​doi.org/​10.1103/​PhysRevB.71.241103
[61] J. Yan and D. Bacon. ``The k-local pauli commuting hamiltonians problem is in p'' (2012). arXiv:1203.3906.
arXiv:1203.3906
[62] H. F. Trotter. ``On the product of semi-groups of operators''. In Proceedings of the American Mathematical Society. Volume 151, pages 545–551. (1959). doi: 10.1090/​S0002-9939-1959-0108732-6.
https:/​/​doi.org/​10.1090/​S0002-9939-1959-0108732-6
[63] M. Suzuki. ``General theory of fractal path integrals with applications to many‐body theories and statistical physics''. Journal of Mathematical Physics 32, 400–407 (1991). doi: 10.1063/​1.529425.
https:/​/​doi.org/​10.1063/​1.529425
[64] R. Y. Rubinstein and D. P. Kroese. ``Simulation and the monte carlo method''. John Wiley & Sons. (2016). doi: 10.1002/​9781118631980.
https:/​/​doi.org/​10.1002/​9781118631980
[65] S. Mohamed, M. Rosca, M. Figurnov, and A. Mnih. ``Monte carlo gradient estimation in machine learning''. The Journal of Machine Learning Research 21, 5183–5244 (2020). url: http:/​/​jmlr.org/​papers/​v21/​19-346.html.
http:/​/​jmlr.org/​papers/​v21/​19-346.html
[66] D. Gottesman. ``The heisenberg representation of quantum computers'' (1998). arXiv:quant-ph/​9807006.
arXiv:quant-ph/9807006
[67] D. Luo, Z. Chen, K. Hu, Z. Zhao, V. M. Hur, and B. K. Clark. ``Gauge-invariant and anyonic-symmetric autoregressive neural network for quantum lattice models''. Phys. Rev. Res. 5, 013216 (2023). doi: 10.1103/​PhysRevResearch.5.013216.
https:/​/​doi.org/​10.1103/​PhysRevResearch.5.013216
[68] R. J. Elliott, P. Pfeuty, and C. Wood. ``Ising model with a transverse field''. Phys. Rev. Lett. 25, 443–446 (1970). doi: 10.1103/​PhysRevLett.25.443.
https:/​/​doi.org/​10.1103/​PhysRevLett.25.443
[69] M. S. L. du Croo de Jongh and J. M. J. van Leeuwen. ``Critical behavior of the two-dimensional ising model in a transverse field: A density-matrix renormalization calculation''. Phys. Rev. B 57, 8494–8500 (1998). doi: 10.1103/​PhysRevB.57.8494.
https:/​/​doi.org/​10.1103/​PhysRevB.57.8494
[70] H. Rieger and N. Kawashima. ``Application of a continuous time cluster algorithm to the two-dimensional random quantum ising ferromagnet''. The European Physical Journal B - Condensed Matter and Complex Systems 9, 233–236 (1999). doi: 10.1007/​s100510050761.
https:/​/​doi.org/​10.1007/​s100510050761
[71] H. W. J. Blöte and Y. Deng. ``Cluster monte carlo simulation of the transverse ising model''. Phys. Rev. E 66, 066110 (2002). doi: 10.1103/​PhysRevE.66.066110.
https:/​/​doi.org/​10.1103/​PhysRevE.66.066110
[72] A. F. Albuquerque, F. Alet, C. Sire, and S. Capponi. ``Quantum critical scaling of fidelity susceptibility''. Phys. Rev. B 81, 064418 (2010). doi: 10.1103/​PhysRevB.81.064418.
https:/​/​doi.org/​10.1103/​PhysRevB.81.064418
[73] M. B. Hastings, I. González, A. B. Kallin, and R. G. Melko. ``Measuring renyi entanglement entropy in quantum monte carlo simulations''. Phys. Rev. Lett. 104, 157201 (2010). doi: 10.1103/​PhysRevLett.104.157201.
https:/​/​doi.org/​10.1103/​PhysRevLett.104.157201
[74] D. N. Page. ``Average entropy of a subsystem''. Phys. Rev. Lett. 71, 1291–1294 (1993). doi: 10.1103/​PhysRevLett.71.1291.
https:/​/​doi.org/​10.1103/​PhysRevLett.71.1291
[75] S. Bravyi, M. B. Hastings, and F. Verstraete. ``Lieb-robinson bounds and the generation of correlations and topological quantum order''. Physical review letters 97, 050401 (2006). doi: 10.1103/​PhysRevLett.97.050401.
https:/​/​doi.org/​10.1103/​PhysRevLett.97.050401
[76] F. Vicentini et al. ``NetKet 3: Machine Learning Toolbox for Many-Body Quantum Systems''. SciPost Phys. CodebasesPage 7 (2022). doi: 10.21468/​SciPostPhysCodeb.7.
https:/​/​doi.org/​10.21468/​SciPostPhysCodeb.7
[77] G. Carleo et al. ``NetKet: A machine learning toolkit for many-body quantum systems''. SoftwareXPage 100311 (2019). doi: 10.1016/​j.softx.2019.100311.
https:/​/​doi.org/​10.1016/​j.softx.2019.100311
[78] D. Häfner and F. Vicentini. ``mpi4jax: Zero-copy MPI communication of JAX arrays''. Journal of Open Source Software 6 (2021). doi: 10.21105/​joss.03419.
https:/​/​doi.org/​10.21105/​joss.03419
[79] A. Sinibaldi and F. Vicentini. ``netket_fidelity package, v0.0.2''. doi: 10.5281/​zenodo.8344170.
https:/​/​doi.org/​10.5281/​zenodo.8344170
[80] V. Havlicek. ``Amplitude Ratios and Neural Network Quantum States''. Quantum 7, 938 (2023). doi: 10.22331/​q-2023-03-02-938.
https:/​/​doi.org/​10.22331/​q-2023-03-02-938
Cited by [1] Jannes Nys, Gabriel Pescia, Alessandro Sinibaldi, and Giuseppe Carleo, "Ab-initio variational wave functions for the time-dependent many-electron Schrödinger equation", Nature Communications 15 1, 9404 (2024) .
[2] Zechen Tang, Haoxiang Chen, Yang Li, Yubing Qian, Yuxiang Wang, Weizhong Fu, Jialin Li, Chen Si, Wenhui Duan, Ji Chen, and Yong Xu, "Deep-learning electronic structure calculations", Nature Computational Science 5 12, 1133 (2025) .
[3] Yantao Wu and Wen-Yuan Liu, "Accurate Gauge-Invariant Tensor-Network Simulations for Abelian Lattice Gauge Theory in (2+1)D: Ground-State and Real-Time Dynamics", Physical Review Letters 135 13, 130401 (2025) .
[4] Thomas Spriggs, Eliska Greplova, Juan Carrasquilla, and Jannes Nys, "Accurate Ground States of SU(2) Lattice Gauge Theory in 2+1D and 3+1D", Physical Review Letters 136 10, 101902 (2026) .
[5] Zhou-Quan Wan and Shiwei Zhang, "Addressing the infinite variance problem in fermionic Monte Carlo simulations: Retrospective error remediation and the exact bridge link method", Physical Review E 112 6, 065309 (2025) .
[6] Wenxuan Zhang, Bo Xing, Xiansong Xu, and Dario Poletti, "Paths towards time evolution with larger neural-network quantum states", Computer Physics Communications 312, 109577 (2025) .
[7] Eimantas Ledinauskas and Egidijus Anisimovas, "Scalable imaginary time evolution with neural network quantum states", SciPost Physics 15 6, 229 (2023) .
[8] Liam Bernheimer, Hristiana Atanasova, and Guy Cohen, "Determinant- and derivative-free quantum Monte Carlo within the stochastic representation of wavefunctions", Reports on Progress in Physics 87 11, 118001 (2024) .
[9] Jia-Qi Wang, Rong-Qiang He, and Zhong-Yi Lu, "Generalized Lanczos method for systematic optimization of neural-network quantum states", Physical Review B 113 8, 085120 (2026) .
[10] Tarun Advaith Kumar, Leon Balents, Timothy H. Hsieh, and Roger G. Melko, "Autoregressive typical thermal states", Annals of Physics 487, 170362 (2026) .
[11] Hannah Lange, Fabian Döschl, Juan Carrasquilla, and Annabelle Bohrdt, "Neural network approach to quasiparticle dispersions in doped antiferromagnets", Communications Physics 7 1, 187 (2024) .
[12] Joseph Tindall, Antonio Francesco Mello, Matthew Fishman, E. Miles Stoudenmire, and Dries Sels, "Dynamics of disordered quantum systems with two- and three-dimensional tensor networks", Science 392 6800, 868 (2026) .
[13] Sara Santos, Xinyu Song, and Vincenzo Savona, "Low-Rank Variational Quantum Algorithm for the Dynamics of Open Quantum Systems", Quantum 9, 1620 (2025) .
[14] Shaojun Gui, Tak-San Ho, and Herschel Rabitz, "Control simulations of many-body quantum systems by a synergism of discrete real-time learning and optimal control theory", The Journal of Chemical Physics 163 10, 104108 (2025) .
[15] Jannes Nys, Zakari Denis, and Giuseppe Carleo, "Real-time quantum dynamics of thermal states with neural thermofields", Physical Review B 109 23, 235120 (2024) .
[16] Ashish Joshi, Robert Peters, and Thore Posske, "Quantum skyrmion dynamics studied by neural network quantum states", Physical Review B 110 10, 104411 (2024) .
[17] Haimeng Zhao, Giuseppe Carleo, and Filippo Vicentini, "Empirical Sample Complexity of Neural Network Mixed State Reconstruction", Quantum 8, 1358 (2024) .
[18] Bizi Huang, Weizhong Fu, and Ji Chen, "Stochastic representation of time-evolving neural network-based wavefunctions", The Journal of Chemical Physics 163 24, 244107 (2025) .
[19] Alessandro Sinibaldi, Antonio Francesco Mello, Mario Collura, and Giuseppe Carleo, "Nonstabilizerness of neural quantum states", Physical Review Research 7 4, 043289 (2025) .
[20] Matteo Acciai, Liliana Arrachea, and Janine Splettstoesser, "Quantum transport phenomena induced by time-dependent fields", La Rivista del Nuovo Cimento 48 10, 653 (2025) .
[21] Anka Van de Walle, Markus Schmitt, and Annabelle Bohrdt, "Many-body dynamics with explicitly time-dependent neural quantum states", Machine Learning: Science and Technology 6 4, 045011 (2025) .
[22] Tatiana Vovk, Anka Van de Walle, Hannes Pichler, and Annabelle Bohrdt, "Neural quantum states for emitter dynamics in waveguide QED", Physical Review A 113 5, 053708 (2026) .
[23] Massimo Bortone, Yannic Rath, and George H. Booth, "Impact of conditional modelling for a universal autoregressive quantum state", Quantum 8, 1245 (2024) .
[24] Wladislaw Krinitsin, Niklas Tausendpfund, Markus Heyl, Matteo Rizzi, and Markus Schmitt, "Time evolution of the quantum Ising model in two dimensions using tree tensor networks", Physical Review B 112 13, 134310 (2025) .
[25] Adrien Kahn, Luca Gravina, and Filippo Vicentini, "Variational subspace methods and application to improving variational Monte Carlo dynamics", Quantum 10, 2082 (2026) .
[26] Gian Gentinetta, Friederike Metz, and Giuseppe Carleo, "Correcting and Extending Trotterized Quantum Many-Body Dynamics", PRX Quantum 6 3, 030361 (2025) .
[27] Elad Parnes, Nir Barnea, Giuseppe Carleo, Alessandro Lovato, Noemi Rocco, and Xilin Zhang, "Nuclear Responses with Neural-Network Quantum States", Physical Review Letters 136 3, 032501 (2026) .
[28] Johannes Christmann, Petr Ivashkov, Mattia Chiurco, and Guglielmo Mazzola, "From quantum-enhanced to quantum-inspired Monte Carlo", Physical Review A 111 4, 042615 (2025) .
[29] Dennis Wagner, Andreas Klümper, and Jesko Sirker, "Thermodynamics based on neural networks", Physical Review B 109 15, 155128 (2024) .
[30] Sidhartha Dash, Luca Gravina, Filippo Vicentini, Michel Ferrero, and Antoine Georges, "Efficiency of neural quantum states in light of the quantum geometric tensor", Communications Physics 8 1, 92 (2025) .
[31] Shaojun Gui, Tak-San Ho, and Herschel Rabitz, "Discrete real-time learning of quantum-state subspace evolution of many-body systems in the presence of time-dependent control fields", Physical Review A 110 5, 052412 (2024) .
[32] Linda Mauron, Zakari Denis, Jannes Nys, and Giuseppe Carleo, "Predicting topological entanglement entropy in a Rydberg analogue simulator", Nature Physics 21 8, 1332 (2025) .
[33] Raffaele Salioni, Rocco Martinazzo, Davide Emilio Galli, and Christian Apostoli, "Adaptive quantum dynamics with the time-dependent variational Monte Carlo method", Physical Review B 113 1, 014408 (2026) .
[34] Brandon Barton, Juan Carrasquilla, Christopher Roth, and Agnes Valenti, "Connectivity determines the capability of sparse neural network quantum states", Machine Learning: Science and Technology 7 3, 035025 (2026) .
[35] Zhuo Chen and Di Luo, 2024 IEEE 6th International Conference on Trust, Privacy and Security in Intelligent Systems, and Applications (TPS-ISA) 516 (2024) ISBN:979-8-3503-8674-5 .
[36] Luca Gravina, Vincenzo Savona, and Filippo Vicentini, "Neural Projected Quantum Dynamics: a systematic study", Quantum 9, 1803 (2025) .
[37] Matija Medvidović and Javier Robledo Moreno, "Neural-network quantum states for many-body physics", The European Physical Journal Plus 139 7, 631 (2024) .
[38] David Linteau, Gabriel Pescia, Jannes Nys, Giuseppe Carleo, and Markus Holzmann, "Phase Diagram and Crystal Melting of Helium-4 in Two Dimensions", Physical Review Letters 134 24, 246001 (2025) .
[39] Alessandro Sinibaldi, Douglas Hendry, Filippo Vicentini, and Giuseppe Carleo, "Time-Dependent Neural Galerkin Method for Quantum Dynamics", Physical Review Letters 136 12, 120402 (2026) .
[40] Andrew D. King, Alberto Nocera, Marek M. Rams, Jacek Dziarmaga, Roeland Wiersema, William Bernoudy, Jack Raymond, Nitin Kaushal, Niclas Heinsdorf, Richard Harris, Kelly Boothby, Fabio Altomare, Mohsen Asad, Andrew J. Berkley, Martin Boschnak, Kevin Chern, Holly Christiani, Samantha Cibere, Jake Connor, Martin H. Dehn, Rahul Deshpande, Sara Ejtemaee, Pau Farre, Kelsey Hamer, Emile Hoskinson, Shuiyuan Huang, Mark W. Johnson, Samuel Kortas, Eric Ladizinsky, Trevor Lanting, Tony Lai, Ryan Li, Allison J. R. MacDonald, Gaelen Marsden, Catherine C. McGeoch, Reza Molavi, Travis Oh, Richard Neufeld, Mana Norouzpour, Joel Pasvolsky, Patrick Poitras, Gabriel Poulin-Lamarre, Thomas Prescott, Mauricio Reis, Chris Rich, Mohammad Samani, Benjamin Sheldan, Anatoly Smirnov, Edward Sterpka, Berta Trullas Clavera, Nicholas Tsai, Mark Volkmann, Alexander M. Whiticar, Jed D. Whittaker, Warren Wilkinson, Jason Yao, T. J. Yi, Anders W. Sandvik, Gonzalo Alvarez, Roger G. Melko, Juan Carrasquilla, Marcel Franz, and Mohammad H. Amin, "Beyond-classical computation in quantum simulation", Science 388 6743, 199 (2025) .
[41] Yaofeng Chen and Li You, "Optimal Control of Unknown Collective Spin Systems via a Neural Network Surrogate", Chinese Physics Letters 42 10, 100601 (2025) .
[42] Matthew Kiser, Matthias Beuerle, and Fedor Šimkovic, "Contextual Subspace Auxiliary-Field Quantum Monte Carlo: Improved Bias with Reduced Quantum Resources", Journal of Chemical Theory and Computation 21 5, 2256 (2025) .
[43] Rajah P. Nutakki, Ahmedeo Shokry, and Filippo Vicentini, "Design principles of deep translationally symmetric neural quantum states for frustrated magnets", Physical Review Research 7 4, 043099 (2025) .
[44] Antoine Misery, Luca Gravina, Alessandro Santini, and Filippo Vicentini, "Looking elsewhere: improving variational Monte Carlo gradients by importance sampling", Machine Learning: Science and Technology 7 1, 015035 (2026) .
[45] Joshua Lin, Di Luo, Xiaojun Yao, and Phiala E. Shanahan, "Real-time dynamics of the Schwinger model as an open quantum system with Neural Density Operators", Journal of High Energy Physics 2024 6, 211 (2024) .
[46] Anna Dawid, Julian Arnold, Borja Requena, Alexander Gresch, Marcin Płodzień, Kaelan Donatella, Kim A. Nicoli, Paolo Stornati, Rouven Koch, Miriam Büttner, Robert Okuła, Gorka Muñoz-Gil, Rodrigo A. Vargas-Hernández, Alba Cervera-Lierta, Juan Carrasquilla, Vedran Dunjko, Marylou Gabrié, Patrick Huembeli, Evert van Nieuwenburg, Filippo Vicentini, Lei Wang, Sebastian J. Wetzel, Giuseppe Carleo, Eliška Greplová, Roman Krems, Florian Marquardt, Michał Tomza, Maciej Lewenstein, and Alexandre Dauphin, "Modern applications of machine learning in quantum sciences", arXiv:2204.04198 , (2022) .
[47] Hannah Lange, Anka Van de Walle, Atiye Abedinnia, and Annabelle Bohrdt, "From architectures to applications: a review of neural quantum states", Quantum Science and Technology 9 4, 040501 (2024) .
[48] Tatiana Vovk, Anka Van de Walle, Hannes Pichler, and Annabelle Bohrdt, "Neural quantum states for emitter dynamics in waveguide QED", arXiv:2508.08964 , (2025) .
[49] Zheyu Wu, Remmy Zen, Heitor P. Casagrande, Dario Poletti, and Stéphane Bressan, "Supervised training of neural-network quantum states for the next-nearest neighbor Ising model", Computer Physics Communications 300, 109169 (2024) .
[50] Xiu-Zhe Luo, Di Luo, and Roger G. Melko, "Operator Learning Renormalization Group", arXiv:2403.03199 , (2024) .
[51] Elena Orlova, Aleksei Ustimenko, Ruoxi Jiang, Peter Y. Lu, and Rebecca Willett, "Deep Stochastic Mechanics", arXiv:2305.19685 , (2023) .
[52] Julien Gacon, "Scalable Quantum Algorithms for Noisy Quantum Computers", arXiv:2403.00940 , (2024) .
[53] Zhuo Chen, Jacob McCarran, Esteban Vizcaino, Marin Soljačić, and Di Luo, "TENG: Time-Evolving Natural Gradient for Solving PDEs With Deep Neural Nets Toward Machine Precision", arXiv:2404.10771 , (2024) .
[54] Hrvoje Vrcan and Johan H. Mentink, "Instability of explicit time integration for strongly quenched dynamics with neural quantum states", arXiv:2507.17421 , (2025) .
[55] Alessandro Lovato, Giuseppe Carleo, Bryce Fore, Morten Hjorth-Jensen, Jane Kim, Arnau Rios, and Noemi Rocco, "Neural-network quantum states for the nuclear many-body problem", arXiv:2602.13826 , (2026) .
[56] Stefano Barison, Filippo Vicentini, and Giuseppe Carleo, "Variational Embeddings for Many Body Quantum Systems", arXiv:2309.08666 , (2023) .
[57] Debbie Eeltink, Filippo Vicentini, and Vincenzo Savona, "Variational dynamics of open quantum systems in phase space", arXiv:2307.07429 , (2023) .
The above citations are from Crossref's cited-by service (last updated successfully 2026-05-30 12:57:21) and SAO/NASA ADS (last updated successfully 2026-05-30 12:57:27). The list may be incomplete as not all publishers provide suitable and complete citation data.
This Paper is published in Quantum under the Creative Commons Attribution 4.0 International (CC BY 4.0) license. Copyright remains with the original copyright holders such as the authors or their institutions.
Quantum is an open-access peer-reviewed journal for quantum science and related fields.
Quantum is non-profit and community-run: an effort by researchers and for researchers to make science more open and publishing more transparent and efficient.
Sign up for our monthly digest of papers and other news.  People Coordinating editors
Carlo Beenakker Eric Cavalcanti Sevag Gharibian Ujjwal Sen Ronald de Wolf
Editors
Elizabeth Agudelo Álvaro Alhambra Anurag Anshu Fabio Anza Mateus Araújo Remigiusz Augusiak Flavio Baccari Miriam Backens Aleksandrs Belovs Alessio Benavoli Kishor Bharti Andrea Di Biagio Cyril Branciard Michele Campisi Ángela Capel Angelo Carollo Marco Cerezo Ulysse Chabaud Francesco Ciccarello Ivan Contreras Luis A. Correa Eleanor Crane Borivoje Dakic Alexander Dalzell Abhinav Deshpande Yongshan Ding Vedran Dunjko Thomas Elliott Dax Enshan Koh Paul Erker Philippe Faist Di Fang Máté Farkas Nicolai Friis Christos Gagatsos Diego García-Martín Roohollah Ghobadi Géza Giedke Aaron Goldberg Daniel Grier Tom Gur Alioscia Hamma Felix Huber Isaac Kim Ravi Kunjwal Felix Leditzky Lorenzo Leone Tongyang Li Jin-Peng Liu Yuan Liu Maximilian Lock Leon Loveridge Tommaso Macrì Daniel Malz Atul Mantri Milad Marvian Daniel McNulty Pérola Milman Mark Mitchison Tomoyuki Morimae Ion Nechita Patrick Rebentrost Narayanan Rengaswamy Joschka Roffe Dennis Rätzel Krishna Kumar Sabapathy Mohan Sarovar Philipp Schindler Alexander Schuckert Gael Sentís Jiangwei Shang Changpeng Shao Kunal Sharma Himadri Shekhar Dhar Jens Siewert Paul Skrzypczyk Luca Tagliacozzo Philip Taranto Yu Tong Jordi Tura Michael Vasmer Petros Wallden Xin Wang John van de Wetering Alexander Wilce Pei Zeng
Executive Board
Christian Gogolin  Marcus Huber  Lídia del Rio
Steering Board
Antonio Acín Anne Broadbent Harry Buhrman Daniel Burgarth Guido Burkard Jens Eisert Steven Flammia Cassandra Granade Aram Harrow Khabat Heshami Chris Heunen Stacey Jeffery Shelby Kimmel Matthew Leifer Debbie Leung Chaoyang Lu Chiara Macchiavello Milan Mosonyi Ahsan Nazir Román Orús Joseph M. Renes Ana Maria Rey Anna Sanpera Jörg Schmiedmayer Urbasi Sinha John A. Smolin Robert W. Spekkens Aephraim M. Steinberg Francesca Vidotto Michael Walter Reinhard Werner Birgitta Whaley Witlef Wieczorek Andreas Winter Karol Życzkowski
Supporters
Support Quantum and
Memberships and Indexing
Feedback and discussion on /r/quantumjournal
Contact us by email .
© Verein zur Förderung des Open Access Publizierens in den Quantenwissenschaften .
Some rights reserved.
Terms and conditions
Impressum
Data protection and privacy policy
https://doi.org/10.22331/q
ISSN 2521-327X
Quantum practices open accounting .
This surveillance-free website does not collect cookies, track visitors, or sell their data.
Copyright © 2026 Quantum –  OnePress theme by FameThemes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [18]: F. Arute et al. — Quantum supremacy using a programmable superconducting processor (Nature 574, 505-510, 2019)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Quantum supremacy using a programmable superconducting processor
URL: https://doi.org/10.1038/s41586-019-1666-5
Quantum supremacy using a programmable superconducting processor | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes. By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection. See our privacy policy for more information on the use of your personal data. Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
articles
article
Quantum supremacy using a programmable superconducting processor
Download PDF
Article
Published: 23 October 2019
Quantum supremacy using a programmable superconducting processor
Frank Arute 1 ,  Kunal Arya 1 ,  Ryan Babbush 1 ,  Dave Bacon 1 ,  Joseph C. Bardin 1 , 2 ,  Rami Barends 1 ,  Rupak Biswas 3 ,  Sergio Boixo 1 ,  Fernando G. S. L. Brandao 1 , 4 ,  David A. Buell 1 ,  Brian Burkett 1 ,  Yu Chen 1 ,  Zijun Chen 1 ,  Ben Chiaro 5 ,  Roberto Collins 1 ,  William Courtney 1 ,  Andrew Dunsworth 1 ,  Edward Farhi 1 ,  Brooks Foxen 1 , 5 ,  Austin Fowler 1 ,  Craig Gidney 1 ,  Marissa Giustina 1 ,  Rob Graff 1 ,  Keith Guerin 1 ,  Steve Habegger 1 ,  Matthew P. Harrigan 1 ,  Michael J. Hartmann 1 , 6 ,  Alan Ho 1 ,  Markus Hoffmann 1 ,  Trent Huang 1 ,  Travis S. Humble 7 ,  Sergei V. Isakov 1 ,  Evan Jeffrey 1 ,  Zhang Jiang 1 ,  Dvir Kafri 1 ,  Kostyantyn Kechedzhi 1 ,  Julian Kelly 1 ,  Paul V. Klimov 1 ,  Sergey Knysh 1 ,  Alexander Korotkov 1 , 8 ,  Fedor Kostritsa 1 ,  David Landhuis 1 ,  Mike Lindmark 1 ,  Erik Lucero 1 ,  Dmitry Lyakh 9 ,  Salvatore Mandrà 3 , 10 ,  Jarrod R. McClean 1 ,  Matthew McEwen 5 ,  Anthony Megrant 1 ,  Xiao Mi 1 ,  Kristel Michielsen 11 , 12 ,  Masoud Mohseni 1 ,  Josh Mutus 1 ,  Ofer Naaman 1 ,  Matthew Neeley 1 ,  Charles Neill 1 ,  Murphy Yuezhen Niu 1 ,  Eric Ostby 1 ,  Andre Petukhov 1 ,  John C. Platt 1 ,  Chris Quintana 1 ,  Eleanor G. Rieffel 3 ,  Pedram Roushan 1 ,  Nicholas C. Rubin 1 ,  Daniel Sank 1 ,  Kevin J. Satzinger 1 ,  Vadim Smelyanskiy 1 ,  Kevin J. Sung 1 , 13 ,  Matthew D. Trevithick 1 ,  Amit Vainsencher 1 ,  Benjamin Villalonga 1 , 14 ,  Theodore White 1 ,  Z. Jamie Yao 1 ,  Ping Yeh 1 ,  Adam Zalcman 1 ,  Hartmut Neven 1 &  … John M. Martinis 1 , 5   Show authors
Nature
volume  574 ,  pages 505–510 ( 2019 ) Cite this article
1.33m Accesses
7509 Citations
6958 Altmetric
Metrics details
Abstract The promise of quantum computers is that certain computational tasks might be executed exponentially faster on a quantum processor than on a classical processor 1 . A fundamental challenge is to build a high-fidelity processor capable of running quantum algorithms in an exponentially large computational space. Here we report the use of a processor with programmable superconducting qubits 2 , 3 , 4 , 5 , 6 , 7 to create quantum states on 53 qubits, corresponding to a computational state-space of dimension 2 53 (about 10 16 ). Measurements from repeated experiments sample the resulting probability distribution, which we verify using classical simulations. Our Sycamore processor takes about 200 seconds to sample one instance of a quantum circuit a million times—our benchmarks currently indicate that the equivalent task for a state-of-the-art classical supercomputer would take approximately 10,000 years. This dramatic increase in speed compared to all known classical algorithms is an experimental realization of quantum supremacy 8 , 9 , 10 , 11 , 12 , 13 , 14 for this specific computational task, heralding a much-anticipated computing paradigm.
You have full access to this article via your institution.
Download PDF
Similar content being viewed by others
Boundaries of quantum supremacy via random circuit sampling
Article  Open access  11 April 2023
Hunting for quantum-classical crossover in condensed matter problems
Article  Open access  29 April 2024
Analyzing the performance of variational quantum factoring on a superconducting quantum processor
Article  Open access  28 October 2021
Main In the early 1980s, Richard Feynman proposed that a quantum computer would be an effective tool with which to solve problems in physics and chemistry, given that it is exponentially costly to simulate large quantum systems with classical computers 1 . Realizing Feynman’s vision poses substantial experimental and theoretical challenges. First, can a quantum system be engineered to perform a computation in a large enough computational (Hilbert) space and with a low enough error rate to provide a quantum speedup? Second, can we formulate a problem that is hard for a classical computer but easy for a quantum computer? By computing such a benchmark task on our superconducting qubit processor, we tackle both questions. Our experiment achieves quantum supremacy, a milestone on the path to full-scale quantum computing 8 , 9 , 10 , 11 , 12 , 13 , 14 . In reaching this milestone, we show that quantum speedup is achievable in a real-world system and is not precluded by any hidden physical laws. Quantum supremacy also heralds the era of noisy intermediate-scale quantum (NISQ) technologies 15 . The benchmark task we demonstrate has an immediate application in generating certifiable random numbers (S. Aaronson, manuscript in preparation); other initial uses for this new computational capability may include optimization 16 , 17 , machine learning 18 , 19 , 20 , 21 , materials science and chemistry 22 , 23 , 24 . However, realizing the full promise of quantum computing (using Shor’s algorithm for factoring, for example) still requires technical leaps to engineer fault-tolerant logical qubits 25 , 26 , 27 , 28 , 29 . To achieve quantum supremacy, we made a number of technical advances which also pave the way towards error correction. We developed fast, high-fidelity gates that can be executed simultaneously across a two-dimensional qubit array. We calibrated and benchmarked the processor at both the component and system level using a powerful new tool: cross-entropy benchmarking 11 . Finally, we used component-level fidelities to accurately predict the performance of the whole system, further showing that quantum information behaves as expected when scaling to large systems.
A suitable computational task To demonstrate quantum supremacy, we compare our quantum processor against state-of-the-art classical computers in the task of sampling the output of a pseudo-random quantum circuit 11 , 13 , 14 . Random circuits are a suitable choice for benchmarking because they do not possess structure and therefore allow for limited guarantees of computational hardness 10 , 11 , 12 . We design the circuits to entangle a set of quantum bits (qubits) by repeated application of single-qubit and two-qubit logical operations. Sampling the quantum circuit’s output produces a set of bitstrings, for example {0000101, 1011100, …}. Owing to quantum interference, the probability distribution of the bitstrings resembles a speckled intensity pattern produced by light interference in laser scatter, such that some bitstrings are much more likely to occur than others. Classically computing this probability distribution becomes exponentially more difficult as the number of qubits (width) and number of gate cycles (depth) grow. We verify that the quantum processor is working properly using a method called cross-entropy benchmarking 11 , 12 , 14 , which compares how often each bitstring is observed experimentally with its corresponding ideal probability computed via simulation on a classical computer. For a given circuit, we collect the measured bitstrings { x i } and compute the linear cross-entropy benchmarking fidelity 11 , 13 , 14 (see also  Supplementary Information ), which is the mean of the simulated probabilities of the bitstrings we measured: $${ {\mathcal F} }_{{\rm{XEB}}}={2}^{n}{\langle P({x}_{i})\rangle }_{i}-1$$
(1)
where n is the number of qubits, P ( x i ) is the probability of bitstring x i computed for the ideal quantum circuit, and the average is over the observed bitstrings. Intuitively, \({ {\mathcal F} }_{{\rm{XEB}}}\) is correlated with how often we sample high-probability bitstrings. When there are no errors in the quantum circuit, the distribution of probabilities is exponential (see Supplementary Information), and sampling from this distribution will produce \({{\mathscr{F}}}_{{\rm{X}}{\rm{E}}{\rm{B}}}=1\) . On the other hand, sampling from the uniform distribution will give ⟨ P ( x i ) ⟩ i  = 1/2 n and produce \({{\mathscr{F}}}_{{\rm{X}}{\rm{E}}{\rm{B}}}=0\) . Values of \({ {\mathcal F} }_{{\rm{XEB}}}\) between 0 and 1 correspond to the probability that no error has occurred while running the circuit. The probabilities P ( x i ) must be obtained from classically simulating the quantum circuit, and thus computing \({ {\mathcal F} }_{{\rm{XEB}}}\) is intractable in the regime of quantum supremacy. However, with certain circuit simplifications, we can obtain quantitative fidelity estimates of a fully operating processor running wide and deep quantum circuits. Our goal is to achieve a high enough \({ {\mathcal F} }_{{\rm{XEB}}}\) for a circuit with sufficient width and depth such that the classical computing cost is prohibitively large. This is a difficult task because our logic gates are imperfect and the quantum states we intend to create are sensitive to errors. A single bit or phase flip over the course of the algorithm will completely shuffle the speckle pattern and result in close to zero fidelity 11 (see also  Supplementary Information ). Therefore, in order to claim quantum supremacy we need a quantum processor that executes the program with sufficiently low error rates.
Building a high-fidelity processor We designed a quantum processor named ‘Sycamore’ which consists of a two-dimensional array of 54 transmon qubits, where each qubit is tunably coupled to four nearest neighbours, in a rectangular lattice. The connectivity was chosen to be forward-compatible with error correction using the surface code 26 . A key systems engineering advance of this device is achieving high-fidelity single- and two-qubit operations, not just in isolation but also while performing a realistic computation with simultaneous gate operations on many qubits. We discuss the highlights below; see also the  Supplementary Information . In a superconducting circuit, conduction electrons condense into a macroscopic quantum state, such that currents and voltages behave quantum mechanically 2 , 30 . Our processor uses transmon qubits 6 , which can be thought of as nonlinear superconducting resonators at 5–7 GHz. The qubit is encoded as the two lowest quantum eigenstates of the resonant circuit. Each transmon has two controls: a microwave drive to excite the qubit, and a magnetic flux control to tune the frequency. Each qubit is connected to a linear resonator used to read out the qubit state 5 . As shown in Fig. 1 , each qubit is also connected to its neighbouring qubits using a new adjustable coupler 31 , 32 . Our coupler design allows us to quickly tune the qubit–qubit coupling from completely off to 40 MHz. One qubit did not function properly, so the device uses 53 qubits and 86 couplers. Fig. 1: The Sycamore processor. The alternative text for this image may have been generated using AI. Full size image
a , Layout of processor, showing a rectangular array of 54 qubits (grey), each connected to its four nearest neighbours with couplers (blue). The inoperable qubit is outlined. b , Photograph of the Sycamore chip.
The processor is fabricated using aluminium for metallization and Josephson junctions, and indium for bump-bonds between two silicon wafers. The chip is wire-bonded to a superconducting circuit board and cooled to below 20 mK in a dilution refrigerator to reduce ambient thermal energy to well below the qubit energy. The processor is connected through filters and attenuators to room-temperature electronics, which synthesize the control signals. The state of all qubits can be read simultaneously by using a frequency-multiplexing technique 33 , 34 . We use two stages of cryogenic amplifiers to boost the signal, which is digitized (8 bits at 1 GHz) and demultiplexed digitally at room temperature. In total, we orchestrate 277 digital-to-analog converters (14 bits at 1 GHz) for complete control of the quantum processor. We execute single-qubit gates by driving 25-ns microwave pulses resonant with the qubit frequency while the qubit–qubit coupling is turned off. The pulses are shaped to minimize transitions to higher transmon states 35 . Gate performance varies strongly with frequency owing to two-level-system defects 36 , 37 , stray microwave modes, coupling to control lines and the readout resonator, residual stray coupling between qubits, flux noise and pulse distortions. We therefore optimize the single-qubit operation frequencies to mitigate these error mechanisms. We benchmark single-qubit gate performance by using the cross-entropy benchmarking protocol described above, reduced to the single-qubit level ( n  = 1), to measure the probability of an error occurring during a single-qubit gate. On each qubit, we apply a variable number m of randomly selected gates and measure \({ {\mathcal F} }_{{\rm{XEB}}}\) averaged over many sequences; as m increases, errors accumulate and average \({ {\mathcal F} }_{{\rm{XEB}}}\) decays. We model this decay by [1 −  e 1 /(1 − 1/ D 2 )] m where e 1 is the Pauli error probability. The state (Hilbert) space dimension term, D  = 2 n , which equals 2 for this case, corrects for the depolarizing model where states with errors partially overlap with the ideal state. This procedure is similar to the more typical technique of randomized benchmarking 27 , 38 , 39 , but supports non-Clifford-gate sets 40 and can separate out decoherence error from coherent control error. We then repeat the experiment with all qubits executing single-qubit gates simultaneously (Fig. 2 ), which shows only a small increase in the error probabilities, demonstrating that our device has low microwave crosstalk. Fig. 2: System-wide Pauli and measurement errors. The alternative text for this image may have been generated using AI. Full size image
a , Integrated histogram (empirical cumulative distribution function, ECDF) of Pauli errors (black, green, blue) and readout errors (orange), measured on qubits in isolation (dotted lines) and when operating all qubits simultaneously (solid). The median of each distribution occurs at 0.50 on the vertical axis. Average (mean) values are shown below. b , Heat map showing single- and two-qubit Pauli errors e 1 (crosses) and e 2 (bars) positioned in the layout of the processor. Values are shown for all qubits operating simultaneously.
We perform two-qubit iSWAP-like entangling gates by bringing neighbouring qubits on-resonance and turning on a 20-MHz coupling for 12 ns, which allows the qubits to swap excitations. During this time, the qubits also experience a controlled-phase (CZ) interaction, which originates from the higher levels of the transmon. The two-qubit gate frequency trajectories of each pair of qubits are optimized to mitigate the same error mechanisms considered in optimizing single-qubit operation frequencies. To characterize and benchmark the two-qubit gates, we run two-qubit circuits with m cycles, where each cycle contains a randomly chosen single-qubit gate on each of the two qubits followed by a fixed two-qubit gate. We learn the parameters of the two-qubit unitary (such as the amount of iSWAP and CZ interaction) by using \({ {\mathcal F} }_{{\rm{XEB}}}\) as a cost function. After this optimization, we extract the per-cycle error e 2 c from the decay of \({ {\mathcal F} }_{{\rm{XEB}}}\) with m , and isolate the two-qubit error e 2 by subtracting the two single-qubit errors e 1 . We find an average e 2 of 0.36%. Additionally, we repeat the same procedure while simultaneously running two-qubit circuits for the entire array. After updating the unitary parameters to account for effects such as dispersive shifts and crosstalk, we find an average e 2 of 0.62%. For the full experiment, we generate quantum circuits using the two-qubit unitaries measured for each pair during simultaneous operation, rather than a standard gate for all pairs. The typical two-qubit gate is a full iSWAP with 1/6th of a full CZ. Using individually calibrated gates in no way limits the universality of the demonstration. One can compose, for example, controlled-NOT (CNOT) gates from 1-qubit gates and two of the unique 2-qubit gates of any given pair. The implementation of high-fidelity ‘textbook gates’ natively, such as CZ or \(\sqrt{{\rm{iSWAP}}}\) , is work in progress. Finally, we benchmark qubit readout using standard dispersive measurement 41 . Measurement errors averaged over the 0 and 1 states are shown in Fig. 2a . We have also measured the error when operating all qubits simultaneously, by randomly preparing each qubit in the 0 or 1 state and then measuring all qubits for the probability of the correct result. We find that simultaneous readout incurs only a modest increase in per-qubit measurement errors. Having found the error rates of the individual gates and readout, we can model the fidelity of a quantum circuit as the product of the probabilities of error-free operation of all gates and measurements. Our largest random quantum circuits have 53 qubits, 1,113 single-qubit gates, 430 two-qubit gates, and a measurement on each qubit, for which we predict a total fidelity of 0.2%. This fidelity should be resolvable with a few million measurements, since the uncertainty on \({ {\mathcal F} }_{{\rm{XEB}}}\) is \(1/\sqrt{{N}_{{\rm{s}}}}\) , where N s is the number of samples. Our model assumes that entangling larger and larger systems does not introduce additional error sources beyond the errors we measure at the single- and two-qubit level. In the next section we will see how well this hypothesis holds up.
Fidelity estimation in the supremacy regime The gate sequence for our pseudo-random quantum circuit generation is shown in Fig. 3 . One cycle of the algorithm consists of applying single-qubit gates chosen randomly from \(\{\sqrt{X},\sqrt{Y},\sqrt{W}\}\) on all qubits, followed by two-qubit gates on pairs of qubits. The sequences of gates which form the ‘supremacy circuits’ are designed to minimize the circuit depth required to create a highly entangled state, which is needed for computational complexity and classical hardness. Fig. 3: Control operations for the quantum supremacy circuits. The alternative text for this image may have been generated using AI. Full size image
a , Example quantum circuit instance used in our experiment. Every cycle includes a layer each of single- and two-qubit gates. The single-qubit gates are chosen randomly from \(\{\sqrt{X},\sqrt{Y},\sqrt{W}\}\) , where  \(W=(X+Y)/\sqrt{2}\) and gates do not repeat sequentially. The sequence of two-qubit gates is chosen according to a tiling pattern, coupling each qubit sequentially to its four nearest-neighbour qubits. The couplers are divided into four subsets (ABCD), each of which is executed simultaneously across the entire array corresponding to shaded colours. Here we show an intractable sequence (repeat ABCDCDAB); we also use different coupler subsets along with a simplifiable sequence (repeat EFGHEFGH, not shown) that can be simulated on a classical computer. b , Waveform of control signals for single- and two-qubit gates.
Although we cannot compute \({ {\mathcal F} }_{{\rm{XEB}}}\) in the supremacy regime, we can estimate it using three variations to reduce the complexity of the circuits. In ‘patch circuits’, we remove a slice of two-qubit gates (a small fraction of the total number of two-qubit gates), splitting the circuit into two spatially isolated, non-interacting patches of qubits. We then compute the total fidelity as the product of the patch fidelities, each of which can be easily calculated. In ‘elided circuits’, we remove only a fraction of the initial two-qubit gates along the slice, allowing for entanglement between patches, which more closely mimics the full experiment while still maintaining simulation feasibility. Finally, we can also run full ‘verification circuits’, with the same gate counts as our supremacy circuits, but with a different pattern for the sequence of two-qubit gates, which is much easier to simulate classically (see also  Supplementary Information ). Comparison between these three variations allows us to track the system fidelity as we approach the supremacy regime. We first check that the patch and elided versions of the verification circuits produce the same fidelity as the full verification circuits up to 53 qubits, as shown in Fig. 4a . For each data point, we typically collect N s = 5 × 10 6 total samples over ten circuit instances, where instances differ only in the choices of single-qubit gates in each cycle. We also show predicted \({ {\mathcal F} }_{{\rm{XEB}}}\) values, computed by multiplying the no-error probabilities of single- and two-qubit gates and measurement (see also  Supplementary Information ). The predicted, patch and elided fidelities all show good agreement with the fidelities of the corresponding full circuits, despite the vast differences in computational complexity and entanglement. This gives us confidence that elided circuits can be used to accurately estimate the fidelity of more-complex circuits. Fig. 4: Demonstrating quantum supremacy. The alternative text for this image may have been generated using AI. Full size image
a , Verification of benchmarking methods. \({ {\mathcal F} }_{{\rm{XEB}}}\) values for patch, elided and full verification circuits are calculated from measured bitstrings and the corresponding probabilities predicted by classical simulation. Here, the two-qubit gates are applied in a simplifiable tiling and sequence such that the full circuits can be simulated out to n = 53, m = 14 in a reasonable amount of time. Each data point is an average over ten distinct quantum circuit instances that differ in their single-qubit gates (for n = 39, 42 and 43 only two instances were simulated). For each n , each instance is sampled with N s of 0.5–2.5 million. The black line shows the predicted \({ {\mathcal F} }_{{\rm{XEB}}}\) based on single- and two-qubit gate and measurement errors. The close correspondence between all four curves, despite their vast differences in complexity, justifies the use of elided circuits to estimate fidelity in the supremacy regime. b , Estimating \({ {\mathcal F} }_{{\rm{XEB}}}\) in the quantum supremacy regime. Here, the two-qubit gates are applied in a non-simplifiable tiling and sequence for which it is much harder to simulate. For the largest elided data ( n = 53, m = 20, total N s = 30 million), we find an average \({ {\mathcal F} }_{{\rm{XEB}}}\)  > 0.1% with 5 σ confidence, where σ includes both systematic and statistical uncertainties. The corresponding full circuit data, not simulated but archived, is expected to show similarly statistically significant fidelity. For m = 20, obtaining a million samples on the quantum processor takes 200 seconds, whereas an equal-fidelity classical sampling would take 10,000 years on a million cores, and verifying the fidelity would take millions of years.
The largest circuits for which the fidelity can still be directly verified have 53 qubits and a simplified gate arrangement. Performing random circuit sampling on these at 0.8% fidelity takes one million cores 130 seconds, corresponding to a million-fold speedup of the quantum processor relative to a single core. We proceed now to benchmark our computationally most difficult circuits, which are simply a rearrangement of the two-qubit gates. In Fig. 4b , we show the measured \({ {\mathcal F} }_{{\rm{XEB}}}\) for 53-qubit patch and elided versions of the full supremacy circuits with increasing depth. For the largest circuit with 53 qubits and 20 cycles, we collected N s  = 30 × 10 6 samples over ten circuit instances, obtaining \({ {\mathcal F} }_{{\rm{XEB}}}=(2.24\pm 0.21)\times {10}^{-3}\) for the elided circuits. With 5 σ confidence, we assert that the average fidelity of running these circuits on the quantum processor is greater than at least 0.1%. We expect that the full data for Fig. 4b should have similar fidelities, but since the simulation times (red numbers) take too long to check, we have archived the data (see ‘Data availability’ section). The data is thus in the quantum supremacy regime.
The classical computational cost We simulate the quantum circuits used in the experiment on classical computers for two purposes: (1) verifying our quantum processor and benchmarking methods by computing \({ {\mathcal F} }_{{\rm{XEB}}}\) where possible using simplifiable circuits (Fig. 4a ), and (2) estimating \({ {\mathcal F} }_{{\rm{XEB}}}\) as well as the classical cost of sampling our hardest circuits (Fig. 4b ). Up to 43 qubits, we use a Schrödinger algorithm, which simulates the evolution of the full quantum state; the Jülich supercomputer (with 100,000 cores, 250 terabytes) runs the largest cases. Above this size, there is not enough random access memory (RAM) to store the quantum state 42 . For larger qubit numbers, we use a hybrid Schrödinger–Feynman algorithm 43 running on Google data centres to compute the amplitudes of individual bitstrings. This algorithm breaks the circuit up into two patches of qubits and efficiently simulates each patch using a Schrödinger method, before connecting them using an approach reminiscent of the Feynman path-integral. Although it is more memory-efficient, the Schrödinger–Feynman algorithm becomes exponentially more computationally expensive with increasing circuit depth owing to the exponential growth of paths with the number of gates connecting the patches. To estimate the classical computational cost of the supremacy circuits (grey numbers in Fig. 4b ), we ran portions of the quantum circuit simulation on both the Summit supercomputer as well as on Google clusters and extrapolated to the full cost. In this extrapolation, we account for the computation cost of sampling by scaling the verification cost with \({ {\mathcal F} }_{{\rm{XEB}}}\) , for example 43 , 44 , a 0.1% fidelity decreases the cost by about 1,000. On the Summit supercomputer, which is currently the most powerful in the world, we used a method inspired by Feynman path-integrals that is most efficient at low depth 44 , 45 , 46 , 47 . At m  = 20 the tensors do not reasonably fit into node memory, so we can only measure runtimes up to m  = 14, for which we estimate that sampling three million bitstrings with 1% fidelity would require a year. On Google Cloud servers, we estimate that performing the same task for m  = 20 with 0.1% fidelity using the Schrödinger–Feynman algorithm would cost 50 trillion core-hours and consume one petawatt hour of energy. To put this in perspective, it took 600 seconds to sample the circuit on the quantum processor three million times, where sampling time is limited by control hardware communications; in fact, the net quantum processor time is only about 30 seconds. The bitstring samples from all circuits have been archived online (see ‘Data availability’ section) to encourage development and testing of more advanced verification algorithms. One may wonder to what extent algorithmic innovation can enhance classical simulations. Our assumption, based on insights from complexity theory 11 , 12 , 13 , is that the cost of this algorithmic task is exponential in circuit size. Indeed, simulation methods have improved steadily over the past few years 42 , 43 , 44 , 45 , 46 , 47 , 48 , 49 , 50 . We expect that lower simulation costs than reported here will eventually be achieved, but we also expect that they will be consistently outpaced by hardware improvements on larger quantum processors.
Verifying the digital error model A key assumption underlying the theory of quantum error correction is that quantum state errors may be considered digitized and localized 38 , 51 . Under such a digital model, all errors in the evolving quantum state may be characterized by a set of localized Pauli errors (bit-flips or phase-flips) interspersed into the circuit. Since continuous amplitudes are fundamental to quantum mechanics, it needs to be tested whether errors in a quantum system could be treated as discrete and probabilistic. Indeed, our experimental observations support the validity of this model for our processor. Our system fidelity is well predicted by a simple model in which the individually characterized fidelities of each gate are multiplied together (Fig. 4 ). To be successfully described by a digitized error model, a system should be low in correlated errors. We achieve this in our experiment by choosing circuits that randomize and decorrelate errors, by optimizing control to minimize systematic errors and leakage, and by designing gates that operate much faster than correlated noise sources, such as 1/ f flux noise 37 . Demonstrating a predictive uncorrelated error model up to a Hilbert space of size 2 53 shows that we can build a system where quantum resources, such as entanglement, are not prohibitively fragile.
The future Quantum processors based on superconducting qubits can now perform computations in a Hilbert space of dimension 2 53  ≈ 9 × 10 15 , beyond the reach of the fastest classical supercomputers available today. To our knowledge, this experiment marks the first computation that can be performed only on a quantum processor. Quantum processors have thus reached the regime of quantum supremacy. We expect that their computational power will continue to grow at a double-exponential rate: the classical cost of simulating a quantum circuit increases exponentially with computational volume, and hardware improvements will probably follow a quantum-processor equivalent of Moore’s law 52 , 53 , doubling this computational volume every few years. To sustain the double-exponential growth rate and to eventually offer the computational volume needed to run well known quantum algorithms, such as the Shor or Grover algorithms 25 , 54 , the engineering of quantum error correction will need to become a focus of attention. The extended Church–Turing thesis formulated by Bernstein and Vazirani 55 asserts that any ‘reasonable’ model of computation can be efficiently simulated by a Turing machine. Our experiment suggests that a model of computation may now be available that violates this assertion. We have performed random quantum circuit sampling in polynomial time using a physically realizable quantum processor (with sufficiently low error rates), yet no efficient method is known to exist for classical computing machinery. As a result of these developments, quantum computing is transitioning from a research topic to a technology that unlocks new computational capabilities. We are only one creative algorithm away from valuable near-term applications.
Data availability
The datasets generated and analysed for this study are available at our public Dryad repository ( https://doi.org/10.5061/dryad.k6t1rj8 ).
References Feynman, R. P. Simulating physics with computers. Int. J. Theor. Phys . 21 , 467–488 (1982). Article   MathSciNet
Google Scholar
Devoret, M. H., Martinis, J. M. & Clarke, J. Measurements of macroscopic quantum tunneling out of the zero-voltage state of a current-biased Josephson junction. Phys. Rev. Lett . 55 , 1908 (1985). Article   CAS   ADS
Google Scholar
Nakamura, Y., Chen, C. D. & Tsai, J. S. Spectroscopy of energy-level splitting between two macroscopic quantum states of charge coherently superposed by Josephson coupling. Phys. Rev. Lett . 79 , 2328 (1997). Article   CAS   ADS
Google Scholar
Mooij, J. et al. Josephson persistent-current qubit. Science 285 , 1036–1039 (1999). Article   CAS
Google Scholar
Wallraff, A. et al. Strong coupling of a single photon to a superconducting qubit using circuit quantum electrodynamics. Nature 431 , 162–167 (2004). Article   CAS   ADS
Google Scholar
Koch, J. et al. Charge-insensitive qubit design derived from the Cooper pair box. Phys. Rev. A 76 , 042319 (2007). Article   ADS
Google Scholar
You, J. Q. & Nori, F. Atomic physics and quantum optics using superconducting circuits. Nature 474 , 589–597 (2011). Article   CAS   ADS
Google Scholar
Preskill, J. Quantum computing and the entanglement frontier. Rapporteur Talk at the 25th Solvay Conference on Physics, Brussels https://doi.org/10.1142/8674 (World Scientific, 2012).
Aaronson, S. & Arkhipov, A. The computational complexity of linear optics. In Proc. 43rd Ann. Symp. on Theory of Computing https://doi.org/10.1145/1993636.1993682 (ACM, 2011).
Bremner, M. J., Montanaro, A. & Shepherd, D. J. Average-case complexity versus approximate simulation of commuting quantum computations. Phys. Rev. Lett . 117 , 080501 (2016). Article   ADS   MathSciNet
Google Scholar
Boixo, S. et al. Characterizing quantum supremacy in near-term devices. Nat. Phys . 14 , 595 (2018). Article   CAS
Google Scholar
Bouland, A., Fefferman, B., Nirkhe, C. & Vazirani, U. On the complexity and verification of quantum random circuit sampling. Nat. Phys . 15 , 159 (2019). Article   CAS
Google Scholar
Aaronson, S. & Chen, L. Complexity-theoretic foundations of quantum supremacy experiments. In 32nd Computational Complexity Conf . https://doi.org/10.4230/LIPIcs.CCC.2017.22 (Schloss Dagstuhl–Leibniz Zentrum für Informatik, 2017).
Neill, C. et al. A blueprint for demonstrating quantum supremacy with superconducting qubits. Science 360 , 195–199 (2018). Article   CAS   ADS   MathSciNet
Google Scholar
Preskill, J. Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article
Google Scholar
Kechedzhi, K. et al. Efficient population transfer via non-ergodic extended states in quantum spin glass. In 13th Conf. on the Theory of Quantum Computation, Communication and Cryptography http://drops.dagstuhl.de/opus/volltexte/2018/9256/pdf/LIPIcs-TQC-2018-9.pdf (Schloss Dagstuhl–Leibniz Zentrum für Informatik, 2018).
Somma, R. D., Boixo, S., Barnum, H. & Knill, E. Quantum simulations of classical annealing processes. Phys. Rev. Lett . 101 , 130504 (2008). Article   CAS   ADS
Google Scholar
Farhi, E. & Neven, H. Classification with quantum neural networks on near term processors. Preprint at https://arxiv.org/abs/1802.06002 (2018).
McClean, J. R., Boixo, S., Smelyanskiy, V. N., Babbush, R. & Neven, H. Barren plateaus in quantum neural network training landscapes. Nat. Commun . 9 , 4812 (2018). Article   ADS
Google Scholar
Cong, I., Choi, S. & Lukin, M. D. Quantum convolutional neural networks. Nat. Phys . https://doi.org/10.1038/s41567-019-0648-8 (2019).
Bravyi, S., Gosset, D. & König, R. Quantum advantage with shallow circuits. Science 362 , 308–311 (2018). Article   CAS   ADS   MathSciNet
Google Scholar
Aspuru-Guzik, A., Dutoi, A. D., Love, P. J. & Head-Gordon, M. Simulated quantum computation of molecular energies. Science 309 , 1704–1707 (2005). Article   CAS   ADS
Google Scholar
Peruzzo, A. et al. A variational eigenvalue solver on a photonic quantum processor. Nat. Commun . 5 , 4213 (2014). Article   CAS   ADS
Google Scholar
Hempel, C. et al. Quantum chemistry calculations on a trapped-ion quantum simulator. Phys. Rev. X 8 , 031022 (2018). CAS
Google Scholar
Shor, P. W. Algorithms for quantum computation: discrete logarithms and factoring proceedings. In Proc. 35th Ann. Symp. on Foundations of Computer Science https://doi.org/10.1109/SFCS.1994.365700 (IEEE, 1994).
Fowler, A. G., Mariantoni, M., Martinis, J. M. & Cleland, A. N. Surface codes: towards practical large-scale quantum computation. Phys. Rev. A 86 , 032324 (2012). Article   ADS
Google Scholar
Barends, R. et al. Superconducting quantum circuits at the surface code threshold for fault tolerance. Nature 508 , 500–503 (2014). Article   CAS   ADS
Google Scholar
Córcoles, A. D. et al. Demonstration of a quantum error detection code using a square lattice of four superconducting qubits. Nat. Commun . 6 , 6979 (2015). Article   ADS
Google Scholar
Ofek, N. et al. Extending the lifetime of a quantum bit with error correction in superconducting circuits. Nature 536 , 441 (2016). Article   CAS   ADS
Google Scholar
Vool, U. & Devoret, M. Introduction to quantum electromagnetic circuits. Int. J. Circuit Theory Appl . 45 , 897–934 (2017). Article
Google Scholar
Chen, Y. et al. Qubit architecture with high coherence and fast tunable coupling circuits. Phys. Rev. Lett . 113 , 220502 (2014). Article   ADS
Google Scholar
Yan, F. et al. A tunable coupling scheme for implementing high-fidelity two-qubit gates. Phys. Rev. Appl . 10 , 054062 (2018). Article   CAS   ADS
Google Scholar
Schuster, D. I. et al. Resolving photon number states in a superconducting circuit. Nature 445 , 515 (2007). Article   CAS   ADS
Google Scholar
Jeffrey, E. et al. Fast accurate state measurement with superconducting qubits. Phys. Rev. Lett . 112 , 190504 (2014). Article   ADS
Google Scholar
Chen, Z. et al. Measuring and suppressing quantum state leakage in a superconducting qubit. Phys. Rev. Lett . 116 , 020501 (2016). Article   ADS
Google Scholar
Klimov, P. V. et al. Fluctuations of energy-relaxation times in superconducting qubits. Phys. Rev. Lett . 121 , 090502 (2018). Article   CAS   ADS
Google Scholar
Yan, F. et al. The flux qubit revisited to enhance coherence and reproducibility. Nat. Commun . 7 , 12964 (2016). Article   CAS   ADS
Google Scholar
Knill, E. et al. Randomized benchmarking of quantum gates. Phys. Rev. A 77 , 012307 (2008). Article   ADS
Google Scholar
Magesan, E., Gambetta, J. M. & Emerson, J. Scalable and robust randomized benchmarking of quantum processes. Phys. Rev. Lett . 106 , 180504 (2011). Article   ADS
Google Scholar
Cross, A. W., Magesan, E., Bishop, L. S., Smolin, J. A. & Gambetta, J. M. Scalable randomised benchmarking of non-Clifford gates. npj Quant. Inform . 2 , 16012 (2016).
Google Scholar
Wallraff, A. et al. Approaching unit visibility for control of a superconducting qubit with dispersive readout. Phys. Rev. Lett . 95 , 060501 (2005). Article   CAS   ADS
Google Scholar
De Raedt, H. et al. Massively parallel quantum computer simulator, eleven years later. Comput. Phys. Commun . 237 , 47–61 (2019). Article   ADS
Google Scholar
Markov, I. L., Fatima, A., Isakov, S. V. & Boixo, S. Quantum supremacy is both closer and farther than it appears. Preprint at https://arxiv.org/abs/1807.10749 (2018).
Villalonga, B. et al. A flexible high-performance simulator for the verification and benchmarking of quantum circuits implemented on real hardware. npj Quant. Inform . (in the press); preprint at https://arxiv.org/abs/1811.09599 (2018).
Boixo, S., Isakov, S. V., Smelyanskiy, V. N. & Neven, H. Simulation of low-depth quantum circuits as complex undirected graphical models. Preprint at https://arxiv.org/abs/1712.05384 (2017).
Chen, J., Zhang, F., Huang, C., Newman, M. & Shi, Y. Classical simulation of intermediate-size quantum circuits. Preprint at https://arxiv.org/abs/1805.01450 (2018).
Villalonga, B. et al. Establishing the quantum supremacy frontier with a 281 pflop/s simulation. Preprint at https://arxiv.org/abs/1905.00444 (2019).
Pednault, E. et al. Breaking the 49-qubit barrier in the simulation of quantum circuits. Preprint at https://arxiv.org/abs/1710.05867 (2017).
Chen, Z. Y. et al. 64-qubit quantum circuit simulation. Sci. Bull . 63 , 964–971 (2018). Article
Google Scholar
Chen, M.-C. et al. Quantum-teleportation-inspired algorithm for sampling large random quantum circuits. Preprint at https://arxiv.org/abs/1901.05003 (2019).
Shor, P. W. Scheme for reducing decoherence in quantum computer memory. Phys. Rev. A 52 , R2493–R2496 (1995). Article   CAS   ADS
Google Scholar
Devoret, M. H. & Schoelkopf, R. J. Superconducting circuits for quantum information: an outlook. Science 339 , 1169–1174 (2013). Article   CAS   ADS
Google Scholar
Mohseni, M. et al. Commercialize quantum technologies in five years. Nature 543 , 171 (2017). Article   CAS   ADS
Google Scholar
Grover, L. K. Quantum mechanics helps in searching for a needle in a haystack. Phys. Rev. Lett . 79 , 325 (1997). Article   CAS   ADS
Google Scholar
Bernstein, E. & Vazirani, U. Quantum complexity theory. In Proc. 25th Ann. Symp. on Theory of Computing https://doi.org/10.1145/167088.167097 (ACM, 1993).
Download references
Acknowledgements We are grateful to E. Schmidt, S. Brin, S. Pichai, J. Dean, J. Yagnik and J. Giannandrea for their executive sponsorship of the Google AI Quantum team, and for their continued engagement and support. We thank P. Norvig, J. Yagnik, U. Hölzle and S. Pichai for advice on the manuscript. We acknowledge K. Kissel, J. Raso, D. L. Yonge-Mallo, O. Martin and N. Sridhar for their help with simulations. We thank G. Bortoli and L. Laws for keeping our team organized. This research used resources from the Oak Ridge Leadership Computing Facility, which is a DOE Office of Science User Facility (supported by contract DE-AC05-00OR22725). A portion of this work was performed in the UCSB Nanofabrication Facility, an open access laboratory. R.B., S.M., and E.G.R. appreciate support from the NASA Ames Research Center and from the Air Force Research (AFRL) Information Directorate (grant F4HBKC4162G001). T.S.H. is supported by the DOE Early Career Research Program. The views and conclusions contained herein are those of the authors and should not be interpreted as necessarily representing the official policies or endorsements, either expressed or implied, of AFRL or the US government.
Author information Authors and Affiliations Google AI Quantum, Mountain View, CA, USA Frank Arute, Kunal Arya, Ryan Babbush, Dave Bacon, Joseph C. Bardin, Rami Barends, Sergio Boixo, Fernando G. S. L. Brandao, David A. Buell, Brian Burkett, Yu Chen, Zijun Chen, Roberto Collins, William Courtney, Andrew Dunsworth, Edward Farhi, Brooks Foxen, Austin Fowler, Craig Gidney, Marissa Giustina, Rob Graff, Keith Guerin, Steve Habegger, Matthew P. Harrigan, Michael J. Hartmann, Alan Ho, Markus Hoffmann, Trent Huang, Sergei V. Isakov, Evan Jeffrey, Zhang Jiang, Dvir Kafri, Kostyantyn Kechedzhi, Julian Kelly, Paul V. Klimov, Sergey Knysh, Alexander Korotkov, Fedor Kostritsa, David Landhuis, Mike Lindmark, Erik Lucero, Jarrod R. McClean, Anthony Megrant, Xiao Mi, Masoud Mohseni, Josh Mutus, Ofer Naaman, Matthew Neeley, Charles Neill, Murphy Yuezhen Niu, Eric Ostby, Andre Petukhov, John C. Platt, Chris Quintana, Pedram Roushan, Nicholas C. Rubin, Daniel Sank, Kevin J. Satzinger, Vadim Smelyanskiy, Kevin J. Sung, Matthew D. Trevithick, Amit Vainsencher, Benjamin Villalonga, Theodore White, Z. Jamie Yao, Ping Yeh, Adam Zalcman, Hartmut Neven & John M. Martinis
Department of Electrical and Computer Engineering, University of Massachusetts Amherst, Amherst, MA, USA Joseph C. Bardin
Quantum Artificial Intelligence Laboratory (QuAIL), NASA Ames Research Center, Moffett Field, CA, USA Rupak Biswas, Salvatore Mandrà & Eleanor G. Rieffel
Institute for Quantum Information and Matter, Caltech, Pasadena, CA, USA Fernando G. S. L. Brandao
Department of Physics, University of California, Santa Barbara, CA, USA Ben Chiaro, Brooks Foxen, Matthew McEwen & John M. Martinis
Friedrich-Alexander University Erlangen-Nürnberg (FAU), Department of Physics, Erlangen, Germany Michael J. Hartmann
Quantum Computing Institute, Oak Ridge National Laboratory, Oak Ridge, TN, USA Travis S. Humble
Department of Electrical and Computer Engineering, University of California, Riverside, CA, USA Alexander Korotkov
Scientific Computing, Oak Ridge Leadership Computing, Oak Ridge National Laboratory, Oak Ridge, TN, USA Dmitry Lyakh
Stinger Ghaffarian Technologies Inc., Greenbelt, MD, USA Salvatore Mandrà
Institute for Advanced Simulation, Jülich Supercomputing Centre, Forschungszentrum Jülich, Jülich, Germany Kristel Michielsen
RWTH Aachen University, Aachen, Germany Kristel Michielsen
Department of Electrical Engineering and Computer Science, University of Michigan, Ann Arbor, MI, USA Kevin J. Sung
Department of Physics, University of Illinois at Urbana-Champaign, Urbana, IL, USA Benjamin Villalonga
Authors Frank Arute View author publications  Search author on: PubMed   Google Scholar
Kunal Arya View author publications  Search author on: PubMed   Google Scholar
Ryan Babbush View author publications  Search author on: PubMed   Google Scholar
Dave Bacon View author publications  Search author on: PubMed   Google Scholar
Joseph C. Bardin View author publications  Search author on: PubMed   Google Scholar
Rami Barends View author publications  Search author on: PubMed   Google Scholar
Rupak Biswas View author publications  Search author on: PubMed   Google Scholar
Sergio Boixo View author publications  Search author on: PubMed   Google Scholar
Fernando G. S. L. Brandao View author publications  Search author on: PubMed   Google Scholar
David A. Buell View author publications  Search author on: PubMed   Google Scholar
Brian Burkett View author publications  Search author on: PubMed   Google Scholar
Yu Chen View author publications  Search author on: PubMed   Google Scholar
Zijun Chen View author publications  Search author on: PubMed   Google Scholar
Ben Chiaro View author publications  Search author on: PubMed   Google Scholar
Roberto Collins View author publications  Search author on: PubMed   Google Scholar
William Courtney View author publications  Search author on: PubMed   Google Scholar
Andrew Dunsworth View author publications  Search author on: PubMed   Google Scholar
Edward Farhi View author publications  Search author on: PubMed   Google Scholar
Brooks Foxen View author publications  Search author on: PubMed   Google Scholar
Austin Fowler View author publications  Search author on: PubMed   Google Scholar
Craig Gidney View author publications  Search author on: PubMed   Google Scholar
Marissa Giustina View author publications  Search author on: PubMed   Google Scholar
Rob Graff View author publications  Search author on: PubMed   Google Scholar
Keith Guerin View author publications  Search author on: PubMed   Google Scholar
Steve Habegger View author publications  Search author on: PubMed   Google Scholar
Matthew P. Harrigan View author publications  Search author on: PubMed   Google Scholar
Michael J. Hartmann View author publications  Search author on: PubMed   Google Scholar
Alan Ho View author publications  Search author on: PubMed   Google Scholar
Markus Hoffmann View author publications  Search author on: PubMed   Google Scholar
Trent Huang View author publications  Search author on: PubMed   Google Scholar
Travis S. Humble View author publications  Search author on: PubMed   Google Scholar
Sergei V. Isakov View author publications  Search author on: PubMed   Google Scholar
Evan Jeffrey View author publications  Search author on: PubMed   Google Scholar
Zhang Jiang View author publications  Search author on: PubMed   Google Scholar
Dvir Kafri View author publications  Search author on: PubMed   Google Scholar
Kostyantyn Kechedzhi View author publications  Search author on: PubMed   Google Scholar
Julian Kelly View author publications  Search author on: PubMed   Google Scholar
Paul V. Klimov View author publications  Search author on: PubMed   Google Scholar
Sergey Knysh View author publications  Search author on: PubMed   Google Scholar
Alexander Korotkov View author publications  Search author on: PubMed   Google Scholar
Fedor Kostritsa View author publications  Search author on: PubMed   Google Scholar
David Landhuis View author publications  Search author on: PubMed   Google Scholar
Mike Lindmark View author publications  Search author on: PubMed   Google Scholar
Erik Lucero View author publications  Search author on: PubMed   Google Scholar
Dmitry Lyakh View author publications  Search author on: PubMed   Google Scholar
Salvatore Mandrà View author publications  Search author on: PubMed   Google Scholar
Jarrod R. McClean View author publications  Search author on: PubMed   Google Scholar
Matthew McEwen View author publications  Search author on: PubMed   Google Scholar
Anthony Megrant View author publications  Search author on: PubMed   Google Scholar
Xiao Mi View author publications  Search author on: PubMed   Google Scholar
Kristel Michielsen View author publications  Search author on: PubMed   Google Scholar
Masoud Mohseni View author publications  Search author on: PubMed   Google Scholar
Josh Mutus View author publications  Search author on: PubMed   Google Scholar
Ofer Naaman View author publications  Search author on: PubMed   Google Scholar
Matthew Neeley View author publications  Search author on: PubMed   Google Scholar
Charles Neill View author publications  Search author on: PubMed   Google Scholar
Murphy Yuezhen Niu View author publications  Search author on: PubMed   Google Scholar
Eric Ostby View author publications  Search author on: PubMed   Google Scholar
Andre Petukhov View author publications  Search author on: PubMed   Google Scholar
John C. Platt View author publications  Search author on: PubMed   Google Scholar
Chris Quintana View author publications  Search author on: PubMed   Google Scholar
Eleanor G. Rieffel View author publications  Search author on: PubMed   Google Scholar
Pedram Roushan View author publications  Search author on: PubMed   Google Scholar
Nicholas C. Rubin View author publications  Search author on: PubMed   Google Scholar
Daniel Sank View author publications  Search author on: PubMed   Google Scholar
Kevin J. Satzinger View author publications  Search author on: PubMed   Google Scholar
Vadim Smelyanskiy View author publications  Search author on: PubMed   Google Scholar
Kevin J. Sung View author publications  Search author on: PubMed   Google Scholar
Matthew D. Trevithick View author publications  Search author on: PubMed   Google Scholar
Amit Vainsencher View author publications  Search author on: PubMed   Google Scholar
Benjamin Villalonga View author publications  Search author on: PubMed   Google Scholar
Theodore White View author publications  Search author on: PubMed   Google Scholar
Z. Jamie Yao View author publications  Search author on: PubMed   Google Scholar
Ping Yeh View author publications  Search author on: PubMed   Google Scholar
Adam Zalcman View author publications  Search author on: PubMed   Google Scholar
Hartmut Neven View author publications  Search author on: PubMed   Google Scholar
John M. Martinis View author publications  Search author on: PubMed   Google Scholar
Contributions The Google AI Quantum team conceived the experiment. The applications and algorithms team provided the theoretical foundation and the specifics of the algorithm. The hardware team carried out the experiment and collected the data. The data analysis was done jointly with outside collaborators. All authors wrote and revised the manuscript and the Supplementary Information. Corresponding author Correspondence to John M. Martinis .
Ethics declarations
Competing interests
The authors declare no competing interests.
Additional information Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. Peer review information Nature thanks Scott Aaronson, Keisuke Fujii and William Oliver for their contribution to the peer review of this work.
Supplementary information
Supplementary Information (download PDF )  This file contains Supplementary Information I–XI, which contains supplementary figures S1–S44 and Supplementary Tables I–X
Rights and permissions Reprints and permissions
About this article
Cite this article Arute, F., Arya, K., Babbush, R. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). https://doi.org/10.1038/s41586-019-1666-5 Download citation  Received : 22 July 2019
Accepted : 20 September 2019
Published : 23 October 2019
Version of record : 23 October 2019
Issue date : 24 October 2019
DOI : https://doi.org/10.1038/s41586-019-1666-5
Share this article Anyone you share the following link with will be able to read this content: Get shareable link Sorry, a shareable link is not currently available for this article.
Copy shareable link to clipboard
Provided by the Springer Nature SharedIt content-sharing initiative
Subjects
Quantum information  Quantum physics
This article is cited by
Quantum-machine-assisted drug discovery
Yidong Zhou Jintai Chen Zhiding Liang
npj Drug Discovery (2026)
On the fundamental resource for exponential advantage in quantum channel learning
Minsoo Kim Changhun Oh
Nature Communications (2026)
Treespilation: architecture- and state-optimised fermion-to-qubit mappings
Aaron Miller Adam Glos Zoltán Zimborás
npj Quantum Information (2026)
A fully packaged cryogenic optical transmitter directly interfaced with a superconducting chip
Bozhi Yin Hayk Gevorgyan Vladimir M. Stojanović
Nature Electronics (2026)
Contextual quantum neural networks for stock price prediction
Sharan Mourya Hannes Leipold Bibhas Adhikari
Scientific Reports (2026)
Comments
Commenting on this article is now closed.
Nick Nick 23 October 2019, 13:54
2 gigabits of raw data given to us, but I thought they were gonna give us the qubits .
earld 23 October 2019, 17:17
IBM say not really..https:// www.ibm.com/blogs/research/...
Jaitan Martini 23 October 2019, 19:46
The IBM contestation is idiotic. This is not about surpassing classical computing in all dimensions.
John Stone 23 October 2019, 21:47
Quote: "Quantum supremacy is the potential ability of quantum computing devices to solve problems that classical computers practically cannot". If IBM's comments are true and they can do that in 2.5 days, then this is obviously NOT quantum supremacy.
sanitychecker 24 October 2019, 01:46
I don't care about the supremacy thing. What I want to know is this: as quantum computing comes of age, what does this mean for the future of encryption and computer security? Given all of the hype about quantum computers, it's not hard for me to imagine the day coming when a quantum computer can successfully break the code of an encryption string. After all, encryption is just high levels maths.
L Garou 24 October 2019, 02:13
Up next! Solving the still undeciphered Indus script.
Julio Chable Moreno 24 October 2019, 04:48
Es el nuevo mecanismo del futuro!!!
Majid 24 October 2019, 13:07
Beginning of "Quantum Supremacy"
killshot
Replied to Majid  15 December 2019, 15:31
You are not allowed to use that word, apparently. Hopefully all scientists are not suddenly looking for "safe spaces".
Majid
Replied to killshot  16 December 2019, 01:25
I cannot believe Nature has published such a childish viewpoint.
Sudipta Singh 24 October 2019, 17:59
The authors show how quickly a quantum computer can infer the state/entropy of random circuits. A practical application is to simulate matter itself as an aggregate of probability density functions. Viewing the Universe as information that varies over time is a paradigm that has applications in this space. My article on this paradigm is below. https://www.linkedin.com/pu...
Iaroslav Shcherbatyi 28 October 2019, 00:17
Looking forward to applications that powerful quantum processors will enable in future!
Sangin 28 October 2019, 13:25
There is no 16-Clue Sudoku. This computation actually took only about 800 processor-years. https://arxiv.org/abs/1201....  I am asking if your quantum processor will take less that a minute to do that and also if it can find all the valid 17-Clue sudoku?
killshot 15 December 2019, 15:33
Being concerned about the use of the word "supremacy" in a recent letter to Science tells me that these 13 signers need a very safe space most of the time. Which impeaches them -- to use a word -- as real "scientists". IOWs, gimme me a break.
You have full access to this article via your institution.
Download PDF
Associated content
Collection
Nobel Prize in Physics 2025
Quantum computing takes flight
William D. Oliver
Nature
News & Views
23 Oct 2019
Quantum supremacy: A three minute guide
Elizabeth Gibney
Nature
Nature Video
05 Nov 2019
Sections  Figures  References  Abstract  Main  A suitable computational task  Building a high-fidelity processor  Fidelity estimation in the supremacy regime  The classical computational cost  Verifying the digital error model  The future  Data availability  References  Acknowledgements  Author information  Ethics declarations  Additional information  Supplementary information  Rights and permissions  About this article  This article is cited by  Comments
Advertisement
Fig. 1: The Sycamore processor. View in article Full size image
Fig. 2: System-wide Pauli and measurement errors. View in article Full size image
Fig. 3: Control operations for the quantum supremacy circuits. View in article Full size image
Fig. 4: Demonstrating quantum supremacy. View in article Full size image
Feynman, R. P. Simulating physics with computers. Int. J. Theor. Phys . 21 , 467–488 (1982). Article   MathSciNet    Google Scholar
Devoret, M. H., Martinis, J. M. & Clarke, J. Measurements of macroscopic quantum tunneling out of the zero-voltage state of a current-biased Josephson junction. Phys. Rev. Lett . 55 , 1908 (1985). Article   CAS   ADS    Google Scholar
Nakamura, Y., Chen, C. D. & Tsai, J. S. Spectroscopy of energy-level splitting between two macroscopic quantum states of charge coherently superposed by Josephson coupling. Phys. Rev. Lett . 79 , 2328 (1997). Article   CAS   ADS    Google Scholar
Mooij, J. et al. Josephson persistent-current qubit. Science 285 , 1036–1039 (1999). Article   CAS    Google Scholar
Wallraff, A. et al. Strong coupling of a single photon to a superconducting qubit using circuit quantum electrodynamics. Nature 431 , 162–167 (2004). Article   CAS   ADS    Google Scholar
Koch, J. et al. Charge-insensitive qubit design derived from the Cooper pair box. Phys. Rev. A 76 , 042319 (2007). Article   ADS    Google Scholar
You, J. Q. & Nori, F. Atomic physics and quantum optics using superconducting circuits. Nature 474 , 589–597 (2011). Article   CAS   ADS    Google Scholar
Preskill, J. Quantum computing and the entanglement frontier. Rapporteur Talk at the 25th Solvay Conference on Physics, Brussels https://doi.org/10.1142/8674 (World Scientific, 2012).
Aaronson, S. & Arkhipov, A. The computational complexity of linear optics. In Proc. 43rd Ann. Symp. on Theory of Computing https://doi.org/10.1145/1993636.1993682 (ACM, 2011).
Bremner, M. J., Montanaro, A. & Shepherd, D. J. Average-case complexity versus approximate simulation of commuting quantum computations. Phys. Rev. Lett . 117 , 080501 (2016). Article   ADS   MathSciNet    Google Scholar
Boixo, S. et al. Characterizing quantum supremacy in near-term devices. Nat. Phys . 14 , 595 (2018). Article   CAS    Google Scholar
Bouland, A., Fefferman, B., Nirkhe, C. & Vazirani, U. On the complexity and verification of quantum random circuit sampling. Nat. Phys . 15 , 159 (2019). Article   CAS    Google Scholar
Aaronson, S. & Chen, L. Complexity-theoretic foundations of quantum supremacy experiments. In 32nd Computational Complexity Conf . https://doi.org/10.4230/LIPIcs.CCC.2017.22 (Schloss Dagstuhl–Leibniz Zentrum für Informatik, 2017).
Neill, C. et al. A blueprint for demonstrating quantum supremacy with superconducting qubits. Science 360 , 195–199 (2018). Article   CAS   ADS   MathSciNet    Google Scholar
Preskill, J. Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article    Google Scholar
Kechedzhi, K. et al. Efficient population transfer via non-ergodic extended states in quantum spin glass. In 13th Conf. on the Theory of Quantum Computation, Communication and Cryptography http://drops.dagstuhl.de/opus/volltexte/2018/9256/pdf/LIPIcs-TQC-2018-9.pdf (Schloss Dagstuhl–Leibniz Zentrum für Informatik, 2018).
Somma, R. D., Boixo, S., Barnum, H. & Knill, E. Quantum simulations of classical annealing processes. Phys. Rev. Lett . 101 , 130504 (2008). Article   CAS   ADS    Google Scholar
Farhi, E. & Neven, H. Classification with quantum neural networks on near term processors. Preprint at https://arxiv.org/abs/1802.06002 (2018).
McClean, J. R., Boixo, S., Smelyanskiy, V. N., Babbush, R. & Neven, H. Barren plateaus in quantum neural network training landscapes. Nat. Commun . 9 , 4812 (2018). Article   ADS    Google Scholar
Cong, I., Choi, S. & Lukin, M. D. Quantum convolutional neural networks. Nat. Phys . https://doi.org/10.1038/s41567-019-0648-8 (2019).
Bravyi, S., Gosset, D. & König, R. Quantum advantage with shallow circuits. Science 362 , 308–311 (2018). Article   CAS   ADS   MathSciNet    Google Scholar
Aspuru-Guzik, A., Dutoi, A. D., Love, P. J. & Head-Gordon, M. Simulated quantum computation of molecular energies. Science 309 , 1704–1707 (2005). Article   CAS   ADS    Google Scholar
Peruzzo, A. et al. A variational eigenvalue solver on a photonic quantum processor. Nat. Commun . 5 , 4213 (2014). Article   CAS   ADS    Google Scholar
Hempel, C. et al. Quantum chemistry calculations on a trapped-ion quantum simulator. Phys. Rev. X 8 , 031022 (2018). CAS    Google Scholar
Shor, P. W. Algorithms for quantum computation: discrete logarithms and factoring proceedings. In Proc. 35th Ann. Symp. on Foundations of Computer Science https://doi.org/10.1109/SFCS.1994.365700 (IEEE, 1994).
Fowler, A. G., Mariantoni, M., Martinis, J. M. & Cleland, A. N. Surface codes: towards practical large-scale quantum computation. Phys. Rev. A 86 , 032324 (2012). Article   ADS    Google Scholar
Barends, R. et al. Superconducting quantum circuits at the surface code threshold for fault tolerance. Nature 508 , 500–503 (2014). Article   CAS   ADS    Google Scholar
Córcoles, A. D. et al. Demonstration of a quantum error detection code using a square lattice of four superconducting qubits. Nat. Commun . 6 , 6979 (2015). Article   ADS    Google Scholar
Ofek, N. et al. Extending the lifetime of a quantum bit with error correction in superconducting circuits. Nature 536 , 441 (2016). Article   CAS   ADS    Google Scholar
Vool, U. & Devoret, M. Introduction to quantum electromagnetic circuits. Int. J. Circuit Theory Appl . 45 , 897–934 (2017). Article    Google Scholar
Chen, Y. et al. Qubit architecture with high coherence and fast tunable coupling circuits. Phys. Rev. Lett . 113 , 220502 (2014). Article   ADS    Google Scholar
Yan, F. et al. A tunable coupling scheme for implementing high-fidelity two-qubit gates. Phys. Rev. Appl . 10 , 054062 (2018). Article   CAS   ADS    Google Scholar
Schuster, D. I. et al. Resolving photon number states in a superconducting circuit. Nature 445 , 515 (2007). Article   CAS   ADS    Google Scholar
Jeffrey, E. et al. Fast accurate state measurement with superconducting qubits. Phys. Rev. Lett . 112 , 190504 (2014). Article   ADS    Google Scholar
Chen, Z. et al. Measuring and suppressing quantum state leakage in a superconducting qubit. Phys. Rev. Lett . 116 , 020501 (2016). Article   ADS    Google Scholar
Klimov, P. V. et al. Fluctuations of energy-relaxation times in superconducting qubits. Phys. Rev. Lett . 121 , 090502 (2018). Article   CAS   ADS    Google Scholar
Yan, F. et al. The flux qubit revisited to enhance coherence and reproducibility. Nat. Commun . 7 , 12964 (2016). Article   CAS   ADS    Google Scholar
Knill, E. et al. Randomized benchmarking of quantum gates. Phys. Rev. A 77 , 012307 (2008). Article   ADS    Google Scholar
Magesan, E., Gambetta, J. M. & Emerson, J. Scalable and robust randomized benchmarking of quantum processes. Phys. Rev. Lett . 106 , 180504 (2011). Article   ADS    Google Scholar
Cross, A. W., Magesan, E., Bishop, L. S., Smolin, J. A. & Gambetta, J. M. Scalable randomised benchmarking of non-Clifford gates. npj Quant. Inform . 2 , 16012 (2016).
Google Scholar
Wallraff, A. et al. Approaching unit visibility for control of a superconducting qubit with dispersive readout. Phys. Rev. Lett . 95 , 060501 (2005). Article   CAS   ADS    Google Scholar
De Raedt, H. et al. Massively parallel quantum computer simulator, eleven years later. Comput. Phys. Commun . 237 , 47–61 (2019). Article   ADS    Google Scholar
Markov, I. L., Fatima, A., Isakov, S. V. & Boixo, S. Quantum supremacy is both closer and farther than it appears. Preprint at https://arxiv.org/abs/1807.10749 (2018).
Villalonga, B. et al. A flexible high-performance simulator for the verification and benchmarking of quantum circuits implemented on real hardware. npj Quant. Inform . (in the press); preprint at https://arxiv.org/abs/1811.09599 (2018).
Boixo, S., Isakov, S. V., Smelyanskiy, V. N. & Neven, H. Simulation of low-depth quantum circuits as complex undirected graphical models. Preprint at https://arxiv.org/abs/1712.05384 (2017).
Chen, J., Zhang, F., Huang, C., Newman, M. & Shi, Y. Classical simulation of intermediate-size quantum circuits. Preprint at https://arxiv.org/abs/1805.01450 (2018).
Villalonga, B. et al. Establishing the quantum supremacy frontier with a 281 pflop/s simulation. Preprint at https://arxiv.org/abs/1905.00444 (2019).
Pednault, E. et al. Breaking the 49-qubit barrier in the simulation of quantum circuits. Preprint at https://arxiv.org/abs/1710.05867 (2017).
Chen, Z. Y. et al. 64-qubit quantum circuit simulation. Sci. Bull . 63 , 964–971 (2018). Article    Google Scholar
Chen, M.-C. et al. Quantum-teleportation-inspired algorithm for sampling large random quantum circuits. Preprint at https://arxiv.org/abs/1901.05003 (2019).
Shor, P. W. Scheme for reducing decoherence in quantum computer memory. Phys. Rev. A 52 , R2493–R2496 (1995). Article   CAS   ADS    Google Scholar
Devoret, M. H. & Schoelkopf, R. J. Superconducting circuits for quantum information: an outlook. Science 339 , 1169–1174 (2013). Article   CAS   ADS    Google Scholar
Mohseni, M. et al. Commercialize quantum technologies in five years. Nature 543 , 171 (2017). Article   CAS   ADS    Google Scholar
Grover, L. K. Quantum mechanics helps in searching for a needle in a haystack. Phys. Rev. Lett . 79 , 325 (1997). Article   CAS   ADS    Google Scholar
Bernstein, E. & Vazirani, U. Quantum complexity theory. In Proc. 25th Ann. Symp. on Theory of Computing https://doi.org/10.1145/167088.167097 (ACM, 1993).
Nature
( Nature )
ISSN 1476-4687 (online)
ISSN 0028-0836 (print)
nature.com footer links
About Nature Portfolio
About us
Press releases
Press office
Contact us
Discover content
Journals A-Z
Articles by subject
protocols.io
Nature Index
Publishing policies
Nature portfolio policies
Open access
Author & Researcher services
Reprints & permissions
Research data
Language editing
Scientific editing
Nature Masterclasses
Research Solutions
Libraries & institutions
Librarian service & tools
Librarian portal
Open research
Recommend to library
Advertising & partnerships
Advertising
Partnerships & Services
Media kits
Branded content
Professional development
Nature Awards
Nature Careers
Nature  Conferences
Regional websites
Nature Africa
Nature China
Nature India
Nature Japan
Nature Middle East
Privacy Policy
Use of cookies
Your privacy choices/Manage cookies
Legal notice
Accessibility statement
Terms & Conditions
Your US state privacy rights
© 2026 Springer Nature Limited
Close banner
Close
Sign up for the Nature Briefing newsletter — what matters in science, free to your inbox daily.
Email address
Sign up
I agree my information will be processed in accordance with the Nature and Springer Nature Limited Privacy Policy .
Close banner
Close
Get the most important science stories of the day, free in your inbox.  Sign up for Nature Briefing
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [19]: A. Morvan et al. — Phase transitions in random circuit sampling (Nature 634, 328-333, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Phase transitions in random circuit sampling
URL: https://doi.org/10.1038/s41586-024-07998-6
Phase transitions in random circuit sampling | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes. By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection. See our privacy policy for more information on the use of your personal data. Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
articles
article
Phase transitions in random circuit sampling
Download PDF
Download PDF
Article
Open access
Published: 09 October 2024
Phase transitions in random circuit sampling
A. Morvan   ORCID: orcid.org/0000-0002-9515-6184 1   na1 ,  B. Villalonga 1   na1 ,  X. Mi   ORCID: orcid.org/0000-0003-0507-0211 1   na1 ,  S. Mandrà   ORCID: orcid.org/0000-0002-3908-2694 1 , 2 , 3   na1 ,  A. Bengtsson   ORCID: orcid.org/0000-0001-5264-4025 1 ,  P. V. Klimov   ORCID: orcid.org/0000-0002-9481-4456 1 ,  Z. Chen 1 ,  S. Hong   ORCID: orcid.org/0000-0001-7421-5635 1 ,  C. Erickson 1 ,  I. K. Drozdov   ORCID: orcid.org/0000-0002-8185-1194 1 , 4 ,  J. Chau   ORCID: orcid.org/0009-0000-3007-5095 1 ,  G. Laun 1 ,  R. Movassagh 1 ,  A. Asfaw 1 ,  L. T. A. N. Brandão   ORCID: orcid.org/0000-0002-4501-089X 5 ,  R. Peralta   ORCID: orcid.org/0000-0002-2318-7563 6 ,  D. Abanin 1 ,  R. Acharya 1 ,  R. Allen 1 ,  T. I. Andersen 1 ,  K. Anderson 1 ,  M. Ansmann   ORCID: orcid.org/0000-0001-8765-5621 1 ,  F. Arute 1 ,  K. Arya 1 ,  J. Atalaya 1 ,  J. C. Bardin   ORCID: orcid.org/0000-0002-6523-6730 1 , 7 ,  A. Bilmes 1 ,  G. Bortoli   ORCID: orcid.org/0009-0008-4597-1691 1 ,  A. Bourassa   ORCID: orcid.org/0000-0002-8517-7475 1 ,  J. Bovaird 1 ,  L. Brill 1 ,  M. Broughton 1 ,  B. B. Buckley 1 ,  D. A. Buell 1 ,  T. Burger 1 ,  B. Burkett   ORCID: orcid.org/0000-0001-8474-6317 1 ,  N. Bushnell 1 ,  J. Campero 1 ,  H.-S. Chang   ORCID: orcid.org/0000-0001-9681-6108 1 ,  B. Chiaro 1 ,  D. Chik 1 ,  C. Chou 1 ,  J. Cogan 1 ,  R. Collins 1 ,  P. Conner 1 ,  W. Courtney 1 ,  A. L. Crook 1 ,  B. Curtin   ORCID: orcid.org/0000-0002-3856-0615 1 ,  D. M. Debroy 1 ,  A. Del Toro Barba   ORCID: orcid.org/0000-0003-0869-5110 1 ,  S. Demura   ORCID: orcid.org/0000-0003-3727-7380 1 ,  A. Di Paolo   ORCID: orcid.org/0000-0002-5174-7310 1 ,  A. Dunsworth 1 ,  L. Faoro 1 ,  E. Farhi 1 ,  R. Fatemi 1 ,  V. S. Ferreira 1 ,  L. Flores Burgos 1 ,  E. Forati 1 ,  A. G. Fowler 1 ,  B. Foxen   ORCID: orcid.org/0000-0002-3732-168X 1 ,  G. Garcia 1 ,  É. Genois   ORCID: orcid.org/0000-0002-2226-1813 1 ,  W. Giang 1 ,  C. Gidney 1 ,  D. Gilboa 1 ,  M. Giustina 1 ,  R. Gosula   ORCID: orcid.org/0000-0002-3025-7312 1 ,  A. Grajales Dau 1 ,  J. A. Gross   ORCID: orcid.org/0000-0001-7049-6206 1 ,  S. Habegger   ORCID: orcid.org/0000-0001-9867-2371 1 ,  M. C. Hamilton 1 , 8 ,  M. Hansen 1 ,  M. P. Harrigan   ORCID: orcid.org/0000-0001-9412-0553 1 ,  S. D. Harrington   ORCID: orcid.org/0000-0003-0521-8378 1 ,  P. Heu 1 ,  M. R. Hoffmann   ORCID: orcid.org/0000-0002-7051-5558 1 ,  T. Huang 1 ,  A. Huff 1 ,  W. J. Huggins   ORCID: orcid.org/0000-0003-2735-1380 1 ,  L. B. Ioffe 1 ,  S. V. Isakov 1 ,  J. Iveland 1 ,  E. Jeffrey 1 ,  Z. Jiang 1 ,  C. Jones 1 ,  P. Juhas   ORCID: orcid.org/0000-0001-8751-4458 1 ,  D. Kafri 1 ,  T. Khattar 1 ,  M. Khezri 1 ,  M. Kieferová 1 , 9 ,  S. Kim 1 ,  A. Kitaev 1 ,  A. R. Klots 1 ,  A. N. Korotkov 1 , 10 ,  F. Kostritsa 1 ,  J. M. Kreikebaum 1 ,  D. Landhuis   ORCID: orcid.org/0000-0001-9804-2185 1 ,  P. Laptev 1 ,  K.-M. Lau 1 ,  L. Laws 1 ,  J. Lee 1 , 11 ,  K. W. Lee 1 ,  Y. D. Lensky 1 ,  B. J. Lester   ORCID: orcid.org/0000-0002-4297-2508 1 ,  A. T. Lill 1 ,  W. Liu 1 ,  W. P. Livingston   ORCID: orcid.org/0000-0001-8399-0975 1 ,  A. Locharla 1 ,  F. D. Malone 1 ,  O. Martin 1 ,  S. Martin 1 ,  J. R. McClean   ORCID: orcid.org/0000-0002-2809-0509 1 ,  M. McEwen   ORCID: orcid.org/0000-0002-9544-141X 1 ,  K. C. Miao 1 ,  A. Mieszala 1 ,  S. Montazeri   ORCID: orcid.org/0000-0002-7124-4585 1 ,  W. Mruczkiewicz   ORCID: orcid.org/0000-0002-8497-6363 1 ,  O. Naaman   ORCID: orcid.org/0000-0002-7760-9186 1 ,  M. Neeley   ORCID: orcid.org/0000-0002-5548-0051 1 ,  C. Neill   ORCID: orcid.org/0000-0001-8509-9836 1 ,  A. Nersisyan 1 ,  M. Newman 1 ,  J. H. Ng   ORCID: orcid.org/0000-0002-7246-6761 1 ,  A. Nguyen 1 ,  M. Nguyen 1 ,  M. Yuezhen Niu 1 ,  T. E. O’Brien   ORCID: orcid.org/0000-0002-8406-6626 1 ,  S. Omonije 1 ,  A. Opremcak 1 ,  A. Petukhov 1 ,  R. Potter 1 ,  L. P. Pryadko 12 ,  C. Quintana 1 ,  D. M. Rhodes 1 ,  C. Rocque 1 ,  E. Rosenberg 1 ,  N. C. Rubin   ORCID: orcid.org/0000-0003-3963-1830 1 ,  N. Saei 1 ,  D. Sank   ORCID: orcid.org/0000-0001-8188-364X 1 ,  K. Sankaragomathi   ORCID: orcid.org/0000-0001-8930-7081 1 ,  K. J. Satzinger   ORCID: orcid.org/0000-0001-5865-0813 1 ,  H. F. Schurkus   ORCID: orcid.org/0000-0002-3210-5929 1 ,  C. Schuster 1 ,  M. J. Shearn 1 ,  A. Shorter 1 ,  N. Shutty   ORCID: orcid.org/0000-0002-6035-2812 1 ,  V. Shvarts 1 ,  V. Sivak 1 ,  J. Skruzny 1 ,  W. C. Smith 1 ,  R. D. Somma 1 ,  G. Sterling 1 ,  D. Strain 1 ,  M. Szalay 1 ,  D. Thor 1 ,  A. Torres 1 ,  G. Vidal 1 ,  C. Vollgraff Heidweiller   ORCID: orcid.org/0000-0002-6513-9885 1 ,  T. White 1 ,  B. W. K. Woo   ORCID: orcid.org/0000-0002-7233-1576 1 ,  C. Xing 1 ,  Z. J. Yao 1 ,  P. Yeh   ORCID: orcid.org/0000-0003-0837-1028 1 ,  J. Yoo 1 ,  G. Young 1 ,  A. Zalcman   ORCID: orcid.org/0000-0002-2585-2424 1 ,  Y. Zhang 1 ,  N. Zhu   ORCID: orcid.org/0000-0002-3037-2003 1 ,  N. Zobrist 1 ,  E. G. Rieffel 2 ,  R. Biswas 2 ,  R. Babbush   ORCID: orcid.org/0000-0001-6979-9533 1 ,  D. Bacon 1 ,  J. Hilton 1 ,  E. Lucero 1 ,  H. Neven   ORCID: orcid.org/0000-0002-9681-6746 1 ,  A. Megrant   ORCID: orcid.org/0000-0002-6371-6140 1 ,  J. Kelly   ORCID: orcid.org/0000-0002-2596-2121 1 ,  P. Roushan   ORCID: orcid.org/0000-0003-1917-3879 1 ,  I. Aleiner   ORCID: orcid.org/0000-0002-9096-254X 1 ,  V. Smelyanskiy 1 ,  K. Kechedzhi   ORCID: orcid.org/0000-0002-0136-1428 1 ,  Y. Chen   ORCID: orcid.org/0000-0002-7473-6745 1 &  … S. Boixo   ORCID: orcid.org/0000-0002-1090-7584 1   Show authors
Nature
volume  634 ,  pages 328–333 ( 2024 ) Cite this article
69k Accesses
107 Citations
610 Altmetric
Metrics details
Abstract Undesired coupling to the surrounding environment destroys long-range correlations in quantum processors and hinders coherent evolution in the nominally available computational space. This noise is an outstanding challenge when leveraging the computation power of near-term quantum processors 1 . It has been shown that benchmarking random circuit sampling with cross-entropy benchmarking can provide an estimate of the effective size of the Hilbert space coherently available 2 , 3 , 4 , 5 , 6 , 7 , 8 . Nevertheless, quantum algorithms’ outputs can be trivialized by noise, making them susceptible to classical computation spoofing. Here, by implementing an algorithm for random circuit sampling, we demonstrate experimentally that two phase transitions are observable with cross-entropy benchmarking, which we explain theoretically with a statistical model. The first is a dynamical transition as a function of the number of cycles and is the continuation of the anti-concentration point in the noiseless case. The second is a quantum phase transition controlled by the error per cycle; to identify it analytically and experimentally, we create a weak-link model, which allows us to vary the strength of the noise versus coherent evolution. Furthermore, by presenting a random circuit sampling experiment in the weak-noise phase with 67 qubits at 32 cycles, we demonstrate that the computational cost of our experiment is beyond the capabilities of existing classical supercomputers. Our experimental and theoretical work establishes the existence of transitions to a stable, computationally complex phase that is reachable with current quantum processors.
Similar content being viewed by others
Extending the computational reach of a superconducting qutrit processor
Article  Open access  14 October 2024
Phase analysis on the error scaling of entangled qubits in a 53-qubit system
Article  Open access  14 July 2021
Measurement-induced entanglement and teleportation on a noisy quantum processor
Article  Open access  18 October 2023
Main The computational complexity of quantum systems arises from the exponential growth of the Hilbert space dimension with system size. On near-term quantum processors whose practical complexity is limited by noise, random circuit sampling (RCS) has emerged as the most suitable candidate for a beyond-classical demonstration. The interplay between computational complexity and noise is highlighted by recent RCS experiments with increasing system sizes and fidelity 4 , 5 , 6 , 9 , 10 , although classical algorithms have also advanced substantially 11 , 12 , 13 , 14 , 15 , 16 . RCS is, arguably, the entry point into the realm of classically intractable problems for any experimental quantum processing platform 17 . The reason is that RCS circuits can be optimized to maximize the speed of quantum correlations with iSWAP-like gates 2 , 18 , 19 , 20 while preventing potential simplifications in the corresponding classical emulations 17 . This intensifying quantum–classical competition motivates two questions. Are there well-defined boundaries for the region where the exponentially large Hilbert space is, in fact, leveraged by a noisy quantum processor? More importantly, can we establish an experimental observable that directly probes these boundaries? In this work, we provide direct insight to these two questions using RCS on a two-dimensional grid of superconducting qubits. We demonstrate that the interplay between quantum dynamics and noise can drive the system into distinct phases. The boundary between these phases can be resolved using finite-size studies with a fidelity estimation technique called cross-entropy benchmarking (XEB) 2 , 3 , 4 , 21 . Reaching the desired phase of maximized complexity requires a noise rate per cycle below a critical threshold whose value is determined by the growth rate of quantum correlations. The structure of these phases is schematically illustrated in Fig. 1 . Driven by the circuit number of cycles or depth, the system first goes through a dynamical phase transition where the output distribution is no longer concentrated in a fraction of bit strings. Anti-concentration is a key ingredient of XEB and of mathematical arguments on the complexity of simulating noiseless RCS 2 , 22 , 23 , 24 , 25 . Nevertheless, we will show that this is a necessary but not sufficient condition for global entanglement (Supplementary Information section  H ), which maximizes the computational cost. Fig. 1: Phase transitions in RCS. The alternative text for this image may have been generated using AI. Full size image
One phase transition goes between a concentrated output distribution of bit strings from RCS at a low number of cycles to a broad or anti-concentrated distribution. There is a second phase transition in a noisy system. A strong-enough error per cycle induces a phase transition from a regime where correlations extend to the full system to a regime where the system may be approximately represented by the product of several uncorrelated subsystems.
The second transition is driven by noise, specifically the error rate per cycle ϵ  ×  n , where ϵ is the error per gate and n is the number of qubits. As illustrated in Fig. 1 , the behaviour of quantum correlations falls into two regimes: when the error rate per cycle is large, the state of the system can be approximately represented by several uncorrelated subsystems (equation ( 3 )). This leaves the quantum system open to spoofing by classical algorithms that represent only part of the system at a time 22 , 26 , 27 . In the regime where the error rate per cycle is sufficiently low, correlations eventually span the entire system, thus restoring its computational complexity, and the experiment cannot be spoofed (Supplementary Information section  F ). The boundary between these two phases is determined by the competition between ϵ  ×  n and the convergence of the system to the ergodic state. Reference 28 studied the same phase transition for one-dimensional and all-to-all connectivity. We found that XEB is a proper observable and can be used to resolve the aforementioned regimes experimentally, as it is sensitive to the nature of the dominant correlations. Specifically, linear XEB is measured as $${\rm{XEB}}={\langle {2}^{n}{p}_{{\rm{sim}}}(s)-1\rangle }_{{\rm{s}}},$$
(1)
where n is the number of qubits, \({p}_{{\rm{sim}}}(s)\) is the ideal (simulated) probability of bit string s and the average is over experimentally observed bit strings s . We measured XEB as a function of the number of cycles or depth d for different system sizes to resolve the dynamical phase transition (Fig. 1 ). The experimental results are shown in Fig. 2a,b for one- and two-dimensional systems, respectively. We found that XEB increased with system size for small d . In this case, the system state was concentrated in a fraction of basis states. However, for large d , XEB decayed exponentially and approximated the circuit fidelity. At an intermediate number of cycles, we observed a single crossing point where all the measured XEB curves intersected and where XEB was approximately independent of the system size. The detailed theory presented in Supplementary Information section  E shows that this is indeed a phase transition associated with the role of the boundary. Fig. 2: Phase transitions in the linear cross-entropy. The alternative text for this image may have been generated using AI. Full size image
a – d , At a low number of cycles, XEB grows with the size of the system. In a noiseless device, XEB will converge to 1 with the number of cycles. In the presence of noise, XEB becomes an estimator of the system fidelity. a , b , We experimentally observed a dynamical phase transition at a fixed number of cycles between these two regimes in one ( a ) and two dimensions ( b ). The random circuits have Haar random single-qubit gates and an iSWAP-like gate as an entangler. c , d , We experimentally probed a noise-induced phase transition using a weak-link model (see the main text), where the weak link is applied every 12 cycles (discrete gate set; see main text). c , The two different regimes. In the weak-noise regime, XEB converges to the fidelity, whereas in the strong-noise regime, XEB remains higher than predicted by the digital error model. d , We induced errors to scan the transition from one regime to the other.
Having identified the minimum number of cycles at which XEB approximated the system fidelity, we formulated an experimental protocol for locating the transition between the strong- and weak-noise regimes (Fig. 1 ). A conceptually simple set-up that highlights the underlying physics for this transition is the so-called weak-link model, where two subsystems of size n /2 are coupled through an entangling gate applied every T cycles. In the limit where T  = ∞ (no weak link is applied), the subsystems were uncoupled and the overall system converged to a product state ρ A   ⊗   ρ B , where ρ A and ρ B are the pure ergodic states of each subsystem. Adding noise, we assumed the so-called depolarizing channel noise model for the density matrix of each subsystem A and B (ref. 29 ): F d /2 ρ A/B  + (1 −  F d /2 ) I A/B /2 n /2 , where I A ( I B ) is the identity matrix and F  = e − ϵ n is the fidelity. Direct substitution of this density matrix into equation ( 1 ) gives XEB = e − ϵ n d  + 2e − ϵ n d /2 . We use XEB = 1 for ρ A/B and XEB = 0 for I A/B /2 n /2 . At finite yet large T , each subsystem approached the ergodic state in less than T cycles. The application of a two-qubit gate between the two subsystems built global correlations, which, therefore, decreased the XEB term proportional to F d /2 with some rate λ . This rate λ depends on the gate and was λ  = 1/4 for the iSWAP-like gates employed in our experiment (Supplementary Information section  D ). Therefore, a simplified model for linear XEB is $${\rm{X}}{\rm{E}}{\rm{B}}\approx 2{\lambda }^{d/T}{e}^{-\epsilon nd/2}+{e}^{-\epsilon nd}.$$
(2)
We justify this equation by formally averaging circuit instances over two-replicas, which results in the so-called population dynamics formalism (Supplementary Information section D ). We probed this behaviour by measuring XEB experimentally as a function of d , as shown in Fig. 2c . We employed a noise-injection protocol that effectively changed the gate fidelities in our quantum circuits (Supplementary Information section  C2 ) and show results corresponding to different noise levels. We used the discrete set of single-qubit gates chosen randomly from Z p X 1/2 Z − p with p   ∈  {−1, −3/4, −1/2, …, 3/4} and Z and X the corresponding Pauli matrices. We observed that in the weak-noise regime, XEB converged to the expected fidelity of the entire system, F d . This was because F was sufficiently high such that F d dominated the contribution to XEB. On the other hand, XEB was significantly above F d in the strong-noise regime owing to the dominant contribution of 2 λ d / T F d /2 to XEB. These results exemplify the competition between the exponential decay of global correlations proportional to ϵ n and the entangling rate between subsystems (proportional to 1/ T in this example). The transition between the two different noise-induced phases was more clearly seen by fixing d to a few values and varying the effective noise level ( F ). We observed that XEB exhibits a non-trivial scaling distinct from F d (Fig. 2d ). In particular, the rate of decay with respect to errors decreased at higher error rates. This is also consistent with 2 λ d / T F d /2 being dominant at high errors. To experimentally locate the critical value of the error per cycle (or equivalently, F ) where the dynamical exponent of XEB changed, we defined a modified order parameter F d /XEB, which is asymptotic to a distinct value of 1 (0) in the weak (strong) noise regime. The transition between the two limits became a discontinuity when d  → ∞, indicating a phase transition for finite ϵ n  ≈  κ c , where the critical value κ c can be a function of λ and T . In the transition region, we observed the finite-size critical behaviour where F d /XEB was approximately a function of ( ϵ n  −  κ c ) d . This was revealed in the order parameter for different numbers of cycles d crossing at a single point, as can be verified from equation ( 2 ) and numerically for the circuits used in the experiment. The experimentally obtained F d /XEB, shown in Fig. 3a–c,e,f , indeed manifested the expected critical behaviour. For ϵ n   ≲   κ c , the order parameter increased as d was increased, whereas for ϵ n   ≳   κ c , the order parameter decreased as d was increased. At the critical point ϵ n  ≈  κ c , the datasets crossed and the order parameter was approximately independent of d . We attribute the slight drift in the crossing point between different depths to potential systematic errors in the experimental estimation of F . Fig. 3: Noise-induced phase transitions. The alternative text for this image may have been generated using AI. Full size image
a – c , Experimental noise-induced phase transitions as a function of the error per cycle for several periods T of the weak-link model (discrete gate set) ( T  = 8 ( a ), T  = 12 ( b ) and T  = 18 ( c )). As T increases, the critical value of noise or error per cycle becomes lower. d , Phase diagram of the transition with analytical, numerical and experimental data. The experimental data were extracted from the crossing of the largest number of cycles scanned. e , f , Experimental transitions in two dimensions with different patterns: staggered ACBD ( e ) and unstaggered EGFH ( f ; discrete gate set). g , Numerical phase diagram of the two-dimensional phase transition. We show the critical point for different sizes and patterns. The qubits are arranged as shown in the inset of e . For fixed size, we increased the number of bridges (such as the red coupler in e ) until all bridges were applied (four and six for the 4 × 4 and 4 × 6 systems, respectively), denoted as links per four cycles in g . For all the patterns, we delimited a lower bound on the critical error rate of 0.47 errors per cycle to separate the region of strong noise where XEB failed to characterize the underlying fidelity and where global correlations were subdominant. The experimental results shown in Fig. 4 (SYC-67) and in Supplementary Information section C1 (SYC-70) are represented by red stars, which are well within the weak-noise regime.
We extracted the critical noise rate for different link frequencies 1/ T experimentally, numerically and analytically (Fig. 3d ). When comparing with the functional form \({\epsilon }n\simeq 4/T\log 2\) predicted by the analytical weak-link model, we observed appreciable deviations when the link frequency approached 1/2, which corresponds to the regular one-dimensional chain. The deviation occurred because the weak-link model was no longer applicable in this regime. A more accurate description is provided by a generalization of this model in Supplementary Information section  E1 . To explain the nature of the noise-induced phase transition for two and more dimensions, we extended the weak-link model from two subsystems to a number of subsystems equal to the number of qubits (see Supplementary Information section  E2 for details). For depths d   ≫  1, the subsystems converge either to an appropriate ergodic state or to a state proportional to the identity matrix, as in the weak-link model. In the noiseless case, there are two stationary configurations, with either all subsystems in the identity matrix or all in the ergodic state. We expanded the noisy state around these two configurations using the so-called dilute flipped spin expansion. This generalizes equation ( 2 ) to $${\rm{XEB}}+1\simeq \sum _{k}\frac{1}{k!}{e}^{-{\epsilon }kd}{({\lambda }^{d}n)}^{k}+\sum _{k}\frac{1}{k!}{e}^{-{\epsilon }(n-k)d}{({\lambda }^{d}n)}^{k}\,,$$
(3)
where the first (second) term on the right-hand side corresponds to the expansion around the identity matrix (ergodic state). See Supplementary Information section  D for the derivation. The index k describes the total number of subsystems not equal to the corresponding global state and k ! is its factorial. The first term on the right-hand side corresponds to the low-weight Pauli paths approximation in ref. 27 . Finally, λ  = 1/4 for the iSWAP gate, as in the weak-link model. The noise-induced phase transition appears in the thermodynamical limit n  → ∞ at fixed ϵ n and \(d/\log n\) (see Supplementary Information section  E for details). We found $${\rm{XEB}}+1\simeq \exp (n{2}^{-2d})(1+{e}^{-{\epsilon }nd}).$$
(4)
The second factor on the right-hand side corresponds to the global fidelity and dominates in the weak-noise regime \({\epsilon }n\ll {\rm{ln}}\,4\) . The first factor describes the convergence to anti-concentration (Supplementary Information section  E ), in accordance with refs. 22 , 23 , and dominates in the strong-noise regime \({\epsilon }n\gg {\rm{ln}}\,4\) . In this case, the first term on the right-hand side of equation ( 3 ) prevails, and by taking small k , the state can be approximately represented by several uncorrelated subsystems. On the one hand, as captured by equation ( 3 ), this transition corresponds to qualitatively different configurations. On the other hand, both regimes correspond to an ordered phase. The noise-induced phase transition is driven by a control parameter (analogous to a magnetic field in an Ising model) that scales with the system size (number of qubits). This is loosely like Fréedericksz transitions in liquid crystals 30 and is qualitatively different from the quantum to classical transition discussed in ref. 31 . The transition discussed here is a competition between the finite rate of convergence to the overall ergodic state and the fidelity per cycle. The transition in ref. 31 is a competition between local interactions and the error rate per qubit and is related to the error threshold of quantum error correction codes. The two-dimensional experimental results are shown in Fig. 3e,f for a 4 × 4 square grid of qubits and two different circuit structures, whereby the two-qubit gates were applied either in a staggered (Fig. 3e ) or an unstaggered (Fig. 3f ) fashion. As in one dimension, the 16-qubit system was divided into two halves connected by a single iSWAP-like gate applied every four cycles. For both circuit structures, we observed a similar crossing between F d /XEB measured at three different cycles, with a higher value of ϵ n observed for the unstaggered patterns. We numerically evaluated critical noise rates for systems of different sizes and circuit structures without weak links, including both the staggered and unstaggered patterns and the ABCD-CDAB pattern used in ref. 4 . Here, we used Haar random single-qubit gates (Supplementary Information section  D ). The vertical line in Fig. 3g gives a lower bound for the noise-induced phase transition. Furthermore, the noise-induced phase transition for the discrete gate set used in the experiment occurred at higher noise rates (Supplementary Information section  F2 ). We compared this lower bound with the 67-qubit and 70-qubit RCS experiments that we will present next. We obtained the error per cycle by fitting the exponential decay of the fidelity (Fig. 4 ). It is evident that these experiments fell well within the weak-noise regime, satisfying the requirement to fully utilize the computational capacity of the noisy quantum processors. Fig. 4: Demonstration of a classically intractable computation. The alternative text for this image may have been generated using AI. Full size image
a , Verification of RCS fidelity with logarithmic XEB. The full device is divided into two (green) or three (blue) patches to estimate the XEB fidelity for a modest computational cost. We used the discrete gate set of single-qubit gates chosen randomly from Z p X 1/2 Z − p with p   ∈  {−1, −3/4, −1/2, …, 3/4}. For each number of cycles, 20 circuit instances were sampled with 100,000 shots each. The solid lines indicate the XEB estimated from the digital error model. b , Verification of RCS fidelity with Loschmidt echo. The inversion was done by reversing the circuit and inserting single-qubit gates. In this case, the Loschmidt echo number of cycles doubled. c , Time complexity estimated as a function of the number of qubits and the number of cycles for a set of circuits. As a working definition of time complexity, we used the number of FLOPs needed to compute the probability of a single bit string under no memory constraints. The solid line indicates the depth at which correlations spread to the full device and the FLOPs with depth go from exponential to polynomial.  d , Evolution of the time complexity of the RCS experiments. The dashed line represents doubly exponential growth as a guide for the eye.
We demonstrated beyond-classical RCS by performing an experiment on a 67-qubit Sycamore chip (Fig. 4 ). These random circuits followed the same two-dimensional ABCD-CDAB pattern as ref. 4 . The single-qubit gates were chosen randomly from the discrete set Z p X 1/2 Z − p with p   ∈  {−1, −3/4, −1/2, …, 3/4}. We show in Supplementary Information section B the fidelity of the elementary operations of the random circuit. On average, we achieved a read-out error of 1.3(0.5) × 10 −2 , a dressed two-qubit Pauli error rate of 5.5(1.3) × 10 −3 that can be further decomposed into a single-qubit Pauli error rate of 1.0(0.5) × 10 −3 , and an intrinsic two-qubit simultaneous error of 3.5(1.4) × 10 −3 . An intrinsic Pauli error rate of 3.5 × 10 −3 corresponds to an average fidelity of 99.72%. We validated the digital error model by looking at patched variations of the random circuit (inset in Fig. 4a ), where slices of two-qubit gates have been removed to create patched circuits for which each patch XEB can be verified for a modest computational cost. The total fidelity was then the product of the patch fidelities. Computing XEB over full circuits is, at present, an intractable classical task. We, thus, estimated the fidelity after 32 cycles using the discrete error model, obtaining 0.1%. This increased depth was possible thanks to the substantially reduced errors compared with previous processors. We collected over 70 million sample bit strings for a single circuit at this depth. In Supplementary Information section  SC1 , we report fidelities for another XEB experiment, SYC-70, done on 70 qubits and with 24 cycles. In Fig. 4b , we verify these extracted fidelities with the Loschmidt echo, where we use the same circuit and its inversion to return to the initial state. We observed good agreement with the XEB experiment and the digital error model. Finally, we estimated the equivalent classical computational cost of RCS with the tensor network contraction method 7 , 11 , 12 , 13 , 14 , 15 , 16 , 18 , 32 , 33 , 34 . With this method, ref. 15 classically sampled the RCS experiment performed in 2019 4 in 15 h using 512 GPUs. Reference 16 also performed this task with a similar cost. Furthermore, another team computed 7 the corresponding XEB, which confirmed the predictions of ref. 4 , which is a harder computational task than noisy sampling. Hence, these notable improvements in classical algorithms significantly raised the beyond-classical threshold. For completeness, in Supplementary Information section  H , we also study matrix product states, a popular tensor network variational representation of one-dimensional quantum states with limited entanglement 35 , 36 , 37 . We found that given current supercomputer memory constraints, matrix product states failed to reach the experimental fidelity and offered worse performance than tensor network contraction. We report improvements in tensor network contraction techniques that resulted in lower estimated computational costs for simulated RCS (Supplementary Information section  G ). Figure 4c shows the time complexity or number of floating-point operations (FLOPs) (the number of real multiplications and additions) as a function of the number of qubits and cycles required to compute a single amplitude at the output of a random circuit without memory constraints, as we are optimizing only the contraction ordering of the underlying tensor network. The time complexity in this context is rigorously defined as the minimum contraction cost achievable in terms of FLOPs per amplitude 12 , which we approximated by optimizing the contraction ordering. This served as a proxy lower bound for the hardness of both sampling and verification. For a fixed number of qubits and increasing number of cycles, there was a notional crossover in the scaling of the time complexity from exponential to linear. Given a noisy experimental set-up, this implies an optimal number of cycles for the trade-off between computational time complexity and fidelity. Beyond the crossover, fidelity decreases faster than the time complexity increases. The crossover number of cycles is consistent with a scaling \(\sqrt{n}\) . A line following the functional form \(d=A\sqrt{n}\) , where n is the number of qubits, has been added as a guide to the eye. Note that this is related to the number of cycles at which ‘typical’ entanglement is achieved (Supplementary Information section  H ) and is a stronger requirement than the anti-concentration of the output distribution. For both 67 and 70 qubits, 24 cycles was deep enough to saturate the exponential growth of this time complexity. Figure 4d shows the growth of the time complexity without memory constraints of the largest RCS experiments run over the last few years. A practical estimate of the computational resources to simulate RCS needs to take into account the finite FLOPS (FLOPs per second) delivery of a supercomputer as well as its memory constraints and other limitations such as finite bandwidth. Table 1 shows estimates of the runtime for the approximate simulation of the largest instances of RCS from refs. 4 , 5 , 6 and the current work when using the state-of-the-art methods discussed in Supplementary Information section  G . For these estimates, we considered sampling 1 million uncorrelated bit strings at a fidelity like that of the experiment using the current top-performing supercomputer, Frontier, which performs 1.7 × 10 18 single-precision FLOPS of theoretical peak performance spread across GPUs with 128 GB of RAM each. This required the computation of 10 million approximate probability amplitudes of uncorrelated bit strings to be used in rejection sampling 18 . Despite notable progress in achieving tensor contraction algorithms that are embarrassingly parallelizable over each GPU 14 , 32 , we found that this technique broke down for the much deeper SYC-67 circuits with 32 cycles given the tight memory constraints. As a result, an estimated lower bound for the sampling cost became substantially more prohibitive. Assuming a distributed use of all RAM and under the unrealistic assumption of negligible bandwidth constraints, the computational cost was around 1 × 10 4  years (Table 1 ). In the untested case in which we expanded working memory to all secondary storage and still ignored the bandwidth, we obtained an estimate of 12 years. Table 1 Estimated computational cost of simulation Full size table
In conclusion, our experiment provides direct insights on how quantum dynamics interacts with noise. The observed phase boundaries lay out quantitative guidance to the regimes where noisy quantum devices can properly leverage their computational power. In addition, we present new RCS results with an estimated fidelity of 1.5 × 10 −3 at 67 qubits and 32 cycles or 880 entanglement gates, corresponding to more than doubling the circuit volume compared to ref. 4 for the same fidelity. Global correlations dominate XEB in the weak-noise phase, which protects RCS against ‘spoofing’ attacks, in contrast to boson sampling 38 , where all known metrics for recent experiments 39 , 40 , 41 are dominated by local correlations 42 . Looking forward, despite the success of RCS in quantifying the available coherent resources, finding practical applications for near-term noisy quantum processors still remains an outstanding challenge. Certified randomness generation 43 , 44 could be a promising candidate for such an application (Supplementary Information section  I ).
Data availability
The quantum circuits and datasets generated and analysed for this study are available at Zenodo ( https://zenodo.org/records/11663206 ) 45 .
Code availability
The source code used for the tensor contraction cost estimates are available under an open-source licence at GitHub ( https://github.com/google-research/google-research/tree/master/rcs_tnsa) .
References Preskill, J. Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article
Google Scholar
Boixo, S. et al. Characterizing quantum supremacy in near-term devices. Nat. Phys. 14 , 595–600 (2018). Article   CAS
Google Scholar
Neill, C. et al. A blueprint for demonstrating quantum supremacy with superconducting qubits. Science 360 , 195–199 (2018). Article   ADS   MathSciNet   CAS   PubMed
Google Scholar
Arute, F. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). Article   ADS   CAS   PubMed
Google Scholar
Wu, Y. et al. Strong quantum computational advantage using a superconducting quantum processor. Phys. Rev. Lett. 127 , 180501 (2021). Article   ADS   CAS   PubMed
Google Scholar
Zhu, Q. et al. Quantum computational advantage via 60-qubit 24-cycle random circuit sampling. Sci. Bull. 67 , 240–245 (2022). Article
Google Scholar
Liu, Y. et al. Verifying quantum advantage experiments with multiple amplitude tensor network contraction. Phys. Rev. Lett. 132 , 030601 (2024).
Mark, D. K., Choi, J., Shaw, A. L., Endres, M. & Choi, S. Benchmarking quantum simulators using ergodic quantum dynamics. Phys. Rev. Lett. 131 , 110601 (2023). Article   ADS   CAS   PubMed
Google Scholar
Shaw, A. L. et al. Benchmarking highly entangled states on a 60-atom analogue quantum simulator. Nature 628 , 71–77 (2024).
Bluvstein, D. et al. Logical quantum processor based on reconfigurable atom arrays. Nature 626 , 58–65 (2022).
Markov, I. L. & Shi, Y. Simulating quantum computation by contracting tensor networks. SIAM J. Comput. https://doi.org/10.1137/050644756 (2008). Article   MathSciNet
Google Scholar
Boixo, S., Isakov, S. V., Smelyanskiy, V. N. & Neven, H. Simulation of low-depth quantum circuits as complex undirected graphical models. Preprint at https://arxiv.org/abs/1712.05384 (2017).
Gray, J. & Kourtis, S. Hyper-optimized tensor network contraction. Quantum 5 , 410 (2021). Article
Google Scholar
Huang, C. et al. Classical simulation of quantum supremacy circuits. Preprint at https://arxiv.org/abs/2005.06787 (2020).
Pan, F., Chen, K. & Zhang, P. Solving the sampling problem of the Sycamore quantum circuits. Phys. Rev. Lett. 129 , 090502 (2022). Article   ADS   CAS   PubMed
Google Scholar
Kalachev, G., Panteleev, P., Zhou, P. & Yung, M.-H. Classical sampling of random quantum circuits with bounded fidelity. Preprint at https://arxiv.org/abs/2112.15083 (2021).
Kechedzhi, K. et al. Effective quantum volume, fidelity and computational cost of noisy quantum processing experiments. Future Gener. Comput. Syst. 153 , 431–441 (2024). Article
Google Scholar
Markov, I. L., Fatima, A., Isakov, S. V. & Boixo, S. Quantum supremacy is both closer and farther than it appears. Preprint at https://arxiv.org/abs/1807.10749 (2018).
Mi, X. et al. Information scrambling in quantum circuits. Science 374 , 1479–1483 (2021). Article   ADS   CAS   PubMed
Google Scholar
Bertini, B., Kos, P. & Prosen, T. Operator entanglement in local quantum circuits. I. Chaotic dual-unitary circuits. SciPost Phys. 8 , 067 (2020). Article   ADS   MathSciNet
Google Scholar
Liu, Y., Otten, M., Bassirianjahromi, R., Jiang, L. & Fefferman, B. Benchmarking near-term quantum computers via random circuit sampling. Preprint at https://arxiv.org/abs/2105.05232 (2021).
Barak, B., Chou, C.-N. & Gao, X. Spoofing linear cross-entropy benchmarking in shallow quantum circuits. Preprint at https://arxiv.org/abs/2005.02421 (2020).
Dalzell, A. M., Hunter-Jones, N. & Brandão, F. G. S. L. Random quantum circuits anticoncentrate in log depth. PRX Quantum 3 , 010333 (2022). Article   ADS
Google Scholar
Bouland, A., Fefferman, B., Nirkhe, C. & Vazirani, U. On the complexity and verification of quantum random circuit sampling. Nat. Phys. 15 , 159 (2019). Article   CAS
Google Scholar
Movassagh, R. The hardness of random quantum circuits. Nat. Phys. 19 , 1719 (2023). Article   CAS
Google Scholar
Gao, X. et al. Limitations of linear cross-entropy as a measure for quantum advantage. PRX Quantum 5 , 010334 (2024). Article   ADS
Google Scholar
Aharonov, D., Gao, X., Landau, Z., Liu, Y. & Vazirani, U. A polynomial-time classical algorithm for noisy random circuit sampling. In Proc. 55th Annual ACM Symposium on Theory of Computing 945–957 (ACM, 2023).
Ware, B. et al. A sharp phase transition in linear cross-entropy benchmarking. Preprint at https://arxiv.org/abs/2305.04954 (2023).
Dalzell, A. M., Hunter-Jones, N. & Brandão, F. G. Random quantum circuits transform local noise into global white noise. Commun. Math. Phys. 405 , 78 (2024). Article   ADS   MathSciNet
Google Scholar
de Gennes, P. & Prost, J. The Physics of Liquid Crystals (Clarendon, 1993).
Aharonov, D. Quantum to classical phase transition in noisy quantum computers. Phys. Rev. A 62 , 062311 (2000).
Chen, J., Zhang, F., Huang, C., Newman, M. & Shi, Y. Classical simulation of intermediate-size quantum circuits. Preprint at https://arxiv.org/abs/1805.01450 (2018).
Villalonga, B. et al. A flexible high-performance simulator for verifying and benchmarking quantum circuits implemented on real hardware. npj Quantum Inf. 5 , 86 (2019). Article   ADS
Google Scholar
Zlokapa, A., Villalonga, B., Boixo, S. & Lidar, D. A. Boundaries of quantum supremacy via random circuit sampling. npj Quantum Inf. 9 , 36 (2023). Article   ADS
Google Scholar
White, S. R. Density-matrix algorithms for quantum renormalization groups. Phys. Rev. B 48 , 10345 (1993). Article   ADS   CAS
Google Scholar
Vidal, G. Efficient classical simulation of slightly entangled quantum computations. Phys. Rev. Lett. 91 , 147902 (2003). Article   ADS   PubMed
Google Scholar
Ayral, T. et al. Density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity. PRX Quantum 4 , 020304 (2023). Article   ADS
Google Scholar
Aaronson, S. & Arkhipov, A. The computational complexity of linear optics. In Proc. Forty-third Annual ACM Symposium on Theory of Computing 333–342 (2011).
Zhong, H.-S. et al. Quantum computational advantage using photons. Science 370 , 1460–1463 (2020). Article   ADS   CAS   PubMed
Google Scholar
Zhong, H.-S. et al. Phase-programmable Gaussian boson sampling using stimulated squeezed light. Phys. Rev. Lett. 127 , 180502 (2021). Article   ADS   CAS   PubMed
Google Scholar
Madsen, L. S. et al. Quantum computational advantage with a programmable photonic processor. Nature 606 , 75–81 (2022). Article   ADS   CAS   PubMed   PubMed Central
Google Scholar
Villalonga, B. et al. Efficient approximation of experimental Gaussian boson sampling. Preprint at https://arxiv.org/abs/2109.11525 (2021).
Bassirian, R., Bouland, A., Fefferman, B., Gunn, S. & Tal, A. On certified randomness from Fourier sampling or random circuit sampling. Preprint at https://arxiv.org/abs/2111.14846 (2021).
Aaronson, S. & Hung, S.-H. Certified randomness from quantum supremacy. In Proc. 55th Annual ACM Symposium on Theory of Computing 933–944 (ACM, 2023).
Morvan, A. et al. Data for ‘Phase transition in random circuit sampling’. Zenodo https://doi.org/10.5281/zenodo.8253792 (2024).
Download references
Acknowledgements We acknowledge insightful discussions with C. Miller on certified randomness and K. J. Sung for his work on randomness extractors. S. Mandrà is partially supported by the Prime Contract No. 80ARC020D0010 with the NASA Ames Research Center and acknowledges funding from the Defense Advanced Research Projects Agency under IAA 8839.
Author information Author notes These authors contributed equally: A. Morvan, B. Villalonga, X. Mi, S. Mandrà
Authors and Affiliations Google Research, Mountain View, CA, USA A. Morvan, B. Villalonga, X. Mi, S. Mandrà, A. Bengtsson, P. V. Klimov, Z. Chen, S. Hong, C. Erickson, I. K. Drozdov, J. Chau, G. Laun, R. Movassagh, A. Asfaw, D. Abanin, R. Acharya, R. Allen, T. I. Andersen, K. Anderson, M. Ansmann, F. Arute, K. Arya, J. Atalaya, J. C. Bardin, A. Bilmes, G. Bortoli, A. Bourassa, J. Bovaird, L. Brill, M. Broughton, B. B. Buckley, D. A. Buell, T. Burger, B. Burkett, N. Bushnell, J. Campero, H.-S. Chang, B. Chiaro, D. Chik, C. Chou, J. Cogan, R. Collins, P. Conner, W. Courtney, A. L. Crook, B. Curtin, D. M. Debroy, A. Del Toro Barba, S. Demura, A. Di Paolo, A. Dunsworth, L. Faoro, E. Farhi, R. Fatemi, V. S. Ferreira, L. Flores Burgos, E. Forati, A. G. Fowler, B. Foxen, G. Garcia, É. Genois, W. Giang, C. Gidney, D. Gilboa, M. Giustina, R. Gosula, A. Grajales Dau, J. A. Gross, S. Habegger, M. C. Hamilton, M. Hansen, M. P. Harrigan, S. D. Harrington, P. Heu, M. R. Hoffmann, T. Huang, A. Huff, W. J. Huggins, L. B. Ioffe, S. V. Isakov, J. Iveland, E. Jeffrey, Z. Jiang, C. Jones, P. Juhas, D. Kafri, T. Khattar, M. Khezri, M. Kieferová, S. Kim, A. Kitaev, A. R. Klots, A. N. Korotkov, F. Kostritsa, J. M. Kreikebaum, D. Landhuis, P. Laptev, K.-M. Lau, L. Laws, J. Lee, K. W. Lee, Y. D. Lensky, B. J. Lester, A. T. Lill, W. Liu, W. P. Livingston, A. Locharla, F. D. Malone, O. Martin, S. Martin, J. R. McClean, M. McEwen, K. C. Miao, A. Mieszala, S. Montazeri, W. Mruczkiewicz, O. Naaman, M. Neeley, C. Neill, A. Nersisyan, M. Newman, J. H. Ng, A. Nguyen, M. Nguyen, M. Yuezhen Niu, T. E. O’Brien, S. Omonije, A. Opremcak, A. Petukhov, R. Potter, C. Quintana, D. M. Rhodes, C. Rocque, E. Rosenberg, N. C. Rubin, N. Saei, D. Sank, K. Sankaragomathi, K. J. Satzinger, H. F. Schurkus, C. Schuster, M. J. Shearn, A. Shorter, N. Shutty, V. Shvarts, V. Sivak, J. Skruzny, W. C. Smith, R. D. Somma, G. Sterling, D. Strain, M. Szalay, D. Thor, A. Torres, G. Vidal, C. Vollgraff Heidweiller, T. White, B. W. K. Woo, C. Xing, Z. J. Yao, P. Yeh, J. Yoo, G. Young, A. Zalcman, Y. Zhang, N. Zhu, N. Zobrist, R. Babbush, D. Bacon, J. Hilton, E. Lucero, H. Neven, A. Megrant, J. Kelly, P. Roushan, I. Aleiner, V. Smelyanskiy, K. Kechedzhi, Y. Chen & S. Boixo
Quantum Artificial Intelligence Laboratory, NASA Ames Research Center, Moffett Field, CA, USA S. Mandrà, E. G. Rieffel & R. Biswas
KBR, Houston, TX, USA S. Mandrà
Department of Physics, University of Connecticut, Storrs, CT, USA I. K. Drozdov
Strativia, Foreign Guest Researcher (Contractor) at National Institute of Standards and Technology (NIST), Gaithersburg, MD, USA L. T. A. N. Brandão
National Institute of Standards and Technology (NIST), Gaithersburg, MD, USA R. Peralta
Department of Electrical and Computer Engineering, University of Massachusetts, Amherst, MA, USA J. C. Bardin
Department of Electrical and Computer Engineering, Auburn University, Auburn, AL, USA M. C. Hamilton
QSI, Faculty of Engineering and Information Technology, University of Technology Sydney, Sydney, New South Wales, Australia M. Kieferová
Department of Electrical and Computer Engineering, University of California, Riverside, CA, USA A. N. Korotkov
Department of Chemistry and Chemical Biology, Harvard University, Cambridge, MA, USA J. Lee
Department of Physics and Astronomy, University of California, Riverside, CA, USA L. P. Pryadko
Authors A. Morvan View author publications  Search author on: PubMed   Google Scholar
B. Villalonga View author publications  Search author on: PubMed   Google Scholar
X. Mi View author publications  Search author on: PubMed   Google Scholar
S. Mandrà View author publications  Search author on: PubMed   Google Scholar
A. Bengtsson View author publications  Search author on: PubMed   Google Scholar
P. V. Klimov View author publications  Search author on: PubMed   Google Scholar
Z. Chen View author publications  Search author on: PubMed   Google Scholar
S. Hong View author publications  Search author on: PubMed   Google Scholar
C. Erickson View author publications  Search author on: PubMed   Google Scholar
I. K. Drozdov View author publications  Search author on: PubMed   Google Scholar
J. Chau View author publications  Search author on: PubMed   Google Scholar
G. Laun View author publications  Search author on: PubMed   Google Scholar
R. Movassagh View author publications  Search author on: PubMed   Google Scholar
A. Asfaw View author publications  Search author on: PubMed   Google Scholar
L. T. A. N. Brandão View author publications  Search author on: PubMed   Google Scholar
R. Peralta View author publications  Search author on: PubMed   Google Scholar
D. Abanin View author publications  Search author on: PubMed   Google Scholar
R. Acharya View author publications  Search author on: PubMed   Google Scholar
R. Allen View author publications  Search author on: PubMed   Google Scholar
T. I. Andersen View author publications  Search author on: PubMed   Google Scholar
K. Anderson View author publications  Search author on: PubMed   Google Scholar
M. Ansmann View author publications  Search author on: PubMed   Google Scholar
F. Arute View author publications  Search author on: PubMed   Google Scholar
K. Arya View author publications  Search author on: PubMed   Google Scholar
J. Atalaya View author publications  Search author on: PubMed   Google Scholar
J. C. Bardin View author publications  Search author on: PubMed   Google Scholar
A. Bilmes View author publications  Search author on: PubMed   Google Scholar
G. Bortoli View author publications  Search author on: PubMed   Google Scholar
A. Bourassa View author publications  Search author on: PubMed   Google Scholar
J. Bovaird View author publications  Search author on: PubMed   Google Scholar
L. Brill View author publications  Search author on: PubMed   Google Scholar
M. Broughton View author publications  Search author on: PubMed   Google Scholar
B. B. Buckley View author publications  Search author on: PubMed   Google Scholar
D. A. Buell View author publications  Search author on: PubMed   Google Scholar
T. Burger View author publications  Search author on: PubMed   Google Scholar
B. Burkett View author publications  Search author on: PubMed   Google Scholar
N. Bushnell View author publications  Search author on: PubMed   Google Scholar
J. Campero View author publications  Search author on: PubMed   Google Scholar
H.-S. Chang View author publications  Search author on: PubMed   Google Scholar
B. Chiaro View author publications  Search author on: PubMed   Google Scholar
D. Chik View author publications  Search author on: PubMed   Google Scholar
C. Chou View author publications  Search author on: PubMed   Google Scholar
J. Cogan View author publications  Search author on: PubMed   Google Scholar
R. Collins View author publications  Search author on: PubMed   Google Scholar
P. Conner View author publications  Search author on: PubMed   Google Scholar
W. Courtney View author publications  Search author on: PubMed   Google Scholar
A. L. Crook View author publications  Search author on: PubMed   Google Scholar
B. Curtin View author publications  Search author on: PubMed   Google Scholar
D. M. Debroy View author publications  Search author on: PubMed   Google Scholar
A. Del Toro Barba View author publications  Search author on: PubMed   Google Scholar
S. Demura View author publications  Search author on: PubMed   Google Scholar
A. Di Paolo View author publications  Search author on: PubMed   Google Scholar
A. Dunsworth View author publications  Search author on: PubMed   Google Scholar
L. Faoro View author publications  Search author on: PubMed   Google Scholar
E. Farhi View author publications  Search author on: PubMed   Google Scholar
R. Fatemi View author publications  Search author on: PubMed   Google Scholar
V. S. Ferreira View author publications  Search author on: PubMed   Google Scholar
L. Flores Burgos View author publications  Search author on: PubMed   Google Scholar
E. Forati View author publications  Search author on: PubMed   Google Scholar
A. G. Fowler View author publications  Search author on: PubMed   Google Scholar
B. Foxen View author publications  Search author on: PubMed   Google Scholar
G. Garcia View author publications  Search author on: PubMed   Google Scholar
É. Genois View author publications  Search author on: PubMed   Google Scholar
W. Giang View author publications  Search author on: PubMed   Google Scholar
C. Gidney View author publications  Search author on: PubMed   Google Scholar
D. Gilboa View author publications  Search author on: PubMed   Google Scholar
M. Giustina View author publications  Search author on: PubMed   Google Scholar
R. Gosula View author publications  Search author on: PubMed   Google Scholar
A. Grajales Dau View author publications  Search author on: PubMed   Google Scholar
J. A. Gross View author publications  Search author on: PubMed   Google Scholar
S. Habegger View author publications  Search author on: PubMed   Google Scholar
M. C. Hamilton View author publications  Search author on: PubMed   Google Scholar
M. Hansen View author publications  Search author on: PubMed   Google Scholar
M. P. Harrigan View author publications  Search author on: PubMed   Google Scholar
S. D. Harrington View author publications  Search author on: PubMed   Google Scholar
P. Heu View author publications  Search author on: PubMed   Google Scholar
M. R. Hoffmann View author publications  Search author on: PubMed   Google Scholar
T. Huang View author publications  Search author on: PubMed   Google Scholar
A. Huff View author publications  Search author on: PubMed   Google Scholar
W. J. Huggins View author publications  Search author on: PubMed   Google Scholar
L. B. Ioffe View author publications  Search author on: PubMed   Google Scholar
S. V. Isakov View author publications  Search author on: PubMed   Google Scholar
J. Iveland View author publications  Search author on: PubMed   Google Scholar
E. Jeffrey View author publications  Search author on: PubMed   Google Scholar
Z. Jiang View author publications  Search author on: PubMed   Google Scholar
C. Jones View author publications  Search author on: PubMed   Google Scholar
P. Juhas View author publications  Search author on: PubMed   Google Scholar
D. Kafri View author publications  Search author on: PubMed   Google Scholar
T. Khattar View author publications  Search author on: PubMed   Google Scholar
M. Khezri View author publications  Search author on: PubMed   Google Scholar
M. Kieferová View author publications  Search author on: PubMed   Google Scholar
S. Kim View author publications  Search author on: PubMed   Google Scholar
A. Kitaev View author publications  Search author on: PubMed   Google Scholar
A. R. Klots View author publications  Search author on: PubMed   Google Scholar
A. N. Korotkov View author publications  Search author on: PubMed   Google Scholar
F. Kostritsa View author publications  Search author on: PubMed   Google Scholar
J. M. Kreikebaum View author publications  Search author on: PubMed   Google Scholar
D. Landhuis View author publications  Search author on: PubMed   Google Scholar
P. Laptev View author publications  Search author on: PubMed   Google Scholar
K.-M. Lau View author publications  Search author on: PubMed   Google Scholar
L. Laws View author publications  Search author on: PubMed   Google Scholar
J. Lee View author publications  Search author on: PubMed   Google Scholar
K. W. Lee View author publications  Search author on: PubMed   Google Scholar
Y. D. Lensky View author publications  Search author on: PubMed   Google Scholar
B. J. Lester View author publications  Search author on: PubMed   Google Scholar
A. T. Lill View author publications  Search author on: PubMed   Google Scholar
W. Liu View author publications  Search author on: PubMed   Google Scholar
W. P. Livingston View author publications  Search author on: PubMed   Google Scholar
A. Locharla View author publications  Search author on: PubMed   Google Scholar
F. D. Malone View author publications  Search author on: PubMed   Google Scholar
O. Martin View author publications  Search author on: PubMed   Google Scholar
S. Martin View author publications  Search author on: PubMed   Google Scholar
J. R. McClean View author publications  Search author on: PubMed   Google Scholar
M. McEwen View author publications  Search author on: PubMed   Google Scholar
K. C. Miao View author publications  Search author on: PubMed   Google Scholar
A. Mieszala View author publications  Search author on: PubMed   Google Scholar
S. Montazeri View author publications  Search author on: PubMed   Google Scholar
W. Mruczkiewicz View author publications  Search author on: PubMed   Google Scholar
O. Naaman View author publications  Search author on: PubMed   Google Scholar
M. Neeley View author publications  Search author on: PubMed   Google Scholar
C. Neill View author publications  Search author on: PubMed   Google Scholar
A. Nersisyan View author publications  Search author on: PubMed   Google Scholar
M. Newman View author publications  Search author on: PubMed   Google Scholar
J. H. Ng View author publications  Search author on: PubMed   Google Scholar
A. Nguyen View author publications  Search author on: PubMed   Google Scholar
M. Nguyen View author publications  Search author on: PubMed   Google Scholar
M. Yuezhen Niu View author publications  Search author on: PubMed   Google Scholar
T. E. O’Brien View author publications  Search author on: PubMed   Google Scholar
S. Omonije View author publications  Search author on: PubMed   Google Scholar
A. Opremcak View author publications  Search author on: PubMed   Google Scholar
A. Petukhov View author publications  Search author on: PubMed   Google Scholar
R. Potter View author publications  Search author on: PubMed   Google Scholar
L. P. Pryadko View author publications  Search author on: PubMed   Google Scholar
C. Quintana View author publications  Search author on: PubMed   Google Scholar
D. M. Rhodes View author publications  Search author on: PubMed   Google Scholar
C. Rocque View author publications  Search author on: PubMed   Google Scholar
E. Rosenberg View author publications  Search author on: PubMed   Google Scholar
N. C. Rubin View author publications  Search author on: PubMed   Google Scholar
N. Saei View author publications  Search author on: PubMed   Google Scholar
D. Sank View author publications  Search author on: PubMed   Google Scholar
K. Sankaragomathi View author publications  Search author on: PubMed   Google Scholar
K. J. Satzinger View author publications  Search author on: PubMed   Google Scholar
H. F. Schurkus View author publications  Search author on: PubMed   Google Scholar
C. Schuster View author publications  Search author on: PubMed   Google Scholar
M. J. Shearn View author publications  Search author on: PubMed   Google Scholar
A. Shorter View author publications  Search author on: PubMed   Google Scholar
N. Shutty View author publications  Search author on: PubMed   Google Scholar
V. Shvarts View author publications  Search author on: PubMed   Google Scholar
V. Sivak View author publications  Search author on: PubMed   Google Scholar
J. Skruzny View author publications  Search author on: PubMed   Google Scholar
W. C. Smith View author publications  Search author on: PubMed   Google Scholar
R. D. Somma View author publications  Search author on: PubMed   Google Scholar
G. Sterling View author publications  Search author on: PubMed   Google Scholar
D. Strain View author publications  Search author on: PubMed   Google Scholar
M. Szalay View author publications  Search author on: PubMed   Google Scholar
D. Thor View author publications  Search author on: PubMed   Google Scholar
A. Torres View author publications  Search author on: PubMed   Google Scholar
G. Vidal View author publications  Search author on: PubMed   Google Scholar
C. Vollgraff Heidweiller View author publications  Search author on: PubMed   Google Scholar
T. White View author publications  Search author on: PubMed   Google Scholar
B. W. K. Woo View author publications  Search author on: PubMed   Google Scholar
C. Xing View author publications  Search author on: PubMed   Google Scholar
Z. J. Yao View author publications  Search author on: PubMed   Google Scholar
P. Yeh View author publications  Search author on: PubMed   Google Scholar
J. Yoo View author publications  Search author on: PubMed   Google Scholar
G. Young View author publications  Search author on: PubMed   Google Scholar
A. Zalcman View author publications  Search author on: PubMed   Google Scholar
Y. Zhang View author publications  Search author on: PubMed   Google Scholar
N. Zhu View author publications  Search author on: PubMed   Google Scholar
N. Zobrist View author publications  Search author on: PubMed   Google Scholar
E. G. Rieffel View author publications  Search author on: PubMed   Google Scholar
R. Biswas View author publications  Search author on: PubMed   Google Scholar
R. Babbush View author publications  Search author on: PubMed   Google Scholar
D. Bacon View author publications  Search author on: PubMed   Google Scholar
J. Hilton View author publications  Search author on: PubMed   Google Scholar
E. Lucero View author publications  Search author on: PubMed   Google Scholar
H. Neven View author publications  Search author on: PubMed   Google Scholar
A. Megrant View author publications  Search author on: PubMed   Google Scholar
J. Kelly View author publications  Search author on: PubMed   Google Scholar
P. Roushan View author publications  Search author on: PubMed   Google Scholar
I. Aleiner View author publications  Search author on: PubMed   Google Scholar
V. Smelyanskiy View author publications  Search author on: PubMed   Google Scholar
K. Kechedzhi View author publications  Search author on: PubMed   Google Scholar
Y. Chen View author publications  Search author on: PubMed   Google Scholar
S. Boixo View author publications  Search author on: PubMed   Google Scholar
Contributions Y.C. and S.B. led the overall project. A. Morvan and X.M. performed the experiments. A. Bengtsson contributed to read-out developments. X.M. and P.V.K. contributed to gate developments. B.V. developed and ran the tensor network contraction optimizations. S. Mandrà developed and ran the matrix product states simulations. A. Morvan, Z.C., S. Hong, C.E., P.V.K. and I.K.D. contributed to the large-system calibration and stability improvements. I.A. and K.K. developed the theories and performed the numerical simulations of the phase transitions. R.M. proved the XEB for approximate tensor representations. J. Chau, G.L., R.M., L.T.A.N.B. and R. Peralta worked on the certified randomness. A.A. provided technical programme management to the project. All authors contributed to building the hardware and software infrastructures and writing the manuscript. Corresponding author Correspondence to K. Kechedzhi .
Ethics declarations
Competing interests
The authors declare no competing interests.
Peer review
Peer review information
Nature thanks Yunchao Liu, Pan Zhang and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available.
Additional information Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.
Supplementary information
Supplementary Information (download PDF )
Peer Review File (download PDF )
Rights and permissions
Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence to share adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by-nc-nd/4.0/ .
Reprints and permissions
About this article
Cite this article Morvan, A., Villalonga, B., Mi, X. et al. Phase transitions in random circuit sampling. Nature 634 , 328–333 (2024). https://doi.org/10.1038/s41586-024-07998-6 Download citation  Received : 09 January 2024
Accepted : 28 August 2024
Published : 09 October 2024
Version of record : 09 October 2024
Issue date : 10 October 2024
DOI : https://doi.org/10.1038/s41586-024-07998-6
Share this article Anyone you share the following link with will be able to read this content: Get shareable link Sorry, a shareable link is not currently available for this article.
Copy shareable link to clipboard
Provided by the Springer Nature SharedIt content-sharing initiative
Subjects
Quantum information  Quantum simulation
This article is cited by
Treespilation: architecture- and state-optimised fermion-to-qubit mappings
Aaron Miller Adam Glos Zoltán Zimborás
npj Quantum Information (2026)
A Short Introduction to Quantum Error Correction
Thiago Lucena de Macedo Guedes
Brazilian Journal of Physics (2026)
Applications of certified randomness
Omar Amer Shouvanik Chakrabarti Marco Pistoia
Nature Reviews Physics (2025)
Quantum computing and the implementation of precision medicine
Nasna Nassir Mohammad Amiruddin Hashmi Mohammed Uddin
npj Genomic Medicine (2025)
Error crafting in mixed quantum gate synthesis
Nobuyuki Yoshioka Seiseki Akibue Yasunari Suzuki
npj Quantum Information (2025)
Download PDF
Sections  Figures  References  Abstract  Main  Data availability  Code availability  References  Acknowledgements  Author information  Ethics declarations  Peer review  Additional information  Supplementary information  Rights and permissions  About this article  This article is cited by
Advertisement
Fig. 1: Phase transitions in RCS. View in article Full size image
Fig. 2: Phase transitions in the linear cross-entropy. View in article Full size image
Fig. 3: Noise-induced phase transitions. View in article Full size image
Fig. 4: Demonstration of a classically intractable computation. View in article Full size image
Preskill, J. Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article    Google Scholar
Boixo, S. et al. Characterizing quantum supremacy in near-term devices. Nat. Phys. 14 , 595–600 (2018). Article   CAS    Google Scholar
Neill, C. et al. A blueprint for demonstrating quantum supremacy with superconducting qubits. Science 360 , 195–199 (2018). Article   ADS   MathSciNet   CAS   PubMed    Google Scholar
Arute, F. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). Article   ADS   CAS   PubMed    Google Scholar
Wu, Y. et al. Strong quantum computational advantage using a superconducting quantum processor. Phys. Rev. Lett. 127 , 180501 (2021). Article   ADS   CAS   PubMed    Google Scholar
Zhu, Q. et al. Quantum computational advantage via 60-qubit 24-cycle random circuit sampling. Sci. Bull. 67 , 240–245 (2022). Article    Google Scholar
Liu, Y. et al. Verifying quantum advantage experiments with multiple amplitude tensor network contraction. Phys. Rev. Lett. 132 , 030601 (2024).
Mark, D. K., Choi, J., Shaw, A. L., Endres, M. & Choi, S. Benchmarking quantum simulators using ergodic quantum dynamics. Phys. Rev. Lett. 131 , 110601 (2023). Article   ADS   CAS   PubMed    Google Scholar
Shaw, A. L. et al. Benchmarking highly entangled states on a 60-atom analogue quantum simulator. Nature 628 , 71–77 (2024).
Bluvstein, D. et al. Logical quantum processor based on reconfigurable atom arrays. Nature 626 , 58–65 (2022).
Markov, I. L. & Shi, Y. Simulating quantum computation by contracting tensor networks. SIAM J. Comput. https://doi.org/10.1137/050644756 (2008). Article   MathSciNet    Google Scholar
Boixo, S., Isakov, S. V., Smelyanskiy, V. N. & Neven, H. Simulation of low-depth quantum circuits as complex undirected graphical models. Preprint at https://arxiv.org/abs/1712.05384 (2017).
Gray, J. & Kourtis, S. Hyper-optimized tensor network contraction. Quantum 5 , 410 (2021). Article    Google Scholar
Huang, C. et al. Classical simulation of quantum supremacy circuits. Preprint at https://arxiv.org/abs/2005.06787 (2020).
Pan, F., Chen, K. & Zhang, P. Solving the sampling problem of the Sycamore quantum circuits. Phys. Rev. Lett. 129 , 090502 (2022). Article   ADS   CAS   PubMed    Google Scholar
Kalachev, G., Panteleev, P., Zhou, P. & Yung, M.-H. Classical sampling of random quantum circuits with bounded fidelity. Preprint at https://arxiv.org/abs/2112.15083 (2021).
Kechedzhi, K. et al. Effective quantum volume, fidelity and computational cost of noisy quantum processing experiments. Future Gener. Comput. Syst. 153 , 431–441 (2024). Article    Google Scholar
Markov, I. L., Fatima, A., Isakov, S. V. & Boixo, S. Quantum supremacy is both closer and farther than it appears. Preprint at https://arxiv.org/abs/1807.10749 (2018).
Mi, X. et al. Information scrambling in quantum circuits. Science 374 , 1479–1483 (2021). Article   ADS   CAS   PubMed    Google Scholar
Bertini, B., Kos, P. & Prosen, T. Operator entanglement in local quantum circuits. I. Chaotic dual-unitary circuits. SciPost Phys. 8 , 067 (2020). Article   ADS   MathSciNet    Google Scholar
Liu, Y., Otten, M., Bassirianjahromi, R., Jiang, L. & Fefferman, B. Benchmarking near-term quantum computers via random circuit sampling. Preprint at https://arxiv.org/abs/2105.05232 (2021).
Barak, B., Chou, C.-N. & Gao, X. Spoofing linear cross-entropy benchmarking in shallow quantum circuits. Preprint at https://arxiv.org/abs/2005.02421 (2020).
Dalzell, A. M., Hunter-Jones, N. & Brandão, F. G. S. L. Random quantum circuits anticoncentrate in log depth. PRX Quantum 3 , 010333 (2022). Article   ADS    Google Scholar
Bouland, A., Fefferman, B., Nirkhe, C. & Vazirani, U. On the complexity and verification of quantum random circuit sampling. Nat. Phys. 15 , 159 (2019). Article   CAS    Google Scholar
Movassagh, R. The hardness of random quantum circuits. Nat. Phys. 19 , 1719 (2023). Article   CAS    Google Scholar
Gao, X. et al. Limitations of linear cross-entropy as a measure for quantum advantage. PRX Quantum 5 , 010334 (2024). Article   ADS    Google Scholar
Aharonov, D., Gao, X., Landau, Z., Liu, Y. & Vazirani, U. A polynomial-time classical algorithm for noisy random circuit sampling. In Proc. 55th Annual ACM Symposium on Theory of Computing 945–957 (ACM, 2023).
Ware, B. et al. A sharp phase transition in linear cross-entropy benchmarking. Preprint at https://arxiv.org/abs/2305.04954 (2023).
Dalzell, A. M., Hunter-Jones, N. & Brandão, F. G. Random quantum circuits transform local noise into global white noise. Commun. Math. Phys. 405 , 78 (2024). Article   ADS   MathSciNet    Google Scholar
de Gennes, P. & Prost, J. The Physics of Liquid Crystals (Clarendon, 1993).
Aharonov, D. Quantum to classical phase transition in noisy quantum computers. Phys. Rev. A 62 , 062311 (2000).
Chen, J., Zhang, F., Huang, C., Newman, M. & Shi, Y. Classical simulation of intermediate-size quantum circuits. Preprint at https://arxiv.org/abs/1805.01450 (2018).
Villalonga, B. et al. A flexible high-performance simulator for verifying and benchmarking quantum circuits implemented on real hardware. npj Quantum Inf. 5 , 86 (2019). Article   ADS    Google Scholar
Zlokapa, A., Villalonga, B., Boixo, S. & Lidar, D. A. Boundaries of quantum supremacy via random circuit sampling. npj Quantum Inf. 9 , 36 (2023). Article   ADS    Google Scholar
White, S. R. Density-matrix algorithms for quantum renormalization groups. Phys. Rev. B 48 , 10345 (1993). Article   ADS   CAS    Google Scholar
Vidal, G. Efficient classical simulation of slightly entangled quantum computations. Phys. Rev. Lett. 91 , 147902 (2003). Article   ADS   PubMed    Google Scholar
Ayral, T. et al. Density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity. PRX Quantum 4 , 020304 (2023). Article   ADS    Google Scholar
Aaronson, S. & Arkhipov, A. The computational complexity of linear optics. In Proc. Forty-third Annual ACM Symposium on Theory of Computing 333–342 (2011).
Zhong, H.-S. et al. Quantum computational advantage using photons. Science 370 , 1460–1463 (2020). Article   ADS   CAS   PubMed    Google Scholar
Zhong, H.-S. et al. Phase-programmable Gaussian boson sampling using stimulated squeezed light. Phys. Rev. Lett. 127 , 180502 (2021). Article   ADS   CAS   PubMed    Google Scholar
Madsen, L. S. et al. Quantum computational advantage with a programmable photonic processor. Nature 606 , 75–81 (2022). Article   ADS   CAS   PubMed   PubMed Central    Google Scholar
Villalonga, B. et al. Efficient approximation of experimental Gaussian boson sampling. Preprint at https://arxiv.org/abs/2109.11525 (2021).
Bassirian, R., Bouland, A., Fefferman, B., Gunn, S. & Tal, A. On certified randomness from Fourier sampling or random circuit sampling. Preprint at https://arxiv.org/abs/2111.14846 (2021).
Aaronson, S. & Hung, S.-H. Certified randomness from quantum supremacy. In Proc. 55th Annual ACM Symposium on Theory of Computing 933–944 (ACM, 2023).
Morvan, A. et al. Data for ‘Phase transition in random circuit sampling’. Zenodo https://doi.org/10.5281/zenodo.8253792 (2024).
Nature
( Nature )
ISSN 1476-4687 (online)
ISSN 0028-0836 (print)
nature.com footer links
About Nature Portfolio
About us
Press releases
Press office
Contact us
Discover content
Journals A-Z
Articles by subject
protocols.io
Nature Index
Publishing policies
Nature portfolio policies
Open access
Author & Researcher services
Reprints & permissions
Research data
Language editing
Scientific editing
Nature Masterclasses
Research Solutions
Libraries & institutions
Librarian service & tools
Librarian portal
Open research
Recommend to library
Advertising & partnerships
Advertising
Partnerships & Services
Media kits
Branded content
Professional development
Nature Awards
Nature Careers
Nature  Conferences
Regional websites
Nature Africa
Nature China
Nature India
Nature Japan
Nature Middle East
Privacy Policy
Use of cookies
Your privacy choices/Manage cookies
Legal notice
Accessibility statement
Terms & Conditions
Your US state privacy rights
© 2026 Springer Nature Limited
Close banner
Close
Sign up for the Nature Briefing newsletter — what matters in science, free to your inbox daily.
Email address
Sign up
I agree my information will be processed in accordance with the Nature and Springer Nature Limited Privacy Policy .
Close banner
Close
Get the most important science stories of the day, free in your inbox.  Sign up for Nature Briefing
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [20]: A. D. King et al. — Beyond-classical computation in quantum simulation (Science 388, 199-204, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Beyond-classical computation in quantum simulation
URL: https://doi.org/10.1126/science.adr9284
[2403.00910] Beyond-classical computation in quantum simulation
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2403.00910
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2403.00910 (quant-ph)
[Submitted on 1 Mar 2024 ( v1 ), last revised 14 Oct 2025 (this version, v2)]
Title: Beyond-classical computation in quantum simulation
Authors: Andrew D. King , Alberto Nocera , Marek M. Rams , Jacek Dziarmaga , Roeland Wiersema , William Bernoudy , Jack Raymond , Nitin Kaushal , Niclas Heinsdorf , Richard Harris , Kelly Boothby , Fabio Altomare , Mohsen Asad , Andrew J. Berkley , Martin Boschnak , Kevin Chern , Holly Christiani , Samantha Cibere , Jake Connor , Martin H. Dehn , Rahul Deshpande , Sara Ejtemaee , Pau Farré , Kelsey Hamer , Emile Hoskinson , Shuiyuan Huang , Mark W. Johnson , Samuel Kortas , Eric Ladizinsky , Tony Lai , Trevor Lanting , Ryan Li , Allison J.R. MacDonald , Gaelen Marsden , Catherine C. McGeoch , Reza Molavi , Richard Neufeld , Mana Norouzpour , Travis Oh , Joel Pasvolsky , Patrick Poitras , Gabriel Poulin-Lamarre , Thomas Prescott , Mauricio Reis , Chris Rich , Mohammad Samani , Benjamin Sheldan , Anatoly Smirnov , Edward Sterpka , Berta Trullas Clavera , Nicholas Tsai , Mark Volkmann , Alexander Whiticar , Jed D. Whittaker , Warren Wilkinson , Jason Yao , T.J. Yi , Anders W. Sandvik , Gonzalo Alvarez , Roger G. Melko , Juan Carrasquilla , Marcel Franz , Mohammad H. Amin  View a PDF of the paper titled Beyond-classical computation in quantum simulation, by Andrew D. King and 61 other authors
View PDF  HTML (experimental)
Abstract: Quantum computers hold the promise of solving certain problems that lie beyond the reach of conventional computers. However, establishing this capability, especially for impactful and meaningful problems, remains a central challenge. Here, we show that superconducting quantum annealing processors can rapidly generate samples in close agreement with solutions of the Schrödinger equation. We demonstrate area-law scaling of entanglement in the model quench dynamics of two-, three-, and infinite-dimensional spin glasses, supporting the observed stretched-exponential scaling of effort for matrix-product-state approaches. We show that several leading approximate methods based on tensor networks and neural networks cannot achieve the same accuracy as the quantum annealer within a reasonable time frame. Thus, quantum annealers can answer questions of practical importance that may remain out of reach for classical computation.
Subjects:
Quantum Physics (quant-ph) ; Disordered Systems and Neural Networks (cond-mat.dis-nn); Statistical Mechanics (cond-mat.stat-mech)
Cite as:  arXiv:2403.00910 [quant-ph]
(or  arXiv:2403.00910v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2403.00910
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Science 388, 199-204 (2025)
Related DOI :
https://doi.org/10.1126/science.ado6285
Focus to learn more
DOI(s) linking to related resources
Submission history From: Andrew King [ view email ]  [v1]  Fri, 1 Mar 2024 19:00:04 UTC (6,682 KB)
[v2]  Tue, 14 Oct 2025 21:21:53 UTC (6,953 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled Beyond-classical computation in quantum simulation, by Andrew D. King and 61 other authors View PDF  HTML (experimental)  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2024-03
Change to browse by:
cond-mat  cond-mat.dis-nn  cond-mat.stat-mech
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [21]: S. Ebadi et al. — Quantum phases of matter on a 256-atom programmable quantum simulator (Nature 595, 227-232, 2021)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Quantum phases of matter on a 256-atom programmable quantum simulator
URL: https://doi.org/10.1038/s41586-021-03582-4
Quantum phases of matter on a 256-atom programmable quantum simulator | Nature
Loading [MathJax]/jax/output/HTML-CSS/config.js
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes. By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection. See our privacy policy for more information on the use of your personal data. Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Subscribe
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Subscribe
Sign up for alerts
RSS feed
nature
articles
article
Article
Published: 07 July 2021
Quantum phases of matter on a 256-atom programmable quantum simulator
Sepehr Ebadi 1 ,  Tout T. Wang 1 ,  Harry Levine 1 ,  Alexander Keesling 1 , 2 ,  Giulia Semeghini 1 ,  Ahmed Omran 1 , 2 ,  Dolev Bluvstein 1 ,  Rhine Samajdar   ORCID: orcid.org/0000-0001-5171-7798 1 ,  Hannes Pichler 3 , 4 ,  Wen Wei Ho   ORCID: orcid.org/0000-0001-7702-2900 1 , 5 ,  Soonwon Choi   ORCID: orcid.org/0000-0002-1247-062X 6 ,  Subir Sachdev   ORCID: orcid.org/0000-0002-2432-7070 1 ,  Markus Greiner 1 ,  Vladan Vuletić   ORCID: orcid.org/0000-0002-9786-0538 7 &  … Mikhail D. Lukin   ORCID: orcid.org/0000-0002-8658-1007 1   Show authors
Nature
volume  595 ,  pages 227–232 ( 2021 ) Cite this article
47k Accesses
1048 Citations
329 Altmetric
Metrics details
Abstract Motivated by far-reaching applications ranging from quantum simulations of complex processes in physics and chemistry to quantum information processing 1 , a broad effort is currently underway to build large-scale programmable quantum systems. Such systems provide insights into strongly correlated quantum matter 2 , 3 , 4 , 5 , 6 , while at the same time enabling new methods for computation 7 , 8 , 9 , 10 and metrology 11 . Here we demonstrate a programmable quantum simulator based on deterministically prepared two-dimensional arrays of neutral atoms, featuring strong interactions controlled by coherent atomic excitation into Rydberg states 12 . Using this approach, we realize a quantum spin model with tunable interactions for system sizes ranging from 64 to 256 qubits. We benchmark the system by characterizing high-fidelity antiferromagnetically ordered states and demonstrating quantum critical dynamics consistent with an Ising quantum phase transition in (2 + 1) dimensions 13 . We then create and study several new quantum phases that arise from the interplay between interactions and coherent laser excitation 14 , experimentally map the phase diagram and investigate the role of quantum fluctuations. Offering a new lens into the study of complex quantum matter, these observations pave the way for investigations of exotic quantum phases, non-equilibrium entanglement dynamics and hardware-efficient realization of quantum algorithms.
Access through your institution
Buy or subscribe
This is a preview of subscription content, access via your institution
Access options
Access through your institution
Access Nature and 54 other Nature Portfolio journals
Get Nature+, our best-value online-access subscription
$32.99 / 30 days
cancel any time
Learn more
Subscribe to this journal
Receive 52 print issues and online access
$199.00 per year
only $3.83 per issue
Learn more
Buy this article Purchase on SpringerLink  Instant access to the full article PDF.  USD 39.95
Prices may be subject to local taxes which are calculated during checkout
Additional access options:
Log in
Learn about institutional subscriptions
Read our FAQs
Contact customer support
Fig. 1: Programmable two-dimensional arrays of strongly interacting Rydberg atoms. The alternative text for this image may have been generated using AI.
Fig. 2: Benchmarking of quantum simulator using chequerboard ordering. The alternative text for this image may have been generated using AI.
Fig. 3: Observation of the (2 + 1)D Ising quantum phase transition on a 16 × 16 array. The alternative text for this image may have been generated using AI.
Fig. 4: Phase diagram of the two-dimensional square lattice. The alternative text for this image may have been generated using AI.
Fig. 5: Probing correlations and coherence in the striated phase via quench dynamics. The alternative text for this image may have been generated using AI.
Similar content being viewed by others
Programmable interactions and emergent geometry in an array of atom clouds
Article
22 December 2021
Characterizing a non-equilibrium phase transition on a quantum computer
Article
11 September 2023
Quantum simulation of 2D antiferromagnets with hundreds of Rydberg atoms
Article
07 July 2021
Data availability
The data that support the findings of this study are available from the corresponding author on reasonable request.
References Preskill, J. Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article
Google Scholar
Zhang, J. et al. Observation of a many-body dynamical phase transition with a 53-qubit quantum simulator. Nature 551 , 601–604 (2017). Article   ADS   CAS   PubMed   PubMed Central
Google Scholar
Gross, C. & Bloch, I. Quantum simulations with ultracold atoms in optical lattices. Science 357 , 995–1001 (2017). Article   ADS   CAS   PubMed
Google Scholar
Choi, J.-y. et al. Exploring the many-body localization transition in two dimensions. Science 352 , 1547–1552 (2016). Article   ADS   MathSciNet   CAS   PubMed   MATH
Google Scholar
Mazurenko, A. et al. A cold-atom Fermi–Hubbard antiferromagnet. Nature 545 , 462–466 (2017). Article   ADS   CAS   PubMed
Google Scholar
Bernien, H. et al. Probing many-body dynamics on a 51-atom quantum simulator. Nature 551 , 579–584 (2017). Article   ADS   CAS   PubMed
Google Scholar
Neill, C. et al. Accurately computing electronic properties of a quantum ring. Preprint at https://arxiv.org/abs/2012.00921v2 (2021).
Wang, C. S. et al. Efficient multiphoton sampling of molecular vibronic spectra on a superconducting bosonic processor. Phys. Rev. X 10 , 021060 (2020). ADS   CAS
Google Scholar
Arute, F. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). Article   ADS   CAS   PubMed
Google Scholar
Zhong, H.-S. et al. Quantum computational advantage using photons. Science 370 , 1460–1463 (2020). Article   ADS   CAS   PubMed
Google Scholar
Giovannetti, V., Lloyd, S. & Maccone, L. Advances in quantum metrology. Nat. Photon . 5 , 222–229 (2011). Article   ADS   CAS
Google Scholar
Browaeys, A. & Lahaye, T. Many-body physics with individually controlled Rydberg atoms. Nat. Phys . 16 , 132–142 (2020). Article   CAS
Google Scholar
Sachdev, S. Quantum Phase Transitions 2nd edn (Cambridge Univ. Press, 2011).
Samajdar, R., Ho, W. W., Pichler, H., Lukin, M. D. & Sachdev, S. Complex density wave orders and quantum phase transitions in a model of square-lattice Rydberg atom arrays. Phys. Rev. Lett . 124 , 103601 (2020). Article   ADS   CAS   PubMed
Google Scholar
Pagano, G. et al. Quantum approximate optimization of the long-range Ising model with a trapped-ion quantum simulator. Proc. Natl Acad. Sci. USA 117 , 25396–25401 (2020). Article   ADS   CAS   PubMed   PubMed Central   MathSciNet
Google Scholar
Friis, N. et al. Observation of entangled states of a fully controlled 20-qubit system. Phys. Rev. X 8 , 021012 (2018). CAS
Google Scholar
Harris, R. et al. Phase transitions in a programmable quantum spin glass simulator. Science 361 , 162–165 (2018). Article   ADS   MathSciNet   CAS   PubMed
Google Scholar
Labuhn, H. et al. Tunable two-dimensional arrays of single Rydberg atoms for realizing quantum Ising models. Nature 534 , 667–670 (2016). Article   ADS   CAS   PubMed
Google Scholar
Morgado, M. & Whitlock, S. Quantum simulation and computing with Rydberg qubits. AVS Quantum Sci . 3 , 023501 (2021). Article   ADS   CAS
Google Scholar
Lienhard, V. et al. Observing the space- and time-dependent growth of correlations in dynamically tuned synthetic Ising models with antiferromagnetic interactions. Phys. Rev. X 8 , 021070 (2018). CAS
Google Scholar
Guardado-Sanchez, E. et al. Probing the quench dynamics of antiferromagnetic correlations in a 2D quantum Ising spin system. Phys. Rev. X 8 , 021069 (2018). CAS
Google Scholar
Kim, H., Park, Y., Kim, K., Sim, H.-S. & Ahn, J. Detailed balance of thermalization dynamics in Rydberg-atom quantum simulators. Phys. Rev. Lett . 120 , 180502 (2018). Article   ADS   CAS   PubMed
Google Scholar
de Léséleuc, S. et al. Observation of a symmetry-protected topological phase of interacting bosons with Rydberg atoms. Science 365 , 775–780 (2019). Article   ADS   MathSciNet   PubMed   MATH   CAS
Google Scholar
Keesling, A. et al. Quantum Kibble–Zurek mechanism and critical dynamics on a programmable Rydberg simulator. Nature 568 , 207–211 (2019). Article   ADS   CAS   PubMed
Google Scholar
Madjarov, I. S. et al. High-fidelity entanglement and detection of alkaline-earth Rydberg atoms. Nat. Phys . 16 , 857–861 (2020). Article   CAS
Google Scholar
Omran, A. et al. Generation and manipulation of Schrödinger cat states in Rydberg atom arrays. Science 365 , 570–574 (2019). Article   ADS   MathSciNet   CAS   PubMed
Google Scholar
Graham, T. M. et al. Rydberg mediated entanglement in a two-dimensional neutral atom qubit array. Phys. Rev. Lett . 123 , 230501 (2019). Article   ADS   CAS   PubMed
Google Scholar
Levine, H. et al. Parallel implementation of high-fidelity multiqubit gates with neutral atoms. Phys. Rev. Lett . 123 , 170503 (2019). Article   ADS   CAS   PubMed
Google Scholar
Madjarov, I. S. et al. An atomic-array optical clock with single-atom readout. Phys. Rev. X 9 , 041052 (2019). CAS
Google Scholar
Young, A. W. et al. Half-minute-scale atomic coherence and high relative stability in a tweezer clock. Nature 588 , 408–413 (2020). Article   ADS   CAS   PubMed
Google Scholar
Schymik, K.-N. et al. Enhanced atom-by-atom assembly of arbitrary tweezers arrays. Phys. Rev. A 102 , 063107 (2020). Article   ADS   CAS
Google Scholar
Kumar, A., Wu, T.-Y., Giraldo, F. & Weiss, D. S. Sorting ultracold atoms in a three-dimensional optical lattice in a realization of Maxwell’s demon. Nature 561 , 83–87 (2018). Article   ADS   CAS   PubMed
Google Scholar
Ohl de Mello, D. et al. Defect-free assembly of 2D clusters of more than 100 single-atom quantum systems. Phys. Rev. Lett . 122 , 203601 (2019). Article   ADS   CAS   PubMed
Google Scholar
Barredo, D., Lienhard, V., de Léséleuc, S., Lahaye, T. & Browaeys, A. Synthetic three-dimensional atomic structures assembled atom by atom. Nature 561 , 79–82 (2018). Article   ADS   CAS   PubMed
Google Scholar
Barredo, D., de Léséleuc, S., Lienhard, V., Lahaye, T. & Browaeys, A. An atom-by-atom assembler of defect-free arbitrary 2D atomic arrays. Science 354 , 1021–1023 (2016). Article   ADS   CAS   PubMed
Google Scholar
Jaksch, D. et al. Fast quantum gates for neutral atoms. Phys. Rev. Lett . 85 , 2208 (2000). Article   ADS   CAS   PubMed
Google Scholar
Lukin, M. D. et al. Dipole blockade and quantum information processing in mesoscopic atomic ensembles. Phys. Rev. Lett . 87 , 037901 (2001). Article   ADS   CAS   PubMed
Google Scholar
Gardas, B., Dziarmaga, J., Zurek, W. H. & Zwolak, M. Defects in quantum computers. Sci. Rep . 8 , 4539 (2018). Article   ADS   PubMed   PubMed Central   CAS
Google Scholar
Zurek, W. H., Dorner, U. & Zoller, P. Dynamics of a quantum phase transition. Phys. Rev. Lett . 95 , 105701 (2005). Article   ADS   PubMed   CAS
Google Scholar
Felser, T., Notarnicola, S. & Montangero, S. Efficient tensor network ansatz for high-dimensional quantum many-body problems. Phys. Rev. Lett . 126 , 170603 (2021). Article   ADS   MathSciNet   CAS   PubMed
Google Scholar
Huang, H.-Y., Kueng, R. & Preskill, J. Predicting many properties of a quantum system from very few measurements. Nat. Phys . 16 , 1050–1057 (2020). Article   CAS
Google Scholar
Verresen, R., Lukin, M. D. & Vishwanath, A. Prediction of toric code topological order from Rydberg blockade. Preprint at https://arxiv.org/abs/2011.12310 (2020).
Samajdar, R., Ho, W. W., Pichler, H., Lukin, M. D. & Sachdev, S. Quantum phases of Rydberg atoms on a kagome lattice. Proc. Natl Acad. Sci. USA 118 , e2015785118 (2021). Article   CAS   PubMed   PubMed Central
Google Scholar
Semeghini, G. et al. Probing topological spin liquids on a programmable quantum simulator. Preprint at https://arxiv.org/abs/2104.04119 (2021).
Saskin, S., Wilson, J. T., Grinkemeyer, B. & Thompson, J. D. Narrow-line cooling and imaging of ytterbium atoms in an optical tweezer array. Phys. Rev. Lett . 122 , 143002 (2019). Article   ADS   CAS   PubMed
Google Scholar
Anderegg, L. et al. An optical tweezer array of ultracold molecules. Science 365 , 1156–1158 (2019). Article   ADS   CAS   PubMed
Google Scholar
Liu, L. R. et al. Building one molecule from a reservoir of two atoms. Science 360 , 900–903 (2018). Article   ADS   CAS   PubMed
Google Scholar
Turner, C. J., Michailidis, A. A., Abanin, D. A., Serbyn, M. & Papić, Z. Weak ergodicity breaking from quantum many-body scars. Nat. Phys . 14 , 745–749 (2018). Article   CAS
Google Scholar
Surace, F. M. et al. Lattice gauge theories and string dynamics in Rydberg atom quantum simulators. Phys. Rev. X 10 , 021041 (2020). CAS
Google Scholar
Bluvstein, D. et al. Controlling quantum many-body dynamics in driven Rydberg atom arrays. Science 371 , 1355–1359 (2021). Article   ADS   CAS   PubMed   MathSciNet
Google Scholar
Diehl, H. W. The theory of boundary critical phenomena. Int. J. Mod. Phys. B 11 , 3503–3523 (1997). Article   ADS
Google Scholar
Bañuls, M. C. et al. Simulating lattice gauge theories within quantum technologies. Eur. Phys. J. D 74 , 165 (2020). Article   ADS   CAS
Google Scholar
Notarnicola, S., Collura, M. & Montangero, S. Real-time-dynamics quantum simulation of (1 + 1)-dimensional lattice QED with Rydberg atoms. Phys. Rev. Research 2 , 013288 (2020). Article   ADS   CAS
Google Scholar
Weimer, H., Müller, M., Lesanovsky, I., Zoller, P. & Büchler, H. P. A Rydberg quantum simulator. Nat. Phys . 6 , 382–388 (2010). Article   CAS
Google Scholar
Auger, J. M., Bergamini, S. & Browne, D. E. Blueprint for fault-tolerant quantum computation with Rydberg atoms. Phys. Rev. A 96 , 052320 (2017). Article
Google Scholar
Farhi, E., Goldstone, J. & Gutmann, S. A quantum approximate optimization algorithm. Preprint at https://arxiv.org/abs/1411.4028 (2014).
Zhou, L., Wang, S.-T., Choi, S., Pichler, H. & Lukin, M. D. Quantum approximate optimization algorithm: performance, mechanism, and implementation on near-term devices. Phys. Rev. X 10 , 021067 (2020). CAS
Google Scholar
Wild, D. S., Sels, D., Pichler, H. & Lukin, M. D. Quantum sampling algorithms for near-term devices. Preprint at https://arxiv.org/abs/2005.14059 (2020).
Scholl, P. et al. Programmable quantum simulation of 2D antiferromagnets with hundreds of Rydberg atoms. Nature https://doi.org/10.1038/s41586-021-03585-1 (2021).
Kim, D. et al. Large-scale uniform optical focus array generation with a phase spatial light modulator. Opt. Lett . 44 , 3178–3181 (2019). Article   ADS   PubMed
Google Scholar
Endres, M. et al. Atom-by-atom assembly of defect-free one-dimensional cold atom arrays. Science 354 , 1024–1027 (2016). Article   ADS   CAS   PubMed
Google Scholar
Lee, W., Kim, H. & Ahn, J. Defect-free atomic array formation using the Hungarian matching algorithm. Phys. Rev. A 95 , 053424 (2017). Article   ADS
Google Scholar
Sheng, C. et al. Efficient preparation of 2D defect-free atom arrays with near-fewest sorting-atom moves. Phys. Rev. Research 3 , 023008 (2021). Article   ADS   CAS
Google Scholar
Levine, H. et al. High-fidelity control and entanglement of Rydberg-atom qubits. Phys. Rev. Lett . 121 , 123603 (2018). Article   ADS   CAS   PubMed
Google Scholar
Bowman, D. et al. High-fidelity phase and amplitude control of phase-only computer generated holograms using conjugate gradient minimisation. Opt. Express 25 , 11692–11700 (2017). Article   ADS   CAS   PubMed
Google Scholar
Zupancic, P. et al. Ultra-precise holographic beam shaping for microscopic quantum control. Opt. Express 24 , 13881–13893 (2016). Article   ADS   CAS   PubMed
Google Scholar
Beterov, I. I., Ryabtsev, I. I., Tretyakov, D. B. & Entin, V. M. Quasiclassical calculations of blackbody-radiation-induced depopulation rates and effective lifetimes of Rydberg nS, nP , and nD alkali-metal atoms with n  ≤ 80. Phys. Rev. A 79 , 052504 (2009). Article   ADS   CAS
Google Scholar
Bhattacharjee, S. M. & Seno, F. A measure of data collapse for scaling. J. Phys. Math. Gen . 34 , 6375 (2001). Article   ADS   CAS   MATH
Google Scholar
Hasenbusch, M. Monte Carlo study of surface critical phenomena: The special point. Phys. Rev. B 84 , 134405 (2011). Article   ADS   CAS
Google Scholar
White, S. R. Density matrix formulation for quantum renormalization groups. Phys. Rev. Lett . 69 , 2863 (1992). Article   ADS   CAS   PubMed
Google Scholar
White, S. R. Density-matrix algorithms for quantum renormalization groups. Phys. Rev. B 48 , 10345 (1993). Article   ADS   CAS
Google Scholar
Stoudenmire, E. M. & White, S. R. Studying two-dimensional systems with the density matrix renormalization group. Annu. Rev. Condens. Matter Phys . 3 , 111–128 (2012). Article
Google Scholar
Fishman, M., White, S. R. & Stoudenmire, E. M. The ITensor software library for tensor network calculations. Preprint at https://arxiv.org/abs/2007.14822 (2020).
Download references
Acknowledgements We thank many members of the Harvard AMO community, particularly E. Urbach, S. Dakoulas and J. Doyle for enabling safe and productive operation of our laboratories during 2020. We thank H. Bernien, D. Englund, M. Endres, N. Gemelke, D. Kim, P. Stark and A. Zibrov for discussions and experimental help. We acknowledge financial support from the Center for Ultracold Atoms, the US National Science Foundation, the Vannevar Bush Faculty Fellowship, the US Department of Energy (DE-SC0021013 and DOE Quantum Systems Accelerator Center, contract no. 7568717), the Office of Naval Research, the Army Research Office MURI and the DARPA ONISQ programme. T.T.W. acknowledges support from Gordon College. H.L. acknowledges support from the National Defense Science and Engineering Graduate (NDSEG) fellowship. G.S. acknowledges support from a fellowship from the Max Planck/Harvard Research Center for Quantum Optics. D.B. acknowledges support from the NSF Graduate Research Fellowship Program (grant DGE1745303) and the Fannie and John Hertz Foundation. W.W.H. is supported by the Moore Foundation’s EPiQS Initiative grant no. GBMF4306, the NUS development grant AY2019/2020, and the Stanford Institute of Theoretical Physics. S.C. acknowledges support from the Miller Institute for Basic Research in Science. R.S. and S.S. were supported by the US Department of Energy under grant DE-SC0019030. The DMRG calculations were performed using the ITensor Library 73 . The computations in this paper were run on the FASRC Cannon cluster supported by the FAS Division of Science Research Computing Group at Harvard University.
Author information Authors and Affiliations Department of Physics, Harvard University, Cambridge, MA, USA Sepehr Ebadi, Tout T. Wang, Harry Levine, Alexander Keesling, Giulia Semeghini, Ahmed Omran, Dolev Bluvstein, Rhine Samajdar, Wen Wei Ho, Subir Sachdev, Markus Greiner & Mikhail D. Lukin
QuEra Computing Inc., Boston, MA, USA Alexander Keesling & Ahmed Omran
Institute for Theoretical Physics, University of Innsbruck, Innsbruck, Austria Hannes Pichler
Institute for Quantum Optics and Quantum Information, Austrian Academy of Sciences, Innsbruck, Austria Hannes Pichler
Department of Physics, Stanford University, Stanford, CA, USA Wen Wei Ho
Department of Physics, University of California Berkeley, Berkeley, CA, USA Soonwon Choi
Department of Physics and Research Laboratory of Electronics, Massachusetts Institute of Technology, Cambridge, MA, USA Vladan Vuletić
Authors Sepehr Ebadi View author publications  Search author on: PubMed   Google Scholar
Tout T. Wang View author publications  Search author on: PubMed   Google Scholar
Harry Levine View author publications  Search author on: PubMed   Google Scholar
Alexander Keesling View author publications  Search author on: PubMed   Google Scholar
Giulia Semeghini View author publications  Search author on: PubMed   Google Scholar
Ahmed Omran View author publications  Search author on: PubMed   Google Scholar
Dolev Bluvstein View author publications  Search author on: PubMed   Google Scholar
Rhine Samajdar View author publications  Search author on: PubMed   Google Scholar
Hannes Pichler View author publications  Search author on: PubMed   Google Scholar
Wen Wei Ho View author publications  Search author on: PubMed   Google Scholar
Soonwon Choi View author publications  Search author on: PubMed   Google Scholar
Subir Sachdev View author publications  Search author on: PubMed   Google Scholar
Markus Greiner View author publications  Search author on: PubMed   Google Scholar
Vladan Vuletić View author publications  Search author on: PubMed   Google Scholar
Mikhail D. Lukin View author publications  Search author on: PubMed   Google Scholar
Contributions S.E., T.T.W., H.L., A.K., G.S, A.O. and D.B. contributed to building the experimental set-up, performed the measurements and analysed the data. Theoretical analysis was performed by R.S., H.P., W.W.H. and S.C. All work was supervised by S.S., M.G., V.V. and M.D.L. All authors discussed the results and contributed to the manuscript. Corresponding author Correspondence to Mikhail D. Lukin .
Ethics declarations
Competing interests
M.G., V.V. and M.D.L. are co-founders and shareholders of QuEra Computing. A.K. and A.O. are shareholders of QuEra Computing. All other authors declare no competing interests.
Additional information Peer review information Nature thanks the anonymous reviewer(s) for their contribution to the peer review of this work. Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.
Extended data figures and tables
Extended Data Fig. 1 Large arrays of optical tweezers.  The experimental platform produces optical tweezer arrays with up to ~1,000 tweezers and ~50% loading probability per tweezer after 100 ms of magneto-optical trap loading time. a , Camera image of an array of 34 × 30 tweezers (1,020 traps), including aberration correction. b , Sample image of random loading into this tweezer array, with 543 loaded atoms. Atoms are detected on an EMCCD camera with fluorescence imaging.
Extended Data Fig. 2 Correcting for aberrations in the SLM tweezer array.  The aberration correction procedure uses the orthogonality of Zernike polynomials and the fact that correcting aberrations increases tweezer light shifts on the atoms. To independently measure and correct each aberration type, Zernike polynomials are added with variable amplitude to the SLM phase hologram, with values optimized to maximize tweezer light shifts. a , Two common aberration types: horizontal coma (upper) and primary spherical (lower), for which ~50 milliwaves compensation on each reduces aberrations and results in higher-depth traps. b , Correcting for aberrations associated with the 13 lowest-order Zernike polynomials. The sum of all polynomials with their associated coefficients gives the total wavefront correction (RMS ~70 milliwaves) for our optical system, which is summed with the optical tweezer hologram on the SLM. c , Trap depths across a 26 × 13 trap array before and after correction for aberrations. Aberration correction results in tighter focusing (higher trap light shift) and improved homogeneity. Trap depths are measured by probing the light shift of each trap on the \(|5{S}_{1/2},F=2\rangle \to |5{P}_{3/2},F{\prime} =2\rangle \) transition. d , Aberration correction also results in higher and more homogeneous trap frequencies across the array. Trap frequencies are measured by modulating tweezer depths at variable frequencies, resulting in parametric heating and atom loss when the modulation frequency is twice the radial trap frequency. The measurement after correction for aberrations shows a narrower spectrum and higher trap frequencies (averaged over the whole array).
Extended Data Fig. 3 Rearrangement protocol.  a , Sample sequence of individual rearrangement steps. There are two pre-sorting moves (1, 2). Move 3 is the single ejection move. Moves 4–6 consist of parallel vertical sorting within each column, including both upward and downward moves. The upper panel illustrates the frequency spectrum of the waveform in the vertical and horizontal AODs during these moves, with the underlying grid corresponding to the calibrated frequencies that map to SLM array rows and columns. b , Spectrograms representing the horizontal and vertical AOD waveforms over the duration of a single vertical frequency scan during a realistic rearrangement procedure for a 26 × 13 array. The heat-maps show frequency spectra of the AOD waveforms over small time intervals during the scan.
Extended Data Fig. 4 Generating homogeneous Rydberg beams.  a , Measured Gaussian-beam illumination on the SLM for shaping the 420-nm Rydberg beam. A Gaussian fit to these data is used as an input for the hologram optimization algorithm. b , Measured wavefront error through our optical system (after correction), showing a reduction of aberrations to λ /100. c , Computer-generated hologram for creating the 420-nm top-hat beam. d , Measured light intensity of the 420-nm top-hat beam (top), and the cross-section along where atoms will be positioned (bottom). Vertical lines denote the 105-μm region where the beam should be flat. e , Using the measured top-hat intensity, a phase correction is calculated for adding to the initial hologram. f , Resulting top-hat beam after feedback shows considerably improved homogeneity. pk–pk, peak to peak.
Extended Data Fig. 5 Characterizing microwave-enhanced Rydberg detection fidelity.  The effect of strong microwave (MW) pulses on Rydberg atoms is measured by preparing atoms in \(|g\rangle \) , exciting to \(|r\rangle \) with a Rydberg π-pulse, and then applying the microwave pulse before de-exciting residual Rydberg atoms with a final Rydberg π-pulse. (The entire sequence occurs while tweezers are briefly turned off.) a , Broad resonances are observed with varying microwave frequency, corresponding to transitions from \(|r\rangle \)  =  \(|70S\rangle \) to other Rydberg states. Note that the transitions to \(|69P\rangle \) and \(|70P\rangle \) are in the range of 10–12 GHz, and over this entire range there is strong transfer out of  \(|r\rangle \) . Other resonances might be due to multiphoton effects. b , With fixed 6.9-GHz microwave frequency and varying pulse time, there is a rapid transfer out of the Rydberg state on the timescale of several nanoseconds. Over short timescales, there may be coherent oscillations that return population back to \(|r\rangle \) , so a 100-ns pulse is used for enhancement of loss signal of \(|r\rangle \) in the experiment.
Extended Data Fig. 6 Coarse-grained local staggered magnetization.  a , Examples of Rydberg populations n i after a faster (top) and slower (bottom) linear sweep. b , Corresponding coarse-grained local staggered magnetizations m i clearly show larger extents of antiferromagnetically ordered domains (dark blue or dark red) for the slower sweep (bottom) than for the faster sweep (top), as expected from the Kibble–Zurek mechanism. c , Isotropic correlation functions \({G}_{m}^{(2)}\) for the corresponding coarse-grained local staggered magnetizations after a faster (top) or a slower (bottom) sweep. d , As a function of radial distance, correlations \({G}_{m}^{(2)}\) decay exponentially with a length scale corresponding to the correlation length ξ . The two decay curves correspond to faster (orange) and slower (blue) sweeps.
Extended Data Fig. 7 Extracting the quantum critical point.  a , The mean Rydberg excitation density \(\langle n\rangle \) versus detuning Δ / Ω on a 16 × 16 array. The data are fitted within a window (dashed lines) to a cubic polynomial (red curve) as a means of smoothing the data. b , The peak in the numerical derivative of the fitted data (red curve) corresponds to the critical point Δ c / Ω  = 1.12(4) (red shaded regions show uncertainty ranges, obtained from varying fit windows). In contrast, the point-by-point slope of the data (grey) is too noisy to be useful. c , Order parameter \(\mathop{ {\mathcal F} }\limits^{ \sim }({\rm{\pi }},{\rm{\pi }})\) for the chequerboard phase versus Δ / Ω measured on a 16 × 16 array with the value of the critical point from b superimposed (red line), showing the clear growth of the order parameter after the critical point. d , DMRG simulations of  \(\langle n\rangle \) versus Δ / Ω on a 10 × 10 array. For comparison against the experimental fitting procedure, the data from numerics are also fitted to a cubic polynomial within the indicated window (dashed lines). e , The point-by-point slope of the numerical data (blue curve) has a peak at Δ c / Ω  = 1.18 (blue dashed line), in good agreement with the results (red dashed line) from both the numerical derivative of the cubic fit on the same data (red curve) and the result of the experiment. f , DMRG simulation of \(\mathop{ {\mathcal F} }\limits^{ \sim }({\rm{\pi }},{\rm{\pi }})\) versus Δ / Ω , with the exact quantum critical point from numerics shown (red line).
Extended Data Fig. 8 Optimization of data collapse.  a , Distance D between rescaled correlation length \(\mathop{\xi }\limits^{ \sim }\) versus \(\mathop{\varDelta }\limits^{ \sim }\) curves depends on both the location of the quantum critical point Δ c / Ω and on the correlation length critical exponent ν . The independently determined Δ c / Ω (blue line, with uncertainty range in grey) and the experimentally extracted value of ν (dashed red line, with uncertainty range corresponding to the red shaded region) are marked on the plot. b , Our determination of ν (red) from data collapse around the independently determined Δ c / Ω (blue) is consistent across arrays of different sizes. c – e , Data collapse is clearly better at the experimentally determined value ( ν  = 0.62) as compared with the mean-field ( ν  = 0.5) or the (1 + 1)D ( ν  = 1) values. The horizontal extent of the data corresponds to the region of overlap of all rescaled datasets.
Rights and permissions Reprints and permissions
About this article
Cite this article Ebadi, S., Wang, T.T., Levine, H. et al. Quantum phases of matter on a 256-atom programmable quantum simulator. Nature 595 , 227–232 (2021). https://doi.org/10.1038/s41586-021-03582-4 Download citation  Received : 21 December 2020
Accepted : 26 April 2021
Published : 07 July 2021
Version of record : 07 July 2021
Issue date : 08 July 2021
DOI : https://doi.org/10.1038/s41586-021-03582-4
Share this article Anyone you share the following link with will be able to read this content: Get shareable link Sorry, a shareable link is not currently available for this article.
Copy shareable link to clipboard
Provided by the Springer Nature SharedIt content-sharing initiative
Subjects
Phase transitions and critical phenomena  Quantum simulation  Ultracold gases
This article is cited by
A systematic encoding of the quadratic assignment problem onto Rydberg arrays
Nathan Daly Thomas Krauss Julia Shapiro
Quantum Information Processing (2026)
Volcano architecture for scalable quantum processor units
Dong-Qi Ma Qing-Xuan Jie Chang-Ling Zou
Science China Physics, Mechanics & Astronomy (2026)
Multifractal-enriched mobility edges and emergent quantum phases in Rydberg atomic arrays
Shan-Zhong Li Yi-Cai Zhang Zhi Li
Science China Physics, Mechanics & Astronomy (2026)
A fault-tolerant neutral-atom architecture for universal quantum computation
Dolev Bluvstein Alexandra A. Geim Mikhail D. Lukin
Nature (2026)
Fast single atom imaging for optical lattice arrays
Lin Su Alexander Douglas Markus Greiner
Nature Communications (2025)
Access through your institution
Buy or subscribe
Sections  Figures  References  Abstract  Data availability  References  Acknowledgements  Author information  Ethics declarations  Additional information  Extended data figures and tables  Rights and permissions  About this article  This article is cited by
Advertisement
Fig. 1: Programmable two-dimensional arrays of strongly interacting Rydberg atoms.
Fig. 2: Benchmarking of quantum simulator using chequerboard ordering.
Fig. 3: Observation of the (2 + 1)D Ising quantum phase transition on a 16 × 16 array.
Fig. 4: Phase diagram of the two-dimensional square lattice.
Fig. 5: Probing correlations and coherence in the striated phase via quench dynamics.
Extended Data Fig. 1 Large arrays of optical tweezers.
Extended Data Fig. 2 Correcting for aberrations in the SLM tweezer array.
Extended Data Fig. 3 Rearrangement protocol.
Extended Data Fig. 4 Generating homogeneous Rydberg beams.
Extended Data Fig. 5 Characterizing microwave-enhanced Rydberg detection fidelity.
Extended Data Fig. 6 Coarse-grained local staggered magnetization.
Extended Data Fig. 7 Extracting the quantum critical point.
Extended Data Fig. 8 Optimization of data collapse.
Preskill, J. Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article    Google Scholar
Zhang, J. et al. Observation of a many-body dynamical phase transition with a 53-qubit quantum simulator. Nature 551 , 601–604 (2017). Article   ADS   CAS   PubMed   PubMed Central    Google Scholar
Gross, C. & Bloch, I. Quantum simulations with ultracold atoms in optical lattices. Science 357 , 995–1001 (2017). Article   ADS   CAS   PubMed    Google Scholar
Choi, J.-y. et al. Exploring the many-body localization transition in two dimensions. Science 352 , 1547–1552 (2016). Article   ADS   MathSciNet   CAS   PubMed   MATH    Google Scholar
Mazurenko, A. et al. A cold-atom Fermi–Hubbard antiferromagnet. Nature 545 , 462–466 (2017). Article   ADS   CAS   PubMed    Google Scholar
Bernien, H. et al. Probing many-body dynamics on a 51-atom quantum simulator. Nature 551 , 579–584 (2017). Article   ADS   CAS   PubMed    Google Scholar
Neill, C. et al. Accurately computing electronic properties of a quantum ring. Preprint at https://arxiv.org/abs/2012.00921v2 (2021).
Wang, C. S. et al. Efficient multiphoton sampling of molecular vibronic spectra on a superconducting bosonic processor. Phys. Rev. X 10 , 021060 (2020). ADS   CAS    Google Scholar
Arute, F. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). Article   ADS   CAS   PubMed    Google Scholar
Zhong, H.-S. et al. Quantum computational advantage using photons. Science 370 , 1460–1463 (2020). Article   ADS   CAS   PubMed    Google Scholar
Giovannetti, V., Lloyd, S. & Maccone, L. Advances in quantum metrology. Nat. Photon . 5 , 222–229 (2011). Article   ADS   CAS    Google Scholar
Browaeys, A. & Lahaye, T. Many-body physics with individually controlled Rydberg atoms. Nat. Phys . 16 , 132–142 (2020). Article   CAS    Google Scholar
Sachdev, S. Quantum Phase Transitions 2nd edn (Cambridge Univ. Press, 2011).
Samajdar, R., Ho, W. W., Pichler, H., Lukin, M. D. & Sachdev, S. Complex density wave orders and quantum phase transitions in a model of square-lattice Rydberg atom arrays. Phys. Rev. Lett . 124 , 103601 (2020). Article   ADS   CAS   PubMed    Google Scholar
Pagano, G. et al. Quantum approximate optimization of the long-range Ising model with a trapped-ion quantum simulator. Proc. Natl Acad. Sci. USA 117 , 25396–25401 (2020). Article   ADS   CAS   PubMed   PubMed Central   MathSciNet    Google Scholar
Friis, N. et al. Observation of entangled states of a fully controlled 20-qubit system. Phys. Rev. X 8 , 021012 (2018). CAS    Google Scholar
Harris, R. et al. Phase transitions in a programmable quantum spin glass simulator. Science 361 , 162–165 (2018). Article   ADS   MathSciNet   CAS   PubMed    Google Scholar
Labuhn, H. et al. Tunable two-dimensional arrays of single Rydberg atoms for realizing quantum Ising models. Nature 534 , 667–670 (2016). Article   ADS   CAS   PubMed    Google Scholar
Morgado, M. & Whitlock, S. Quantum simulation and computing with Rydberg qubits. AVS Quantum Sci . 3 , 023501 (2021). Article   ADS   CAS    Google Scholar
Lienhard, V. et al. Observing the space- and time-dependent growth of correlations in dynamically tuned synthetic Ising models with antiferromagnetic interactions. Phys. Rev. X 8 , 021070 (2018). CAS    Google Scholar
Guardado-Sanchez, E. et al. Probing the quench dynamics of antiferromagnetic correlations in a 2D quantum Ising spin system. Phys. Rev. X 8 , 021069 (2018). CAS    Google Scholar
Kim, H., Park, Y., Kim, K., Sim, H.-S. & Ahn, J. Detailed balance of thermalization dynamics in Rydberg-atom quantum simulators. Phys. Rev. Lett . 120 , 180502 (2018). Article   ADS   CAS   PubMed    Google Scholar
de Léséleuc, S. et al. Observation of a symmetry-protected topological phase of interacting bosons with Rydberg atoms. Science 365 , 775–780 (2019). Article   ADS   MathSciNet   PubMed   MATH   CAS    Google Scholar
Keesling, A. et al. Quantum Kibble–Zurek mechanism and critical dynamics on a programmable Rydberg simulator. Nature 568 , 207–211 (2019). Article   ADS   CAS   PubMed    Google Scholar
Madjarov, I. S. et al. High-fidelity entanglement and detection of alkaline-earth Rydberg atoms. Nat. Phys . 16 , 857–861 (2020). Article   CAS    Google Scholar
Omran, A. et al. Generation and manipulation of Schrödinger cat states in Rydberg atom arrays. Science 365 , 570–574 (2019). Article   ADS   MathSciNet   CAS   PubMed    Google Scholar
Graham, T. M. et al. Rydberg mediated entanglement in a two-dimensional neutral atom qubit array. Phys. Rev. Lett . 123 , 230501 (2019). Article   ADS   CAS   PubMed    Google Scholar
Levine, H. et al. Parallel implementation of high-fidelity multiqubit gates with neutral atoms. Phys. Rev. Lett . 123 , 170503 (2019). Article   ADS   CAS   PubMed    Google Scholar
Madjarov, I. S. et al. An atomic-array optical clock with single-atom readout. Phys. Rev. X 9 , 041052 (2019). CAS    Google Scholar
Young, A. W. et al. Half-minute-scale atomic coherence and high relative stability in a tweezer clock. Nature 588 , 408–413 (2020). Article   ADS   CAS   PubMed    Google Scholar
Schymik, K.-N. et al. Enhanced atom-by-atom assembly of arbitrary tweezers arrays. Phys. Rev. A 102 , 063107 (2020). Article   ADS   CAS    Google Scholar
Kumar, A., Wu, T.-Y., Giraldo, F. & Weiss, D. S. Sorting ultracold atoms in a three-dimensional optical lattice in a realization of Maxwell’s demon. Nature 561 , 83–87 (2018). Article   ADS   CAS   PubMed    Google Scholar
Ohl de Mello, D. et al. Defect-free assembly of 2D clusters of more than 100 single-atom quantum systems. Phys. Rev. Lett . 122 , 203601 (2019). Article   ADS   CAS   PubMed    Google Scholar
Barredo, D., Lienhard, V., de Léséleuc, S., Lahaye, T. & Browaeys, A. Synthetic three-dimensional atomic structures assembled atom by atom. Nature 561 , 79–82 (2018). Article   ADS   CAS   PubMed    Google Scholar
Barredo, D., de Léséleuc, S., Lienhard, V., Lahaye, T. & Browaeys, A. An atom-by-atom assembler of defect-free arbitrary 2D atomic arrays. Science 354 , 1021–1023 (2016). Article   ADS   CAS   PubMed    Google Scholar
Jaksch, D. et al. Fast quantum gates for neutral atoms. Phys. Rev. Lett . 85 , 2208 (2000). Article   ADS   CAS   PubMed    Google Scholar
Lukin, M. D. et al. Dipole blockade and quantum information processing in mesoscopic atomic ensembles. Phys. Rev. Lett . 87 , 037901 (2001). Article   ADS   CAS   PubMed    Google Scholar
Gardas, B., Dziarmaga, J., Zurek, W. H. & Zwolak, M. Defects in quantum computers. Sci. Rep . 8 , 4539 (2018). Article   ADS   PubMed   PubMed Central   CAS    Google Scholar
Zurek, W. H., Dorner, U. & Zoller, P. Dynamics of a quantum phase transition. Phys. Rev. Lett . 95 , 105701 (2005). Article   ADS   PubMed   CAS    Google Scholar
Felser, T., Notarnicola, S. & Montangero, S. Efficient tensor network ansatz for high-dimensional quantum many-body problems. Phys. Rev. Lett . 126 , 170603 (2021). Article   ADS   MathSciNet   CAS   PubMed    Google Scholar
Huang, H.-Y., Kueng, R. & Preskill, J. Predicting many properties of a quantum system from very few measurements. Nat. Phys . 16 , 1050–1057 (2020). Article   CAS    Google Scholar
Verresen, R., Lukin, M. D. & Vishwanath, A. Prediction of toric code topological order from Rydberg blockade. Preprint at https://arxiv.org/abs/2011.12310 (2020).
Samajdar, R., Ho, W. W., Pichler, H., Lukin, M. D. & Sachdev, S. Quantum phases of Rydberg atoms on a kagome lattice. Proc. Natl Acad. Sci. USA 118 , e2015785118 (2021). Article   CAS   PubMed   PubMed Central    Google Scholar
Semeghini, G. et al. Probing topological spin liquids on a programmable quantum simulator. Preprint at https://arxiv.org/abs/2104.04119 (2021).
Saskin, S., Wilson, J. T., Grinkemeyer, B. & Thompson, J. D. Narrow-line cooling and imaging of ytterbium atoms in an optical tweezer array. Phys. Rev. Lett . 122 , 143002 (2019). Article   ADS   CAS   PubMed    Google Scholar
Anderegg, L. et al. An optical tweezer array of ultracold molecules. Science 365 , 1156–1158 (2019). Article   ADS   CAS   PubMed    Google Scholar
Liu, L. R. et al. Building one molecule from a reservoir of two atoms. Science 360 , 900–903 (2018). Article   ADS   CAS   PubMed    Google Scholar
Turner, C. J., Michailidis, A. A., Abanin, D. A., Serbyn, M. & Papić, Z. Weak ergodicity breaking from quantum many-body scars. Nat. Phys . 14 , 745–749 (2018). Article   CAS    Google Scholar
Surace, F. M. et al. Lattice gauge theories and string dynamics in Rydberg atom quantum simulators. Phys. Rev. X 10 , 021041 (2020). CAS    Google Scholar
Bluvstein, D. et al. Controlling quantum many-body dynamics in driven Rydberg atom arrays. Science 371 , 1355–1359 (2021). Article   ADS   CAS   PubMed   MathSciNet    Google Scholar
Diehl, H. W. The theory of boundary critical phenomena. Int. J. Mod. Phys. B 11 , 3503–3523 (1997). Article   ADS    Google Scholar
Bañuls, M. C. et al. Simulating lattice gauge theories within quantum technologies. Eur. Phys. J. D 74 , 165 (2020). Article   ADS   CAS    Google Scholar
Notarnicola, S., Collura, M. & Montangero, S. Real-time-dynamics quantum simulation of (1 + 1)-dimensional lattice QED with Rydberg atoms. Phys. Rev. Research 2 , 013288 (2020). Article   ADS   CAS    Google Scholar
Weimer, H., Müller, M., Lesanovsky, I., Zoller, P. & Büchler, H. P. A Rydberg quantum simulator. Nat. Phys . 6 , 382–388 (2010). Article   CAS    Google Scholar
Auger, J. M., Bergamini, S. & Browne, D. E. Blueprint for fault-tolerant quantum computation with Rydberg atoms. Phys. Rev. A 96 , 052320 (2017). Article    Google Scholar
Farhi, E., Goldstone, J. & Gutmann, S. A quantum approximate optimization algorithm. Preprint at https://arxiv.org/abs/1411.4028 (2014).
Zhou, L., Wang, S.-T., Choi, S., Pichler, H. & Lukin, M. D. Quantum approximate optimization algorithm: performance, mechanism, and implementation on near-term devices. Phys. Rev. X 10 , 021067 (2020). CAS    Google Scholar
Wild, D. S., Sels, D., Pichler, H. & Lukin, M. D. Quantum sampling algorithms for near-term devices. Preprint at https://arxiv.org/abs/2005.14059 (2020).
Scholl, P. et al. Programmable quantum simulation of 2D antiferromagnets with hundreds of Rydberg atoms. Nature https://doi.org/10.1038/s41586-021-03585-1 (2021).
Kim, D. et al. Large-scale uniform optical focus array generation with a phase spatial light modulator. Opt. Lett . 44 , 3178–3181 (2019). Article   ADS   PubMed    Google Scholar
Endres, M. et al. Atom-by-atom assembly of defect-free one-dimensional cold atom arrays. Science 354 , 1024–1027 (2016). Article   ADS   CAS   PubMed    Google Scholar
Lee, W., Kim, H. & Ahn, J. Defect-free atomic array formation using the Hungarian matching algorithm. Phys. Rev. A 95 , 053424 (2017). Article   ADS    Google Scholar
Sheng, C. et al. Efficient preparation of 2D defect-free atom arrays with near-fewest sorting-atom moves. Phys. Rev. Research 3 , 023008 (2021). Article   ADS   CAS    Google Scholar
Levine, H. et al. High-fidelity control and entanglement of Rydberg-atom qubits. Phys. Rev. Lett . 121 , 123603 (2018). Article   ADS   CAS   PubMed    Google Scholar
Bowman, D. et al. High-fidelity phase and amplitude control of phase-only computer generated holograms using conjugate gradient minimisation. Opt. Express 25 , 11692–11700 (2017). Article   ADS   CAS   PubMed    Google Scholar
Zupancic, P. et al. Ultra-precise holographic beam shaping for microscopic quantum control. Opt. Express 24 , 13881–13893 (2016). Article   ADS   CAS   PubMed    Google Scholar
Beterov, I. I., Ryabtsev, I. I., Tretyakov, D. B. & Entin, V. M. Quasiclassical calculations of blackbody-radiation-induced depopulation rates and effective lifetimes of Rydberg nS, nP , and nD alkali-metal atoms with n  ≤ 80. Phys. Rev. A 79 , 052504 (2009). Article   ADS   CAS    Google Scholar
Bhattacharjee, S. M. & Seno, F. A measure of data collapse for scaling. J. Phys. Math. Gen . 34 , 6375 (2001). Article   ADS   CAS   MATH    Google Scholar
Hasenbusch, M. Monte Carlo study of surface critical phenomena: The special point. Phys. Rev. B 84 , 134405 (2011). Article   ADS   CAS    Google Scholar
White, S. R. Density matrix formulation for quantum renormalization groups. Phys. Rev. Lett . 69 , 2863 (1992). Article   ADS   CAS   PubMed    Google Scholar
White, S. R. Density-matrix algorithms for quantum renormalization groups. Phys. Rev. B 48 , 10345 (1993). Article   ADS   CAS    Google Scholar
Stoudenmire, E. M. & White, S. R. Studying two-dimensional systems with the density matrix renormalization group. Annu. Rev. Condens. Matter Phys . 3 , 111–128 (2012). Article    Google Scholar
Fishman, M., White, S. R. & Stoudenmire, E. M. The ITensor software library for tensor network calculations. Preprint at https://arxiv.org/abs/2007.14822 (2020).
Nature
( Nature )
ISSN 1476-4687 (online)
ISSN 0028-0836 (print)
nature.com footer links
About Nature Portfolio
About us
Press releases
Press office
Contact us
Discover content
Journals A-Z
Articles by subject
protocols.io
Nature Index
Publishing policies
Nature portfolio policies
Open access
Author & Researcher services
Reprints & permissions
Research data
Language editing
Scientific editing
Nature Masterclasses
Research Solutions
Libraries & institutions
Librarian service & tools
Librarian portal
Open research
Recommend to library
Advertising & partnerships
Advertising
Partnerships & Services
Media kits
Branded content
Professional development
Nature Awards
Nature Careers
Nature  Conferences
Regional websites
Nature Africa
Nature China
Nature India
Nature Japan
Nature Middle East
Privacy Policy
Use of cookies
Your privacy choices/Manage cookies
Legal notice
Accessibility statement
Terms & Conditions
Your US state privacy rights
© 2026 Springer Nature Limited
Close banner
Close
Sign up for the Nature Briefing newsletter — what matters in science, free to your inbox daily.
Email address
Sign up
I agree my information will be processed in accordance with the Nature and Springer Nature Limited Privacy Policy .
Close banner
Close
Get the most important science stories of the day, free in your inbox.  Sign up for Nature Briefing
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [22]: Y. Kim et al. — Evidence for the utility of quantum computing before fault tolerance (Nature 618, 500-505, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Evidence for the utility of quantum computing before fault tolerance
URL: https://doi.org/10.1038/s41586-023-06096-3
Evidence for the utility of quantum computing before fault tolerance | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes. By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection. See our privacy policy for more information on the use of your personal data. Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
articles
article
Evidence for the utility of quantum computing before fault tolerance
Download PDF
Download PDF
Article
Open access
Published: 14 June 2023
Evidence for the utility of quantum computing before fault tolerance
Youngseok Kim   ORCID: orcid.org/0000-0002-8486-9162 1   na1 ,  Andrew Eddins   ORCID: orcid.org/0000-0001-5088-4711 2   na1 ,  Sajant Anand   ORCID: orcid.org/0000-0001-6372-0513 3 ,  Ken Xuan Wei 1 ,  Ewout van den Berg   ORCID: orcid.org/0000-0002-0991-3397 1 ,  Sami Rosenblatt 1 ,  Hasan Nayfeh 1 ,  Yantao Wu 3 , 4 ,  Michael Zaletel 3 , 5 ,  Kristan Temme   ORCID: orcid.org/0000-0002-4195-0569 1 &  … Abhinav Kandala   ORCID: orcid.org/0000-0002-2566-1388 1   Show authors
Nature
volume  618 ,  pages 500–505 ( 2023 ) Cite this article
217k Accesses
1048 Citations
1288 Altmetric
Metrics details
Abstract Quantum computing promises to offer substantial speed-ups over its classical counterpart for certain problems. However, the greatest impediment to realizing its full potential is noise that is inherent to these systems. The widely accepted solution to this challenge is the implementation of fault-tolerant quantum circuits, which is out of reach for current processors. Here we report experiments on a noisy 127-qubit processor and demonstrate the measurement of accurate expectation values for circuit volumes at a scale beyond brute-force classical computation. We argue that this represents evidence for the utility of quantum computing in a pre-fault-tolerant era. These experimental results are enabled by advances in the coherence and calibration of a superconducting processor at this scale and the ability to characterize 1 and controllably manipulate noise across such a large device. We establish the accuracy of the measured expectation values by comparing them with the output of exactly verifiable circuits. In the regime of strong entanglement, the quantum computer provides correct results for which leading classical approximations such as pure-state-based 1D (matrix product states, MPS) and 2D (isometric tensor network states, isoTNS) tensor network methods 2 , 3 break down. These experiments demonstrate a foundational tool for the realization of near-term quantum applications 4 , 5 .
Similar content being viewed by others
Scalable error mitigation for noisy quantum circuits produces competitive expectation values
Article
06 February 2023
Measurement-induced entanglement and teleportation on a noisy quantum processor
Article  Open access  18 October 2023
Unconditional advantage of noisy qudit quantum circuits over biased threshold circuits in constant depth
Article  Open access  15 April 2025
Main It is almost universally accepted that advanced quantum algorithms such as factoring 6 or phase estimation 7 will require quantum error correction. However, it is acutely debated whether processors available at present can be made sufficiently reliable to run other, shorter-depth quantum circuits at a scale that could provide an advantage for practical problems. At this point, the conventional expectation is that the implementation of even simple quantum circuits with the potential to exceed classical capabilities will have to wait until more advanced, fault-tolerant processors arrive. Despite the tremendous progress of quantum hardware in recent years, simple fidelity bounds 8 support this bleak forecast; one estimates that a quantum circuit 100 qubits wide by 100 gate-layers deep executed with 0.1% gate error yields a state fidelity less than 5 × 10 −4 . Nonetheless, the question remains whether properties of the ideal state can be accessed even with such low fidelities. The error-mitigation 9 , 10 approach to near-term quantum advantage on noisy devices exactly addresses this question, that is, that one can produce accurate expectation values from several different runs of the noisy quantum circuit using classical post-processing. Quantum advantage can be approached in two steps: first, by demonstrating the ability of existing devices to perform accurate computations at a scale that lies beyond brute-force classical simulation, and second by finding problems with associated quantum circuits that derive an advantage from these devices. Here we focus on taking the first step and do not aim to implement quantum circuits for problems with proven speed-ups. We use a superconducting quantum processor with 127 qubits to run quantum circuits with up to 60 layers of two-qubit gates, a total of 2,880 CNOT gates. General quantum circuits of this size lie beyond what is feasible with brute-force classical methods. We thus first focus on specific test cases of the circuits permitting exact classical verification of the measured expectation values. We then turn to circuit regimes and observables in which classical simulation becomes challenging and compare with results from state-of-the-art approximate classical methods. Our benchmark circuit is the Trotterized time evolution of a 2D transverse-field Ising model, sharing the topology of the qubit processor (Fig. 1a ). The Ising model appears extensively across several areas in physics and has found creative extensions in recent simulations exploring quantum many-body phenomena, such as time crystals 11 , 12 , quantum scars 13 and Majorana edge modes 14 . As a test of utility of quantum computation, however, the time evolution of the 2D transverse-field Ising model is most relevant in the limit of large entanglement growth in which scalable classical approximations struggle. Fig. 1: Noise characterization and scaling for 127-qubit Trotterized time-evolution circuits. The alternative text for this image may have been generated using AI. Full size image
a , Each Trotter step of the Ising simulation includes single-qubit X and two-qubit Z Z rotations. Random Pauli gates are inserted to twirl (spirals) and controllably scale the noise of each CNOT layer. The dagger indicates conjugation by the ideal layer. b , Three depth-1 layers of CNOT gates suffice to realize interactions between all neighbour pairs on ibm_kyiv. c , Characterization experiments efficiently learn the local Pauli error rates λ l , i (colour scales) comprising the overall Pauli channel Λ l associated with the l th twirled CNOT layer. (Figure expanded in Supplementary Information  IV.A ). d , Pauli errors inserted at proportional rates can be used to either cancel (PEC) or amplify (ZNE) the intrinsic noise.
In particular, we consider time dynamics of the Hamiltonian, $$H=-\,J\sum _{\langle i,j\rangle }{Z}_{i}{Z}_{j}+h\sum _{i}{X}_{i},$$
(1)
in which J  > 0 is the coupling of nearest-neighbour spins with i  <  j and h is the global transverse field. Spin dynamics from an initial state can be simulated by means of first-order Trotter decomposition of the time-evolution operator, $$\begin{array}{ll}{{\rm{e}}}^{-{\rm{i}}{H}_{ZZ}\delta t}\,= & {\prod }_{\langle i,j\rangle }{{\rm{e}}}^{{\rm{i}}J\delta t{Z}_{i}{Z}_{j}}={\prod }_{\langle i,j\rangle }{{\rm{R}}}_{{Z}_{i}{Z}_{j}}(-2J\delta t)\\ {{\rm{e}}}^{-{\rm{i}}{H}_{X}\delta t}\,= & {\prod }_{i}{{\rm{e}}}^{-{\rm{i}}h\delta t{X}_{i}}={\prod }_{i}{{\rm{R}}}_{{X}_{i}}(2h\delta t),\\ \end{array}$$
(2)
in which the evolution time T is discretized into T / δ t Trotter steps and \({{\rm{R}}}_{{Z}_{i}{Z}_{j}}({\theta }_{J})\) and \({{\rm{R}}}_{{X}_{i}}({\theta }_{{\rm{h}}})\) are Z Z and X rotation gates, respectively. We are not concerned with the model error owing to Trotterization and thus take the Trotterized circuit as ideal for any classical comparison. For experimental simplicity, we focus on the case θ J  = −2 J δ t  = −π/2 such that the Z Z rotation requires only one CNOT,
where the equality holds up to a global phase. In the resulting circuit (Fig. 1a ), each Trotter step amounts to a layer of single-qubit rotations, R X ( θ h ), followed by commuting layers of parallelized two-qubit rotations, R ZZ ( θ J ). For the experimental implementation, we primarily used the IBM Eagle processor ibm_kyiv, composed of 127 fixed-frequency transmon qubits 15 with heavy-hex connectivity and median T 1 and T 2 times of 288 μs and 127 μs, respectively. These coherence times are unprecedented for superconducting processors of this scale and allow the circuit depths accessed in this work. The two-qubit CNOT gates between neighbours are realized by calibrating the cross-resonance interaction 16 . As each qubit has at most three neighbours, all Z Z interactions can be performed in three layers of parallelized CNOT gates (Fig. 1b ). The CNOT gates within each layer are calibrated for optimal simultaneous operation (see Methods for more details). We now see that these hardware performance improvements enable even larger problems to be successfully executed with error mitigation, in comparison with recent work 1 , 17 on this platform. Probabilistic error cancellation (PEC) 9 has been shown 1 to be very effective at providing unbiased estimates of observables. In PEC, a representative noise model is learned and effectively inverted by sampling from a distribution of noisy circuits related to the learned model. Yet, for the current error rates on our device, the sampling overhead for the circuit volumes considered in this work remains restrictive, as discussed further below. We therefore turn to zero-noise extrapolation (ZNE) 9 , 10 , 17 , 18 , which provides a biased estimator at a potentially much lower sampling cost. ZNE is either a polynomial 9 , 10 or exponential 19 extrapolation method for noisy expectation values as a function of a noise parameter. This requires the controlled amplification of the intrinsic hardware noise by a known gain factor G to extrapolate to the ideal G  = 0 result. ZNE has been widely adopted in part because noise-amplification schemes based on pulse stretching 9 , 17 , 18 or subcircuit repetition 20 , 21 , 22 have circumvented the need for precise noise learning, while relying on simplistic assumptions about the device noise. More precise noise amplification can, however, enable substantial reductions in the bias of the extrapolated estimator, as we demonstrate here. The sparse Pauli–Lindblad noise model proposed in ref.  1 turns out to be especially well suited for noise shaping in ZNE. The model takes the form \({{\rm{e}}}^{{\mathcal{L}}}\) , in which \({\mathcal{L}}\) is a Lindbladian comprising Pauli jump operators P i weighted by rates λ i . It was shown in ref.  1 that restricting to jump operators acting on local pairs of qubits yields a sparse noise model that can be efficiently learned for many qubits and that accurately captures the noise associated with layers of two-qubit Clifford gates, including crosstalk, when combined with random Pauli twirls 23 , 24 . The noisy layer of gates is modelled as a set of ideal gates preceded by some noise channel Λ. Thus, applying Λ α before the noisy layer produces an overall noise channel Λ G with gain G  =  α  + 1. Given the exponential form of the Pauli–Lindblad noise model, the map \({{\rm{e}}}^{\alpha {\mathcal{L}}}\) is obtained by simply multiplying the Pauli rates λ i by α . The resulting Pauli map can be sampled to obtain appropriate circuit instances; for α  ≥ 0, the map is a Pauli channel that can be sampled directly, whereas for α  < 0, quasi-probabilistic sampling is needed with sampling overhead γ −2 α for some model-specific γ . In PEC, we choose α  = −1 to obtain an overall zero-gain noise level. In ZNE, we instead amplify the noise 10 , 25 , 26 , 27 to different gain levels and estimate the zero-noise limit using extrapolation. For practical applications, we need to consider the stability of the learned noise model over time (Supplementary Information  III.A ), for instance, owing to qubit interactions with fluctuating microscopic defects known as two-level systems 28 . Clifford circuits serve as useful benchmarks of estimates produced by error mitigation, as they can be efficiently simulated classically 29 . Notably, the entire Ising Trotter circuit becomes Clifford when θ h is chosen to be a multiple of π/2. As a first example, we therefore set the transverse field to zero (R X (0) =  I ) and evolve the initial state |0 ⟩ ⊗ 127 (Fig. 1a ). The CNOT gates nominally leave this state unchanged, so the ideal weight-1 observables Z q all have expectation value 1; owing to the Pauli twirling of each layer, the bare CNOTs do affect the state. For each Trotter experiment, we first characterized the noise models Λ l for the three Pauli-twirled CNOT layers (Fig. 1c ) and then used these models to implement Trotter circuits with noise gain levels G   ∈  {1, 1.2, 1.6}. Figure 2a illustrates the estimation of ⟨ Z 106 ⟩ after four Trotter steps (12 CNOT layers). For each G , we generated 2,000 circuit instances in which, before each layer l , we have inserted products of one-qubit and two-qubit Pauli errors i from \({\mathcal{L}}\) drawn with probabilities \({p}_{l,i}=(1-{{\rm{e}}}^{-2(G-1){\lambda }_{l,i}})/2\) and executed each instance 64 times, totalling 384,000 executions. As more circuit instances are accumulated, the estimates of ⟨ Z 106 ⟩ G , corresponding to the different gains G , converge to distinct values. The different estimates are then fit by an extrapolating function in G to estimate the ideal value ⟨ Z 106 ⟩ 0 . The results in Fig. 2a highlight the reduced bias from exponential extrapolation 19 in comparison with linear extrapolation. That said, exponential extrapolation can exhibit instabilities, for instance, when expectation values are unresolvably close to zero, and—in such cases—we iteratively downgrade the extrapolation model complexity (see Supplementary Information  II.B ). The procedure outlined in Fig. 2a was applied to the measurement results from each qubit q to estimate all N  = 127 Pauli expectations ⟨ Z q ⟩ 0 . The variation in the unmitigated and mitigated observables in Fig. 2b is indicative of the non-uniformity in the error rates across the entire processor. We report the global magnetization along \(\hat{z}\) , \({M}_{z}={\sum }_{q}\,\langle {Z}_{q}\rangle /N\) , for increasing depth in Fig. 2c . Although the unmitigated result shows a gradual decay from 1 with an increasing deviation for deeper circuits, ZNE greatly improves agreement, albeit with a small bias, with the ideal value even out to 20 Trotter steps, or 60 CNOT depth. Notably, the number of samples used here is much smaller than an estimate of the sampling overhead that would be needed in a naive PEC implementation (see Supplementary Information  IV.B ). In principle, this disparity may be greatly reduced by more advanced PEC implementations using light-cone tracing 30 or by improvements in hardware error rates. As future hardware and software developments bring down sampling costs, PEC may be preferred when affordable to avoid the potentially biased nature of ZNE. Fig. 2: Zero-noise extrapolation with probabilistic error amplification. The alternative text for this image may have been generated using AI. Full size image
Mitigated expectation values from Trotter circuits at the Clifford condition θ h  = 0. a , Convergence of unmitigated ( G  = 1), noise-amplified ( G  > 1) and noise-mitigated (ZNE) estimates of ⟨ Z 106 ⟩ after four Trotter steps. In all panels, error bars indicate 68% confidence intervals obtained by means of percentile bootstrap. Exponential extrapolation (exp, dark blue) tends to outperform linear extrapolation (linear, light blue) when differences between the converged estimates of ⟨ Z 106 ⟩ G ≠0 are well resolved. b , Magnetization (large markers) is computed as the mean of the individual estimates of ⟨ Z q ⟩ for all qubits (small markers). c , As circuit depth is increased, unmitigated estimates of M z decay monotonically from the ideal value of 1. ZNE greatly improves the estimates even after 20 Trotter steps (see Supplementary Information  II for ZNE details).
Next, we test the efficacy of our methods for non-Clifford circuits and the Clifford θ h  = π/2 point, with non-trivial entangling dynamics compared with the identity-equivalent circuits discussed in Fig. 2 . The non-Clifford circuits are of particular importance to test, as the validity of exponential extrapolation is no longer guaranteed (see Supplementary Information  V  and ref.  31 ). We restrict the circuit depth to five Trotter steps (15 CNOT layers) and judiciously choose observables that are exactly verifiable. Figure 3 shows the results as θ h is swept between 0 and π/2 for three such observables of increasing weight. Figure 3a shows M z as before, an average of weight-1 ⟨ Z ⟩ observables, whereas Fig. 3b,c show weight-10 and weight-17 observables. The latter operators are stabilizers of the Clifford circuit at θ h  = π/2, obtained by evolution of the initial stabilizers Z 13 and Z 58 , respectively, of |0 ⟩ ⊗ 127 for five Trotter steps, ensuring non-vanishing expectation values in the strongly entangling regime of particular interest. Although the entire 127-qubit circuit is executed experimentally, light-cone and depth-reduced (LCDR) circuits enable brute-force classical simulation of the magnetization and weight-10 operator at this depth (see Supplementary Information  VII ). Over the full extent of the θ h sweep, the error-mitigated observables show good agreement with the exact evolution (see Fig. 3a,b ). However, for the weight-17 operator, the light cone expands to 68 qubits, a scale beyond brute-force classical simulation, so we turn to tensor network methods. Fig. 3: Classically verifiable expectation values from 127-qubit, depth-15 Clifford and non-Clifford circuits. The alternative text for this image may have been generated using AI. Full size image
Expectation value estimates for θ h sweeps at a fixed depth of five Trotter steps for the circuit in Fig. 1a . The considered circuits are non-Clifford except at θ h  = 0, π/2. Light-cone and depth reductions of respective circuits enable exact classical simulation of the observables for all θ h . For all three plotted quantities (panel titles), mitigated experimental results (blue) closely track the exact behaviour (grey). In all panels, error bars indicate 68% confidence intervals obtained by means of percentile bootstrap. The weight-10 and weight-17 observables in b and c are stabilizers of the circuit at θ h  = π/2 with respective eigenvalues +1 and −1; all values in c have been negated for visual simplicity. The lower inset in a depicts variation of ⟨ Z q ⟩ at θ h  = 0.2 across the device before and after mitigation and compares with exact results. Upper insets in all panels illustrate causal light cones, indicating in blue the final qubits measured (top) and the nominal set of initial qubits that can influence the state of the final qubits (bottom). M z also depends on 126 other cones besides the example shown. Although in all panels exact results are obtained from simulations of only causal qubits, we include tensor network simulations of all 127 qubits (MPS, isoTNS) to help gauge the domain of validity for those techniques, as discussed in the main text. isoTNS results for the weight-17 operator in c are not accessible with current methods (see Supplementary Information  VI ). All experiments were carried out for G  = 1, 1.2, 1.6 and extrapolated as in Supplementary Information  II.B . For each G , we generated 1,800–2,000 random circuit instances for a and b and 2,500–3,000 instances for c .
Tensor networks have been widely used to approximate and compress quantum state vectors that arise in the study of the low-energy eigenstates of and time evolution by local Hamiltonians 2 , 32 , 33 and, more recently, have been successfully used to simulate low-depth noisy quantum circuits 34 , 35 , 36 . Simulation accuracy can be improved by increasing the bond dimension χ , which constrains the amount of entanglement of the represented quantum state, at a computational cost scaling polynomially with χ . As entanglement (bond dimension) of a generic state grows linearly (exponentially) with time evolution until it saturates the volume law, deep quantum circuits are inherently difficult for tensor networks 37 . We consider both quasi-1D matrix product states (MPS) and 2D isometric tensor network states (isoTNS) 3 that have \({\mathcal{O}}({\chi }^{3})\) and \({\mathcal{O}}({\chi }^{7})\) scaling of time-evolution complexity, respectively. Details of both methods and their strengths are provided in Methods and Supplementary Information  VI . Specifically for the case of the weight-17 operator shown in Fig. 3c , we find that an MPS simulation of the LCDR circuit at χ  = 2,048 is sufficient to obtain the exact evolution (see Supplementary Information  VIII ). The larger causal cone of the weight-17 observable results in an experimental signal that is weaker compared with that of the weight-10 observable; nevertheless, mitigation still yields good agreement with the exact trace. This comparison suggests that the domain of experimental accuracy could extend beyond the scale of exact classical simulation. We expect that these experiments will eventually extend to circuit volumes and observables in which such light-cone and depth reductions are no longer important. Therefore, we also study the performance of MPS and isoTNS for the full 127-qubit circuit executed in Fig. 3 , at respective bond dimensions of χ  = 1,024 and χ  = 12, which are primarily limited by memory requirements. Figure 3 shows that the tensor network methods struggle with increasing θ h , losing both accuracy and continuity near the verifiable Clifford point θ h  = π/2. This breakdown can be understood in terms of entanglement properties of the state. The stabilizer state produced by the circuit at θ h  = π/2 has an exactly flat bipartite entanglement spectrum, found from a Schmidt decomposition of a 1D ordering of the qubits. Thus, truncating states with small Schmidt weight—the basis of all tensor network algorithms—is not justified. However, as exact tensor network representations generically require bond dimension exponential in circuit depth, truncation is necessary for tractable numerical simulations. Finally, in Fig. 4 , we stretch our experiments to regimes in which the exact solution is not available with the classical methods considered here. The first example (Fig. 4a ) is similar to Fig. 3c but with a further final layer of single-qubit Pauli rotations that interrupt the circuit-depth reduction that previously enabled exact verification for any θ h (see Supplementary Information  VII ). At the verifiable Clifford point θ h  = π/2, the mitigated results agree again with the ideal value, whereas the χ  = 3,072 MPS simulation of the 68-qubit LCDR circuit markedly fails in the strongly entangling regime of interest. Although χ  = 2,048 was sufficient for exact simulation of the weight-17 operator in Fig. 3c , an MPS bond dimension of 32,768 would be needed for exact simulation of this modified circuit and operator with θ h  = π/2. Fig. 4: Estimating expectation values beyond exact verification. The alternative text for this image may have been generated using AI. Full size image
Plot markers, confidence intervals and causal light cones appear as defined in Fig. 3 . a , Estimates of a weight-17 observable (panel title) after five Trotter steps for several values of θ h . The circuit is similar to that in Fig. 3c but with further single-qubit rotations at the end. This effectively simulates the time evolution of the spins after Trotter step six by using the same number of two-qubit gates used for Trotter step five. As in Fig. 3c , the observable is a stabilizer at θ h  = π/2 with eigenvalue −1, so we negate the y axis for visual simplicity. Optimization of the MPS simulation by including only qubits and gates in the causal light cone enables a higher bond dimension ( χ  = 3,072), but the simulation still fails to approach −1 (+1 in negated y axis) at θ h  = π/2. b , Estimates of the single-site magnetization 〈 Z 62 〉 after 20 Trotter steps for several values of θ h . The MPS simulation is light-cone-optimized and performed with bond dimension χ  = 1,024, whereas the isoTNS simulation ( χ  = 12) includes the gates outside the light cone. The experiments were carried out with G  = 1, 1.3, 1.6 for a and G  = 1, 1.2, 1.6 for b , and extrapolated as in Supplementary Information  II.B . For each G , we generated 2,000–3,200 random circuit instances for a and 1,700–2,400 instances for b .
As a final example, we extend the circuit depth to 20 Trotter steps (60 CNOT layers) and estimate the θ h dependence of a weight-1 observable, ⟨ Z 62 ⟩ , in Fig. 4b , in which the causal cone extends over the entire device. Given the non-uniformity of device performance, also seen in the spread of single-site observables in Fig. 2b , we choose an observable that obtains the expected result ⟨ Z 62 ⟩  ≈ 1 at the verifiable θ h  = 0 point. Despite the greater depth, the MPS simulations of the LCDR circuit agree well with the experiment in the weakly entangling regime of small θ h . Although deviations from the experimental trace emerge with increasing θ h , we note that the MPS simulations slowly move in the direction of the experimental data with increasing χ (see Supplementary Information X ) and that the bond dimension needed to exactly represent the stabilizer state and its evolution to depth 20 at θ h  = π/2 is 7.2 × 10 16 , 13 orders of magnitude larger than what we considered (see Supplementary Information VIII ). For reference, as the memory required to store an MPS scales as \({\mathcal{O}}({\chi }^{2})\) , already a bond dimension of χ  = 1 × 10 8 would require 400 PB, independent of any runtime considerations. Furthermore, full-state tensor network simulations are already unable to capture the dynamics at the exactly verifiable five-step circuit in Fig. 3a . We also note that, given the large unmitigated signal, there may be opportunity to study time evolution at even larger depths on the current device. For execution times, the tensor network simulations in Fig. 4 were run on a 64-core, 2.45-GHz processor with 128 GB of memory, in which the run time to access an individual data point at fixed θ h was 8 h for Fig. 4a and 30 h for Fig. 4b . The corresponding quantum wall-clock run time was approximately 4 h for Fig. 4a and 9.5 h for Fig. 4b , but this is also far from a fundamental limit, being at present dominated by classical processing delays that stand to be largely eliminated through conceptually straightforward optimizations. Indeed, the estimated device run time for the error-mitigated expectation values using 614,400 samples (2,400 circuit instances for each gain factor and readout error mitigation, with 64 shots per instance) at a conservative sampling rate of 2 kHz is only 5 min 7 s, which can be even further reduced by optimization of qubit reset speeds. On the other hand, the classical simulations may also be improved by methods besides the pure-state tensor networks considered here, such as Heisenberg operator evolution methods, which have recently been applied to non-Clifford simulations 38 . Another approach is to numerically emulate the ZNE used experimentally. For example, it was recently argued that the finite- χ truncation error introduced by tensor-product compression mimics experimental gate errors 34 . It would thus be natural to develop a theory for extrapolating tensor network state expectation values in the bond dimension χ for time evolution, as has been done in the case of ground-state search 39 . Alternatively, one can more directly emulate ZNE by introducing artificial dissipation into the dynamics engineered so that the resulting mixed-state evolution has reduced tensor-product bond dimension, as—for example—in dissipation-assisted operator evolution 40 , and extrapolate results with respect to the strength of the dissipation. Although such methods 40 , 41 can successfully capture the long-time dynamics of the low-weight observables of a 1D spin chain, their applicability to high-weight observables in 2D at intermediate times is not clear—particularly as these methods are explicitly constructed to truncate complex operators. The observation that a noisy quantum processor, even before the advent of fault-tolerant quantum computing, produces reliable expectation values at a scale beyond 100 qubits and non-trivial circuit depth leads to the conclusion that there is indeed merit to pursuing research towards deriving a practical computational advantage from noise-limited quantum circuits. Over recent years, substantial research effort has been directed to develop and demonstrate candidate heuristic quantum algorithms 5 that use noise-limited quantum circuits to estimate expectation values. We have now reached reliability at a scale for which one will be able to verify proposals and explore new approaches to determine which can provide utility beyond classical approximation methods. At the same time, these results will motivate and help advance classical approximation methods as both approaches serve as valuable benchmarks of one another. However, even with improved classical methods, impending order-of-magnitude improvements in gate fidelities 42 and speed of superconducting quantum systems will drive substantial enhancements in accessible circuit volumes and paint an increasingly bright picture of the utility of noisy quantum computers.
Methods Device calibration The speed of cross-resonance-based CNOT gates is dependent on the qubit–qubit detuning and, typically, gate speeds across the device are chosen independently to minimize individual gate errors 43 . This leads to a large spread in CNOT times across the device. Noting that the speed of each parallelized CNOT layer is limited by the slowest gate in the layer, we develop a new tune-up scheme for large-scale processor calibration that optimizes the layer rather than the individual gates. First, the control and target qubits are assigned to each gate layer to reduce crosstalk and leakage from transmon-frequency collisions. The slowest gate in each layer then has its duration carefully optimized. Finally, all gates in the layer are fixed to this duration and calibrated simultaneously with error-amplification sequences 44 . Compared with independently calibrated gates, the layer duration is unchanged, but gates are slower with lower drive amplitudes, reducing any leakage arising from multi-photon transitions. The simultaneous calibration also ensures that the gates are calibrated as they are implemented in the circuit. Noise model Throughout this work, we amplify gate noise by means of a learned noise model. For this model, following ref.  1 , a general Pauli channel is approximated by \(\Lambda (\rho )=\exp [{\mathcal{L}}](\rho )\) with a sparse Pauli–Lindblad generator $${\mathcal{L}}(\rho )=\sum _{i}{\lambda }_{i}({P}_{i}\,\rho {P}_{i}^{\dagger }-\rho ).$$
Here the jump operators are chosen to be Pauli operators P i with \({P}_{i}^{\dagger }{P}_{i}=I\) and the model is parameterized by the non-negative coefficients λ i . This model can be rewritten as $$\Lambda (\rho )=\mathop{\bigcirc}\limits_{i}\left({w}_{i}\cdot +(1-{w}_{i}){P}_{i}\cdot {P}_{i}^{\dagger }\right)(\rho ),$$
in which \({w}_{i}=(1+{{\rm{e}}}^{-2{\lambda }_{i}})/2\) and \({\bigcirc}_{i=1}^{n}{O}_{i}(\,\cdot \,)=({O}_{n}\,\circ \,{O}_{n-1}\,\circ \cdots \circ \,{O}_{1})\) represents the composition of operators and O ( ⋅ )( ρ ) =  O ( ρ ). In other words, we can express Λ( ρ ) as a composition of simple Pauli maps. For physical noise channels, in which all λ i  ≥ 0, the composition consists of simply Pauli channels. By allowing non-zero coefficients λ i only for Pauli terms P i whose support corresponds to a single qubit or a pair of connected qubits, we obtain a sparse noise model that can be efficiently learned and that, despite its simplicity, is able to capture crosstalk errors 1 . It is readily seen that \(\exp [\alpha {\mathcal{L}}]\) is obtained by scaling all λ i by α . For α  ≥ 0, the resulting noise model is a composition of Pauli channels. Samples from this channel can be obtained by independently sampling P i with probability 1 −  w i for each of the simple channels and multiplying the results. For α  < 0, the resulting coefficients 1 −  w i are generally negative, leading to a non-physical noise map. Sampling in that case can still be done, albeit in a quasi-probabilistic manner. Doing so results in a sampling overhead of γ 2 , in which \(\gamma =\exp \left({\sum }_{i}2{\lambda }_{i}\right)\) . Brute-force simulations The simplest, most accurate and most limited method is simulation of a collection of the state of M qubits as a dense vector of 2 M complex coefficients. All unitary gates, irrespective of locality, can be applied directly to the vector. Expectation values are found by vector–matrix–vector product of the conjugated state, operator and state. We use this approach for simulations up to 30 qubits. Tensor network methods For circuits of more than 30 qubits, we used 1D and 2D tensor network state methods 45 . For a quantum state on M qubits, tensor network methods approximate the 2 M complex coefficients for the wavefunction amplitude as a network of contracted tensors containing \({\mathcal{O}}\left(M{\chi }^{p}\right)\) coefficients, in which p is an integer depending on the method. Here we consider MPS 2 , 32 , 33 with p  = 2 and isoTNS 3 with p  = 4. MPS represent a quantum state as a network of rank-3 tensors that, when contracted or multiplied together, give an approximation to the wavefunction amplitude for each basis state. isoTNS are a restriction of projected entangled pair states, a 2D generalization of MPS to square lattices in which the network consists of rank-5 tensors. The accuracy and computational cost of both MPS and isoTNS depend on the bond dimension χ . MPS methods have the advantage of well-developed algorithms, yet suffer from fundamental limitations of using a 1D method to simulate a 2D system. isoTNS methods, on the other hand, are inherently 2D methods but suffer from unavoidable sources of error not present for MPS, though these can be systematically reduced with increasing bond dimension.
Data availability
The datasets generated and analysed during this study are available at https://doi.org/10.6084/m9.figshare.22500355 .
References van den Berg, E., Minev, Z.K., Kandala, A. et al. Probabilistic error cancellation with sparse Pauli–Lindblad models on noisy quantum processors. Nat. Phys. https://doi.org/10.1038/s41567-023-02042-2 (2023).
Paeckel, S. et al. Time-evolution methods for matrix-product states. Ann. Phys. 411 , 167998 (2019). Article   MathSciNet   CAS   MATH
Google Scholar
Zaletel, M. P. & Pollmann, F. Isometric tensor network states in two dimensions. Phys. Rev. Lett. 124 , 037201 (2020). Article   ADS   MathSciNet   CAS   PubMed
Google Scholar
Preskill, j Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article
Google Scholar
Bharti, K. et al. Noisy intermediate-scale quantum algorithms. Rev. Mod. Phys. 94 , 015004 (2022). Article   ADS   MathSciNet   CAS
Google Scholar
Shor, P. W. in Proc. 35th Annual Symposium on Foundations of Computer Science 124–134 (IEEE, 1994).
Kitaev, A. Y. Quantum measurements and the Abelian Stabilizer Problem. Preprint at https://arxiv.org/abs/quant-ph/9511026 (1995).
Arute, F. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). Article   ADS   CAS   PubMed
Google Scholar
Temme, K., Bravyi, S. & Gambetta, J. M. Error mitigation for short-depth quantum circuits. Phys. Rev. Lett. 119 , 180509 (2017). Article   ADS   MathSciNet   PubMed
Google Scholar
Li, Y. & Benjamin, S. C. Efficient variational quantum simulator incorporating active error minimization. Phys. Rev. X 7 , 021050 (2017).
Google Scholar
Mi, X. et al. Time-crystalline eigenstate order on a quantum processor. Nature 601 , 531–536 (2022). Article   ADS   CAS   PubMed
Google Scholar
Frey, P. & Rachel, S. Realization of a discrete time crystal on 57 qubits of a quantum computer. Sci. Adv. 8 , eabm7652 (2022). Article   PubMed   PubMed Central
Google Scholar
Chen, I.-C., Burdick, B., Yao, Y., Orth, P. P. & Iadecola, T. Error-mitigated simulation of quantum many-body scars on quantum computers with pulse-level control. Phys. Rev. Res. 4 , 043027 (2022). Article   CAS
Google Scholar
Mi, X. et al. Noise-resilient edge modes on a chain of superconducting qubits. Science 378 , 785–790 (2022). Article   ADS   CAS   PubMed
Google Scholar
Koch, J. et al. Charge-insensitive qubit design derived from the Cooper pair box. Phys. Rev. A 76 , 042319 (2007). Article   ADS
Google Scholar
Chow, J. M. et al. Simple all-microwave entangling gate for fixed-frequency superconducting qubits. Phys. Rev. Lett. 107 , 080502 (2011). Article   ADS   PubMed
Google Scholar
Kim, Y. et al. Scalable error mitigation for noisy quantum circuits produces competitive expectation values. Nat. Phys. https://doi.org/10.1038/s41567-022-01914-3 (2023).
Kandala, A. et al. Error mitigation extends the computational reach of a noisy quantum processor. Nature 567 , 491–495 (2019). Article   ADS   CAS   PubMed
Google Scholar
Endo, S., Benjamin, S. C. & Li, Y. Practical quantum error mitigation for near-future applications. Phys. Rev. X 8 , 031027 (2018). CAS
Google Scholar
Dumitrescu, E. F. et al. Cloud quantum computing of an atomic nucleus. Phys. Rev. Lett. 120 , 210501 (2018). Article   ADS   CAS   PubMed
Google Scholar
He, A., Nachman, B., de Jong, W. A. & Bauer, C. W. Zero-noise extrapolation for quantum-gate error mitigation with identity insertions. Phys. Rev. A 102 , 012426 (2020). Article   ADS   MathSciNet   CAS
Google Scholar
Giurgica-Tiron, T., Hindy, Y., Larose, R., Mari, A. & Zeng, W. J. digital zero noise extrapolation for quantum error mitigation. in 2020 IEEE International Conference on Quantum Computing and Engineering (QCE) 306–316 (IEEE, 2020).
Bennett, C. H. et al. Purification of noisy entanglement and faithful teleportation via noisy channels. Phys. Rev. Lett. 76 , 722–725 (1996). Article   ADS   CAS   PubMed
Google Scholar
Knill, E. Fault-tolerant postselected quantum computation: threshold analysis. Preprint at https://arxiv.org/abs/quant-ph/0404104 (2004).
Mari, A., Shammah, N. & Zeng, W. J. Extending quantum probabilistic error cancellation by noise scaling. Phys. Rev. A 104 , 052607 (2021). Article   ADS   MathSciNet   CAS
Google Scholar
Ferracin, S. et al. Efficiently improving the performance of noisy quantum computers. Preprint at https://arxiv.org/abs/2201.10672 (2022).
McDonough, B. et al. Automated quantum error mitigation based on probabilistic error reduction. In I EEE/ACM Third International Workshop on Quantum Computing Software (QCS) 83–93 (IEEE/ACM, 2022).
Carroll, M., Rosenblatt, S., Jurcevic, P., Iauer, I. & Kandala, A. Dynamics of superconducting qubit relaxation times. npj Quantum Inf. 9 , 132 (2022). Article   ADS
Google Scholar
Aaronson, S. & Gottesman, D. Improved simulation of stabilizer circuits. Phys. Rev. A 70 , 052328 (2004). Article   ADS
Google Scholar
Tran, M. C., Sharma, K. & Temme, K. Locality and error mitigation of quantum circuits. Preprint at https://arxiv.org/abs/2303.06496 (2023).
Cai, Z. Multi-exponential error extrapolation and combining error mitigation techniques for NISQ applications. npj Quantum Inf. 7 , 80 (2021). Article   ADS
Google Scholar
Schöllwock, U. The density-matrix renormalization group in the age of matrix product states. Ann. Phys. 326 , 96–192 (2011). Article   ADS   MathSciNet   MATH
Google Scholar
Hauschild, J. & Pollmann, F. Efficient numerical simulations with tensor networks: Tensor Network Python (TeNPy). SciPost Phys. Lect. Notes https://doi.org/10.21468/SciPostPhysLectNotes.5 (2018).
Zhou, Y., Stoudenmire, E. M. & Waintal, X. What limits the simulation of quantum computers?. Phys. Rev. X 10 , 041038 (2020). CAS
Google Scholar
Guo, C. et al. General-purpose quantum circuit simulator with projected entangled-pair states and the quantum supremacy frontier. Phys. Rev. Lett. 123 , 190501 (2019). Article   ADS   CAS   PubMed
Google Scholar
Ayral, T. et al. Density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity. PRX Quantum 4 , 020304 (2023). Article   ADS
Google Scholar
Calabrese, P. & Cardy, J. Evolution of entanglement entropy in one-dimensional systems. J. Stat. Mech. Theory Exp. 2005 , P04010 (2005). Article   MathSciNet   MATH
Google Scholar
Bravyi, S. et al. Simulation of quantum circuits by low-rank stabilizer decompositions. Quantum 3 , 181 (2019). Article
Google Scholar
Hubig, C., Haegeman, J. & Schollwöck, U. Error estimates for extrapolations with matrix-product states. Phys. Rev. B 97 , 045125 (2018). Article   ADS
Google Scholar
Rakovszky, T., von Keyserlingk, C. W. & Pollmann, F. Dissipation-assisted operator evolution method for capturing hydrodynamic transport. Phys. Rev. B 105 , 075131 (2022). Article   ADS   CAS
Google Scholar
White, C. D., Zaletel, M., Mong, R. S. K. & Refael, G. Quantum dynamics of thermalizing systems. Phys. Rev. B 97 , 035127 (2018). Article   ADS   CAS
Google Scholar
Stehlik, J. et al. Tunable coupling architecture for fixed-frequency transmon superconducting qubits. Phys. Rev. Lett. 127 , 080505 (2021). Article   ADS   CAS   PubMed
Google Scholar
Zhang, E. J. et al. High-performance superconducting quantum processors via laser annealing of transmon qubits. Sci. Adv. 8 , eabi6690 (2022). Article   CAS   PubMed   PubMed Central
Google Scholar
Wei, K. X. et al. Hamiltonian engineering with multicolor drives for fast entangling gates and quantum crosstalk cancellation. Phys. Rev. Lett. 129 , 060501 (2022). Article   ADS   CAS   PubMed
Google Scholar
Cirac, J. I., Pérez-García, D., Schuch, N. & Verstraete, F. Matrix product states and projected entangled pair states: concepts, symmetries, theorems. Rev. Mod. Phys. 93 , 045003 (2021). Article   ADS   MathSciNet   CAS
Google Scholar
Download references
Acknowledgements
This work would not have been possible without the contributions of the entire IBM Quantum team, including: K. Aarhus, B. Abdo, D. W. Abraham, E. Adams, G. Aleksandrowicz, D. Alevras, T. Alexander, A. Alexopoulos, H. Alghassi, L. Ament, M. Amico, A. Anderson, M. Aney, S. A. S. Antezana, J. Apuzzo, E. Arbel, E. Arellano, V. Arena, T. Armon, M. Arthur, P. K. Austel, U. Bacher, S. Bangsaruntip, Z. Barabás, v. barbosa, S. V. Barron, G. Bauer, J. Bauer, M. Beck, M. Beckley, S. W. Bedell, L. Bello, Y. Ben-Haim, G. Bennett, L. A. Berge, M. Bernagozzi, J. Betke, L. S. Bishop, J. Blair, A. A. Blanco, S. R. Blanks, D. F. Bogorin, R. Bonam, M. Boraas, P. Bosavage, Y. Bosch, S. Bravyi, M. Brink, B. J. Brown, J. S. Broz, J. Bruley, D. Bryant, M. Buehler, M. Byers, M. T. Byrnes, E. Bäumer, C. Cabral Jr., S. Cairns, J. Calderón, L. Carata-Dejoianu, M. Carlucci, S. Carnevale, A. Carniol, S. Carri, M. S. Carroll, A. Carter, E. C. Castañeda, R. Chadwick, M. E. V. Chan, R. Cheek, V. Chiang, R. Chiarella, M. Chido, S. Choi, R. Cholarajan, A. Choquette, J. M. Chow, T. A. Christensen, B. Christenson, C. Christianson, W. Chung, C. Chung, M. Clausen, C. Codella, H. Colquhoun Jr., R. Conti, M. Copel, A. D. Corcoles, H. Cortes, J. M. Cotte, R. Cremins, A. Cross, A. Cross, G. Crossman, J. Cruz-Benito, S. Czaplewski, P. E. Dahlen, H. P. Dang, K. Dang, J. Dangler, M. P. David, A. R. Davila, G. Dawson, A. Dekusar, B. Delaney, P. Delosreyes, S. Derakhshandeh, A. Deshmukh, M. Desnoyers, O. E. Dial, M. DiDonato, S. Dikaleh, B. Dimock, T. Dixon, R. A. Donaton, B. Donovan, M. Doyle, Z. Dreiss, J. Drummond, E. A. Duch, N. Dunfee, L. Durst, R. A. Eades, N. Earnest-Noble, D. J. Egger, N. Einsidler, B. Ek, J. Ekman, S. Elrington, R. Elsasser, I. Elsayed, A. Emerich, S. Engelmann, K. R. Erickson, K. Escobar, A. Estes, M. Facchini, A. Falk, M. Farmer, B. Fearon, K. Ferguson, A. G. Fernandez, F. M. Fernandez, A. H. Ferrera, K. J. Ferris, B. Fett, A. Finck, J. Finley, L. E. Fischer, S. Flynn, F. F. Flöther, K. Fogel, J. P. Fouarge, G. Fraczak, P. Frank, D. Frank, J. C. Franquis, T. N. Friedhoff, D. Friedman, R. Frison, D. Fry, T. Fukui, B. Fuller, R. K. Fwamba, J. Gacon, M. Galante, J. M. Gambetta, C. A. Garcia, D. K. Garcia, J. M. Garcia, A. R. García, S. Garion, J. R. Garrison, B. P. Gaucher, A. Gebbie, J. Gerboth, S. Ghosh, F. Giancaspro, A. Giannetta, G. W. Gibson Jr., L. Gil, L. Gilgeous, G. Gionta, J. R. Glick, J. A. Glick, W. Glogowski, I. Goldman, J. T. Gomez, J. Gomez, S. de la Puente González, A. Gooding, R. T. Gordon, T. Greenfield, J. N. Greiner, L. Gruber, T. P. Gujarati, S. R. Gumede, K. Gunsky, H. Haas, R. Haight, S. A. Hall, I. Hamamura, J. B. Hannon, R. U. Haq, V. Harish, T. T. Harnack, S. Hart, G. S. Haspil, F. Haverkamp, V. Havlicek, C. Haymes, J. Haynes, A. He, M. B. Healy, R. Hebbar, J. Henspeter, F. J. C. Hernández, C. Herrick, J. Hertzberg, A. Hervier, H. Higgins, M. Hillenbrand, I. Hincks, C. W. P. Hoerst, K. L. Holland, B. Holt, M. Hopstaken, H. Horii, T. A. Horvath, R. House, D. Hrtanek, E. Huang, J. Huang, J. R. Huffman, L. Hung, T. Huynh, N. Ibrahim, T. Imamichi, B. Ingmanson, K. Inoue, J. Irish, S. Itoh, T. Itoko, K. Jadin, H. Jagannathan, K. Jambunathan, J. A. Janechek, A. Javadi-Abhari, M. J. Jeanson, T. A. Jennings, O. Jinka, T. Jochym-O’Connor, B. R. Johnson, C. Johnson, S. Johnston, M. R. Jokar, B. A. Jones, E. A. Joseph, P. Jurcevic, H. Kang, M. Karakas, A. Kariye, S. Kashiwa, Z. Kauffman, D. Kaulen, J. Kaus, K. Kawase, G. A. Keefe, P. Keefer, N. Keenan, J. Kern, A. Khokhar, H. Kim, S. Kim, T. Kiraly, S. Kirschner, S. Kister, K. Knodel, W. Kong, B. Kreeger, M. Kriegshauser, K. Krsulich, V. Kumar, M. Kumph, C. Kurotori, D. Kwee, M. LaDue, R. Lallement, W. F. Landers, O. Lanes, G. J. Lapeyre, C. Larsen, O. Lasisi, I. Lauer, D. Layden, S. LeClerc, K. Lee, C. Lee, S. Lekuch, R. Letzter, M. Li, I. Liepuoniute, P. Lindner, T. Lindquist, G. Lindsell, E. G. Liniger, V. Lipinska, C. B. Lirakis, J. Lishman, D. Lokken-Toyli, R. Lolowang, M. Lu, W. Lu, S. Lukashov, A. Lukin, J. Luna, Y. Luo, K. Main, R. Majumdar, M. Malekakhlagh, R. Malik, H. Mallela, H. Mamin, C. Mancini, P. Mann, C. Marroquin, Y. Martin, I. D. Martinez, J. J. Martinez, Y. G. Martín-Mantero, N. A. Masluk, M. Mastro, K. Masuda, A. Matsuo, T. Maurer, D. McClure, M. McDonald, S. McJunkin, D. McKay, P. McKeone, K. McLaughlin, B. McPeek, D. Meirom, F. J. Mertil, R. Mertz, S. S. Meshram, A. Miessen, D. Millar, J. Milloz, Z. Minev, A. Mitchell, B. Mitchell, A. Mitra, T. Mittal, S. Miyabe, H. Mohammadbagherpoor, T. Mori, J. G. Mosquera, S. Mostame, M. A. Mueed, S. Mukesh, T. Mulder, Y. Muranaka, W. Murphy, C. Murray, J. P. Mzila-O’Connor, T. Müller, J. Nah, V. K. Naik, K. Najafi, D. Nakano, Y. Nam, P. Nation, J. S. Newbury, C. Nirkhe, S. Nur, P. O’Brien, K. O’Connell, L. E. Ocola, R. Ohira, M. Ohtani, T. Onodera, E. Opata, J. Orcutt, L. Oscarlece, R. Otaolea, I. Othmani, J. A. Ott, G. I. Ovejero, R. Padbury, E. B. H. Padilla, S. Panda, J. M. Papalia, R. Paranjape, P. Parazzoli, J. E. Park, B. Parney, R. T. Paske, D. Passarella, J. Patel, G. F. Paulik, E. Pednault, T. Pellegrini, B. Peropadre, K. S. Petrarca, S. Peyer, A. A. de la Peña, S. M. Pfaendler, M. Pfaffhauser, A. Phan, T. Phung, K. Pizzolato, B. Pokharel, T. Poole, K. Pooley, A. Popescu, C. Porter, A. Prabhakar, J. A. Prentice, E. Prew, E. Pritchett, M. Proissl, R. de Putter, D. Puzzuoli, A. Pyzyna, B. Quanz, E. Quigley, V. Radescu, J. J. Raftery, S. Raghunathan, A. Ragupathi, S. Rajalingam, P. Rall, J. Ralph, I. R. Ramallal, D. Ramirez, A. Rao, V. Rastunkov, A. Ray, S. Rayyan, C. T. Rettner, P. D. Reyes, C. Richard, D. Ristè, E. Rivera, P. Rivero, M. Rizzolo, J. M. Roberts, N. Robertson, N. Robinson-Duncan, K. Rodbell, D. J. Rodriguez, D. M. Rodriguez, V. Rodriguez-Toro, A. Rojas, A. Rose, K. Ross, M. Rossmannek, T. Roth, M. B. Rothwell, J. R. Rozen, J. J. Ruedinger, D. Rugar, J. A. Russo, L. Sabaloz, H. Saenz, M. Sagianis, M. Sandberg, S. Sanichar, A. Sasaki, R. Sathananthan, A. Sauerland, H. Saunders, F. Scafirimuto, C. Scerbo, P. Schardt, M. J. Scheckel, L. Schleeper, R. Schmidt, J. M. Schmoll, R. Schoenberger, T. L. Scholten, K. Schoneck, J. Schuhmacher, A. Seif, M. Selvanayagam, H. H. R. Sepulveda, I. F. Sertage, P. Shah, W. Shanks, D. Shao, V. Sharma, D. Sharma, O. Shehab, R. M. Shelby, S. Sheldon, J. Sherman, N. Shimada, O. Shtanko, S. A. Shurson, V. Siddhu, W. Simmons, N. Simon, E. N. Sirong, J. W. Sleight, J. Smith, J. A. Smolin, B. Snell, D. Soederstedt, J. G. Sogo, J. Speidell, W. Spratt, S. Spring, S. Srinivasan, A. A. Stabile, K. Stawiasz, M. Steffen, J. Stehlik, R. Steiner, D. Stephenson, C. Stuckey, L. V. Subramaniam, J. Summerour, Y. Sun, N. Sundaresan, K. Sung, J. Suttle, T. Syed, C. Tabachnick, F. Tacchino, M. Takeori, M. Takita, A. Talle, C. Tan, E. P. Tapia, J. Tarm, I. Tavernelli, N. Taylor, J. Tersoff, S. Thomas, T. Thorbeck, S. Thoss, K. Tian, A. Tiano, K. Tien, J. Timmerwilke, T. Timpane, M. Tokunari, R. Tolentino, M. Tolunay, G. Toth, G. Totir, J. Totte, K. D. Tran, M. Tran, M. Treinish, B. D. Trimm, C. Tuma, M. Turchetti, L. Turlapati, C. S. Tyberg, P. Tysowski, G. Ulsh, D. Underwood, F. Valenti, D. G. Valiñas, M. VanDieren, F. Varchon, R. Vaught, A. C. Vazquez, A. Vilches, V. Villar, D. Vinayagamurthy, M. H. Vishkasougheh, S. K. L. P. Vishwakarma, C. C. Voss, C. Vu, E. Vásquez, A. Wack, M. Walther, C. Wang, D. Wang, F. Wang, M. Ware, J. Watrous, B. Webb, P. Wendling, B. Werneke, N. White, S. Willenborg, J. Williams, D. Wisnieff, S. Woerner, A. Wolseth, R. Woo, K. Wood, S. P. Wood, C. J. Wood, J. R. Wootton, J. L. Wright, B. Wymore, L. Xing, C. Xiong, T. Yamamoto, H. W. Yan, J. Yau, J. Yeh, K. Yoagaraj, T. Yoder, T. Younger, J. Yu, V. Yuen, D. Zajac, D. Zarsky, B. Zazueta, G. Zettles IV, E. J. Zhang, H. Zhang, R. Zhao, G. Zhu, S. Zhuk, S. Ziemak, C. Zoufal. M.Z. and S.A. were supported by the U.S. Department of Energy, Office of Science, Basic Energy Sciences, under Early Career Award No. DE-SC0022716. Y.W. is supported by the RIKEN iTHEMS fellowship. This work used the Anvil supercomputer at Purdue University through allocation PHY220016 from the Advanced Cyberinfrastructure Coordination Ecosystem: Services & Support (ACCESS) programme, which is supported by National Science Foundation grant nos. 2138259, 2138286, 2138307, 2137603 and 2138296. This research used resources of the National Energy Research Scientific Computing Center, a DOE Office of Science User Facility supported by the Office of Science of the U.S. Department of Energy under contract no. DE-AC02-05CH11231 using NERSC award BES-ERCAP0024710. This research used the Lawrencium computational cluster resource provided by the IT Division at the Lawrence Berkeley National Laboratory (supported by the Director, Office of Science, Office of Basic Energy Sciences, of the U.S. Department of Energy under contract no. DE-AC02-05CH11231). We are indebted to Frank Pollmann and Sheng-Hsuan Lin for their contributions to the isoTNS code used in this work. S.A. thanks J. Hauschild for insightful conversations and support with the TeNPy library 33 , which was used to implement the MPS simulations.
Author information Author notes These authors contributed equally: Youngseok Kim, Andrew Eddins
Authors and Affiliations IBM Quantum, IBM Thomas J. Watson Research Center, Yorktown Heights, NY, USA Youngseok Kim, Ken Xuan Wei, Ewout van den Berg, Sami Rosenblatt, Hasan Nayfeh, Kristan Temme & Abhinav Kandala
IBM Quantum, IBM Research - Cambridge, Cambridge, MA, USA Andrew Eddins
Department of Physics, University of California, Berkeley, Berkeley, CA, USA Sajant Anand, Yantao Wu & Michael Zaletel
RIKEN iTHEMS, Wako, Japan Yantao Wu
Materials Sciences Division, Lawrence Berkeley National Laboratory, Berkeley, CA, USA Michael Zaletel
Authors Youngseok Kim View author publications  Search author on: PubMed   Google Scholar
Andrew Eddins View author publications  Search author on: PubMed   Google Scholar
Sajant Anand View author publications  Search author on: PubMed   Google Scholar
Ken Xuan Wei View author publications  Search author on: PubMed   Google Scholar
Ewout van den Berg View author publications  Search author on: PubMed   Google Scholar
Sami Rosenblatt View author publications  Search author on: PubMed   Google Scholar
Hasan Nayfeh View author publications  Search author on: PubMed   Google Scholar
Yantao Wu View author publications  Search author on: PubMed   Google Scholar
Michael Zaletel View author publications  Search author on: PubMed   Google Scholar
Kristan Temme View author publications  Search author on: PubMed   Google Scholar
Abhinav Kandala View author publications  Search author on: PubMed   Google Scholar
Contributions Y.K. and A.E. ran hardware and numerical experiments. S.A., Y.W. and M.Z. developed the tensor network methods and ran the classical simulations. Y.K., K.X.W. and A.K. developed the device-calibration protocol and calibrated the quantum processor with S.R. and H.N. E.v.d.B. and K.T. developed the error-mitigation protocol. Y.K., A.E., S.A., M.Z., K.T. and A.K. analysed the data. All authors contributed to the manuscript. K.T. and A.K. designed the project. A.K. managed the project. Corresponding authors Correspondence to Youngseok Kim , Andrew Eddins or Abhinav Kandala .
Ethics declarations
Competing interests
The authors declare no competing interests.
Peer review
Peer review information
Nature thanks Jonas Bylander, Zhenyu Cai, Balint Koczor, Göran Wendin and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available.
Additional information Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.
Supplementary information
Supplementary Information (download PDF )  Supplementary Sections 1–10, including Supplementary Figs. 1–13, Supplementary Table 1 and Supplementary References.
Peer Review File (download PDF )
Rights and permissions
Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/ .
Reprints and permissions
About this article
Cite this article Kim, Y., Eddins, A., Anand, S. et al. Evidence for the utility of quantum computing before fault tolerance. Nature 618 , 500–505 (2023). https://doi.org/10.1038/s41586-023-06096-3 Download citation  Received : 24 February 2023
Accepted : 18 April 2023
Published : 14 June 2023
Version of record : 14 June 2023
Issue date : 15 June 2023
DOI : https://doi.org/10.1038/s41586-023-06096-3
Share this article Anyone you share the following link with will be able to read this content: Get shareable link Sorry, a shareable link is not currently available for this article.
Copy shareable link to clipboard
Provided by the Springer Nature SharedIt content-sharing initiative
Subjects
Information technology  Quantum information  Quantum simulation
This article is cited by
Quantum-machine-assisted drug discovery
Yidong Zhou Jintai Chen Zhiding Liang
npj Drug Discovery (2026)
Realization of two-dimensional discrete time crystals with anisotropic Heisenberg coupling
Eric D. Switzer Niall F. Robertson Nicolás Lorente
Nature Communications (2026)
On the fundamental resource for exponential advantage in quantum channel learning
Minsoo Kim Changhun Oh
Nature Communications (2026)
Treespilation: architecture- and state-optimised fermion-to-qubit mappings
Aaron Miller Adam Glos Zoltán Zimborás
npj Quantum Information (2026)
Improved quantum computation using operator backpropagation
Bryce Fuller Minh C. Tran Antonio Mezzacapo
npj Quantum Information (2026)
Download PDF
Associated content
Quantum computer scales up by mitigating errors
Göran Wendin Jonas Bylander
Nature
News & Views
14 Jun 2023
What IBM’s result means for quantum computing
Shamini Bundell Nick Petrić Howe
Nature
Nature Podcast
14 Jun 2023
Sections  Figures  References  Abstract  Main  Methods  Data availability  References  Acknowledgements  Author information  Ethics declarations  Peer review  Additional information  Supplementary information  Rights and permissions  About this article  This article is cited by
Advertisement
Fig. 1: Noise characterization and scaling for 127-qubit Trotterized time-evolution circuits. View in article Full size image
Fig. 2: Zero-noise extrapolation with probabilistic error amplification. View in article Full size image
Fig. 3: Classically verifiable expectation values from 127-qubit, depth-15 Clifford and non-Clifford circuits. View in article Full size image
Fig. 4: Estimating expectation values beyond exact verification. View in article Full size image
van den Berg, E., Minev, Z.K., Kandala, A. et al. Probabilistic error cancellation with sparse Pauli–Lindblad models on noisy quantum processors. Nat. Phys. https://doi.org/10.1038/s41567-023-02042-2 (2023).
Paeckel, S. et al. Time-evolution methods for matrix-product states. Ann. Phys. 411 , 167998 (2019). Article   MathSciNet   CAS   MATH    Google Scholar
Zaletel, M. P. & Pollmann, F. Isometric tensor network states in two dimensions. Phys. Rev. Lett. 124 , 037201 (2020). Article   ADS   MathSciNet   CAS   PubMed    Google Scholar
Preskill, j Quantum computing in the NISQ era and beyond. Quantum 2 , 79 (2018). Article    Google Scholar
Bharti, K. et al. Noisy intermediate-scale quantum algorithms. Rev. Mod. Phys. 94 , 015004 (2022). Article   ADS   MathSciNet   CAS    Google Scholar
Shor, P. W. in Proc. 35th Annual Symposium on Foundations of Computer Science 124–134 (IEEE, 1994).
Kitaev, A. Y. Quantum measurements and the Abelian Stabilizer Problem. Preprint at https://arxiv.org/abs/quant-ph/9511026 (1995).
Arute, F. et al. Quantum supremacy using a programmable superconducting processor. Nature 574 , 505–510 (2019). Article   ADS   CAS   PubMed    Google Scholar
Temme, K., Bravyi, S. & Gambetta, J. M. Error mitigation for short-depth quantum circuits. Phys. Rev. Lett. 119 , 180509 (2017). Article   ADS   MathSciNet   PubMed    Google Scholar
Li, Y. & Benjamin, S. C. Efficient variational quantum simulator incorporating active error minimization. Phys. Rev. X 7 , 021050 (2017).
Google Scholar
Mi, X. et al. Time-crystalline eigenstate order on a quantum processor. Nature 601 , 531–536 (2022). Article   ADS   CAS   PubMed    Google Scholar
Frey, P. & Rachel, S. Realization of a discrete time crystal on 57 qubits of a quantum computer. Sci. Adv. 8 , eabm7652 (2022). Article   PubMed   PubMed Central    Google Scholar
Chen, I.-C., Burdick, B., Yao, Y., Orth, P. P. & Iadecola, T. Error-mitigated simulation of quantum many-body scars on quantum computers with pulse-level control. Phys. Rev. Res. 4 , 043027 (2022). Article   CAS    Google Scholar
Mi, X. et al. Noise-resilient edge modes on a chain of superconducting qubits. Science 378 , 785–790 (2022). Article   ADS   CAS   PubMed    Google Scholar
Koch, J. et al. Charge-insensitive qubit design derived from the Cooper pair box. Phys. Rev. A 76 , 042319 (2007). Article   ADS    Google Scholar
Chow, J. M. et al. Simple all-microwave entangling gate for fixed-frequency superconducting qubits. Phys. Rev. Lett. 107 , 080502 (2011). Article   ADS   PubMed    Google Scholar
Kim, Y. et al. Scalable error mitigation for noisy quantum circuits produces competitive expectation values. Nat. Phys. https://doi.org/10.1038/s41567-022-01914-3 (2023).
Kandala, A. et al. Error mitigation extends the computational reach of a noisy quantum processor. Nature 567 , 491–495 (2019). Article   ADS   CAS   PubMed    Google Scholar
Endo, S., Benjamin, S. C. & Li, Y. Practical quantum error mitigation for near-future applications. Phys. Rev. X 8 , 031027 (2018). CAS    Google Scholar
Dumitrescu, E. F. et al. Cloud quantum computing of an atomic nucleus. Phys. Rev. Lett. 120 , 210501 (2018). Article   ADS   CAS   PubMed    Google Scholar
He, A., Nachman, B., de Jong, W. A. & Bauer, C. W. Zero-noise extrapolation for quantum-gate error mitigation with identity insertions. Phys. Rev. A 102 , 012426 (2020). Article   ADS   MathSciNet   CAS    Google Scholar
Giurgica-Tiron, T., Hindy, Y., Larose, R., Mari, A. & Zeng, W. J. digital zero noise extrapolation for quantum error mitigation. in 2020 IEEE International Conference on Quantum Computing and Engineering (QCE) 306–316 (IEEE, 2020).
Bennett, C. H. et al. Purification of noisy entanglement and faithful teleportation via noisy channels. Phys. Rev. Lett. 76 , 722–725 (1996). Article   ADS   CAS   PubMed    Google Scholar
Knill, E. Fault-tolerant postselected quantum computation: threshold analysis. Preprint at https://arxiv.org/abs/quant-ph/0404104 (2004).
Mari, A., Shammah, N. & Zeng, W. J. Extending quantum probabilistic error cancellation by noise scaling. Phys. Rev. A 104 , 052607 (2021). Article   ADS   MathSciNet   CAS    Google Scholar
Ferracin, S. et al. Efficiently improving the performance of noisy quantum computers. Preprint at https://arxiv.org/abs/2201.10672 (2022).
McDonough, B. et al. Automated quantum error mitigation based on probabilistic error reduction. In I EEE/ACM Third International Workshop on Quantum Computing Software (QCS) 83–93 (IEEE/ACM, 2022).
Carroll, M., Rosenblatt, S., Jurcevic, P., Iauer, I. & Kandala, A. Dynamics of superconducting qubit relaxation times. npj Quantum Inf. 9 , 132 (2022). Article   ADS    Google Scholar
Aaronson, S. & Gottesman, D. Improved simulation of stabilizer circuits. Phys. Rev. A 70 , 052328 (2004). Article   ADS    Google Scholar
Tran, M. C., Sharma, K. & Temme, K. Locality and error mitigation of quantum circuits. Preprint at https://arxiv.org/abs/2303.06496 (2023).
Cai, Z. Multi-exponential error extrapolation and combining error mitigation techniques for NISQ applications. npj Quantum Inf. 7 , 80 (2021). Article   ADS    Google Scholar
Schöllwock, U. The density-matrix renormalization group in the age of matrix product states. Ann. Phys. 326 , 96–192 (2011). Article   ADS   MathSciNet   MATH    Google Scholar
Hauschild, J. & Pollmann, F. Efficient numerical simulations with tensor networks: Tensor Network Python (TeNPy). SciPost Phys. Lect. Notes https://doi.org/10.21468/SciPostPhysLectNotes.5 (2018).
Zhou, Y., Stoudenmire, E. M. & Waintal, X. What limits the simulation of quantum computers?. Phys. Rev. X 10 , 041038 (2020). CAS    Google Scholar
Guo, C. et al. General-purpose quantum circuit simulator with projected entangled-pair states and the quantum supremacy frontier. Phys. Rev. Lett. 123 , 190501 (2019). Article   ADS   CAS   PubMed    Google Scholar
Ayral, T. et al. Density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity. PRX Quantum 4 , 020304 (2023). Article   ADS    Google Scholar
Calabrese, P. & Cardy, J. Evolution of entanglement entropy in one-dimensional systems. J. Stat. Mech. Theory Exp. 2005 , P04010 (2005). Article   MathSciNet   MATH    Google Scholar
Bravyi, S. et al. Simulation of quantum circuits by low-rank stabilizer decompositions. Quantum 3 , 181 (2019). Article    Google Scholar
Hubig, C., Haegeman, J. & Schollwöck, U. Error estimates for extrapolations with matrix-product states. Phys. Rev. B 97 , 045125 (2018). Article   ADS    Google Scholar
Rakovszky, T., von Keyserlingk, C. W. & Pollmann, F. Dissipation-assisted operator evolution method for capturing hydrodynamic transport. Phys. Rev. B 105 , 075131 (2022). Article   ADS   CAS    Google Scholar
White, C. D., Zaletel, M., Mong, R. S. K. & Refael, G. Quantum dynamics of thermalizing systems. Phys. Rev. B 97 , 035127 (2018). Article   ADS   CAS    Google Scholar
Stehlik, J. et al. Tunable coupling architecture for fixed-frequency transmon superconducting qubits. Phys. Rev. Lett. 127 , 080505 (2021). Article   ADS   CAS   PubMed    Google Scholar
Zhang, E. J. et al. High-performance superconducting quantum processors via laser annealing of transmon qubits. Sci. Adv. 8 , eabi6690 (2022). Article   CAS   PubMed   PubMed Central    Google Scholar
Wei, K. X. et al. Hamiltonian engineering with multicolor drives for fast entangling gates and quantum crosstalk cancellation. Phys. Rev. Lett. 129 , 060501 (2022). Article   ADS   CAS   PubMed    Google Scholar
Cirac, J. I., Pérez-García, D., Schuch, N. & Verstraete, F. Matrix product states and projected entangled pair states: concepts, symmetries, theorems. Rev. Mod. Phys. 93 , 045003 (2021). Article   ADS   MathSciNet   CAS    Google Scholar
Nature
( Nature )
ISSN 1476-4687 (online)
ISSN 0028-0836 (print)
nature.com footer links
About Nature Portfolio
About us
Press releases
Press office
Contact us
Discover content
Journals A-Z
Articles by subject
protocols.io
Nature Index
Publishing policies
Nature portfolio policies
Open access
Author & Researcher services
Reprints & permissions
Research data
Language editing
Scientific editing
Nature Masterclasses
Research Solutions
Libraries & institutions
Librarian service & tools
Librarian portal
Open research
Recommend to library
Advertising & partnerships
Advertising
Partnerships & Services
Media kits
Branded content
Professional development
Nature Awards
Nature Careers
Nature  Conferences
Regional websites
Nature Africa
Nature China
Nature India
Nature Japan
Nature Middle East
Privacy Policy
Use of cookies
Your privacy choices/Manage cookies
Legal notice
Accessibility statement
Terms & Conditions
Your US state privacy rights
© 2026 Springer Nature Limited
Close banner
Close
Sign up for the Nature Briefing: AI and Robotics newsletter — what matters in AI and robotics research, free to your inbox weekly.
Email address
Sign up
I agree my information will be processed in accordance with the Nature and Springer Nature Limited Privacy Policy .
Close banner
Close
Get the most important science stories of the day, free in your inbox.  Sign up for Nature Briefing: AI and Robotics
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [23]: F. Pan, P. Zhang — Simulation of quantum circuits using the big-batch tensor network method (Phys. Rev. Lett. 128, 030501, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Simulation of Quantum Circuits Using the Big-Batch Tensor Network Method
URL: https://doi.org/10.1103/PhysRevLett.128.030501
Simulation of Quantum Circuits Using the Big-Batch Tensor Network Method - Astrophysics Data System
Skip to main content
Now on article abstract page
Toggle navigation
ads
SciX Transition Resources
SciX is the evolution of ADS, bringing its powerful capabilities into new domains. SciX will become the sole interface in late 2026.
Visit SciX
Learn about SciX
Feedback
Submit Updates
General Feedback
ORCID
Sign in to ORCID to claim papers in the ADS.
About
Transition to SciX
About ADS
What's New
ADS Blog
ADS Help Pages
ADS Legacy Services
Careers@ADS
Sign Up
Log In
ADS is currently experiencing an issue with missing recent ArXiv preprints. Please be assured the records are in the system and we are actively working on a solution to propagate them to the search engine.
Close
Search Bar to Enter New Query
quick field:
Author  First Author  Abstract
Year  Fulltext
Select a field or operator
abstract  abstract only  acknowledgements  affiliation  arXiv category  author count  author  bibcode  bibliographic group  bib abbrev, e.g. ApJ  body of article  data archive  collection  citation count  doctype  doi  entdate  first author  fulltext  identifier  inst  keyword  object  orcid  page  property  publication full name  date published  title  uat  volume  year
citations()  pos()  references()  reviews()  similar()  topn()  trending()  useful()
single wildcard: ?  wildcard: *  exact match: =
All Search Terms
Your search returned 0 results
Your search returned  0  results
Show Menu  Full Text Sources
view
Abstract
Citations (100)
References (26)
Co-Reads
Similar Papers
Volume Content
Graphics
Metrics
Export Citation
|-->
Simulation of Quantum Circuits Using the Big-Batch Tensor Network Method
Show affiliations
Loading affiliations  affiliations loading
Pan, Feng
;
Zhang, Pan
Abstract
We propose a tensor network approach to compute amplitudes and probabilities for a large number of correlated bitstrings in the final state of a quantum circuit. As an application, we study Google's Sycamore circuits, which are believed to be beyond the reach of classical supercomputers and have been used to demonstrate quantum supremacy. By employing a small computational cluster containing 60 graphical processing units (GPUs), we compute exact amplitudes and probabilities of 2 ×10 6 correlated bitstrings with some entries fixed (which span a subspace of the output probability distribution) for the Sycamore circuit with 53 qubits and 20 cycles. The obtained results verify the Porter-Thomas distribution of the large and deep quantum circuits of Google, provide datasets and benchmarks for developing approximate simulation methods, and can be used for spoofing the linear cross entropy benchmark of quantum supremacy. Then we extend the proposed big-batch method to a full-amplitude simulation approach that is more efficient than the existing Schrödinger method on shallow circuits and the Schrödinger-Feynman method in general, enabling us to obtain the state vector of Google's simplifiable circuit with n =43 qubits and m =14 cycles using only one GPU. We also manage to obtain the state vector for Google's simplifiable circuits with n =50 qubits and m =14 cycles using a small GPU cluster, breaking the previous record on the number of qubits in full-amplitude simulations. Our method is general in computing bitstring probabilities for a broad class of quantum circuits and can find applications in the verification of quantum computers. We anticipate that our method will pave the way for combining tensor network-based classical computations and near-term quantum computations for solving challenging problems in the real world.
Publication:
Physical Review Letters, Volume 128, Issue 3, article id.030501
Pub Date:  January 2022  DOI:
10.1103/PhysRevLett.128.030501
Bibcode:
2022PhRvL.128c0501P
Copied!
Feedback/Corrections?
full text sources
APS Electronic on-line publisher article (HTML)
Graphics
Click to view more
© The SAO Astrophysics Data System
adshelp[at]cfa.harvard.edu
The ADS is operated by the Smithsonian Astrophysical Observatory under NASA Cooperative Agreement 80NSSC25M7105
*The material contained in this document is based upon work supported by a National Aeronautics and Space Administration (NASA) grant or cooperative agreement. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author and do not necessarily reflect the views of NASA.
Resources
About ADS
ADS Help
System Status
What's New
Careers@ADS
Web Accessibility Policy
Social
@adsabs
ADS Blog
Project
Switch to basic HTML
Privacy Policy
Terms of Use
Smithsonian Astrophysical Observatory
Smithsonian Institution
NASA
🌓
View page in SciX
×
Back
How may we help you?
Missing/Incorrect Record
Submit a missing record or correct an existing record.
Missing References
Submit missing references to an existing ADS record.
Associated Articles
Submit associated articles to an existing record (e.g. arXiv / published paper).
General Feedback
Send your comments and suggestions for improvements.
Name
Email
Feedback
Submit
You can also reach us at adshelp [at] cfa.harvard.edu
This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.
Close without submitting
Alert
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [24]: J. Gray, S. Kourtis — Hyper-optimized tensor network contraction (Quantum 5, 410, 2021)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Hyper-optimized tensor network contraction
URL: https://doi.org/10.22331/q-2021-03-15-410
Hyper-optimized tensor network contraction – Quantum
Skip to content
the open journal for quantum science
Menu
Papers
Perspectives
Instructions
For authors
For referees
For editors
For authors of Views
Editorial policies
People
About
News
Mission and structure
Tools and open source
Code of Conduct
Outreach
Press
Contact
Hyper-optimized tensor network contraction
Hyper-optimized tensor network contraction  Johnnie Gray 1,2 and Stefanos Kourtis 1,3,4  1 Blackett Laboratory, Imperial College London, London SW7 2AZ, United Kingdom 2 Division of Chemistry and Chemical Engineering, California Institute of Technology, Pasadena, California 91125, USA 3 Department of Physics, Boston University, Boston, MA, 02215, USA 4 Institut quantique & Département de physique, Université de Sherbrooke, Québec J1K 2R1, Canada
Published: 2021-03-15, volume 5 , page 410  Eprint: arXiv:2002.01935v4  Doi: https://doi.org/10.22331/q-2021-03-15-410  Citation: Quantum 5, 410 (2021).  Get full text pdf Read on arXiv Vanity  Find this paper interesting or want to discuss? Scite or leave a comment on SciRate .
Abstract Tensor networks represent the state-of-the-art in computational methods across many disciplines, including the classical simulation of quantum many-body systems and quantum circuits. Several applications of current interest give rise to tensor networks with irregular geometries. Finding the best possible contraction path for such networks is a central problem, with an exponential effect on computation time and memory footprint. In this work, we implement new randomized protocols that find very high quality contraction paths for arbitrary and large tensor networks. We test our methods on a variety of benchmarks, including the random quantum circuit instances recently implemented on Google quantum chips. We find that the paths obtained can be very close to optimal, and often many orders or magnitude better than the most established approaches. As different underlying geometries suit different methods, we also introduce a hyper-optimization approach, where both the method applied and its algorithmic parameters are tuned during the path finding. The increase in quality of contraction schemes found has significant practical implications for the simulation of quantum many-body systems and particularly for the benchmarking of new quantum chips. Concretely, we estimate a speed-up of over 10,000 × × compared to the original expectation for the classical simulation of the Sycamore `supremacy' circuits.
Featured image: Example of a near-optimal contraction tree for a small tensor network.
Popular summary
Tensor networks offer a universal language that can express a large variety of scientific concepts, from partition functions to quantum circuits. Tensor network contraction can be a practical method for addressing computational challenges, such as the solution of hard constraint satisfaction problems or the simulation and benchmarking of quantum computation on classical computers. The core task of contracting a tensor network is exponentially sensitive to the quality of a so-called contraction tree, which describes a series of pairwise merges that turn the network into a single tensor. We tackle this problem with three key techniques. Firstly, we re-conceive the tensor network as a hyper-graph and use hyper-graph partitioning to build the tree. Secondly, we introduce various simplification schemes to prepare the tensor network for contraction. Finally, we use a Bayesian optimizer that intelligently learns to build ever better trees for a particular contraction. We show vastly improved performance for a variety of problems, including the simulation of Google's Sycamore circuits, the simulation of the quantum approximate optimization algorithm, as well as the solution of weighted model counting problems. For accessible sizes, the paths we find are very close to optimal.
► BibTeX data
@article{Gray2021hyperoptimized,
doi = {10.22331/q-2021-03-15-410},
url = {https://doi.org/10.22331/q-2021-03-15-410},
title = {Hyper-optimized tensor network contraction},
author = {Gray, Johnnie and Kourtis, Stefanos},
journal = {{Quantum}},
issn = {2521-327X},
publisher = {{Verein zur F{\"{o}}rderung des Open Access Publizierens in den Quantenwissenschaften}},
volume = {5},
pages = {410},
month = mar,
year = {2021}
} ► References
[1] F. Verstraete, V. Murg, and J. Cirac, Adv. Phys. 57, 143 (2008).
https:/​/​doi.org/​10.1080/​14789940801912366
[2] R. Orús, Ann. Phys. (N. Y). 349, 117 (2014).
https:/​/​doi.org/​10.1016/​j.aop.2014.06.013
[3] J. C. Bridgeman and C. T. Chubb, J. Phys. A Math. Theor. 50, 223001 (2017).
https:/​/​doi.org/​10.1088/​1751-8121/​aa6dc3
[4] J. D. Biamonte and V. Bergholm, arXiv:1708.00006 (2017), arXiv:1708.00006.
arXiv:1708.00006
[5] M. Levin and C. P. Nave, Phys. Rev. Lett. 99, 120601 (2007).
https:/​/​doi.org/​10.1103/​PhysRevLett.99.120601
[6] G. Evenbly and G. Vidal, Phys. Rev. Lett. 115, 180405 (2015).
https:/​/​doi.org/​10.1103/​PhysRevLett.115.180405
[7] G. Evenbly, Phys. Rev. B 95, 045117 (2017).
https:/​/​doi.org/​10.1103/​PhysRevB.95.045117
[8] A. Cichocki, N. Lee, I. Oseledets, A.-H. Phan, Q. Zhao, and D. P. Mandic, Found. Trends Mach. Learn. 9, 249 (2016).
https:/​/​doi.org/​10.1561/​2200000059
[9] A. Cichocki, N. Lee, I. Oseledets, A.-H. Phan, Q. Zhao, M. Sugiyama, and D. P. Mandic, Found. Trends Mach. Learn. 9, 431 (2017).
https:/​/​doi.org/​10.1561/​2200000067
[10] L. Dueñas-Osorio, M. Y. Vardi, and J. Rojo, Struct. Saf. 75, 110 (2018).
https:/​/​doi.org/​10.1016/​j.strusafe.2018.05.004
[11] I. L. Markov and Y. Shi, SIAM J. Comput. 38, 963 (2008).
https:/​/​doi.org/​10.1137/​050644756
[12] E. Stoudenmire and D. J. Schwab, in Advances in Neural Information Processing Systems 29, edited by D. D. Lee, M. Sugiyama, U. V. Luxburg, I. Guyon, and R. Garnett (Curran Associates, Inc., 2016) pp. 4799–4807.
http:/​/​papers.nips.cc/​paper/​6211-supervised-learning-with-tensor-networks.pdf
[13] E. M. Stoudenmire, Quantum Sci. Technol. 3, 034003 (2018).
https:/​/​doi.org/​10.1088/​2058-9565/​aaba1a
[14] C. Roberts, A. Milsted, M. Ganahl, A. Zalcman, B. Fontaine, Y. Zou, J. Hidary, G. Vidal, and S. Leichenauer, arXiv:1905.01330 (2019), arXiv:1905.01330.
arXiv:1905.01330
[15] H. C. Jiang, Z. Y. Weng, and T. Xiang, Phys. Rev. Lett. 101, 090603 (2008).
https:/​/​doi.org/​10.1103/​PhysRevLett.101.090603
[16] Z.-C. Gu and X.-G. Wen, Phys. Rev. B 80, 155131 (2009).
https:/​/​doi.org/​10.1103/​PhysRevB.80.155131
[17] Z. Y. Xie, J. Chen, M. P. Qin, J. W. Zhu, L. P. Yang, and T. Xiang, Phys. Rev. B 86, 045139 (2012).
https:/​/​doi.org/​10.1103/​PhysRevB.86.045139
[18] H.-H. Zhao, Z. Y. Xie, T. Xiang, and M. Imada, Phys. Rev. B 93, 125115 (2016).
https:/​/​doi.org/​10.1103/​PhysRevB.93.125115
[19] M. Bal, M. Mariën, J. Haegeman, and F. Verstraete, Phys. Rev. Lett. 118, 250602 (2017).
https:/​/​doi.org/​10.1103/​PhysRevLett.118.250602
[20] S. Yang, Z.-C. Gu, and X.-G. Wen, Phys. Rev. Lett. 118, 110504 (2017).
https:/​/​doi.org/​10.1103/​PhysRevLett.118.110504
[21] Y.-Y. Shi, L.-M. Duan, and G. Vidal, Phys. Rev. A 74, 022320 (2006).
https:/​/​doi.org/​10.1103/​PhysRevA.74.022320
[22] L. G. Valiant, SIAM J. Comput. 37, 1565 (2008).
https:/​/​doi.org/​10.1137/​070682575
[23] S. Bravyi, Contemp. Math. 482, 179 (2008), arXiv:0801.2989.
https:/​/​doi.org/​10.1090/​conm/​482/​09419
arXiv:0801.2989
[24] M. Aguado and G. Vidal, Phys. Rev. Lett. 100, 070404 (2008).
https:/​/​doi.org/​10.1103/​PhysRevLett.100.070404
[25] R. König, B. W. Reichardt, and G. Vidal, Phys. Rev. B 79, 195123 (2009).
https:/​/​doi.org/​10.1103/​PhysRevB.79.195123
[26] S. J. Denny, J. D. Biamonte, D. Jaksch, and S. R. Clark, J. Phys. A Math. Theor. 45, 015309 (2012).
https:/​/​doi.org/​10.1088/​1751-8113/​45/​1/​015309
[27] L. G. Valiant, Theor. Comput. Sci. 8, 189 (1979).
https:/​/​doi.org/​10.1016/​0304-3975(79)90044-6
[28] C. Damm, M. Holzer, and P. McKenzie, Comput. Complex. 11, 54 (2002).
https:/​/​doi.org/​10.1007/​s00037-000-0170-4
[29] B. M. Terhal and D. P. DiVincenzo, Quant. Inf. Comp. 4, 134 (2004), arXiv:0205133 [quant-ph].
arXiv:quant-ph/0205133
[30] M. J. Bremner, R. Jozsa, and D. J. Shepherd, Proc. R. Soc. A Math. Phys. Eng. Sci. 467, 459 (2010).
https:/​/​doi.org/​10.1098/​rspa.2010.0301
[31] S. Aaronson and A. Arkhipov, Theory Comput. 9, 143 (2013).
https:/​/​doi.org/​10.4086/​toc.2013.v009a004
[32] R. Jozsa and M. V. den Nest, arXiv:1305.6190 (2013), https:/​/​doi.org/​10.26421/​qic14.7-8-7, arXiv:1305.6190.
https:/​/​doi.org/​10.26421/​qic14.7-8-7
arXiv:1305.6190
[33] T. Morimae, K. Fujii, and J. F. Fitzsimons, Phys. Rev. Lett. 112, 130502 (2014).
https:/​/​doi.org/​10.1103/​PhysRevLett.112.130502
[34] J. Carolan, C. Harrold, C. Sparrow, E. Martin-Lopez, N. J. Russell, J. W. Silverstone, P. J. Shadbolt, N. Matsuda, M. Oguma, M. Itoh, G. D. Marshall, M. G. Thompson, J. C. F. Matthews, T. Hashimoto, J. L. O'Brien, and A. Laing, Science 349, 711 (2015).
https:/​/​doi.org/​10.1126/​science.aab3642
[35] E. Farhi and A. W. Harrow, arXiv:1602.07674 (2016), arXiv:1602.07674.
arXiv:1602.07674
[36] S. Aaronson, A. Bouland, G. Kuperberg, and S. Mehraban, in Proceedings of the 49th Annual ACM SIGACT Symposium on Theory of Computing (2017) pp. 317–327.
https:/​/​doi.org/​10.1145/​3055399.3055453
[37] S. Aaronson and L. Chen, arXiv:1612.05903 (2016), arXiv:1612.05903.
arXiv:1612.05903
[38] S. Boixo, S. V. Isakov, V. N. Smelyanskiy, R. Babbush, N. Ding, Z. Jiang, M. J. Bremner, J. M. Martinis, and H. Neven, Nat. Phys. 14, 595 (2018).
https:/​/​doi.org/​10.1038/​s41567-018-0124-x
[39] A. Bouland, B. Fefferman, C. Nirkhe, and U. Vazirani, Nat. Phys. 15, 159 (2019).
https:/​/​doi.org/​10.1038/​s41567-018-0318-2
[40] E. S. Fried, N. P. D. Sawaya, Y. Cao, I. D. Kivlichan, J. Romero, and A. Aspuru-Guzik, PLoS One 13, e0208510 (2018).
https:/​/​doi.org/​10.1371/​journal.pone.0208510
[41] J. Chen, F. Zhang, C. Huang, M. Newman, and Y. Shi, arXiv:1805.01450 (2018), arXiv:1805.01450.
arXiv:1805.01450
[42] E. F. Dumitrescu, A. L. Fisher, T. D. Goodrich, T. S. Humble, B. D. Sullivan, and A. L. Wright, PLoS One 13, e0207827 (2018).
https:/​/​doi.org/​10.1371/​journal.pone.0207827
[43] S. Kourtis, C. Chamon, E. R. Mucciolo, and A. E. Ruckenstein, SciPost Phys. 7, 60 (2019).
https:/​/​doi.org/​10.21468/​SciPostPhys.7.5.060
[44] J. M. Dudek, L. Dueñas-Osorio, and M. Y. Vardi, arXiv:1908.04381 (2019), arXiv:1908.04381.
arXiv:1908.04381
[45] F. Arute, K. Arya, R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F. G. S. L. Brandao, D. A. Buell, B. Burkett, Y. Chen, Z. Chen, B. Chiaro, R. Collins, W. Courtney, A. Dunsworth, E. Farhi, B. Foxen, A. Fowler, C. Gidney, M. Giustina, R. Graff, K. Guerin, S. Habegger, M. P. Harrigan, M. J. Hartmann, A. Ho, M. Hoffmann, T. Huang, T. S. Humble, S. V. Isakov, E. Jeffrey, Z. Jiang, D. Kafri, K. Kechedzhi, J. Kelly, P. V. Klimov, S. Knysh, A. Korotkov, F. Kostritsa, D. Landhuis, M. Lindmark, E. Lucero, D. Lyakh, S. Mandrà, J. R. McClean, M. McEwen, A. Megrant, X. Mi, K. Michielsen, M. Mohseni, J. Mutus, O. Naaman, M. Neeley, C. Neill, M. Y. Niu, E. Ostby, A. Petukhov, J. C. Platt, C. Quintana, E. G. Rieffel, P. Roushan, N. C. Rubin, D. Sank, K. J. Satzinger, V. Smelyanskiy, K. J. Sung, M. D. Trevithick, A. Vainsencher, B. Villalonga, T. White, Z. J. Yao, P. Yeh, A. Zalcman, H. Neven, and J. M. Martinis, Nature 574, 505 (2019).
https:/​/​doi.org/​10.1038/​s41586-019-1666-5
[46] D. Bienstock, Journal of Combinatorial Theory, Series B 49, 103 (1990).
https:/​/​doi.org/​10.1016/​0095-8956(90)90066-9
[47] B. O'Gorman, in 14th Conference on the Theory of Quantum Computation, Communication and Cryptography (TQC 2019), Leibniz International Proceedings in Informatics (LIPIcs), Vol. 135, edited by W. van Dam and L. Mancinska (Schloss Dagstuhl–Leibniz-Zentrum fuer Informatik, Dagstuhl, Germany, 2019) pp. 10:1–10:19.
https:/​/​doi.org/​10.4230/​LIPIcs.TQC.2019.10
[48] R. N. C. Pfeifer, J. Haegeman, and F. Verstraete, Phys. Rev. E 90, 033315 (2014).
https:/​/​doi.org/​10.1103/​PhysRevE.90.033315
[49] D. G. A. Smith and J. Gray, J. Open Source Softw. 3, 753 (2018).
https:/​/​doi.org/​10.21105/​joss.00753
[50] V. Gogate and R. Dechter, in Proceedings of the 20th conference on Uncertainty in artificial intelligence (AUAI Press, 2004) pp. 201–208, arXiv:1207.4109.
arXiv:1207.4109
[51] M. Hamann and B. Strasser, J. Exp. Algorithmics 23, 1.2 (2018).
https:/​/​doi.org/​10.1145/​3173045
[52] B. Strasser, arXiv:1709.08949 (2017), arXiv:1709.08949.
arXiv:1709.08949
[53] M. A. Porter, J.-P. Onnela, and P. J. Mucha, Not. Am. Math. Soc. 56, 1082 (2009), arXiv:0902.3788.
arXiv:0902.3788
[54] S. Fortunato, Phys. Rep. 486, 75 (2010).
https:/​/​doi.org/​10.1016/​j.physrep.2009.11.002
[55] M. Girvan and M. E. J. Newman, Proc. Natl. Acad. Sci. 99, 7821 (2002).
https:/​/​doi.org/​10.1073/​pnas.122653799
[56] S. Schlag, V. Henne, T. Heuer, H. Meyerhenke, P. Sanders, and C. Schulz, in 2016 Proc. Eighteenth Work. Algorithm Eng. Exp. (Society for Industrial and Applied Mathematics, Philadelphia, PA, 2016) pp. 53–67.
https:/​/​doi.org/​10.1137/​1.9781611974317.5
[57] Y. Akhremtsev, T. Heuer, P. Sanders, and S. Schlag, in 2017 Proc. Ninteenth Work. Algorithm Eng. Exp. (Society for Industrial and Applied Mathematics, Philadelphia, PA, 2017) pp. 28–42.
https:/​/​doi.org/​10.1137/​1.9781611974768.3
[58] D. A. Papa and I. L. Markov, in Handbook of Approximation Algorithms and Metaheuristics (2007).
[59] B. Shahriari, K. Swersky, Z. Wang, R. P. Adams, and N. de Freitas, Proceedings of the IEEE 104, 148 (2016).
https:/​/​doi.org/​10.1109/​JPROC.2015.2494218
[60] L. Gustafson, Bayesian Tuning and Bandits: An Extensible, Open Source Library for AutoML, M. eng thesis, Massachusetts Institute of Technology, Cambridge, MA (2018).
https:/​/​dai.lids.mit.edu/​wp-content/​uploads/​2018/​05/​Laura_MEng_Final.pdf
[61] C. K. Williams and C. E. Rasmussen, Gaussian processes for machine learning, Vol. 2 (MIT press Cambridge, MA, 2006).
https:/​/​doi.org/​10.7551/​mitpress/​3206.001.0001
[62] S. Boixo, S. V. Isakov, V. N. Smelyanskiy, and H. Neven, arXiv:1712.05384 (2017), arXiv:1712.05384.
arXiv:1712.05384
[63] J. Gray, Journal of Open Source Software 3, 819 (2018).
https:/​/​doi.org/​10.21105/​joss.00819
[64] J. Gray, ``cotengra,'' https:/​/​github.com/​jcmgray/​cotengra (2020).
https:/​/​github.com/​jcmgray/​cotengra
[65] B. Villalonga, D. Lyakh, S. Boixo, H. Neven, T. S. Humble, R. Biswas, E. G. Rieffel, A. Ho, and S. Mandrà, Quantum Science and Technology 5, 034003 (2020).
https:/​/​doi.org/​10.1088/​2058-9565/​ab7eeb
[66] I. L. Markov and Y. Shi, Algorithmica 59 (2009), https:/​/​doi.org/​10.1007/​s00453-009-9312-5.
https:/​/​doi.org/​10.1007/​s00453-009-9312-5
[67] F. Viger and M. Latapy, in COCOON'05 Proc. 11th Annu. Int. Conf. Comput. Comb. (2005) pp. 440–449.
https:/​/​doi.org/​10.1007/​11533719_45
[68] K. Meichanetzidis and S. Kourtis, Phys. Rev. E 100, 033303 (2019).
https:/​/​doi.org/​10.1103/​PhysRevE.100.033303
[69] É. Fusy, Random Struct. Algorithms 35, 464 (2009).
https:/​/​doi.org/​10.1002/​rsa.20275
[70] J.-Y. Cai and V. Choudhary, Theoretical Computer Science 384, 22 (2007), theory and Applications of Models of Computation.
https:/​/​doi.org/​10.1016/​j.tcs.2007.05.015
[71] F. Bacchus, S. Dalmao, and T. Pitassi, in 44th Annual IEEE Symposium on Foundations of Computer Science, 2003. Proceedings. (2003) pp. 340–351.
https:/​/​doi.org/​10.1109/​SFCS.2003.1238208
[72] C. Domshlak and J. Hoffmann, J. Artif. Int. Res. 30, 565–620 (2007).
https:/​/​doi.org/​10.1613/​jair.2289
[73] C. P. Gomes, A. Sabharwal, and B. Selman, in Handbook of Satisfiability (2009).
[74] ``1st international competition on model counting (mc 2020),''.
https:/​/​mccompetition.org/​2020/​mc_description
[75] J. Dudek, V. Phan, and M. Vardi, ``Addmc: Weighted model counting with algebraic decision diagrams,'' (2020).
https:/​/​doi.org/​10.1609/​aaai.v34i02.5505
[76] E. Farhi, J. Goldstone, and S. Gutmann, (2014), arXiv:1411.4028 [quant-ph].
arXiv:1411.4028
[77] C. Huang, M. Szegedy, F. Zhang, X. Gao, J. Chen, and Y. Shi, (2019), arXiv:1909.02559 [quant-ph].
arXiv:1909.02559
[78] J. Preskill, arXiv:1203.5813 (2012), arXiv:1203.5813.
arXiv:1203.5813
[79] E. Pednault, J. A. Gunnels, G. Nannicini, L. Horesh, T. Magerlein, E. Solomonik, E. W. Draeger, E. T. Holland, and R. Wisnieff, arXiv:1710.05867 (2017), arXiv:1710.05867.
arXiv:1710.05867
[80] F. Zhang, C. Huang, M. Newman, J. Cai, H. Yu, Z. Tian, B. Yuan, H. Xu, J. Wu, X. Gao, J. Chen, M. Szegedy, and Y. Shi, arXiv:1907.11217 (2019), arXiv:1907.11217.
arXiv:1907.11217
[81] B. Villalonga, S. Boixo, B. Nelson, C. Henze, E. Rieffel, R. Biswas, and S. Mandrà, npj Quantum Inf. 5, 86 (2019).
https:/​/​doi.org/​10.1038/​s41534-019-0196-1
[82] C. Guo, Y. Liu, M. Xiong, S. Xue, X. Fu, A. Huang, X. Qiang, P. Xu, J. Liu, S. Zheng, H.-L. Huang, M. Deng, D. Poletti, W.-S. Bao, and J. Wu, Phys. Rev. Lett. 123, 190501 (2019).
https:/​/​doi.org/​10.1103/​PhysRevLett.123.190501
[83] I. L. Markov, A. Fatima, S. V. Isakov, and S. Boixo, arXiv preprint arXiv:1807.10749 (2018).
arXiv:1807.10749
[84] https:/​/​github.com/​sboixo/​GRCS.
https:/​/​github.com/​sboixo/​GRCS
[85] I. D. Kivlichan, J. McClean, N. Wiebe, C. Gidney, A. Aspuru-Guzik, G. K.-L. Chan, and R. Babbush, Phys. Rev. Lett. 120, 110501 (2018).
https:/​/​doi.org/​10.1103/​PhysRevLett.120.110501
[86] J. Bradbury, R. Frostig, P. Hawkins, M. J. Johnson, C. Leary, D. Maclaurin, and S. Wanderman-Milne, ``JAX: composable transformations of Python+NumPy programs,'' (2018).
http:/​/​github.com/​google/​jax
[87] S. Bravyi, M. Suchara, and A. Vargo, Phys. Rev. A 90, 032326 (2014).
https:/​/​doi.org/​10.1103/​PhysRevA.90.032326
[88] A. J. Ferris and D. Poulin, Phys. Rev. Lett. 113, 030501 (2014).
https:/​/​doi.org/​10.1103/​PhysRevLett.113.030501
[89] C. T. Chubb and S. T. Flammia, arXiv:1809.10704 (2018).
arXiv:1809.10704
Cited by [1] Jin-Guo Liu, Xun Gao, Madelyn Cain, Mikhail D. Lukin, and Sheng-Tao Wang, "Computing Solution Space Properties of Combinatorial Optimization Problems Via Generic Tensor Networks", SIAM Journal on Scientific Computing 45 3, A1239 (2023) .
[2] Andor Menczer and Örs Legeza, "Tensor Network State Algorithms on AI Accelerators", Journal of Chemical Theory and Computation 20 20, 8897 (2024) .
[3] Feng Pan, Keyang Chen, and Pan Zhang, "Solving the Sampling Problem of the Sycamore Quantum Circuits", Physical Review Letters 129 9, 090502 (2022) .
[4] Shi-Ju Ran and Gang Su, "Tensor Networks for Interpretable and Efficient Quantum-Inspired Machine Learning", Intelligent Computing 2, 0061 (2023) .
[5] Tomasz Szołdra, Rick Mukherjee, and Peter Schmelcher, "Scalable preparation of matrix product states with sequential and brick wall quantum circuits", Quantum Science and Technology 11 2, 025056 (2026) .
[6] Rong Hu, Haotian Wang, Wangdong Yang, Renqiu Ouyang, Keqin Li, and Kenli Li, "BCB-SpTC: An Efficient Sparse High-Dimensional Tensor Contraction Employing Tensor Core Acceleration", IEEE Transactions on Parallel and Distributed Systems 35 12, 2435 (2024) .
[7] Elisabeth Wybo and Martin Leib, "Vanishing performance of the parity-encoded quantum approximate optimization algorithm applied to spin-glass models", Quantum 8, 1554 (2024) .
[8] Adil A. Gangat and Johnnie Gray, "Hyperoptimized approximate contraction of tensor networks for rugged-energy-landscape spin glasses on periodic square and cubic lattices", Physical Review E 110 6, 065306 (2024) .
[9] Lukas Burgholzer, Alexander Ploier, and Robert Wille, "Simulation Paths for Quantum Circuit Simulation With Decision Diagrams What to Learn From Tensor Networks, and What Not", IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems 42 4, 1113 (2023) .
[10] Daniel Strano, Benn Bollay, Aryan Blaauw, Nathan Shammah, William J. Zeng, and Andrea Mari, 2023 IEEE International Conference on Quantum Computing and Engineering (QCE) 949 (2023) ISBN:979-8-3503-4323-6 .
[11] Przemysław Dominikowski, Atte Torri, Brice Pointal, Oguz Kaya, Laercio Lima Pilla, and Olivier Coulaud, 2025 IEEE International Parallel and Distributed Processing Symposium Workshops (IPDPSW) 1274 (2025) ISBN:979-8-3315-2643-6 .
[12] Ar A Melnikov, A A Termanova, S V Dolgov, F Neukart, and M R Perelshtein, "Quantum state preparation using tensor networks", Quantum Science and Technology 8 3, 035027 (2023) .
[13] Aditya Dubey, Zeki Zeybek, and Peter Schmelcher, "Simulating quantum circuits with tree tensor networks using density-matrix renormalization group algorithm", Physical Review B 112 10, 104312 (2025) .
[14] Feng Pan, Hanfeng Gu, Lvlin Kuang, Bing Liu, and Pan Zhang, "Efficient Quantum Circuit Simulation by Tensor Network Methods on Modern GPUs", ACM Transactions on Quantum Computing 5 4, 1 (2024) .
[15] Joseph Tindall and Matthew Fishman, "Gauging tensor networks with belief propagation", SciPost Physics 15 6, 222 (2023) .
[16] Hiryuki Ootomo, Hidetaka Manabe, Kenji Harada, and Rio Yokota, Lecture Notes in Computer Science 13948, 259 (2023) ISBN:978-3-031-32040-8 .
[17] He-Liang Huang, Youwei Zhao, and Chu Guo, "How to Design a Classically Difficult Random Quantum Circuit for Quantum Computational Advantage Experiments", Intelligent Computing 3, 0079 (2024) .
[18] Marcos Díez García and Antonio Márquez Romero, "Survey on Computational Applications of Tensor-Network Simulations", IEEE Access 12, 193212 (2024) .
[19] Yong Liu, Yaojian Chen, Chu Guo, Jiawei Song, Xinmin Shi, Lin Gan, Wenzhao Wu, Wei Wu, Haohuan Fu, Xin Liu, Dexun Chen, Zhifeng Zhao, Guangwen Yang, and Jiangang Gao, "Verifying Quantum Advantage Experiments with Multiple Amplitude Tensor Network Contraction", Physical Review Letters 132 3, 030601 (2024) .
[20] Eleanor G. Rieffel, Ata Akbari Asanjan, M. Sohaib Alam, Namit Anand, David E. Bernal Neira, Sophie Block, Lucas T. Brady, Steve Cotton, Zoe Gonzalez Izquierdo, Shon Grabbe, Erik Gustafson, Stuart Hadfield, P. Aaron Lott, Filip B. Maciejewski, Salvatore Mandrà, Jeffrey Marshall, Gianni Mossi, Humberto Munoz Bauza, Jason Saied, Nishchay Suri, Davide Venturelli, Zhihui Wang, and Rupak Biswas, "Assessing and advancing the potential of quantum computing: A NASA case study", Future Generation Computer Systems 160, 598 (2024) .
[21] Sebastian Schlag, Tobias Heuer, Lars Gottesbüren, Yaroslav Akhremtsev, Christian Schulz, and Peter Sanders, "High-Quality Hypergraph Partitioning", ACM Journal of Experimental Algorithmics 27, 1 (2022) .
[22] Sachin Kasture, Oleksandr Kyriienko, and Vincent E. Elfving, "Protocols for classically training quantum generative models on probability distributions", Physical Review A 108 4, 042406 (2023) .
[23] Moritz Cygorek, Jonathan Keeling, Brendon W. Lovett, and Erik M. Gauger, "Sublinear Scaling in Non-Markovian Open Quantum Systems Simulations", Physical Review X 14 1, 011010 (2024) .
[24] Christian Bøgh Larsen, Simon Brun Olsen, Kim Guldstrand Larsen, and Christian Schilling, "Contraction Heuristics for Tensor Decision Diagrams", Entropy 26 12, 1058 (2024) .
[25] Wei-You Liao, Xiang Wang, Xiao-Yue Xu, Chen Ding, Shuo Zhang, He-Liang Huang, and Chu Guo, "JuliVQC.jl: an efficient variational quantum circuit simulator for near-term quantum algorithms", The European Physical Journal Special Topics 234 20, 6223 (2025) .
[26] Jin Lee, Zheng Zhang, Sofía González-García, and Haewon Jeong, 2024 IEEE International Symposium on Information Theory (ISIT) 3095 (2024) ISBN:979-8-3503-8284-6 .
[27] Laura S. Herzog, Lukas Burgholzer, Christian Ufrecht, Daniel D. Scherer, and Robert Wille, 2025 62nd ACM/IEEE Design Automation Conference (DAC) 1 (2025) ISBN:979-8-3315-0304-8 .
[28] Hidetaka Manabe, Yasunari Suzuki, and Andrew S Darmawan, "Efficient simulation of leakage errors in quantum error correcting codes using tensor network methods", New Journal of Physics 27 11, 114512 (2025) .
[29] Adil A. Gangat, "Linear-time classical approximate optimization of cubic-lattice classical spin glasses", Physical Review Applied 25 2, 024003 (2026) .
[30] Justin Provazza, Klaas Gunst, Huanchen Zhai, Garnet K.-L. Chan, Toru Shiozaki, Nicholas C. Rubin, and Alec F. White, "Fast Emulation of Fermionic Circuits with Matrix Product States", Journal of Chemical Theory and Computation 20 9, 3719 (2024) .
[31] Danylo Lykov, Jonathan Wurtz, Cody Poole, Mark Saffman, Tom Noel, and Yuri Alexeev, "Sampling frequency thresholds for the quantum advantage of the quantum approximate optimization algorithm", npj Quantum Information 9 1, 73 (2023) .
[32] Rong Fu, Zhongling Su, Han-Sen Zhong, Xiti Zhao, Jianyang Zhang, Feng Pan, Pan Zhang, Xianhe Zhao, Ming-Cheng Chen, Chao-Yang Lu, Jian-Wei Pan, Zhilin Pei, Xingcheng Zhang, and Wanli Ouyang, SC24: International Conference for High Performance Computing, Networking, Storage and Analysis 1 (2024) ISBN:979-8-3503-5291-7 .
[33] Dorit Aharonov, Xun Gao, Zeph Landau, Yunchao Liu, and Umesh Vazirani, Proceedings of the 55th Annual ACM Symposium on Theory of Computing 945 (2023) ISBN:9781450399135 .
[34] Jeffrey Marshall and Namit Anand, "Simulation of quantum optics by coherent state decomposition", Optica Quantum 1 2, 78 (2023) .
[35] Yang Gao, Huanchen Zhai, Johnnie Gray, Ruojing Peng, Gunhee Park, Wen-Yuan Liu, Eirik F. Kjønstad, and Garnet Kin-Lic Chan, "Fermionic tensor network contraction for arbitrary geometries", Physical Review Research 7 2, 023193 (2025) .
[36] Aaron Sander, Lukas Burgholzer, and Robert Wille, "Equivalence checking of quantum circuits via intermediary matrix product operator", Physical Review Research 7 2, 023261 (2025) .
[37] I-Chi Chen, João C. Getelina, Klée Pollock, Aleksei Khindanov, Srimoyee Sen, Yong-Xin Yao, and Thomas Iadecola, "Classical and quantum simulations of 1+1-dimensional Z 2 Z 2 gauge theory at finite temperature and density", Communications Physics 8 1, 375 (2025) .
[38] Glen Evenbly, "A Practical Guide to the Numerical Implementation of Tensor Networks I: Contractions, Decompositions, and Gauge Freedom", Frontiers in Applied Mathematics and Statistics 8, 806549 (2022) .
[39] Mekena Metcalf, Pablo Andrés-Martínez, and Nathan Fitzpatrick, SC24: International Conference for High Performance Computing, Networking, Storage and Analysis 1 (2024) ISBN:979-8-3503-5291-7 .
[40] Xiao Mi, Pedram Roushan, Chris Quintana, Salvatore Mandrà, Jeffrey Marshall, Charles Neill, Frank Arute, Kunal Arya, Juan Atalaya, Ryan Babbush, Joseph C. Bardin, Rami Barends, Joao Basso, Andreas Bengtsson, Sergio Boixo, Alexandre Bourassa, Michael Broughton, Bob B. Buckley, David A. Buell, Brian Burkett, Nicholas Bushnell, Zijun Chen, Benjamin Chiaro, Roberto Collins, William Courtney, Sean Demura, Alan R. Derk, Andrew Dunsworth, Daniel Eppens, Catherine Erickson, Edward Farhi, Austin G. Fowler, Brooks Foxen, Craig Gidney, Marissa Giustina, Jonathan A. Gross, Matthew P. Harrigan, Sean D. Harrington, Jeremy Hilton, Alan Ho, Sabrina Hong, Trent Huang, William J. Huggins, L. B. Ioffe, Sergei V. Isakov, Evan Jeffrey, Zhang Jiang, Cody Jones, Dvir Kafri, Julian Kelly, Seon Kim, Alexei Kitaev, Paul V. Klimov, Alexander N. Korotkov, Fedor Kostritsa, David Landhuis, Pavel Laptev, Erik Lucero, Orion Martin, Jarrod R. McClean, Trevor McCourt, Matt McEwen, Anthony Megrant, Kevin C. Miao, Masoud Mohseni, Shirin Montazeri, Wojciech Mruczkiewicz, Josh Mutus, Ofer Naaman, Matthew Neeley, Michael Newman, Murphy Yuezhen Niu, Thomas E. O’Brien, Alex Opremcak, Eric Ostby, Balint Pato, Andre Petukhov, Nicholas Redd, Nicholas C. Rubin, Daniel Sank, Kevin J. Satzinger, Vladimir Shvarts, Doug Strain, Marco Szalay, Matthew D. Trevithick, Benjamin Villalonga, Theodore White, Z. Jamie Yao, Ping Yeh, Adam Zalcman, Hartmut Neven, Igor Aleiner, Kostyantyn Kechedzhi, Vadim Smelyanskiy, and Yu Chen, "Information scrambling in quantum circuits", Science 374 6574, 1479 (2021) .
[41] Han-Sen Zhong, Yu-Hao Deng, Jian Qin, Hui Wang, Ming-Cheng Chen, Li-Chao Peng, Yi-Han Luo, Dian Wu, Si-Qiu Gong, Hao Su, Yi Hu, Peng Hu, Xiao-Yan Yang, Wei-Jun Zhang, Hao Li, Yuxuan Li, Xiao Jiang, Lin Gan, Guangwen Yang, Lixing You, Zhen Wang, Li Li, Nai-Le Liu, Jelmer J. Renema, Chao-Yang Lu, and Jian-Wei Pan, "Phase-Programmable Gaussian Boson Sampling Using Stimulated Squeezed Light", Physical Review Letters 127 18, 180502 (2021) .
[42] Linjian Ma, Matthew Fishman, Edwin Miles Stoudenmire, and Edgar Solomonik, "Approximate Contraction of Arbitrary Tensor Networks with a Flexible and Efficient Density Matrix Algorithm", Quantum 8, 1580 (2024) .
[43] Yaojian Chen, Yong Liu, Xinmin Shi, Jiawei Song, Xin Liu, Lin Gan, Chu Guo, Haohuan Fu, Jie Gao, Dexun Chen, and Guangwen Yang, Proceedings of the 28th ACM SIGPLAN Annual Symposium on Principles and Practice of Parallel Programming 148 (2023) ISBN:9798400700156 .
[44] Martin Roa-Villescas, Xuanzhao Gao, Sander Stuijk, Henk Corporaal, and Jin-Guo Liu, "Probabilistic inference in the era of tensor networks and differential programming", Physical Review Research 6 3, 033261 (2024) .
[45] Adhitha Dias, Logan Anderson, Kirshanthan Sundararajah, Artem Pelenitsyn, and Milind Kulkarni, "SparseAuto: An Auto-scheduler for Sparse Tensor Computations using Recursive Loop Nest Restructuring", Proceedings of the ACM on Programming Languages 8 OOPSLA2, 527 (2024) .
[46] Valter Uotila, 2024 IEEE International Conference on Quantum Computing and Engineering (QCE) 390 (2024) ISBN:979-8-3315-4137-8 .
[47] Seunghwan Kim, Changjong Kim, Alex Sim, Kesheng Wu, Houjun Tang, and Sunggon Kim, 2025 IEEE 25th International Symposium on Cluster, Cloud and Internet Computing (CCGrid) 142 (2025) ISBN:979-8-3315-0934-7 .
[48] Jonathan Wurtz and Danylo Lykov, "Fixed-angle conjectures for the quantum approximate optimization algorithm on regular MaxCut graphs", Physical Review A 104 5, 052419 (2021) .
[49] Dominik Hangleiter and Jens Eisert, "Computational advantage of quantum random sampling", Reviews of Modern Physics 95 3, 035001 (2023) .
[50] Junjie Wu and Yong Liu, "Benchmarking Quantum Computational Advantages on Supercomputers", Advanced Quantum Technologies 7 11, 2400143 (2024) .
[51] Hiroshi Yamauchi, Tomah Sogabe, and Rodney van Meter, 2024 IEEE International Conference on Quantum Computing and Engineering (QCE) 1404 (2024) ISBN:979-8-3315-4137-8 .
[52] Reza Haghshenas, Johnnie Gray, Andrew C. Potter, and Garnet Kin-Lic Chan, "Variational Power of Quantum Circuit Tensor Networks", Physical Review X 12 1, 011047 (2022) .
[53] Ruojing Peng, Johnnie Gray, and Garnet Kin-Lic Chan, "Arithmetic circuit tensor networks, multivariable function representation, and high-dimensional integration", Physical Review Research 5 1, 013156 (2023) .
[54] Martin Roa-Villescas and Jin-Guo Liu, "TensorInference: A Julia package for tensor-based probabilistic inference", Journal of Open Source Software 8 90, 5700 (2023) .
[55] Qirui Zhang, Mehdi Saligane, Hun-Seok Kim, David Blaauw, Georgios Tzimpragos, and Dennis Sylvester, 2024 25th International Symposium on Quality Electronic Design (ISQED) 1 (2024) ISBN:979-8-3503-0927-0 .
[56] Mengyao Hu and Jordi Tura, "Tropical Contraction of Tensor Networks as a Bell Inequality Optimization Toolset", Physical Review Letters 136 10, 100202 (2026) .
[57] Reza Haghshenas, "Optimization schemes for unitary tensor-network circuit", Physical Review Research 3 2, 023148 (2021) .
[58] Danylo Lykov, Ruslan Shaydulin, Yue Sun, Yuri Alexeev, and Marco Pistoia, Proceedings of the SC '23 Workshops of the International Conference on High Performance Computing, Network, Storage, and Analysis 1443 (2023) ISBN:9798400707858 .
[59] Sergio Sanchez-Ramirez, Javier Conejero, Francesc Lordan, Anna Queralt, Toni Cortes, Rosa M Badia, and Artur Garcia-Saez, 2021 IEEE/ACM Second International Workshop on Quantum Computing Software (QCS) 1 (2021) ISBN:978-1-7281-8674-0 .
[60] Alexander Zlokapa, Benjamin Villalonga, Sergio Boixo, and Daniel A. Lidar, "Boundaries of quantum supremacy via random circuit sampling", npj Quantum Information 9 1, 36 (2023) .
[61] Shi-Xin Zhang, Jonathan Allcock, Zhou-Quan Wan, Shuo Liu, Jiace Sun, Hao Yu, Xing-Han Yang, Jiezhong Qiu, Zhaofeng Ye, Yu-Qin Chen, Chee-Kong Lee, Yi-Cong Zheng, Shao-Kai Jian, Hong Yao, Chang-Yu Hsieh, and Shengyu Zhang, "TensorCircuit: a Quantum Software Framework for the NISQ Era", Quantum 7, 912 (2023) .
[62] Aleksandr Berezutskii, Minzhao Liu, Atithi Acharya, Roman Ellerbrock, Johnnie Gray, Reza Haghshenas, Zichang He, Abid Khan, Viacheslav Kuzmin, Dmitry Lyakh, Danylo Lykov, Salvatore Mandrà, Christopher Mansell, Alexey Melnikov, Artem Melnikov, Vladimir Mironov, Dmitry Morozov, Florian Neukart, Alberto Nocera, Michael A. Perlin, Michael Perelshtein, Matthew Steinberg, Ruslan Shaydulin, Benjamin Villalonga, Markus Pflitsch, Marco Pistoia, Valerii Vinokur, and Yuri Alexeev, "Tensor networks for quantum computing", Nature Reviews Physics 7 10, 581 (2025) .
[63] Angus Lowe, Matija Medvidović, Anthony Hayes, Lee J. O&apos;Riordan, Thomas R. Bromley, Juan Miguel Arrazola, and Nathan Killoran, "Fast quantum circuit cutting with randomized measurements", Quantum 7, 934 (2023) .
[64] Meng Zhang, Chao Wang, Shaojun Dong, Hao Zhang, Yongjian Han, and Lixin He, "Entanglement entropy scaling of noisy random quantum circuits in two dimensions", Physical Review A 106 5, 052430 (2022) .
[65] Atte Torri, Przemysław Dominikowski, Brice Pointal, Oguz Kaya, Laércio Lima Pilla, and Olivier Coulaud, Lecture Notes in Computer Science 15902, 63 (2026) ISBN:978-3-031-99871-3 .
[66] Wei Xu, Weiqin Tong, and Xiaoyang Liu, 2024 4th International Conference on Neural Networks, Information and Communication (NNICE) 133 (2024) ISBN:979-8-3503-9437-5 .
[67] Hao Tang, José Leonardo Simancas-García, Jianming Mai, Minghao Cheng, Imran Iqbal, and Lip Yee Por, "Overview of Digital Quantum Simulator: Applications and Comparison with Latest Methods", SPIN 15 02, 2440004 (2025) .
[68] Benjamin Lanthier, Jeremy Côté, and Stefanos Kourtis, "Tensor networks for p-spin models", Frontiers in Physics 12, 1431810 (2024) .
[69] Ying Li, Ze-Yao Han, Chao-Jian Li, Jin Lü, Xiao Yuan, and Bu-Jiao Wu, "Review on quantum advantages of sampling problems", Acta Physica Sinica 70 21, 210201 (2021) .
[70] Ke Chen, Mingzheng Zhu, Haishan Song, Wei Xie, and Xiang-Yang Li, "Hypergraph-based approximate maximum likelihood decoding for quantum codes under circuit-level noise", Physical Review Research 8 2, 023191 (2026) .
[71] Hao-Kai Zhang, Shuo Liu, and Shi-Xin Zhang, "Absence of Barren Plateaus in Finite Local-Depth Circuits with Long-Range Entanglement", Physical Review Letters 132 15, 150603 (2024) .
[72] Mari Carmen Bañuls, "Tensor Network Algorithms: A Route Map", Annual Review of Condensed Matter Physics 14 1, 173 (2023) .
[73] Ed Younis, 2026 IEEE/ACM International Symposium on Code Generation and Optimization (CGO) 295 (2026) ISBN:979-8-3315-9288-2 .
[74] Lesley Gover, Vinul Wimalaweera, Fariha Azad, Matthew DeCross, Michael Foss-Feig, and Andrew G. Green, "Fully optimised variational simulation of a dynamical quantum phase transition on a trapped-ion quantum computer", Quantum 10, 2109 (2026) .
[75] Manuel S Rudolph, Jing Chen, Jacob Miller, Atithi Acharya, and Alejandro Perdomo-Ortiz, "Decomposition of matrix product states into shallow quantum circuits", Quantum Science and Technology 9 1, 015012 (2024) .
[76] Zewen Zhang, Roger Paredes, Bhuvanesh Sundar, David Quiroga, Anastasios Kyrillidis, Leonardo Duenas-Osorio, Guido Pagano, and Kaden R A Hazzard, "Grover-QAOA for 3-SAT: quadratic speedup, fair-sampling, and parameter clustering", Quantum Science and Technology 10 1, 015022 (2025) .
[77] Vicente Lopez-Oliva, Jose M. Badia, and Maribel Castillo, "Efficient quantum circuit contraction using tensor decision diagrams", The Journal of Supercomputing 81 1, 354 (2025) .
[78] Chris N. Self, Sofyan Iblisdir, Gavin K. Brennen, and Konstantinos Meichanetzidis, "Estimating the Jones polynomial for Ising anyons on noisy quantum computers", Physical Review Research 8 2, 023168 (2026) .
[79] Nicholas H. Stair and Francesco A. Evangelista, "QForte: An Efficient State-Vector Emulator and Quantum Algorithms Library for Molecular Electronic Structure", Journal of Chemical Theory and Computation 18 3, 1555 (2022) .
[80] Chongxiao Zhao, Chenyang Li, and Wenjie Dou, "Stochastic resolution of identity to CC2 for large systems: Excited-state gradients and derivative couplings", The Journal of Chemical Physics 163 23, 234101 (2025) .
[81] M. R. Perelshtein, A. I. Pakhomchik, Ar. A. Melnikov, M. Podobrii, A. Termanova, I. Kreidich, B. Nuriev, S. Iudin, C. W. Mansell, and V. M. Vinokur, "NISQ-compatible approximate quantum algorithm for unconstrained and constrained discrete optimization", Quantum 7, 1186 (2023) .
[82] Arne Wulff, Boyang Chen, Matthew Steinberg, Yinglu Tang, Matthias Möller, and Sebastian Feld, "Quantum computing and tensor networks for laminate design: A novel approach to stacking sequence retrieval", Computer Methods in Applied Mechanics and Engineering 432, 117380 (2024) .
[83] Andrea De Girolamo, Paolo Facchi, Peter Rabl, Saverio Pascazio, Cosmo Lupo, and Giuseppe Magnifico, "Dynamical cluster-based strategy for improving tensor network algorithms in quantum circuit simulations", Physical Review Research 7 4, 043170 (2025) .
[84] Etienne Granet, Kévin Hémery, and Henrik Dreyer, "Analog simulation of noisy quantum circuits", Physical Review Research 7 1, 013213 (2025) .
[85] Anna Leonteva, Guido Masella, Maxime Outteryck, Asier Peiro Orioli, and Shannon Whitlock, "Comparative Benchmarking of Utility-Scale Quantum Emulators", ACM Transactions on Quantum Computing 7 2, 1 (2026) .
[86] Fang Li, Xin Liu, Yong Liu, Pengpeng Zhao, Yuling Yang, Honghui Shang, Weizhe Sun, Zhen Wang, Enming Dong, and Dexun Chen, Proceedings of the International Conference for High Performance Computing, Networking, Storage and Analysis 1 (2021) ISBN:9781450384421 .
[87] Meng Zhang, Chao Wang, and Yongjian Han, "Noisy Random Quantum Circuit Sampling and its Classical Simulation", Advanced Quantum Technologies 6 7, 2300030 (2023) .
[88] Trevor Vincent, Lee J. O&apos;Riordan, Mikhail Andrenkov, Jack Brown, Nathan Killoran, Haoyu Qi, and Ish Dhand, "Jet: Fast quantum circuit simulations with parallel task-based tensor-network contraction", Quantum 6, 709 (2022) .
[89] Michael Foss-Feig, Guido Pagano, Andrew C. Potter, and Norman Y. Yao, "Progress in Trapped-Ion Quantum Simulation", Annual Review of Condensed Matter Physics 16 1, 145 (2025) .
[90] Julien Drapeau, Shreya Banerjee, and Stefanos Kourtis, "Counting with the quantum alternating operator ansatz", Quantum Science and Technology 11 2, 025037 (2026) .
[91] Philipp Seitz, Ismael Medina, Esther Cruz, Qunsheng Huang, and Christian B. Mendl, "Simulating quantum circuits using tree tensor networks", Quantum 7, 964 (2023) .
[92] Aaron C. Hoyt, Jonathan S. Bersson, Sean Garner, Chenxu Liu, and Ang Li, 2025 IEEE High Performance Extreme Computing Conference (HPEC) 1 (2025) ISBN:979-8-3315-7844-2 .
[93] Salvatore Mandra, Jeffrey Marshall, Eleanor G. Rieffel, and Rupak Biswas, 2021 IEEE/ACM Second International Workshop on Quantum Computing Software (QCS) 99 (2021) ISBN:978-1-7281-8674-0 .
[94] Harun Bayraktar, Ali Charara, David Clark, Saul Cohen, Timothy Costa, Yao-Lung L. Fang, Yang Gao, Jack Guan, John Gunnels, Azzam Haidar, Andreas Hehn, Markus Hohnerbach, Matthew Jones, Tom Lubowe, Dmitry Lyakh, Shinya Morino, Paul Springer, Sam Stanwyck, Igor Terentyev, Satya Varadhan, Jonathan Wong, and Takuma Yamaguchi, 2023 IEEE International Conference on Quantum Computing and Engineering (QCE) 1050 (2023) ISBN:979-8-3503-4323-6 .
[95] Sergey Bravyi, David Gosset, and Yinchen Liu, "How to Simulate Quantum Measurement without Computing Marginals", Physical Review Letters 128 22, 220503 (2022) .
[96] Ying Liu, Boning Meng, and Juqiu Wang, "Exponential time complexity for contracting tensor networks", The Computer Journal 69 4, 613 (2026) .
[97] Jiale Huang, Xiangjian Qian, and Mingpu Qin, "Nonstabilizerness entanglement entropy: A measure of hardness in the classical simulation of quantum many-body systems with tensor network states", Physical Review A 112 1, 012425 (2025) .
[98] Tuomas Laakkonen, Konstantinos Meichanetzidis, and John van de Wetering, "Picturing Counting Reductions with the ZH-Calculus", Electronic Proceedings in Theoretical Computer Science 384, 89 (2023) .
[99] Thorsten B. Wahl and Sergii Strelchuk, "Simulating Quantum Circuits Using Efficient Tensor Network Contraction Algorithms with Subexponential Upper Bound", Physical Review Letters 131 18, 180601 (2023) .
[100] Muhammad AbuGhanem and Hichem Eleuch, "NISQ Computers: A Path to Quantum Supremacy", IEEE Access 12, 102941 (2024) .
[101] Ramis Movassagh, "The hardness of random quantum circuits", Nature Physics 19 11, 1719 (2023) .
[102] Willow Ahrens, Fredrik Kjolstad, and Saman Amarasinghe, Proceedings of the 43rd ACM SIGPLAN International Conference on Programming Language Design and Implementation 269 (2022) ISBN:9781450392655 .
[103] Tomislav Begušić, Johnnie Gray, and Garnet Kin-Lic Chan, "Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance", Science Advances 10 3, eadk4321 (2024) .
[104] Thomas Barthel and Qiang Miao, "Scaling of contraction costs for entanglement renormalization algorithms including tensor Trotterization and variational Monte Carlo", Physical Review B 111 4, 045104 (2025) .
[105] Thien Nguyen, Dmitry Lyakh, Eugene Dumitrescu, David Clark, Jeff Larkin, and Alexander McCaskey, "Tensor Network Quantum Virtual Machine for Simulating Quantum Circuits at Exascale", ACM Transactions on Quantum Computing 4 1, 1 (2023) .
[106] Alistair W R Smith, A J Paige, and M S Kim, "Faster variational quantum algorithms with quantum kernel-based surrogate models", Quantum Science and Technology 8 4, 045016 (2023) .
[107] Jordi Tura, "Boosting simulation of quantum computers", Nature Computational Science 1 10, 638 (2021) .
[108] Johnnie Gray and Garnet Kin-Lic Chan, "Hyperoptimized Approximate Contraction of Tensor Networks with Arbitrary Geometry", Physical Review X 14 1, 011009 (2024) .
[109] Jing Liu, Ying Tang, and Pan Zhang, "Efficient optimization of variational autoregressive networks with natural gradient", Physical Review E 111 2, 025304 (2025) .
[110] Hristo Venev, Thien Udomsrirungruang, Dimitar Dimitrov, Timon Gehr, and Martin Vechev, "qblaze: An Efficient and Scalable Sparse Quantum Simulator", Proceedings of the ACM on Programming Languages 9 OOPSLA2, 444 (2025) .
[111] Yonglong Ding, "Exploring the nexus between thermodynamic phase transitions and geometric fractals through systematic lattice point classification", AIP Advances 14 8, 085107 (2024) .
[112] Daiwei Zhu, Gregory D. Kahanamoku-Meyer, Laura Lewis, Crystal Noel, Or Katz, Bahaa Harraz, Qingfeng Wang, Andrew Risinger, Lei Feng, Debopriyo Biswas, Laird Egan, Alexandru Gheorghiu, Yunseong Nam, Thomas Vidick, Umesh Vazirani, Norman Y. Yao, Marko Cetina, and Christopher Monroe, "Interactive cryptographic proofs of quantumness using mid-circuit measurements", Nature Physics 19 11, 1725 (2023) .
[113] Lukas Burgholzer and Robert Wille, Design Automation Tools and Software for Quantum Computing 67 (2026) ISBN:978-3-032-06769-2 .
[114] Andrea D’Urbano, Mario Angelelli, and Christian Catalano, Lecture Notes in Computer Science 14484, 60 (2024) ISBN:978-3-031-49268-6 .
[115] Cameron Ibrahim, Danylo Lykov, Zichang He, Yuri Alexeev, and Ilya Safro, 2022 IEEE High Performance Extreme Computing Conference (HPEC) 1 (2022) ISBN:978-1-6654-9786-2 .
[116] Zhenlin Wu, Haosong Zhao, Hongyuan Liu, Wujie Wen, and Jiajia Li, "gHyPart: GPU-friendly End-to-End Hypergraph Partitioner", ACM Transactions on Architecture and Code Optimization 22 1, 1 (2025) .
[117] Yusuke Kimura, Shaowen Li, Hiroyuki Sato, Masahiro Fujita, and Robert Wille, "Improving Decision Diagram-Based Quantum Circuit Simulation Using Static Variable Ordering and Multinode Ring Communication", IEEE Transactions on Quantum Engineering 7, 1 (2026) .
[118] Tomislav Begušić and Garnet Kin-Lic Chan, "Real-Time Operator Evolution in Two and Three Dimensions via Sparse Pauli Dynamics", PRX Quantum 6 2, 020302 (2025) .
[119] Alessio Cicero, Mohammad Ali Maleki, Muhammad Waqar Azhar, Anton Frisk Kockum, and Pedro Trancoso, "Simulation of Quantum Computers: Review and Acceleration Opportunities", ACM Transactions on Quantum Computing 7 1, 1 (2026) .
[120] Robert Cimrman, "Fast evaluation of finite element weak forms using python tensor contraction packages", Advances in Engineering Software 159, 103033 (2021) .
[121] Qingling Zhu, Sirui Cao, Fusheng Chen, Ming-Cheng Chen, Xiawei Chen, Tung-Hsun Chung, Hui Deng, Yajie Du, Daojin Fan, Ming Gong, Cheng Guo, Chu Guo, Shaojun Guo, Lianchen Han, Linyin Hong, He-Liang Huang, Yong-Heng Huo, Liping Li, Na Li, Shaowei Li, Yuan Li, Futian Liang, Chun Lin, Jin Lin, Haoran Qian, Dan Qiao, Hao Rong, Hong Su, Lihua Sun, Liangyuan Wang, Shiyu Wang, Dachao Wu, Yulin Wu, Yu Xu, Kai Yan, Weifeng Yang, Yang Yang, Yangsen Ye, Jianghan Yin, Chong Ying, Jiale Yu, Chen Zha, Cha Zhang, Haibin Zhang, Kaili Zhang, Yiming Zhang, Han Zhao, Youwei Zhao, Liang Zhou, Chao-Yang Lu, Cheng-Zhi Peng, Xiaobo Zhu, and Jian-Wei Pan, "Quantum computational advantage via 60-qubit 24-cycle random circuit sampling", Science Bulletin 67 3, 240 (2022) .
[122] Yong (Alexander) Liu, Xin (Lucy) Liu, Fang (Nancy) Li, Haohuan Fu, Yuling Yang, Jiawei Song, Pengpeng Zhao, Zhen Wang, Dajia Peng, Huarong Chen, Chu Guo, Heliang Huang, Wenzhao Wu, and Dexun Chen, Proceedings of the International Conference for High Performance Computing, Networking, Storage and Analysis 1 (2021) ISBN:9781450384421 .
[123] Joseph Tindall, Antonio Francesco Mello, Matthew Fishman, E. Miles Stoudenmire, and Dries Sels, "Dynamics of disordered quantum systems with two- and three-dimensional tensor networks", Science 392 6800, 868 (2026) .
[124] Feng Pan and Pan Zhang, "Simulation of Quantum Circuits Using the Big-Batch Tensor Network Method", Physical Review Letters 128 3, 030501 (2022) .
[125] E. M. Stoudenmire and Xavier Waintal, "Opening the Black Box inside Grover’s Algorithm", Physical Review X 14 4, 041029 (2024) .
[126] Rafael Ballester-Ripoll and Manuele Leonelli, "Global sensitivity analysis of uncertain parameters in Bayesian networks", International Journal of Approximate Reasoning 180, 109368 (2025) .
[127] Thomas Ayral, "Classical and quantum algorithms for many-body problems", Comptes Rendus. Physique 26 G1, 25 (2025) .
[128] A. Morvan, B. Villalonga, X. Mi, S. Mandrà, A. Bengtsson, P. V. Klimov, Z. Chen, S. Hong, C. Erickson, I. K. Drozdov, J. Chau, G. Laun, R. Movassagh, A. Asfaw, L. T. A. N. Brandão, R. Peralta, D. Abanin, R. Acharya, R. Allen, T. I. Andersen, K. Anderson, M. Ansmann, F. Arute, K. Arya, J. Atalaya, J. C. Bardin, A. Bilmes, G. Bortoli, A. Bourassa, J. Bovaird, L. Brill, M. Broughton, B. B. Buckley, D. A. Buell, T. Burger, B. Burkett, N. Bushnell, J. Campero, H.-S. Chang, B. Chiaro, D. Chik, C. Chou, J. Cogan, R. Collins, P. Conner, W. Courtney, A. L. Crook, B. Curtin, D. M. Debroy, A. Del Toro Barba, S. Demura, A. Di Paolo, A. Dunsworth, L. Faoro, E. Farhi, R. Fatemi, V. S. Ferreira, L. Flores Burgos, E. Forati, A. G. Fowler, B. Foxen, G. Garcia, É. Genois, W. Giang, C. Gidney, D. Gilboa, M. Giustina, R. Gosula, A. Grajales Dau, J. A. Gross, S. Habegger, M. C. Hamilton, M. Hansen, M. P. Harrigan, S. D. Harrington, P. Heu, M. R. Hoffmann, T. Huang, A. Huff, W. J. Huggins, L. B. Ioffe, S. V. Isakov, J. Iveland, E. Jeffrey, Z. Jiang, C. Jones, P. Juhas, D. Kafri, T. Khattar, M. Khezri, M. Kieferová, S. Kim, A. Kitaev, A. R. Klots, A. N. Korotkov, F. Kostritsa, J. M. Kreikebaum, D. Landhuis, P. Laptev, K.-M. Lau, L. Laws, J. Lee, K. W. Lee, Y. D. Lensky, B. J. Lester, A. T. Lill, W. Liu, W. P. Livingston, A. Locharla, F. D. Malone, O. Martin, S. Martin, J. R. McClean, M. McEwen, K. C. Miao, A. Mieszala, S. Montazeri, W. Mruczkiewicz, O. Naaman, M. Neeley, C. Neill, A. Nersisyan, M. Newman, J. H. Ng, A. Nguyen, M. Nguyen, M. Yuezhen Niu, T. E. O’Brien, S. Omonije, A. Opremcak, A. Petukhov, R. Potter, L. P. Pryadko, C. Quintana, D. M. Rhodes, C. Rocque, E. Rosenberg, N. C. Rubin, N. Saei, D. Sank, K. Sankaragomathi, K. J. Satzinger, H. F. Schurkus, C. Schuster, M. J. Shearn, A. Shorter, N. Shutty, V. Shvarts, V. Sivak, J. Skruzny, W. C. Smith, R. D. Somma, G. Sterling, D. Strain, M. Szalay, D. Thor, A. Torres, G. Vidal, C. Vollgraff Heidweiller, T. White, B. W. K. Woo, C. Xing, Z. J. Yao, P. Yeh, J. Yoo, G. Young, A. Zalcman, Y. Zhang, N. Zhu, N. Zobrist, E. G. Rieffel, R. Biswas, R. Babbush, D. Bacon, J. Hilton, E. Lucero, H. Neven, A. Megrant, J. Kelly, P. Roushan, I. Aleiner, V. Smelyanskiy, K. Kechedzhi, Y. Chen, and S. Boixo, "Phase transitions in random circuit sampling", Nature 634 8033, 328 (2024) .
[129] Costantino Carugno, Jake Muff, Mikael P. Johansson, Sven Karlsson, and Alberto Lanzanova, Communications in Computer and Information Science 2398, 113 (2025) ISBN:978-3-031-86239-7 .
[130] José Ramón Pareja Monturiol, David Pérez-García, and Alejandro Pozas-Kerstjens, "TensorKrowch: Smooth integration of tensor networks in machine learning", Quantum 8, 1364 (2024) .
[131] Yulin Wu, Wan-Su Bao, Sirui Cao, Fusheng Chen, Ming-Cheng Chen, Xiawei Chen, Tung-Hsun Chung, Hui Deng, Yajie Du, Daojin Fan, Ming Gong, Cheng Guo, Chu Guo, Shaojun Guo, Lianchen Han, Linyin Hong, He-Liang Huang, Yong-Heng Huo, Liping Li, Na Li, Shaowei Li, Yuan Li, Futian Liang, Chun Lin, Jin Lin, Haoran Qian, Dan Qiao, Hao Rong, Hong Su, Lihua Sun, Liangyuan Wang, Shiyu Wang, Dachao Wu, Yu Xu, Kai Yan, Weifeng Yang, Yang Yang, Yangsen Ye, Jianghan Yin, Chong Ying, Jiale Yu, Chen Zha, Cha Zhang, Haibin Zhang, Kaili Zhang, Yiming Zhang, Han Zhao, Youwei Zhao, Liang Zhou, Qingling Zhu, Chao-Yang Lu, Cheng-Zhi Peng, Xiaobo Zhu, and Jian-Wei Pan, "Strong Quantum Computational Advantage Using a Superconducting Quantum Processor", Physical Review Letters 127 18, 180501 (2021) .
[132] Matthew Fishman, Steven White, and Edwin Stoudenmire, "The ITensor Software Library for Tensor Network Calculations", SciPost Physics Codebases 4 (2022) .
[133] Lukas Burgholzer and Robert Wille, Design Automation Tools and Software for Quantum Computing 19 (2026) ISBN:978-3-032-06769-2 .
[134] Lukas Burgholzer, Hartwig Bauer, and Robert Wille, 2021 IEEE International Conference on Quantum Computing and Engineering (QCE) 199 (2021) ISBN:978-1-6654-1691-7 .
[135] He-Liang Huang, Xiao-Yue Xu, Chu Guo, Guojing Tian, Shi-Jie Wei, Xiaoming Sun, Wan-Su Bao, and Gui-Lu Long, "Near-term quantum computing techniques: Variational quantum algorithms, error mitigation, circuit compilation, benchmarking and classical simulation", Science China Physics, Mechanics & Astronomy 66 5, 250302 (2023) .
[136] Marzio Vallero, Paolo Rech, and Flavio Vella, "State of practice: Evaluating GPU performance of state vector and tensor network methods", Future Generation Computer Systems 174, 107927 (2026) .
[137] Akihiro Tabuchi, Satoshi Imamura, Masafumi Yamazaki, Takumi Honda, Akihiko Kasagi, Hiroshi Nakao, Naoto Fukumoto, and Kohta Nakashima, 2023 IEEE International Conference on Quantum Computing and Engineering (QCE) 959 (2023) ISBN:979-8-3503-4323-6 .
[138] Matthias Christandl, Vladimir Lysikov, Vincent Steffan, Albert H. Werner, and Freek Witteveen, "The resource theory of tensor networks", Quantum 8, 1560 (2024) .
[139] Balint Pato, June Vanlerberghe, and Kenneth R. Brown, "Hyper-optimized Quantum Lego Contraction Schedules", Quantum 10, 2092 (2026) .
[140] Sangchul Oh and Sabre Kais, "Comparison of quantum advantage experiments using random circuit sampling", Physical Review A 107 2, 022610 (2023) .
[141] Hanyan Cao, Yijia Wang, Feng Pan, and Pan Zhang, "Integrating neural networks and tensor networks for computing free energy", Communications in Theoretical Physics 77 9, 095602 (2025) .
[142] N. Paraskevopoulos, M. Steinberg, B. Undseth, A. Sarkar, L.M.K. Vandersypen, X. Xue, and S. Feld, "Near-Term Spin-Qubit Architecture Design via Multipartite Maximally Entangled States", PRX Quantum 6 2, 020307 (2025) .
[143] Xiaosi Xu, Simon Benjamin, Jianxin Chen, Jinzhao Sun, Xiao Yuan, and Pan Zhang, "A Herculean task: classical simulation of quantum computers", Science Bulletin 70 23, 4104 (2025) .
[144] Marco Parigi, Mehran Khosrojerdi, Filippo Caruso, and Leonardo Banchi, "Analysis of quantum image representations for supervised classification", AVS Quantum Science 8 1, 013801 (2026) .
[145] Per Sehlstedt, Jan Brandejs, Paolo Bientinesi, and Lars Karlsson, "The software landscape for the density matrix renormalization group", Computer Physics Communications 324, 110136 (2026) .
[146] Ümit Çatalyürek, Karen Devine, Marcelo Faraj, Lars Gottesbüren, Tobias Heuer, Henning Meyerhenke, Peter Sanders, Sebastian Schlag, Christian Schulz, Daniel Seemaier, and Dorothea Wagner, "More Recent Advances in (Hyper)Graph Partitioning", ACM Computing Surveys 55 12, 1 (2023) .
[147] Jernej Rudi Finžgar, Aron Kerschbaumer, Martin J.A. Schuetz, Christian B. Mendl, and Helmut G. Katzgraber, "Quantum-Informed Recursive Optimization Algorithms", PRX Quantum 5 2, 020327 (2024) .
[148] Ryan L. Mann, "Simulating quantum computations with Tutte polynomials", npj Quantum Information 7 1, 141 (2021) .
[149] Yijia Wang, Yuwen Ebony Zhang, Feng Pan, and Pan Zhang, "Tensor Network Message Passing", Physical Review Letters 132 11, 117401 (2024) .
[150] Andor Menczer, Maarten van Damme, Alan Rask, Lee Huntington, Jeff Hammond, Sotiris S. Xantheas, Martin Ganahl, and Örs Legeza, "Parallel Implementation of the Density Matrix Renormalization Group Method Achieving a Quarter petaFLOPS Performance on a Single DGX-H100 GPU Node", Journal of Chemical Theory and Computation 20 19, 8397 (2024) .
[151] Cole Brower, Samuel Rodriguez Bernabeu, Jeff Hammond, John Gunnels, Sotiris S. Xantheas, Martin Ganahl, Andor Menczer, and Örs Legeza, "Mixed-Precision Ab Initio Tensor Network State Methods Adapted for NVIDIA Blackwell Technology via Emulated FP64 Arithmetic", Journal of Chemical Theory and Computation acs.jctc.6c00203 (2026) .
[152] Dian-Teng Chen, Phillip Helms, Ashlyn R. Hale, Minseong Lee, Chenghan Li, Johnnie Gray, George Christou, Vivien S. Zapf, Garnet Kin-Lic Chan, and Hai-Ping Cheng, "Using Hyperoptimized Tensor Networks and First-Principles Electronic Structure to Simulate the Experimental Properties of the Giant {Mn84} Torus", The Journal of Physical Chemistry Letters 13 10, 2365 (2022) .
[153] Anthony M. Smaldone, Yu Shee, Gregory W. Kyro, Chuzhi Xu, Nam P. Vu, Rishab Dutta, Marwa H. Farag, Alexey Galda, Sandeep Kumar, Elica Kyoseva, and Victor S. Batista, "Quantum Machine Learning in Drug Discovery: Applications in Academia and Pharmaceutical Industries", Chemical Reviews 125 12, 5436 (2025) .
[154] Shaowen Li, Yusuke Kimura, Hiroyuki Sato, and Masahiro Fujita, "Parallelizing Quantum Simulation With Decision Diagrams", IEEE Transactions on Quantum Engineering 5, 1 (2024) .
[155] Jesse J. Osborne and Ian P. McCulloch, "Efficient and systematic calculation of arbitrary observables for the matrix product state excitation ansatz", Physical Review Research 7 2, 023018 (2025) .
[156] Dmitry A. Abanin, Rajeev Acharya, Laleh Aghababaie-Beni, Georg Aigeldinger, Ashok Ajoy, Ross Alcaraz, Igor Aleiner, Trond I. Andersen, Markus Ansmann, Frank Arute, Kunal Arya, Abraham Asfaw, Nikita Astrakhantsev, Juan Atalaya, Ryan Babbush, Dave Bacon, Brian Ballard, Joseph C. Bardin, Christian Bengs, Andreas Bengtsson, Alexander Bilmes, Sergio Boixo, Gina Bortoli, Alexandre Bourassa, Jenna Bovaird, Dylan Bowers, Leon Brill, Michael Broughton, David A. Browne, Brett Buchea, Bob B. Buckley, David A. Buell, Tim Burger, Brian Burkett, Nicholas Bushnell, Anthony Cabrera, Juan Campero, Hung-Shen Chang, Yu Chen, Zijun Chen, Ben Chiaro, Liang-Ying Chih, Desmond Chik, Charina Chou, Jahan Claes, Agnetta Y. Cleland, Josh Cogan, Saul Cohen, Roberto Collins, Paul Conner, William Courtney, Alexander L. Crook, Ben Curtin, Sayan Das, Laura De Lorenzo, Dripto M. Debroy, Sean Demura, Michel Devoret, Agustin Di Paolo, Paul Donohoe, Ilya Drozdov, Andrew Dunsworth, Clint Earle, Alec Eickbusch, Aviv Moshe Elbag, Mahmoud Elzouka, Catherine Erickson, Lara Faoro, Edward Farhi, Vinicius S. Ferreira, Leslie Flores Burgos, Ebrahim Forati, Austin G. Fowler, Brooks Foxen, Suhas Ganjam, Gonzalo Garcia, Robert Gasca, Élie Genois, William Giang, Craig Gidney, Dar Gilboa, Raja Gosula, Alejandro Grajales Dau, Dietrich Graumann, Alex Greene, Jonathan A. Gross, Hanfeng Gu, Steve Habegger, John Hall, Ikko Hamamura, Michael C. Hamilton, Monica Hansen, Matthew P. Harrigan, Sean D. Harrington, Stephen Heslin, Paula Heu, Oscar Higgott, Gordon Hill, Jeremy Hilton, Sabrina Hong, Hsin-Yuan Huang, Ashley Huff, William J. Huggins, Lev B. Ioffe, Sergei V. Isakov, Justin Iveland, Evan Jeffrey, Zhang Jiang, Xiaoxuan Jin, Cody Jones, Stephen Jordan, Chaitali Joshi, Pavol Juhas, Andreas Kabel, Dvir Kafri, Hui Kang, Amir H. Karamlou, Kostyantyn Kechedzhi, Julian Kelly, Trupti Khaire, Tanuj Khattar, Mostafa Khezri, Seon Kim, Robbie King, Paul V. Klimov, Andrey R. Klots, Bryce Kobrin, Alexander N. Korotkov, Fedor Kostritsa, Robin Kothari, John Mark Kreikebaum, Vladislav D. Kurilovich, Elica Kyoseva, David Landhuis, Tiano Lange-Dei, Brandon W. Langley, Pavel Laptev, Kim-Ming Lau, Loïck Le Guevel, Justin Ledford, Joonho Lee, Kenny Lee, Yuri D. Lensky, Shannon Leon, Brian J. Lester, Wing Yan Li, Alexander T. Lill, Wayne Liu, William P. Livingston, Aditya Locharla, Erik Lucero, Daniel Lundahl, Aaron Lunt, Sid Madhuk, Fionn D. Malone, Ashley Maloney, Salvatore Mandrà, James M. Manyika, Leigh S. Martin, Orion Martin, Steven Martin, Yossi Matias, Cameron Maxfield, Jarrod R. McClean, Matt McEwen, Seneca Meeks, Anthony Megrant, Xiao Mi, Kevin C. Miao, Amanda Mieszala, Zlatko Minev, Reza Molavi, Sebastian Molina, Shirin Montazeri, Alexis Morvan, Ramis Movassagh, Wojciech Mruczkiewicz, Ofer Naaman, Matthew Neeley, Charles Neill, Ani Nersisyan, Hartmut Neven, Michael Newman, Jiun How Ng, Anthony Nguyen, Murray Nguyen, Chia-Hung Ni, Murphy Yuezhen Niu, Logan Oas, Thomas E. O’Brien, William D. Oliver, Alex Opremcak, Kristoffer Ottosson, Andre Petukhov, Alex Pizzuto, John Platt, Rebecca Potter, Orion Pritchard, Leonid P. Pryadko, Chris Quintana, Ganesh Ramachandran, Chandrasekhar Ramanathan, Matthew J. Reagor, John Redding, David M. Rhodes, Gabrielle Roberts, Eliott Rosenberg, Emma Rosenfeld, Pedram Roushan, Nicholas C. Rubin, Negar Saei, Daniel Sank, Kannan Sankaragomathi, Kevin J. Satzinger, Alexander Schmidhuber, Henry F. Schurkus, Christopher Schuster, Thomas Schuster, Michael J. Shearn, Aaron Shorter, Noah Shutty, Vladimir Shvarts, Volodymyr Sivak, Jindra Skruzny, Spencer Small, Vadim Smelyanskiy, W. Clarke Smith, Rolando D. Somma, Sofia Springer, George Sterling, Doug Strain, Jordan Suchard, Philippe Suchsland, Aaron Szasz, Alex Sztein, Douglas Thor, Eifu Tomita, Alfredo Torres, M. Mert Torunbalci, Abeer Vaishnav, Justin Vargas, Sergey Vdovichev, Guifre Vidal, Benjamin Villalonga, Catherine Vollgraff Heidweiller, Steven Waltman, Shannon X. Wang, Brayden Ware, Kate Weber, Travis Weidel, Tom Westerhout, Theodore White, Kristi Wong, Bryan W. K. Woo, Cheng Xing, Z. Jamie Yao, Ping Yeh, Bicheng Ying, Juhwan Yoo, Noureldin Yosri, Grayson Young, Adam Zalcman, Chongwei Zhang, Yaxing Zhang, Ningfeng Zhu, and Nicholas Zobrist, "Observation of constructive interference at the edge of quantum ergodicity", Nature 646 8086, 825 (2025) .
[157] A. V. Berezutskii, I. A. Luchnikov, and A. K. Fedorov, "Simulating quantum circuits using the multi-scale entanglement renormalization ansatz", Physical Review Research 7 1, 013063 (2025) .
[158] Aaron Sander, Lukas Burgholzer, and Robert Wille, 2023 IEEE International Conference on Quantum Computing and Engineering (QCE) 283 (2023) ISBN:979-8-3503-4323-6 .
[159] K. Kechedzhi, S.V. Isakov, S. Mandrà, B. Villalonga, X. Mi, S. Boixo, and V. Smelyanskiy, "Effective quantum volume, fidelity and computational cost of noisy quantum processing experiments", Future Generation Computer Systems 153, 431 (2024) .
[160] Dmitry I. Lyakh, Thien Nguyen, Daniel Claudino, Eugene Dumitrescu, and Alexander J. McCaskey, "ExaTN: Scalable GPU-Accelerated High-Performance Processing of General Tensor Networks at Exascale", Frontiers in Applied Mathematics and Statistics 8, 838601 (2022) .
[161] Xin Hong, Xiangzhen Zhou, Sanjiang Li, Yuan Feng, and Mingsheng Ying, "A Tensor Network based Decision Diagram for Representation of Quantum Circuits", ACM Transactions on Design Automation of Electronic Systems 27 6, 1 (2022) .
[162] Cupjin Huang, Fang Zhang, Michael Newman, Xiaotong Ni, Dawei Ding, Junjie Cai, Xun Gao, Tenghui Wang, Feng Wu, Gengyan Zhang, Hsiang-Sheng Ku, Zhengxiong Tian, Junyin Wu, Haihong Xu, Huanjun Yu, Bo Yuan, Mario Szegedy, Yaoyun Shi, Hui-Hai Zhao, Chunqing Deng, and Jianxin Chen, "Efficient parallelization of tensor network contraction for simulating quantum computation", Nature Computational Science 1 9, 578 (2021) .
[163] Alfred M. Pastor, Jose M. Badia, and Maribel Castillo, "A community detection-based parallel algorithm for quantum circuit simulation using tensor networks", The Journal of Supercomputing 81 3, 450 (2025) .
[164] Rong-Yang Sun, Tomonori Shirakawa, and Seiji Yunoki, "Improved real-space parallelizable matrix-product state compression and its application to unitary quantum dynamics simulation", Physical Review B 110 8, 085149 (2024) .
[165] Lars S. Madsen, Fabian Laudenbach, Mohsen Falamarzi. Askarani, Fabien Rortais, Trevor Vincent, Jacob F. F. Bulmer, Filippo M. Miatto, Leonhard Neuhaus, Lukas G. Helt, Matthew J. Collins, Adriana E. Lita, Thomas Gerrits, Sae Woo Nam, Varun D. Vaidya, Matteo Menotti, Ish Dhand, Zachary Vernon, Nicolás Quesada, and Jonathan Lavoie, "Quantum computational advantage with a programmable photonic processor", Nature 606 7912, 75 (2022) .
[166] Lars Gottesbüren, Tobias Heuer, Nikolai Maas, Peter Sanders, and Sebastian Schlag, "Scalable High-Quality Hypergraph Partitioning", ACM Transactions on Algorithms 20 1, 1 (2024) .
[167] Oliver Lunt, Jonas Richter, and Arijeet Pal, Quantum Science and Technology 251 (2022) ISBN:978-3-031-03997-3 .
[168] Thomas Ayral, Thibaud Louvet, Yiqing Zhou, Cyprien Lambert, E. Miles Stoudenmire, and Xavier Waintal, "Density-Matrix Renormalization Group Algorithm for Simulating Quantum Circuits with a Finite Fidelity", PRX Quantum 4 2, 020304 (2023) .
[169] Nicholas C. Rubin, Klaas Gunst, Alec White, Leon Freitag, Kyle Throssell, Garnet Kin-Lic Chan, Ryan Babbush, and Toru Shiozaki, "The Fermionic Quantum Emulator", Quantum 5, 568 (2021) .
[170] Ziang Wang, Feng Wu, Hui-Hai Zhao, Xin Wan, and Xiaotong Ni, "SuperGrad: a differentiable simulator for superconducting processors", Quantum 9, 1722 (2025) .
[171] Jin-Guo Liu, Xuanzhao Gao, and Richard Samuelson, "OMEinsumContractionOrders: A Julia package for tensor network contraction order optimization", Journal of Open Source Software 11 119, 9886 (2026) .
[172] Miklós Antal Werner, Andor Menczer, and Örs Legeza, Advances in Quantum Chemistry 94, 115 (2026) ISBN:9780443430572 .
[173] Abhinav Deshpande, Arthur Mehta, Trevor Vincent, Nicolás Quesada, Marcel Hinsche, Marios Ioannou, Lars Madsen, Jonathan Lavoie, Haoyu Qi, Jens Eisert, Dominik Hangleiter, Bill Fefferman, and Ish Dhand, "Quantum computational advantage via high-dimensional Gaussian boson sampling", Science Advances 8 1, eabi7894 (2022) .
[174] Lukas Burgholzer, Alexander Ploier, and Robert Wille, 2022 Design, Automation & Test in Europe Conference & Exhibition (DATE) 64 (2022) ISBN:978-3-9819263-6-1 .
[175] Mihail Stoian, Richard M. Milbradt, and Christian B. Mendl, "On the Optimal Linear Contraction Order of Tree Tensor Networks, and Beyond", SIAM Journal on Scientific Computing 46 5, B647 (2024) .
[176] Takato Mori, Hidetaka Manabe, and Hiroaki Matsueda, "Entanglement distillation toward minimal bond cut surface in tensor networks", Physical Review D 106 8, 086008 (2022) .
[177] Andor Menczer and Örs Legeza, "Massively Parallel Tensor Network State Algorithms on Hybrid CPU-GPU Based Architectures", Journal of Chemical Theory and Computation 21 4, 1572 (2025) .
[178] Sung-Bin B. Lee, Hee Ryang Choi, Daniel Donghyon Ohm, and Seung-Sup B. Lee, "Scalable projected entangled-pair state representation of random quantum circuit states", Physical Review Research 7 3, 033252 (2025) .
[179] Shaan Nagy, Roger Paredes, Jeffrey M. Dudek, Leonardo Dueñas-Osorio, and Moshe Y. Vardi, "Ising model partition-function computation as a weighted counting problem", Physical Review E 109 5, 055301 (2024) .
[180] M. DeCross, R. Haghshenas, M. Liu, E. Rinaldi, J. Gray, Y. Alexeev, C. H. Baldwin, J. P. Bartolotta, M. Bohn, E. Chertkov, J. Cline, J. Colina, D. DelVento, J. M. Dreiling, C. Foltz, J. P. Gaebler, T. M. Gatterman, C. N. Gilbreth, J. Giles, D. Gresh, A. Hall, A. Hankin, A. Hansen, N. Hewitt, I. Hoffman, C. Holliman, R. B. Hutson, T. Jacobs, J. Johansen, P. J. Lee, E. Lehman, D. Lucchetti, D. Lykov, I. S. Madjarov, B. Mathewson, K. Mayer, M. Mills, P. Niroula, J. M. Pino, C. Roman, M. Schecter, P. E. Siegfried, B. G. Tiemann, C. Volin, J. Walker, R. Shaydulin, M. Pistoia, S. A. Moses, D. Hayes, B. Neyenhuis, R. P. Stutz, and M. Foss-Feig, "Computational Power of Random Quantum Circuits in Arbitrary Geometries", Physical Review X 15 2, 021052 (2025) .
[181] Georg Schusteritsch, David W. Wright, Andrew G. Green, and Vid Stojevic, "What is the future role of quantum computation in drug discovery?", Emerging Topics in Life Sciences 8 2, 83 (2025) .
[182] Lukas Burgholzer and Robert Wille, Design Automation Tools and Software for Quantum Computing 53 (2026) ISBN:978-3-032-06769-2 .
[183] Alexander M. Dalzell, Sam McArdle, Mario Berta, Przemyslaw Bienias, Chi-Fang Chen, András Gilyén, Connor T. Hann, Michael J. Kastoryano, Emil T. Khabiboulline, Aleksander Kubica, Grant Salton, Samson Wang, and Fernando G. S. L. Brandão, "Quantum algorithms: A survey of applications and end-to-end complexities", arXiv:2310.03011 , (2023) .
[184] Cupjin Huang, Fang Zhang, Michael Newman, Junjie Cai, Xun Gao, Zhengxiong Tian, Junyin Wu, Haihong Xu, Huanjun Yu, Bo Yuan, Mario Szegedy, Yaoyun Shi, and Jianxin Chen, "Classical Simulation of Quantum Supremacy Circuits", arXiv:2005.06787 , (2020) .
[185] Xun Gao, Marcin Kalinowski, Chi-Ning Chou, Mikhail D. Lukin, Boaz Barak, and Soonwon Choi, "Limitations of Linear Cross-Entropy as a Measure for Quantum Advantage", PRX Quantum 5 1, 010334 (2024) .
[186] Ramis Movassagh, "Quantum supremacy and random circuits", arXiv:1909.06210 , (2019) .
[187] Feng Pan and Pan Zhang, "Simulating the Sycamore quantum supremacy circuits", arXiv:2103.03074 , (2021) .
[188] Xiaosi Xu, Simon Benjamin, Jinzhao Sun, Xiao Yuan, and Pan Zhang, "A Herculean task: Classical simulation of quantum computers", arXiv:2302.08880 , (2023) .
[189] Benjamin Villalonga, Murphy Yuezhen Niu, Li Li, Hartmut Neven, John C. Platt, Vadim N. Smelyanskiy, and Sergio Boixo, "Efficient approximation of experimental Gaussian boson sampling", arXiv:2109.11525 , (2021) .
[190] Harun Bayraktar, Ali Charara, David Clark, Saul Cohen, Timothy Costa, Yao-Lung L. Fang, Yang Gao, Jack Guan, John Gunnels, Azzam Haidar, Andreas Hehn, Markus Hohnerbach, Matthew Jones, Tom Lubowe, Dmitry Lyakh, Shinya Morino, Paul Springer, Sam Stanwyck, Igor Terentyev, Satya Varadhan, Jonathan Wong, and Takuma Yamaguchi, "cuQuantum SDK: A High-Performance Library for Accelerating Quantum Science", arXiv:2308.01999 , (2023) .
[191] Feng Pan, Pengfei Zhou, Sujie Li, and Pan Zhang, "Contracting Arbitrary Tensor Networks: General Approximate Algorithm and Applications in Graphical Models and Quantum Circuit Simulations", Physical Review Letters 125 6, 060503 (2020) .
[192] Jin-Guo Liu, Lei Wang, and Pan Zhang, "Tropical Tensor Network for Ground States of Spin Glasses", Physical Review Letters 126 9, 090506 (2021) .
[193] Alessio Cicero, Mohammad Ali Maleki, Muhammad Waqar Azhar, Anton Frisk Kockum, and Pedro Trancoso, "Simulation of Quantum Computers: Review and Acceleration Opportunities", arXiv:2410.12660 , (2024) .
[194] Alex Townsend-Teague and Konstantinos Meichanetzidis, "Simplification Strategies for the Qutrit ZX-Calculus", arXiv:2103.06914 , (2021) .
[195] Andor Menczer, Maarten van Damme, Alan Rask, Lee Huntington, Jeff Hammond, Sotiris S. Xantheas, Martin Ganahl, and Örs Legeza, "Parallel implementation of the Density Matrix Renormalization Group method achieving a quarter petaFLOPS performance on a single DGX-H100 GPU node", arXiv:2407.07411 , (2024) .
[196] Danylo Lykov, Ruslan Shaydulin, Yue Sun, Yuri Alexeev, and Marco Pistoia, "Fast Simulation of High-Depth QAOA Circuits", arXiv:2309.04841 , (2023) .
[197] Alexander Zlokapa, Sergio Boixo, and Daniel Lidar, "Boundaries of quantum supremacy via random circuit sampling", arXiv:2005.02464 , (2020) .
[198] Fumiyoshi Kobayashi, Hidetaka Manabe, Gregory A. L. White, Terry Farrelly, Kavan Modi, and Thomas M. Stace, "Tensor-network decoders for process tensor descriptions of non-Markovian noise", arXiv:2412.13739 , (2024) .
[199] Costantino Carugno, Jake Muff, Mikael P. Johansson, Sven Karlsson, and Alberto Lanzanova, "NordIQuEst: the Nordic-Estonian Quantum Computing e-Infrastructure Quest", arXiv:2406.02216 , (2024) .
[200] Feng Pan, Hanfeng Gu, Lvlin Kuang, Bing Liu, and Pan Zhang, "Efficient Quantum Circuit Simulation by Tensor Network Methods on Modern GPUs", arXiv:2310.03978 , (2023) .
[201] Chi-Ning Chou, "The Computational Lens: from Quantum Physics to Neuroscience", arXiv:2310.20539 , (2023) .
[202] Hiroyuki Ootomo, Hidetaka Manabe, Kenji Harada, and Rio Yokota, "Quantum Circuit Simulation by SGEMM Emulation on Tensor Cores and Automatic Precision Selection", arXiv:2303.08989 , (2023) .
[203] Roman Schutski, Taras Khakhulin, Ivan Oseledets, and Dmitry Kolmakov, "Simple heuristics for efficient parallel tensor contraction and quantum circuit simulation", Physical Review A 102 6, 062614 (2020) .
[204] Lars Gottesbüren, Tobias Heuer, Nikolai Maas, Peter Sanders, and Sebastian Schlag, "Scalable High-Quality Hypergraph Partitioning", arXiv:2303.17679 , (2023) .
[205] Adhitha Dias, Logan Anderson, Kirshanthan Sundararajah, Artem Pelenitsyn, and Milind Kulkarni, "SparseAuto: An Auto-Scheduler for Sparse Tensor Computations Using Recursive Loop Nest Restructuring", arXiv:2311.09549 , (2023) .
[206] Xin Hong, Xiangzhen Zhou, Sanjiang Li, Yuan Feng, and Mingsheng Ying, "A Tensor Network based Decision Diagram for Representation of Quantum Circuits", arXiv:2009.02618 , (2020) .
[207] Jeffrey M. Dudek and Moshe Y. Vardi, "Parallel Weighted Model Counting with Tensor Networks", arXiv:2006.15512 , (2020) .
[208] Tobias Heuer, "A Direct k-Way Hypergraph Partitioning Algorithm for Optimizing the Steiner Tree Metric", arXiv:2309.16694 , (2023) .
[209] Tuomas Laakkonen, Konstantinos Meichanetzidis, and John van de Wetering, "Picturing Counting Reductions with the ZH-Calculus", arXiv:2304.02524 , (2023) .
[210] John Brennan, Momme Allalen, David Brayford, Kenneth Hanley, Luigi Iapichino, Lee J. O'Riordan, Myles Doyle, and Niall Moran, "Tensor Network Circuit Simulation at Exascale", arXiv:2110.09894 , (2021) .
[211] Jin Lee, Sofia Gonzalez-Garcia, Zheng Zhang, and Haewon Jeong, "Coded Computing Meets Quantum Circuit Simulation: Coded Parallel Tensor Network Contraction Algorithm", arXiv:2405.13946 , (2024) .
[212] Zhimin Wang, Zhaoyun Chen, Shengbin Wang, Wendong Li, Yongjian Gu, Guoping Guo, and Zhiqiang Wei, "A quantum circuit simulator and its applications on Sunway TaihuLight supercomputer", arXiv:2008.07140 , (2020) .
[213] Willow Ahrens, Fredrik Kjolstad, and Saman Amarasinghe, "An Asymptotic Cost Model for Autoscheduling Sparse Tensor Programs", arXiv:2111.14947 , (2021) .
[214] Linjian Ma and Chao Yang, "Low Rank Approximation in Simulations of Quantum Algorithms", arXiv:2104.11396 , (2021) .
[215] Mekena Metcalf, Pablo Andrés-Martínez, and Nathan Fitzpatrick, "Realizing Quantum Kernel Models at Scale with Matrix Product State Simulation", arXiv:2411.09336 , (2024) .
[216] Miklós Antal Werner, Andor Menczer, and Örs Legeza, "Tensor network state methods and quantum information theory for strongly correlated molecular systems", arXiv:2501.18263 , (2025) .
[217] Sayan Mukherjee and Shinichiro Akiyama, "Congestion bounds via Laplacian eigenvalues and their application to tensor networks with arbitrary geometry", arXiv:2510.02725 , (2025) .
[218] Hrant Gharibyan, Mohammed Zuhair Mullath, Nicholas E. Sherman, Vincent P. Su, Hayk Tepanyan, and Yuxuan Zhang, "Heuristic Quantum Advantage with Peaked Circuits", arXiv:2510.25838 , (2025) .
[219] Manuel Geiger, Qunsheng Huang, and Christian B. Mendl, "Optimizing Tensor Network Partitioning using Simulated Annealing", arXiv:2507.20667 , (2025) .
[220] Arman Sauliere, Guglielmo Lami, Corentin Boyer, Jacopo De Nardis, and Andrea De Luca, "Universality in the Anticoncentration of Noisy Quantum Circuits at Finite Depths", arXiv:2508.14975 , (2025) .
[221] Lesley Gover, Vinul Wimalaweera, Fariha Azad, Matthew DeCross, Michael Foss-Feig, and Andrew G. Green, "Fully optimised variational simulation of a dynamical quantum phase transition on a trapped-ion quantum computer", arXiv:2502.06961 , (2025) .
[222] Yusuke Kimura, Masahiro Fujita, and Robert Wille, "Scoring-based Static Variable Ordering for Decision Diagram-based Quantum Circuit Simulation", arXiv:2512.01186 , (2025) .
[223] Patrick A. Myers, Joseph A. Bogdan, Majdi I. Radaideh, and Brian C. Kiedrowski, "Tensorized Discontinuous Isogeometric Analysis Method for the 2-D Time-Independent Linearized Boltzmann Transport Equation", arXiv:2601.18925 , (2026) .
The above citations are from Crossref's cited-by service (last updated successfully 2026-05-30 07:01:34) and SAO/NASA ADS (last updated successfully 2026-05-29 18:05:10). The list may be incomplete as not all publishers provide suitable and complete citation data. Could not fetch ADS cited-by data during last attempt 2026-05-30 07:01:34: Cannot retrieve data from ADS due to rate limitations.
This Paper is published in Quantum under the Creative Commons Attribution 4.0 International (CC BY 4.0) license. Copyright remains with the original copyright holders such as the authors or their institutions.
Quantum is an open-access peer-reviewed journal for quantum science and related fields.
Quantum is non-profit and community-run: an effort by researchers and for researchers to make science more open and publishing more transparent and efficient.
Sign up for our monthly digest of papers and other news.  People Coordinating editors
Carlo Beenakker Eric Cavalcanti Sevag Gharibian Ujjwal Sen Ronald de Wolf
Editors
Elizabeth Agudelo Álvaro Alhambra Anurag Anshu Fabio Anza Mateus Araújo Remigiusz Augusiak Flavio Baccari Miriam Backens Aleksandrs Belovs Alessio Benavoli Kishor Bharti Andrea Di Biagio Cyril Branciard Michele Campisi Ángela Capel Angelo Carollo Marco Cerezo Ulysse Chabaud Francesco Ciccarello Ivan Contreras Luis A. Correa Eleanor Crane Borivoje Dakic Alexander Dalzell Abhinav Deshpande Yongshan Ding Vedran Dunjko Thomas Elliott Dax Enshan Koh Paul Erker Philippe Faist Di Fang Máté Farkas Nicolai Friis Christos Gagatsos Diego García-Martín Roohollah Ghobadi Géza Giedke Aaron Goldberg Daniel Grier Tom Gur Alioscia Hamma Felix Huber Isaac Kim Ravi Kunjwal Felix Leditzky Lorenzo Leone Tongyang Li Jin-Peng Liu Yuan Liu Maximilian Lock Leon Loveridge Tommaso Macrì Daniel Malz Atul Mantri Milad Marvian Daniel McNulty Pérola Milman Mark Mitchison Tomoyuki Morimae Ion Nechita Patrick Rebentrost Narayanan Rengaswamy Joschka Roffe Dennis Rätzel Krishna Kumar Sabapathy Mohan Sarovar Philipp Schindler Alexander Schuckert Gael Sentís Jiangwei Shang Changpeng Shao Kunal Sharma Himadri Shekhar Dhar Jens Siewert Paul Skrzypczyk Luca Tagliacozzo Philip Taranto Yu Tong Jordi Tura Michael Vasmer Petros Wallden Xin Wang John van de Wetering Alexander Wilce Pei Zeng
Executive Board
Christian Gogolin  Marcus Huber  Lídia del Rio
Steering Board
Antonio Acín Anne Broadbent Harry Buhrman Daniel Burgarth Guido Burkard Jens Eisert Steven Flammia Cassandra Granade Aram Harrow Khabat Heshami Chris Heunen Stacey Jeffery Shelby Kimmel Matthew Leifer Debbie Leung Chaoyang Lu Chiara Macchiavello Milan Mosonyi Ahsan Nazir Román Orús Joseph M. Renes Ana Maria Rey Anna Sanpera Jörg Schmiedmayer Urbasi Sinha John A. Smolin Robert W. Spekkens Aephraim M. Steinberg Francesca Vidotto Michael Walter Reinhard Werner Birgitta Whaley Witlef Wieczorek Andreas Winter Karol Życzkowski
Supporters
Support Quantum and
Memberships and Indexing
Feedback and discussion on /r/quantumjournal
Contact us by email .
© Verein zur Förderung des Open Access Publizierens in den Quantenwissenschaften .
Some rights reserved.
Terms and conditions
Impressum
Data protection and privacy policy
https://doi.org/10.22331/q
ISSN 2521-327X
Quantum practices open accounting .
This surveillance-free website does not collect cookies, track visitors, or sell their data.
Copyright © 2026 Quantum –  OnePress theme by FameThemes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [25]: T. Ayral et al. — Density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity (PRX Quantum 4, 020304, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: A density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity
URL: https://doi.org/10.1103/PRXQuantum.4.020304
[2207.05612] A density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2207.05612
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2207.05612 (quant-ph)
[Submitted on 12 Jul 2022 ( v1 ), last revised 29 Aug 2022 (this version, v2)]
Title: A density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity
Authors: Thomas Ayral , Thibaud Louvet , Yiqing Zhou , Cyprien Lambert , E. Miles Stoudenmire , Xavier Waintal  View a PDF of the paper titled A density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity, by Thomas Ayral and 4 other authors
View PDF
Abstract: We develop a density-matrix renormalization group (DMRG) algorithm for the simulation of quantum circuits. This algorithm can be seen as the extension of time-dependent DMRG from the usual situation of hermitian Hamiltonian matrices to quantum circuits defined by unitary matrices. For small circuit depths, the technique is exact and equivalent to other matrix product state (MPS) based techniques. For larger depths, it becomes approximate in exchange for an exponential speed up in computational time. Like an actual quantum computer, the quality of the DMRG results is characterized by a finite fidelity. However, unlike a quantum computer, the fidelity depends strongly on the quantum circuit considered. For the most difficult possible circuit for this technique, the so-called "quantum supremacy" benchmark of Google Inc. , we find that the DMRG algorithm can generate bit strings of the same quality as the seminal Google experiment on a single computing core. For a more structured circuit used for combinatorial optimization (Quantum Approximate Optimization Algorithm or QAOA), we find a drastic improvement of the DMRG results with error rates dropping by a factor of 100 compared with random quantum circuits. Our results suggest that the current bottleneck of quantum computers is their fidelities rather than the number of qubits.
Comments:  25 pages, 13 figures. Review section updated
Subjects:
Quantum Physics (quant-ph) ; Strongly Correlated Electrons (cond-mat.str-el)
Cite as:  arXiv:2207.05612 [quant-ph]
(or  arXiv:2207.05612v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2207.05612
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  PRX Quantum 4, 020304 (2023)
Related DOI :
https://doi.org/10.1103/PRXQuantum.4.020304
Focus to learn more
DOI(s) linking to related resources
Submission history From: Xavier Waintal [ view email ]  [v1]  Tue, 12 Jul 2022 15:28:55 UTC (693 KB)
[v2]  Mon, 29 Aug 2022 15:49:30 UTC (688 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled A density-matrix renormalization group algorithm for simulating quantum circuits with a finite fidelity, by Thomas Ayral and 4 other authors View PDF  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2022-07
Change to browse by:
cond-mat  cond-mat.str-el
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [26]: T. Schuster et al. — A polynomial-time classical algorithm for noisy quantum circuits (Phys. Rev. X 15, 041018, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: A polynomial-time classical algorithm for noisy quantum circuits
URL: https://doi.org/10.1103/PhysRevX.15.041018
[2407.12768] A polynomial-time classical algorithm for noisy quantum circuits
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2407.12768
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2407.12768 (quant-ph)
[Submitted on 17 Jul 2024 ( v1 ), last revised 14 Oct 2024 (this version, v2)]
Title: A polynomial-time classical algorithm for noisy quantum circuits
Authors: Thomas Schuster , Chao Yin , Xun Gao , Norman Y. Yao  View a PDF of the paper titled A polynomial-time classical algorithm for noisy quantum circuits, by Thomas Schuster and 3 other authors
View PDF  HTML (experimental)
Abstract: We provide a polynomial-time classical algorithm for noisy quantum circuits. The algorithm computes the expectation value of any observable for any circuit, with a small average error over input states drawn from an ensemble (e.g. the computational basis). Our approach is based upon the intuition that noise exponentially damps non-local correlations relative to local correlations. This enables one to classically simulate a noisy quantum circuit by only keeping track of the dynamics of local quantum information. Our algorithm also enables sampling from the output distribution of a circuit in quasi-polynomial time, so long as the distribution anti-concentrates. A number of practical implications are discussed, including a fundamental limit on the efficacy of noise mitigation strategies: for constant noise rates, any quantum circuit for which error mitigation is efficient on most input states, is also classically simulable on most input states.
Comments:  11 pages, 3 figures + 30 page Appendix
Subjects:
Quantum Physics (quant-ph) ; Computational Complexity (cs.CC); Information Theory (cs.IT); Mathematical Physics (math-ph); Atomic Physics (physics.atom-ph)
Cite as:  arXiv:2407.12768 [quant-ph]
(or  arXiv:2407.12768v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2407.12768
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Thomas Schuster [ view email ]  [v1]  Wed, 17 Jul 2024 17:48:39 UTC (1,583 KB)
[v2]  Mon, 14 Oct 2024 16:55:22 UTC (1,136 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled A polynomial-time classical algorithm for noisy quantum circuits, by Thomas Schuster and 3 other authors View PDF  HTML (experimental)  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2024-07
Change to browse by:
cs  cs.CC  cs.IT  math  math-ph  math.IT  math.MP  physics  physics.atom-ph
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [27]: J. Robledo-Moreno et al. — Chemistry beyond the scale of exact diagonalization on a quantum-centric supercomputer (Sci. Adv. 11, eadu9991, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Chemistry Beyond the Scale of Exact Diagonalization on a Quantum-Centric Supercomputer
URL: https://doi.org/10.1126/sciadv.adu9991
[2405.05068] Chemistry Beyond the Scale of Exact Diagonalization on a Quantum-Centric Supercomputer
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2405.05068
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
open search
GO
open navigation menu
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2405.05068 (quant-ph)
[Submitted on 8 May 2024 ( v1 ), last revised 13 Jul 2025 (this version, v3)]
Title: Chemistry Beyond the Scale of Exact Diagonalization on a Quantum-Centric Supercomputer
Authors: Javier Robledo-Moreno , Mario Motta , Holger Haas , Ali Javadi-Abhari , Petar Jurcevic , William Kirby , Simon Martiel , Kunal Sharma , Sandeep Sharma , Tomonori Shirakawa , Iskandar Sitdikov , Rong-Yang Sun , Kevin J. Sung , Maika Takita , Minh C. Tran , Seiji Yunoki , Antonio Mezzacapo  View a PDF of the paper titled Chemistry Beyond the Scale of Exact Diagonalization on a Quantum-Centric Supercomputer, by Javier Robledo-Moreno and 16 other authors
View PDF  HTML (experimental)
Abstract: A universal quantum computer can simulate diverse quantum systems, with electronic structure for chemistry offering challenging problems for practical use cases around the hundred-qubit mark. While current quantum processors have reached this size, deep circuits and large number of measurements lead to prohibitive runtimes for quantum computers in isolation. Here, we demonstrate the use of classical distributed computing to offload all but an intrinsically quantum component of a workflow for electronic structure simulations. Using a Heron superconducting processor and the supercomputer Fugaku, we simulate the ground-state dissociation of N _2 and the [2Fe-2S] and [4Fe-4S] clusters, with circuits up to 77 qubits and 10,570 gates. The proposed algorithm processes quantum samples to produce upper bounds for the ground-state energy and sparse approximations to the ground-state wavefunctions. Our results suggest that, for current error rates, a quantum-centric supercomputing architecture can tackle challenging chemistry problems beyond sizes amenable to exact diagonalization.
Subjects:
Quantum Physics (quant-ph) ; Other Condensed Matter (cond-mat.other); Chemical Physics (physics.chem-ph); Computational Physics (physics.comp-ph)
Report number:  RIKEN-iTHEMS-Report-24
Cite as:  arXiv:2405.05068 [quant-ph]
(or  arXiv:2405.05068v3 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2405.05068
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Science Advances 11, 25, eadu9991 (2025)
Related DOI :
https://doi.org/10.1126/sciadv.adu9991
Focus to learn more
DOI(s) linking to related resources
Submission history From: Javier Robledo Moreno [ view email ]  [v1]  Wed, 8 May 2024 14:08:07 UTC (27,985 KB)
[v2]  Thu, 14 Nov 2024 16:59:50 UTC (29,986 KB)
[v3]  Sun, 13 Jul 2025 21:10:52 UTC (29,029 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled Chemistry Beyond the Scale of Exact Diagonalization on a Quantum-Centric Supercomputer, by Javier Robledo-Moreno and 16 other authors View PDF  HTML (experimental)  TeX Source
view license
Current browse context: quant-ph
< prev
|    next >
new  |  recent  | 2024-05
Change to browse by:
cond-mat  cond-mat.other  physics  physics.chem-ph  physics.comp-ph
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
Links to Code Toggle
Papers with Code ( What is Papers with Code? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [28]: J. Tindall et al. — Efficient tensor network simulation of IBM's Eagle Kicked Ising experiment (PRX Quantum 5, 010308, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Efficient tensor network simulation of IBM's Eagle kicked Ising experiment
URL: https://doi.org/10.1103/PRXQuantum.5.010308
[2306.14887] Efficient tensor network simulation of IBM's Eagle kicked Ising experiment
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2306.14887
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2306.14887 (quant-ph)
[Submitted on 26 Jun 2023 ( v1 ), last revised 26 Jan 2024 (this version, v3)]
Title: Efficient tensor network simulation of IBM's Eagle kicked Ising experiment
Authors: Joseph Tindall , Matt Fishman , Miles Stoudenmire , Dries Sels  View a PDF of the paper titled Efficient tensor network simulation of IBM's Eagle kicked Ising experiment, by Joseph Tindall and 2 other authors
View PDF
Abstract: We report an accurate and efficient classical simulation of a kicked Ising quantum system on the heavy-hexagon lattice. A simulation of this system was recently performed on a 127 qubit quantum processor using noise mitigation techniques to enhance accuracy (Nature volume 618, p.~500-505 (2023)). Here we show that, by adopting a tensor network approach that reflects the geometry of the lattice and is approximately contracted using belief propagation, we can perform a classical simulation that is significantly more accurate and precise than the results obtained from the quantum processor and many other classical methods. We quantify the tree-like correlations of the wavefunction in order to explain the accuracy of our belief propagation-based approach. We also show how our method allows us to perform simulations of the system to long times in the thermodynamic limit, corresponding to a quantum computer with an infinite number of qubits. Our tensor network approach has broader applications for simulating the dynamics of quantum systems with tree-like correlations.
Comments:  17 Pages. 11 Figures. Updated to reflect final publication version
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:2306.14887 [quant-ph]
(or  arXiv:2306.14887v3 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2306.14887
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  PRX Quantum 5, 010308 (2024)
Related DOI :
https://doi.org/10.1103/PRXQuantum.5.010308
Focus to learn more
DOI(s) linking to related resources
Submission history From: Joseph Tindall [ view email ]  [v1]  Mon, 26 Jun 2023 17:54:08 UTC (747 KB)
[v2]  Wed, 16 Aug 2023 17:13:31 UTC (1,355 KB)
[v3]  Fri, 26 Jan 2024 16:16:56 UTC (1,067 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled Efficient tensor network simulation of IBM's Eagle kicked Ising experiment, by Joseph Tindall and 2 other authors View PDF  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2023-06
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
1 blog link  ( what is this? )
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [29]: T. Begušić, J. Gray, G. K.-L. Chan — Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance (Sci. Adv. 10, eadk4321, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance
URL: https://doi.org/10.1126/sciadv.adk4321
[2308.05077] Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2308.05077
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2308.05077 (quant-ph)
[Submitted on 9 Aug 2023 ( v1 ), last revised 26 Jan 2024 (this version, v3)]
Title: Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance
Authors: Tomislav Begušić , Johnnie Gray , Garnet Kin-Lic Chan  View a PDF of the paper titled Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance, by Tomislav Begu\v{s}i\'c and 2 other authors
View PDF  HTML (experimental)
Abstract: A recent quantum simulation of observables of the kicked Ising model on 127 qubits implemented circuits that exceed the capabilities of exact classical simulation. We show that several approximate classical methods, based on sparse Pauli dynamics and tensor network algorithms, can simulate these observables orders of magnitude faster than the quantum experiment, and can also be systematically converged beyond the experimental accuracy. Our most accurate technique combines a mixed Schrödinger and Heisenberg tensor network representation with the Bethe free entropy relation of belief propagation to compute expectation values with an effective wavefunction-operator sandwich bond dimension >16,000,000, achieving an absolute accuracy, without extrapolation, in the observables of <0.01, which is converged for many practical purposes. We thereby identify inaccuracies in the experimental extrapolations and suggest how future experiments can be implemented to increase the classical hardness.
Comments:  This can be regarded as the full version of the preliminary note in arXiv:2306.16372
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:2308.05077 [quant-ph]
(or  arXiv:2308.05077v3 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2308.05077
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Sci. Adv. 10, eadk4321 (2024)
Related DOI :
https://doi.org/10.1126/sciadv.adk4321
Focus to learn more
DOI(s) linking to related resources
Submission history From: Tomislav Begušić [ view email ]  [v1]  Wed, 9 Aug 2023 17:15:17 UTC (5,517 KB)
[v2]  Tue, 22 Aug 2023 06:01:53 UTC (5,587 KB)
[v3]  Fri, 26 Jan 2024 21:15:43 UTC (6,930 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled Fast and converged classical simulations of evidence for the utility of quantum computing before fault tolerance, by Tomislav Begu\v{s}i\'c and 2 other authors View PDF  HTML (experimental)  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2023-08
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [30]: M. S. Rudolph, E. Fontana, Z. Holmes, L. Cincio — Classical surrogate simulation of quantum systems with LOWESA (arXiv:2308.09109, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Classical surrogate simulation of quantum systems with LOWESA
URL: https://arxiv.org/abs/2308.09109
[2308.09109] Classical surrogate simulation of quantum systems with LOWESA
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2308.09109
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2308.09109 (quant-ph)
[Submitted on 17 Aug 2023]
Title: Classical surrogate simulation of quantum systems with LOWESA
Authors: Manuel S. Rudolph , Enrico Fontana , Zoë Holmes , Lukasz Cincio  View a PDF of the paper titled Classical surrogate simulation of quantum systems with LOWESA, by Manuel S. Rudolph and 3 other authors
View PDF
Abstract: We introduce LOWESA as a classical algorithm for faithfully simulating quantum systems via a classically constructed surrogate expectation landscape. After an initial overhead to build the surrogate landscape, one can rapidly study entire families of Hamiltonians, initial states and target observables. As a case study, we simulate the 127-qubit transverse-field Ising quantum system on a heavy-hexagon lattice with up to 20 Trotter steps which was recently presented in Nature 618, 500-505 (2023). Specifically, we approximately reconstruct (in minutes to hours on a laptop) the entire expectation landscape spanned by the heavy-hex Ising model. The expectation of a given observable can then be evaluated at different parameter values, i.e. with different onsite magnetic fields and coupling strengths, in fractions of a second on a laptop. This highlights that LOWESA can attain state-of-the-art performance in quantum simulation tasks, with the potential to become the algorithm of choice for scanning a wide range of systems quickly.
Comments:  13 pages, 6 figures
Subjects:
Quantum Physics (quant-ph) ; Strongly Correlated Electrons (cond-mat.str-el)
Report number:  LA-UR-23-29362
Cite as:  arXiv:2308.09109 [quant-ph]
(or  arXiv:2308.09109v1 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2308.09109
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Manuel Rudolph [ view email ]  [v1]  Thu, 17 Aug 2023 17:32:16 UTC (1,364 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled Classical surrogate simulation of quantum systems with LOWESA, by Manuel S. Rudolph and 3 other authors View PDF  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2023-08
Change to browse by:
cond-mat  cond-mat.str-el
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [31]: M. S. Rudolph, J. Tindall — Simulating and sampling from quantum circuits with 2D tensor networks (arXiv:2507.11424, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Simulating and Sampling from Quantum Circuits with 2D Tensor Networks
URL: https://arxiv.org/abs/2507.11424
[2507.11424] Simulating and Sampling from Quantum Circuits with 2D Tensor Networks
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2507.11424
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2507.11424 (quant-ph)
[Submitted on 15 Jul 2025 ( v1 ), last revised 14 Sep 2025 (this version, v2)]
Title: Simulating and Sampling from Quantum Circuits with 2D Tensor Networks
Authors: Manuel S. Rudolph , Joseph Tindall  View a PDF of the paper titled Simulating and Sampling from Quantum Circuits with 2D Tensor Networks, by Manuel S. Rudolph and 1 other authors
View PDF  HTML (experimental)
Abstract: Classical simulations of quantum circuits play a vital role in the development of quantum computers and for taking the temperature of the field. Here, we classically simulate various physically-motivated circuits using 2D tensor network ansätze for the many-body wavefunction which match the geometry of the underlying quantum processor. We then employ a generalized version of the boundary Matrix Product State contraction algorithm to controllably generate samples from the resultant tensor network states. Our approach allows us to systematically converge both the quality of the final state and the samples drawn from it to the true distribution defined by the circuit, with GPU hardware providing us with significant speedups over CPU hardware. With these methods, we simulate the largest local unitary Jastrow ansatz circuit taken from recent IBM experiments to numerical precision. We also study a domain-wall quench in a two-dimensional discrete-time Heisenberg model on large heavy-hex and rotated square lattices, which reflect IBM's and Google's latest quantum processors respectively. We observe a rapid buildup of complex loop correlations on the Google Willow geometry which significantly impact the local properties of the system. Meanwhile, we find loop correlations build up extremely slowly on heavy-hex processors and have almost negligible impact on the local properties of the system, even at large circuit depths. Our results underscore the role the geometry of the quantum processor plays in classical simulability.
Comments:  13 pages, 9 figures
Subjects:
Quantum Physics (quant-ph) ; Other Condensed Matter (cond-mat.other)
Cite as:  arXiv:2507.11424 [quant-ph]
(or  arXiv:2507.11424v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2507.11424
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Manuel Rudolph [ view email ]  [v1]  Tue, 15 Jul 2025 15:50:02 UTC (2,683 KB)
[v2]  Sun, 14 Sep 2025 22:18:46 UTC (3,161 KB)
Full-text links:  Access Paper:
View a PDF of the paper titled Simulating and Sampling from Quantum Circuits with 2D Tensor Networks, by Manuel S. Rudolph and 1 other authors View PDF  HTML (experimental)  TeX Source
view license
Current browse context:
quant-ph
< prev
|    next >
new  |  recent  | 2025-07
Change to browse by:
cond-mat  cond-mat.other
References & Citations
INSPIRE HEP
NASA ADS  Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv  Contact
subscribe to arXiv mailings Click here to subscribe  Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [32]: N. Schuch et al. — Computational complexity of projected entangled pair states (Phys. Rev. Lett. 98, 140506, 2007)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Computational Complexity of Projected Entangled Pair States
URL: https://doi.org/10.1103/PhysRevLett.98.140506
Computational Complexity of Projected Entangled Pair States | Phys. Rev. Lett.
Opens in a new window Opens an external website Opens an external website in a new window  This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy  Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content  All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine  Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review Letters
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Computational Complexity of Projected Entangled Pair States Norbert Schuch 1 , Michael M. Wolf 1 , Frank Verstraete 2 , and J. Ignacio Cirac 1  open icon close icon  1 Max-Planck-Institut für Quantenoptik, Hans-Kopfermann-Str. 1, D-85748 Garching, Germany 2 Fakultät für Physik, Universität Wien, Boltzmanngasse 5, A-1090 Wien, Austria
PDF Share open icon close icon X  Facebook  Mendeley  LinkedIn  Reddit  Sina Weibo
Phys. Rev. Lett. 98 , 140506 – Published 4 April, 2007  DOI:https://doi.org/10.1103/PhysRevLett.98.140506
Export Citation
277
Show metrics open icon close icon
See more details
Picked up by 1 news outlets
Referenced in 1 patents
Mentioned in 2 Q&A threads
114 readers on Mendeley
3 readers on CiteULike
277
CITATIONS
Abstract We determine the computational power of preparing projected entangled pair states (PEPS), as well as the complexity of classically simulating them, and generally the complexity of contracting tensor networks. While creating PEPS allows us to solve 𝑃 ⁢ 𝑃 problems, the latter two tasks are both proven to be # 𝑃 -complete. We further show how PEPS can be used to approximate ground states of gapped Hamiltonians and that creating them is easier than creating arbitrary PEPS. The main tool for our proofs is a duality between PEPS and postselection which allows us to use existing results from quantum complexity.
locked icon
locked icon
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription If you have a personal subscription through your APS membership please log in. Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options Buy Article »  Log in with APS Journals Account  Log in with username/password provided by your institution  Get access through a U.S. public or high school
References (Subscription Required)
Outline Information  Citing Articles (221)  Abstract  Article Text  References
Phys. Rev. Lett. 98 , 140506 – Published 4 April, 2007
Vol. 98, Iss. 14 — 6 April 2007  Received 7 November 2006
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevLett.98.140506
© 2007 American Physical Society
Outline Information Outline
Citing Articles (221)  Abstract  Article Text  References
Information
Phys. Rev. Lett. 98 , 140506 – Published 4 April, 2007
Vol. 98, Iss. 14 — 6 April 2007  Received 7 November 2006
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevLett.98.140506
© 2007 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science SCOAP 3 Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors General Information  Submit a Manuscript  Publication Rights  Open Science  SCOAP 3  Policies & Practices  Tips for Authors  Professional Conduct
Reviewers General Information  Submit a Report  Update Your Information  Policies & Practices  Reviewer FAQ  Guidelines for Reviewers  Outstanding Referees
Librarians General Information  Subscriptions  Online License Agreement  Usage Statistics  Your Account
Students Physics  PhysicsCentral  Student Membership
Connect Privacy  Policies  Contact Information  Feedback
ISSN 1079-7114 (online), 0031-9007 (print). ©2026 American Physical Society. All rights reserved. Physical Review Letters™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username  Password  Forgot your username/password?  Create an account  Sign in to your APS Member Account  Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation Paste a citation or DOI Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume  Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [33]: J. Haferkamp et al. — Contracting projected entangled pair states is average-case hard (Phys. Rev. Res. 2, 013010, 2020)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Contracting projected entangled pair states is average-case hard
URL: https://doi.org/10.1103/PhysRevResearch.2.013010
[1810.00738] Contracting projected entangled pair states is average-case hard
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:1810.00738
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:1810.00738 (quant-ph)
[Submitted on 1 Oct 2018]
Title: Contracting projected entangled pair states is average-case hard
Authors: Jonas Haferkamp , Dominik Hangleiter , Jens Eisert , Marek Gluza
View a PDF of the paper titled Contracting projected entangled pair states is average-case hard, by Jonas Haferkamp and 3 other authors
View PDF
Abstract: An accurate calculation of the properties of quantum many-body systems is one of the most important yet intricate challenges of modern physics and computer science. In recent years, the tensor network ansatz has established itself as one of the most promising approaches enabling striking efficiency of simulating static properties of one-dimensional systems and abounding numerical applications in condensed matter theory. In higher dimensions, however, a connection to the field of computational complexity theory has shown that the accurate normalization of the two-dimensional tensor networks called projected entangled pair states (PEPS) is #P-complete. Therefore, an efficient algorithm for PEPS contraction would allow to solve exceedingly difficult combinatorial counting problems, which is considered highly unlikely. Due to the importance of understanding two- and three-dimensional systems the question currently remains: Are the known constructions typical of states relevant for quantum many-body systems? In this work, we show that an accurate evaluation of normalization or expectation values of PEPS is as hard to compute for typical instances as for special configurations of highest computational hardness. We discuss the structural property of average-case hardness in relation to the current research on efficient algorithms attempting tensor network contraction, hinting at a wealth of possible further insights into the average-case hardness of important problems in quantum many-body theory.
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:1810.00738 [quant-ph]
(or  arXiv:1810.00738v1 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.1810.00738
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Research 2, 013010 (2020)
Related DOI :
https://doi.org/10.1103/PhysRevResearch.2.013010
Focus to learn more
DOI(s) linking to related resources
Submission history From: Marek Gluza [ view email ]  [v1]  Mon, 1 Oct 2018 14:49:22 UTC (50 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Contracting projected entangled pair states is average-case hard, by Jonas Haferkamp and 3 other authors
View PDF
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2018-10
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [34]: R. Alkabetz, I. Arad — Tensor networks contraction and the belief propagation algorithm (Phys. Rev. Res. 3, 023073, 2021)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Tensor networks contraction and the belief propagation algorithm
URL: https://doi.org/10.1103/PhysRevResearch.3.023073
[2008.04433] Tensor Networks contraction and the Belief Propagation algorithm
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2008.04433
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2008.04433 (quant-ph)
[Submitted on 10 Aug 2020 ( v1 ), last revised 24 Aug 2020 (this version, v2)]
Title: Tensor Networks contraction and the Belief Propagation algorithm
Authors: Roy Alkabetz , Itai Arad
View a PDF of the paper titled Tensor Networks contraction and the Belief Propagation algorithm, by Roy Alkabetz and 1 other authors
View PDF
Abstract: Belief Propagation is a well-studied message-passing algorithm that runs over graphical models and can be used for approximate inference and approximation of local marginals. The resulting approximations are equivalent to the Bethe-Peierls approximation of statistical mechanics. Here we show how this algorithm can be adapted to the world of PEPS tensor networks and used as an approximate contraction scheme. We further show that the resultant approximation is equivalent to the ``mean field'' approximation that is used in the Simple-Update algorithm, thereby showing that the latter is a essentially the Bethe-Peierls approximation. This shows that one of the simplest approximate contraction algorithms for tensor networks is equivalent to one of the simplest schemes for approximating marginals in graphical models in general, and paves the way for using improvements of BP as tensor networks algorithms.
Comments:  RevTeX 4.1, 14 pages, 13 figures. Comments are welcome. Version2: very minor modifications
Subjects:
Quantum Physics (quant-ph) ; Statistical Mechanics (cond-mat.stat-mech)
Cite as:  arXiv:2008.04433 [quant-ph]
(or  arXiv:2008.04433v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2008.04433
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Research 3, 023073 (2021)
Related DOI :
https://doi.org/10.1103/PhysRevResearch.3.023073
Focus to learn more
DOI(s) linking to related resources
Submission history From: Itai Arad [ view email ]  [v1]  Mon, 10 Aug 2020 22:03:25 UTC (389 KB)
[v2]  Mon, 24 Aug 2020 13:15:20 UTC (390 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Tensor Networks contraction and the Belief Propagation algorithm, by Roy Alkabetz and 1 other authors
View PDF
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2020-08
Change to browse by:
cond-mat
cond-mat.stat-mech
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [35]: J. Tindall, M. Fishman — Gauging tensor networks with belief propagation (SciPost Phys. 15, 222, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Gauging tensor networks with belief propagation
URL: https://doi.org/10.21468/SciPostPhys.15.6.222
[2306.17837] Gauging tensor networks with belief propagation
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2306.17837
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
open search
GO
open navigation menu
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2306.17837 (quant-ph)
[Submitted on 30 Jun 2023 ( v1 ), last revised 28 Feb 2025 (this version, v5)]
Title: Gauging tensor networks with belief propagation
Authors: Joseph Tindall , Matthew T. Fishman
View a PDF of the paper titled Gauging tensor networks with belief propagation, by Joseph Tindall and Matthew T. Fishman
View PDF  HTML (experimental)
Abstract: Effectively compressing and optimizing tensor networks requires reliable methods for fixing the latent degrees of freedom of the tensors, known as the gauge. Here we introduce a new algorithm for gauging tensor networks using belief propagation, a method that was originally formulated for performing statistical inference on graphical models and has recently found applications in tensor network algorithms. We show that this method is closely related to known tensor network gauging methods. It has the practical advantage, however, that existing belief propagation implementations can be repurposed for tensor network gauging, and that belief propagation is a very simple algorithm based on just tensor contractions so it can be easier to implement, optimize, and generalize. We present numerical evidence and scaling arguments that this algorithm is faster than existing gauging algorithms, demonstrating its usage on structured, unstructured, and infinite tensor networks. Additionally, we apply this method to improve the accuracy of the widely used simple update gate evolution algorithm.
Comments:  45 Pages. 11 Figures
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:2306.17837 [quant-ph]
(or  arXiv:2306.17837v5 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2306.17837
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  SciPost Phys. 15, 222 (2023)
Related DOI :
https://doi.org/10.21468/SciPostPhys.15.6.222
Focus to learn more
DOI(s) linking to related resources
Submission history From: Joseph Tindall [ view email ]  [v1]  Fri, 30 Jun 2023 17:56:15 UTC (2,489 KB)
[v2]  Fri, 18 Aug 2023 16:41:30 UTC (2,689 KB)
[v3]  Tue, 7 Nov 2023 20:26:44 UTC (2,328 KB)
[v4]  Tue, 5 Dec 2023 19:12:28 UTC (2,328 KB)
[v5]  Fri, 28 Feb 2025 16:47:01 UTC (2,484 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Gauging tensor networks with belief propagation, by Joseph Tindall and Matthew T. Fishman
View PDF
HTML (experimental)
TeX Source
view license
Current browse context: quant-ph
< prev
|  next >
new  |  recent  | 2023-06
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
Links to Code Toggle
Papers with Code ( What is Papers with Code? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [36]: G. Vidal — Efficient simulation of one-dimensional quantum many-body systems (Phys. Rev. Lett. 93, 040502, 2004)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Efficient simulation of one-dimensional quantum many-body systems
URL: https://doi.org/10.1103/PhysRevLett.93.040502
[quant-ph/0310089] Efficient simulation of one-dimensional quantum many-body systems
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:quant-ph/0310089
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:quant-ph/0310089 (quant-ph)
[Submitted on 14 Oct 2003]
Title: Efficient simulation of one-dimensional quantum many-body systems
Authors: G. Vidal
View a PDF of the paper titled Efficient simulation of one-dimensional quantum many-body systems, by G. Vidal
View PDF
Abstract: We present a numerical method to simulate the time evolution, according to a Hamiltonian made of local interactions, of quantum spin chains and systems alike. The efficiency of the scheme depends on the amount of the entanglement involved in the simulated evolution. Numerical analysis indicate that this method can be used, for instance, to efficiently compute time-dependent properties of low-energy dynamics of sufficiently regular but otherwise arbitrary one-dimensional quantum many-body systems.
Comments:  4 pages, 1 figure
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:quant-ph/0310089
(or  arXiv:quant-ph/0310089v1 for this version)
https://doi.org/10.48550/arXiv.quant-ph/0310089
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Lett. 93, 040502 (2004)
Related DOI :
https://doi.org/10.1103/PhysRevLett.93.040502
Focus to learn more
DOI(s) linking to related resources
Submission history From: Guifre Vidal [ view email ]  [v1]  Tue, 14 Oct 2003 01:57:22 UTC (34 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Efficient simulation of one-dimensional quantum many-body systems, by G. Vidal
View PDF
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2003-10
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
2 blog links  ( what is this? )
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [37]: H. C. Jiang et al. — Accurate determination of tensor network state of quantum lattice models in two dimensions (Phys. Rev. Lett. 101, 090603, 2008)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Accurate determination of tensor network state of quantum lattice models in two dimensions
URL: https://doi.org/10.1103/PhysRevLett.101.090603
[0806.3719] Accurate determination of tensor network state of quantum lattice models in two dimensions
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:0806.3719
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Strongly Correlated Electrons
arXiv:0806.3719 (cond-mat)
[Submitted on 23 Jun 2008]
Title: Accurate determination of tensor network state of quantum lattice models in two dimensions
Authors: H. C. Jiang , Z. Y. Weng , T. Xiang
View a PDF of the paper titled Accurate determination of tensor network state of quantum lattice models in two dimensions, by H. C. Jiang and 2 other authors
View PDF
Abstract: We have proposed a novel numerical method to calculate accurately the physical quantities of the ground state with the tensor-network wave function in two dimensions. We determine the tensor network wavefunction by a projection approach which applies iteratively the Trotter-Suzuki decomposition of the projection operator and the singular value decomposition of matrix. The norm of the wavefunction and the expectation value of a physical observable are evaluated by a coarse grain renormalization group approach. Our method allows a tensor-network wavefunction with a high bond degree of freedom (such as D=8) to be handled accurately and efficiently in the thermodynamic limit. For the Heisenberg model on a honeycomb lattice, our results for the ground state energy and the staggered magnetization agree well with those obtained by the quantum Monte Carlo and other approaches.
Comments:  4 pages 5 figures 2 tables
Subjects:
Strongly Correlated Electrons (cond-mat.str-el) ; Statistical Mechanics (cond-mat.stat-mech); Computational Physics (physics.comp-ph); Quantum Physics (quant-ph)
Cite as:  arXiv:0806.3719 [cond-mat.str-el]
(or  arXiv:0806.3719v1 [cond-mat.str-el] for this version)
https://doi.org/10.48550/arXiv.0806.3719
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Lett. 101, 090603 (2008)
Related DOI :
https://doi.org/10.1103/PhysRevLett.101.090603
Focus to learn more
DOI(s) linking to related resources
Submission history From: Tao Xiang [ view email ]  [v1]  Mon, 23 Jun 2008 16:36:26 UTC (179 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Accurate determination of tensor network state of quantum lattice models in two dimensions, by H. C. Jiang and 2 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.str-el
< prev
|  next >
new  |  recent  | 2008-06
Change to browse by:
cond-mat
cond-mat.stat-mech
physics
physics.comp-ph
quant-ph
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [38]: M. Lubasch et al. — Algorithms for finite projected entangled pair states (Phys. Rev. B 90, 064425, 2014)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Algorithms for finite projected entangled pair states
URL: https://doi.org/10.1103/PhysRevB.90.064425
Algorithms for finite projected entangled pair states | Phys. Rev. B
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review B
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Algorithms for finite projected entangled pair states
Michael Lubasch , J. Ignacio Cirac , and Mari-Carmen Bañuls  open icon
close icon
Max-Planck-Institut für Quantenoptik, Hans-Kopfermann-Straße 1, 85748 Garching, Germany
PDF Share open icon
close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. B 90 , 064425 – Published 25 August, 2014
DOI:https://doi.org/10.1103/PhysRevB.90.064425
Export Citation
182
Show metrics open icon
close icon
See more details
Posted by 1 X users
Mentioned in 1 Q&A threads
87 readers on Mendeley
182
CITATIONS
Abstract
Projected entangled pair states (PEPS) are a promising ansatz for the study of strongly correlated quantum many-body systems in two dimensions. However, due to their high computational cost, developing and improving PEPS algorithms is necessary to make the ansatz widely usable in practice. Here we analyze several algorithmic aspects of the method. On the one hand, we quantify the connection between the correlation length of the PEPS and the accuracy of its approximate contraction and discuss how purifications can be used in the latter. On the other hand, we present algorithmic improvements for the update of the tensor that introduce drastic gains in the numerical conditioning and the efficiency of the algorithms. Finally, the state-of-the-art general PEPS code is benchmarked with the Heisenberg and quantum Ising models on lattices of up to 2 1 × 2 1 sites.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (138)
Abstract
Article Text
References
Phys. Rev. B 90 , 064425 – Published 25 August, 2014
Vol. 90, Iss. 6 — 1 August 2014
Received 15 May 2014
Revised 8 August 2014
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.90.064425
©2014 American Physical Society
Outline Information
Outline
Citing Articles (138)
Abstract
Article Text
References
Information
Phys. Rev. B 90 , 064425 – Published 25 August, 2014
Vol. 90, Iss. 6 — 1 August 2014
Received 15 May 2014
Revised 8 August 2014
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.90.064425
©2014 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 2469-9969 (online), 2469-9950 (print). ©2026 American Physical Society. All rights reserved.  Physical Review B™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [39]: H. N. Phien et al. — Infinite projected entangled pair states algorithm improved (Phys. Rev. B 92, 035142, 2015)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Infinite projected entangled pair states algorithm improved
URL: https://doi.org/10.1103/PhysRevB.92.035142
Infinite projected entangled pair states algorithm improved: Fast full update and gauge fixing | Phys. Rev. B
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review B
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Infinite projected entangled pair states algorithm improved: Fast full update and gauge fixing
Ho N. Phien 1 , Johann A. Bengua 1 , Hoang D. Tuan 1 , Philippe Corboz 2 , and Román Orús 3  open icon
close icon
1 Centre for Health Technologies, Faculty of Engineering and Information Technology, University of Technology Sydney, Sydney, New South Wales 2007, Australia
2 Institute for Theoretical Physics, University of Amsterdam, Science Park 904 Postbus 94485, 1090 GL Amsterdam, Netherlands
3 Institute of Physics, Johannes Gutenberg University, 55099 Mainz, Germany
PDF Share open icon
close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. B 92 , 035142 – Published 24 July, 2015
DOI:https://doi.org/10.1103/PhysRevB.92.035142
Export Citation
219
Show metrics open icon
close icon
See more details
Posted by 2 X users
51 readers on Mendeley
219
CITATIONS
Abstract
The infinite projected entangled pair states (iPEPS) algorithm [J. Jordan et al. , Phys. Rev. Lett. 101 , 250602 (2008) ] has become a useful tool in the calculation of ground-state properties of two-dimensional quantum lattice systems in the thermodynamic limit. Despite its many successful implementations, the method has some limitations in its present formulation which hinder its application to some highly entangled systems. The purpose of this paper is to unravel some of these issues, in turn enhancing the stability and efficiency of iPEPS methods. For this, we first introduce the fast full update scheme, where effective environment and iPEPS tensors are both simultaneously updated (or evolved) throughout time. As we shall show, this implies two crucial advantages: (i) dramatic computational savings and (ii) improved overall stability. In addition, we extend the application of the local gauge fixing , successfully implemented for finite-size PEPS [M. Lubasch et al. , Phys. Rev. B 90 , 064425 (2014) ], to the iPEPS algorithm. We see that the gauge fixing not only further improves the stability of the method but also accelerates the convergence of the alternating least-squares sweeping in the (either “full” or “fast full”) tensor update scheme. The improvement in terms of computational cost and stability of the resulting “improved” iPEPS algorithm is benchmarked by studying the ground-state properties of the quantum Heisenberg and transverse-field Ising models on an infinite square lattice.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (165)
Abstract
Article Text
References
Phys. Rev. B 92 , 035142 – Published 24 July, 2015
Vol. 92, Iss. 3 — 15 July 2015
Received 18 March 2015
Revised 2 July 2015
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.92.035142
©2015 American Physical Society
Outline Information
Outline
Citing Articles (165)
Abstract
Article Text
References
Information
Phys. Rev. B 92 , 035142 – Published 24 July, 2015
Vol. 92, Iss. 3 — 15 July 2015
Received 18 March 2015
Revised 2 July 2015
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.92.035142
©2015 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 2469-9969 (online), 2469-9950 (print). ©2026 American Physical Society. All rights reserved.  Physical Review B™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [40]: Supplementary materials are available online
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: 
[Full text not available — the publication may be behind a paywall or the content could not be extracted from the web page. Only the abstract/metadata was accessible. Please consult the original publication via the DOI/URL above.]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [41]: I. A. Luchnikov et al. — Large-scale quantum annealing simulation with tensor networks and belief propagation (arXiv:2409.12240, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Large-scale quantum annealing simulation with tensor networks and belief propagation
URL: https://arxiv.org/abs/2409.12240
[2409.12240] Large-scale quantum annealing simulation with tensor networks and belief propagation
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2409.12240
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2409.12240 (quant-ph)
[Submitted on 18 Sep 2024 ( v1 ), last revised 12 Oct 2024 (this version, v2)]
Title: Large-scale quantum annealing simulation with tensor networks and belief propagation
Authors: Ilia A. Luchnikov , Egor S. Tiunov , Tobias Haug , Leandro Aolita
View a PDF of the paper titled Large-scale quantum annealing simulation with tensor networks and belief propagation, by Ilia A. Luchnikov and 3 other authors
View PDF  HTML (experimental)
Abstract: Quantum annealing and quantum approximate optimization algorithms hold a great potential to speed-up optimization problems. This could be game-changing for a plethora of applications. Yet, in order to hope to beat classical solvers, quantum circuits must scale up to sizes and performances much beyond current hardware. In that quest, intense experimental effort has been recently devoted to optimizations on 3-regular graphs, which are computationally hard but experimentally relatively amenable. However, even there, the amount and quality of quantum resources required for quantum solvers to outperform classical ones is unclear. Here, we show that quantum annealing for 3-regular graphs can be classically simulated even at scales of 1000 qubits and 5000000 two-qubit gates with all-to-all connectivity. To this end, we develop a graph tensor-network quantum annealer (GTQA) able of high-precision simulations of Trotterized circuits of near-adiabatic evolutions. Based on a recently proposed belief-propagation technique for tensor canonicalization, GTQA is equipped with re-gauging and truncation primitives that keep approximation errors small in spite of the circuits generating significant amounts of entanglement. As a result, even with a maximal bond dimension as low as 4, GTQA produces solutions competitive with those of state-of-the-art classical solvers. For non-degenerate instances, the unique solution can be read out from the final reduced single-qubit states. In contrast, for degenerate problems, such as MaxCut, we introduce an approximate measurement simulation algorithm for graph tensor-network states. On one hand, our findings showcase the potential of GTQA as a powerful quantum-inspired optimizer. On the other hand, they considerably raise the bar required for experimental demonstrations of quantum speed-ups in combinatorial optimizations.
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:2409.12240 [quant-ph]
(or  arXiv:2409.12240v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2409.12240
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Ilia Luchnikov [ view email ]  [v1]  Wed, 18 Sep 2024 18:00:08 UTC (5,537 KB)
[v2]  Sat, 12 Oct 2024 10:47:18 UTC (5,538 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Large-scale quantum annealing simulation with tensor networks and belief propagation, by Ilia A. Luchnikov and 3 other authors
View PDF
HTML (experimental)
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2024-09
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [42]: F. Verstraete, J. I. Cirac — Renormalization algorithms for quantum-many body systems in two and higher dimensions (arXiv:cond-mat/0407066, 2004)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Renormalization algorithms for quantum-many body systems in two and higher dimensions
URL: https://arxiv.org/abs/cond-mat/0407066
[cond-mat/0407066] Renormalization algorithms for Quantum-Many Body Systems in two and higher dimensions
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:cond-mat/0407066
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Strongly Correlated Electrons
arXiv:cond-mat/0407066 (cond-mat)
[Submitted on 2 Jul 2004]
Title: Renormalization algorithms for Quantum-Many Body Systems in two and higher dimensions
Authors: F. Verstraete , J. I. Cirac
View a PDF of the paper titled Renormalization algorithms for Quantum-Many Body Systems in two and higher dimensions, by F. Verstraete and 1 other authors
View PDF
Abstract: We describe quantum many--body systems in terms of projected entangled--pair states, which naturally extend matrix product states to two and more dimensions. We present an algorithm to determine correlation functions in an efficient way. We use this result to build powerful numerical simulation techniques to describe the ground state, finite temperature, and evolution of spin systems in two and higher dimensions.
Subjects:
Strongly Correlated Electrons (cond-mat.str-el) ; Quantum Physics (quant-ph)
Cite as:  arXiv:cond-mat/0407066 [cond-mat.str-el]
(or  arXiv:cond-mat/0407066v1 [cond-mat.str-el] for this version)
https://doi.org/10.48550/arXiv.cond-mat/0407066
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Ignacio Cirac [ view email ]  [v1]  Fri, 2 Jul 2004 13:09:17 UTC (170 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Renormalization algorithms for Quantum-Many Body Systems in two and higher dimensions, by F. Verstraete and 1 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.str-el
< prev
|  next >
new  |  recent  | 2004-07
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
2 blog links  ( what is this? )
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [43]: G. Evenbly et al. — Loop series expansions for tensor networks (arXiv:2409.03108, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Loop series expansions for tensor networks
URL: https://arxiv.org/abs/2409.03108
[2409.03108] Loop Series Expansions for Tensor Networks
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2409.03108
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2409.03108 (quant-ph)
[Submitted on 4 Sep 2024 ( v1 ), last revised 26 Mar 2025 (this version, v2)]
Title: Loop Series Expansions for Tensor Networks
Authors: Glen Evenbly , Nicola Pancotti , Ashley Milsted , Johnnie Gray , Garnet Kin-Lic Chan
View a PDF of the paper titled Loop Series Expansions for Tensor Networks, by Glen Evenbly and 4 other authors
View PDF  HTML (experimental)
Abstract: Belief propagation (BP) can be a useful tool to approximately contract a tensor network, provided that the contributions from any closed loops in the network are sufficiently weak. In this manuscript we describe how a loop series expansion can be applied to systematically improve the accuracy of a BP approximation to a tensor network contraction, in principle converging arbitrarily close to the exact result. More generally, our result provides a framework for expanding a tensor network as a sum of component networks in a hierarchy of increasing complexity. We benchmark this proposal for the contraction of iPEPS, either representing the ground state of an AKLT model or with randomly defined tensors, where it is shown to improve in accuracy over standard BP by several orders of magnitude whilst incurring only a minor increase in computational cost. These results indicate that the proposed series expansions could be a useful tool to accurately evaluate tensor networks in cases that otherwise exceed the limits of established contraction routines.
Comments:  Main text: 6 pages, 5 figures. Appendices: 8 pages, 7 figures. Revised version contains improved results and an additional appendix entry
Subjects:
Quantum Physics (quant-ph) ; Disordered Systems and Neural Networks (cond-mat.dis-nn)
Cite as:  arXiv:2409.03108 [quant-ph]
(or  arXiv:2409.03108v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2409.03108
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Research 8, 013245 (2026)
Related DOI :
https://doi.org/10.1103/vqks-cr6x
Focus to learn more
DOI(s) linking to related resources
Submission history From: Glen Evenbly [ view email ]  [v1]  Wed, 4 Sep 2024 22:22:35 UTC (2,079 KB)
[v2]  Wed, 26 Mar 2025 20:08:06 UTC (2,349 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Loop Series Expansions for Tensor Networks, by Glen Evenbly and 4 other authors
View PDF
HTML (experimental)
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2024-09
Change to browse by:
cond-mat
cond-mat.dis-nn
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [44]: D. B. Johnson — Finding all the elementary circuits of a directed graph (SIAM J. Comput. 4, 77-84, 1975)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Finding all the elementary circuits of a directed graph
URL: https://doi.org/10.1137/0204007
Johnson's algorithm - Wikipedia
Jump to content
Main menu
Main menu
move to sidebar  hide
Navigation
Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Contribute
Help
Learn to edit
Community portal
Recent changes
Upload file
Special pages
Search
Search
Appearance
Donate
Create account
Log in
Personal tools
Donate
Create account
Log in
Contents
move to sidebar  hide
(Top)
1  Algorithm description
2  Example
3  Correctness
4  Analysis
5  References
6  External links
Toggle the table of contents
Johnson's algorithm
15 languages
Čeština
Español
فارسی
Français
עברית
Magyar
日本語
Polski
Português
Русский
Српски / srpski
ไทย
Türkçe
Українська
Tiếng Việt
Edit links
Article
Talk
English
Read
Edit
View history
Tools
Tools
move to sidebar  hide
Actions
Read
Edit
View history
General
What links here
Related changes
Upload file
Permanent link
Page information
Cite this page
Get shortened URL
Expand all
Edit interlanguage links
Print/export
Download as PDF
Printable version
In other projects
Wikimedia Commons
Wikidata item
Appearance
move to sidebar  hide
Text
Small
Standard
Large
This page always uses small font size
Width
Standard
Wide
The content is as wide as possible for your browser window.
Color
Automatic
Light
Dark
This page is always in light mode.
From Wikipedia, the free encyclopedia
Method to find shortest paths
For the scheduling algorithm of the same name, see Job shop scheduling .
Johnson's algorithm  Class All-pairs shortest path problem (for weighted graphs)
Data structure Graph
Worst-case performance
O  (
|
V
|
2
log  ⁡
|
V
|
+
|
V
|
|
E
|
)
{\displaystyle O(|V|^{2}\log |V|+|V||E|)}
Johnson's algorithm is a way to find the shortest paths between all pairs of vertices in an edge-weighted directed graph . It allows some of the edge weights to be negative numbers , but no negative-weight cycles may exist. It works by using the Bellman–Ford algorithm to compute a transformation of the input graph that removes all negative weights, allowing Dijkstra's algorithm to be used on the transformed graph. [ 1 ] [ 2 ] It is named after Donald B. Johnson , who first published the technique in 1977. [ 3 ]
A similar reweighting technique is also used in a version of the successive shortest paths algorithm for the minimum cost flow problem due to Edmonds and Karp, [ 4 ] as well as in Suurballe's algorithm for finding two disjoint paths of minimum total length between the same two vertices in a graph with non-negative edge weights. [ 5 ]
Algorithm description [ edit ]
Johnson's algorithm consists of the following steps: [ 1 ] [ 2 ]
First, a new node q is added to the graph, connected by zero-weight edges to each of the other nodes.
Second, the Bellman–Ford algorithm is used, starting from the new vertex q , to find for each vertex v the minimum weight h ( v ) of a path from q to v . If this step detects a negative cycle, the algorithm is terminated.
Next the edges of the original graph are reweighted using the values computed by the Bellman–Ford algorithm: an edge from u to v , having length ⁠
w  (  u  ,  v  )
{\displaystyle w(u,v)}
⁠ , is given the new length w ( u , v ) + h ( u ) − h ( v ) .
Finally, q is removed, and Dijkstra's algorithm is used to find the shortest paths from each node s to every other vertex in the reweighted graph. The distance in the original graph is then computed for each distance D ( u , v ), by adding h ( v ) − h ( u ) to the distance returned by Dijkstra's algorithm.
Example [ edit ]
The first three stages of Johnson's algorithm are depicted in the illustration below.
The graph on the left of the illustration has two negative edges, but no negative cycles. The center graph shows the new vertex q , a shortest path tree as computed by the Bellman–Ford algorithm with q as starting vertex, and the values h ( v ) computed at each other node as the length of the shortest path from q to that node. Note that these values are all non-positive, because q has a length-zero edge to each vertex and the shortest path can be no longer than that edge. On the right is shown the reweighted graph, formed by replacing each edge weight ⁠
w  (  u  ,  v  )
{\displaystyle w(u,v)}
⁠ by w ( u , v ) + h ( u ) − h ( v ) . In this reweighted graph, all edge weights are non-negative, but the shortest path between any two nodes uses the same sequence of edges as the shortest path between the same two nodes in the original graph. The algorithm concludes by applying Dijkstra's algorithm to each of the four starting nodes in the reweighted graph.
Correctness [ edit ]
In the reweighted graph, all paths between a pair s and t of nodes have the same quantity h ( s ) − h ( t ) added to them. The previous statement can be proven as follows: Let p be an ⁠
s  −  t
{\displaystyle s-t}
⁠ path. Its weight W in the reweighted graph is given by the following expression:
(
w  (  s  ,
p
1
)  +  h  (  s  )  −  h  (
p
1
)
)
+
(
w  (
p
1
,
p
2
)  +  h  (
p
1
)  −  h  (
p
2
)
)
+  .  .  .  +
(
w  (
p
n
,  t  )  +  h  (
p
n
)  −  h  (  t  )
)
.
{\displaystyle \left(w(s,p_{1})+h(s)-h(p_{1})\right)+\left(w(p_{1},p_{2})+h(p_{1})-h(p_{2})\right)+...+\left(w(p_{n},t)+h(p_{n})-h(t)\right).}
Every
+  h  (
p
i
)
{\displaystyle +h(p_{i})}
is cancelled by
−  h  (
p
i
)
{\displaystyle -h(p_{i})}
in the previous bracketed expression; therefore, we are left with the following expression for W :
(
w  (  s  ,
p
1
)  +  w  (
p
1
,
p
2
)  +  ⋯  +  w  (
p
n
,  t  )
)
+  h  (  s  )  −  h  (  t  )
{\displaystyle \left(w(s,p_{1})+w(p_{1},p_{2})+\cdots +w(p_{n},t)\right)+h(s)-h(t)}
The bracketed expression is the weight of p in the original weighting.
Since the reweighting adds the same amount to the weight of every ⁠
s  −  t
{\displaystyle s-t}
⁠ path, a path is a shortest path in the original weighting if and only if it is a shortest path after reweighting. The weight of edges that belong to a shortest path from q to any node is zero, and therefore the lengths of the shortest paths from q to every node become zero in the reweighted graph; however, they still remain shortest paths. Therefore, there can be no negative edges: if edge uv had a negative weight after the reweighting, then the zero-length path from q to u together with this edge would form a negative-length path from q to v , contradicting the fact that all vertices have zero distance from q . The non-existence of negative edges ensures the optimality of the paths found by Dijkstra's algorithm. The distances in the original graph may be calculated from the distances calculated by Dijkstra's algorithm in the reweighted graph by reversing the reweighting transformation. [ 1 ]
Analysis [ edit ]
The time complexity of this algorithm, using Fibonacci heaps in the implementation of Dijkstra's algorithm, is
O  (
|
V
|
2
log  ⁡
|
V
|
+
|
V
|
|
E
|
)
{\displaystyle O(|V|^{2}\log |V|+|V||E|)}
: the algorithm uses
O  (
|
V
|
|
E
|
)
{\displaystyle O(|V||E|)}
time for the Bellman–Ford stage of the algorithm, and
O  (
|
V
|
log  ⁡
|
V
|
+
|
E
|
)
{\displaystyle O(|V|\log |V|+|E|)}
for each of the
|
V
|
{\displaystyle |V|}
instantiations of Dijkstra's algorithm. Thus, when the graph is sparse , the total time can be faster than the Floyd–Warshall algorithm , which solves the same problem in time
O  (
|
V
|
3
)
{\displaystyle O(|V|^{3})}
. [ 1 ]
References [ edit ]
^ Jump up to: a b c d Cormen, Thomas H. ; Leiserson, Charles E. ; Rivest, Ronald L. ; Stein, Clifford (2001), Introduction to Algorithms , MIT Press and McGraw-Hill, ISBN 978-0-262-03293-3 . Section 25.3, "Johnson's algorithm for sparse graphs", pp. 636–640.
^ Jump up to: a b  Black, Paul E. (2004), "Johnson's Algorithm", Dictionary of Algorithms and Data Structures , National Institute of Standards and Technology .
^  Johnson, Donald B. (1977), "Efficient algorithms for shortest paths in sparse networks", Journal of the ACM , 24 (1): 1– 13, doi : 10.1145/321992.321993 , S2CID 207678246 .
^  Edmonds, J.; Karp, Richard M. (1972), "Theoretical Improvements in Algorithmic Efficiency for Network Flow Problems", Journal of the ACM , 19 (2): 248– 264, doi : 10.1145/321694.321699 .
^  Suurballe, J. W. (1974), "Disjoint paths in a network", Networks , 14 (2): 125– 145, doi : 10.1002/net.3230040204 .
External links [ edit ]
Boost: All Pairs Shortest Paths
hide
v
t
e
Graph and tree traversal algorithms
Search
α–β pruning
A*
IDA*
LPA*
SMA*
Best-first search
Beam search
Bidirectional search
Breadth-first search
Lexicographic
Parallel
B*
Depth-first search
Iterative deepening
D*
Fringe search
Jump point search
Monte Carlo tree search
SSS*
Shortest path
Bellman–Ford
Dijkstra's
Floyd–Warshall
Johnson's
Shortest path faster
Yen's
Minimum spanning tree
Borůvka's
Kruskal's
Prim's
Reverse-delete
List of graph search algorithms
Retrieved from " https://en.wikipedia.org/w/index.php?title=Johnson%27s_algorithm&oldid=1321323800 "
Categories :  Graph algorithms
Search algorithms
Graph distance
Hidden categories:  Articles with short description
S... [truncated]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [45]: J. Fairbanks et al. — JuliaGraphs/Graphs.jl: An optimized graphs package for the Julia programming language (2021)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: JuliaGraphs/Graphs.jl: An optimized graphs package for the Julia programming language
URL: https://github.com/JuliaGraphs/Graphs.jl
GitHub - JuliaGraphs/Graphs.jl: An optimized graphs package for the Julia programming language · GitHub
Skip to content
Navigation Menu
Toggle navigation
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE  Why GitHub
Documentation
Blog
Changelog
Marketplace
View all features
Solutions
BY COMPANY SIZE  Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE  App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY  Healthcare
Financial services
Manufacturing
Government
View all industries
View all solutions
Resources
EXPLORE BY TOPIC  AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE  Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES  Documentation
Customer support
Community forum
Trust center
Partners
View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS  Security Lab
Maintainer Community
Accelerator
GitHub Stars
Archive Program
REPOSITORIES  Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
-->
Search
Clear
Search syntax tips
Provide feedback
-->
We read every piece of feedback, and take your input very seriously.
Include my email address so I can be contacted
Cancel
Submit feedback
Saved searches
Use saved searches to filter your results more quickly
-->
Name
Query
To see all available qualifiers, see our documentation .
Cancel
Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session.  You signed out in another tab or window. Reload to refresh your session.  You switched accounts on another tab or window. Reload to refresh your session.
Dismiss alert
{{ message }}
JuliaGraphs
/
Graphs.jl
Public
Notifications You must be signed in to change notification settings
Fork 124
Star 531
Code
Issues  114
Pull requests  27
Discussions
Actions
Security and quality  0
Insights
Additional navigation options
Code
Issues
Pull requests
Discussions
Actions
Security and quality
Insights
JuliaGraphs/Graphs.jl
master
7 Branches
31 Tags
Go to file
Code
Open more actions menu
Folders and files
Name Name  Last commit message
Last commit date
Latest commit
dependabot[bot]
Bump julia-actions/setup-julia from 2 to 3 ( #514 )
Open commit details
success  May 8, 2026
d153227 · May 8, 2026
History
2,362 Commits
Open commit details
2,362 Commits
.github
.github
Bump julia-actions/setup-julia from 2 to 3 ( #514 )
May 8, 2026
benchmark
benchmark
Optimize diameter calculation for weighted graphs ( #495 )
Apr 6, 2026
docs
docs
ECG Community Detection implementation ( #502 )
Apr 27, 2026
ext
ext
Add GraphsSharedArraysExt and remove Distributed dependency ( #430 )
Oct 17, 2025
src
src
ECG Community Detection implementation ( #502 )
Apr 27, 2026
test
test
ECG Community Detection implementation ( #502 )
Apr 27, 2026
.JuliaFormatter.toml
.JuliaFormatter.toml
Uniform code style ( #190 )
Nov 21, 2022
.git-blame-ignore-revs
.git-blame-ignore-revs
add old formatting commits to git blame ignore file ( #474 )
Nov 30, 2025
.gitignore
.gitignore
use /test/Project.toml instead of [extras] in /Project.toml ( #436 )
Aug 16, 2025
CHANGELOG.md
CHANGELOG.md
ECG Community Detection implementation ( #502 )
Apr 27, 2026
CITATION.bib
CITATION.bib
Update CITATION.bib ( #158 )
Jul 24, 2022
CONTRIBUTING.md
CONTRIBUTING.md
Add ColPrac badge to README and a mention in CONTRIBUTING ( #312 )
Oct 30, 2023
LICENSE.md
LICENSE.md
Hierarchical documentation structure ( #114 )
Mar 11, 2022
Project.toml
Project.toml
version bump for 1.14.0 ( #501 )
Feb 27, 2026
README.md
README.md
Add CHANGELOG.md and changelog enforcer workflow ( #494 )
Feb 23, 2026
View all files
Repository files navigation
README
Contributing
License
Graphs.jl
Overview
The goal of Graphs.jl is to offer a performant platform for network and graph analysis in Julia, following the example of libraries such as NetworkX in Python. To this end, Graphs.jl offers:
a set of simple, concrete graph implementations -- SimpleGraph (for undirected graphs) and SimpleDiGraph (for directed graphs)
an API for the development of more sophisticated graph implementations under the AbstractGraph type
a large collection of graph algorithms with the same requirements as this API.
Installation
Installation is straightforward. First, enter Pkg mode by hitting ] , and then run the following command:
pkg> add Graphs
Basic use
Graphs.jl includes numerous convenience functions for generating graphs, such as path_graph , which builds a simple undirected path graph of a given length. Once created, these graphs can be easily interrogated and modified.
julia> g = path_graph ( 6 ){6, 5} undirected simple Int64 graph
# Number of verticesjulia> nv (g)6
# Number of edgesjulia> ne (g)5
# Add an edge to make the path a loopjulia> add_edge! (g, 1 , 6 );
Documentation
The full documentation is available at GitHub Pages . Documentation for methods is also available via the Julia REPL help system.Additional tutorials can be found at JuliaGraphsTutorials .
Citing
We encourage you to cite our work if you have used our libraries, tools or datasets. Starring the Graphs.jl repository on GitHub is also appreciated.
The latest citation information may be found in the CITATION.bib file within the repository.
Contributing
We welcome contributions and bug reports!Please see CONTRIBUTING.md for guidance on development and bug reporting.
JuliaGraphs development subscribes to the Julia Community Standards .
Related packages
It is an explicit design decision that any data not required for graph manipulation (attributes and other information, for example) is expected to be stored outside of the graph structure itself.
Additional functionality like advanced IO and file formats, weighted graphs, property graphs, and optimization-related functions can be found in the packages of the JuliaGraphs organization .
Project history
Graphs.jl is the successor to LightGraphs.jl (archived October 2021); see the CHANGELOG for the full transition history.
About
An optimized graphs package for the Julia programming language
juliagraphs.org/Graphs.jl/
Topics
datastructures
graph
graph-algorithms
graphs
julia
data-structures
graph-theory
graph-analytics
hacktoberfest
juliagraphs
Resources
Readme
License
View license
Contributing
Contributing
Citation
Cite this repository
Loading
Something went wrong.
Uh oh!
There was an error while loading. Please reload this page .
Activity
Custom properties
Stars
531  stars
Watchers
9  watching
Forks
124  forks
Report repository
Releases 30
v1.14.0
Latest
Feb 27, 2026
+ 29 releases
Uh oh!
There was an error while loading. Please reload this page .
Contributors 90
+ 76 contributors
Languages
Julia  100.0%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can’t perform that action at this time.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [46]: J. Haegeman et al. — Time-dependent variational principle for quantum lattices (Phys. Rev. Lett. 107, 070601, 2011)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Time-dependent variational principle for quantum lattices
URL: https://doi.org/10.1103/PhysRevLett.107.070601
[1103.0936] Time-dependent variational principle for quantum lattices
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cond-mat > arXiv:1103.0936
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Condensed Matter > Strongly Correlated Electrons
arXiv:1103.0936 (cond-mat)
[Submitted on 4 Mar 2011 ( v1 ), last revised 26 May 2011 (this version, v2)]
Title: Time-dependent variational principle for quantum lattices
Authors: Jutho Haegeman , J. Ignacio Cirac , Tobias J. Osborne , Iztok Pizorn , Henri Verschelde , Frank Verstraete
View a PDF of the paper titled Time-dependent variational principle for quantum lattices, by Jutho Haegeman and 4 other authors
View PDF
Abstract: We develop a new algorithm based on the time-dependent variational principle applied to matrix product states to efficiently simulate the real- and imaginary time dynamics for infinite one-dimensional quantum lattice systems. This procedure: (1) is argued to be optimal; (2) does not rely on the Trotter decomposition and thus has no Trotter error; (3) explicitly preserves all symmetries and conservation laws; and (4) has low computational complexity. The algorithm is illustrated using both imaginary time and real-time examples.
Comments:  main text (4+ pages, 2 figures, 1 table) + supplementary material (15 pages, 2 figures). Corrections and other small changes, added reference
Subjects:
Strongly Correlated Electrons (cond-mat.str-el) ; Statistical Mechanics (cond-mat.stat-mech); Quantum Physics (quant-ph)
Cite as:  arXiv:1103.0936 [cond-mat.str-el]
(or  arXiv:1103.0936v2 [cond-mat.str-el] for this version)
https://doi.org/10.48550/arXiv.1103.0936
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  Phys. Rev. Lett. 107, 070601 (2011)
Related DOI :
https://doi.org/10.1103/PhysRevLett.107.070601
Focus to learn more
DOI(s) linking to related resources
Submission history From: Jutho Haegeman [ view email ]  [v1]  Fri, 4 Mar 2011 16:04:31 UTC (554 KB)
[v2]  Thu, 26 May 2011 14:58:34 UTC (569 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Time-dependent variational principle for quantum lattices, by Jutho Haegeman and 4 other authors
View PDF
TeX Source
view license
Current browse context:
cond-mat.str-el
< prev
|  next >
new  |  recent  | 2011-03
Change to browse by:
cond-mat
cond-mat.stat-mech
quant-ph
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
IArxiv recommender toggle
IArxiv Recommender  ( What is IArxiv? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [47]: A. D. King et al. — Quantum critical dynamics in a 5,000-qubit programmable spin glass (Nature 617, 61-66, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Quantum critical dynamics in a 5,000-qubit programmable spin glass
URL: https://doi.org/10.1038/s41586-023-05867-2
Quantum critical dynamics in a 5,000-qubit programmable spin glass | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Subscribe
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Subscribe
Sign up for alerts
RSS feed
nature
articles
article
Article
Published: 19 April 2023
Quantum critical dynamics in a 5,000-qubit programmable spin glass
Andrew D. King  ORCID: orcid.org/0000-0001-8362-8941 1 ,
Jack Raymond 1 ,
Trevor Lanting 1 ,
Richard Harris 1 ,
Alex Zucca 1 ,
Fabio Altomare 1 ,
Andrew J. Berkley  ORCID: orcid.org/0000-0002-4235-8452 1 ,
Kelly Boothby 1 ,
Sara Ejtemaee 1 ,
Colin Enderud 1 ,
Emile Hoskinson 1 ,
Shuiyuan Huang  ORCID: orcid.org/0000-0001-9799-1872 1 ,
Eric Ladizinsky 1 ,
Allison J. R. MacDonald 1 ,
Gaelen Marsden 1 ,
Reza Molavi 1 ,
Travis Oh 1 ,
Gabriel Poulin-Lamarre  ORCID: orcid.org/0000-0002-2602-6255 1 ,
Mauricio Reis 1 ,
Chris Rich  ORCID: orcid.org/0000-0001-8989-3199 1 ,
Yuki Sato 1 ,
Nicholas Tsai 1 ,
Mark Volkmann 1 ,
Jed D. Whittaker  ORCID: orcid.org/0000-0002-0456-3244 1 ,
Jason Yao 1 ,
Anders W. Sandvik 2 &
…
Mohammad H. Amin 1 , 3  Show authors
Nature
volume 617 , pages 61–66 ( 2023 ) Cite this article
16k Accesses
247 Citations
325 Altmetric
Metrics details
Abstract
Experiments on disordered alloys 1 , 2 , 3 suggest that spin glasses can be brought into low-energy states faster by annealing quantum fluctuations than by conventional thermal annealing. Owing to the importance of spin glasses as a paradigmatic computational testbed, reproducing this phenomenon in a programmable system has remained a central challenge in quantum optimization 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 . Here we achieve this goal by realizing quantum-critical spin-glass dynamics on thousands of qubits with a superconducting quantum annealer. We first demonstrate quantitative agreement between quantum annealing and time evolution of the Schrödinger equation in small spin glasses. We then measure dynamics in three-dimensional spin glasses on thousands of qubits, for which classical simulation of many-body quantum dynamics is intractable. We extract critical exponents that clearly distinguish quantum annealing from the slower stochastic dynamics of analogous Monte Carlo algorithms, providing both theoretical and experimental support for large-scale quantum simulation and a scaling advantage in energy optimization.
Access through your institution
Buy or subscribe
This is a preview of subscription content, access via your institution
Access options
Access through your institution
Access Nature and 54 other Nature Portfolio journals
Get Nature+, our best-value online-access subscription
$32.99 / 30 days
cancel any time
Learn more
Subscribe to this journal
Receive 52 print issues and online access
$199.00 per year
only $3.83 per issue
Learn more
Buy this article
Purchase on SpringerLink
Instant access to the full article PDF.
USD 39.95
Prices may be subject to local taxes which are calculated during checkout
Additional access options:
Log in
Learn about institutional subscriptions
Read our FAQs
Contact customer support
Fig. 1: Programmable quantum spin glasses.
The alternative text for this image may have been generated using AI.
Fig. 2: Coherent Schrödinger dynamics.
The alternative text for this image may have been generated using AI.
Fig. 3: Dynamic finite-size scaling in 3D spin glasses.
The alternative text for this image may have been generated using AI.
Fig. 4: Critical scaling of final residual energy.
The alternative text for this image may have been generated using AI.
Similar content being viewed by others
Cyclic quantum annealing: searching for deep low-energy states in 5000-qubit spin glass
Article  Open access  28 December 2024
Coherent quantum annealing in a programmable 2,000 qubit Ising chain
Article
15 September 2022
Non-equilibrium quantum domain reconfiguration dynamics in a two-dimensional electronic crystal and a quantum annealer
Article  Open access  06 June 2024
Data availability
Data supporting the findings are available in the Zenodo online repository https://doi.org/10.5281/zenodo.7640779 .
Code availability
An open-source version of the SQA code used in this work is available at https://github.com/dwavesystems/dwave-pimc .
References
Brooke, J., Bitko, D., Rosenbaum, T. F. & Aeppli, G. Quantum annealing of a disordered magnet. Science 284 , 779–781 (1999).
Article  ADS  CAS  PubMed
Google Scholar
Aeppli, G. & Rosenbaum, T. F. in Quantum Annealing and Related Optimization Methods (eds Das, A. & Chakrabarti, B.) Ch. 6 (Springer, 2005).
Das, A. & Chakrabarti, B. K. Colloquium: quantum annealing and analog quantum computation. Rev. Mod. Phys. 80 , 1061–1081 (2008).
Article  ADS  MathSciNet  MATH
Google Scholar
Kadowaki, T. & Nishimori, H. Quantum annealing in the transverse Ising model. Phys. Rev. E 58 , 5355 (1998).
Article  ADS  CAS
Google Scholar
Santoro, G. E., Martonák, R., Tosatti, E. & Car, R. Theory of quantum annealing of an Ising spin glass. Science 295 , 2427–2430 (2002).
Article  ADS  CAS  PubMed
Google Scholar
Harris, R. et al. Experimental investigation of an eight-qubit unit cell in a superconducting optimization processor. Phys. Rev. B 82 , 024511 (2010).
Article  ADS
Google Scholar
Rønnow, T. F. et al. Defining and detecting quantum speedup. Science 345 , 420–424 (2014).
Article  ADS  PubMed
Google Scholar
Katzgraber, H. G., Hamze, F. & Andrist, R. S. Glassy chimeras could be blind to quantum speedup: designing better benchmarks for quantum annealing machines. Phys. Rev. X 4 , 021008 (2014).
Google Scholar
Hen, I. et al. Probing for quantum speedup in spin-glass problems with planted solutions. Phys. Rev. A 92 , 042325 (2015).
Article  ADS
Google Scholar
Heim, B., Rønnow, T. F., Isakov, S. V. & Troyer, M. Quantum versus classical annealing of Ising spin glasses. Science 348 , 215–217 (2015).
Article  ADS  MathSciNet  CAS  PubMed  MATH
Google Scholar
Boixo, S. et al. Computational multiqubit tunnelling in programmable quantum annealers. Nat. Commun. 7 , 10327 (2016).
Article  ADS  CAS  PubMed  PubMed Central
Google Scholar
Denchev, V. S. et al. What is the computational value of finite-range tunneling? Phys. Rev. X 6 , 031015 (2016).
Google Scholar
Albash, T. & Lidar, D. A. Demonstration of a scaling advantage for a quantum annealer over simulated annealing. Phys. Rev. X 8 , 031016 (2018).
CAS
Google Scholar
Mezard M. & Montanari, A. Information, Physics, and Computation (Oxford Univ. Press, 2009).
Stein, D. L. & Newman, C. M. Spin Glasses and Complexity (Princeton Univ. Press, 2013).
Kirkpatrick, S., Gelatt, C. D. & Vecchi, M. P. Optimization by simulated annealing. Science 220 , 671–680 (1983).
Article  ADS  MathSciNet  CAS  PubMed  MATH
Google Scholar
Tan, C. M. (ed.) Simulated Annealing (InTech, 2008).
Albash, T. & Lidar, D. A. Adiabatic quantum computation. Rev. Mod. Phys. 90 , 015002 (2018).
Article  ADS  MathSciNet
Google Scholar
Arnab Das, A. & Chakrabarti, B. (eds) Quantum Annealing and Related Optimization Methods (Springer, 2005).
Feynman, R. P. Simulating physics with computers. Int. J. Theor. Phys. 21 , 467–488 (1982).
Article  MathSciNet
Google Scholar
Johnson, M. W. et al. Quantum annealing with manufactured spins. Nature 473 , 194–198 (2011).
Article  ADS  CAS  PubMed
Google Scholar
Lechner, W., Hauke, P. & Zoller, P. A quantum annealing architecture with all-to-all connectivity from local interactions. Sci. Adv. 1 , e15008 (2015).
Article
Google Scholar
Weber, S. J. et al. Coherent coupled qubits for quantum annealing. Phys. Rev. Appl. 8 , 014004 (2017).... [truncated]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [48]: K. Trachenko, A. Zaccone — Slow stretched-exponential and fast compressed-exponential relaxation (J. Phys. Condens. Matter 33, 315101, 2021)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Slow stretched-exponential and fast compressed-exponential relaxation
URL: https://doi.org/10.1088/1361-648X/ac04cd
Slow stretched-exponential and fast compressed-exponential relaxation from local event dynamics - IOPscience
We value your privacy
We and our 3 partners use cookies and other tracking technologies to improve your experience on our website. We may store and/or access information on a device and process personal data, such as your IP address and browsing data, for personalised advertising and content, advertising and content measurement, audience research and services development. Additionally, we may utilize precise geolocation data and identification through device scanning.
Please note that your choices apply across all our subdomains. Once you give consent, a floating button will appear at the bottom of your screen, allowing you to change or withdraw your consent at any time. We respect your choices and are committed to providing you with a transparent and secure browsing experience. Privacy and Cookies policy
Customize Accept All
Customize Consent Preferences
Customise your consent preferences for Cookie Categories and advertising tracking preferences for Purposes & Features and Vendors below. You can give granular consent for each Third Party Vendor . Most vendors require explicit consent for personal data processing, while some rely on legitimate interest. However, you have the right to object to their use of legitimate interest. Additionally, please note that your preferences regarding purposes and vendors are saved in a cookie named 'euconsent' on your device and may be retained for up to 730 days to remember your choices.
Cookie Categories
Purposes & Features
Vendors
Cookie Categories
We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.
The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ... Show more
Necessary Always Active
Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.
Cookie
__uzma
Duration
6 months
Description
No description available.
Cookie
__uzmb
Duration
6 months
Description
No description available.
Cookie
__uzme
Duration
6 months
Description
No description available.
Cookie
IOP_session_live
Duration
session
Description
No description available.
Cookie
__ssds
Duration
6 months
Description
No description available.
Cookie
__ssuzjsr2
Duration
6 months
Description
No description available.
Cookie
__uzmaj2
Duration
6 months
Description
No description available.
Cookie
__uzmbj2
Duration
6 months
Description
No description available.
Cookie
__uzmcj2
Duration
6 months
Description
No description available.
Cookie
__uzmdj2
Duration
6 months
Description
No description available.
Cookie
__uzmd
Duration
6 months
Description
This cookie is set by the provider ShieldSquare. This is a performance and monitoring cookie used for distinguishing bot and scraper traffic.
Cookie
AWSALBCORS
Duration
7 days
Description
Amazon Web Services set this cookie for load balancing.
Cookie
JSESSIONID
Duration
session
Description
New Relic uses this cookie to store a session identifier so that New Relic can monitor session counts for an application.
Cookie
__uzmc
Duration
6 months
Description
This cookie is set by the provider ShieldSquare. This is a performance and monitoring cookie used for distinguishing bot and scraper traffic.
Cookie
AWSALB
Duration
7 days
Description
AWSALB is an application load balancer cookie set by Amazon Web Services to map the session to the target.
Cookie
__cf_bm
Duration
1 hour
Description
This cookie, set by Cloudflare, is used to support Cloudflare Bot Management.
Cookie
PHPSESSID
Duration
session
Description
This cookie is native to PHP applications. The cookie stores and identifies a user's unique session ID to manage user sessions on the website. The cookie is a session cookie and will be deleted when all the browser windows are closed.
Cookie
cookieyes-consent
Duration
1 year
Description
CookieYes sets this cookie to remember users' consent preferences so that their preferences are respected on subsequent visits to this site. It does not collect or store any personal information about the site visitors.
Cookie
__uzmf
Duration
6 months
Description
Description is currently not available.
Cookie
uzmx
Duration
6 months
Description
Description is currently not available.
Cookie
_cfuvid
Duration
session
Description
Calendly sets this cookie to track users across sessions to optimize user experience by maintaining session consistency and providing personalized services
Cookie
TiPMix
Duration
1 hour
Description
The TiPMix cookie is set by Azure to determine which web server the users must be directed to.
Cookie
x-ms-routing-name
Duration
1 hour
Description
Azure sets this cookie for routing production traffic by specifying the production slot.
Cookie
euconsent
Duration
1 year
Description
CookieYes sets this cookie to store data when IAB TCF is enabled.
Cookie
rc::h
Duration
Never Expires
Description
This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks.
Cookie
rc::e
Duration
session
Description
This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks.
Cookie
uzmxj
Duration
6 months
Description
Description is currently not available.
Cookie
__ssuzjsr0
Duration
6 months
Description
Description is currently not available.
Cookie
__uzmaj0
Duration
6 months
Description
Description is currently not available.
Cookie
__uzmbj0
Duration
6 months
Description
Description is currently not available.
Cookie
__uzmcj0
Duration
6 months
Description
Description is currently not available.
Cookie
__uzmdj0
Duration
6 months
Description
Description is currently not available.
Cookie
__uzmlj0
Duration
6 months
Description
Description is currently not available.
Cookie
__uzmfj0
Duration
6 months
Description
Description is currently not available.
Functional
Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.
Cookie
issuem_lp
Duration
1 month
Description
No description available.
Cookie
ytidb::LAST_RESULT_ENTRY_KEY
Duration
Never Expires
Description
The cookie ytidb::LAST_RESULT_ENTRY_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future.
Cookie
__Secure-YEC
Duration
past
Description
Description is currently not available.
Cookie
__Secure-YNID
Duration
6 months
Description
Google cookie used to protect user security and prevent fraud, especially during the login process.
Analytics
Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.
Cookie
_ga_*
Duration
1 year 1 month 4 days
Description
Google Analytics sets this cookie to store and count page views.
Cookie
_ga
Duration
1 year 1 month 4 days
Description
Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors.
Cookie
_hjSessionUser_*
Duration
1 year
Description
Hotjar sets this cookie to ensure data from subsequent visits to the same site is attributed to the same user ID, which persists in the Hotjar User ID, which is unique to that site.
Cookie
_hjSession_*
Duration
1 hour
Description
Hotjar sets this cookie to ensure data from subsequent visits to the same site is attributed to the same user ID, which persists in the Hotjar User ID, which is unique to that site.
Cookie
pardot
Duration
past
Description
The pardot cookie is set while the visitor is logged in as a Pardot user. The cookie indicates an active session and is not used for tracking.
Cookie
_hjTLDTest
Duration
session
Description
To determine the most generic cookie path that has to be used instead of the page hostname, Hotjar sets the _hjTLDTest cookie to store different URL substring alternatives until it fails.
Cookie
vuid
Duration
1 year 1 month 4 days
Description
Vimeo installs this cookie to collect tracking information by setting a unique ID to embed videos on the website.
Cookie
_clck
Duration
1 year
Description
Microsoft Clarity sets this cookie to retain the browser's Clarity User ID and settings exclusive to that website. This guarantees that actions taken during subsequent visits to the same website will be linked to the same user ID.
Cookie
_clsk
Duration
1 day
Description
Microsoft Clarity sets this cookie to store and consolidate a user's pageviews into a single session recording.
Performance
Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.
No cookies to display.
Advertisement
Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.
Cookie
__eoi
Duration
6 months
Description
Description is currently not available.
Cookie
test_cookie
Duration
15 minutes
Description
doubleclick.net sets this cookie to determine if the user's browser su... [truncated]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [49]: Z. W. Wu et al. — Stretched and compressed exponentials in the relaxation dynamics of a metallic glass-forming melt (Nat. Commun. 9, 5334, 2018)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Stretched and compressed exponentials in the relaxation dynamics of a metallic glass-forming melt
URL: https://doi.org/10.1038/s41467-018-07759-w
Stretched and compressed exponentials in the relaxation dynamics of a metallic glass-forming melt | Nature Communications
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
Reviews & Analysis
News & Comment
Videos
Collections
Subjects
Follow us on Facebook
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Aims & Scope
Editors
Journal Information
Open Access Fees and Funding
Calls for Papers
Editorial Values Statement
Journal Metrics
Editors' Highlights
Contact
Editorial policies
Top Articles
Publish with us
Publish with us
For authors
For Reviewers
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
nature communications
articles
article
Stretched and compressed exponentials in the relaxation dynamics of a metallic glass-forming melt
Download PDF
Download PDF
Article
Open access
Published: 17 December 2018
Stretched and compressed exponentials in the relaxation dynamics of a metallic glass-forming melt
Zhen Wei Wu  ORCID: orcid.org/0000-0002-1395-2380 1 , 2 ,
Walter Kob  ORCID: orcid.org/0000-0001-7405-2178 3 ,
Wei-Hua Wang 4 &
…
Limei Xu 1 , 5  Show authors
Nature Communications
volume 9 , Article number: 5334 ( 2018 ) Cite this article
12k Accesses
100 Citations
1 Altmetric
Metrics details
Abstract
The dynamics of glass-forming systems shows a multitude of features that are absent in normal liquids, such as non-exponential relaxation and a strong temperature-dependence of the relaxation time. Connecting these dynamic properties to the microscopic structure of the system is challenging because of the presence of the structural disorder. Here we use computer simulations of a metallic glass-former to establish such a connection. By probing the temperature and wave-vector dependence of the intermediate scattering function we find that the relaxation dynamics of the glassy melt is directly related to the local arrangement of icosahedral structures: Isolated icosahedra give rise to a liquid-like stretched exponential relaxation whereas clusters of icosahedra lead to a compressed exponential relaxation that is reminiscent to the one found in a solid. Our results show that in metallic glass-formers these two types of relaxation processes can coexist and give rise to a dynamics that is surprisingly complex.
Similar content being viewed by others
Distinct relaxation mechanism at room temperature in metallic glass
Article  Open access  01 February 2023
Liquid-like versus stress-driven dynamics in a metallic glass former observed by temperature scanning X-ray photon correlation spectroscopy
Article  Open access  13 May 2025
Length-scale dependence of the anomalous atomic motion in metallic glasses
Article
06 April 2026
Introduction
The relaxation dynamics of glass-forming liquids has been and still is a topic of intensive research 1 , 2 , 3 . This activity is motivated by the fact that glasses are not only important for a multitude of industrial and daily applications but also pose a formidable intellectual challenge since so far there is no theoretical framework that is able to give a satisfactory description of the many unusual features of glass-forming liquids and glasses. For example, most glass-forming systems show in the liquid state a stretched exponential decay of their time correlation functions 4 , 5 , 6 , and it is believed that this is directly related to the so-called dynamical heterogeneities 4 , 5 , 6 , 7 in the system, a phenomenon for which at present there is no solid theoretical understanding 8 . For temperatures slightly below the glass transition temperature T g , the systems show instead compressed exponentials that are speculated to be related to the release of internal stresses 9 , 10 , 11 , 12 , 13 , 14 , although also in this case we lack a good understanding for this behavior. Note that this type of stress relaxation is expected to be also important deep in the glass state 9 , 10 and thus to be related to the mechanical properties of the material, hence giving a rational why certain glasses, such as metallic glasses, are ductile and others, for example, oxide glasses, are brittle 15 , 16 .
Since in glass physics all dynamical features are a smooth function of temperature, it must be expected that such internal stresses are in fact already present in the deeply supercooled melt and hence the compressed exponentials should be observable to some extent already at temperatures above T g , that is, in the glassy melt. However, detecting in experiments the coexistence of such different relaxation behavior is not an easy task, since one first needs to identify observables that are related to the different relaxation mechanisms and then be able to measure their corresponding correlation functions. Furthermore, it cannot be expected that all glass-forming systems will show such a coexistence and hence a wise choice on the material has to be made. Since for the case of metallic glasses one does indeed find a crossover from stretched to compressed relaxation if temperature is decreased 10 , 17 , such systems seem to be good candidates to detect the simultaneous presence of both relaxation mechanisms, and in the following we show that this expectation is indeed borne out.
For metallic glasses it is well documented that local icosahedral clusters are important structural building blocks 18 , 19 and it has been found that atoms in these entities have a smaller than average atomic volume, a higher than average elastic modulus, and show a slower than average dynamics 20 , 21 , 22 , 23 . These observations indicate that these clusters are indeed relevant for the slowing down of the dynamics of the melt and the mechanical properties of the glass 24 . In the following, we will thus focus on atoms that are at the center of these icosahedra and in particular will consider various types of clusters formed by such interlocked icosahedra, that is, structures that have a size larger than the typical interatomic distance. By probing the wave-vector dependence of the relaxation of the intermediate scattering function for different clusters, we find that the relaxation dynamics shows a stretched exponential time dependence for weakly connected clusters, whereas strongly connected clusters have a compressed exponential time dependence, thus demonstrating that for metallic glasses these two types of processes can indeed coexist, a behavior that we expect to be related to the outstanding mechanical properties of these systems.
Results
Vibrational properties
The studied Cu 50 Zr 50 system consists of N  = 10,000 atoms interacting via an embedded atom potential 25 . (See Methods for details on the simulations.) For this system the onset temperature, that is, the point at which the dynamics becomes glassy 2 , is around 1250 K (see Supplementary Information), and in the following we study the properties of the system between 950 and 1100 K, that is, in a T - range in which the dynamics is already rather glassy. (See Supplementary Information for the T -dependence of the relaxation time.) As discussed above, in this system icosahedral-like clusters with a Cu atom in its center constitute slowly relaxing structures 18 , 21 , 23 and hence we focus here on the dynamics of these entities. For this we use a Voronoi construction 24 , 26 to identify those Cu atoms that are exactly 12-fold coordinated, that is, are in the center of an icosahedron. For each of these atoms, we count the number, k , of neighboring Cu atoms that are also 12-fold coordinated and we refer the central Cu atom to be in the center of a k -cluster (see lower inset of Fig. 1 ) 21 , 27 . (When we discuss in the following the dynamic properties of a k -clusters we refer to the value of k at time zero.) In the Supplementary Information, we show how the concentration of these populations change with temperature T . The space and time dependence of the relaxation dynamics can be characterized by means of the self-intermediate scattering function (SISF) F s ( q , t ), where q is the wave-vector:
$$F_{\mathrm{s}}(q,t) = \frac{1}{N}\mathop {\sum}\limits_{j = 1}^N \left\langle {{\mathrm{exp}}\left[ { - {\mathrm{i}}{\bf{q}} \cdot \left( {{\bf{r}}_j(t) - {\bf{r}}_j(0)} \right)} \right]} \right\rangle .$$
(1)
Here N is the number of particles considered, 〈.〉 is the thermal average, and r j ( t ) is the position of particle j at time t . In Fig. 1 we show the time dependence of F s ( q , t ) for particles that have different connectivity. The wave-vector is 2.8 Å −1 which corresponds to the main peak in the static structure factor (see Supplementary Fig. 2 in the Supplementary Information). We recognize that for t  ≤ 0.1 ps the different curves fall on a common curve, showing that on this time scale the motion of the particles is independent of their environment, that is, of k , since up to this time the motion is ballistic 21 . This is no longer the case for somewhat larger t in that the correlators for large k show a marked peak at around 0.2 ps. The presence of such a peak indicates that on this time scale the motion of large- k particles has the character of a damped oscillator, and in the Supplementary Information we show that this feature is indeed also very pronounced in the glass state (see Supplementary Fig. 9 ). This k- dependence of F s ( q , t ) shows that with increasing k the cage becomes stiffer and the damping is weaker. In previous studies the presence of such a peak has been associated with the so-called boson peak 28 , 29 , 30 , 31 , 32 , that is, an excess in the vibrational density of states (DOS) in the glass state 2 . Such an interpretation is indeed compatible for the present system as well, since we do find a peak at around 4 THz if one divides the vibrational DO S by the square of the frequency, see Supplementary Fig. 3b in the Supplementary Information, which matches well the 0.2 ps found for the peak in F s ( q , t ). Also included in the graph is the correlator for the Cu atoms that are not in the center of an icosahedron and we see that this function decays significantly faster than the one for the icosahedrally packed atoms (also shown), in agreement with the results from ref. 23 . Furthermore, we see that the former correlator shows no peak at intermediate times, thus confirming that this peak is related to the highly structured local environment of the central atom. The upper inset in the figure shows the same correlators on a much larger time range, demonstrating that the k -dependence of the SISF is present even on the time scale of the α -relaxation, see below for more details, thus indicating a connection between the dynamics at short times with the one at long times 33 , 34 , 35 .
Fig. 1
The alternative text for this image may have been generated using AI.  Full size image
Relaxation dynamics of the system at short times. Short-time behavior of the self-intermediate scattering function of particles with different local connectivity k (symbols). The wave-vector is q  = 2.8 Å −1 and T  = 1000 K. With increasing k the height of the peak at around 0.2 ps increases showing that the motion becomes less damped. The solid lines are fits to the data with Eq. ( 2 ). Also included is F s ( q , t ) for the Cu atoms in an icosahedral cluster (dashed red line), the Cu atoms not in an icosahedral cluster (blue dashed line), and all Cu atoms (green). The black dashed line is the correlation function averaged over all atoms. The upper inset shows the same data in a larger time interval. The lower inset illustrates the definition of particles with different connectivities k : Particles in blue are the center of an icosahedral-like cluster
To describe the dynamics at these short times in a quantitative manner, we fit the correlator with the simple Ansatz
$$F_{\mathrm{s}}(q,t) = \mathop {\sum}\limits_{j = L,H} {\kern 1pt} C_j{\kern 1pt} {\mathrm{exp}}\left\{ {{\mathrm{i}}q\left[ {A{\kern 1pt} {\mathrm{cos}}\left( {\omega _jt + \delta _j} \right) - A{\kern 1pt} {\mathrm{cos}}\left( {\delta _j} \right)} \right]} \right\},$$
(2)
where L and H denote a low- and high-frequency mode, respectively, and we have C L  +  C H  = 1, that is, we describe the motion of a particle as a superposition of two harmonic oscillators. The resulting fits are included in Fig. 1 as well and we see that this functional form gives indeed a good description of the data. Figure 2a presents the k -dependence of ω H and ω L and one recognizes that both of them increase with k (basically linearly, with a small bend at around k  = 5), which demonstrates that with increasing connectivity the cage becomes stiffer. Figure 2b shows the q -dependence of the two frequencies at low q and one sees that ω L is a linear function of q , as expected for a generic SISF that couples at low q to the acoustic modes 36 . (For this plot we have averaged over all values of k since the k -dependence seen in panel a depends only weakly on q .) In contrast to this, ω H is independent of q , showing that this mode has an optical character. In view of the observed k -dependence seen in Fig. 2 , we can conclude that the peak in F s ( q , t ) at around 0.2 ps is directly related to the details of the local structure. Similar results are found for the coherent intermediate scattering function.
Fig. 2
The alternative text for this image may have been generated using AI.  Full size image
... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [50]: M. Bernaschi et al. — The quantum transition of the two-dimensional Ising spin glass (Nature 631, 749-754, 2024)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: The quantum transition of the two-dimensional Ising spin glass
URL: https://doi.org/10.1038/s41586-024-07647-y
The quantum transition of the two-dimensional Ising spin glass | Nature
Your privacy, your choice
We use essential cookies to make sure the site can function. We also use optional cookies for advertising, personalisation of content, usage analysis, and social media, as well as to allow video information to be shared for both marketing, analytics and editorial purposes.
By accepting optional cookies, you consent to the processing of your personal data - including transfers to third parties. Some third parties are outside of the European Economic Area, with varying standards of data protection.
See our privacy policy for more information on the use of your personal data.
Manage preferences for further information and to change your choices.
Accept all cookies  Reject optional cookies
Skip to main content
Thank you for visiting nature.com. You are using a browser version with limited support for CSS. To obtain the best experience, we recommend you use a more up to date browser (or turn off compatibility mode in Internet Explorer). In the meantime, to ensure continued support, we are displaying the site without styles and JavaScript.
Advertisement
View all journals
Search
Search
Search articles by subject, keyword or author
Show results from
All journals  This journal
Search
Advanced search
Quick links
Explore articles by subject
Find a job
Guide to authors
Editorial policies
Log in
Content  Explore content
Explore content
Research articles
News
Opinion
Research Analysis
Careers
Books & Culture
Podcasts
Videos
Current issue
Browse issues
Collections
Subjects
Follow us on Facebook
Follow us on Bluesky
Follow us on X
Sign up for alerts
RSS feed
About the journal
About the journal
Journal Staff
About the Editors
Research Cross-Journal Editorial Team
Journal Information
Journal Metrics
Our publishing models
Editorial Values Statement
Editorial policies
Journalistic Principles
History of Nature
Awards
Contact
Send a news tip
Publish with us
Publish with us
For Authors
For Referees
Language editing services
Open access funding
Submit manuscript
Sign up for alerts
RSS feed
nature
articles
article
The quantum transition of the two-dimensional Ising spin glass
Download PDF
Download PDF
Article
Open access
Published: 10 July 2024
The quantum transition of the two-dimensional Ising spin glass
Massimo Bernaschi  ORCID: orcid.org/0000-0003-3661-9836 1 ,
Isidoro González-Adalid Pemartín  ORCID: orcid.org/0000-0003-4640-0125 2 ,
Víctor Martín-Mayor  ORCID: orcid.org/0000-0002-3376-0327 2 &
…
Giorgio Parisi 3 , 4  Show authors
Nature
volume 631 , pages 749–754 ( 2024 ) Cite this article
28k Accesses
34 Citations
62 Altmetric
Metrics details
Abstract
Quantum annealers are commercial devices that aim to solve very hard computational problems 1 , typically those involving spin glasses 2 , 3 . Just as in metallurgic annealing, in which a ferrous metal is slowly cooled 4 , quantum annealers seek good solutions by slowly removing the transverse magnetic field at the lowest possible temperature. Removing the field diminishes the quantum fluctuations but forces the system to traverse the critical point that separates the disordered phase (at large fields) from the spin-glass phase (at small fields). A full understanding of this phase transition is still missing. A debated, crucial question regards the closing of the energy gap separating the ground state from the first excited state. All hopes of achieving an exponential speed-up, compared to classical computers, rest on the assumption that the gap will close algebraically with the number of spins 5 , 6 , 7 , 8 , 9 . However, renormalization group calculations predict instead that there is an infinite-randomness fixed point 10 . Here we solve this debate through extreme-scale numerical simulations, finding that both parties have grasped parts of the truth. Although the closing of the gap at the critical point is indeed super-algebraic, it remains algebraic if one restricts the symmetry of possible excitations. As this symmetry restriction is experimentally achievable (at least nominally), there is still hope for the quantum annealing paradigm 11 , 12 , 13 .
Similar content being viewed by others
Coherent quantum annealing in a programmable 2,000 qubit Ising chain
Article
15 September 2022
Quantum annealing of a frustrated magnet
Article  Open access  25 April 2024
Quantum critical dynamics in a 5,000-qubit programmable spin glass
Article
19 April 2023
Main
Optimization problems are ubiquitous in everyday life (think, for instance, of deciding the best delivery route or scheduling jobs for the different tools in a factory). These problems can be mathematically formalized: N entities (for example, jobs queuing for their appropriate tools) compete as they try to satisfy their mutually contradictory goals. The overall frustration produced by a particular solution is quantified through a cost function, which one attempts to minimize. This task is best solved with the help of a computer, even for quite small N . Research into computational complexity studies how the computational resources (memory, computing time and so on) grow with N (ref. 14 ). If, for all known algorithms, the necessary resources grow faster with N than any polynomial, for example, like N !, the problem is considered hard. A small subset of these problems, named NP-complete, is of particular interest: if an efficient algorithm (with resources scaling polynomially in N ) were discovered for any of the NP-complete problems, then a vast family of hard optimization problems in this subset would become easy. For physicists, the most familiar example of an NP-complete problem is finding the minimal energy state—the ground state—of an Ising spin-glass Hamiltonian on a non-planar graph 15 , 16 . This explains the surge of hardware specifically designed for minimizing a spin-glass Hamiltonian through a variety of algorithms and physical principles (see, for example, refs. 17 , 18 , 19 , 20 , 21 , 22 ).
Specifically, the strategy that concerns us here is quantum annealing. Both in the original formulation 11 , and also in its hardware implementation 1 , 20 , the aim is to solve the situation for spin glasses. In particular, D-wave chips solve Ising spin glass in D  = 2 spatial dimensions ( \({D}^{{\prime} } > 2\) can be coded over a D-wave’s D  = 2 graph 23 ; see pages 13 and 49 in ref. 24 for more on the definition of D ).
Spin glass is the paradigmatic statistical model for quenched disorder 25 . In a transverse field, the Hamiltonian for S  = 1/2 spins is
$$H=-\frac{1}{2}\sum _{x,y}\,\left[\,{J}_{x,y}{\sigma }_{x}^{Z}{\sigma }_{y}^{Z}\right]\,-\,\varGamma \sum _{x}\,{\sigma }_{x}^{X},$$
(1)
where J x,y are the random couplings that define the problem instance under consideration, Γ is the transverse field and \({\sigma }_{x}^{X}\) and \({\sigma }_{x}^{Z}\) are, respectively, the first and third Pauli matrices acting on the spin at site x . The phase diagram for a two-dimensional interaction matrix J x,y is sketched in Fig. 1a . For Γ  =  ∞ , in the ground state, all spins are as much aligned with the transverse field as quantum mechanics allows them to be. (Paradoxically, from the point of view of the computational basis that diagonalizes the \({\sigma }_{{\boldsymbol{x}}}^{Z}\) matrices, this ground state seems to be a totally random statistical mixture). As Γ is diminished at zero temperature, the ground state varies. In particular, at Γ  = 0, the ground state encodes the solution of the optimization problem we are interested in. At some point during the annealing, Γ goes through the critical value Γ c that separates the disordered ground state from the spin-glass ground state, which has a glassy order in the computational basis. This is not just theoretical daydreaming. In a recent experiment conducted on a D-wave chip 23 , some 5,000 qubits displayed coherent quantum dynamics as Γ went through Γ c , for annealings lasting several nanoseconds.
Fig. 1: Phase diagram and critical scaling for the two-dimensional quantum spin glass.
The alternative text for this image may have been generated using AI.  Full size image
a , Phase diagram for a two-dimensional Ising spin glass in terms of temperature T and transverse field Γ . For all T  > 0, the system is disordered when studied at large length scales, so that it is in the paramagnetic phase (PM). At T  = 0, the ground state seems disordered for Γ  >  Γ c (from the point of view of the computational basis). For Γ  <  Γ c , we encounter the spin-glass phase (SG), which is different for every disorder realization (equation ( 1 )). b , Our finite-size scaling analysis (see, for example, refs. 48 , 60 ) of the critical point at T  = 0 and Γ  =  Γ c , in terms of the parameter k that represents Γ in the Trotter–Suzuki formulation (‘The Trotter–Suzuki formula’ in Methods ; k grows as Γ decreases). Left, correlation length ξ (3) in units of the lattice size L versus k . The curves for the different L ’s intersect at the critical point k c  ≈ 0.29. Right, data in the left-hand panel of b , when represented as a function of the scaling variable L 1/ ν ( k  −  k c ) with 1/ ν  = 0.7, converge to a limiting curve as L grows. Points in b are statistical averages, and errors are one standard deviation. Our data set is fully described in Extended Data Table 1 .
Source Data
A strong theoretical command of the phase transition at Γ c is clearly necessary. A very powerful tool in the analytical study of phase transitions is the renormalization group, which helps to clarify which properties of the critical point are not modified by the different microscopic details of different experiments. Only very broad features, such as symmetries, matter (making it possible to classify problems into universality classes). In fact, the study of disordered systems was one of the early applications of the renormalization group (see, for example, refs. 26 , 27 , 28 ), a strategy that is firmly established for D  = 2 (ref. 29 ). Yet, it has taken considerable time and effort to show that the renormalization group—and the accompanying universality—also applies to disordered systems for D  > 2 (refs. 30 , 31 , 32 , 33 , 34 ; even for D  = 2, this was a hard endeavour for spin glasses 35 ). Unfortunately, the study of the quantum spin-glass transition at finite D is considerably behind its thermal counterpart. Essentially, only the D  = 1 case is well understood 36 , 37 , 38 , 39 .
The second-simplest problem to analyse, a spin glass with D  = 2, poses quite a challenge. Indeed, different approaches have produced mutually contradictory predictions for the crucial physical quantity that ultimately determines whether the quantum computational complexity of the problem to be considered is smaller than its classical counterpart. We are referring to the energy gap Δ that separates the ground state from the first excited state of the Hamiltonian ( 1 ). Indeed, the required annealing time grows with 1/ Δ 2 (ref. 40 ). In a spin glass with N   ∝   L 2 quantum spins at Γ  =  Γ c , where L is the linear size of the system, Δ   ∝   L − z , where z is the so-called dynamic critical exponent. Early Monte Carlo simulations 5 , 6 , 8 and a series-expansion study 9 found finite values of z (for example, z  ≈ 1.5 for D  = 2 spin glasses 5 ). A finite z is also a crucial assumption of the droplet model for the quantum spin-glass transition 41 . On the other hand, a real-space renormalization group analysis concluded that z  =  ∞ for D  = 2 or 3 spatial dimensions 10 . (A Monte Carlo simulation too claimed that z  =  ∞ for D  = 2 (ref. 42 )).
The starting assumption of refs. 5 , 6 , 8 , 23 was a finite value of exponent z . Yet, to clarify the aforementioned controversy, our analysis is completely agnostic about z . Just as Rieger and Young pushed to the very limit the computational capabilities of the time using special hardware (transputers) 5 , we have performed unprecedented large-scale simulations on graphical processing units (GPUs) using highly tuned custom codes. A careful consideration of the global spin-flip symmetry, implemented by the parity operator \(P={\prod }_{x}{\sigma }_{x}^{X}\) , turns out to be crucial. Although the gap for same-parity excitations scales algebraically in the number of spins, the gap for parity-changing excitations does close super-algebraically. The coexistence of these two qualitatively different scalings at the critical point is extremely unusual and is probably caused by Griffiths–McCoy singularities 36 , 37 , 38 , 39 , 43 . (In the spin-glass phase, instead, the spontaneously broken parity symmetry naturally generates an exponentially small gap but only for parity-changing excitations.) Although Griffiths–McCoy singularities are strongly dependent on D , interestingly, ref. 44 hinted at an algebraically scaling gap for same-parity excitations at the quantum critical point of a three-regular graph (a D = ∞ problem; parity-changing excitations were not studied in ref. 44 ).
The ground state
Our aim here is to study the phase transition as seen from the ground state (so that the spectra of excitations and, hence, exponent z do not play any role in the analysis in ‘The phase transition’). This entails taking the limit T  → 0.
In the Trotter formulation that we use (‘The Trotter–Suzuki formula’ in Methods ), the original quantum spins on an L  ×  L lattice are replaced by classical spins on an L  ×  L  ×  L τ lattice, S x , τ  = ±1. The extra dimension τ is named the Euclidean time. Γ is replaced by a new parameter k that grows as Γ decreases. The energy gap Δ translates into a correlation length η  = 1/( kΔ ) over Euclidean time. In this formulation, the limits T  → 0 and L τ  →  ∞ are equivalent.
Although our main results stem from Monte Carlo simulations, a complementary exact-diagonalization effort on small systems (‘Exact diagonalization’ in the next section and ‘More about exact diagonalization’ in Methods ) has been extremely useful, both in shaping our analysis and in providing an understanding for how the limit T  → 0 is approached (‘At the limit of zero temperature’).
Exact diagonalization
The main lessons that exact diagonalization of systems with size L  ≤ 6 (‘More about exact diagonalization’ in Methods and Extended Data Figs. 1 and 3 ) have taught us are the following.
The parity operator P splits the spectrum of the Hamiltonian (equation ( 1 )) into even energy levels ( E 0,e  <  E 1,e  < …) and odd levels ( E 0,o  <  E 1,o  < …). The ground state is even and its energy is E GS  =  E 0,e .
The first excited state is E 0,o . The minimal gap Δ  =  E 0,o  −  E 0,e displays dramatic fluctuations among samples, up to the point that a... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [51]: Y. Kato, S. Onoda — Numerical evidence of quantum melting of spin ice (Phys. Rev. Lett. 115, 077202, 2015)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Numerical evidence of quantum melting of spin ice
URL: https://doi.org/10.1103/PhysRevLett.115.077202
Numerical Evidence of Quantum Melting of Spin Ice: Quantum-to-Classical Crossover | Phys. Rev. Lett.
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review Letters
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Numerical Evidence of Quantum Melting of Spin Ice: Quantum-to-Classical Crossover
Yasuyuki Kato 1,2 and Shigeki Onoda 1,3  open icon  close icon
1 RIKEN Center for Emergent Matter Science (CEMS), Wako, Saitama 351-0198, Japan
2 Department of Applied Physics, University of Tokyo, Bunkyo, Tokyo 113-8656, Japan
3 Condensed Matter Theory Laboratory, RIKEN, Wako, Saitama 351-0198, Japan
PDF Share open icon  close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. Lett. 115 , 077202 – Published 14 August, 2015
DOI:https://doi.org/10.1103/PhysRevLett.115.077202
Export Citation
87
Show metrics open icon  close icon
See more details
Picked up by 1 news outlets
Posted by 5 X users
Referenced in 1 patents
On 1 Facebook pages
43 readers on Mendeley
87
CITATIONS
Abstract
Unbiased quantum Monte Carlo simulations are performed on the nearest-neighbor spin- 1 2 pyrochlore 𝑋 ⁢ 𝑋 ⁢ 𝑍 model with an antiferromagnetic longitudinal and the weak ferromagnetic transverse exchange couplings, 𝐽 and 𝐽 ⊥ . The specific heat exhibits a broad peak at 𝑇 C S I ∼ 0 . 2 ⁢ 𝐽 associated with a crossover to a classical Coulomb liquid regime showing a suppressed spin-ice monopole density, a broadened pinch-point singularity, and the Pauling entropy for | 𝐽 ⊥ | ≪ 𝐽 , as in classical spin ice. On further cooling, the entropy restarts decaying for 𝐽 ⊥ > 𝐽 ⊥ ⁢ 𝑐 ∼ − 0 . 1 0 4 ⁢ 𝐽 , producing another broad specific heat peak for a crossover to a bosonic quantum Coulomb liquid, where the spin correlation contains both photon and quantum spin-ice monopole contributions. With negatively increasing 𝐽 ⊥ across 𝐽 ⊥ ⁢ 𝑐 , a first-order thermal phase transition occurs from the quantum Coulomb liquid to an 𝑋 ⁢ 𝑌 ferromagnet. Relevance to magnetic rare-earth pyrochlore oxides is discussed.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Article Available via CHORUS
Download Accepted Manuscript
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
Supplemental Material (Subscription Required)
References (Subscription Required)
Outline Information
Citing Articles (73)
Abstract
Article Text
Supplemental Material
References
Phys. Rev. Lett. 115 , 077202 – Published 14 August, 2015
Vol. 115, Iss. 7 — 14 August 2015
Received 7 November 2014
Export Citation
Reuse & Permissions
Article Available via CHORUS  Download Accepted Manuscript
DOI: https://doi.org/10.1103/PhysRevLett.115.077202
© 2015 American Physical Society
Outline Information
Outline
Citing Articles (73)
Abstract
Article Text
Supplemental Material
References
Information
Phys. Rev. Lett. 115 , 077202 – Published 14 August, 2015
Vol. 115, Iss. 7 — 14 August 2015
Received 7 November 2014
Export Citation
Reuse & Permissions
Article Available via CHORUS  Download Accepted Manuscript
DOI: https://doi.org/10.1103/PhysRevLett.115.077202
© 2015 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science SCOAP 3 Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
SCOAP 3
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 1079-7114 (online), 0031-9007 (print). ©2026 American Physical Society. All rights reserved.  Physical Review Letters™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [52]: J. Tindall, M. Rudolph — TensorNetworkQuantumSimulator.jl (2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: TensorNetworkQuantumSimulator.jl
URL: https://github.com/JoeyT1994/TensorNetworkQuantumSimulator
GitHub - JoeyT1994/TensorNetworkQuantumSimulator.jl: Package built on top of ITensors.jl and NamedGraphs.jl for quantum simulation with tensor networks (TNs) of near-arbitrary geometry · GitHub
Skip to content
Navigation Menu
Toggle navigation
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE  Why GitHub
Documentation
Blog
Changelog
Marketplace
View all features
Solutions
BY COMPANY SIZE  Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE  App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY  Healthcare
Financial services
Manufacturing
Government
View all industries
View all solutions
Resources
EXPLORE BY TOPIC  AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE  Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES  Documentation
Customer support
Community forum
Trust center
Partners
View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS  Security Lab
Maintainer Community
Accelerator
GitHub Stars
Archive Program
REPOSITORIES  Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
-->
Search
Clear
Search syntax tips
Provide feedback
-->
We read every piece of feedback, and take your input very seriously.
Include my email address so I can be contacted
Cancel
Submit feedback
Saved searches
Use saved searches to filter your results more quickly
-->
Name
Query
To see all available qualifiers, see our documentation .
Cancel
Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session.  You signed out in another tab or window. Reload to refresh your session.  You switched accounts on another tab or window. Reload to refresh your session.
Dismiss alert
{{ message }}
JoeyT1994
/
TensorNetworkQuantumSimulator.jl
Public
Notifications You must be signed in to change notification settings
Fork 17
Star 75
Code
Issues  0
Pull requests  3
Actions
Projects
Security and quality  0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security and quality
Insights
JoeyT1994/TensorNetworkQuantumSimulator.jl
main
22 Branches  26 Tags
Go to file
Code
Open more actions menu
Folders and files
Name Name  Last commit message
Last commit date
Latest commit
JoeyT1994
Merge pull request #68 from JoeyT1994/Improvement
Open commit details  success  May 8, 2026
78f4cd3 · May 8, 2026
History
395 Commits
Open commit details
395 Commits
.github
.github
x64 only. Int64 dropped
Oct 28, 2025
docs
docs
Better docs
May 7, 2026
examples
examples
Better observable parsing
Nov 18, 2025
src
src
Better docs
May 7, 2026
test
test
Better gate defining
Apr 29, 2026
.gitignore
.gitignore
update ci and tests
Oct 27, 2025
LICENSE
LICENSE
Add MIT License to the project
Oct 25, 2025
Project.toml
Project.toml
Project bump
May 8, 2026
README.md
README.md
Better gate defining
Apr 29, 2026
View all files
Repository files navigation
README
MIT license
TensorNetworkQuantumSimulator
A Julia package for simulating quantum circuits, quantum dynamics and equilibrium physics with tensor networks (TNs) of near-arbitrary geometry. Built on top of ITensors and NamedGraphs .
The main workhorses of the simulation are belief propagation (BP) and the singular value decomposition for applying gates, and BP or boundary MPS for estimating expectation values and sampling.
Documentation
Full documentation is available at https://JoeyT1994.github.io/TensorNetworkQuantumSimulator.jl/ , covering:
Getting Started — complete tutorial from lattice definition to measurement
Graphs — lattice constructors and graph utilities
Tensor Networks — TensorNetwork and TensorNetworkState types
Gate Application — circuits, simple update, and supported gates
Expectation Values — observables, norms, and reduced density matrices
Entanglement Entropy — von Neumann and Rényi entropies
Sampling — bitstring sampling with optional certification
Caches — BeliefPropagationCache and BoundaryMPSCache in depth
Advanced Topics — GPU support, loop corrections, precision control
API Reference — complete function reference
Installation
julia > using Pkg; Pkg . add ( " TensorNetworkQuantumSimulator " )
Quick Start
using TensorNetworkQuantumSimulator
# 1. Define a graph (5x5 square lattice) g = named_grid (( 5 , 5 ))
# 2. Create an initial state (all spins up, ComplexF32 precision) ψ = tensornetworkstate (ComplexF32, v -> " ↑ " , g, " S=1/2 " )
# 3. Build a circuit layer (1st-order Trotter step of the transverse-field Ising model) J, hx, dt = 1.0 , 2.5 , 0.01 layer = [] append! (layer, ( " Rx " , [v], 2 * hx * dt) for v in vertices (g))ec = edge_color (g, 4 ) for colored_edges in ec append! (layer, ( " Rzz " , pair, 2 * J * dt) for pair in colored_edges) end
# 4. Apply 50 layers of the circuit apply_kwargs = (; maxdim = 10 , cutoff = 1e-10 , normalize_tensors = true )circuit = reduce (vcat, [layer for _ in 1 : 50 ])ψ, errors = apply_gates (circuit, ψ; apply_kwargs)
# 5. Measure an expectation value sz_bp = expect (ψ, ( " Z " , ( 3 , 3 )); alg = " bp " )sz_bmps = expect (ψ, ( " Z " , ( 3 , 3 )); alg = " boundarymps " , mps_bond_dimension = 10 )
Usage Guide
Defining the Geometry
The starting point of most calculations is a NamedGraph that encodes the geometry of your tensor network. Vertices correspond to qubits (or qutrits, bosonic sites, etc.) and edges correspond to pairs of sites that directly interact. Built-in constructors are provided for common lattices:
g = named_grid (( 5 , 5 )) # 2D square lattice g = named_grid (( 3 , 3 , 3 ); periodic = true ) # 3D periodic cubic lattice g = named_hexagonal_lattice_graph ( 4 , 4 ) # hexagonal lattice g = heavy_hexagonal_lattice ( 5 , 5 ) # heavy-hexagonal lattice g = lieb_lattice ( 5 , 5 ) # Lieb lattice
Constructing a Tensor Network State
A TensorNetworkState (TNS) is a tensor network representation of your wavefunction, with the structure specified by the graph g . Product states can be constructed using string labels or numerical vectors:
# All spins up (bond dimension 1) ψ = tensornetworkstate (v -> " ↑ " , g, " S=1/2 " )
# Random state with bond dimension 4 and ComplexF32 elements ψ = random_tensornetworkstate (ComplexF32, g, " S=1/2 " ; bond_dimension = 4 )
The optional first argument sets the element type ( Float64 by default). Use ComplexF32 or ComplexF64 for complex-valued states.
Heisenberg Picture
You can also work directly in the Heisenberg picture, representing a many-body operator as a TNS in the "Pauli" basis. Each site encodes the coefficients of I, X, Y, Z:
# Start with the Z operator on a single site, identity elsewhere ψ = paulitensornetworkstate (ComplexF32, v -> v == v0 ? " Z " : " I " , g)
Gates are then applied as conjugation by unitaries, and observables are extracted via traces (see examples/2dIsing_dynamics_Heisenbergpicture.jl ).
Building Circuits
A circuit is a Vector of gates to be applied sequentially. Each gate is specified as a tuple (gate_string, vertices, parameter) or as a raw ITensor :
layer = [] # Single-site rotations  append! (layer, ( " Rx " , [v], 2 * hx * dt) for v in vertices (g)) append! (layer, ( " Rz " , [v], 2 * hz * dt) for v in vertices (g))
# Two-site gates, grouped by edge coloring for efficiency ec = edge_color (g, 4 ) # 4 = coordination number of the square lattice  for colored_edges in ec append! (layer, ( " Rzz " , pair, 2 * J * dt) for pair in colored_edges) end
The edge_color function identifies groups of non-overlapping edges. Non-overlapping gates within a group are applied in parallel during the simulation. The second argument should be the coordination number (maximum vertex degree) of the graph.
Applying Gates
Apply gates to the TNS using apply_gates . The apply_kwargs control bond dimension truncation during the SVD:
apply_kwargs = (; maxdim = 10 , cutoff = 1e-10 , normalize_tensors = true )ψ, errors = apply_gates (circuit, ψ; apply_kwargs)
You can also pass a BeliefPropagationCache directly to reuse BP messages between gate applications:
ψ_bpc = update ( BeliefPropagationCache (ψ))ψ_bpc, errors = apply_gates (circuit, ψ_bpc; apply_kwargs)
Expectation Values
Compute expectation values with expect , choosing from several contraction algorithms:
# Belief propagation (works on any graph, fast, approximate) sz = expect (ψ, ( " Z " , ( 3 , 3 )); alg = " bp " )
# Boundary MPS (planar graphs only, more accurate, adjustable precision) sz = expect (ψ, ( " Z " , ( 3 , 3 )); alg = " boundarymps " , mps_bond_dimension = 16 )
# Exact contraction (only feasible for small systems) sz = expect (ψ, ( " Z " , ( 3 , 3 )); alg = " exact " )
# Multi-site observables szz = expect (ψ, ( " ZZ " , [( 3 , 3 ), ( 3 , 4 )]); alg = " bp " )
# Multiple observables at once observables = [( " Z " , [v]) for v in vertices (g)]sz_all = expect (ψ, observables; alg = " bp " )
If you already have an updated BeliefPropagationCache or BoundaryMPSCache , pass it directly to avoid redundant cache construction.
Norms, Inner Products and Reduced Density Matrices
# Squared norm nsq = norm_sqr (ψ; alg = " bp " )
# Norm (via LinearAlgebra)  using LinearAlgebran = norm (ψ; alg = " bp " )
# Normalize the state ψ = normalize (ψ; alg = " bp " )
# Inner product between two states ip = ITensors . inner (ψ, ϕ; alg = " bp " )
# Reduced density matrix on a set of vertices ρ = reduced_density_matrix (ψ, [( 3 , 3 )]; alg = " bp " )
All of these support the same algorithm options as expect : "exact" , "bp" , "boundarymps" , and (for norms) "loopcorrections" .
Sampling
Draw bitstring samples from the probability distribution defined by the squared amplitudes of the state:
# Basic sampling (returns bitstrings only) bitstrings = sample (ψ, 100 ; alg = " boundarymps " , norm_mps_bond_dimension = 10 )
# Directly certified sampling (returns bitstrings with p(x)/q(x) estimates) results = sample_directly_certified (ψ, 100 ; alg = " boundarymps " , norm_mps_bond_dimension = 10 )
# Certified sampling (independent contraction for certification) results = sample_certified (ψ, 100 ; alg = " boundarymps " , norm_mps_bond_dimension = 10 )
BP-based sampling is also available via alg = "bp" .
Truncation
Reduce the bond dimension of an existing TNS:
ψ_truncated = truncate (ψ; alg = " bp " , maxdim = 4 , cutoff = 1e-10 )
Supported Gates
Gates are specified as tuples of the form (gate_string, vertices) or (gate_string, vertices, parameter) . The vertices can be a vector of one or two graph vertices, or a NamedEdge for two-qubit gates. All parameterised gates follow the Qiskit convention.
One-qubit gates (parameter in parentheses where required):
Gate  Parameter  Description
"X" , "Y" , "Z"  --  Pauli gates
"H"  --  Hadamard
"P"  phase  Phase gate
"Rx" , "Ry" , "Rz"  angle  Pauli rotation
"CRx" , "CRy" , "CRz"  angle  Controlled Pauli rotation (single-qubit part)
Two-qubit gates:
Gate  Parameter  Description
"CNOT" , "CX" , "CY"  --  Controlled gates
"SWAP" , "iSWAP" , "√SWAP" , "√iSWAP"  --  Swap variants
"Rxx" , "Ryy" , "Rzz"  angle  Pauli-pair rotations
"Rxxyy" , "Rxxyyzz"  angle  Multi-Pauli rotations
"CPHASE"  phase  Controlled phase
Custom gates can be defined by constructing the corresponding ITensor acting on the physical indices of the target qubits.
GPU Support
GPU support is enabled for all operations. Load the relevant Julia GPU package (e.g. CUDA.jl or Metal.jl) and transfer the state or cache:
using TensorNetworkQuantumSimulator using CUDA
g = named_grid (( 8 , 8 ))ψ_cpu = random_tensornetworkstate (ComplexF32, g; bond_dimension = 8 )ψ_gpu = CUDA . cu (ψ_cpu)
@time expect (ψ_cpu, ( " Z " , ( 1 , 1 )); alg = " boundarymps " , mps_bond_dimension = 16 ) @time expect (ψ_gpu, ( " Z " , ( 1 , 1 )); alg = " boundarymps " , mps_bond_dimension = 16 )
Caches can also be transferred: CUDA.cu(BeliefPropagationCache(ψ)) . Significant speedups are seen on NVIDIA GPUs at moderate to large bond dimensions.
Algorithm Guide
Algorithm  Keyword  Graph requirement  Cost  Accuracy
Belief propagation  alg = "bp"  Any  Low  Exact on trees, approximate on loopy graphs
Boundary MPS  alg = "boundarymps"  Planar  Moderate (tuneable via mps_bond_dimension )  Converges to exact with increasing bond dimension
Loop corrections  alg = "loopcorrections"  Any  Moderate  Systematic corrections to BP
Exact contraction  alg = "exact"  Any (small systems)  Exponential  Exact
Examples
See the examples/ directory for complete worked examples:
2D Ising dynamics ( 2dIsing_dynamics.jl ) -- time evolution on a square lattice with BP and boundary MPS measurements
3D Ising dynamics ( 3dIsing_dynamics.jl ) -- time evolution on a periodic 3D cubic lattice
Heavy-hex Ising dynamics ( heavyhexIsing_dynamics.jl ) -- evolution, measurement and sampling on a heavy-hexagonal lattice
Heisenberg picture ( 2dIsing_dynamics_Heisenbergpicture.jl ) -- operator evolution in the Pauli basis
Boundary MPS ( boundarymps.jl ) -- comparing BP, boundary MPS and exact expectation values
Loop corrections ( loopcorrections.jl ) -- improving BP norm estimates with loop corrections
We encourage users to read the literature listed below and explore the tests and source code to learn how the package works in detail.
Relevant Literature
Helpful reading for understanding the algorithms and the kind of simulations the library has been used for:
J. Tindall and M. Fishman, "Gauging tensor networ... [TRUNCATED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [53]: J. Tindall et al. — Data for: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks (Dryad, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Data for: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks
URL: https://doi.org/10.5061/dryad.7d7wm388g
Dryad | Data: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks
Skip to main content
Explore
Submit
Advanced search
Search Dryad data
More
About
Who we are
What we do
Partner with us
Support us
Get help
Login
Data from: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks
Tindall, Joseph 1 ; Mello, Antonio 1 ; Fishman, Matthew 1 ; Stoudenmire, Edwin Miles 1 ; Sels, Dries 1
Author affiliations
Flatiron Institute
Research facility: Simons Foundation
Published Mar 31, 2026 on Dryad .
https://doi.org/10.5061/dryad.7d7wm388g
Data files
Mar 31, 2026 version files  38.45 MB
DynamicsofDisorderedSystemsData.zip
Preview
38.44 MB
README.md
14.60 KB
Click names to download individual files
Download full dataset
Abstract
Large-scale quantum annealing dynamics of Ising spin glasses were recently implemented on D-Wave’s Advantage2 system on a range of lattices. Following extensive comparison to existing numerical methods, these experiments were claimed to be beyond the reach of classical computation. Here, we simulate these spin glass models with lattice-specific tensor networks, using belief propagation (BP) to keep up with the entanglement generated during the time evolution and then extracting expectation values with more sophisticated variants of BP. We find that state-of-the-art accuracies can be achieved with modest computational resources. Moreover, our results are scalable in both two and three dimensions, which we leverage to verify universal Kibble-Zurek physics on systems involving hundreds of qubits.
README: Data from: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks
Dataset DOI: 10.5061/dryad.7d7wm388g
Overview
This repository contains data from tensor network state (TNS) simulations of quasi-adiabatic dynamics in the disordered transverse field Ising model (TFIM). The simulations cover three specific lattice geometries: square, diamond cubic, and regular cubic lattices.
In cases where ground truth matrix product state (MPS) data is available, it is provided. Data from the D-Wave Advantage2 Quantum Processor is provided to,o which was originally reported in Science 12 Mar 2025 Vol 388, Issue 6743 with the accompanying Zenodo repo https://zenodo.org/records/14063693 .
The provided data and scripts then allow for the reconstruction of all plots as presented in the corresponding paper "Dynamics of Disordered Quantum Systems with Two- and Three-Dimensional Tensor Networks" in the journal Science.
Repository Structure
All raw data is contained within the compressed file DynamicsofDisorderedSystemsData.zip . The data is organized into several high-level folders: one for each of the figures in the main text and supplementary material. The pertinent subfolders are structured as in the table below:
DynamicsofDisorderedSystemsData.zip├── Figure2│ ├── CylindricalTNSCorrs│ ├── MPSGroundTruthCorrs│ ├── QPUCorrs│ ├── Instances│ └── Plot_Figure2.py├── Figure3│ ├── TNSCorrs│ ├── MPSGroundTruthCorrs│ ├── QPUCorrs│ ├── Instances│ └── Plot_Figure3.py├── Figure4│ ├── AllDiamondTNSCorrs│ ├── NNDiamondTNSCorrs│ ├── instance.npz│ └── Plot_Figure4.py├── Figure5│ ├── DiamondTNS│ │ ├── Instances│ │ └── Corrs│ ├── CylinderTNS│ │ ├── Instances│ │ └── Corrs│ └── Plot_Figure5.py├── SupplementaryMaterialFigure3│ ├── BPEvolutionGateErrors│ ├── DiamondTNSCorrs│ └── Plot_SMFigure3.py├── SupplementaryMaterialFigure4│ ├── DiamondTNSEvolutionWalltimes│ ├── DiamondTNSLoopCorrectionWalltimes│ └── Plot_SMFigure4.py└── SupplementaryMaterialFigure5 ├── CylindricalTNSCorrs ├── MPSGroundTruthCorrs ├── Instances └── Plot_SMFigure5.py
Individual descriptions of the contents of the high-level folders are as follows.
Each includes a dedicated Python script (e.g., Plot_FigureX.py) to reproduce the specific figure from the raw .npz file,s which contains all of the data.
Figure 2
Raw data and plotting script for simulations on an 8x8 cylindrical lattice with annealing times t_a = 2, 7, and 20 ns and n = 20 disorder instances. Data includes correlations from MPS (ground truth), QP,U and Cylindrical TNS simulations, with a folder for each of these three methods. The subfolders in CylindricalTNS correspond to different annealing times and bond dimensions.
Additionally, there is an Instances folder containing a .npz file for each disorder instance.
Figure 3
Raw data and plotting script for simulations on cylindrical, diamond cubic, and diamond lattices with annealing times t_a = 2, 7, and 20 ns and 20 disorder instances. Data includes correlations from MPS (ground truth), QP,U and TNS simulations with a folder for each of these three methods. These have subfolders for different lattice instances and, in the TNS case, also for different bond dimensions, measurement approaches,s etc.
Figure 4
Raw data and plotting script for 3D TNS simulations of the 192 qubit diamond lattice at an annealing time of t_a = 7 ns. The data covers correlations for a range of bond dimensions and orders of loop correction.
Figure 5
Raw data (correlations) and plotting script for cylindrical and diamond cubic TNS simulations across a range of annealing times, system size,s and disorder instances, allowing a Kibble-Zurek collapse to be performed.
SupplementaryMaterial3
Raw data and plotting script for diamond cubic TNS simulations. Data is for a range of annealing times and system sizes and includes correlations and gate errors at different bond dimensions and orders of loop correction.
SupplementaryMaterial4
Raw data and plotting script for diamond cubic TNS simulations. Data is for a range of annealing times and system sizes and includes wall times on both GPU and CPU for different bond dimensions and orders of loop correction.
SupplementaryMaterial5
Raw data and plotting script for 8x8 cylindrical TNS simulations. Data includes correlations from MPS, QPU, and Cylindrical TNS simulations for 20 different disorder instances and truncation protocols.
Summary of Variables in Raw Data Files
All raw data is stored in NumPy .npz format. The variables contained in each file type are summarised below.
Disorder Instance Files
Found in Instances/ subfolders across Figures 2, 3, 5, and Supplementary Material Figure 5. Each file defines one realisation of disorder in the transverse field Ising model.
Variable  Type  Description
Jij  1D float array  Coupling strengths J_ij for each edge in the lattice.
i  1D int array  Source qubit index for each edge.
j  1D int array  Target qubit index for each edge.
MPS Ground Truth and QPU Correlation Files
Found in MPSGroundTruthCorrs/ and QPUCorrs/ subfolders. Each file contains correlations across all disorder instances for a given lattice geometry and annealing time.
Variable  Type  Description
corrs  2D float array, shape (n_disorders, n_correlations)  Upper-triangular two-point correlators <sigma z_i sigma z_j>. Each row corresponds to one disorder instance.
TNS Correlation Files (Single Instance)
Found in cylindrical, diamo,nd and cubic dimer TNS subfolders across Figures 2, 3, 5, and Supplementary Material Figure 5. Each file contains the correlations for a single disorder instance at a given bond dimension and annealing time. This includes both boundary-MPS measured and loop-corrected correlations.
Variable  Type  Description
corrs  1D float array  Upper-triangular two-point correlators <sigma z_i sigma z_j> for one disorder instance.
Nearest-Neighbour Diamond TNS Correlations (Figure 4)
Found in NNDiamondTNSCorrs/ . Each file contains a single nearest-neighbour correlator at multiple loop correction orders for a given bond dimension.
Variable  Type  Description
corrs  1D float array  Nearest-neighbour correlator value at each loop correction order.
looplengths  1D int array  The maximum loop length l_max corresponding to each entry in corrs .
All Pairwise Diamond TNS Correlations (Figure 4)
Found in AllDiamondTNSCorrs/ . Each file contains all pairwise correlators for a given bond dimension and loop correction order.
Variable  Type  Description
corrs  1D float array  All pairwise two-point correlators <sigma z_i sigma z_j>.
Distance-Averaged Cylindrical TNS Correlations (Figure 5)
Found in CylinderTNS/Corrs/ . Each file contains disorder-averaged correlations as a function of lattice distance.
Variable  Type  Description
corrs  1D float array  Disorder-averaged correlator at each lattice distance.
dists  1D float array  Lattice distances corresponding to each entry in corrs .
BP Evolution Gate Errors (Supplementary Material Figure 3)
Found in BPEvolutionGateErrors/ . Each file contains the gate error for one simulation run.
Variable  Type  Description
gate_error  scalar float  Mean gate error epsilon_g from the BP evolution for a given system size, bond dimension, disorder instance, and annealing time.
BP Correction Correlations (Supplementary Material Figure 3)
Found in DiamondTNSCorrs/ . Each file contains correlators before and after the first-order loop correction for a subset of qubit pairs.
Variable  Type  Description
bp_corrs  1D float array  Two-point correlators from BP (before loop correction).
bp_corrected_corrs  1D float array  Two-point correlators after first-order BP loop correction.
Evolution Walltimes (Supplementary Material Figure 4)
Found in DiamondTNSEvolutionWalltimes/ . Each file records the simulation runtime for one BP evolution run.
Variable  Type  Description
time_taken  scalar float  Walltime in seconds for the BP evolution simulation.
Loop Correction Walltimes (Supplementary Material Figure 4)
Found in DiamondTNSLoopCorrectionWalltimes/ . Each file records the walltime for computing one loop-corrected measurement on either CPU or GPU.
Variable  Type  Description
time_taken  scalar float  Walltime in seconds for computing a single loop-corrected correlator measurement.
File Naming Conventions
The .npz filenames encode simulation parameters. The key identifiers are:
Parameter  Meaning
AnnealingTime / ta  Annealing time in nanoseconds
Chi  TNS bond dimension
ChiTrunc  Truncated bond dimension used during boundary-MPS contraction
MPSRANK  Bond dimension of the boundary MPS
LoopLength  Maximum loop length l_max used for loop corrections (0 = BP only)
DisorderNo  Index of the disorder realisation (1-indexed)
Radius  Linear size L of the cylindrical lattice
nx , ny , nz  Lattice dimensions for 3D geometries (number of qubits = 0.25 * nx * ny * nz for diamond lattices, 2 * nx * ny * nz for cubic dimer lattices)
UseGPUtrue / UseGPUfalse  Whether the loop correction was performed on the GPU or the CPU
Installation & Setup
To run the plotting scripts and inspect the raw data, you must have a Python environment installed with the following modules:
NumPy
Matplotlib
Scipy
Recommendation: We recommend using Conda to manage your Python environment.
Data Usage & Reproduction
Loading Data Manually
If you wish to inspect the raw data without using the provided plotting scripts, you can load any .npz file directly in Python:
import numpy as np
data = np.load('path/to/file.npz')# List all available variables in the fileprint(data.files) # Access a specific variable (e.g., corrs)corrs = data['corrs']
Reproducing Figures
Unzip DynamicsofDisorderedSystemsData.zip.
Run the associated script in the associated folder with your Python environment activated:
python Figure2/Plot_Figure2.py
Original Simulation Software
While the provided data is in .npz format for Python, the original simulations were produced using the open-source Julia package:
Tensor Network Quantum Simulator: https://github.com/JoeyT1994/TensorNetworkQuantumSimulator.jl (open access, MIT licensed software) which is built on top of the ITensors.jl Julia package.
Citation
Copy
Tindall, Joseph; Mello, Antonio; Fishman, Matthew et al. (2026). Data from: Dynamics of disordered quantum systems with two- and three-dimensional tensor networks [Dataset]. Dryad. https://doi.org/10.5061/dryad.7d7wm388g
0 views  0 downloads
0 citations
Share:
Link copied
License:
Public domain
Subject keywords
Quantum computing
Quantum mechanics
Quantum systems
Computer and information sciences
Physical sciences
Funding
United States Air Force Office of Scientific Research : FA9550-21
Related works
Primary article
From: Science
https://doi.org/10.1126/science.adx2728
Software
https://github.com/JoeyT1994/TensorNetworkQuantumSimulator.jl
Privacy  Accessibility  Terms of service  Partner terms
Enquiries  Latest news  Subscribe  Jobs & opportunities
© 2026 Dryad. Content on this site is licensed for reuse .
Yes  No
.showModal(); and close with .close(); -->
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [54]: S. Sahu, B. Swingle — Efficient tensor network simulation of quantum many-body physics on sparse graphs (arXiv:2206.04701, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Efficient tensor network simulation of quantum many-body physics on sparse graphs
URL: https://arxiv.org/abs/2206.04701
[2206.04701] Efficient tensor network simulation of quantum many-body physics on sparse graphs
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2206.04701
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
open search
GO
open navigation menu
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2206.04701 (quant-ph)
[Submitted on 9 Jun 2022]
Title: Efficient tensor network simulation of quantum many-body physics on sparse graphs
Authors: Subhayan Sahu , Brian Swingle
View a PDF of the paper titled Efficient tensor network simulation of quantum many-body physics on sparse graphs, by Subhayan Sahu and Brian Swingle
View PDF
Abstract: We study tensor network states defined on an underlying graph which is sparsely connected. Generic sparse graphs are expander graphs with a high probability, and one can represent volume law entangled states efficiently with only polynomial resources. We find that message-passing inference algorithms such as belief propagation can lead to efficient computation of local expectation values for a class of tensor network states defined on sparse graphs. As applications, we study local properties of square root states, graph states, and also employ this method to variationally prepare ground states of gapped Hamiltonians defined on generic graphs. Using the variational method we study the phase diagram of the transverse field quantum Ising model defined on sparse expander graphs.
Comments:  9.5 + 1.5 pages, 11 figures
Subjects:
Quantum Physics (quant-ph) ; Statistical Mechanics (cond-mat.stat-mech); Strongly Correlated Electrons (cond-mat.str-el)
Cite as:  arXiv:2206.04701 [quant-ph]
(or  arXiv:2206.04701v1 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2206.04701
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Subhayan Sahu [ view email ]  [v1]  Thu, 9 Jun 2022 18:00:03 UTC (3,701 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Efficient tensor network simulation of quantum many-body physics on sparse graphs, by Subhayan Sahu and Brian Swingle
View PDF
TeX Source
view license
Current browse context: quant-ph
< prev
|  next >
new  |  recent  | 2022-06
Change to browse by:
cond-mat
cond-mat.stat-mech
cond-mat.str-el
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [55]: S. S. Jahromi, R. Orús — Universal tensor-network algorithm for any infinite lattice (Phys. Rev. B 99, 195105, 2019)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Universal tensor-network algorithm for any infinite lattice
URL: https://doi.org/10.1103/PhysRevB.99.195105
Universal tensor-network algorithm for any infinite lattice | Phys. Rev. B
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review B
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Universal tensor-network algorithm for any infinite lattice
Saeed S. Jahromi 1,2,* and Román Orús 3,2,4  open icon  close icon
1 Department of Physics, Sharif University of Technology, Tehran 14588-89694, Iran
2 Donostia International Physics Center, Paseo Manuel de Lardizabal 4, E-20018 San Sebastián, Spain
3 Institute of Physics, Johannes Gutenberg University, 55099 Mainz, Germany
4 Ikerbasque Foundation for Science, Maria Diaz de Haro 3, E-48013 Bilbao, Spain
* jahromi@physics.sharif.edu
PDF Share open icon  close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. B 99 , 195105 – Published 3 May, 2019
DOI:https://doi.org/10.1103/PhysRevB.99.195105
Export Citation
35
Show metrics open icon  close icon
See more details
Posted by 12 X users
48 readers on Mendeley
35
CITATIONS
Abstract
We present a general graph-based projected entangled-pair state (gPEPS) algorithm to approximate ground states of nearest-neighbor local Hamiltonians on any lattice or graph of infinite size. By introducing the structural matrix, which codifies the details of tensor networks on any graphs in any dimension 𝑑 , we are able to produce a code that can be essentially launched to simulate any lattice. We further introduce an optimized algorithm to compute simple tensor updates as well as expectation values and correlators with a mean-field-like effective environments. Though not being variational, this strategy allows to cope with PEPS of very large bond dimension (e.g., 𝐷 = 1 0 0 ) and produces remarkably accurate results in the thermodynamic limit in many situations, and specially when the correlation length is small and the connectivity of the lattice is large. We prove the validity of our approach by benchmarking the algorithm against known results for several models, i.e., the antiferromagnetic Heisenberg model on a chain, star and cubic lattices, the hardcore Bose-Hubbard model on square lattice, the ferromagnetic Heisenberg model in a field on the pyrochlore lattice, as well as the three-state quantum Potts model in field on the kagome lattice and the spin-1 bilinear-biquadratic Heisenberg model on the triangular lattice. We further demonstrate the performance of gPEPS by studying the quantum phase transition of the 2 ⁢ 𝑑 quantum Ising model in transverse magnetic field on the square lattice, and the phase diagram of the Kitaev-Heisenberg model on the hyperhoneycomb lattice. Our results are in excellent agreement with previous studies.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Physics Subject Headings (PhySH)
Quantum phase transitions
Graph theory
Lattice models in condensed matter
Matrix product states
Projected entangled pair states
Tensor network methods
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (26)
Abstract
Article Text
References
Phys. Rev. B 99 , 195105 – Published 3 May, 2019
Vol. 99, Iss. 19 — 15 May 2019
Received 19 February 2019
Revised 16 April 2019
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.99.195105
©2019 American Physical Society
Outline Information
Outline
Citing Articles (26)
Abstract
Article Text
References
Information
Phys. Rev. B 99 , 195105 – Published 3 May, 2019
Vol. 99, Iss. 19 — 15 May 2019
Received 19 February 2019
Revised 16 April 2019
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.99.195105
©2019 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 2469-9969 (online), 2469-9950 (print). ©2026 American Physical Society. All rights reserved.  Physical Review B™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [56]: P. Pippan et al. — Efficient matrix-product state method for periodic boundary conditions (Phys. Rev. B 81, 081103, 2010)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Efficient matrix-product state method for periodic boundary conditions
URL: https://doi.org/10.1103/PhysRevB.81.081103
Efficient matrix-product state method for periodic boundary conditions | Phys. Rev. B
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review B
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Editors' Suggestion
Rapid Communication
Efficient matrix-product state method for periodic boundary conditions
Peter Pippan 1 , Steven R. White 2 , and Hans Gerd Evertz 1  open icon  close icon
1 Institut für Theoretische Physik, Technische Universität Graz, A-8010 Graz, Austria
2 Department of Physics and Astronomy, University of California, Irvine, California 92697, USA
PDF Share open icon  close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. B 81 , 081103(R) – Published 12 February, 2010
DOI:https://doi.org/10.1103/PhysRevB.81.081103
Export Citation
82
Show metrics open icon  close icon
82
CITATIONS
Abstract
We introduce an efficient method to calculate the ground state of one-dimensional lattice models with periodic boundary conditions. The method works in the representation of matrix product states (MPS), related to the density matrix renormalization group (DMRG) method. It improves on a previous approach by Verstraete et al. We introduce a factorization procedure for long products of MPS matrices, which reduces the computational effort from 𝑚 5 to 𝑚 3 , where 𝑚 is the matrix dimension, and 𝑚 ≃ 1 0 0 – 1 0 0 0 in typical cases. We test the method on the 𝑆 = 1 2 and 𝑆 = 1 Heisenberg chains. It is also applicable to nontranslationally invariant cases. The method makes ground-state calculations with periodic boundary conditions about as efficient as traditional DMRG calculations for systems with open boundaries.
locked icon
locked icon
locked icon
locked icon
locked icon
locked icon
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (77)
Abstract
Article Text
References
Phys. Rev. B 81 , 081103(R) – Published 12 February, 2010
Vol. 81, Iss. 8 — 15 February 2010
Received 30 December 2009
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.81.081103
© 2010 American Physical Society
Outline Information
Outline
Citing Articles (77)
Abstract
Article Text
References
Information
Phys. Rev. B 81 , 081103(R) – Published 12 February, 2010
Vol. 81, Iss. 8 — 15 February 2010
Received 30 December 2009
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevB.81.081103
© 2010 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 2469-9969 (online), 2469-9950 (print). ©2026 American Physical Society. All rights reserved.  Physical Review B™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [57]: C. Guo, D. Poletti, I. Arad — Block belief propagation algorithm for two-dimensional tensor networks (Phys. Rev. B 108, 125111, 2023)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Block belief propagation algorithm for two-dimensional tensor networks
URL: https://arxiv.org/abs/2301.05844
[2301.05844] Block belief propagation algorithm for two-dimensional tensor networks
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions, and all contributors. Donate
> quant-ph > arXiv:2301.05844
Help | Advanced Search
All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text
Search
GO
quick links
Login
Help Pages
About
Quantum Physics
arXiv:2301.05844 (quant-ph)
[Submitted on 14 Jan 2023 (v1), last revised 7 Sep 2023 (this version, v3)]
Title:Block belief propagation algorithm for two-dimensional tensor networks
Authors:Chu Guo, Dario Poletti, Itai Arad View a PDF of the paper titled Block belief propagation algorithm for two-dimensional tensor networks, by Chu Guo and 2 other authors
View PDF
Abstract:Belief propagation is a well-studied algorithm for approximating local marginals of multivariate probability distribution over complex networks, while tensor network states are powerful tools for quantum and classical many-body problems. Building on a recent connection between the belief propagation algorithm and the problem of tensor network contraction, we propose a block belief propagation algorithm for contracting two-dimensional tensor networks and approximating the ground state of $2D$ systems. The advantages of our method are three-fold: 1) the same algorithm works for both finite and infinite systems; 2) it allows natural and efficient parallelization; 3) given its flexibility it would allow to deal with different unit cells. As applications, we use our algorithm to study the $2D$ Heisenberg and transverse Ising models, and show that the accuracy of the method is on par with state-of-the-art results.
Comments: 12 pages, 13 figures
Subjects:  Quantum Physics (quant-ph); Strongly Correlated Electrons (cond-mat.str-el); Computational Physics (physics.comp-ph)
Cite as: arXiv:2301.05844 [quant-ph]
(or  arXiv:2301.05844v3 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2301.05844
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference: Physical Review B, 108, 125111 (2023)
Related DOI:  https://doi.org/10.1103/PhysRevB.108.125111
Focus to learn more
DOI(s) linking to related resources
Submission history From: Chu Guo [view email]  [v1] Sat, 14 Jan 2023 07:37:08 UTC (1,628 KB)
[v2] Mon, 6 Mar 2023 03:07:47 UTC (1,574 KB)
[v3] Thu, 7 Sep 2023 00:25:54 UTC (2,263 KB)
Full-text links: Access Paper:
View a PDF of the paper titled Block belief propagation algorithm for two-dimensional tensor networks, by Chu Guo and 2 other authorsView PDFTeX Source
view license
Current browse context:
quant-ph
< prev    |    next >
new |  recent | 2023-01
Change to browse by:  cond-mat cond-mat.str-el physics physics.comp-ph
References & Citations
INSPIRE HEP
NASA ADSGoogle Scholar
Semantic Scholar
export BibTeX citation Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools  Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer (What is the Explorer?)
Connected Papers Toggle
Connected Papers (What is Connected Papers?)
Litmaps Toggle
Litmaps (What is Litmaps?)
scite.ai Toggle
scite Smart Citations (What are Smart Citations?)
Code, Data, Media  Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv (What is alphaXiv?)
Links to Code Toggle
CatalyzeX Code Finder for Papers (What is CatalyzeX?)
DagsHub Toggle
DagsHub (What is DagsHub?)
GotitPub Toggle
Gotit.pub (What is GotitPub?)
Huggingface Toggle
Hugging Face (What is Huggingface?)
ScienceCast Toggle
ScienceCast (What is ScienceCast?)
Demos  Demos
Replicate Toggle
Replicate (What is Replicate?)
Spaces Toggle
Hugging Face Spaces (What is Spaces?)
Spaces Toggle
TXYZ.AI (What is TXYZ.AI?)
Related Papers  Recommenders and Search Tools
Link to Influence Flower
Influence Flower (What are Influence Flowers?)
Core recommender toggle
CORE Recommender (What is CORE?)
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs.
Which authors of this paper are endorsers? | Disable MathJax (What is MathJax?)
About
Help
contact arXivClick here to contact arXiv Contact
subscribe to arXiv mailingsClick here to subscribe Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [58]: G. Vidal — Efficient classical simulation of slightly entangled quantum computations (Phys. Rev. Lett. 91, 147902, 2003)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Efficient classical simulation of slightly entangled quantum computations
URL: https://doi.org/10.1103/PhysRevLett.91.147902
Efficient Classical Simulation of Slightly Entangled Quantum Computations | Phys. Rev. Lett.
Opens in a new window Opens an external website Opens an external website in a new window
This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. Privacy Policy
Accept Deny non-essential Manage preferences
Close Cookie Preferences
Skip to Main Content
All Journals Physics Magazine
search icon
Article Lookup
user icon
Sign in
search icon
Article Lookup
user icon
Sign in
user icon
Sign in
All Journals Physics Magazine
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Physical Review Letters
Highlights
Recent
Accepted
Collections
Authors
Referees
Press
About
Editorial Team
RSS
Efficient Classical Simulation of Slightly Entangled Quantum Computations
Guifré Vidal  open icon  close icon
Institute for Quantum Information, California Institute of Technology, Pasadena, California 91125, USA
PDF Share open icon  close icon
X
Facebook
Mendeley
LinkedIn
Reddit
Sina Weibo
Phys. Rev. Lett. 91 , 147902 – Published 1 October, 2003
DOI:https://doi.org/10.1103/PhysRevLett.91.147902
Export Citation
2.1k
Show metrics open icon  close icon
See more details
Posted by 16 X users
Referenced in 7 patents
Referenced in 2 Wikipedia pages
Reddited by 2
Mentioned in 7 Q&A threads
731 readers on Mendeley
4 readers on CiteULike
2.1k
CITATIONS
Abstract
We present a classical protocol to efficiently simulate any pure-state quantum computation that involves only a restricted amount of entanglement. More generally, we show how to classically simulate pure-state quantum computations on 𝑛 qubits by using computational resources that grow linearly in 𝑛 and exponentially in the amount of entanglement in the quantum computer. Our results imply that a necessary condition for an exponential computational speedup (with respect to classical computations) is that the amount of entanglement increases with the size 𝑛 of the computation, and provide an explicit lower bound on the required growth.
Authorization Required
We need you to provide your credentials before accessing this content.
Log in via your institution
If your institution provides access using Shibboleth/OpenAthens log in.
Log in via APS Member Subscription
If you have a personal subscription through your APS membership please log in.
Starting August 1, 2019 APS member subscribers will need to log in using your member credentials instead of your APS Journal Account.
APS Member Log In
Other Options
Buy Article »
Log in with APS Journals Account
Log in with username/password provided by your institution
Get access through a U.S. public or high school
References (Subscription Required)
Outline Information
Citing Articles (1767)
Abstract
Article Text
References
Phys. Rev. Lett. 91 , 147902 – Published 1 October, 2003
Vol. 91, Iss. 14 — 3 October 2003
Received 25 February 2003
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevLett.91.147902
© 2003 American Physical Society
Outline Information
Outline
Citing Articles (1767)
Abstract
Article Text
References
Information
Phys. Rev. Lett. 91 , 147902 – Published 1 October, 2003
Vol. 91, Iss. 14 — 3 October 2003
Received 25 February 2003
Export Citation
Reuse & Permissions
DOI: https://doi.org/10.1103/PhysRevLett.91.147902
© 2003 American Physical Society
open icon
close icon
News Join APS
Authors
open icon
close icon
General Information Submit a Manuscript Publication Rights Open Science SCOAP 3 Policies & Practices Tips for Authors Professional Conduct
Reviewers
open icon
close icon
General Information Submit a Report Update Your Information Policies & Practices Reviewer FAQ Guidelines for Reviewers Outstanding Referees
Librarians
open icon
close icon
General Information Subscriptions Online License Agreement Usage Statistics Your Account
Students
open icon
close icon
Physics PhysicsCentral Student Membership
Connect
open icon
close icon
Privacy Policies Contact Information Feedback
News Join APS
Authors
General Information
Submit a Manuscript
Publication Rights
Open Science
SCOAP 3
Policies & Practices
Tips for Authors
Professional Conduct
Reviewers
General Information
Submit a Report
Update Your Information
Policies & Practices
Reviewer FAQ
Guidelines for Reviewers
Outstanding Referees
Librarians
General Information
Subscriptions
Online License Agreement
Usage Statistics
Your Account
Students
Physics
PhysicsCentral
Student Membership
Connect
Privacy
Policies
Contact Information
Feedback
ISSN 1079-7114 (online), 0031-9007 (print). ©2026 American Physical Society. All rights reserved.  Physical Review Letters™ is a trademark of the American Physical Society, registered in the United States, Canada, European Union, and Japan. The APS Physics logo and Physics logo are trademarks of the American Physical Society. Information about registration may be found here . Use of the American Physical Society websites and journals implies that the user has read and agrees to our Terms and Conditions and any applicable Subscription Agreement .
Sign In to Your Journals Account
Username
Password
Forgot your username/password?
Create an account
Sign in to your APS Member Account
Sign in via your Institution  Sign In
Filter
Filter
Article Lookup
Enter a citation
Paste a citation or DOI
Lookup Article
Journal APS Open Sci.  Phys. Rev. Lett.  Phys. Rev. X  PRX Energy  PRX Life  PRX Quantum  Rev. Mod. Phys.  Phys. Rev. A  Phys. Rev. B  Phys. Rev. C  Phys. Rev. D  Phys. Rev. E  Phys. Rev. Research  Phys. Rev. Accel. Beams  Phys. Rev. ST Accel. Beams  Phys. Rev. Applied  Phys. Rev. Fluids  Phys. Rev. Materials  Phys. Rev. Phys. Educ. Res.  Phys. Rev. ST Phys. Educ. Res.  Physics  Phys. Rev.  Phys. Rev. (Series I)  Physics Physique Fizika
Volume
Article ID / page number
Lookup Article
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [59]: Y. Zhou et al. — What limits the simulation of quantum computers? (Phys. Rev. X 10, 041038, 2020)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: What limits the simulation of quantum computers?
URL: https://arxiv.org/abs/2002.07730
[2002.07730] What limits the simulation of quantum computers?
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions, and all contributors. Donate
> quant-ph > arXiv:2002.07730
Help | Advanced Search
All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text
Search
GO
quick links
Login
Help Pages
About
Quantum Physics
arXiv:2002.07730 (quant-ph)
[Submitted on 18 Feb 2020 (v1), last revised 24 Mar 2020 (this version, v2)]
Title:What limits the simulation of quantum computers?
Authors:Yiqing Zhou, E. Miles Stoudenmire, Xavier Waintal View a PDF of the paper titled What limits the simulation of quantum computers?, by Yiqing Zhou and E. Miles Stoudenmire and Xavier Waintal
View PDF
Abstract:It is imperative that useful quantum computers be very difficult to simulate classically; otherwise classical computers could be used for the applications envisioned for the quantum ones. Perfect quantum computers are unarguably exponentially difficult to simulate: the classical resources required grow exponentially with the number of qubits N or the depth D of the circuit. Real quantum computing devices, however, are characterized by an exponentially decaying fidelity \mathcal{F} \sim (1-\epsilon)^{ND} with an error rate \epsilon per operation as small as \approx 1\% for current devices. In this work, we demonstrate that real quantum computers can be simulated at a tiny fraction of the cost that would be needed for a perfect quantum computer. Our algorithms compress the representations of quantum wavefunctions using matrix product states (MPS), which capture states with low to moderate entanglement very accurately. This compression introduces a finite error rate \epsilon so that the algorithms closely mimic the behavior of real quantum computing devices. The computing time of our algorithm increases only linearly with N and D. We illustrate our algorithms with simulations of random circuits for qubits connected in both one and two dimensional lattices. We find that \epsilon can be decreased at a polynomial cost in computing power down to a minimum error \epsilon_\infty. Getting below \epsilon_\infty requires computing resources that increase exponentially with \epsilon_\infty/\epsilon. For a two dimensional array of N=54 qubits and a circuit with Control-Z gates, error rates better than state-of-the-art devices can be obtained on a laptop in a few hours. For more complex gates such as a swap gate followed by a controlled rotation, the error rate increases by a factor three for similar computing time.
Comments: New data added, 14 figures
Subjects:  Quantum Physics (quant-ph); Strongly Correlated Electrons (cond-mat.str-el)
Cite as: arXiv:2002.07730 [quant-ph]
(or  arXiv:2002.07730v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2002.07730
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference: Phys. Rev. X 10, 041038 (2020)
Related DOI:  https://doi.org/10.1103/PhysRevX.10.041038
Focus to learn more
DOI(s) linking to related resources
Submission history From: Xavier Waintal [view email]  [v1] Tue, 18 Feb 2020 17:00:39 UTC (317 KB)
[v2] Tue, 24 Mar 2020 16:25:01 UTC (326 KB)
Full-text links: Access Paper:
View a PDF of the paper titled What limits the simulation of quantum computers?, by Yiqing Zhou and E. Miles Stoudenmire and Xavier WaintalView PDFTeX Source
view license
Current browse context:
quant-ph
< prev    |    next >
new |  recent | 2020-02
Change to browse by:  cond-mat cond-mat.str-el
References & Citations
INSPIRE HEP
NASA ADSGoogle Scholar
Semantic Scholar
1 blog link (what is this?)
export BibTeX citation Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools  Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer (What is the Explorer?)
Connected Papers Toggle
Connected Papers (What is Connected Papers?)
Litmaps Toggle
Litmaps (What is Litmaps?)
scite.ai Toggle
scite Smart Citations (What are Smart Citations?)
Code, Data, Media  Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv (What is alphaXiv?)
Links to Code Toggle
CatalyzeX Code Finder for Papers (What is CatalyzeX?)
DagsHub Toggle
DagsHub (What is DagsHub?)
GotitPub Toggle
Gotit.pub (What is GotitPub?)
Huggingface Toggle
Hugging Face (What is Huggingface?)
ScienceCast Toggle
ScienceCast (What is ScienceCast?)
Demos  Demos
Replicate Toggle
Replicate (What is Replicate?)
Spaces Toggle
Hugging Face Spaces (What is Spaces?)
Spaces Toggle
TXYZ.AI (What is TXYZ.AI?)
Related Papers  Recommenders and Search Tools
Link to Influence Flower
Influence Flower (What are Influence Flowers?)
Core recommender toggle
CORE Recommender (What is CORE?)
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs.
Which authors of this paper are endorsers? | Disable MathJax (What is MathJax?)
About
Help
contact arXivClick here to contact arXiv Contact
subscribe to arXiv mailingsClick here to subscribe Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [60]: S.-B. B. Lee et al. — Scalable projected entangled-pair state representation of random quantum circuit states (Phys. Rev. Res. 7, 033252, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Scalable projected entangled-pair state representation of random quantum circuit states
URL: https://arxiv.org/abs/2504.04769
[2504.04769] Scalable projected entangled-pair state representation of random quantum circuit states
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions, and all contributors. Donate
> quant-ph > arXiv:2504.04769
Help | Advanced Search
All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text
Search
GO
quick links
Login
Help Pages
About
Quantum Physics
arXiv:2504.04769 (quant-ph)
[Submitted on 7 Apr 2025 (v1), last revised 18 Sep 2025 (this version, v2)]
Title:Scalable projected entangled-pair state representation of random quantum circuit states
Authors:Sung-Bin B. Lee, Hee Ryang Choi, Daniel Donghyon Ohm, Seung-Sup B. Lee View a PDF of the paper titled Scalable projected entangled-pair state representation of random quantum circuit states, by Sung-Bin B. Lee and 3 other authors
View PDF HTML (experimental)
Abstract:Classical simulation of a programmable quantum processor is crucial in identifying the threshold of a quantum advantage. We demonstrate the simple update of projected entangled-pair states (PEPSs) in the Vidal gauge that represent random quantum circuit states, which center around recent quantum advantage claims. Applied to square lattices of qubits akin to state-of-the-art superconducting processors, the PEPS representation is exact for circuit depths less than \mathcal{D}_\mathrm{tr} = \beta\log_2\chi, where \chi is the maximum bond dimension and 2 \lesssim \beta \lesssim 4 depends on the choice of two-qubit gates, independent of the qubit number n. We find the universal scaling behaviors of the state fidelity by treating large-scale circuits of n \leq 10^{4}, using \chi \leq 128 on a conventional CPU. Our method has a polynomial scaling of computational costs with n for circuit depth \mathcal{D}=O(\log n) and is more advantageous than matrix product state approaches if n is large. This work underscores PEPSs as a scalable tool for benchmarking quantum algorithms with future potential for sampling applications using advanced contraction techniques.
Subjects:  Quantum Physics (quant-ph); Computational Physics (physics.comp-ph)
Cite as: arXiv:2504.04769 [quant-ph]
(or  arXiv:2504.04769v2 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2504.04769
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference: Phys. Rev. Research 7, 033252 (2025)
Related DOI:  https://doi.org/10.1103/rzgm-cywf
Focus to learn more
DOI(s) linking to related resources
Submission history From: Seung-Sup Lee Prof. [view email]  [v1] Mon, 7 Apr 2025 06:47:48 UTC (763 KB)
[v2] Thu, 18 Sep 2025 04:09:26 UTC (759 KB)
Full-text links: Access Paper:
View a PDF of the paper titled Scalable projected entangled-pair state representation of random quantum circuit states, by Sung-Bin B. Lee and 3 other authorsView PDFHTML (experimental)TeX Source
view license
Current browse context:
quant-ph
< prev    |    next >
new |  recent | 2025-04
Change to browse by:  physics physics.comp-ph
References & Citations
INSPIRE HEP
NASA ADSGoogle Scholar
Semantic Scholar
export BibTeX citation Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools  Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer (What is the Explorer?)
Connected Papers Toggle
Connected Papers (What is Connected Papers?)
Litmaps Toggle
Litmaps (What is Litmaps?)
scite.ai Toggle
scite Smart Citations (What are Smart Citations?)
Code, Data, Media  Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv (What is alphaXiv?)
Links to Code Toggle
CatalyzeX Code Finder for Papers (What is CatalyzeX?)
DagsHub Toggle
DagsHub (What is DagsHub?)
GotitPub Toggle
Gotit.pub (What is GotitPub?)
Huggingface Toggle
Hugging Face (What is Huggingface?)
ScienceCast Toggle
ScienceCast (What is ScienceCast?)
Demos  Demos
Replicate Toggle
Replicate (What is Replicate?)
Spaces Toggle
Hugging Face Spaces (What is Spaces?)
Spaces Toggle
TXYZ.AI (What is TXYZ.AI?)
Related Papers  Recommenders and Search Tools
Link to Influence Flower
Influence Flower (What are Influence Flowers?)
Core recommender toggle
CORE Recommender (What is CORE?)
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs.
Which authors of this paper are endorsers? | Disable MathJax (What is MathJax?)
About
Help
contact arXivClick here to contact arXiv Contact
subscribe to arXiv mailingsClick here to subscribe Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [61]: L. Mauron, G. Carleo — Challenging the quantum advantage frontier with large-scale classical simulations of annealing dynamics (arXiv:2503.08247, 2025)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Challenging the quantum advantage frontier with large-scale classical simulations of annealing dynamics
URL: https://arxiv.org/abs/2503.08247
[2503.08247] Challenging the Quantum Advantage Frontier with Large-Scale Classical Simulations of Annealing Dynamics
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> quant-ph > arXiv:2503.08247
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Quantum Physics
arXiv:2503.08247 (quant-ph)
[Submitted on 11 Mar 2025]
Title: Challenging the Quantum Advantage Frontier with Large-Scale Classical Simulations of Annealing Dynamics
Authors: Linda Mauron , Giuseppe Carleo
View a PDF of the paper titled Challenging the Quantum Advantage Frontier with Large-Scale Classical Simulations of Annealing Dynamics, by Linda Mauron and 1 other authors
View PDF  HTML (experimental)
Abstract: Recent demonstrations of D-Wave's annealing-based quantum simulators have established new benchmarks for quantum computational advantage [ arXiv:2403.00910 ]. However, the precise location of the classical-quantum computational frontier remains an open question, as classical simulation strategies continue to evolve. Here, we demonstrate that time-dependent variational Monte Carlo (t-VMC) with a physically motivated Jastrow-Feenberg wave function can efficiently simulate the quantum annealing of spin glasses up to system sizes previously thought to be intractable. Our approach achieves accuracy comparable to that of quantum processing units while requiring only polynomially scaling computational resources, in stark contrast to entangled-limited tensor network methods that scale exponentially. For systems up to 128 spins on a three-dimensional diamond lattice, we maintain correlation errors below 7%, which match or exceed the precision of existing quantum hardware. Rigorous assessments of residual energies and time-dependent variational principle errors establish clear performance benchmarks for classical simulations. These findings substantially shift the quantum advantage frontier and underscore that classical variational techniques, which are not fundamentally constrained by entanglement growth, remain competitive at larger system sizes than previously anticipated.
Subjects:
Quantum Physics (quant-ph)
Cite as:  arXiv:2503.08247 [quant-ph]
(or  arXiv:2503.08247v1 [quant-ph] for this version)
https://doi.org/10.48550/arXiv.2503.08247
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Linda Mauron [ view email ]  [v1]  Tue, 11 Mar 2025 10:09:37 UTC (1,641 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled Challenging the Quantum Advantage Frontier with Large-Scale Classical Simulations of Annealing Dynamics, by Linda Mauron and 1 other authors
View PDF
HTML (experimental)
TeX Source
view license
Current browse context:
quant-ph
< prev
|  next >
new  |  recent  | 2025-03
References & Citations
INSPIRE HEP
NASA ADS
Google Scholar
Semantic Scholar
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [62]: J. Bezanson et al. — Julia: A Fresh Approach to Numerical Computing (SIAM Rev. 59, 65-98, 2017)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: Julia: A Fresh Approach to Numerical Computing
URL: https://arxiv.org/abs/1411.1607
[1411.1607] Julia: A Fresh Approach to Numerical Computing
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions, and all contributors. Donate
> cs > arXiv:1411.1607
Help | Advanced Search
All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text
Search
GO
quick links
Login
Help Pages
About
Computer Science > Mathematical Software
arXiv:1411.1607 (cs)
[Submitted on 6 Nov 2014 (v1), last revised 19 Jul 2015 (this version, v4)]
Title:Julia: A Fresh Approach to Numerical Computing
Authors:Jeff Bezanson, Alan Edelman, Stefan Karpinski, Viral B. Shah View a PDF of the paper titled Julia: A Fresh Approach to Numerical Computing, by Jeff Bezanson and 3 other authors
View PDF
Abstract:Bridging cultures that have often been distant, Julia combines expertise from the diverse fields of computer science and computational science to create a new approach to numerical computing. Julia is designed to be easy and fast. Julia questions notions generally held as "laws of nature" by practitioners of numerical computing:
1. High-level dynamic programs have to be slow.
2. One must prototype in one language and then rewrite in another language for speed or deployment, and
3. There are parts of a system for the programmer, and other parts best left untouched as they are built by the experts.
We introduce the Julia programming language and its design --- a dance between specialization and abstraction. Specialization allows for custom treatment. Multiple dispatch, a technique from computer science, picks the right algorithm for the right circumstance. Abstraction, what good computation is really about, recognizes what remains the same after differences are stripped away. Abstractions in mathematics are captured as code through another technique from computer science, generic programming.
Julia shows that one can have machine performance without sacrificing human convenience.
Comments: 37 pages
Subjects:  Mathematical Software (cs.MS)
Cite as: arXiv:1411.1607 [cs.MS]
(or  arXiv:1411.1607v4 [cs.MS] for this version)
https://doi.org/10.48550/arXiv.1411.1607
Focus to learn more
arXiv-issued DOI via DataCite
Submission history From: Alan Edelman [view email]  [v1] Thu, 6 Nov 2014 13:39:40 UTC (2,236 KB)
[v2] Fri, 7 Nov 2014 11:19:21 UTC (2,236 KB)
[v3] Fri, 12 Dec 2014 22:40:09 UTC (3,140 KB)
[v4] Sun, 19 Jul 2015 19:58:28 UTC (2,255 KB)
Full-text links: Access Paper:
View a PDF of the paper titled Julia: A Fresh Approach to Numerical Computing, by Jeff Bezanson and 3 other authorsView PDFTeX Source
view license
Current browse context:
cs.MS
< prev    |    next >
new |  recent | 2014-11
Change to browse by:  cs
References & Citations
NASA ADSGoogle Scholar
Semantic Scholar
DBLP - CS Bibliography
listing | bibtex
Jeff BezansonAlan EdelmanStefan KarpinskiViral B. Shah
export BibTeX citation Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools  Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer (What is the Explorer?)
Connected Papers Toggle
Connected Papers (What is Connected Papers?)
Litmaps Toggle
Litmaps (What is Litmaps?)
scite.ai Toggle
scite Smart Citations (What are Smart Citations?)
Code, Data, Media  Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv (What is alphaXiv?)
Links to Code Toggle
CatalyzeX Code Finder for Papers (What is CatalyzeX?)
DagsHub Toggle
DagsHub (What is DagsHub?)
GotitPub Toggle
Gotit.pub (What is GotitPub?)
Huggingface Toggle
Hugging Face (What is Huggingface?)
ScienceCast Toggle
ScienceCast (What is ScienceCast?)
Demos  Demos
Replicate Toggle
Replicate (What is Replicate?)
Spaces Toggle
Hugging Face Spaces (What is Spaces?)
Spaces Toggle
TXYZ.AI (What is TXYZ.AI?)
Related Papers  Recommenders and Search Tools
Link to Influence Flower
Influence Flower (What are Influence Flowers?)
Core recommender toggle
CORE Recommender (What is CORE?)
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs.
Which authors of this paper are endorsers? | Disable MathJax (What is MathJax?)
About
Help
contact arXivClick here to contact arXiv Contact
subscribe to arXiv mailingsClick here to subscribe Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Ref [63]: M. Fishman, S. R. White, E. M. Stoudenmire — The ITensor Software Library for tensor network calculations (arXiv:2007.14822, 2022)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Title: The ITensor Software Library for tensor network calculations
URL: https://arxiv.org/abs/2007.14822
[2007.14822] The ITensor Software Library for Tensor Network Calculations
Skip to main content
Learn about arXiv becoming an independent nonprofit.
We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors.  Donate
> cs > arXiv:2007.14822
Help | Advanced Search
All fields  Title  Author  Abstract  Comments  Journal reference  ACM classification  MSC classification  Report number  arXiv identifier  DOI  ORCID  arXiv author ID  Help pages  Full text
Search
GO
quick links
Login
Help Pages
About
-->
Computer Science > Mathematical Software
arXiv:2007.14822 (cs)
[Submitted on 28 Jul 2020 ( v1 ), last revised 20 Dec 2021 (this version, v2)]
Title: The ITensor Software Library for Tensor Network Calculations
Authors: Matthew Fishman , Steven R. White , E. Miles Stoudenmire
View a PDF of the paper titled The ITensor Software Library for Tensor Network Calculations, by Matthew Fishman and 2 other authors
View PDF
Abstract: ITensor is a system for programming tensor network calculations with an interface modeled on tensor diagram notation, which allows users to focus on the connectivity of a tensor network without manually bookkeeping tensor indices. The ITensor interface rules out common programming errors and enables rapid prototyping of tensor network algorithms. After discussing the philosophy behind the ITensor approach, we show examples of each part of the interface including Index objects, the ITensor product operator, tensor factorizations, tensor storage types, algorithms for matrix product state (MPS) and matrix product operator (MPO) tensor networks, quantum number conserving block-sparse tensors, and the NDTensors library. We also review publications that have used ITensor for quantum many-body physics and for other areas where tensor networks are increasingly applied. To conclude we discuss promising features and optimizations to be added in the future.
Comments:  Submitted to SciPost Physics Codebases. Version 2 contains benchmarks of ITensor C++ and Julia versions, and link to external benchmarks including TeNPy software
Subjects:
Mathematical Software (cs.MS) ; Strongly Correlated Electrons (cond-mat.str-el); Computational Physics (physics.comp-ph)
Cite as:  arXiv:2007.14822 [cs.MS]
(or  arXiv:2007.14822v2 [cs.MS] for this version)
https://doi.org/10.48550/arXiv.2007.14822
Focus to learn more
arXiv-issued DOI via DataCite
Journal reference:  SciPost Phys. Codebases 4 (2022)
Related DOI :
https://doi.org/10.21468/SciPostPhysCodeb.4
Focus to learn more
DOI(s) linking to related resources
Submission history From: E.M. Stoudenmire [ view email ]  [v1]  Tue, 28 Jul 2020 15:38:57 UTC (708 KB)
[v2]  Mon, 20 Dec 2021 22:16:09 UTC (815 KB)
Full-text links:
Access Paper:
View a PDF of the paper titled The ITensor Software Library for Tensor Network Calculations, by Matthew Fishman and 2 other authors
View PDF
TeX Source
view license
Current browse context:
cs.MS
< prev
|  next >
new  |  recent  | 2020-07
Change to browse by:
cond-mat
cond-mat.str-el
cs
physics
physics.comp-ph
References & Citations
NASA ADS
Google Scholar
Semantic Scholar
DBLP - CS Bibliography
listing | bibtex
E. Miles Stoudenmire
export BibTeX citation  Loading...
BibTeX formatted citation
×
loading...
Data provided by:
Bookmark
Bibliographic Tools
Bibliographic and Citation Tools
Bibliographic Explorer Toggle
Bibliographic Explorer ( What is the Explorer? )
Connected Papers Toggle
Connected Papers ( What is Connected Papers? )
Litmaps Toggle
Litmaps ( What is Litmaps? )
scite.ai Toggle
scite Smart Citations ( What are Smart Citations? )
Code, Data, Media
Code, Data and Media Associated with this Article
alphaXiv Toggle
alphaXiv ( What is alphaXiv? )
Links to Code Toggle
CatalyzeX Code Finder for Papers ( What is CatalyzeX? )
DagsHub Toggle
DagsHub ( What is DagsHub? )
GotitPub Toggle
Gotit.pub ( What is GotitPub? )
Huggingface Toggle
Hugging Face ( What is Huggingface? )
ScienceCast Toggle
ScienceCast ( What is ScienceCast? )
Demos
Demos
Replicate Toggle
Replicate ( What is Replicate? )
Spaces Toggle
Hugging Face Spaces ( What is Spaces? )
Spaces Toggle
TXYZ.AI ( What is TXYZ.AI? )
Related Papers
Recommenders and Search Tools
Link to Influence Flower
Influence Flower ( What are Influence Flowers? )
Core recommender toggle
CORE Recommender ( What is CORE? )
Author
Venue
Institution
Topic
About arXivLabs
arXivLabs: experimental projects with community collaborators
arXivLabs is a framework that allows collaborators to develop and share new arXiv features directly on our website.
Both individuals and organizations that work with arXivLabs have embraced and accepted our values of openness, community, excellence, and user data privacy. arXiv is committed to these values and only works with partners that adhere to them.
Have an idea for a project that will add value for arXiv's community? Learn more about arXivLabs .
Which authors of this paper are endorsers? | Disable MathJax ( What is MathJax? )
About
Help
contact arXiv Click here to contact arXiv
Contact
subscribe to arXiv mailings Click here to subscribe
Subscribe
Copyright
Privacy Policy
Web Accessibility Assistance
arXiv Operational Status