> Source: https://github.com/coderonion/awesome-rust-list

GitHub - coderonion/awesome-rust-list: This repository lists some awesome public Rust projects, Videos, Blogs and Jobs.
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
coderonion / awesome-rust-list Public
Notifications You must be signed in to change notification settings
Fork 6
Star 46
This repository lists some awesome public Rust projects, Videos, Blogs and Jobs.
46 stars 6 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 0
Pull requests 0
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
coderonion/awesome-rust-list
main
1 Branch 0 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
Awesome-Rust-List
This repository lists some awesome public Rust projects, Videos, Blogs and Jobs.
Contents
Awesome-Rust-List
Contents
Summary
Official Rust
Awesome List
Learning Resources
Performance Benchmark
Data Structure and Algorithm
Parallel and Async Library
FFI Bindings
GPU Programming
Web3 and ZKP Framework
Scientific Computation
Numerical Calculation
Linear Algebra
Lie Groups
Optimization Framework
Evolutionary Computation
Finite Element Analysis
Data Analysis and Visualization
Machine Learning
Machine Learning Framework
Large Language Model
AI Generated Content
Object Detection
Design Pattern
Static Variables
Memory Allocator
Embedded Development
General Operating System
Robot Operating System
Hardware Description Language
Logic Programming
Shared Memory
Remote Desktop
Date and Time
Data Encryption
Database
Sensor and Communication Protocol
Signal Processing
File Processing
Image and Video Processing
Live Media Server
Localization and Mapping
Path Planning
Motion Control
Finite State Machine
Game Field
Search Engine
Network Service
Web Crawler
RPC Framework
Web Framework
WebAssembly
Graphics Library
GUI
GUI Framework
GUI Software
Dioxus-Related
Slint-Related
Tauri-Related
Makepad-Related
Blogs
Jobs and Interview
Summary
Official Rust
Rust  : The Rust Programming Language. Empowering everyone to build reliable and efficient software. www.rust-lang.org. Rust Foundation.
Rust std : The Rust Standard Library.
Docs.rs : Docs.rs documentation.
crates.io : The Rust community's crate registry.
Lib.rs : Fast, lightweight, opinionated, unofficial alternative to crates.io.
Cheats.rs  : Rust Language Cheat Sheet. cheats.rs
Explaine.rs : The explaine.rs
Rust Playground : The Rust Playground. rust-lang/rust-playground  .
Awesome List
rust-unofficial/awesome-rust  : A curated list of Rust code and resources.
rust-embedded/awesome-embedded-rust  : Curated list of resources for Embedded and Low-level development in the Rust programming language.
TaKO8Ki/awesome-alternatives-in-rust  : A curated list of replacements for existing software written in Rust.
rust-in-blockchain/awesome-blockchain-rust  : Collect libraries and packages about blockchain/cryptography in Rust.
jetli/awesome-yew  : 😎 A curated list of awesome things related to Yew / WebAssembly.
vaaaaanquish/Awesome-Rust-MachineLearning  : This repository is a list of machine learning libraries written in Rust. It's a compilation of GitHub repositories, blogs, books, movies, discussions, papers, etc. 🦀
awesome-rust-com/awesome-rust  :A curated list of awesome Rust frameworks, libraries and software. awesome-rust
rust-cc/awesome-cryptography-rust  : Collect libraries and packages about cryptography in Rust.
ddotta/awesome-polars  : A curated list of Polars talks, tools, examples & articles. Contributions welcome !
ex0dus-0x/awesome-rust-security  : Curated list of awesome projects and resources related to Rust and computer security.
robotics-rs/robotics.rs  : List of (awesome) Rust libraries for Robotics. Web site of robotics.rs. See index.md. robotics.rs
jgsimard/RustRobotics  : This package is a rust implementation of robotics algorithms. So far, the main source is the book Probabilistic Robotics.
rsasaki0109/RustRobotics  : Rust implementation of PythonRobotics such as EKF, DWA, Pure Pursuit, LQR.
Learning Resources
Rust std : The Rust Standard Library.
Docs.rs : Docs.rs documentation.
Cheats.rs  : Rust Language Cheat Sheet. cheats.rs
kingfree/cheats.rs  : Rust 语言备忘清单 (简体中文). Rust 语言备忘清单
Explaine.rs : The explaine.rs
rust-lang/book  : The Rust Programming Language. doc.rust-lang.org/book/
rust-lang/rust-by-example  : Learn Rust with examples (Live code editor included). doc.rust-lang.org/stable/rust-by-example/
rust-lang/rustlings  : rustlings 🦀❤. 🦀 Small exercises to get you used to reading and writing Rust code!
google/comprehensive-rust  : This is the Rust course used by the Android team at Google. It provides you the material to quickly teach Rust. google.github.io/comprehensive-rust/. 欢迎来到 Comprehensive Rust 🦀
ehsanmok/create-your-own-lang-with-rust  : Create your own programming language with Rust. createlang.rs.
sunface/rust-course  : Rust语言圣经(Rust Course)。“连续六年成为全世界最受喜爱的语言，无 GC 也无需手动内存管理、极高的性能和安全性、过程/OO/函数式编程、优秀的包管理、JS 未来基石" — 工作之余的第二语言来试试 Rust 吧。<<Rust语言圣经>>拥有全面且深入的讲解、生动贴切的示例、德芙般丝滑的内容，甚至还有JS程序员关注的 WASM 和 Deno 等专题。这可能是目前最用心的 Rust 中文学习教程 / Book。 course.rs
sunface/rust-by-practice  : Learning Rust By Practice, narrowing the gap between beginner and skilled-dev through challenging examples, exercises and projects. Rust By Practice(Rust语言实战)
sunface/new-rusty-book  : A curated list of recipes and repos that can be used to build your rusty projects. Rusty Book= Cookbook + Awesome Rust！ rusty.course.rs
smallnest/concurrency-programming-via-rust  : concurrency programming via rust. 深入理解Rust并发编程。
mainmatter/100-exercises-to-learn-rust  : A self-paced course to learn Rust, one exercise at a time. 100 Exercises To Learn Rust
WTFAcademy/WTF-Rust  : Rust 教程：零知识证明系列教程。
RustyCab/LearnRustEasy  : 本书的定位是做一本方便入门的Rust书籍，所以本书主要讲解Rust的基础知识，对于一些高阶的知识本书中尽量少提及或者不提及，希望本书能让您的Rust入门之路不再崎岖！本书在线阅读地址 LearnRustEasy.
tyrchen/geektime-rust  : geektime-rust：我的极客时间 Rust 课程的代码仓库，随课程更新。
the-web3/chaineye-rust  : Rust 中文教程。本教程由链眼社区出品。
reganzm/hug_rust  : 拥抱rust。
pretzelhammer/rust-blog  : pretzelhammer's Rust blog 🦀. Educational blog posts for Rust beginners.
ctjhoa/rust-learning  : A bunch of links to blog posts, articles, videos, etc for learning Rust.
lborb/book  : The Little Book of Rust Books. lborb.github.io/book/
instrumentisto/rust-incubator  : Learning Rust step-by-step. This project represents a hard-way step-by-step Rust learning course from language basics to a capability of web backend development.
1595901624/StudyRust  : 公众号：《Rust学习日记》Rust 学习日记 源码 ，让你的Rust从0基础小白到大牛。
MacroKata : Welcome to MacroKata, a set of exercises which you can use to learn how to write macros in Rust.
veykril/tlborm  : The Little Book of Rust Macros (updated fork). veykril.github.io/tlborm/. The Little Book of Rust Macros （Rust 宏小册）
dtolnay/proc-macro-workshop  : Rust Latam: procedural macros workshop. This repo contains a selection of projects designed to learn to write Rust procedural macros — Rust code that generates Rust code.
dtolnay/proc-macro2  : A wrapper around the procedural macro API of the compiler's proc_macro crate.
nrc/proc-macro-rules  : Macro-rules-style syntax matching for procedural macros.
rustomax/rust-iterators  : Basic Rust iterator usage. The goal of this tutorial is to provide a handy reference to some of the common iterator patterns.
Rust文档网 : Rust 官方文档中文教程。
Rust程序设计语言 : Rust 程序设计语言 简体中文版。
rust-boom/rust-boom  : rust awesome（资源）. 💥 rust-boom.github.io/rust-boom/. Rust Boom 是一个仓主在学习使用 Rust 的时候，对 Rust 的一些难点的解决方法以及一些 Rust 开源的好玩的库、书籍、文章的整理，希望可以帮助更多的 Rust 初学者来翻过 Rust 这座大山。
rust-lang-cn/reference-cn  : Rust 参考手册 中文版——Chinese translation of The Rust Reference. rustwiki.org/zh-CN/reference
rust-lang-cn/rust-by-example-cn  : Rust By Example 中文版(包含在线代码编辑器)。 通过例子学 Rust 中文版
rust-lang-cn/nomicon-zh-Hans  : Rust 秘典（死灵书）。 nomicon.purewhite.io/
Warrenren/inside-rust-std-library  : 本书主要对RUST的标准库代码进行分析，并试图给出RUST标准库代码的分析脉络。This project try to give a venation of how reading the RUST standard library source code.
wtklbm/rust-library-i18n  : Rust 核心库和标准库中文翻译，可作为 IDE 工具的智能提示，并生成本地 API 文档。
johnthagen/min-sized-rust  : 🦀 How to minimize Rust binary size 📦
better-rs/learn-rs  : learn-rs: 快速学习 rust。
Tauri + Vue3 + Naive-UI Template  : Tauri + Vue3 + Naive-UI Template. 前端框架: typescript + vue3 + naive-ui.
better-rs/annotated-rs  : annotated-rs: rust 知名项目源码分析。
zanderxyz/advent-of-code  : My solutions to the annual Advent of Code problems. 2020 in Zig; 2021/22 in Rust. www.adventofcode.com/
pavloslav/advent-of-code-rust  : Learning Rust language.
kovyrin/aoc2022  : Playing with AOC 2022 problems using Rust.
CreatorsDAO/rust-co-learn  : rust-co-learn.
DaviRain-Su/all-in-one-rust  : all-in-one-rust.
DaviRain-Su/rust-no-std-source  : About Rust no std sources.
night-cruise/async-rust  : 这是一本电子书，旨在介绍 Rust 中 async/await 语法和异步运行时的原理和工作机制。 night-cruise.github.io/async-rust/
LearningOS/rust-based-os-comp2023 : 2023秋冬季开源操作系统训练营。
phodal/aigc  : 《构筑大语言模型应用：应用开发与架构设计》一本关于 LLM 在真实世界应用的开源电子书，介绍了大语言模型的基础知识和应用，以及如何构建自己的模型。其中包括Prompt的编写、开发和管理，探索最好的大语言模型能带来什么，以及LLM应用开发的模式和架构设计。 aigc.phodal.com/
Performance Benchmark
kostya/benchmarks  : Some benchmarks of different languages.
jinyus/related_post_gen  : Data Processing benchmark featuring Rust, Go, Swift, Zig etc.
zackradisic/rust-vs-zig  : This is an experiment to evaluate Rust vs. Zig by writing a bytecode interpreter with GC in both languages and comparing them.
lucascompython/zigXrustXc  : Performance of Zig vs Rust vs C.
CoalNova/BasicCompare  : A basic comparitive analysis of C, C++, Rust, and Zig.
Data Structure and Algorithm
krahets/hello-algo  : 《Hello 算法》是一本动画图解、能运行、可提问的数据结构与算法入门书，支持 Java, C++, Python, Go, JS, TS, C#, Swift, Zig 等语言。 前往阅读 > hello-algo.com.
TheAlgorithms/Rust  : All Algorithms implemented in Rust.
EbTech/rust-algorithms  : Common data structures and algorithms in Rust. A collection of classic data structures and algorithms, emphasizing usability, beauty and clarity over full generality.
rust-unofficial/too-many-lists  : Learning Rust With Entirely Too Many Linked Lists.
rustlang-cn/rust-algos  : Rust算法题解，用Rust语言实现常见的算法和数据结构，以及leetcode题解。
QMHTMY/RustBook  : A book about Rust Data Structures and Algorithms.
matey-jack/dl-list-mini.fs : Simple doubly-linked list in safe Rust.
Bonsai  : Rust implementation of behavior trees.
msakuta/rusty-behavior-tree-lite  : Lightweight behavior tree implementation in Rust.
darthdeus/behavior-tree  : Behavior trees for Rust!
callmestech/lists  : Learning Rust With Entirely Too Many Linked Lists.
Parallel and Async Library
Rayon  : Rayon: A data parallelism library for Rust.
mpi  : MPI bindings for Rust. docs.rs/mpi.
Flume  : A safe and fast multi-producer, multi-consumer channel. crates.io/crates/flume
Tokio  : A runtime for writing reliable, asynchronous, and slim applications with the Rust programming language.
May  : May is a high-performance library for programming stackful coroutines with which you can easily develop and maintain massive concurrent programs. It can be thought as the Rust version of the popular Goroutine.
event-listener  : Notify async tasks or threads.
async-process  : Async interface for working with processes.
FFI Bindings
PyO3  : Rust bindings for the Python interpreter.
UniFFI  : UniFFI - a multi-language bindings generator for Rust. mozilla.github.io/uniffi-rs/
cxx  : Safe interop between Rust and C++. cxx.rs
Autocxx  : Tool for safe ergonomic Rust/C++ interop driven from existing C++ headers. docs.rs/autocxx
bindgen  : Automatically generates Rust FFI bindings to C (and some C++) libraries.
C2Rust  : C2Rust helps you migrate C99-compliant code to Rust. c2rust.com/
embed-c  : Embed C code at compile time inside Rust using C2Rust.
rust-cpp  : rust-cpp - Embed C++ code directly in Rust.
zngur  : A C++/Rust interop tool. hkalbasi.github.io/zngur
safer_ffi  : Write safer FFI code in Rust without polluting it with unsafe code. getditto.github.io/safer_ffi
Diplomat  : Experimental Rust tool for generating FFI definitions allowing many other languages to call Rust code.
jlrs  : Julia bindings for Rust.
Rutie  : “The Tie Between Ruby and Rust.”
suirad/zig-header-gen  : Automatically generate headers/bindings for other languages from Zig code.
kassane/zFFI  : CBindgen FFI test.
emilHof/zigc  : Zigc aims to provide the basic functionality for compiling and linking Zig libraries into your Rust projects.
jeremyBanks/zig_with_cargo  : Building Zig libraries in a Rust Cargo package.
nekodjin/rusty-ziguanas  : Experiments in Zig-Rust and Rust-Zig FFI.
DutchGhost/zigiffy  : Rust FFI with Zig.
DutchGhost/rustiffy  : Zig FFI with Rust.
natanalt/zig2rs  : use zig code in rust - a medium effort shitpost.
ogxd/ffidji  : 🐶 FFIDJI is a tool to automatically generate bindings between languages, like calling Rust code from C# for instance.
Deukhoofd/csharp_binder  : A simple library to generate C# bindings for a Rust foreign function interface (FFI).
toolness/csharpbindgen  : A Rust library for generating C# bindings from Rust code.
Cysharp/csbindgen  : Generate C# FFI from Rust for automatically brings native code and C native library to .NET and Unity.
nikomatsakis/duchess  : Experiments with Java-Rust interop.
antoniusnaumann/cargo-swift  : A cargo plugin to easily build Swift packages from Rust code. crates.io/crates/cargo-swift
tomleavy/safer-ffi-gen  : Attribute macro to help automate Rust FFI bindings.
py2many/py2many  : Transpiler of Python to many other languages.
GPU Programming
jessfraz/advent-of-cuda  : Doing advent of code with CUDA and rust.
Bend  : A massively parallel, high-level programming language. higherorderco.com
HVM  : A massively parallel, optimal functional runtime in Rust. higherorderco.com
ZLUDA  : CUDA on AMD GPUs.
Rust-CUDA  : Ecosystem of libraries and tools for writing and executing fast GPU code fully in Rust.
cudarc  : cudarc: minimal and safe api over the cuda toolkit.
bindgen_cuda  : Similar crate than bindgen in philosophy. It will help create automatic bindgen to cuda kernels source files and make them easier to use directly from Rust.
Lyn-liyuan/ndarray-cuda-matmul  : a high-performance computing solution designed to accelerate matrix operations using Nvidia's CUDA technology with Rust's ndarray data structure.
cuda-driver  : 基于 CUDA Driver API 的 cuda 运行时环境。
async-cuda  : Asynchronous CUDA for Rust.
async-tensorrt  : Asynchronous TensorRT for Rust.
krnl  : Safe, portable, high performance compute (GPGPU) kernels.
custos  : A minimal OpenCL, CUDA, WGPU and host CPU array manipulation engine / framework.
spinorml/nvlib  : Rust interoperability with NVIDIA CUDA NVRTC and Driver.
DoeringChristian/cuda-rs  : Cuda Bindings for rust generated with bindgen-cli (similar to cust_raw).
romankoblov/rust-nvrtc  : NVRTC bindings for RUST.
solkitten/astro-cuda  : CUDA Driver API bindings for Rust.
bokutotu/curs  : cuda&cublas&cudnn wrapper for Rust.
rust-cuda/cuda-sys  : Rust binding to CUDA APIs.
bheisler/RustaCUDA  : Rusty wrapper for the CUDA Driver API.
tmrob2/cuda2rust_sandpit  : Minimal examples to get CUDA linear algebra programs working with Rust using CC & FFI.
PhDP/rust-cuda-template  : Simple template for Rust + CUDA.
neka-nat/cuimage  : Rust implementation of image processing library with CUDA.
yanghaku/cuda-driver-sys  : Rust binding to CUDA Driver APIs.
Canyon-ml/canyon-sys  : Rust Bindings for Cuda, CuDNN.
cea-hpc/HARP  : Small tool for profiling the performance of hardware-accelerated Rust code using OpenCL and CUDA.
Conqueror712/CUDA-Simulator  : A self-developed version of the user-mode CUDA emulator project and a learning repository for Rust.
cszach/rust-cuda-template  : A Rust CUDA template with detailed instructions.
exor2008/fluid-simulator  : Rust CUDA fluid simulator.
chichieinstein/rustycuda  : Convenience functions for generic handling of CUDA resources on the Rust side.
Jafagervik/cruda  : CRUDA - Writing rust with cuda.
lennyerik/cutransform  : CUDA kernels in any language supported by LLVM.
cjordan/hip-sys  : Rust bindings for HIP.
rust-gpu  : 🐉 Making Rust a first-class language and ecosystem for GPU shaders 🚧 shader.rs.
wgpu  : Safe and portable GPU abstraction in Rust, implementing WebGPU API. wgpu.rs.
Vulkano  : Safe and rich Rust wrapper around the Vulkan API. Vulkano is a Rust wrapper around the Vulkan graphics API. It follows the Rust philosophy, which is that as long as you don't use unsafe code you shouldn't be able to trigger any undefined behavior. In the case of Vulkan, this means that non-unsafe code should always conform to valid API usage.
Ash  : Vulkan bindings for Rust.
ocl  : OpenCL for Rust.
opencl3  : A Rust implementation of the Khronos OpenCL 3.0 API.
Web3 and ZKP Framework
Web3-Recruitment-Platform  : Web3及远程工作招聘平台、频道汇总｜@Web3-Club。
Tachyon  : Modular ZK(Zero Knowledge) backend accelerated by GPU.
Blitzar  : Zero-knowledge proof acceleration with GPUs for C++ and Rust. www.spaceandtime.io/
blitzar-rs  : High-Level Rust wrapper for the blitzar-sys crate. www.spaceandtime.io/
ICICLE  : ICICLE is a library for ZK acceleration using CUDA-enabled GPUs.
BLAZE  : blaze is a Rust library for ZK acceleration on Xilinx FPGAs.
BLAZE  : The Halo2 zero-knowledge proving system. zcash.github.io/halo2/
Kimchi  : The proof systems used by Mina. This repository contains kimchi, a general-purpose zero-knowledge proof system for proving the correct execution of programs. o1-labs.github.io/proof-systems/
0xPolygonZero/plonky2  : This repository was originally for Plonky2, a SNARK implementation based on techniques from PLONK and FRI. It has since expanded to include tools such as Starky, a highly performant STARK implementation.
dusk-network/plonk  : Pure Rust implementation of the PLONK ZKProof System done by the Dusk-Network team. dusk-network.github.io/plonk
EspressoSystems/jellyfish  : A Rust Implementation of the PLONK ZKP System and Extensions. jellyfish.docs.espressosys.com
Substrate  : Substrate: The platform for blockchain innovators.
Sui  : Sui is a next-generation smart contract platform with high throughput, low latency, and an asset-oriented programming model powered by the Move programming language. sui.io
move  : Move is a programming language for writing safe smart contracts originally developed at Facebook to power the Diem blockchain.
move-cn/letsmove  : Let's Move 一项学Move获得SUI的激励计划，鼓励更多的人学习Move语言。
Rooch  : Rooch is a modular DApp container with the Move language. rooch.network
Polkadot  : The Parity Polkadot Blockchain SDK. The Polkadot SDK repository provides all the resources needed to start building on the Polkadot network, a multi-chain blockchain platform that enables different blockchains to interoperate and share information in a secure and scalable way. polkadot.network/
Bifrost  : Bifrost is a Web3 derivatives protocol that provides decentralized cross-chain liquidity for staked assets.
nostr  : a truly censorship-resistant alternative to Twitter that has a chance of working. The simplest open protocol that is able to create a censorship-resistant global "social" network once and for all.
awesome-nostr  : A curated list of nostr projects and resources. www.nostr.net
Damus  : A twitter-like nostr client for iPhone, iPad and MacOS.
Amethyst  : Amethyst brings the best social network to your Android phone. Just insert your Nostr private key and start posting.
rust-nostr/nostr  : Nostr protocol implementation, SDK and FFI.
mikedilger/gossip  : Gossip is a desktop client for nostr.
Sway  : 🌴 Empowering everyone to build reliable and efficient smart contracts. fuellabs.github.io/sway
FuelLabs/fuel-core  : Rust full node implementation of the Fuel v2 protocol.
FuelLabs/fuels-rs  : Fuel Network Rust SDK. fuellabs.github.io/fuels-rs
solana  : Web-Scale Blockchain for fast, secure, scalable, decentralized apps and marketplaces. solanalabs.com
solana-playground  : Quickly develop, deploy and test Solana programs from browsers. beta.solpg.io
Anchor  : ⚓ Solana Sealevel Framework. anchor-lang.com
CreatorsDAO/awesome-learn-solana  : awesome-learn-solana.
CreatorsDAO/creatorsdao.github.io  : Creators Dao all about source. creatorsdao.github.io/
CleverProgrammers/facebook-solana-blockchain  : Build Facebook 3.0 on Blockchain with Solana | Next.js | Netlify | Sanity.io.
MartinKavik/voting-solana-moonzoon  : The Voting example based on MoonZoon and Solana.
NEAR Docs : Welcome! This is the starting point for all the documentation in NEAR.
near/awesome-near  : Curated list of resources: examples, libraries, projects. examples.near.org
near/nearcore  : Reference client for NEAR Protocol. near.org
near/near-sdk-rs  : Rust library for writing NEAR smart contracts. near-sdk.io
near/create-near-app  : Create a starter app hooked up to the NEAR blockchain.
near-examples/NFT  : Example implementations of tokens to represent unique assets, such as collectibles or deeds, using the NEP-171 spec (similar to ERC-721).
near-examples/nft-tutorial  : Welcome to NEAR's NFT tutorial, where we will help you parse the details around NEAR's NEP-171 standard (Non-Fungible Token Standard), and show you how to build your own NFT smart contract from the ground up, improving your understanding about the NFT standard along the way.
hanakannzashi/near-course-base  : NEAR 智能合约开发教程（基础篇）。
tranvinh146/voting-contract  : This is smart contract to vote from phase 1 to phase 2 on Near.
catmcgee/near-voting-contracts  : Different types of voting smart contracts on NEAR blockchain.
rickhysis/vote-coffe-near  : This is smart contract example for vote the best coffe using NEAR Protocol ("NEAR" hereafter).
Dispa1r/Disp41r-Super-Voting-System  : a super super super voting system on near block chain :)
flexabyte/near-vote  : A decentralized voting contract for NEAR protocol.
YellingOilbird/choice  : NEAR smart contract for non-binary vote.
dylan751/near-app-vote-sc  : Voting App using Near-Rust and implement ZKP.
winkelstein/DeChat  : Messenger based on NEAR blockchain.
Cairo  : Cairo is the first Turing-complete language for creating provable programs for general computation. ⚡ Blazing ⚡ fast ⚡ compiler for Cairo, written in 🦀 Rust 🦀
cairo-book/cairo-book.github.io  : The Cairo Programming Language Book, a comprehensive documentation of the Cairo 1 programming language. The Cairo Programming Language Book
Orion  : Orion: An Open-source Framework for Validity and ZK ML ✨. ONNX Runtime in Cairo 1.0 for verifiable ML inference using STARK. orion.gizatech.xyz
franalgaba/neural-network-cairo  : Neural Network implementation from scratch for MNIST using Cairo 1.0.
raphaelDkhn/cairo_ml  : Build neural network models in Cairo 1.0.
gakonst/awesome-starknet  : A curated list of awesome StarkNet resources, libraries, tools and more.
starknet-edu/starknetbook  : Mastering Cairo and Starknet. By the Starknet community. book.starknet.io
xJonathanLEI/starknet-rs  : Complete Starknet library in Rust™. starknet.rs
0xSpaceShard/starknet-devnet-rs  : A local testnet for Starknet... in Rust.
0xAsten/Starknet-Tech-Stacks-Mindmap  : This open collaboration project aims to explore and document the various technology stacks associated with Starknet.
gakonst/ethers-rs  : Complete Ethereum & Celo library and wallet implementation in Rust. https://docs.rs/ethers
Galactic-Hub/cosmos-sdk-rs  : Cosmos SDK implement by Rust.
cosmos/ibc-rs  : Rust implementation of the Inter-Blockchain Communication (IBC) protocol.
Sovereign-Labs/sovereign-sdk  : A framework for building seamlessly scalable and interoperable rollups that can run on any blockchain. sovereign.xyz
octopus-network/near-ibc  : near smart contract implement ibc protocol.
talent-verse/Jobs  : Web3, Blockchain, AI jobs.
wildonion/smarties  : 🍬 NEAR and Ethereum NFT Marketplace Smart Contracts 🍫
sigp/lighthouse  : Ethereum consensus client in Rust.
the-web3/chaineye-blockchain-interview  : 区块链链面试指南。面试了很多区块链工程师，感觉大家都无法抓住面试的要点，本教程主要是整理一些区块链中的面试思路和面试题目, 本教程由链眼社区出品。
Scientific Computation
Numerical Calculation
rapl  : Rank Polymorphic array library for Rust. rapl is an experimental numerical computing Rust library that provides a simple way of working with N-dimensional array, along with a wide range of mathematical functions to manipulate them. It takes inspiration from NumPy and APL, with the primary aim of achieving maximum ergonomics and user-friendliness while maintaining generality.
scilib  : A rust crate for mathematics and science. crates.io/crates/scilib
fitting-rs  : Curve fitting library for Rust. crates.io/crates/fitting
Linear Algebra
mathbench  : mathbench is a suite of unit tests and benchmarks comparing the output and performance of a number of different Rust linear algebra libraries for common game and graphics development tasks.
ndarray  : The ndarray crate provides an n-dimensional container for general elements and for numerics.
ndarray-linalg  : Linear algebra package for rust-ndarray using LAPACK binding.
nalgebra  : Linear algebra library for the Rust programming language.
faer  : Linear algebra foundation for the Rust programming language. faer-rs.github.io. faer is a collection of crates that implement low level linear algebra routines in pure Rust. The aim is to eventually provide a fully featured library for linear algebra with focus on portability, correctness, and performance.
glam  : A simple and fast 3D math library for games and graphics.
russell  : Rust Scientific Libary. Special functions (Bessel, Elliptic, Beta, Gamma, Erf). Linear algebra. Sparse solvers. ODE and DAE solvers. Probability distributions. Tensor calculus.
hasty  : High-performance BLAS and LAPACK within Rust.
tensr  : A high-performance, cross-platform, multi-backend tensor/array library for Rust.
cgmath  : A linear algebra and mathematics library for computer graphics.
ultraviolet  : A wide linear algebra crate for games and graphics.
vek  : Generic 2D-3D math swiss army knife for game engines, with SIMD support and focus on convenience.
static-math  : Safe and fast mathematical operations with static arrays in the Rust programming language.
rust-numpy  : PyO3-based Rust bindings of the NumPy C-API.
custos-math  : This crate provides CUDA, OpenCL, CPU (and Stack) based matrix operations using custos.
bluss/matrixmultiply  : General matrix multiplication of f32 and f64 matrices in Rust. Supports matrices with general strides. docs.rs/matrixmultiply/
Kai-Striega/blas-rs  : Experimental BLAS implementation in pure rust.
Lie Groups
sophus-rs  : Rust bindings for the C++ implementation of Lie Groups using Eigen.
Optimization Framework
OpEn  : Optimization Engine (OpEn) is a solver for Fast & Accurate Embedded Optimization for next-generation Robotics and Autonomous Systems. Nonconvex embedded optimization: code generation for fast real-time optimization. alphaville.github.io/optimization-engine/
light-curve/ceres-solver-rs  : Rust bindings for Ceres Solver.
pranayspeed/g2o-rust-bindings  : g2o-rust-bindings.
mithi/rusty-genes  : Genetic algorithm implementation in Rust with animated visualizations in Python.
Evolutionary computation
EvoTorch  : Advanced evolutionary computation library built directly on top of PyTorch, created at NNAISENSE. evotorch.ai
ecrs-org/ecrs  : ecrs - Evolutionary computation algorithms & tools for Rust.
unhindered-ec/unhindered-ec  : A Rust framework supporting a variaty of evolutionary computation (EC) tools.
Finite Element Analysis
FENRIS  : A Rust library for building advanced applications with the Finite Element Method (FEM).
InteractiveComputerGraphics/higher_order_embedded_fem  : Source code for our paper "Higher-order finite elements for embedded simulation".
Data Analysis and Visualization
Polars  : Polars. Fast multi-threaded, hybrid-out-of-core DataFrame library in Rust | Python | Node.js.
Plotters  : A rust drawing library for high quality data plotting for both WASM and native, statically and realtimely 🦀 📈🚀
Rerun  : Rerun: Visualization infrastructure for computer vision. Log images, point clouds, etc, and visualize them effortlessly. Built in Rust using egui. rerun.io
Lance  : Lance: modern columnar data format for ML. Convert from parquet in 2-lines of code for 100x faster random access, a vector index, data versioning, and more. Compatible with pandas, duckdb, polars, pyarrow, with more integrations on the way. eto-ai.github.io/lance/
Typst  : A new markup-based typesetting system that is powerful and easy to learn. Typst is a new markup-based typesetting system that is designed to be as powerful as LaTeX while being much easier to learn and use. typst.app.
Charming  : A visualization library for Rust.
Machine Learning
Machine Learning Framework
Candle  : Minimalist ML framework for Rust.
Safetensors  : Simple, safe way to store and distribute tensors. huggingface.co/docs/safetensors
Tokenizers  : 💥 Fast State-of-the-Art Tokenizers optimized for Research and Production. huggingface.co/docs/tokenizers
ToluClassics/candle-tutorial  : Tutorial for Porting PyTorch Transformer Models to Candle (Rust).
Burn  : Burn - A Flexible and Comprehensive Deep Learning Framework in Rust. burn-rs.github.io/
dfdx  : Deep learning in Rust, with shape checked tensors and neural networks.
luminal  : Deep learning at the speed of light. www.luminalai.com/
crabml  : crabml is focusing on the reimplementation of GGML using the Rust programming language.
TensorFlow Rust  : Rust language bindings for TensorFlow.
tch-rs  : Rust bindings for the C++ api of PyTorch.
tract  : Sonos' Neural Network inference engine. Tiny, no-nonsense, self-contained, Tensorflow and ONNX inference
ort  : A Rust wrapper for ONNX Runtime. docs.rs/ort
arrayfire-rust  : Rust wrapper for ArrayFire. ArrayFire is a high performance library for parallel computing with an easy-to-use API. It enables users to write scientific computing code that is portable across CUDA, OpenCL and CPU devices.
Linfa  : A Rust machine learning framework. Linfa aims to provide a comprehensive toolkit to build Machine Learning applications with Rust.
Juice  : The Hacker's Machine Learning Engine.
autograph  : A machine learning library for Rust.
SmartCore  : The most advanced machine learning library in Rust. SmartCore is a comprehensive library for machine learning and numerical computing. The library provides a set of tools for linear algebra, numerical computing, optimization, and enables a generic, powerful yet still efficient approach to machine learning. smartcorelib.org/
onnxruntime-rs  : This is an attempt at a Rust wrapper for Microsoft's ONNX Runtime (version 1.8).
Wonnx  : Wonnx is a GPU-accelerated ONNX inference run-time written 100% in Rust, ready for the web.
altius  : Small ONNX inference runtime written in Rust.
goldstraw/RustCNN  : Rust convolutional neural network from scratch.
goldstraw/RustTransformer  : A transformer built from scratch in Rust.
elftausend/gradients  : Deep Learning library using custos and custos-math.
michaelmelanson/spiking-neural-net  : A spiking neural network simulation library.
AnicetNgrt/neural_networks_rust  : Implementing NNs & other machine learning utils in Rust from scratch.
herrmann/rustorch  : "PyTorch in Rust".
michaelgiba/ggml-rs  : Work in progress rust bindings to ggml.
KerfuffleV2/ggml-sys-bleedingedge  : Bleeding edge low level Rust binding for GGML.
PABannier/rust-ggml  : Rust bindings for C tensor library ggml.
KerfuffleV2/rusty-ggml  : GGML bindings that aim to be idiomatic Rust rather than directly corresponding to the C/C++ interface.
danforbes/ggml-rs-bindings  : This is a personal educational project for learning more about rustformers/llm, from which almost all of the code in this repository was copied.
kurtschelfthout/tensorken  : A fun, hackable, GPU-accelerated, neural network library in Rust, written by an idiot.
Orion  : Orion: An Open-source Framework for Validity and ZK ML ✨. ONNX Runtime in Cairo 1.0 for verifiable ML inference using STARK. orion.gizatech.xyz
franalgaba/neural-network-cairo  : Neural Network implementation from scratch for MNIST using Cairo 1.0.
raphaelDkhn/cairo_ml  : Build neural network models in Cairo 1.0.
Large Language Model
sobelio/llm-chain  : llm-chain 🚀 is a collection of Rust crates designed to help you create advanced LLM applications such as chatbots, agents, and more. As a comprehensive LLM-Ops platform we have strong support for both cloud and locally-hosted LLMs. llm-chain.xyz
Abraxas-365/langchain-rust  : 🦜🔗LangChain for Rust, the easiest way to write LLM-based programs in Rust.
EricLBuehler/mistral.rs  : Blazingly fast LLM inference. Mistral.rs is a fast LLM inference platform supporting inference on a variety of devices, quantization, and easy-to-use application with an Open-AI API compatible HTTP server and Python bindings.
edgenai/edgen  : ⚡ Edgen: Local, private GenAI server alternative to OpenAI. No GPU required. Run AI models locally: LLMs (Llama2, Mistral, Mixtral...), Speech-to-text (whisper) and many others. docs.edgen.co/
edgenai/llama_cpp-rs  : High-level, optionally asynchronous Rust bindings to llama.cpp.
coreylowman/llama-dfdx  : LLaMa 7b with CUDA acceleration implemented in rust. Minimal GPU memory needed!
edgenai/llama_cpp-rs  : High-level, optionally asynchronous Rust bindings to llama.cpp.
srush/llama2.rs  : A fast llama2 decoder in pure Rust.
gaxler/llama2.rs  : Inference Llama 2 in one file of pure Rust 🦀
Llama2-burn  : Llama2 LLM ported to Rust burn.
whisper-burn  : A Rust implementation of OpenAI's Whisper model using the burn framework.
stable-diffusion-burn  : Stable Diffusion v1.4 ported to Rust's burn framework.
tazz4843/whisper-rs  : Rust bindings to whisper.cpp.
rustformers/llm  : Run inference for Large Language Models on CPU, with Rust 🦀🚀🦙.
Chidori  : A reactive runtime for building durable AI agents. docs.thousandbirds.ai.
Atome-FE/llama-node  : Believe in AI democratization. llama for nodejs backed by llama-rs and llama.cpp, work locally on your laptop CPU. support llama/alpaca/gpt4all/vicuna model. www.npmjs.com/package/llama-node
Noeda/rllama  : Rust+OpenCL+AVX2 implementation of LLaMA inference code.
lencx/ChatGPT  : 🔮 ChatGPT Desktop Application (Mac, Windows and Linux). NoFWL.
Synaptrix/ChatGPT-Desktop  : Fuel your productivity with ChatGPT-Desktop - Blazingly fast and supercharged!
Poordeveloper/chatgpt-app  : A ChatGPT App for all platforms. Built with Rust + Tauri + Vue + Axum.
mxismean/chatgpt-app  : Tauri 项目：ChatGPT App.
sonnylazuardi/chat-ai-desktop  : Chat AI Desktop App. Unofficial ChatGPT desktop app for Mac & Windows menubar using Tauri & Rust.
yetone/openai-translator  : The translator that does more than just translation - powered by OpenAI.
m1guelpf/browser-agent  : A browser AI agent, using GPT-4. docs.rs/browser-agent
sigoden/aichat  : Using ChatGPT/GPT-3.5/GPT-4 in the terminal.
uiuifree/rust-openai-chatgpt-api  : "rust-openai-chatgpt-api" is a Rust library for accessing the ChatGPT API, a powerful NLP platform by OpenAI. The library provides a simple and efficient interface for sending requests and receiving responses, including chat. It uses reqwest and serde for HTTP requests and JSON serialization.
1595901624/gpt-aggregated-edition  : 聚合ChatGPT官方版、ChatGPT免费版、文心一言、Poe、chatchat等多平台，支持自定义导入平台。
Cormanz/smartgpt  : A program that provides LLMs with the ability to complete complex tasks using plugins.
femtoGPT  : femtoGPT is a pure Rust implementation of a minimal Generative Pretrained Transformer. discord.gg/wTJFaDVn45
shafishlabs/llmchain-rs  : 🦀Rust + Large Language Models - Make AI Services Freely and Easily. Inspired by LangChain.
flaneur2020/llama2.rs  : An rust reimplementatin of https://github.com/karpathy/llama2.c.
Heng30/chatbox  : A Chatbot for OpenAI ChatGPT. Based on Slint-ui and Rust.
fairjm/dioxus-openai-qa-gui  : a simple openai qa desktop app built with dioxus.
purton-tech/bionicgpt  : Accelerate LLM adoption in your organisation. Chat with your confidential data safely and securely. bionic-gpt.com
rustai-solutions/candle_demo_openchat_35  : candle_demo_openchat_35.
InfiniTensor/transformer-rs  : 从 YdrMaster/llama2.rs 发展来的手写 transformer 模型项目。
AI Generated Content
pykeio/diffusers  : modular Rust library for optimized Stable Diffusion inference 🔮 docs.rs/pyke-diffusers
Object Detection
usls  : A Rust library integrated with ONNXRuntime, providing a collection of Computer Vison and Vision-Language models.
ptaxom/pnn  : pnn is Darknet compatible neural nets inference engine implemented in Rust. By optimizing was achieved significant performance increment(especially in FP16 mode). pnn provide CUDNN-based and TensorRT-based inference engines.
bencevans/rust-opencv-yolov5  : YOLOv5 Inference with ONNX & OpenCV in Rust.
masc-it/yolov5-api-rust  : Rust API to run predictions with YoloV5 models.
AndreyGermanov/yolov8_onnx_rust  : YOLOv8 inference using Rust.
igor-yusupov/rusty-yolo  : rusty-yolo.
gsuyemoto/yolo-rust  : Run YOLO computer vision model using Rust and OpenCV and/or Torch.
alianse777/darknet-rust  : A Rust wrapper for Darknet, an open source neural network framework written in C and CUDA. pjreddie.com/darknet/
12101111/yolo-rs  : Yolov3 & Yolov4 with TVM and rust.
TKGgunter/yolov4_tiny_rs  : A rust implementation of yolov4_tiny algorithm.
flixstn/You-Only-Look-Once  : A Rust implementation of Yolo for object detection and tracking.
lenna-project/yolo-plugin  : Yolo Object Detection Plugin for Lenna.
laclouis5/globox-rs  : Object detection toolbox for parsing, converting and evaluating bounding box annotations.
metobom/tchrs-opencv-webcam-inference  : This example shows steps for running a Python trained model on webcam feed with opencv and tch-rs. Model will run on GPU.
Design Pattern
fadeevab/design-patterns-rust  : Rust examples for all 23 classic GoF design patterns, and even a little more.
lpxxn/rust-design-pattern  : Rust Design Patterns.
Static Variables
typed-arena  : A small macro for defining lazy evaluated static variables in Rust.
Memory Allocator
typed-arena  : A fast (but limited) allocation arena for values of a single type.
bumpalo  : A fast bump allocation arena for Rust. docs.rs/bumpalo
generational-arena  : A safe arena allocator that allows deletion without suffering from the ABA problem by using generational indices. docs.rs/generational-arena
tikv/jemallocator  : Rust allocator using jemalloc as a backend.
Embedded Development
stm32-rs : Community Rust support projects for STM32 microcontrollers.
rust-embedded : Enabling usage of Rust on Embedded Platforms (Embedded Linux / RTOS / Bare Metal).
RTIC  : Real-Time Interrupt-driven Concurrency (RTIC) framework for ARM Cortex-M microcontrollers. rtic.rs
Embassy  : Modern embedded framework, using Rust and async. embassy.dev
rust-raspberrypi-OS-tutorials  : 📚 Learn to write an embedded OS in Rust 🦀
Tock  : A secure embedded operating system for microcontrollers. www.tockos.org
lobaro/FreeRTOS-rust  : This project is based on code from freertos.rs and some additions to simplify the usage of FreeRTOS in embedded applications written in Rust.
Exein-io/pulsar  : A modular and blazing fast runtime security framework for the IoT, powered by eBPF. pulsar.sh
General Operating System
BlogOS  : This repository contains the source code for the Writing an OS in Rust series at os.phil-opp.com.
rCore-Tutorial-v3  : OS kernel labs based on Rust/C Lang & RISC-V 64/X86-32.
rCore  : Rust version of THU uCore OS. Linux compatible.
zCore  : Reimplement Zircon microkernel in Rust.
RustSBI  : RISC-V Supervisor Binary Interface (RISC-V SBI) implementation library in Rust; runs on M or HS mode; good support for embedded Rust ecosystem.
writing-an-os-in-rust  : 《使用Rust编写操作系统》
Theseus  : Theseus is a modern OS written from scratch in Rust that explores 𝐢𝐧𝐭𝐫𝐚𝐥𝐢𝐧𝐠𝐮𝐚𝐥 𝐝𝐞𝐬𝐢𝐠𝐧, novel OS structure, and state management.
snarkOS  : A Decentralized Operating System for Zero-Knowledge Applications.
thepowersgang/rust_os  : An OS kernel written in rust. Non POSIX.
MOROS  : MOROS: Obscure Rust Operating System 🦉
EuraliOS  : A hobby x86-64 operating system written in Rust.
SIMDeez  : A library that abstracts over SIMD instruction sets, including ones with differing widths. SIMDeez is designed to allow you to write a function one time and produce SSE2, SSE41, and AVX2 versions of the function.
yavkOS  : Operating system based off of blog_os, with the goal of running wasm modules as executables.
Felix OS  : 🐱 x86 operating system. Felix is my attempt at writing an x86 operating system. It's written completely from scratch in Rust and doesn't use any external dependencies.
jdreaver/rust-os  : Creating a bare metal OS in Rust.
r9os/r9  : The R9 operating system.
Robot Operating System
micro-ROS for Arduino  : micro-ROS library for Arduino.
dora-rs  : In 2023, AI is booming! Robotic framework however hasn't changed much in years... This is why we create dora-rs! dora-rs is a new robotic framework that brings modernity into robotic application. dora goal is to be a low latency, composable, and distributed data flow. dora.carsmos.ai
openrr  : Open Rust Robotics. OpenRR (pronounced like "opener") is Open Rust Robotics platform.
rosrust  : rosrust is a pure Rust implementation of a ROS client library.
ros2_rust  : Rust bindings for ROS2.
r2r  : R2R - Easy to use, runtime-agnostic, async rust bindings for ROS2.
erdos  : Dataflow system for building self-driving car and robotics applications.
rclrust  : This is yet another ROS2 client library written in Rust.
RustDDS  : RustDDS is a pure Rust implementation of Data Distribution Service, developed by Atostek Oy.
ros2-client  : ROS2 client library based on RustDDS.
rosbag-rs  : A pure Rust crate for reading ROS bag files.
rustros_tf  : This is a rust port of the ROS tf library.
urdf-rs  : URDF parser using serde-xml-rs for rust.
urdf-viz  : visualize URDF/XACRO file, URDF Viewer works on Windows/MacOS/Linux.
ros-nalgebra  : Generate code to convert geometry_msgs into nalgebra structs, for rosrust.
strawlab/opencv-ros-camera  : Geometric models of OpenCV/ROS cameras for photogrammetry.
luickk/MinimalRoboticsPlatform  : MRP is a minimal microkernel that supports the most fundamental robotic domains. It's thought for highly integrated robotics development.
newpavlov/rosbag-rs  : A pure Rust crate for reading ROS bag files.
Hardware Description Language
Veryl  : Veryl: A Modern Hardware Description Language.
RustHDL  : A framework for writing FPGA firmware using the Rust Programming Language.
VHDL-LS/rust_hdl  : This repository contains a fast VHDL language server and analysis library written in Rust.
yupferris/kaze  : An HDL embedded in Rust. kaze provides an API to describe Modules composed of Signals, which can then be used to generate Rust simulator code or Verilog modules.
dalance/sv-parser  : SystemVerilog parser library fully compliant with IEEE 1800-2017.
dalance/svls  : SystemVerilog language server.
dalance/svlint  : SystemVerilog linter.
vivekmalneedi/veridian  : A SystemVerilog Language Server.
zachjs/sv2v  : SystemVerilog to Verilog conversion.
Logic Programming
Scryer Prolog  : A modern Prolog implementation written mostly in Rust.
Shared Memory
elast0ny/shared_memory  : A Rust wrapper around native shared memory for Linux and Windows.
Remote Desktop
RustDesk  : Virtual / remote desktop infrastructure for everyone! Open source TeamViewer / Citrix alternative. rustdesk.com.
Date and Time
Chrono  : Chrono: Date and Time for Rust.
Data Encryption
rustic  : rustic - fast, encrypted, deduplicated backups powered by Rust.
Database
Qdrant  : Qdrant - Vector Database for the next generation of AI applications. Also available in the cloud https://cloud.qdrant.io/. qdrant.tech
SQLx  : 🧰 The Rust SQL Toolkit. An async, pure Rust SQL crate featuring compile-time checked queries without a DSL. Supports PostgreSQL, MySQL, SQLite, and MSSQL.
Rusqlite  : Rusqlite is an ergonomic wrapper for using SQLite from Rust.
Njord  : ⛵ A lightweight ORM library for Rust.
CeresDB  : CeresDB is a high-performance, distributed, cloud native time-series database. docs.ceresdb.io
redb  : An embedded key-value database in pure Rust. www.redb.org
mysql_async  : Asyncronous Rust Mysql driver based on Tokio.
Rustbase  : Rustbase is open source, lightweight, modern and fast NoSQL database. rustbase.app/
Sensor and Communication Protocol
WebRTC.rs  : A pure Rust implementation of WebRTC. webrtc.rs
serialport-rs  : A cross-platform serial port library in Rust. Provides a blocking I/O interface and port enumeration including USB device information.
scottlamb/moonfire-nvr  : Moonfire NVR, a security camera network video recorder.
l1npengtul/nokhwa  : Cross Platform Rust Library for Powerful Webcam/Camera Capture.
shirok1/livox-rs  : Alternative Livox LiDAR library.
jerry73204/rust-lidar-utils  : Encode and decode Velodyne and Ouster lidar packets in Rust.
hacknus/serial-monitor-rust  : A cross-plattform serial monitor/plotter written entirely in rust.
apertus-open-source-cinema/axiom-recorder  : Software to record moving images from Apertus° AXIOM cameras via USB3 or ethernet.
cameleon-rs/cameleon  : A safe, fast, and flexible library for GenICam compatible cameras.
Signal Processing
strawlab/adskalman-rs  : Kalman filter implementation in Rust.
nravic/kalmanrs  : A (yet to be) comprehensive Kalman Filter library in Rust.
spdes/kalman-rust  : A simple implementation of Kalman filter and RTS smoother in Rust (ndarray).
hortovanyi/Unscented-Kalman-Filter-Rust  : UKF written in Rust based on the C++ UKF from the Udacity SD Car Nanodegree.
wangxiaochuTHU/yakf  : Yet Another Kalman Filter Implementation. As well as Lie Theory (Lie group and algebra) on SE(3). [no_std] is supported by default.
MichaelMauderer/filter-rs  : Kalman filters and other optimal and non-optimal estimation filters in Rust.
rbagd/rust-linearkalman  : Kalman filtering and smoothing in Rust.
File Processing
Serde  : Serde is a framework for serializing and deserializing Rust data structures efficiently and generically. serde.rs/
serde-rs/json  : Strongly typed JSON library for Rust.
BurntSushi/rust-csv  : A fast and flexible CSV reader and writer for Rust, with support for Serde.
informationsea/xlsxwriter-rs  : Excel file writer for Rust. crates.io/crates/xlsxwriter
Ballasi/num2words  : Convert numbers like 42 to forty-two. crates.io/crates/num2words
Image and Video Processing
opencv-rust  : Rust bindings for OpenCV 3 & 4.
rust-cv/cv  : Rust CV mono-repo. Contains pure-Rust dependencies which attempt to encapsulate the capability of OpenCV, OpenMVG, and vSLAM frameworks in a cohesive set of APIs.
photon  : ⚡ Rust/WebAssembly image processing library. silvia-odwyer.github.io/photon. Photon is a high-performance Rust image processing library, which compiles to WebAssembly, allowing for safe, blazing-fast image processing both natively and on the web.
image-rs/image  : Encoding and decoding images in Rust.
image-rs/imageproc  : An image processing library, based on the image library.
zshipko/image2-rs  : A Rust crate focused on generic image processing for a wide range of image formats and data types.
WebRTC.rs  : A pure Rust implementation of WebRTC. webrtc.rs
zmwangx/rust-ffmpeg  : Safe FFmpeg wrapper.
meh/rust-ffmpeg  : Safe FFmpeg wrapper.
Simp  : 🖼 Simp is a fast and simple GPU-accelerated image manipulation program.
jay3332/ril  : Rust Imaging Library: A high-level imaging crate for Rust. crates.io/crates/ril
Futsch1/image-sieve  : ImageSieve is a GUI based tool to assist in sorting images based on taken date and similarity, categorize them according to their creation date and archive them in a target folder.
neka-nat/cuimage  : Rust implementation of image processing library with CUDA.
iamdb/stream-cv  : Playing around with Rust, libav (ffmpeg), opencv and multithreading.
BinciLuo/Rust-opencv-Application  : Implementation of an application based on OpenCV written in Rust.
koukemo/rust_cv_sample  : Sample of Rust using opencv to load images.
Live Media Server
Xiu  : A simple, high performance and secure live media server in pure Rust (RTMP[cluster]/RTSP/HTTP-FLV/HLS).🦀
Localization and Mapping
richardanaya/slamburger  : A SLAM algorithm for WebAssembly 🍔
pekkaran/violet  : A toy stereo visual inertial odometry (VIO) system.
ndbaker1/SLAMR  : modules for visual odometry and IMU integration written in Rust.
geoeo/Vision  : Computer Vision stuff in Rust.
geoeo/visual_odometry  : A rust port of https://github.com/geoeo/Dense_VO.
mpizenberg/visual-odometry-rs  : Visual Odometry in Rust (vors).
code-cp/direct_method_simple  : This repo implements a simple direct method using the TUM RGBD dataset.
Path Planning
pathfinding  : Pathfinding library for rust. This crate implements several pathfinding, flow, and graph algorithms in Rust.
rrt  : RRT (Rapidly-exploring Random Tree) library in Rust.
gear  : Collision Avoidance Path Planning in Rust-lang.
trajectory  : trajectory interpolation library for Rust and robotics.
marcbone/s_curve  : S-Curve trajectory generator written in rust.
Sollimann/bonsai  : Rust implementation of behavior trees.
Motion Control
k  : k: Kinematics library for rust-lang.
rsasaki0109/RustRobotics  : This package is a rust implementation of PythonRobotics. Rust implementation of PythonRobotics such as EKF, DWA, Pure Pursuit, LQR.
braincore/pid-rs  : A PID controller for Rust projects.
yoshuawuyts/pid-lite  : A small PID controller library.
bohonghuang/rov-host  : A cross-platform, high-performance underwater robot controll program written in Rust.
zaiic/pid_rs  : A fairly minimal PID controller implementation in Rust.
josh-tracey/PIDController  : Rust PID Controller library. Rust Crate: https://crates.io/crates/adriftdev_pid
ua-kxie/pid-ctrl  : Flexible pid controller with time delta as argument.
tana/balance-robot2  : Self-balancing robot using LQR control, written in Rust.
AlexKaravaev/rust_mpc  : MPC racing controller made in ros2-rust.
Finite State Machine
eugene-babichenko/rust-fsm  : A framework for building finite state machines in Rust.
hashmismatch/finny.rs  : Finny - Hierarchical Finite State Machines for Rust.
Game Field
Bevy  : Bevy is a refreshingly simple data-driven game engine built in Rust. It is free and open-source forever! bevyengine.org
Fyrox  : 3D and 2D game engine written in Rust. fyrox.rs
Ambient  : Ambient is a runtime for building high-performance multiplayer games and 3D applications, powered by WebAssembly, Rust and WebGPU. ambient.run
Rapier  : Rapier is a set of 2D and 3D physics engines for games, animation, and robotics. rapier.rs
bevy_rapier  : Official Rapier plugin for the Bevy game engine.
Parry  : 2D and 3D collision-detection library for Rust. parry.rs
Eldiron  : A cross platform classic RPG game creator written in Rust. www.eldiron.com
Search Engine
Meilisearch  : ⚡ A lightning-fast search engine that fits effortlessly into your apps, websites, and workflow 🔍 www.meilisearch.com
Network Service
Pingora  : Pingora is a Rust framework to build fast, reliable and programmable networked systems. Open sourcing Pingora: our Rust framework for building programmable network services
Web Crawler
Spider  : Spider: The fastest web crawler and indexer. docs.rs/spider/
a11ywatch/crawler  : A gRPC web indexer turbo charged for performance.
Antosser/web-crawler  : Rust Web Crawler that finds every page, image, and script on a website (and downloads it)
ravenxd0/crawler  : Web Crawler in Rust.
lonexw/rust-crawler  : A simple crawler, built with Rust lang.
tawilkinson/rust_web_crawler  : A simple web crawler in rust.
RPC Framework
Volo  : Volo is a high-performance and strong-extensibility Rust RPC framework that helps developers build microservices. crates.io/crates/volo
Web Framework
reqwest  : An easy and powerful Rust HTTP Client. docs.rs/reqwest
Yew  : Yew is a modern Rust framework for creating multi-threaded front-end web apps with WebAssembly. yew.rs
Axum  : Ergonomic and modular web framework built with Tokio, Tower, and Hyper.
Salvo  : Salvo is a powerful and simplest web server framework in Rust world. salvo.rs
Actix  : Actix Web is a powerful, pragmatic, and extremely fast web framework for Rust. actix.rs
Rocket  : A web framework for Rust. rocket.rs
Poem  : A full-featured and easy-to-use web framework with the Rust programming language.
Rouille  : Rouille, a Rust web micro-framework.
Leptos  : Build fast web applications with Rust.
Farm  : Super fast web build tool written in Rust - 基于 Rust 的极速 web 构建引擎。 farm-fe.github.io
zino  : zino is a full-featured web application framework for Rust with a focus on productivity and performance.
Hyper  : A terminal built on web technologies. hyper.is
Deno  : Deno is a simple, modern and secure runtime for JavaScript and TypeScript that uses V8 and is built in Rust. deno.land
SWC  : SWC (stands for Speedy Web Compiler) is a super-fast TypeScript / JavaScript compiler written in Rust. swc.rs
tchatche.rs  : tchatche.rs is a blazing fast chat application built with Axum and Yew.rs. tchatche.rs
tonic  : A native gRPC client & server implementation with async/await support. docs.rs/tonic
MoonZoon  : Rust Fullstack Framework.
WebAssembly
Wasmer  : Wasmer is a fast and secure WebAssembly runtime that enables super lightweight containers to run anywhere: from Desktop to the Cloud, Edge and IoT devices. wasmer.io
wasmtime  : A fast and secure runtime for WebAssembly. wasmtime.dev/
Graphics Library
rust-skia/rust-skia  : Safe Rust bindings to the Skia Graphics Library.
gtk-rs/gtk4-rs  : Rust bindings of GTK 4. gtk-rs.org/gtk4-rs/
gtk-rs/gtk3-rs  : Rust bindings for GTK 3. gtk-rs.org
SabianF/rust_wgpu_3D_vision  : A program to simulate stereoscopic 4D vision, using a virtual 3D retina which is created by rapidly displaying all voxels at varying depths of a 3D volume.
GUI
GUI Framework
flutter_rust_bridge  : Flutter/Dart <-> Rust binding generator, feature-rich, but seamless and simple. fzyzcjy.github.io/flutter_rust_bridge/
Rinf  : Rust for native business logic, Flutter for flexible and beautiful GUI.
Dioxus  : Fullstack GUI library for desktop, web, mobile, and more. dioxuslabs.com
marc2332/freya  : Native GUI library for 🦀 Rust powered by 🧬 Dioxus and 🎨 Skia. freyaui.dev/
Slint  : Slint is a declarative GUI toolkit to build native user interfaces for applications that are written in Rust, C++, or JavaScript. slint.dev
slint-ui/slint-rust-template  : A template for a Rust Application using Slint. This is meant to be used with cargo-generate. slint.dev
syf20020816/SurrealismUI  : SurrealismUI是一个完全使用Slint进行构建的Slint第三方组件库。 SurrealismUI is a third-party component library built entirely using Slint.
Tauri  : Build smaller, faster, and more secure desktop applications with a web frontend. tauri.app. Tauri is a framework for building tiny, blazingly fast binaries for all major desktop platforms. Developers can integrate any front-end framework that compiles to HTML, JS and CSS for building their user interface. The backend of the application is a rust-sourced binary with an API that the front-end can interact with.
Pake  : 🤱🏻 Turn any webpage into a desktop app with Rust. 🤱🏻 很简单的用 Rust 打包网页生成很小的桌面 App.
Makepad  : Makepad is a creative software development platform for Rust that compiles to wasm/webGL, osx/metal, windows/dx11 linux/opengl. makepad.dev/
Vizia  : A declarative GUI library written in Rust. docs.vizia.dev
KDAB/cxx-qt  : Safe interop between Rust and Qt.
egui  : egui: an easy-to-use immediate mode GUI in Rust that runs on both web and native.
Iced  : A cross-platform GUI library for Rust focused on simplicity and type-safety. Inspired by Elm.
Xilem  : An experimental Rust architecture for reactive UI.
Druid  : A data-first Rust-native UI toolkit.
Floem  : A native Rust UI library with fine-grained reactivity.
Crux  : Cross-platform app development in Rust. redbadger.github.io/crux/
KDE/rust-qt-binding-generator  : Generate bindings to use Rust code in Qt and QML.
marek-g/rust-fui  : MVVM Rust UI Framework Library.
apertus-open-source-cinema/narui  : A react-inspired UI library for building multimedia desktop apps with rust and vulkan.
GUI Software
Dioxus-Related
Dioxus 中文网 : 帮助您快速构建可靠的用户界面程序。
DioxusLabs/dioxus-std  : A library to provide abstractions to access common utilities when developing Dioxus applications.
DioxusLabs/dioxus-html-macro  : An html macro for dioxus applications.
DioxusLabs/awesome-dioxus  : An awesome list of Dioxus-related content and resources.
DioxusLabs/example-projects  : Featured Dioxus projects on how to build clean user interfaces in Rust.
mrxiaozhuox/dioxus-starter  : Starter template for Dioxus framework. http://dioxus-starter.mrxzx.info/
Ebou  : TEbou is a cross platform Mastodon (and Pleroma, untested) client written in Rust using the Dioxus UI library. terhech.de/ebou/
Uplink  : (Pre-Release Software) Secure, Encrypted, P2P chat written atop Warp, IPFS, LibP2P, Dioxus and many more awesome projects and protocols.
dxps/fullstack-rust-axum-dioxus-rwa  : An example of a RealWorld app implementation as a Fullstack Rust project using Axum (be) and Dioxus (fe).
fairjm/dioxus-openai-qa-gui  : a simple openai qa desktop app built with dioxus.
hiltonm/dioxus-charts  : A simple chart components library for Dioxus.
lucianopinochet/chat-app  : chat app made in rust with the library dioxus.
lucianopinochet/group_chat  : Group Chat App of rust, that use the dioxus framework for the GUI and tokio for asynchronous tcpstream run time, with integrated server.
mrxiaozhuox/dioxus-hackernews  : Hacker News clone with Dioxus.
matheusb432/rust-uchat  : 'Build a Full-Stack Twitter Clone with Rust' course code and notes.
dallasrust/website-dioxus  : Dallas Rust User Meetup website using Dioxus. www.dallasrust.org/
coal-rock/site  : the source for my personal site, built using axum and dioxus.
nissy-dev/dioxus-free-icons  : 'Use free svg icons in your Dioxus projects easily with dioxus-free-icons.
arqalite/rummy-nights  : A rummy score counter web app written with Rust/Dioxus and Tailwind CSS. rummy-nights.vercel.app
LIU9293/rust-2048  : Learn rust by coding a 2048 game use dioxus.
swanandx/html-to-rsx  : Convert HTML to RSX, a meta language used by dioxus.
justdimaa/cloud-rs  : A file storage service using Rust, gRPC, and MongoDB.
Slint-Related
slint-ui/madewithslint  : This is the website repo listing awesome applications built with Slint. madewithslint.com/
slint-ui/cargo-ui  : This is a project to make a GUI for cargo, built using Slint.
GaspardCulis/slint-tetris  : Tetris game made with Slint. gaspardculis.github.io/slint-tetris/
MohaBeacon/slint-opencv  : slint-opencv.
Heng30/chatbox  : A Chatbot for OpenAI ChatGPT. Based on Slint-ui and Rust.
Ouam74/RUST_Real-time_plots_using_SLINT_and_PLOTTERS.rs  : RUST_Real-time_plots_using_SLINT_and_PLOTTERS.rs
hexiangdong2020/PlcDebugTool  : 使用Rust和Slint编写的Simense S7 PLC的调试工具。
hexiangdong2020/SerialDebugTool  : 使用Rust和Slint开发的串口调试工具。
Damncool0216/slint-stm32f1  : small demo using Slint on stm32f1.
vgarleanu/lumiere  : Example video player built with MPV and Slint-UI.
Berrysoft/tunet-rust  : 清华大学校园网 Rust 库与客户端。
jturcotte/chiptrack  : A cross-platform sequencer and synthesizer based on the emulation of the Game Boy sound chip. jturcotte.github.io/chiptrack/
colelawrence/here-now  : A low-resource native app for sharing space with co-workers and friends.
planet0104/slint-noframe-window  : slint no-frame window.
zhangzqs/esp-clock-rs  : 使用Rust语言编写的个人时钟，基于Slint GUI框架，计划支持PC端模拟器，可移植性。
Tauri-Related
sandunwira/SupTube  : An open-source Windows client for YouTube. suptube.repl.co
spieglt/FlyingCarpet  : File transfer between Android, iOS, Linux, macOS, and Windows over ad hoc WiFi. No network infrastructure required, just two devices with WiFi chips in close range.
Minori-ty/mp4To4K-rust  : 使用Tauri做的一个将动漫视频转4K视频的软件。
seiKiMo-Inc/Laudiolin  : A "high quality" music player written in TypeScript using Tauri and React.
kingwingfly/bilibili-downloader-rs  : Bilibili Downloader. A bilibili video downloader app built by Tauri, Vue and Rust!
pacholoamit/pachtop  : Cross-platform (Linux, WIndows, MacOS) Desktop GUI system monitor, built with Rust & Tauri.
lecepin/douyin-downloader  : 使用非常简单的抖音视频无水印下载工具。支持下单个视频，以及下载某个人的所有视频。（采用rust+tauri编写，安装包非常小）。
lecepin/desktop-webcam  : 使用 webassembly 通过 tauri 封装的桌面摄相头。
pot-app/pot-desktop  : 🌈一个跨平台的划词翻译软件 | A cross-platform translation software. pot.pylogmon.com
conaticus/FileExplorer  : Fast file explorer written with Tauri and React.
mxismean/image-tiny-tauri  : Tauri 项目：图片压缩应用。一款小而美的图片压缩工具， 支持 png、jpg、gif 三种图片格式压缩。 该工具不依赖服务端，只需在客户端就可以完成压缩工作。您只需拖拽你的图片文件到该应用窗口即可。
BD777/imageview  : Image viewer by tauri. A image viewer by tauri. 用来看图的软件，当然，看漫画也是很方便的。
Makepad-Related
mobilerust/makepad_wechat  : WeChat-like application implemented with Makepad.
mobilerust/makepad_taobao  : makepad_taobao.
mobilerust/makepad_social_media_feed  : Example app of a social media feed for mobile applications, using makepad.
mobilerust/todo_makepad  : Example TODO app built with Makepad.
Blogs
微信公众号「Rust语言中文社区」
2021-08-08，拓展 | Rust语言在嵌入式领域的应用
2023-05-07，【Rust日报】2023-05-06 深度学习框架 Burn 发布 v0.7.0
2023-05-11，【Rust日报】2023-05-10 llm - 使用Rust在CPU上运行大模型
2023-05-11，Rust UI 框架：Slint UI 简单入门
2023-05-24，字节跳动：将持续投入Rust，期待更多Rust生态合作和建设
2023-05-26，【Rust日报】2023-05-25 Scientific Computing in Rust 2023
2023-06-04，【Rust日报】2023-06-03 femtoGPT，纯 Rust 实现的最小化 GPT
2023-06-22，[Rust招聘] 国家智能网联汽车创新中心Rust工程师招聘（车载操作系统）
2023-07-14，邀请您参加有偿的Unsafe Rust调研
2023-08-10，【Rust招聘】【理想汽车】rust高级开发工程师（35K-50K）
2024-03-04，【Rust 日报】2024-03-03 高性能深度学习库luminal
2024-05-22，RustChinaConf2024正式启动 - 开源项目“锈”
2024-05-27，【社区投稿】给 NdArray 装上 CUDA 的轮子
微信公众号「Rust学习日记」
2022-08-13，【Rust 中级教程】 01 泛型
2022-08-20，【Rust 中级教程】 02 结构体与泛型
2022-09-04，【Rust 中级教程】 03 trait (1)
2022-09-10，【Rust 中级教程】 04 trait (2)
2022-09-18，【Rust 中级教程】 04 trait (3)
2022-09-24，【Rust 中级教程】 06 trait (4)
2022-10-01，【Rust 中级教程】 07 内存
2022-10-16，【Rust 中级教程】 08 所有权（1）
2022-10-22，【Rust 中级教程】 09 所有权（2）
2022-10-29，【Rust 中级教程】 10 所有权（3）
2022-11-05，【Rust 中级教程】 11 所有权与trait（4）
2022-11-12，【Rust 中级教程】 12 共享所有权
2022-11-19，【Rust 中级教程】 13 引用与借用（1）
2022-11-26，【Rust 中级教程】 14 引用与借用（2）
2022-12-17，【Rust 中级教程】 15 引用与借用（3）
2022-12-24，Rust 中级教程 第16课——引用的 lifetime（1）
2023-01-07，Rust 中级教程 第17课——引用的 lifetime（2）
2023-01-14，Rust 中级教程 第18课——trait object （1）
2023-02-04，Rust 中级教程 第19课——trait object （2）
2023-02-18，Rust 中级教程 第20课——Box
2023-02-25，Rust 中级教程 第21课——Drop trait
2023-03-04，Rust 中级教程 第22课——内部可变性（1）
2023-03-11，Rust 中级教程 第23课——内部可变性（2）
2023-03-18，Rust 中级教程 第24课——下划线（Underscore）
2023-04-01，【Rust 进阶教程】 01 闭包与所有权
2023-04-08，【Rust 进阶教程】 02 详解迭代器（1）
2023-04-15，【Rust 进阶教程】 03 详解迭代器（2）
2023-04-22，【Rust 进阶教程】 04 并发编程
2023-05-06，【Rust 进阶教程】 05 通道
2023-05-13，【Rust 进阶教程】 06 线程安全
2023-05-21，【Rust 实战】Rust 与 Python 交互
2023-06-04，【Rust 进阶教程】 07 Mutex
2023-07-30，【Rust 进阶教程】 08 读写锁
2023-08-05，【Rust 进阶教程】 09 原子类型
2023-08-12，【Rust 进阶教程】 10 操作符重载
2023-08-19，【Rust 进阶教程】 11 错误处理 - panic
2023-08-26，【Rust 进阶教程】 12 错误处理 - Result
2023-08-30，【Rust-SlintUI教程】01 Hello Slint UI
2023-09-02，【Rust-SlintUI教程】02 初识 Slint UI
2023-09-06，【Rust-SlintUI教程】03 元素与标识符
2023-09-17，【Rust 进阶教程】13 包（crate）
2023-10-14，【Rust 进阶教程】14 模块
2023-10-14，【Rust 进阶教程】15 测试（test）
2023-10-21，【Rust 进阶教程】16 注释与文档
2023-10-28，【Rust 进阶教程】17 正则表达式
2023-11-04，【Rust 进阶教程】18 OsStr 和 OsString
2023-11-11，【Rust 进阶教程】19 Path 和 PathBuf
2023-12-03，【Rust 进阶教程】22 宏编程-声明宏
2023-12-10，【Rust 进阶教程】23 宏编程-过程宏（属性宏）
2023-12-31，【Rust 进阶教程】24 宏编程-过程宏（函数宏）
2024-04-10，【Rust 进阶教程】25 宏编程-过程宏（派生宏）
2024-04-18，【Rust 进阶教程】26 宏编程-syn
2024-04-25，【Rust 进阶教程】27 宏编程-quote
2024-05-14，【Rust 进阶教程】28 unsafe
2024-05-23，【Rust 进阶教程】29 裸指针
微信公众号「兔子写代码」
2023-03-17，Rust 闲聊 | Rust 语言真的会是未来吗？
2023-03-21，彻底搞懂 Rust 的宏（一）：简介
2023-03-22，彻底搞懂 Rust 的宏（二）：声明宏的组成
2023-03-28，彻底搞懂 Rust 的宏（三）：声明宏语法全解析
2023-04-19，彻底搞懂 Rust 的宏（四）：片段分类符
2023-04-29，彻底搞懂 Rust 的宏（五）：宏展开
2023-05-06，彻底搞懂 Rust 的宏（六）：一个小例子及两个注意点
2023-05-16，彻底搞懂 Rust 的宏（七）：重复元变量
2023-05-23，彻底搞懂 Rust 的宏（八）：内建宏
2023-06-28，Rust 笔记 | 迭代器(一)：Iterator 和 IntoIterator
2023-07-06，Rust 笔记 | 迭代器(二)：创建迭代器
2023-08-03，Rust 笔记 | 迭代器的适配器：map 和 filter
2023-08-08，Rust 笔记 | 迭代器的适配器：filter_map 和 flat_map
2023-08-11，Rust 笔记 | 迭代器的适配器：flatten
2023-08-16，Rust 笔记 | 迭代器的适配器：take 和 take_while
2023-08-18，Rust 笔记 | 迭代器的适配器：skip 和 skip_while
微信公众号「三角兽」
2024-03-06，三角兽新系列！拥抱未来语言Rust
2024-04-19，逼自己看完，你的Rust撸码水平就会变牛，手搓一个线程池
2024-04-23，逼自己看完，你的Rust撸码水平就会提高，手搓一个mini-async异步运行时——Rust高并发的基础
微信公众号「coding到灯火阑珊」
2024-03-21，2024年Rust编程的十大领域
2024-05-31，适合Rust初学者晋级到中级的项目
微信公众号「TinTinLand」
2023-09-22，Rust课程挑战赛获奖项目公布，点击查收精彩回顾！
微信公众号「Antalpha Labs」
2024-05-11，ZKP 课程招募｜把握 PLONK，细嗅底层加密的金蔷薇
微信公众号「706青年空间」
2023-05-26，Rust 共学招募 | 跨越 Web2 与 Web3 深入底层重构世界
2023-07-27，Rust 共学第一期结束！七个项目参与最终 Demo Day 分享
2023-08-15，Solana 共学招募 | 聚集 Rust 开发者，一起组队黑客松
微信公众号「总有一点知识你需要」
2023-04-09，[翻译] 在2023年，每个学习Rust的人都应该知道的资源
2023-09-06，什么是Anchor
微信公众号「CSDN」
2021-03-24，底层I/O性能大PK：Python/Java被碾压，Rust有望取代C++
2021-11-09，为什么 Rust 是编程的未来？
2022-06-24，Rust，程序员创业的最佳选择？
2023-05-05，将代码从 C 迁移到 Rust，sudo、su 正在行动！
2023-05-15，Mozilla 发布 Rust | 历史上的今天
2023-05-16，Windows 11 初尝 Rust，36000 行内核代码已重写！
2023-05-16，可能取代Vulkan和OpenGL的WebGPU为何如此重要？
2023-06-23，200 行 Rust 代码编写一个向量搜索库，代码已开源！
微信公众号「OSC开源社区」
2019-07-23，微软解释为什么Rust是系统编程的最佳选择
2023-04-05，Slint 1.0正式发布，Rust编写的原生GUI工具包
2023-05-06，Rust重写万物？
微信公众号「InfoQ」
2023-02-04，雄心勃勃的计划：沃尔沃正在将 Rust 用于其车载软件
2023-04-28，30年老代码被干掉！微软用18万行 Rust 改写 Windows 系统内核
2023-05-05，Rust 生态纯属炒作？3 年写了 10 万行代码的开发者吐槽：当初用 Rust 是被忽悠了
微信公众号「码小菜」
2023-05-13，我什么放弃了C/C++，而选择了Rust
2023-05-13，Qdrant不只是高性能向量数据库
微信公众号「腾讯技术工程」
2022-12-29，大牛书单 | Rust 好书推荐
微信公众号「Parity Tech」
2023-05-23，Substrate 账户、地址和密钥
微信公众号「分布式实验室」
2023-02-16，我们选择了Rust，因为它太快了
2023-02-27，跟着Rust语言中文社区联合创始人学Rust
微信公众号「Rust编程指北」
2022-01-31，Rust 到底值不值得学：万字长文对比、特色和理念
微信公众号「51CTO技术栈」
2023-03-28，后端队友选择Rust，爽到了！
微信公众号「量子位」
2023-05-29，取代C++！3.6万行Rust代码改写Windows内核，这门语言最早竟用来修电梯
微信公众号「AI前线」
2023-08-11，Python 失宠！Hugging Face 用 Rust 新写了一个 ML框架，现已低调开源
微信公众号「AI工程化」
2023-08-11，Hugging Face偷偷放大招了，Rust版本的ML框架Candle曝光
微信公众号「技术源泉」
2024-04-19，Rust 无锁算法库
微信公众号「数据科学研习社」
2024-05-02，Nextest：下一代 Rust 测试加速神器
2024-05-06，从小白到 Rust 大神，这本开源书籍带你上路
2024-05-22，每个 Rust 小白都应该收藏的开源项目：whoami
微信公众号「程序员吾真本」
2024-05-09，诚邀Rust图书Rust/Java/C++技术评审人
微信公众号「编程悟道」
2024-05-11，如何用Rust成功重写C++代码库的指南[万字长文,新手勿进][译]
微信公众号「roseduan写字的地方」
2024-04-23，开源一个 Rust 练手小项目
微信公众号「NLP工程化」
2024-05-17，LangChain Rust：用 Rust 语言实现的库
微信公众号「DappLink」
2024-05-05，来 The Web3, 学习史上最全面的区块链教程，挑战高薪
微信公众号「OpenBuild」
2024-05-07，来 The Web3, 学习史上最全面的区块链教程，挑战高薪
2024-05-15，如何成为全能性的智能合约开发者
微信公众号「流浪AI」
2024-04-27，LLaMA 3的Rust实现
微信公众号「猿禹宙」
2024-04-08，Rust ETH利器：ethers 与 build.rs 的完美结合
微信公众号「机器之心」
2024-05-20，首个GPU高级语言，大规模并行就像写Python，已获8500 Star
微信公众号「Rust逆流」
2024-05-16，思考Rust：为何摒弃继承？从函数与方法的区别谈起
微信公众号「山川与湖水」
2024-05-30，《100 Exercises To Learn Rust》：深入掌握 Rust 编程语言的实战宝典
「 MIT Technology Review」
2023-02-14，How Rust went from a side project to the world's most-loved programming language
「 Piotr Kołaczkowski」
2023-05-21，How Much Memory Do You Need to Run 1 Million Concurrent Tasks?
「 tweede golf」
2023-07-12，Why Rust is a great fit for embedded software - 2023 update
Jobs and Interview
微信公众号「TinTinLand」
2024-05-11，Web3 招聘 | MerlinStarter、CoinW Exchange、TonUP、Cian 海量岗位放送中
微信公众号「Rust语言中文社区」
2024-05-20，【Rust招聘】具身智能应用开发实习(1名)
2024-06-14，【校招/实习】实验室长期招聘Rust工程师 base北上深
About
This repository lists some awesome public Rust projects, Videos, Blogs and Jobs.
Topics
rust gui computer-vision cuda jobs riscv yolo awesome-list llama web3 candle tauri zkp yolov5 slint llm chatgpt langchain llama3 yolov10
Resources
Readme
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
46 stars
Watchers
2 watching
Forks
6 forks
Report repository
Releases
No releases published
Packages 0
No packages published
Uh oh!
There was an error while loading. Please reload this page.
Contributors 2
 coderonion
 mjovanc Marcus Cvjeticanin
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.