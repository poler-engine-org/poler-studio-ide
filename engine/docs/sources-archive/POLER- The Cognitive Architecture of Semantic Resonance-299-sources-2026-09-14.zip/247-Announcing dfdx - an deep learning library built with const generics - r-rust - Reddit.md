> Source: https://www.reddit.com/r/rust/comments/vy5uwf/announcing_dfdx_an_deep_learning_library_built/

Announcing dfdx - an deep learning library built with const generics : r/rust
Skip to main content Announcing dfdx - an deep learning library built with const generics : r/rust
Open menu
Open navigation 
Go to Reddit Home 
r/rust
TRENDING TODAY
Get App
Get the Reddit app
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Navigation Skip to Right Sidebar
Back
 Go to rust
r/rust
• 4y ago
rust_dfdx
Locked post
Stickied post
Archived post
View post in other languages
Report
Announcing dfdx - an deep learning library built with const generics
Links: github, crates.io/dfdx, docs.rs/dfdx
Discord: https://discord.gg/AtUhGqBDP5
Hey Everyone,
I've been working on dfdx for a while, and I want to get it out there now! As you'll see from the length of this post, there are so many details I want to share about how this library works.
It started out as a personal side project quite a while ago, but the design I ended up with made it really easy to get a ton of features.
What is dfdx?
Short version: pytorch/tensorflow, but 100% in rust and really easy to use.
Long version: A deep learning library that contains tensors (up to 4d), tensor operations, backprop/auto diff implementation, neural network building blocks, and deep learning optimizers. It's fully implemented in rust, and uses const generics as much as possible (e.g. tensors have shapes known at compile time).
See github/docs.rs for more details.
Why should I use it?
The DL ecosystem in rust is still pretty nascent. The crates I've seen were either wrappers around c++ libraries, not using const generics, or seemed kinda hard to use.
While building dfdx and looking at other DL libraries outside of rust, I also realized that many of them are very complicated and hard to understand. Pytorch for example has so many layers of indirection involved with the c++ side, its hard to find where things actually happen.
A "fun" exercise: find the c++ binary cross entropy implementation in pytorch.
I'm building dfdx to be:
Really easy to use/read (check out examples/)
Really easy to maintain/extend/understand (check out some internals in src/tensor_ops)
Checked at compile time as much as possible (e.g. you can't call backward without gradients; operations require compatible tensor sizes)
Highly tested & verified against existing libraries
You can also save neural networks as .npz files which are pretty easy to load into pytorch, if you want to train in rust and then use in python 😃.
More details in github/docs.rs.
How does it work?
The special bits are all in how the backward operations & derivatives are recorded on the GradientTape . For any given operation on a tensor or multiple tensors, there is (usually) only 1 resulting tensor. The GradientTape from the inputs is always moved to the resulting tensor. So a tensor operation in dfdx does the following:
Compute the result
Remove the tape from the input
Insert the backward operation into the tape
Put the tape into the result
Now there are actually two kinds of tapes in dfdx:
OwnedTape , which just a wrapper around GradientTape .
NoneTape , which is a unit struct and does not track backward operations.
To actually kick off gradient tracking, you need to actually explicitly insert a new OwnedTape into the input using .trace() ! Then the OwnedTape will be carried through the entire forward pass tracking gradients. At the end when you call backward() , it removes the tape from the loss tensor, and runs all the operations in reverse to produce a Gradients . Then you go through the normal update of parameters with an Optimizer .
Since the type of Tape is tracked as a generic parameter of all tensors, all the operations know at compile time whether they are getting a OwnedTape or a NoneTape !
There's soooo much more to get into, and a lot of fun things about the implementation. See README.md#fun-implementation-details for some more tidbits.
But is it faster than pytorch?
With all of my cpu laptop testing: yes. I've been doing all my speed benchmarking with examples/mnist_classifier.rs, and dfdx can be anywhere from x2-3 faster than pytorch is. I suspect a lot of this comes from optimizations rust can do since it has:
access to the entire program (pytorch libraries are compiled and then used by python and have to support all usescases)
const generic tensors (again pytorch can't do this since the c++ is a backend for python)
fun fact: rust auto vectorizes a lot of the array operations, so dfdx contains no simd code!
I'll be adding more documentation and actual benchmarks in the future. issue #20
A nice/funny aside that shows dfdx's potential: pytorch recently posted A BetterTransformer for Fast Transformer Inference on their blog, about speeding up transformers with "fastpath" execution (where gradients aren't tracked). In dfdx this would be trivial since you can just implement forward different for OwnedTape and NoneTape!
What's missing?
Unfortunately, some important functionality is gated behind feature(generic_const_exprs). See dfdx issues. This includes:
Convolutional layers. (The output size can be calculated at compile time, which requires doing simple arithmetic with const usize's)
tensor flatten/reshapes/splitting/concatenation. (also requires arithmetic with const usize's).
I've been working a bit on nightly to test how all of this would work, but its quite unwieldy implementation wise at the moment.
I also have not added GPU support issue #9. I think Rust-CUDA could be used for this, but this will probably require a ton of effort (I'm available for sponsorship if you really want this feature!).
Regardless of no GPU support, dfdx can link to Intel MKL which is really fast on the CPU!
What's next?
I'm still discovering optimizations for speed/allocations in internal code, so I'm sure there'll be more of that. There's also plenty more optimizers/neural network layers/operations that are missing.
The biggest thing I'm working on next is Transformers issue #34, which I do think dfdx can support without const generics.
As you can guess I could go on and on about dfdx, so I'm happy to answer any questions you have!
Read more
543
· 67
Comments Section
leofidus-ger
•
4y ago
This is incredibly awesome, and in my view already one of the biggest highlights of Rust's ML story.
100
rust_dfdx
OP
• 4y ago
Wow thank you so much! 🎉
35
MthDc_
•
4y ago
This looks very nice and I like you leveraging const generics for shapes. I've made so many shape mistakes before, that this would be so useful in my Python code base. It's also something I wrote a blog post about a while ago, but that was more to do with device placement using const generics: see this link. Are you planning on supporting something like that too?
And what about 5+D tensors? I have some use cases that require this, though with some workarounds I could get 4D to work too. Is there anything in particular limiting you to four dimensions?
50
rust_dfdx
OP
• 4y ago
Thanks! And yeah definitely have had shape issues in python, that's why I wanted const generics so badly. Yes tensors already have a Device trait, and if GPU devices are added I would definitely want index captured as const generic, so thanks for sharing that post!
There's nothing limiting from more than 4D, I just arbitrarily stopped there. Would be pretty straightforward to add!
25
Continue this thread 
YRUDancin
•
4y ago
What cases require 5+D tensors? The highest I've ever seen is 4 .
6
Continue this thread 
dnaaun
•
4y ago
First off, super-dope name!
Second, IMHO, the fact that you're using const generics can honestly make this library competitive with Python for ML development (because I really think it will lead to faster iteration and experimentation).
My question is: how does integration with ndarray (and other data-related rust libraries) look like?
This is super exciting!
34
rust_dfdx
OP
• 4y ago
Thanks! Took a while to think of the name, but once I thought of it I immediately knew haha.
In earlier versions I was using ndarray , however when writing tests I found it really verbose to turn a normal rust array into a vec to pass it to ndarray and then store that into tensors. const generics make it easy to use normal rust arrays so I wanted to take advantage of that.
I am depending on the matrixmultiply crate that ndarray 's author wrote (which is pretty awesome!).
All that said, tensors just contain raw rust arrays (behind a Rc). You can call tensor.data() to get a reference to the array, or tensor.mut_data() if you want a mutable version. After that you can do whatever you want with the array, so I hope that's pretty compatible!
23
Continue this thread 
ksyiros
•
4y ago
This is cool, but is it possible to support dynamic tensor shapes? I'm interested in models that can handle sequences of different length not known at compile time.
12
rust_dfdx
OP
• 4y ago
Great question!
Currently all tensors must have shape specified at compile time, there's no dynamically shaped tensor.
If you want the model to act on the entire dynamic sequence at once without padding, then that is not possible.
If the model can operate on each element separately (like an RNN/LSTM), or you are open to padding all sequences to a fixed length (i think pretty common), then this should be possible!
9
Continue this thread
1 more reply
[deleted]
•
4y ago
Comment deleted by user
rust_dfdx
OP
• 4y ago
It looks like there a number of key differences, though I'll caveat this with all this is based on me browsing the src of mushin since I could find t many frontend examples!
On the frontend interface side:
mushin has 1 tensor struct that assumes exactly 4 dimensions. dfdx has different structs for each dimension (Tensor0D, Tensor1D, etc)
mushin tensors use arrayfire arrays, dfdx uses rust arrays
I can't seem to find something to combine multiple module's together in mushin, but for dfdx you can use tuple's to represent a sequential module
On the backend side of things, they are very different approaches to backprop. It looks like mushin has a set kinds of operations ( https://github.com/c0dearm/mushin/blob/main/src/graph/node.rs#L15), and stores data and gradients in a Node object behind refcells.
In dfdx backprop, there's no fixed set of operations, and operation is just a Box<FnOnce<...>> https://github.com/coreylowman/dfdx/blob/main/src/gradients.rs#L37. dfdx backprop used to be similar with the enum for operation types, but there's a lot of custom operations that made it really hard (at least I found it annoying). Now every tensor operation in dfdx defines the backward op as a closure in the function itself. That also means every operation's backward op can be optimized specifically for that function.
There's other differences in how nn layers are implemented if you compare the source of linear layers: https://github.com/coreylowman/dfdx/blob/main/src/nn/linear.rs vs https://github.com/c0dearm/mushin/blob/main/src/nn/layers/linear.rs
Final thing I'll add is dfdx code start's re-using elementary computations as much as possible. E.g. it looks like mushin mse_loss has it's own special backward operation https://github.com/c0dearm/mushin/blob/main/src/nn/losses.rs#L6, where dfdx just uses the already built mean(), square(), and sub() functions. https://github.com/coreylowman/dfdx/blob/main/src/losses.rs#L9
13 
YRUDancin
•
4y ago
Wow I literally just started something a week ago that is nearly exactly this. I have some differences like using Box<[T]> instead of nested arrays, and using the stride mechanics of numpy. I see on your Github you need MacOS testing, I'd be willing to help :)
10
rust_dfdx
OP
• 4y ago
Awesome! How are the ergonomics of boxed slices?
Oooh a MacOS person great! Basically need someone to install Intel MKL ( https://www.intel.com/content/www/us/en/developer/tools/oneapi/base-toolkit-download.html), and then run the "mkl_link_tool" that's installed. That'll print out the link commands & directories to use so I can update build.rs to link to intel's libraries on mac!
We can discuss more on issue #66 if you're available
8
Continue this thread
[deleted]
•
4y ago
Comment deleted by user
rust_dfdx
OP
• 4y ago
Thank you, and contributions are certainly welcome!! Just seeing polars & mushin, thanks for sharing those
4 
chalk_nz
•
4y ago
This looks pretty cool. I'm not a user of these kinds of libraries, but I would like to see more of this kind of thing in Rust.
I see you need someone to test on MacOS. Do you just need someone to run the test suite, or are you more after people using the crate to "test it out" on Macos?
6
rust_dfdx
OP
• 4y ago
Thanks! Yeah I think there's so much potential.
This is somewhat copied from another post above, but I need help to:
Figure out what linking commands/directory structure Intel MKL uses on MacOS.
I'd add some things for MacOS (hopefully its pretty close to linux) to the build.rs file based on #1
I'd need someone on MacOS to then run the test suite using the mkl features. e.g. cargo test --tests --features mkl-dynamic-seq
6
Academic_Ad_4723
•
4y ago
This is some great work. I hope it will help to bring Rust further into the world of scientific computing.
5
arnetterolanda
•
4y ago
Great design!But to be honest,what i want most is something like tf.data or pytorch dataloader.
4
rust_dfdx
OP
• 4y ago
With SubsetIterator (equivalent to pytorch BatchSampler & SubsetRandomSampler classes) you can get pretty far, but totally agree there's a lot of room for improvement on the data side of things!
See examples/mnist_classifier.rs#73 for how its used atm.
8 
dnaaun
•
4y ago
If it makes you feel any better, I think implementing those is much easier than implementing backprop, optimization, and basic NN building blocks.
Having used the pytorch dataloaders a bunch, can I ask what part of it that is not already achievable by using rust iterators you are missing? Is it perhaps the ability to load data in a parallel way?
5
1 more reply
SorteKanin
•
4y ago
This looks really cool!
3
1 more reply 
[deleted]
•
4y ago
This is awesome and what I'd been hoping someone would make! Thank you for your work on this, I'll be sure to dive deeply when I next spend some time in rust.
Might be able to help with the cuda stuff eventually (not a cuda wizard at all, but I've built more than a few kernels in my time)
3
rusty_shell
•
4y ago
@rust_dfdx Why did you remove the description and your comment replies? (Text is visible again for me, maybe some reddit bug, might have only been marked as "deleted" for some short time)
Great project, it looks awesome :)
In a few weeks, once it has more external usage already, you could also post it on the machine learning subreddit: r/MachineLearning
3
2 more replies
codedcosmos
•
4y ago
Though I think this is cool. I'm still waiting for a GPU accelerated ML library for Rust.
Having said that this is still cool.
3 
[deleted]
•
4y ago
cool project 👈😎👈, nice to see const dimensionality information
i'm working on a ml library in rust myself (so far it's more like just backprop), i'm using ndarray for arrays, and i was forced to use dynamic dimensions ( IxDyn ) for dimension data on the tape, eliminating many of the benefits of static type checking, but for now i'm just trying to get something working at all (lol)
i suppose i could technically eliminate IxDyn by giving tape six generic type parameters, for all possibilities of dimensionality (up to 6 with ndarray), but that's for a later day
if you have any advice with regards to challenges you overcame, which i'm likely to encounter in my project, i'd be very happy :)
i'm particularly curious about the way you handle decentralised (meaning no global variables or a dedicated variable to be the arbiter of truth, so to speak, in terms of the tape data) ways to store and pass along the tape (for backprop) in a way that's also okay in terms of efficiency; in my project, for each "tensor" i just wrap all the info necessary for backprop (like gradients, operation type etc) in a Rc<RefCell<>> , which can then just be recorded on the tape, and then this tape is simply cloned onto the next variable, meaning that in a a * b = c scenario, c now carries along a copy of both a 's and b 's tape
this isn't that big of an issue, since it's just copying over pointers, but it's still kind of annoying imo... anyway, i'm curious how you dealt with that
anyway, good luck with your project, the more ml is free of python the better imo :)
2
1 more reply 
[deleted]
•
4y ago
also, more of a tangent with regards to the general ml space, why is nobody doing auto differentiation of tensor wrt to tensor? that would be so cool 🤔😎
2
Particular_Motor7307
•
4y ago
also, more of a tangent with regards to the general ml space, why is nobody doing auto differentiation of tensor wrt to tensor? that would be so cool
Sounds like we have a volunteer! :DGood luck and let us know how it goes.
3
Continue this thread 
BaleineSanguine
•
4y ago
What does using const generics change ?
2
1 more reply 
b0rk4
•
4y ago
This is awesome. Seems like the scalar type is currently hard coded to f32 - unless I'm missing something.
Are you planning to support other types such as f16 and f64, e.g. through generics?
2
4 more replies
View more comments
Related Answers Section
Related Answers
Best resources for deep learning with Rust
Hugging Face alternatives for ML in Rust
Candle library for deep learning in Rust
DeepMind's use of Rust for machine learning
Cudarc library for Rust deep learning
New to Reddit?
Create your account and connect with a world of communities.
Continue with Email
Continue With Phone Number
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy.
More posts you may like
Announcing cudarc and fully GPU accelerated dfdx: ergonomic deep learning ENTIRELY in rust, now with CUDA support and tensors with mixed compile and runtime dimensions!  r/rust • 3y ago [
Announcing cudarc and fully GPU accelerated dfdx: ergonomic deep learning ENTIRELY in rust, now with CUDA support and tensors with mixed compile and runtime dimensions!
](https://www.reddit.com/r/rust/comments/11xkwpo/announcing_cudarc_and_fully_gpu_accelerated_dfdx/) 237 upvotes · 32 comments
dfdx v0.10.0 - deep learning now with even more const generic goodness  r/rust • 3y ago [
dfdx v0.10.0 - deep learning now with even more const generic goodness
](https://www.reddit.com/r/rust/comments/yj8kn9/dfdx_v0100_deep_learning_now_with_even_more_const/) 89 upvotes · 13 comments
Any recommendations for a Rust library and/or tutorial to learn deep learning?  r/rust • 3y ago [
Any recommendations for a Rust library and/or tutorial to learn deep learning?
](https://www.reddit.com/r/rust/comments/yfvwto/any_recommendations_for_a_rust_library_andor/) 7 upvotes · 4 comments
A look into how dfdx compiles & uses cuda kernels  r/rust • 3y ago [
A look into how dfdx compiles & uses cuda kernels
](https://www.reddit.com/r/rust/comments/12horcb/a_look_into_how_dfdx_compiles_uses_cuda_kernels/) 60 upvotes · 12 comments
dfdx v0.9.0 - nightly convs & transformers, broadcasting/reducing/selecting from any axis, and more!  r/rust • 4y ago [
dfdx v0.9.0 - nightly convs & transformers, broadcasting/reducing/selecting from any axis, and more!
](https://www.reddit.com/r/rust/comments/wu0te9/dfdx_v090_nightly_convs_transformers/) 50 upvotes · 7 comments
What makes Rust the best language for Deep Learning  r/rust • 2y ago [
What makes Rust the best language for Deep Learning
](https://www.reddit.com/r/rust/comments/1bixnh4/what_makes_rust_the_best_language_for_deep/) 177 upvotes · 41 comments
Best rust library to create .docx file  r/rust • 8mo ago [
Best rust library to create .docx file
](https://www.reddit.com/r/rust/comments/1lqlgb7/best_rust_library_to_create_docx_file/) 38 upvotes · 27 comments
I made a derive-less reflection library with the new type_info feature!  r/rust • 1mo ago [
I made a derive-less reflection library with the new type_info feature!
](https://www.reddit.com/r/rust/comments/1qnlrbp/i_made_a_deriveless_reflection_library_with_the/)  yasupa 64 upvotes · 7 comments
Introducing dlpark: A Rust Library for High-Performance Tensor Exchange with Python  r/rust • 3y ago [
Introducing dlpark: A Rust Library for High-Performance Tensor Exchange with Python
](https://www.reddit.com/r/rust/comments/13jnub9/introducing_dlpark_a_rust_library_for/)  github 50 upvotes · 8 comments
Are there some machine or deep learning crates on Rust?  r/rust • 3y ago [
Are there some machine or deep learning crates on Rust?
](https://www.reddit.com/r/rust/comments/132msua/are_there_some_machine_or_deep_learning_crates_on/) 11 upvotes · 8 comments
µcad, a new language for CAD written in Rust r/openscad • 3mo ago [
µcad, a new language for CAD written in Rust
](https://www.reddit.com/r/openscad/comments/1ozfq1q/%C2%B5cad_a_new_language_for_cad_written_in_rust/)  8:54 250 upvotes · 105 comments
Best way to learn Rust?  r/rust • 5mo ago [
Best way to learn Rust?
](https://www.reddit.com/r/rust/comments/1nvrl36/best_way_to_learn_rust/) 37 upvotes · 40 comments
I made a Neural Network library from scratch in Rust trying to solve a regression problem for my university's ML course  r/rust • 3y ago [
I made a Neural Network library from scratch in Rust trying to solve a regression problem for my university's ML course
](https://www.reddit.com/r/rust/comments/12wpx84/i_made_a_neural_network_library_from_scratch_in/) 298 upvotes · 26 comments
Learning How to Program in Rust  r/rust • 21d ago [
Learning How to Program in Rust
](https://www.reddit.com/r/rust/comments/1qw9tkp/learning_how_to_program_in_rust/) 16 upvotes · 20 comments
prek — a faster, drop-in alternative to pre-commit (written in Rust)  r/rust • 6mo ago [
prek — a faster, drop-in alternative to pre-commit (written in Rust)
](https://www.reddit.com/r/rust/comments/1nccg3w/prek_a_faster_dropin_alternative_to_precommit/) 217 upvotes · 33 comments
HelixDB: a fast vector-graph database built in Rust.  r/rust • 9mo ago [
HelixDB: a fast vector-graph database built in Rust.
](https://www.reddit.com/r/rust/comments/1kpaok5/helixdb_a_fast_vectorgraph_database_built_in_rust/)  github 140 upvotes · 20 comments
What did you build while learning Rust ?  r/rust • 5mo ago [
What did you build while learning Rust ?
](https://www.reddit.com/r/rust/comments/1o3w69y/what_did_you_build_while_learning_rust/) 100 upvotes · 109 comments
I want to learn Rust but don't know what to build.  r/rust • 3mo ago [
I want to learn Rust but don't know what to build.
](https://www.reddit.com/r/rust/comments/1p105ua/i_want_to_learn_rust_but_dont_know_what_to_build/) 19 comments
Would anyone like me to review their code?  r/rust • 6mo ago [
Would anyone like me to review their code?
](https://www.reddit.com/r/rust/comments/1n9q0mh/would_anyone_like_me_to_review_their_code/) 166 upvotes · 132 comments
best way to learn rust?  r/rust • 2mo ago [
best way to learn rust?
](https://www.reddit.com/r/rust/comments/1pzp7um/best_way_to_learn_rust/) 30 comments
Backend dev in Rust is so fun  r/rust • 2mo ago [
Backend dev in Rust is so fun
](https://www.reddit.com/r/rust/comments/1q3homo/backend_dev_in_rust_is_so_fun/) 333 upvotes · 55 comments
Memory analysis in Rust  r/rust • 7mo ago [
Memory analysis in Rust
](https://www.reddit.com/r/rust/comments/1mpezl0/memory_analysis_in_rust/) 45 upvotes · 15 comments
Rust CUDA May 2025 project update  r/rust • 9mo ago [
Rust CUDA May 2025 project update
](https://www.reddit.com/r/rust/comments/1kwm65f/rust_cuda_may_2025_project_update/) 256 upvotes · 30 comments
Coding on a GPU with rust?  r/rust • 3mo ago [
Coding on a GPU with rust?
](https://www.reddit.com/r/rust/comments/1pf3b10/coding_on_a_gpu_with_rust/) 176 upvotes · 48 comments
[Media] I made an open-source Flow based programming tool  r/rust • 6mo ago [
[Media] I made an open-source Flow based programming tool
](https://www.reddit.com/r/rust/comments/1n8do4a/media_i_made_an_opensource_flow_based_programming/)  82 upvotes · 9 comments
View Post in
Русский
Português (Brasil)
Community Info Section
r/rust
Join
The Rust Programming Language
A place for all things related to the Rust programming language—an open-source systems language that emphasizes performance, reliability, and productivity.
Show more
Public
Anyone can view, post, and comment to this community
Top Posts
Reddit reReddit: Top posts of July 13, 2022
Reddit reReddit: Top posts of July 2022
Reddit reReddit: Top posts of 2022
Reddit Rules Privacy Policy User Agreement Your Privacy Choices Accessibility Reddit, Inc. © 2026. All rights reserved.
Expand Navigation
Expand Navigation
Collapse Navigation
Collapse Navigation 
0cAFcWeA5lhKx45YTGljWF4dgmHW4gzyYpBUoQcUz_-lekVnvKagyc7r_83jwclrtuWkpvot_I9JGmL3-L5heiq6OKunfz59OR_TW0IbpIVDIYDQcd2IFhZVGiBrfNEqODbya1UpwFIZf-6xg_iWYXAJx8dHOHhd03gr9XOrku6FUy_QJcShh74dw2QNOnNCIoOIkn4cuJVvbPTEF_CIL_uFxq5VpC_LxTjOZi6MDhJtRkv01jgXyuaqTv1zjxrhRDnxGyrOFaaS9sbqEoBz47m0XqhhTB_HGR9eXF0zLnKCP_4vqhVntSFtTSRW355JBc-VPw5hRdeFw36TDIkLb5kORg-Yi_S-XKG2XzqFRm-icjiDaF4dAxcDvG78QAUz4Bj7pviRWUuyEDDUU8PpmrMzSyIfyPt3B1XoKtC7yUf72sDqXMzfl8Y4Pa2wsl1w66ylAyqFzcz397rX1kFxU9840Jgnsnvm0AcDvRu-_7yfbGJslf7_Av-bWi9o_SDWfo3doHfU-okOH8Ig8bgv-pG7qMDsVzvm0aNIHTP12HsAq4ZPKom_flHMdHmMGdrzLvXXO-sk-cHDwOvUM8FHebyC4l_KMb7dY-JJwmrncUHd-Y1u8YylKV2zZhU7AeJ9GLbTPPL1uoKW2_thCcM3fKVbBQBJg7oMSK_D3kFZXme0mpuJU9ohhd8ZOLdBLavyq33Dc9itHAE9H5Mdillk1UWGJoEeKKommR6d7kVvQP-7KNkpcCpNEMjK_7dCgBq1OBE9V6jkQibk_hMBA_4pRQnmF4CKgz90rJsHi1Hjx1quAZRiTFfG2GF-0aebF3mn3ZrVZiXG1MJCZcFPsMnOSJP9z4LciNr5mjOdfAGvQrrDl6FusY-DCItiChbSvRnvJU1GKxP-sM2pD7geZAV4FtCAarzU8aChvvwfoVQ4B6PbeT0hZ3tTc1CbTUq0oJgf9dIVOV0MREwetQR_hcyoo9tcfA_skUkjHKhmJoV--02c4JRv0RhH7JVzShgleZgE72GOApClhZRY6lB7yT_hprQtTXuI5ohwkEIaR_QbnpnqrnlEVy1k4VpD0mCyjZi2-bhQXbTUPum1QbXiITKXeqAeNMLKVe-QujZSYPiYsboWMLKKEffkcDeL_ekAJX0Egx2kZQsQnL6fzlGvdYsXybxQ74fA9RKn0LE4Ej2MfGLyb2qyK4ymIKXDQM4n1kwe_IpecbQ54bdev54corI7PKy52kk61Ge3VnQ9icAVHbd7ZtbOeMjG-yE9e9uWFQRCeglX1r2lVReN_6cxespsecAAhfca5BmVdSN7fI2TqC7HkO3H0Bi3DxytjB8tqZs7xYn4_MGXIIo58zWZNKt3xzML0WFaN41uJhWXKNxxc_gLwUMF6-w9o5Gg955hMsFHb8NlbIxFj9FuQSlgcX1ijF4mx43aVRHJTSi5CSMKAgVnuibjlHaGVcL-lP9aG9qEbdUsWg7W5aLosNXLcM-wwtFSsQuzJdiQujK4Q9zV1n6sfxZpv7VzQouQJC9jnovErweXvj8eEejIowOXNB6ueb-RcPiwNiUs4vBluOcKw_GuH0FsKrHRtTrXsvDgnptkAp5bgzpwP0PD6sj2ScQySbW4-9uNBt76zNJpS0-OpHSXfiNqnmFeL6EGpDtWj_LiQkbRIU9cFk0xcmtbkl85J71Pf_7wQw0gCssmZ9oC8DSV1dokY-fQfvsbxm8hycRPiPeztRWq73wtActrJTKMp1WIJmGqgsRd8hGF79k5cc7r6q_BJE3xGq75G2DcUuZYTyjg1qy9TyGi1JP8ObANxodt0RQiNtPpccJYci4Ksr6peZ6BOMT9OoKR6b1bZhJ8bjA7KeKIpRcD1sdwdhH2GK4VRwjv_3R03i3-KJhXDsSAIgFIndDaDiDGzowC1R59K1Ek0N2c6q2BTtktt2xz_ooW9z3anP7XCBSPzQsOaIIaOEfpIjO8kcwYbbG8icb-tta--4CmdoQKqfur6Z2gd_j1nV72Zrhc9dbnSO2K9ayuixwQgMa3aTwnBboMJaF30OhiIVfuZjRASSBDcDWXEwJ2KBakqCQ7O2U-l79E5yZ-tHIbeSQ14Ll-MLQqvaVPtZRQQAJOl_MPErW-TiHFoUHl01McMFMdNpjw