> Source: https://docs.rs/dfdx/latest/dfdx/nn/index.html

dfdx::nn - Rust
Docs.rs
dfdx-0.13.0
dfdx 0.13.0
Permalink
Docs.rs crate page
MIT OR Apache-2.0
Links
Homepage
Repository
crates.io
Source
Owners
coreylowman
Dependencies
cudarc ^0.9.13 normal
gemm ^0.15.4 normal
half ^2.3.1 normal
libm ^0.2.7 normal
memmap2 ^0.5 normal
no-std-compat ^0.4.1 normal
num-traits ^0.2.15 normal
rand ^0.8.5 normal
rand_distr ^0.4.3 normal
rayon ^1.7.0 normal
safetensors ^0.3 normal
spin ^0.9.8 normal
zip ^0.6.6 normal
indicatif ^0.17.3 dev
mnist ^0.5.0 dev
tempfile ^3.3.0 dev
glob ^0.3.1 build
Versions
60.38% of the crate is documented
Platform
i686-pc-windows-msvc
i686-unknown-linux-gnu
x86_64-apple-darwin
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
☰
Module nn
Module nn
Modules
Traits
?
Module dfdx:: nn
source
· [−]
Expand description
High level neural network building blocks such as modules::Linear, activations, and tuples as Module s. Also includes .save() & .load() for all Module s.
Mutable vs Immutable forwards
This is provided as two separate traits
ModuleMut::forward_mut() which receives &mut self .
Module::forward() which receives &self .
This has nothing to do with whether gradients are being tracked or not. It only controls whether the module itself can be modified. Both OwnedTape and NoneTape can still be passed to both, and all modules should conform to this expected behavior.
In general, ModuleMut::forward_mut() should be used during training, and Module::forward() during evaluation/testing/inference/validation.
Here is a list of existing modules that have different behavior in these two functions:
modules::BatchNorm1D
modules::BatchNorm2D
modules::DropoutOneIn
modules::Dropout
Fallible forwards
You can also get a result from Module by using ModuleMut::try_forward_mut, and Module::try_forward.
Similar to fallible tensor_ops, the main purpose of this is to handle out of memory errors at the device level.
Initializing
Use DeviceBuildExt for device agnostic module creation/randomization:
Here, the return type depends on the device and dtype you are using.
For example, when using device crate::tensor::Cpu and f32 , the type is Linear<5, 2, f32, Cpu> . When using a Cuda device and f64 , the type is Linear<5, 2, f64, Cuda> .
Alternatively, you can use BuildModule, which requires device specific model definitions:
Allocating & zeroing gradients
Use ZeroGrads::alloc_grads() and ZeroGrads::zero_grads() to reduce allocations, and enable gradient accumulation! This is the equivalent of pytorch's Optimizer.zero_grad
Exponential Moving Average (EMA)
All models implement ModelEMA::ema() to keep track of an exponential moving average of an entire model.
Resetting parameters
All modules implement ResetParams, which allows you to reset a module back to a randomized state:
Sequential models
Tuple's implement Module, so you can string multiple module's together.
Here's a single layer MLP:
Here's a more complex feedforward network that takes vectors of 5 elements and maps them to 2 elements.
Saving and Loading
numpy
Enable with the "numpy" feature.
Call SaveToNpz::save() and LoadFromNpz::load() methods. All modules provided here implement it, including tuples. These all save to/from .npz files, which are basically zip files with multiple .npy files.
This is implemented to be fairly portable. For example you can load a simple MLP into pytorch like so:
safetensors
Enable with the "safetensors" feature.
The feature safetensors allows to do the same with https://github.com/huggingface/safetensors.
Call SaveToSafetensors::save_safetensors() and LoadFromSafetensors::load_safetensors() funcs. All modules provided here implement it, including tuples.
These all save to/from .safetensors files, which are flat layout with JSON header, allowing for super fast loads (with memory mapping).
This is implemented to be fairly portable. For example you can use https://github.com/huggingface/transformers
Re-exports
pub use [tensor_collection](https://docs.rs/dfdx/latest/dfdx/nn/tensor_collection/index.html)::*;
Modules
builders Simple specification of network structure, without worrying about device or dtype.
modules Structs containing initialized Tensors & impls for super::Module. See super::builders for helpful utilities in creating these in a device/dtype agnostic way.
prelu
tensor_collection Traits to define a TensorCollection and how to iterate them using ModuleVisitor. Use RecursiveWalker to do the iteration and TensorVisitor to define functions to iterate through and/or construct Modules.
Traits
BuildModule Something that can be built. Related to super::BuildOnDevice
BuildOnDevice Something that can be built on a different device than it is on.
DeviceBuildExt An extension trait that allows you to build a module with a device method. Also allows easy specification of Dtype.
LoadFromNpz Something that can be loaded from a .npz file (which is a zip file).
LoadFromSafetensors Something that can be loaded from a .safetensors file.
ModelEMA Performs model exponential moving average on two modules.
Module Immutable forward of Input that produces Module::Output. See ModuleMut for mutable forward.
ModuleMut Mutable forward of Input that produces ModuleMut::Output. See Module for immutable forward.
NonMutableModule Marker trait for modules that don't have different behavior between mutable forwards and non-mutable forwards
NumParams Get the number of trainable parameters in a model.
ResetParams Reset a module's parameters with their default reset function:
SaveToNpz Something that can be saved to a .npz (which is a .zip ).
SaveToSafetensors Something that can be saved to a .safetensors .
ToDevice Something that can be copied to another Device .
ToDtype Something that can be copied to have a different dtype
ZeroGrads Zero's any gradients associated with self .
ZeroSizedModule Marker trait for modules with no updatable parameters. These have blanket impls for, and ModuleMut