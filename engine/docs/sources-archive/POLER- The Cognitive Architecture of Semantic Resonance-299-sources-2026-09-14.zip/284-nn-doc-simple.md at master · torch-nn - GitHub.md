> Source: https://github.com/torch/nn/blob/master/doc/simple.md

nn/doc/simple.md at master · torch/nn · GitHub
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
torch / nn Public
Notifications You must be signed in to change notification settings
Fork 964
Star 1.4k
Code
Issues 157
Pull requests 16
Actions
Projects 0
Wiki
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Wiki
Security
Insights
Files Expand file tree
master
Breadcrumbs
nn
/ doc
/
simple.md
Copy path
Blame More file actions
Blame More file actions
Latest commit
tornadomeet
Create simple.md
9 years ago
7e2c4b6
· 9 years ago
History
History
Open commit details 
History
executable file
·
1927 lines (1486 loc) · 59.5 KB
master
Breadcrumbs
nn
/ doc
/
simple.md
Top
File metadata and controls
Preview
Code
Blame
executable file
·
1927 lines (1486 loc) · 59.5 KB
Raw
Copy raw file
Download raw file
Outline
Edit and raw actions
Simple layers
Simple Modules are used for various tasks like adapting Tensor methods and providing affine transformations :
Parameterized Modules :
Linear : a linear transformation ;
LinearWeightNorm : a weight normalized linear transformation ;
SparseLinear : a linear transformation with sparse inputs ;
IndexLinear : an alternative linear transformation with for sparse inputs and max normalization ;
Bilinear : a bilinear transformation with sparse inputs ;
PartialLinear : a linear transformation with sparse inputs with the option of only computing a subset ;
Add : adds a bias term to the incoming data ;
CAdd : a component-wise addition to the incoming data ;
Mul : multiply a single scalar factor to the incoming data ;
CMul : a component-wise multiplication to the incoming data ;
Euclidean : the euclidean distance of the input to k mean centers ;
WeightedEuclidean : similar to Euclidean, but additionally learns a diagonal covariance matrix ;
Cosine : the cosine similarity of the input to k mean centers ;
Kmeans : Kmeans clustering layer;
Modules that adapt basic Tensor methods :
Copy : a copy of the input with type casting ;
Narrow : a narrow operation over a given dimension ;
Replicate : repeats input n times along its first dimension ;
Reshape : a reshape of the inputs ;
View : a view of the inputs ;
Contiguous : contiguous of the inputs ;
Select : a select over a given dimension ;
MaskedSelect : a masked select module performs the torch.maskedSelect operation ;
Index : a index over a given dimension ;
Squeeze : squeezes the input;
Unsqueeze : unsqueeze the input, i.e., insert singleton dimension;
Transpose : transposes the input ;
Modules that adapt mathematical Tensor methods :
AddConstant : adding a constant ;
MulConstant : multiplying a constant ;
Max : a max operation over a given dimension ;
Min : a min operation over a given dimension ;
Mean : a mean operation over a given dimension ;
Sum : a sum operation over a given dimension ;
Exp : an element-wise exp operation ;
Log : an element-wise log operation ;
Abs : an element-wise abs operation ;
Power : an element-wise pow operation ;
Square : an element-wise square operation ;
Sqrt : an element-wise sqrt operation ;
Clamp : an element-wise clamp operation ;
Normalize : normalizes the input to have unit L_p norm ;
MM : matrix-matrix multiplication (also supports batches of matrices) ;
Miscellaneous Modules :
BatchNormalization : mean/std normalization over the mini-batch inputs (with an optional affine transform) ;
PixelShuffle : Rearranges elements in a tensor of shape [C*r, H, W] to a tensor of shape [C, H*r, W*r] ;
Identity : forward input as-is to output (useful with ParallelTable) ;
Dropout : masks parts of the input using binary samples from a bernoulli distribution ;
SpatialDropout : same as Dropout but for spatial inputs where adjacent pixels are strongly correlated ;
VolumetricDropout : same as Dropout but for volumetric inputs where adjacent voxels are strongly correlated ;
Padding : adds padding to a dimension ;
L1Penalty : adds an L1 penalty to an input (for sparsity) ;
GradientReversal : reverses the gradient (to maximize an objective function) ;
GPU : decorates a module so that it can be executed on a specific GPU device.
TemporalDynamicKMaxPooling : selects the k highest values in a sequence. k can be calculated based on sequence length ;
Constant : outputs a constant value given an input (which is ignored);
WhiteNoise : adds isotropic Gaussian noise to the signal when in training mode;
OneHot : transforms a tensor of indices into one-hot encoding;
PrintSize : prints the size of input and gradOutput (useful for debugging);
ZeroGrad : forwards the input as-is, yet zeros the gradInput ;
Collapse : just like nn.View(-1) ;
Convert : convert between different tensor types or shapes;
Linear
Applies a linear transformation to the incoming data, i.e. y = Ax + b . The input tensor given in forward(input) must be either a vector (1D tensor) or matrix (2D tensor). If the input is a matrix, then each row is assumed to be an input sample of given batch. The layer can be used without bias by setting bias = false .
You can create a layer in the following way:
Usually this would be added to a network of some kind, e.g.:
The weights and biases ( A and b) can be viewed with:
The gradients for these weights can be seen with:
As usual with nn modules, applying the linear transformation is performed with:
LinearWeightNorm
LinearWeightNorm implements the reparametrization presented in Weight Normalization, which decouples the length of neural network weight vectors from their direction. The weight vector w is determined instead by parameters g and v such that w = g * v / ||v|| , where ||v|| is the euclidean norm of vector v . In all other respects this layer behaves like nn.Linear .
To convert between nn.Linear and nn.LinearWeightNorm you can use the nn.LinearWeightNorm.fromLinear(linearModule) and weightNormModule:toLinear() functions.
Other layer types can make use of weight normalization through the nn.WeightNorm container.
SparseLinear
Applies a linear transformation to the incoming sparse data, i.e. y = Ax + b . The input tensor given in forward(input) must be a sparse vector represented as 2D tensor of the form torch.Tensor(N, 2) where the pairs represent indices and values. The SparseLinear layer is useful when the number of input dimensions is very large and the input data is sparse.
You can create a sparse linear layer in the following way:
The sparse linear module may be used as part of a larger network, and apart from the form of the input, SparseLinear operates in exactly the same way as the Linear layer.
A sparse input vector may be created as so...
The first column contains indices, the second column contains values in a a vector where all other elements are zeros. The indices should not exceed the stated dimensions of the input to the layer (10000 in the example).
IndexLinear
Applies the following transformation to the incoming (optionally) normalized sparse input data: z = Weight * y + bias , where
y_i = normalize and (x_i * (1 / x_i_max) + b_i) or x_i
x_i is the i'th feature of the input,
b_i is a per-feature bias,
x_i_max is the maximum absolute value seen so far during training for feature i .
The normalization of input features is very useful to avoid explosions during training if sparse input values are really high. It also helps ditinguish between the presence and the absence of a given feature.
Parameters
inputSize is the maximum number of features.
outputSize is the number of output neurons.
doGradInput , if false (the default), the gradInput will not be computed.
keysOffset lets you specify input keys are in the [1+keysOffset, N+keysOffset] range. (defaults to 0 )
weight and bias allow you to create the module with existing weights without using additional memory. When passing weight and bias , inputSize and outputSize are inferred from the weights.
normalize will activate the normalization of the input feature values. ( false by default)
You can create an IndexLinear layer the following way:
Differences from SparseLinear
The layout of weight is transposed compared to SparseLinear . This was done for performance considerations.
The gradWeight that is computed for in-place updates is a sparse representation of the whole gradWeight matrix. Its size changes from one backward pass to another. This was done for performance considerations.
The input format differs from the SparseLinear input format by accepting keys and values as a table of tensors. This enables IndexLinear to have a larger range for keys than SparseLinear .
The input tensors must be in one of the following formats.
An array of size 2 containing a batch of keys followed by a batch of values .
an array of size 3 containing a flattened (pre-concatenated) batch of keys , followed by values , and sizes .
Note: The tensors representing keys and sizes must always be of type LongTensor / CudaLongTensor . The values can be either FloatTensor or DoubleTensor or their cutorch equivalents.
Bilinear
Applies a bilinear transformation to the incoming data, i.e. \forall k: y_k = x_1 A_k x_2 + b . The input tensor given in forward(input) is a table containing both inputs x_1 and x_2 , which are tensors of size N x inputDimension1 and N x inputDimension2 , respectively. The layer can be trained without biases by setting bias = false .
You can create a layer in the following way:
Input data for this layer would look as follows:
PartialLinear
PartialLinear is a Linear layer that allows the user to a set a collection of column indices. When the column indices are set, the layer will behave like a Linear layer that only has those columns. Meanwhile, all parameters are preserved, so resetting the PartialLinear layer will result in a module that behaves just like a regular Linear layer.
This module is useful, for instance, when you want to do forward-backward on only a subset of a Linear layer during training but use the full Linear layer at test time.
You can create a layer in the following way:
Input data for this layer would look as follows:
One can set the partition of indices to compute using the function setPartition(indices) where indices is a tensor containing the indices to compute.
One can reset the partition via the resetPartition() function that resets the partition to compute all indices, making it's behaviour equivalent to nn.Linear
Dropout
During training, Dropout masks parts of the input using binary samples from a bernoulli distribution. Each input element has a probability of p of being dropped, i.e having its commensurate output element be zero. This has proven an effective technique for regularization and preventing the co-adaptation of neurons (see Hinton et al. 2012).
Furthermore, the outputs are scaled by a factor of 1/(1-p) during training. This allows the input to be simply forwarded as-is during evaluation.
In this example, we demonstrate how the call to forward samples different outputs to dropout (the zeros) given the same input :
Backward drops out the gradients at the same location:
In both cases the gradOutput and input are scaled by 1/(1-p) , which in this case is 2 .
During evaluation, Dropout does nothing more than forward the input such that all elements of the input are considered.
There is also an option for stochastic evaluation which drops the outputs just like how it is done during training:
We can return to training our model by first calling Module:training():
When used, Dropout should normally be applied to the input of parameterized Modules like Linear or SpatialConvolution. A p of 0.5 (the default) is usually okay for hidden layers. Dropout can sometimes be used successfully on the dataset inputs with a p around 0.2 . It sometimes works best following Transfer Modules like ReLU. All this depends a great deal on the dataset so its up to the user to try different combinations.
SpatialDropout
module = nn.SpatialDropout(p)
This version performs the same function as nn.Dropout , however it assumes the 2 right-most dimensions of the input are spatial, performs one Bernoulli trial per output feature when training, and extends this dropout value across the entire feature map.
As described in the paper "Efficient Object Localization Using Convolutional Networks" ( http://arxiv.org/abs/1411.4280), if adjacent pixels within feature maps are strongly correlated (as is normally the case in early convolution layers) then iid dropout will not regularize the activations and will otherwise just result in an effective learning rate decrease. In this case, nn.SpatialDropout will help promote independence between feature maps and should be used instead. nn.SpatialDropout accepts 3D or 4D inputs. If the input is 3D than a layout of (features x height x width) is assumed and for 4D (batch x features x height x width) is assumed.
VolumetricDropout
module = nn.VolumetricDropout(p)
This version performs the same function as nn.Dropout , however it assumes the 3 right-most dimensions of the input are spatial, performs one Bernoulli trial per output feature when training, and extends this dropout value across the entire feature map.
As described in the paper "Efficient Object Localization Using Convolutional Networks" ( http://arxiv.org/abs/1411.4280), if adjacent voxels within feature maps are strongly correlated (as is normally the case in early convolution layers) then iid dropout will not regularize the activations and will otherwise just result in an effective learning rate decrease. In this case, nn.VolumetricDropout will help promote independence between feature maps and should be used instead. nn.VolumetricDropout accepts 4D or 5D inputs. If the input is 4D than a layout of (features x time x height x width) is assumed and for 5D (batch x features x time x height x width) is assumed.
Abs
Add
Applies a bias term to the incoming data, i.e. yi = x_i + b_i , or if scalar = true then uses a single bias term, yi = x_i + b . So if scalar = true then inputDimension value will be disregarded.
Example:
gives the output:
i.e. the network successfully learns the input x has been shifted to produce the output y .
CAdd
Applies a component-wise addition to the incoming data, i.e. y_i = x_i + b_i . Argument size can be one or many numbers (sizes) or a torch.LongStorage . For example, nn.CAdd(3,4,5) is equivalent to nn.CAdd(torch.LongStorage{3,4,5}) . If the size for a particular dimension is 1, the addition will be expanded along the entire axis.
Example:
gives the output:
i.e. the network successfully learns the input x has been shifted by those bias factors to produce the output y .
Mul
Applies a single scaling factor to the incoming data, i.e. y = w x , where w is a scalar.
Example:
gives the output:
i.e. the network successfully learns the input x has been scaled by pi.
CMul
Applies a component-wise multiplication to the incoming data, i.e. y_i = w_i * x_i . Argument size can be one or many numbers (sizes) or a torch.LongStorage . For example, nn.CMul(3,4,5) is equivalent to nn.CMul(torch.LongStorage{3,4,5}) . If the size for a particular dimension is 1, the multiplication will be expanded along the entire axis.
Example:
gives the output:
i.e. the network successfully learns the input x has been scaled by those scaling factors to produce the output y .
Max
Applies a max operation over dimension dimension . Hence, if an nxpxq Tensor was given as input, and dimension = 2 then an nxq matrix would be output. When nInputDim is provided, inputs larger than that value will be considered batches where the actual dimension to apply the max operation will be dimension dimension + 1 .
Min
Applies a min operation over dimension dimension . Hence, if an nxpxq Tensor was given as input, and dimension = 2 then an nxq matrix would be output. When nInputDim is provided, inputs larger than that value will be considered batches where the actual dimension to apply the min operation will be dimension dimension + 1 .
Mean
Applies a mean operation over dimension dimension . Hence, if an nxpxq Tensor was given as input, and dimension = 2 then an nxq matrix would be output. When nInputDim is provided , inputs larger than that value will be considered batches where the actual dimension to apply the sum operation will be dimension dimension + 1 . This module is based on nn.Sum.
Sum
Applies a sum operation over dimension dimension . Hence, if an nxpxq Tensor was given as input, and dimension = 2 then an nxq matrix would be output. If argument squeeze is set to false then the output would be of size nx1xq . When nInputDim is provided , inputs larger than that value will be considered batches where the actual dimension to apply the sum operation will be dimension dimension + 1 . Negative indexing is allowed by providing a negative value to nInputDim . When sizeAverage is provided, the sum is divided by the size of the input in this dimension . This is equivalent to the mean operation performed by the nn.Mean module.
Euclidean
Outputs the Euclidean distance of the input to outputSize centers, i.e. this layer has the weights w_j , for j = 1 ,.., outputSize , where w_j are vectors of dimension inputSize .
The distance y_j between center j and input x is formulated as y_j = || w_j - x || .
WeightedEuclidean
This module is similar to Euclidean, but additionally learns a separate diagonal covariance matrix across the features of the input space for each center.
In other words, for each of the outputSize centers w_j , there is a diagonal covariance matrices c_j , for j = 1 ,.., outputSize , where c_j are stored as vectors of size inputSize .
The distance y_j between center j and input x is formulated as y_j = || c_j * (w_j - x) || .
Cosine
Outputs the cosine similarity of the input to outputSize centers, i.e. this layer has the weights w_j , for j = 1 ,.., outputSize , where w_j are vectors of dimension inputSize .
The distance y_j between center j and input x is formulated as y_j = (x · w_j) / ( || w_j || * || x || ) .
Kmeans
k is the number of centroids and dim is the dimensionality of samples. The forward pass computes distances with respect to centroids and returns index of closest centroid. Centroids can be updated using gradient descent. Centroids can be initialized randomly or by using kmeans++ algoirthm:
Example showing how to use Kmeans module to do standard Kmeans clustering.
nn.Kmeans() module maintains loss only for the latest forward. If you want to maintain loss over the whole dataset then you who would need do it my adding the module loss for every forward.
You can also use nn.Kmeans() as an auxillary layer in your network. A call to forward will generate an output containing the index of the nearest cluster for each sample in the batch. The gradInput generated by updateGradInput will be zero.
Identity
Creates a module that returns whatever is input to it as output. This is useful when combined with the module ParallelTable in case you do not wish to do anything to one of the input Tensors.
Example:
gives the output:
Here is a more useful example, where one can implement a network which also computes a Criterion using this module:
Copy
This layer copies the input to output with type casting from inputType to outputType . Unless forceCopy is true, when the first two arguments are the same, the input isn't copied, only transferred as the output. The default forceCopy is false. When dontCast is true, a call to nn.Copy:type(type) will not cast the module's output and gradInput Tensor s to the new type. The default is false.
Narrow
Narrow is application of narrow operation in a module. The module further supports negative length , dim and offset to handle inputs of unknown size.
Replicate
This class creates an output where the input is replicated nFeature times along dimension dim (default 1). There is no memory allocation or memory copy in this module. It sets the stride along the dim th dimension to zero. When provided, ndim should specify the number of non-batch dimensions. This allows the module to replicate the same non-batch dimension dim for both batch and non-batch inputs .
Reshape
Reshapes an nxpxqx.. Tensor into a dimension1xdimension2x... Tensor , taking the elements row-wise.
The optional last argument batchMode , when true forces the first dimension of the input to be considered the batch dimension, and thus keep its size fixed. This is necessary when dealing with batch sizes of one. When false , it forces the entire input (including the first dimension) to be reshaped to the input size. Default batchMode=nil , which means that the module considers inputs with more elements than the produce of provided sizes, i.e. dimension1xdimension2x... , to be batches.
Example:
View
This module creates a new view of the input tensor using the sizes passed to the constructor. The parameter sizes can either be a LongStorage or numbers. The method setNumInputDims() allows to specify the expected number of dimensions of the inputs of the modules. This makes it possible to use minibatch inputs when using a size -1 for one of the dimensions. The method resetSize(sizes) allows to reset the view size of the module after initialization.
Example 1:
Example 2:
For collapsing non-batch dims, check out nn.Collapse.
Contiguous
Is used to make input , gradOutput or both contiguous, corresponds to torch.contiguous function. Only does copy and allocation if input or gradOutput is not contiguous, otherwise passes the same Tensor .
Select
Selects a dimension and index of a nxpxqx.. Tensor .
Example:
gives the output:
This can be used in conjunction with Concat to emulate the behavior of Parallel, or to select various parts of an input Tensor to perform operations on. Here is a fairly complicated example:
MaskedSelect
Performs a torch.MaskedSelect on a Tensor . The mask is supplied as a tabular argument with the input on the forward and backward passes.
Example:
Gives the output:
Index
Applies the Tensor index operation along the given dimension. So
gives the same output as
Squeeze
Applies the Tensor squeeze operation. So
gives the same output as
Setting numInputDims allows to use this module on batches.
Unsqueeze
Insert singleton dim (i.e., dimension 1) at position pos . For an input with dim = input:dim() , there are dim + 1 possible positions to insert the singleton dimension. For example, if input is 3 dimensional Tensor in size p x q x r , then the singleton dim can be inserted at the following 4 positions
Example:
Indicate the expected input feature map dimension by specifying numInputDims . This allows the module to work with mini-batch. Example:
Transpose
Swaps dimension dim1 with dim2 , then dim3 with dim4 , and so on. So
gives the same output as
The method setNumInputDims() allows to specify the expected number of dimensions of the inputs of the modules. This makes it possible to use minibatch inputs. Example:
Exp
Applies the exp function element-wise to the input Tensor , thus outputting a Tensor of the same dimension.
Log
Applies the log function element-wise to the input Tensor , thus outputting a Tensor of the same dimension.
Square
Takes the square of each element.
Sqrt
Takes the square root of each element.
Power
Raises each element to its p -th power.
Clamp
Clamps all elements into the range [min_value, max_value] . Output is identical to input in the range, otherwise elements less than min_value (or greater than max_value ) are saturated to min_value (or max_value ).
Normalize
Normalizes the input Tensor to have unit L_p norm. The smoothing parameter eps prevents division by zero when the input contains all zero elements (default = 1e-10 ).
Input can be 1D or 2D (in which case it's considered as in batch mode)
Normalize has a specialized implementation for the inf norm, which corresponds to the maximum norm.
MM
Performs multiplications on one or more pairs of matrices. If transA is set to true, the first matrix is transposed before multiplication. If transB is set to true, the second matrix is transposed before multiplication. By default, the matrices do not get transposed.
The module also accepts 3D inputs which are interpreted as batches of matrices. When using batches, the first input matrix should be of size b x m x n and the second input matrix should be of size b x n x p (assuming transA and transB are not set). If transA or transB is set, transpose takes place between the second and the third dimensions for the corresponding matrix.
BatchNormalization
where N is the dimensionality of input eps is a small value added to the standard-deviation to avoid divide-by-zero. Defaults to 1e-5 . affine is a boolean. When set to false, the learnable affine transform is disabled. Defaults to true
During training, this layer keeps a running estimate of its computed mean and std. The running sum is kept with a default momentum of 0.1 (unless over-ridden) During evaluation, this running mean/std is used for normalization.
Implements Batch Normalization as described in the paper: "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift" by Sergey Ioffe, Christian Szegedy.
The operation implemented is:
where the mean and standard-deviation are calculated per-dimension over the mini-batches and where gamma and beta are learnable parameter vectors of size N (where N is the input size). The learning of gamma and beta is optional. The module only accepts 2D inputs.
PixelShuffle
module = nn.PixelShuffle(r)
Rearranges elements in a tensor of shape [C*r*r, H, W] to a tensor of shape [C, H*r, W*r] . This is useful for implementing efficient sub-pixel convolution with a stride of 1/r (see Shi et. al). Below we show how the PixelShuffle module can be used to learn upscaling filters to transform a low-resolution input to a high resolution one, with a 3x upscale factor. This is useful for tasks such as super-resolution, see "Real-Time Single Image and Video Super-Resolution Using an Efficient Sub-Pixel Convolutional Neural Network" - Shi et al. for further details.
Padding
This module adds pad units of padding to dimension dim of the input. If pad is negative, padding is added to the left, otherwise, it is added to the right of the dimension. When nInputDim is provided, inputs larger than that value will be considered batches where the actual dim to be padded will be dimension dim + 1 . When value is provide, the padding will be filled with that value . The default value is zero. When index is provided, padding will be added at that offset from the left or right, depending on the sign of pad .
Example 1:
Example 2:
Example 3:
L1Penalty
L1Penalty is an inline module that in its forward propagation copies the input Tensor directly to the output, and computes an L1 loss of the latent state (input) and stores it in the module's loss field. During backward propagation: gradInput = gradOutput + gradLoss .
This module can be used in autoencoder architectures to apply L1 losses to internal latent state without having to use Identity and parallel containers to carry the internal code to an output criterion.
Example (sparse autoencoder, note: decoder should be normalized):
GradientReversal
This module preserves the input, but takes the gradient from the subsequent layer, multiplies it by -lambda and passes it to the preceding layer. This can be used to maximise an objective function whilst using gradient descent, as described in "Domain-Adversarial Training of Neural Networks" ( http://arxiv.org/abs/1505.07818).
One can also call:
to set the hyper-parameter lambda dynamically during training.
GPU
Decorates an encapsulated module so that it can be executed on a specific GPU device . The decorated module's parameters are thus hosted on the specified GPU device . All operations on the gpu module are executed on that device. Calls to forward / backward will transfer arguments input and gradOutput to the specified device , which are then fed as arguments to the decorated module . Returned output is located on the specified outdevice (defaults to device ). Returned gradInput is allocated on the same device as the input .
When serialized/deserialized, the gpu module will be run on the same device that it was serialized with. To prevent this from happening, the module can be converted to float/double before serialization:
The module is located in the nn package instead of cunn as this allows it to be used in CPU-only environments, which are common for production models.
The module supports nested table input and gradOutput tensors originating from multiple devices. Each nested tensor in the returned gradInput will be transferred to the device its commensurate tensor in the input .
The intended use-case is not for model-parallelism where the models are executed in parallel on multiple devices, but for sequential models where a single GPU doesn't have enough memory.
Example using 4 GPUs:
Note how the last GPU instance will return an output tensor on the same device as the current device ( cutorch.getDevice ).
TemporalDynamicKMaxPooling
Selects the highest k values for each feature in the feature map sequence provided. The input sequence is composed of nInputFrame frames (i.e. nInputFrame is sequence length). The input tensor in forward(input) is expected to be a 2D tensor ( nInputFrame x inputFrameSize ) or a 3D tensor ( nBatchFrame x nInputFrame x inputFrameSize ), where inputFrameSize is the number of features across the sequence.
If factor is not provided, k = minK , else the value of k is calculated with:
Constant
This module outputs a constant value given an input. If nInputDim is specified, it uses the input to determine the size of the batch. The value is then replicated over the batch. Otherwise, the value Tensor is output as is. During backward , the returned gradInput is a zero Tensor of the same size as the input . This module has no trainable parameters.
You can use this with nn.ConcatTable() to append constant inputs to an input :
This is useful when you want to output a value that is independent of the input to the neural network.
WhiteNoise
This module adds isotropic Gaussian noise to the input . This can be useful for training Denoising Autoencoders. Takes mean and stdev of the normal distribution as constructor arguments. Default values for mean and standard deviation are 0 and 0.1 respectively. With module:training() , Gaussian noise is added during forward . During backward gradients are passed as is. With module:evaluate() the mean is added to the input.
OneHot
Transforms a tensor of input indices having integer values between 1 and outputSize into a tensor of one-hot vectors of size outputSize .
Forward an index to get a one-hot vector :
Forward a batch of 3 indices. Notice that these need not be stored as torch.LongTensor :
Forward batch of 2 x 3 indices :
PrintSize
This module is useful for debugging complicated module composites. It prints the size of the input and gradOutput during forward and backward propagation respectively. The name is a string used to identify the module along side the printed size.
ZeroGrad
The module zeros the gradInput but forwards the input as-is.
Collapse
This module is the equivalent of:
It collapses all non-batch dimensions. This is useful for converting a spatial feature map to the single dimension required by a dense hidden layer like Linear.
Convert
Module to convert between different data formats. For example, we can flatten images by using :
or equivalently
Lets try it with an input:
You could also try:
Furthermore, it automatically converts the input to have the same type as self.output (i.e. the type of the module). So you can also just use is for automatic input type converions:
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.