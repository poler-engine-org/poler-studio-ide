> Source: https://github.com/LaurentMazare/tch-rs

GitHub - LaurentMazare/tch-rs: Rust bindings for the C++ api of PyTorch.
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
LaurentMazare / tch-rs Public
Notifications You must be signed in to change notification settings
Fork 415
Star 5.3k
Rust bindings for the C++ api of PyTorch.
License
Apache-2.0, MIT licenses found
Licenses found
Apache-2.0 LICENSE-APACHE
MIT LICENSE-MIT
5.3k stars 415 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 191
Pull requests 37
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
LaurentMazare/tch-rs
main
75 Branches 3 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
Apache-2.0 license
MIT license
tch-rs
Rust bindings for the C++ api of PyTorch. The goal of the tch crate is to provide some thin wrappers around the C++ PyTorch api (a.k.a. libtorch). It aims at staying as close as possible to the original C++ api. More idiomatic rust bindings could then be developed on top of this. The documentation can be found on docs.rs.
    
changelog
The code generation part for the C api on top of libtorch comes from ocaml-torch.
Getting Started
This crate requires the C++ PyTorch library (libtorch) in version v2.10.0 to be available on your system. You can either:
Use the system-wide libtorch installation (default).
Install libtorch manually and let the build script know about it via the LIBTORCH environment variable.
Use a Python PyTorch install, to do this set LIBTORCH_USE_PYTORCH=1 .
When a system-wide libtorch can't be found and LIBTORCH is not set, the build script can download a pre-built binary version of libtorch by using the download-libtorch feature. By default a CPU version is used. The TORCH_CUDA_VERSION environment variable can be set to cu117 in order to get a pre-built binary using CUDA 11.7.
System-wide Libtorch
On linux platforms, the build script will look for a system-wide libtorch library in /usr/lib/libtorch.so .
Python PyTorch Install
If the LIBTORCH_USE_PYTORCH environment variable is set, the active python interpreter is called to retrieve information about the torch python package. This version is then linked against.
Libtorch Manual Install
Get libtorch from the PyTorch website download section and extract the content of the zip file.
For Linux and macOS users, add the following to your .bashrc or equivalent, where /path/to/libtorch is the path to the directory that was created when unzipping the file.
The header files location can also be specified separately from the shared library via the following:
For Windows users, assuming that X:\path\to\libtorch is the unzipped libtorch directory.
Navigate to Control Panel -> View advanced system settings -> Environment variables.
Create the LIBTORCH variable and set it to X:\path\to\libtorch .
Append X:\path\to\libtorch\lib to the Path variable. If you prefer to temporarily set environment variables, in PowerShell you can run
You should now be able to run some examples, e.g. cargo run --example basics .
Windows Specific Notes
As per the pytorch docs the Windows debug and release builds are not ABI-compatible. This could lead to some segfaults if the incorrect version of libtorch is used.
It is recommended to use the MSVC Rust toolchain (e.g. by installing stable-x86_64-pc-windows-msvc via rustup) rather than a MinGW based one as PyTorch has compatibilities issues with MinGW.
Static Linking
When setting environment variable LIBTORCH_STATIC=1 , libtorch is statically linked rather than using the dynamic libraries. The pre-compiled artifacts don't seem to include libtorch.a by default so this would have to be compiled manually, e.g. via the following:
Examples
Basic Tensor Operations
This crate provides a tensor type which wraps PyTorch tensors. Here is a minimal example of how to perform some tensor operations.
Training a Model via Gradient Descent
PyTorch provides automatic differentiation for most tensor operations it supports. This is commonly used to train models using gradient descent. The optimization is performed over variables which are created via a nn::VarStore by defining their shapes and initializations.
In the example below my_module uses two variables x1 and x2 which initial values are 0. The forward pass applied to tensor xs returns xs * x1 + exp(xs) * x2 .
Once the model has been generated, a nn::Sgd optimizer is created. Then on each step of the training loop:
The forward pass is applied to a mini-batch of data.
A loss is computed as the mean square error between the model output and the mini-batch ground truth.
Finally an optimization step is performed: gradients are computed and variables from the VarStore are modified accordingly.
Writing a Simple Neural Network
The nn api can be used to create neural network architectures, e.g. the following code defines a simple model with one hidden layer and trains it on the MNIST dataset using the Adam optimizer.
More details on the training loop can be found in the detailed tutorial.
Using some Pre-Trained Model
The pretrained-models example illustrates how to use some pre-trained computer vision model on an image. The weights - which have been extracted from the PyTorch implementation - can be downloaded here resnet18.ot and here resnet34.ot.
The example can then be run via the following command:
This should print the top 5 imagenet categories for the image. The code for this example is pretty simple.
Importing Pre-Trained Weights from PyTorch Using SafeTensors
safetensors is a new simple format by HuggingFace for storing tensors. It does not rely on Python's pickle module, and therefore the tensors are not bound to the specific classes and the exact directory structure used when the model is saved. It is also zero-copy, which means that reading the file will require no more memory than the original file.
For more information on safetensors , please check out https://github.com/huggingface/safetensors
Installing safetensors
You can install safetensors via the pip manager:
Exporting weights in PyTorch
Note: the filename of the export must be named with a .safetensors suffix for it to be properly decoded by tch .
Importing weights in tch
Further examples include:
A simplified version of char-rnn illustrating character level language modeling using Recurrent Neural Networks.
Neural style transfer uses a pre-trained VGG-16 model to compose an image in the style of another image (pre-trained weights: vgg16.ot).
Some ResNet examples on CIFAR-10.
A tutorial showing how to deploy/run some Python trained models using TorchScript JIT.
Some Reinforcement Learning examples using the OpenAI Gym environment. This includes a policy gradient example as well as an A2C implementation that can run on Atari games.
A Transfer Learning Tutorial shows how to finetune a pre-trained ResNet model on a very small dataset.
A simplified version of GPT similar to minGPT.
A Stable Diffusion implementation following the lines of hugginface's diffusers library.
External material:
A tutorial showing how to use Torch to compute option prices and greeks.
tchrs-opencv-webcam-inference uses tch-rs and opencv to run inference on a webcam feed for some Python trained model based on mobilenet v3.
FAQ
What are the best practices for Python to Rust model translations?
See some details in this thread.
How to get this to work on a M1/M2 mac?
Check this issue.
Compilation is slow, torch-sys seems to be rebuilt every time cargo gets run.
See this issue, this could be caused by rust-analyzer not knowing about the proper environment variables like LIBTORCH and LD_LIBRARY_PATH .
Using Rust/tch code from Python.
It is possible to call Rust/tch code from Python via PyO3, tch-ext provides an example of such a Python extension.
Error loading shared libraries.
If you get an error about not finding some shared libraries when running the generated binaries (e.g. error while loading shared libraries: libtorch_cpu.so: cannot open shared object file: No such file or directory ). You can try adding the following to your .bashrc where /path/to/libtorch is the path to your libtorch install.
License
tch-rs is distributed under the terms of both the MIT license and the Apache license (version 2.0), at your option.
See LICENSE-APACHE, LICENSE-MIT for more details.
About
Rust bindings for the C++ api of PyTorch.
Topics
rust machine-learning deep-learning neural-network pytorch
Resources
Readme
License
Apache-2.0, MIT licenses found
Licenses found
Apache-2.0 LICENSE-APACHE
MIT LICENSE-MIT
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
5.3k stars
Watchers
50 watching
Forks
415 forks
Report repository
Releases
3 tags
Packages 0
No packages published
Used by 2.7k
[
 + 2,738](https://github.com/LaurentMazare/tch-rs/network/dependents)
Contributors 82
+ 68 contributors
Languages
Rust 63.9%
C++ 19.0%
C 16.3%
OCaml 0.7%
Python 0.1%
CMake 0.0%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.