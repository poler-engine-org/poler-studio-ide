POLER FPGA Project — Полный исходный код
Сгенерировано: 2026-06-08 05:06 UTC
Инструменты: Zig 0.11.0 | Icarus Verilog 12.0 | RISC-V GCC 13.3.0 | GCC 14.2.0
--------------------------------------------------------------------------------
📄 verilog/tensor_product.v
--------------------------------------------------------------------------------
📄 verilog/poler_cycle.v
--------------------------------------------------------------------------------
📄 verilog/top_level.v
--------------------------------------------------------------------------------
📄 simulation/tb_tensor.v
--------------------------------------------------------------------------------
📄 zig/build.zig
--------------------------------------------------------------------------------
📄 zig/tensor.zig
--------------------------------------------------------------------------------
📄 zig/main.zig
--------------------------------------------------------------------------------
📄 tests/test_tensor.zig
--------------------------------------------------------------------------------
📄 assembly/startup.s
--------------------------------------------------------------------------------
📄 docs/README.md
a ⊗_ε b = a·b + ε·(a∧b)
A ⊗_ε A = A
fpga-project/ ├── verilog/           # Verilog/SystemVerilog HDL modules │   ├── tensor_product.v   # Deformed tensor product module │   ├── poler_cycle.v      # POLER cycle iteration engine │   └── top_level.v        # Top-level integration module ├── zig/               # Zig software implementation │   ├── main.zig           # Entry point with parallel computation │   └── tensor.zig         # Tensor product and POLER cycle in Zig ├── assembly/          # RISC-V assembly │   └── startup.s          # System initialization code ├── simulation/        # Testbenches │   └── tb_tensor.v        # Testbench for tensor product ├── tests/             # Software tests │   └── test_tensor.zig    # Zig unit tests └── docs/              # Documentation ├── README.md          # This file └── architecture.md    # Architecture description
Build Zig
Run Tests
References
POLER Architecture - Algebraic Theory of Archetypes
Deformed Tensor Products in Quantum Group Theory
FPGA Acceleration of Algebraic Computation
┌─────────────────────────────────────────────────┐ │              Software Layer (Zig)                │ │  ┌──────────┐  ┌───────────┐  ┌──────────────┐ │ │  │ main.zig │  │ tensor.zig│  │ test_tensor  │ │ │  │ (entry)  │  │ (compute) │  │ (validation) │ │ │  └─────┬────┘  └─────┬─────┘  └──────┬───────┘ │ └────────┼─────────────┼───────────────┼─────────┘ │             │               │ ┌────────┼─────────────┼───────────────┼─────────┐ │        │   Hardware Abstraction (Bus) │         │ │  ┌─────┴─────────────┴───────────────┴───────┐ │ │  │           APB-like Register Interface      │ │ │  │  ADDR_A=0x0  ADDR_B=0x1  ADDR_EPS=0x2    │ │ │  │  ADDR_RESULT=0x3  ADDR_CONTROL=0x6        │ │ │  └──────────────────┬────────────────────────┘ │ └─────────────────────┼──────────────────────────┘ │ ┌─────────────────────┼──────────────────────────┐ │           FPGA Hardware Layer                   │ │  ┌──────────────────┴────────────────────────┐ │ │  │              top_level.v                   │ │ │  │  ┌──────────────┐  ┌──────────────────┐   │ │ │  │  │tensor_product│  │   poler_cycle    │   │ │ │  │  │  a⊗_εb       │  │ P→O→L→E→R loop  │   │ │ │  │  └──────────────┘  └──────────────────┘   │ │ │  └───────────────────────────────────────────┘ │ └────────────────────────────────────────────────┘ │ ┌────────┼───────────────────────────────────────┐ │        │   RISC-V Soft Processor               │ │  ┌─────┴─────┐                                 │ │  │ startup.s │  (RV32IM initialization)        │ │  └───────────┘                                 │ └────────────────────────────────────────────────┘
Stage 1: product = a * b, wedge = a ^ b Stage 2: result = product + (epsilon * wedge) >> DEFORM_PARAM
--------------------------------------------------------------------------------
📄 docs/guide.md
a = 42, b = 17, ε = 0x1000 a ⊗_ε b = 717                    ← тензорное произведение с деформацией
POLER Cycle: Initial: 0x0f0f0f0f             ← начальное состояние Archetype: 0xff00ff00           ← ограничивающее множество Converged: 0xffffffff           ← аттрактор (неподвижная точка) Iterations: 2                   ← сошлось за 2 шага
ALL TESTS PASSED (6/6 тестов)
fpga-project/ ├── verilog/          ← Описание «железа» (что будет на кристалле) │   ├── tensor_product.v   — модуль тензорного произведения │   ├── poler_cycle.v      — модуль POLER цикла │   └── top_level.v        — всё вместе (верхний уровень) ├── zig/              ← Программная модель (запускается на ПК) │   ├── main.zig           — точка входа │   ├── tensor.zig         — реализация операций │   └── build.zig          — скрипт сборки ├── assembly/         ← Ассемблер RISC-V (для мягкого ядра в FPGA) │   └── startup.s ├── simulation/       ← Тесты для Verilog │   └── tb_tensor.v        — тестбенч (6 тестов) ├── tests/            ← Тесты для Zig │   └── test_tensor.zig └── docs/             ← Документация
a ⊗_ε b = a·b + ε·sin(a)·cos(b)
--------------------------------------------------------------------------------
📊 Статистика
Файлов: 9
Строк кода: 983
Языки: Verilog/SystemVerilog, Zig, RISC-V Assembly
Тесты Zig: ✅ PASS
Тесты Verilog: ✅ 6/6 PASS