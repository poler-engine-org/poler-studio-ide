> Source: https://github.com/SSIGPRO/MaskPruning

GitHub - SSIGPRO/MaskPruning
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
SSIGPRO / MaskPruning Public
Notifications You must be signed in to change notification settings
Fork 0
Star 0
License
MIT license
0 stars 0 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 0
Pull requests 0
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
SSIGPRO/MaskPruning
main
1 Branch 0 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
MIT license
MaskPruning
General Description
We propose a novel pruning technique based on trainable probability masks that, when binarized, select the elements of the network to prune. Our method features i) an automatic selections of the elements to prune by jointly training the binary masks with the model, ii) the capability of controlling the pruning level through hyper-parameters of a novel regularization term.
We have succesfully applied our method to prune the dense layers of AlexNet: check the Jupyter Lab demo!
This is a first version of a project that will be integrated and expanded in future, i.e., we plan to make our pruning masks work for many more layer types.
Prunining by Masking
We make use of trainable binary masks in our work, that we first encounterd in [1] ,[2].
Binary masks are able to create binary structures by searching for the probability of every element of the final mask to be 0 or 1. Using probability masks allows to i) create non-binary and differentiable masks at training time, so the model can be trained (backpropagation would be hampered if binary object were used), and ii) to create binary masks at inference time, so to guarantee real pruning.
We train the resulting model by adding a novel regularization term in the loss, whose purpose is to push to binary values the elements of probability mask.
Motivation of our method
In this work each dense layer of a neural network is coupled with a binary mask that learns what elements should be kept (1s in the mask) and what should be discarded (0s in the mask). The great and real advantage of our method is that model weights and mask weights are trained at the same time, so to run a pruning strategy that literally i) prunes only the weights that would make the loss decrease, and ii) re-adapts the non-pruned weights, in order to decrese the loss.
Mask Pruning library
A new class "Model_for_pruning" is created. It inherits from "tf.keras.Model" and adds many functionalities:
given a model, it authomatically couples all the Dense layers with a trainable binary mask layer;
lets the user easily modify the internal parameters of the network, also proving shortcuts to methods used for visualization;
when the training is over, authomatically returns the pruned model by removing the masks and by only keeping the layers/weights corresponding to the "1s" of the masks.
The result is a handy collection of functions, all encompassed in the class "Model_for_pruning". Check the demo for a quick demonstration based on AlexNet.
References
[1] https://github.com/cagladbahadir/LOUPE
[2] C. D. Bahadir, A. Q. Wang, A. V. Dalca and M. R. Sabuncu, "Deep-Learning-Based Optimization of the Under-Sampling Pattern in MRI," in IEEE Transactions on Computational Imaging, vol. 6, pp. 1139-1152, 2020, doi: 10.1109/TCI.2020.3006727.
About
No description, website, or topics provided.
Resources
Readme
License
MIT license
Uh oh!
There was an error while loading. Please reload this page.
Activity
Custom properties
Stars
0 stars
Watchers
0 watching
Forks
0 forks
Report repository
Releases
No releases published
Packages 0
No packages published
Languages
Python 56.8%
Jupyter Notebook 43.2%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.