> Source: https://philsci-archive.pitt.edu/23999/1/Bamonti,Cinti,Sanchioni-WheelerDeWitt.pdf

Quo Vadis Wheeler-DeWitt Time? 
Challenging Emergent Time in Quantum Cosmology 
Nicola Bamonti1,2, Enrico Cinti3, Marco Sanchioni4 
1 Department of Philosophy, Scuola Normale Superiore 
Piazza dei Cavalieri 7, 56126 Pisa, Italy 
2Department of Philosophy, University of Geneva, 
5, rue de Candolle, CH-1211 Genève 4, Switzerland 
3ILLC/IoP/DIEP, University of Amsterdam, 
1090 GL Amsterdam, The Netherlands 
4Istituto Universitario Sophia, 
Via San Vito n.28, Loppiano, 50064 Figline e Incisa Valdarno (FI) Italia 
1,2nicola.bamonti@sns.it 3cinti.enrico@gmail.com, 4marco.sanchioni2@gmail.com 
Abstract 
This paper challenges the notion of emergent time in quantum cosmology by examining 
the reconciliation of the timeless Wheeler-deWitt equation with the Universe’s 
dynamical evolution. It critically evaluates the analogy between the Wheeler-DeWitt 
and Klein-Gordon equations, highlighting challenges for the identification of an emergent 
time parameter. The paper concludes that refining this analogy may lead to a better 
understanding of emergent time in quantum cosmology, though still not free of 
complications. 
1
Contents 
1 Introduction 2 
2 On the Choice of α as Time 3 
3 KG-WdW (dis)Analogy 5 
4 Time and Functionalism 9 
5 A Good Analogy between WdW and KG 11 
6 Where did Time Go? 13 
7 Conclusion 15 
1 Introduction 
The problem of identifying time from a timeless description is one of the oldest and most 
fascinating puzzles in quantum gravity (QG) and, in particular, in quantum cosmology 
(QC). In this latter context, in particular, it takes the form of the problem of reconciling 
the apparent timelessness of the Wheleer-deWitt (WdW) equation with the dynamical 
evolution of our universe, particularly its (semi)classical description in terms of fields 
evolving over a smooth spacetime manifold. 
Various strategies have been pursued in the attempt to resolve this problem, ranging 
from the use of a semiclassical approximation to justify the emergence of time in the 
semiclassical regime to different ways of identifying a time variable prior to quantization, 
which then makes the quantum regime temporal (Isham, 1992). The former strategy, 
realized by applying the WKB approximation to the WdW equation, has enjoyed 
significant popularity in the QC literature. Important discussions of this approach in the 
physics literature are Vilenkin (1989); Kuchař (2011); Kiefer (2012); in the philosophical 
literature Thebault (2021); Huggett and Thébault (2023) are recent in-depth discussions 
of the conceptual foundations of this strategy. 
2
The emergent time strategy is often justified with a formal analogy between the 
WdW equation and the Klein-Gordon (KG) equation: in particular, one claims that, in 
the semiclassical limit, the volume of the universe α in the WdW equation is analogous 
to the time parameter in the KG equation. Hence, since upon taking two formally 
analogous equations and studying them in the appropriate regime, we find that the time 
parameter in KG is mapped to the α parameter in WdW, then it is natural to view α as 
an emergent time in WdW, or so the argument goes. 
In this paper, we challenge this widespread view in QC by first arguing that the 
choice of the parameter α is underdetermined, and there are multiple equally good 
candidates for time (§2). We then discuss two possible strategies to isolate α as the 
“correct” time parameter, one based on the analogy with KG (§3), and the other based 
on a form of functionalism, put forward by Huggett and Thébault (2023) (§4): both strategies are found unsatisfactory. Finally, we discuss how to make the analogy between 
KG and WdW precise (§5). However, we point out that this analogy leads to a very 
different picture of time than what we might have expected, and it is not even clear 
whether, in this form, the analogy is sufficient to identify time in WdW (§6). We then 
conclude (§7). 
2 On the Choice of α as Time 
To apply canonical QG à la WdW to cosmology, we employ minisuperspace. 
Minisuperspace arises from the possibility of restricting the general problem of defining 
QG to simpler, highly symmetric spacetimes, reducing the dynamics to a 
finite-dimensional problem. The most relevant application of minisuperspace is to a 
homogeneous Universe, described by a class of different cosmologies known as the nine 
Bianchi models (Bianchi, 1897). In such spaces, the 3-geometries {hij} are equivalent to 
the three scale factors {a(t), b(t), c(t)} of the anisotropic universe, since the homogeneity 
condition makes the theory invariant under 3-diffeomorphisms. Consequently, the space 
of physical states is reduced to a finite-dimensional subspace of Wheeler’s Superspace 
(the space of 3-geometries) and the WdW wavefunctional is replaced by a wavefunction. 
The construction of the Hamiltonian representation of Bianchi models is usually 
3
performed by using the variables (α(t), β±(t)), known as Misner variables (Misner, 
1969): the variable α(t) is related to the spatial volume of the universe, while β± 
represent the spatial anisotropies and correspond to the two physical degrees of freedom 
of gravity. It is worth noting that the physical states ψ(t, α, β±) are defined in the space 
of the volume and anisotropies of the universe, which does not coincide with the physical 
spacetime, thus precluding any clear notion of causality. 
In this new framework, the canonical formalism gives a weakly vanishing 
Hamiltonian, known as the Bianchi-Misner Hamiltonian HBM , since it is a linear 
combination of first-class constraints. Therefore, as in the case of QG, the universe’s 
wavefunction ψ does not depend on the time coordinate t. The WdW equation for the 
Bianchi models is: 
HBM |ψ⟩ = 2χe−3α/2ℏ2[∂2α − ∂2β± + UB(α, β±)]ψ(α, β±) = 0 (1) 
where χ = 8πG and UB(α, β±) is known as the Bianchi potential. Consistently with the 
finite-dimensional reduction of the general theory, it represents a single equation defining 
a 3-dimensional quantum system. One can see an immediate similarity with a KG 
equation with a varying mass, highlighting how the universe’s volume, related to the 
variable α, has the features of a good internal time, while the β± variables represent the 
spatial coordinates. Hence, the evolution of the quantum universe resembles that of a 
relativistic particle moving in a 3-dimensional space (although the causal structure of the 
minisuperspace has no direct physical meaning). 
However, α is not unique in having the features of a good time parameter: as is well 
known in the literature, in certain cosmological models, it is also legitimate to choose, 
e.g., a scalar field as time parameter (Rovelli and Smolin, 1994; Isham, 1992). For 
instance, in the quantum FRLW cosmological model, it is possible to use the matter 
degrees of freedom as the physical clock of the theory. 
Considering the Bianchi-Misner superHamiltonian (1) and taking the isotropic case, 
we obtain the WdW equation in Misner variables for the vacuum, flat FLRW 
cosmological model with zero cosmological constant: 
2χe−3α/2ℏ2[∂2α + UB(α)]ψ(α) = 0 (2) 
4
Following Kiefer (1988), we take the matter content to be represented entirely by a 
homogeneous scalar field ϕ with a potential V (ϕ). 
In such a way, the WdW equation of the model is: 
ĤFLRW |ψ⟩ = 2χe−3α/2ℏ2[∂2α − ∂2ϕ + V (α, ϕ)]ψ(α, ϕ) = 0 (3) 
where V (α, ϕ) = e3αV (ϕ). 
Under the inflationary assumption of a non-interacting field in the limit of the 
cosmological singularity (Kolb and Turner, 1994), necessary for QC, the potential V (ϕ) 
dependent on the derivatives of the scalar field ϕ can be neglected. Consequently, we 
recover the 2-dimensional KG-like equation: 
2χe−3α/2ℏ2[∂2α − ∂2ϕ]ψ(α, ϕ) = 0 (4) 
which describes a free, massless particle, where both the variable α and the scalar field ϕ 
can play the role of time (Bamonti et al., 2022). Hence, it is underdetermined which 
parameter plays the role of time in the (semi)classical regime since we have no 
straightforward way to decide which variable between ϕ and α should play this role. In 
the next section, we will discuss some attempts at establishing α as the correct emergent 
time parameter. 
3 KG-WdW (dis)Analogy 
The analogy between the KG and the WdW equations is fundamentally grounded in 
their structural similarity: both represent second-order differential equations that impose 
constraints on the wavefunction. This similarity lays the groundwork for the claim that 
the parameter α may fulfil an analogous role in each equation, despite the arguments of 
the preceding section. A crucial point for this analogy, in particular as concerns the 
temporal status of α, is that the dynamics of the two theories must be, in some sense, 
analogous. Since the temporal status of α emerges from dynamical considerations, as 
detailed in §2, a failure in a dynamical analogy between WdW and KG would imply that 
the two theories are disanalogous in the regime relevant to justifying the use of α as 
5
time; hence, for α to count as time, we need a deep similarity in the dynamical behavior 
of each theory. 
In any quantum field theory, whether it describes gravitational or non-gravitational 
fields, the dynamic of the theory is determined by its inner product, as it underpins 
conservation laws and the unitary evolution of quantum states. Consequently, whether α 
can assume the role of time is the question of how analogous the inner products of the 
KG and WdW equations are. If these inner products were analogous, we would have a 
correspondence in the dynamics of both theories, thereby validating the interpretation of 
α as describing time. On the other hand, a lack of analogy between the inner products 
suggests that the dynamics differ significantly between the two theories. This divergence 
would indicate that the role of time could be distinctly conceptualized within each 
theory, cautioning against a straightforward equivalence of the role played by α in the 
two theories. In this second case, the justification was merely on the formal structural 
similarities of the equations without a deeper dynamical analogy. To understand the 
status of the (dis)analogy of the inner product in the two theories, we follow Witten 
(2022). 
The KG inner product between two wavefunctions ϕ1 and ϕ2 both satisfying the KG 
equation in a spacetime M is given by: 
⟨ϕ1|ϕ2⟩KG = i 
∫ Σ 
dΣµ ϕ1 
←→ ∂ µϕ2, (5) 
where Σ is any Cauchy hypersurface in M , dΣµ is the surface element over which the 
integral is performed, and ϕ1 
←→ ∂ µϕ2 = ϕ1 ∂µϕ2 − ϕ2 ∂µϕ1, with ϕ the complex conjugate 
of ϕ. 
Defining an inner product for solutions to the WdW equation is significantly more 
involved than for the KG equation. Let us sketch the features of the WdW inner product 
that are most relevant to our discussion, though we will not give a complete 
construction. The general form of such an inner product is: 
⟨ϕ1|ϕ2⟩WdW = 
∫ Met/3-Diff 
Dh ϕ1(h) ∏ x⃗∈S 
δ(H(x⃗))ϕ2(h) . (6) 
6
where the integral spans the space of 3-metrics (Met) on a hypersurface S modulo 
3-diffeomorphisms (Met/3-Diff), also known as the Wheeler’s Superspace (see §2). This space encompasses the 3-metric configurations considered equivalent under spatial 
diffeomorphism transformations, highlighting the gauge invariance intrinsic to General 
Relativity. The wavefunctions ϕ1 and ϕ2 are functions of the 3-metric h, reflecting the 
quantum gravitational states as configurations of the geometry itself. The presence of the 
delta functions δ(H(x⃗)) within the integral enforces the Hamiltonian constraint at every 
point x⃗ on the hypersurface S, ensuring that only configurations satisfying the WdW 
equation contribute to the inner product. This mechanism guarantees that the inner 
product is computed over “physical” states—those that are solutions to the Hamiltonian 
constraint Hψ = 0. This inner product also defines the following equivalence relation:1 
ψ(h) ≡ ψ(h) + ∑ i 
H(x⃗i)χi(h) , (7) 
which plays a crucial role in this context. It states that two quantum states are 
equivalent if their difference can be expressed as a sum of terms, each term being the 
application of the Hamiltonian operator H(x⃗i) at various points x⃗i to arbitrary functions 
χi(h). This relation is a quantum analogue of the classical Hamiltonian constraint, 
extending its role from eliminating non-physical configurations to defining an equivalence 
class of quantum states. By integrating over (Met/3-Diff) and incorporating the product 
of delta functions, the inner product (6) inherently respects the equivalence relation, 
ensuring that the path integral quantization framework accommodates diffeomorphism 
invariance. 
This revised interpretation of the constraint operators underlying the inner product 
(6) carries a significant advantage: this formulation allows the WdW theory to be 
quantized using the BRST formalism (Becchi et al., 1976; Henneaux and Teitelboim, 
1992). In BRST quantization one has to introduce ghost fields, which transform like the 
generators of the gauge symmetry —diffeomorphisms in our framework — but with 
opposite statistics. Thus, in our case, we would have to introduce a new field cµ(t, x⃗) that 
1The discrete sum over points xi ∈ S can also be replaced by a continuous integral. 
7
transforms as the generator of diffeomorphisms but has a Fermi-Dirac statistics.2 Having 
introduced the ghosts fields cµ(t, x⃗), one can then define the BRST charge Q as follows: 
Q = 
∫ S 
dD−1x √ h ( c0(t, x⃗)H(x⃗) + ci(t, x⃗)Pi(x⃗) + . . . 
) , (8) 
where c0 is the temporal component of the ghost field cµ(t, x⃗) and is coupled with H, while ci(t, x⃗) is its spatial component, and it is coupled with Pi(x⃗). The BRST charge Q 
obeys Q2 = 0 and one can thus define a cohomology structure, i.e. a space of states that 
satisfy Qψ = 0 modulo the equivalence relation ψ ≡ ψ +Qχ for any other state χ. 
Cohomology is key in BRST quantization because it defines the physical states of the 
theory: physical states belong to the cohomology generated by the BRST charge. This 
mathematical structure mirrors the Hamiltonian constraint in the WdW equation: the 
condition Qψ = 0 gives both Hψ = 0 and Pi(x⃗)ψ = 0, which are, indeed, the traditional 
WdW constraints.3 
Leaving aside the complex derivation of the inner product, one can rewrite the inner 
product (6) in the following form: 
⟨ϕ1|ϕ2⟩WdW = 
∫ Dh0 Dc 
i Dcj ϕ1 (det Ξ)ϕ2 . (9) 
In this formulation, the WdW inner product is written as a path integral over the metric 
h and ghost fields. The crucial feature of this equation is the inclusion of det Ξ, a 
2For completeness, one also has to introduce antighosts and auxiliary fields in BRST 
quantization. However, these details are irrelevant to our argument; thus, we omit them 
for ease of exposition. 3For ease of exposition, we ignore the possibility that also cµ can annihilate a state 
ψ. Generally speaking, this could be the case. The quantum theory generated by BRST 
quantization can have states that obey just one of the traditional WdW constraints, or 
even none. Thus, the traditional WdW theory is a subset of the theory developed in the 
BRST framework. 
8
determinant resulting from integrating out additional ghost fields, just as is done when 
dealing with processes in QFTs, such as QCD. 
Given equations (5) and (9) for KG and WdW respectively, we are now equipped to 
compare their inner products. Despite the structural similarity of the equation of the 
two theories, there are two crucial differences in their inner products: 
 Definiteness of the Inner Product: It is well known that, unlike the 
positive-definite inner product found in non-relativistic quantum mechanics, the 
KG inner product can yield negative values for the norm of specific solutions. 
Indeed, the KG inner product can be negative, zero, or positive, reflecting the 
indefinite nature of the norm in the relativistic context. However, Witten (2022) 
shows that the inner product of the (revised version) of the WdW theory is 
positive-definite (as it is supposed to be for any theory of gravity). 
 Status of the Hamiltonian Constraint: Another critical difference between 
KG and WdW lies in the status of the Hamiltonian constraint. In WdW, the 
constraint imposes H(x⃗) = 0 for each point x⃗ in a Cauchy hypersurface S. 
However, the Hamilton constraint in KG theory imposes H = 0, H being a single 
operator. Thus, the Hamilton constraint of the WdW theory can be associated 
with an infinite family of KG-like Hamiltonian constraints. The same crucial 
difference can be seen from another point of view: the KG inner product of 
equation (5) is defined on a codimension 1 hypersurface U , while the WdW inner 
product (9) is defined on a submanifold of infinite codimension. 
4 Time and Functionalism 
Having seen how attempts at justifying the use of α as a time parameter in the 
semiclassical approximation based on an analogy with the Klein-Gordon equation fail, let 
us now move to consider a different approach, i.e. the functional strategy developed in 
Huggett and Thébault (2023). 
Without delving into unnecessary details, the point that Huggett and Thébault 
(2023) wish to make is that we can identify a time parameter by the role it plays in a 
9
certain physical theory, along the lines of how spacetime is analyzed in a functionalist 
approach (Knox, 2013, 2019; Baker, 2021). In particular, Huggett and Thébault (2023) 
suggest that time should be first divided into two aspects: the chrono-metric structure 
and the chrono-directed structure; the first one encodes a relation of betweenness 
between events, including a temporal metric to define temporal distances between such 
events, while the second one encodes a directionality for temporal relations, i.e. it tells 
whether an event is before or after another event to which is temporally related. For our 
purposes, it will be sufficient to discuss the status of the chrono-metric structure vis a vis 
emergent time, as this already is enough to see the problems that our discussion raises 
for this strategy to justify α as the time parameter. 
Huggett and Thébault (2023) in general want to claim that any structure that plays 
the time role will satisfy the chrono-metric properties described above, i.e., it will fix a 
betweenness relation between events and duration for intervals between events. At the 
same time, (Huggett and Thébault, 2023, p. 4) also emphasize that: 
Now, when a set of objects possesses structures with the formal properties 
that we have described, it is still legitimate to ask whether they are in fact 
temporal : perhaps instead they refer to some other physical relations (spatial 
relations, for instance). We take the general attitude that a structure can be 
identified as temporal in virtue of the roles it plays in dynamical physical 
theories. We do not offer a general account of what these roles are; rather we 
appeal to the fact that time is already identified in existing physical theories, 
and in this paper aim to pinpoint the (emergent) structures playing those 
roles. 
In other words, Huggett and Thébault (2023) take it that, given a certain physical 
theory, we should be able to identify the time parameter not by checking that it satisfies 
certain roles but rather that it corresponds, in the appropriate regime where time indeed 
emerges, to the time parameter of a theory whose temporal structure we antecedently 
understand. Huggett and Thébault (2023) then suggest that such a role, in the case of 
the WdW equation, is indeed played by the parameter α. 
From this discussion, it is immediate to see the problem for this strategy v̀ıs a v̀ıs our 
discussion in §2. Our discussion above points out a fundamental ambiguity in what 
10
counts as a time parameter, in the sense that there are multiple parameters with a prima 
facie equally good claim to the title of time. Hence, the functionalist strategy that 
Huggett and Thébault (2023) use cannot resolve such a problem since the problem for us 
is not to identify a parameter playing the time role but rather that we have too many 
parameters playing such a role. 
5 A Good Analogy between WdW and KG 
Despite the crucial differences between the inner products of the KG and WdW theories 
analyzed in §3, an underlying analogy exists when considering the KG theory from an 
appropriate perspective. We find common ground by reformulating the KG theory as a 
covariant theory on a one-dimensional worldline, effectively introducing a gravity-induced 
gauge symmetry akin to that found in the WdW theory. In this reformulation, the 
metric on the worldline is represented by e2(t), allowing the KG action to be rewritten to 
mirror the gauge symmetry considerations of the WdW discussion. This approach 
bridges the conceptual gap, demonstrating that the two theories’ inner products exhibit 
a crucial analogy rooted in their shared symmetry structures and gauge invariance 
principles. In this framework, the KG action can be rewritten as: 
S = 1 
2 
∫ λ 
dt 
( −1 
e ηµν 
dXµ 
dt 
dXν 
dt − em2 
) . (10) 
This action, invariant under reparametrization of λ, captures the essence of KG’s theory 
but incorporates a form of gauge symmetry through the dynamics of the one-dimensional 
worldline. The equivalence of this reparametrized action to the KG theory becomes 
evident through the Euler-Lagrange equation for the metric field e, which yields the KG 
Hamiltonian constraint. This result is derived as follows: 
0 = −∂S ∂e 
= 1 
e2 ηµν 
dXµ 
dt 
dXν 
dt +m2 = ηµνΠµΠν +m2 = −ηµν ∂ 
∂µ ∂ 
∂µ +m2 , (11) 
where the conjugate momenta Πµ are defined as Πµ = 1 e ηµν 
dXν 
dt , and, upon quantisation, 
these momenta become Πµ = −i ∂ ∂Xµ . 
By establishing a covariant version of the KG theory on the worldline, we can extend 
11
the application of BRST symmetry techniques—previously utilized in reformulating the 
WdW theory—to this context. This process necessitates introducing ghost fields 
associated with the theory’s symmetry generators. Specifically, for the covariant KG 
theory, we introduce a ghost field c tied to infinitesimal reparametrizations of the 
worldline. Given the need for this ghost field to possess opposite statistics compared to 
the field e, c is defined as a Grassmann number.4 
Without entering into unnecessary details of this derivation, it is possible to show 
that the inner product resulting from the BRST derivation aligns precisely with the KG 
inner product in (5). This derivation, revealing the structural analogy between the KG 
and WdW theories through BRST quantization, is important in understanding how the 
ghost fields’ integration, giving rise to the determinants, underpins both theories’ inner 
products. Specifically, the KG’s inner product ←→ ∂ µ term and the WdW’s det Ξ emerge as 
determinants resulting from integrating out ghost fields associated with their respective 
BRST symmetries. This structural similarity highlights a profound connection between 
the two theories, even as they manifest differently. The ←→ ∂ µ in the KG theory and det Ξ 
in the WdW theory both function as ghost determinants but are tied to distinct BRST 
symmetries, reflective of their respective theories’ underpinnings in relativistic quantum 
mechanics and QG. Consequently, these determinants contribute differently to the 
nature of each theory’s inner product: ←→ ∂ µ results in an indefinite inner product, 
aligning with the expectation for relativistic theories; on the other hand, det Ξ yields a 
positive definite inner product, consistent with the requirements for QG theories. 
Having identified a plausible analogy between WdW and KG, this can prima facie 
justify the identification of α as a time variable, modulo the caveats just highlighted. In 
the following section, we will however discuss some complications for this approach. 
4Grassmann numbers are used to describe fermionic variables or fermionic fields in 
QFT, where fermionic statistics require that operators corresponding to fermionic particles 
satisfy anticommutation relations (Peskin and Schroeder, 1995). 
12
6 Where did Time Go? 
We have seen in the previous section how one can justify using α as a time parameter, 
and that the analogy between the WdW and KG equations plays a crucial role. At the 
same time, such an analogy requires significant adjustments to justify the role of α as 
time. Let us briefly discuss some of the consequences and limitations of the argument in 
§5. First of all, however, let us emphasize what the argument of the previous section 
does indeed achieve. Insofar as it establishes a good formal analogy between the KG 
equation and the WdW equation, the argument of §5 ensures that we can at least think 
of α as the right parameter when we look for something that formally satisfies some of 
the properties of a time parameter. So, at the very least, the underdetermination 
problem raised in §2 is prima facie resolved by the discussion in §5. However, the analogy of §5 does not establish whether α behaves as we would expect time to behave, 
despite being formally analogous to the time parameter of the KG equation. 
For example, it is still the case that the Hamiltonian constraint of the WdW equation 
is pointwise. This fact implies that, as the Hamiltonian constraint is the origin of the 
alleged time flow parametrized by α, this flow is pointwise, not the kind of global flow we 
usually associate with time. In other words, the emergent time that we are defining from 
the WdW equation does not describe the flow of a 3-dimensional surface along the time 
dimension but rather describes the flow of an infinite number of points, each flowing 
independently through their own time (fixed by the Hamiltonian constraint at that 
point).5 
Another related but more fundamental problem with interpreting α as time lies with 
how we obtained the analogy with the KG equation in BRST quantization. In 
particular, we first moved to a worldline formulation of the theory to arrive at a BRST 
expression for the quantum KG equation. Then we noticed that in this context, there is 
a Hamiltonian constraint enforcing the invariance of the dynamics under arbitrary 
reparametrizations of the coordinate λ, enforcing that this coordinate does not encode 
physically relevant information. This Hamiltonian constraint then, upon BRST 
quantization, leads to an expression analogous to the WdW equation and hence allows 
5A related notion is the idea that relativistic time is many-fingered (Anderson, 2012). 
13
for the analogy between the two equations, particularly with respect to time, to go 
through. 
However, what is unclear in this procedure is whether the Hamiltonian constraint on 
the worldline still encodes a time parameter. If this condition fails, the analogy cannot 
give us time in the WdW equation. Let us briefly comment on why one might be 
skeptical regarding the temporal status of the Hamiltonian constraint in the KG 
equation. As we mentioned above, the Hamiltonian constraint in this context enforces a 
kind of reparametrization invariance on the worldline; as such, it does not seem to have 
any straightforward relation to physical time. One can relate it to time by noticing that 
the coordinate λ, parametrizing the worldline, which extends only through time, keeps 
track of the time expired across two points on the worldline. 
However, this interpretation only works because, in the KG equation, we have a 
background spacetime that gives us a physical definition of the time parameter. If we did 
not have such a background, then the Hamiltonian constraint would have told us that 
the theory is invariant under a choice of coordinate on the worldline, which either has no 
relation to time or, at best, enforces the same kind of disappearance of time that we 
found problematic in the first place when looking at the WdW equation. In other words, 
by moving to BRST quantization and fixing the analogy between KG and WdW, we 
have made KG more similar to WdW, and so harder to interpret, rather than simplifying 
the interpretation of WdW. Indeed, if we did not have a background, then KG would 
face the same problems as WdW; however, this is precisely the situation we find 
ourselves in with regard to WdW, which does not have a spacetime background, hence 
making the identification of α as time problematic, even if there is a broader analogy 
with KG. Indeed, once we have a well-defined analogy between KG and WdW, to 
identify time in KG we need to appeal to the spacetime background, which is the aspect 
in which the two theories are disanalogous. Hence, it is precisely in identifying the time 
parameter that the analogy between KG and WdW breaks down. 
14
7 Conclusion 
In this paper, we examined the WdW equation’s implications for the concept of time in 
QC, especially the challenge of defining an emergent time in a timeless universe. 
Through a critical analysis of the analogy between the WdW and KG equations, we 
highlighted the difficulties in identifying a suitable time parameter in QC. Our discussion 
underscores the complexity and ambiguity in conceptualizing time in this domain, calling 
for a more sophisticated understanding of the nature of time and dynamics in the WdW 
context. 
Indeed, the disanalogies in the inner products derived from KG and WdW underscore 
profound differences in their dynamics. While both theories exhibit structural 
similarities, the different nature of their inner products dictates fundamentally distinct 
dynamical behaviors. This disparity calls into question the straightforward use of 
analogy to justify treating the parameter α as time in QC. However, our discussion also 
reveals a profound analogy between the two theories, emphasizing the crucial role of 
quantizing gauge symmetries. While not immediately decisive for the question of α’s 
role, this important connection points to a rich vein of theoretical insight that could 
enhance our understanding of QG and relativistic quantum field theories. Exploring 
these implications will be left for future works. 
In conclusion, our investigation into the WdW equation reveals that the quest for an 
emergent time in QC faces significant conceptual hurdles, suggesting the development of 
frameworks that can accommodate the peculiar dynamical features of QC and deepen 
our understanding of our universe’s quantum gravitational structure. 
References 
Anderson, E. (2012). Problem of time in quantum gravity. 
Baker, D. J. (2021). Knox’s inertial spacetime functionalism (and a better alternative). 
Synthese 199 (Suppl 2), 277–298. 
Bamonti, N., A. Costantini, and G. Montani (2022). Features of the primordial universe 
15
in f (r)-gravity as viewed in the jordan frame. Classical and Quantum Gravity 39 (17), 
175011. 
Becchi, C., A. Rouet, and R. Stora (1976, June). Renormalization of gauge theories. 
Annals of Physics 98 (2), 287–321. 
Bianchi, L. (1897). Sugli spaźı a tre dimensioni che ammettono un gruppo continuo di 
movimenti: memoria. Tipografia della R. Accademis dei Lincei. 
Henneaux, M. and C. Teitelboim (1992). Quantization of gauge systems. Princeton 
university press. 
Huggett, N. and K. P. Thébault (2023). Finding time for wheeler-dewitt cosmology. 
arXiv preprint arXiv:2310.11072 . 
Isham, C. J. (1992). Canonical quantum gravity and the problem of time. 
Kiefer, C. (1988, September). Wave packets in minisuperspace. Physical Review 
D 38 (6), 1761–1772. 
Kiefer, C. (2012, April). Quantum Gravity (3 ed.). International Series of Monographs 
on Physics. London, England: Oxford University Press. 
Knox, E. (2013). Effective spacetime geometry. Studies in History and Philosophy of 
Science Part B: Studies in History and Philosophy of Modern Physics 44 (3), 346–356. 
Knox, E. (2019). Physical relativity from a functionalist perspective. Studies in History 
and Philosophy of Science Part B: Studies in History and Philosophy of Modern 
Physics 67, 118–124. 
Kolb, E. W. and M. S. Turner (1994, January). The early universe. Philadelphia, PA: 
Westview Press. 
Kuchař, K. V. (2011, July). Time and interpretations of quantum gravity. International 
Journal of Modern Physics D 20 (supp01), 3–86. 
16
Misner, C. W. (1969, October). Quantum cosmology. i. Physical Review 186 (5), 
1319–1327. 
Peskin, M. E. and D. V. Schroeder (1995, September). An introduction to quantum field 
theory. Philadelphia, PA: Westview Press. 
Rovelli, C. and L. Smolin (1994, January). The physical hamiltonian in nonperturbative 
quantum gravity. Physical Review Letters 72 (4), 446–449. 
Thebault, K. P. Y. (2021). The problem of time. In E. Knox and A. Wilson (Eds.), The 
Routledge Companion to Philosophy of Physics. Routledge. 
Vilenkin, A. (1989, February). Interpretation of the wave function of the universe. 
Physical Review D 39 (4), 1116–1122. 
Witten, E. (2022). A note on the canonical formalism for gravity. arXiv preprint 
arXiv:2212.08270 . 
17