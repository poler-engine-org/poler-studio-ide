> Source: https://burn.dev/

Burn
Home
Get Started
Learn
Blog
Benchmarks 
Home
Get Started
Learn
Blog
Benchmarks    
Turn Compute Into Intelligence
Train and deploy AI models efficiently on any device
Create neural networks that run better on any hardware, for both training and inference.
Burn's novel approach supports dynamic graphs and shapes with the performance of static graphs, thanks to our advanced multiplatform Just-in-Time compiler. 
Core Principles
We do not compromise on what matters the most in artificial intelligence.
We believe in maximizing compute across all existing hardware, turning it into impactful intelligence. 
Blazingly Fast
Combine multi-level compiler technology with runtime search to find the best way to run any neural network.  
Flexible
Build neural networks with dynamic graphs and shapes, without sacrificing performance for both training and inference.  
Portable
Run your models on cloud servers, laptops, mobile, from AMD, NVIDIA, Intel, Qualcom, Apple, or any computing device.  
The Next-Generation AI Infrastructure
Accelerate Progress with Burn
Increased Developer Productivity
Less performance tuning, no custom hacks, minimal debugging, no dependency hell. Optimized focus for more iterations.
More Iterations
More feedback accelerates model improvement and drives research breakthroughs, leading to better results.
Better Results
Whether you're deploying models more cost-effectively, improving customer satisfaction, or increasing your number of publications, it will enhance your work.
MNIST Inference Demo
Draw a digit here
Clear
Probability result
The model is built using Web Assembly and runs entirely in the browser.
The code can be found here.
Built with Rust
Burn introduces a unique architecture based on tensor operation streams, fully optimized at runtime and auto-tuned for your hardware by a Just-in-Time compiler. This approach relies on Rust's ownership rules to precisely track tensor usage, a feature unattainable without a robust type system. It enables you to create highly dynamic models with the performance of an extensively optimized static graph.
Burn adheres to the best practices of the Rust programming language, renowned for its reliability, enhancing development speed and helping you achieve your goals more quickly.  
Be part of our community
Join our Discord and GitHub group!
We want everyone to feel welcome, no matter their background. Ask questions, share your creations, and stay updated on Burn's latest releases! 🔥
2 408 Members
247 Contributors
14.4 K Stars
828 Forks
Join the mailing list Put a star on Github
   
Shape the future of AI with us
Let's get started
Join the mailing list
Join our community! We'd love to keep you in the loop with our newsletter.
⇥
✕
Resources
Home Get Started Benchmarks Blog Learn Docs Burn Book
Community
Github Discord Mailing list Tracel
Projects
Burn Crate Burn GitHub CubeCL Crate CubeCL GitHub
Company
Tracel AI Careers LinkedIn X
Copyright 2025 © Burn | Tracel Inc. All rights reserved. Design by