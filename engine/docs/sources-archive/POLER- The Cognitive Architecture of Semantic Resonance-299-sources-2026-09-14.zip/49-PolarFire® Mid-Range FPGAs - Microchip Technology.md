> Source: https://www.microchip.com/en-us/products/fpgas-and-plds/fpgas/polarfire-fpgas

PolarFire® Mid-Range FPGAs | Microchip Technology
Skip to main content Skip to footer
We detect you are using an unsupported browser. For the best experience, please visit the site using Chrome, Firefox, Safari, or Edge. X
Log in to myMicrochip to access tools and benefits. Sign up in just one minute.
Maximize Your Experience: Reap the Personalized Advantages by Completing Your Profile to Its Fullest. Update Here
Stay in the loop with the latest from Microchip. Update your profile while you are at it. Update Here
Complete your profile to access more resources. Update Here
This page requires frames in order to show content 
Cross-reference search 
Sign In
Dont have an account? Create Account
Dashboard
Settings
Change Password
Registered Development Tools
Log Out 
Products
All Products
Product Selection Tools
Microcontrollers
Microprocessors
Analog
Amplifiers and Linear ICs
Clock and Timing
Data Converters
Embedded Controllers
FPGAs and PLDs
High-Speed Networking
Interface and Connectivity
Memory Products
Power
RF and Microwave
Security
Sensors and Motor Drive
Services
Smart Energy Solutions
Storage
Touch
Wireless Connectivity
x
Browse Product Selection Tools view all
Analog and Interface Treelink Selection Tool
LDO Selector Guide
MemoryLink Product Selection Tool
Parametric Search Tool
x
Browse Microcontrollers view all
8-bit MCUs
PIC® MCUs
AVR® Microcontrollers (MCUs)
16-bit MCUs
Digital Signal Controllers (DSCs)
dsPIC33A DSCs
dsPIC33C DSCs
dsPIC33E DSCs
32-bit MCUs
Arm® Cortex®-Based MCUs
MIPS32® Core-Based MCUs
PIC32A High-Performance MCUs
Wireless MCUs
x
Browse Microprocessors view all
32-bit MPUs
64-bit MPUs
x
Browse Amplifiers and Linear ICs view all
Comparator ICs
Current Sense Amplifier ICs
Current/Voltage/Power Monitor ICs
Instrumentation Amplifier ICs
Operational Amplifier ICs
Programmable Gain Amplifier ICs
x
Browse Clock and Timing view all
Clock and Timing Components
Atomic Clocks
Clock and Data Distribution
Clock Generators
GNSS/PPS-Disciplined Oscillators
Jitter Attenuators
Oscillators
Real-Time Clocks (RTCCs)
Standard Crystals
SyncE and IEEE® 1588
Clock and Timing Systems
BlueSky® Technology
Enterprise Network Time Servers
GNSS Timing Accessories
GNSS Timing Instruments
M-Code Time and Frequency Solutions
SOSA® OpenVPX Systems
PTP IEEE® 1588 Grandmaster Clocks
Power Utility Timing Systems
Secure Position, Navigation and Time
Synchronization Management and Monitoring
Telecommunication Clock Systems
Time Scale and Time Measurement Systems
Timing Signal Distribution Amplifiers
Trusted Time For Zero Trust Networks
Virtual Primary Reference Time Clock
Frequency and Timing Systems Product Support
x
Browse Data Converters view all
AC/DC Power and Energy Devices
Analog-to-Digital Converters (ADCs)
Special-Purpose Analog-to-Digital Converters (ADCs)
Digital Potentiometers
Digital-to-Analog Converters (DACs)
Voltage Reference ICs
x
Browse Embedded Controllers view all
Data Center Controllers
Notebook and Desktop Embedded Controllers
Storage and Backplane Controllers
Bridge Controllers
x
Browse FPGAs and PLDs view all
FPGAs
PolarFire® Mid-Range FPGAs
System-on-Chip FPGAs
PolarFire® SoC FPGAs
Mi-V Ecosystem
Radiation-Tolerant FPGAs
Antifuse FPGAs
FPGA Documentation
Support for FPGAs and PLDs
Mature Products - AT40Kxx Coprocessor Series FPGAs
Low-Power FPGAs
FPGA Boards and Kits
FPGA Solution Stacks
IP Core Tools
FPGA Design Tools
Embedded Software Design
Hardware Design
Conversion Tools
FPGA Software Downloads
SPLD/CPLDs
PLD Design Resources
x
Browse High-Speed Networking view all
Ethernet Products
Power over Ethernet Products
ARCNET Controllers
Data and Video Transceivers
ASA Motion Link
Network Processors
Optical Networking Products
High-Speed Communications ICs
x
Browse Interface and Connectivity view all
ASA Motion Link
CAN and CAN FD Protocol Products
CoaXPress Technology
DC-DC High-Voltage Interface Drivers and Amplifier Arrays
Ethernet Products
INICnet™ Technology Solutions
LIN Bus Networking Products
Line Circuits
Line Drivers
PCIe Products
Serial Peripherals
USB
x
Browse Memory Products view all
OTP EPROM
Parallel EEPROM
Serial EERAM
Serial EEPROM
Serial and Parallel Flash Memory
Serial SRAM and Serial NVSRAM
Smart Memory Controllers (SMCs)
Memory Xplorer Embedded Memory Evaluation Platform
MemoryLink Product Selection Tool
x
Browse Power view all
Gate Drivers and Motor Drivers
High-Reliability Power Management
LED Drivers and Backlighting
Overvoltage and Overcurrent Protection Devices
Power Discretes (MOSFETs, IGBTs, Diodes, Rectifiers)
Power Supply and Battery Charging
Silicon Carbide Devices and Power Modules
Space-Grade Power Management Solutions
Voltage/Current Regulators, Converters and Controllers
x
Browse RF and Microwave view all
RF MMIC Amplifiers, Prescalers and Control Products
RF Modules and Assemblies
RF Power Amplifiers
RF Power Transistors
RF Power MOSFETs
RF Discrete and SAW Filters
RF Silicon and GaAs Diodes
Space-Grade RF and Microwave Solutions
Test and Measurement Solutions
5G Communication Solutions
x
Browse Security view all
Secure Authentication ICs
Platform Root of Trust Controllers
Trust Platform
MCUs With Integrated Security
Security With 32-bit MPUs
Military-Grade Security by Design
x
Browse Sensors and Motor Drive view all
CO, Smoke Detector and Horn Driver ICs
Inductive Position Sensors
Temperature Sensors
Current Sense Amplifiers
Current/Voltage/Power Monitor ICs
x
Browse Services view all
Frequency and Timing Systems Services
Wafer Foundry Services
Semiconductor Packaging and Assembly Services
x
Browse Smart Energy Solutions view all
Metering
Power Line Communications
Wireless Communications
x
Browse Storage view all
Smart Memory Controllers (SMCs)
PCIe® Switches
Flashtec® NVMe® Controllers
SmartIOC I/O Controllers
SmartROC RAID-on-Chip Controllers
SXP SAS Expanders
Tachyon® Protocol Controllers
Smart Storage Platform
Adaptec® Host Bus Adapters (HBAs)
Adaptec® SmartRAID RAID Adapters
Adaptec® Cables and Accessories
Adaptec® RAID Accelerators
XpressConnect™ Retimers
x
Browse Touch view all
Microcontrollers With On-Chip Touch
2D Touchpads with Microcontrollers
Getting Started
Turnkey MCUs with Capacitive Touch
maXTouch® Touchscreen Controllers
GestIC® Air Gesture Controllers
Touchscreens with Proximity Detection and Air Gestures
Legacy: Analog Resistive
Touch Development Tools
x
Browse Wireless Connectivity view all
Bluetooth® Low Energy
Multiprotocol
Matter
Sub-GHz
Thread
Wi-Fi®
Zigbee®
Specialty Wireless
Features
Plug-and-Play
Security
Applications
Solutions
All Megatrends and Solutions
Aerospace and Defense
Automotive and Transportation
Communications Infrastructure
Consumer
Data Centers and Computing
Industrial
IoT Solutions
Medical
Sustainability
Technologies
x
Browse Aerospace and Defense view all
Aviation
Defense
Space
Design Partners
Recommended for Aerospace and Defense Designs
x
Browse Automotive and Transportation view all
ADAS and AV
Body Electronics
Charging Station
Electric Two-Wheeler
EV, HEV and PHEV
IVN
Infotainment
ISO 26262 Automotive Functional Safety
Automotive Products
Recommended for Automotive
AUTOSAR Ecosystem
Electric Medium and Heavy-Duty Vehicles
Electric and Hybrid Maritime Vessels
Electric Railway Systems
x
Browse Communications Infrastructure view all
5G Network Infrastructure
Access Networks
Broadcast Video
Design Partners
FPGA Solutions for Communications Infrastructure
Transport Networks
x
Browse Consumer view all
Home Appliances
Intelligent Lighting and Control
x
Browse Data Centers and Computing view all
Data Center Solutions
Computing Solutions
x
Browse Industrial view all
Home Appliances
Intelligent Lighting and Control
Metering Solutions
Motor Control and Drive
Professional Audio
Smart Embedded Vision
Smart Building
Smart Factory
FPGAs for Industrial Applications
Robotics
x
Browse IoT Solutions view all
AliOS Things
Amazon Web Services
Microsoft Azure Cloud Computing
Cellular IoT
Smart Building
Smart Agriculture Solutions
Smart Factory
Smart Medical Solutions
Smart Mining and Construction
Products
IoT Development Kits
Design Partners
x
Browse Medical view all
Advanced Medical Technology
Clinical Devices
Dental Solutions
Diagnostic and Monitoring
Smart Medical Solutions
Diagnostic and Monitoring Solutions
Demonstrations and Design Files
Design Partners
Medical Imaging Semiconductor Technology
x
Browse Sustainability view all
Asset Tracking
Charging Station
Electric Two-Wheeler
Energy Storage System
EV, HEV and PHEV
HVAC
Liquid Detection
Motor Control for Energy Efficiency
Smart Agriculture Solutions
Smart Building
Smart Street Lighting
Solar Inverters
Design Partners
x
Browse Technologies view all
Networking and Connectivity
Edge AI
Edge Computing
Displays
Embedded Security
Functional Safety
Motor Control and Drive
Power Conversion
Tools
All Tools
MCU and MPU Development Tool Ecosystem
Mi-V RISC-V® Ecosystem
Search and Discover
Configure
Develop
Debug
Evaluation Boards
Qualify
Production
Archives
x
Browse Search and Discover view all
Development Tools Listing
Development Tools Selector
MPLAB® Discover Content Search Platform
x
Browse Configure view all
MPLAB® Code Configurator
MCC Melody
MCC Classic
MPLAB® Connect Configurator
MPLAB® Harmony v3
MPLAB® Harmony v3 Articles and Documentation
MPLAB® Network Creator
Microchip Graphics Suite (MGS)
Microchip Graphics Suite for Linux® OS
ClockWorks® Configurator
x
Browse Develop view all
MPLAB® Tools for VS Code®
MPLAB AI Coding Assistant
Zephyr® for Microchip
MPLAB® X IDE
MPLAB® XC Compilers
MPLAB® XC HPA
MPLAB® XC Compiler Advisor
Licenses
MPLAB® Ecosystem Downloads Archive
MPLAB® Machine Learning Development Suite
MPLAB® motorBench® Development Suite
MPLAB® PowerSmart™ Development Suite
Analog Development Tool Ecosystem
FilterLab Active Filter Designer
CLB Synthesizer
Development Tools for Arm® Core-Based MCUs
FPGA Design Tools
K2L Automotive Tools
Libraries, Code Examples and More
Trust Platform Design Suite
CMSIS Support for Microchip Devices
x
Browse Debug view all
Programmers and Debuggers
Atmel-ICE
MPLAB® ICD 5 In-Circuit Debugger
MPLAB® ICE 4 In-Circuit Emulator
MPLAB® PICkit™ 5 In-Circuit Debugger
MPLAB® PICkit™ Basic In-Circuit Debugger
MPLAB® Snap In-Circuit Debugger
Power Debugger
Development Tool Accessories
Data Visualizer
MPLAB® Data Visualizer
x
Browse Evaluation Boards view all
Development Tools Listing
Development Tools Selector (DTS)
Last Chance Deals
8-bit MCU Tools
16-bit MCU Tools
dsPIC® DSC Tools
32-bit MCU Tools
32-bit MPU Tools
64-bit MPU Tools
Analog Product Tools
FPGA Tools
Curiosity Development Boards
Curiosity Nano Development Platform
Xplained Boards
Maker and DIY Solutions
Development Tool Partners
FreeRTOS Guide
Development Tool Repair Service (CiSAR)
Development Tools Warranty
x
Browse Qualify view all
MPLAB® Code Coverage
MPLAB® Development Ecosystem for Functional Safety
MPLAB® Analysis Tool Suite
x
Browse Production view all
MPLAB® Integrated Programming Environment (IPE)
Softlog Tools
x
Browse Archives view all
AVR® and SAM MCU Downloads Archive
Softpacks
MPLAB® Ecosystem Downloads Archive
Resources
Reference Designs
MPLAB® Discover Content Search Platform
Dev Tool Selector
MPLAB® Mindi™ Software Library
Software Library
Technical Documentation
Package Outline Drawings
Export Control Data
Model Context Protocol (MCP) Server
x
Browse Technical Documentation view all
Application Notes
Data Sheets
Errata
Migration Documents
Product Briefs
Programming Specifications
Reference Manuals
User Guides
x
Browse Package Outline Drawings view all
FPGA Packaging
Support
Technical Learning
Microchip University On-Demand Courses
Developer Help Technical Training
MASTERs
Live FPGA Training
Videos
Podcasts
Case Studies
Academic Program
FIRST® Robotics Competition
Microchip Makes Community
x
Browse Videos view all
Coffee Break
Designs for the Edge
Ask Our Experts Video Series
Developer Help Videos
x
Browse Podcasts view all
Microchip Is ...
Beyond the Microchip
x
Browse Case Studies view all
Semtech USB 2.0 Connectivity Solution
PCIe® Interconnect Solution
Interoperability Testing With Toshiba
Predictive Maintenance for Smart Factories
IP Video Deployment With PoE
Rapid Prototyping of IoT Applications
x
Browse Microchip Makes Community view all
Frequently Asked Questions
About
Careers
Corporate Overview
Contact Us
Corporate Responsibility
Events
Global Sales and Distribution
Investor Relations
Legal Information
News and Media
x
Browse Careers view all
Microchip Around the World
Americas
Asia-Pacific
Europe and the Middle East
Intern and Graduate Programs
Mission, Vision and Values
Our Commitment to Employees
Working Here
x
Browse Corporate Overview view all
Artificial Intelligence (AI) at Microchip
Awards and Recognition
Global Manufacturing
Microchip FAQs
Notice of Fraudulent Behavior
Our Culture
Acquired Companies
Actel FPGAs
Adaptec® Products
Atmel Products
Micrel Products
Microsemi Products
Neuronix AI Labs
Vectron® Products
x
Browse Corporate Responsibility view all
Our Company
Our People
Our Planet
Our Products
Our Supply Chain
Environmental Health and Safety
x
Browse Legal Information view all
Copyright Guidelines
Microchip Logos
Microchip Patents
Microchip Trademarks
Privacy Notice
Secure Document Extranet Privacy Notice
Website Terms and Conditions
x
Browse News and Media view all
News Releases
RSS Feeds
Microchip Blog
Videos
Purchase
Products
Solutions
Tools
Resources
Support
Technical Learning
About
Purchase
Products
All Products
Product Selection Tools
Microcontrollers
Microprocessors
Analog
Amplifiers and Linear ICs
Clock and Timing
Data Converters
Embedded Controllers
FPGAs and PLDs
High-Speed Networking
Interface and Connectivity
Memory Products
Power
RF and Microwave
Security
Sensors and Motor Drive
Services
Smart Energy Solutions
Storage
Touch
Wireless Connectivity
Product Selection Tools
View All
Analog and Interface Treelink Selection Tool
LDO Selector Guide
MemoryLink Product Selection Tool
Parametric Search Tool
Microcontrollers
View All
8-bit MCUs
16-bit MCUs
Digital Signal Controllers (DSCs)
32-bit MCUs
Wireless MCUs
Microprocessors
View All
32-bit MPUs
64-bit MPUs
Amplifiers and Linear ICs
View All
Comparator ICs
Current Sense Amplifier ICs
Current/Voltage/Power Monitor ICs
Instrumentation Amplifier ICs
Operational Amplifier ICs
Programmable Gain Amplifier ICs
Clock and Timing
View All
Clock and Timing Components
Clock and Timing Systems
Data Converters
View All
AC/DC Power and Energy Devices
Analog-to-Digital Converters (ADCs)
Special-Purpose Analog-to-Digital Converters (ADCs)
Digital Potentiometers
Digital-to-Analog Converters (DACs)
Voltage Reference ICs
Embedded Controllers
View All
Data Center Controllers
Notebook and Desktop Embedded Controllers
Storage and Backplane Controllers
Bridge Controllers
FPGAs and PLDs
View All
FPGAs
System-on-Chip FPGAs
Radiation-Tolerant FPGAs
Antifuse FPGAs
FPGA Documentation
Support for FPGAs and PLDs
Mature Products - AT40Kxx Coprocessor Series FPGAs
Low-Power FPGAs
FPGA Boards and Kits
FPGA Solution Stacks
IP Core Tools
FPGA Design Tools
SPLD/CPLDs
High-Speed Networking
View All
Ethernet Products
Power over Ethernet Products
ARCNET Controllers
Data and Video Transceivers
ASA Motion Link
Network Processors
Optical Networking Products
High-Speed Communications ICs
Interface and Connectivity
View All
ASA Motion Link
CAN and CAN FD Protocol Products
CoaXPress Technology
DC-DC High-Voltage Interface Drivers and Amplifier Arrays
Ethernet Products
INICnet™ Technology Solutions
LIN Bus Networking Products
Line Circuits
Line Drivers
PCIe Products
Serial Peripherals
USB
Memory Products
View All
OTP EPROM
Parallel EEPROM
Serial EERAM
Serial EEPROM
Serial and Parallel Flash Memory
Serial SRAM and Serial NVSRAM
Smart Memory Controllers (SMCs)
Memory Xplorer Embedded Memory Evaluation Platform
MemoryLink Product Selection Tool
Power
View All
Gate Drivers and Motor Drivers
High-Reliability Power Management
LED Drivers and Backlighting
Overvoltage and Overcurrent Protection Devices
Power Discretes (MOSFETs, IGBTs, Diodes, Rectifiers)
Power Supply and Battery Charging
Silicon Carbide Devices and Power Modules
Space-Grade Power Management Solutions
Voltage/Current Regulators, Converters and Controllers
RF and Microwave
View All
RF MMIC Amplifiers, Prescalers and Control Products
RF Modules and Assemblies
RF Power Amplifiers
RF Power Transistors
RF Power MOSFETs
RF Discrete and SAW Filters
RF Silicon and GaAs Diodes
Space-Grade RF and Microwave Solutions
Test and Measurement Solutions
5G Communication Solutions
Security
View All
Secure Authentication ICs
Platform Root of Trust Controllers
Trust Platform
MCUs With Integrated Security
Security With 32-bit MPUs
Military-Grade Security by Design
Sensors and Motor Drive
View All
CO, Smoke Detector and Horn Driver ICs
Inductive Position Sensors
Temperature Sensors
Current Sense Amplifiers
Current/Voltage/Power Monitor ICs
Services
View All
Frequency and Timing Systems Services
Wafer Foundry Services
Semiconductor Packaging and Assembly Services
Smart Energy Solutions
View All
Metering
Power Line Communications
Wireless Communications
Storage
View All
Smart Memory Controllers (SMCs)
PCIe® Switches
Flashtec® NVMe® Controllers
SmartIOC I/O Controllers
SmartROC RAID-on-Chip Controllers
SXP SAS Expanders
Tachyon® Protocol Controllers
Smart Storage Platform
Adaptec® Host Bus Adapters (HBAs)
Adaptec® SmartRAID RAID Adapters
Adaptec® Cables and Accessories
Adaptec® RAID Accelerators
XpressConnect™ Retimers
Touch
View All
Microcontrollers With On-Chip Touch
Turnkey MCUs with Capacitive Touch
maXTouch® Touchscreen Controllers
GestIC® Air Gesture Controllers
Touchscreens with Proximity Detection and Air Gestures
Legacy: Analog Resistive
Touch Development Tools
Wireless Connectivity
View All
Bluetooth® Low Energy
Multiprotocol
Matter
Sub-GHz
Thread
Wi-Fi®
Zigbee®
Specialty Wireless
Features
Applications
8-bit MCUs
View All
PIC® MCUs
AVR® Microcontrollers (MCUs)
Digital Signal Controllers (DSCs)
View All
dsPIC33A DSCs
dsPIC33C DSCs
dsPIC33E DSCs
32-bit MCUs
View All
Arm® Cortex®-Based MCUs
MIPS32® Core-Based MCUs
PIC32A High-Performance MCUs
Clock and Timing Components
View All
Atomic Clocks
Clock and Data Distribution
Clock Generators
GNSS/PPS-Disciplined Oscillators
Jitter Attenuators
Oscillators
Real-Time Clocks (RTCCs)
Standard Crystals
SyncE and IEEE® 1588
Clock and Timing Systems
View All
BlueSky® Technology
Enterprise Network Time Servers
GNSS Timing Accessories
GNSS Timing Instruments
M-Code Time and Frequency Solutions
SOSA® OpenVPX Systems
PTP IEEE® 1588 Grandmaster Clocks
Power Utility Timing Systems
Secure Position, Navigation and Time
Synchronization Management and Monitoring
Telecommunication Clock Systems
Time Scale and Time Measurement Systems
Timing Signal Distribution Amplifiers
Trusted Time For Zero Trust Networks
Virtual Primary Reference Time Clock
Frequency and Timing Systems Product Support
FPGAs
View All
PolarFire® Mid-Range FPGAs
System-on-Chip FPGAs
View All
PolarFire® SoC FPGAs
Mi-V Ecosystem
FPGA Design Tools
View All
Embedded Software Design
Hardware Design
Conversion Tools
FPGA Software Downloads
SPLD/CPLDs
View All
PLD Design Resources
Microcontrollers With On-Chip Touch
View All
2D Touchpads with Microcontrollers
Getting Started
Features
View All
Plug-and-Play
Security
Solutions
All Megatrends and Solutions
Aerospace and Defense
Automotive and Transportation
Communications Infrastructure
Consumer
Data Centers and Computing
Industrial
IoT Solutions
Medical
Sustainability
Technologies
Aerospace and Defense
View All
Aviation
Defense
Space
Design Partners
Recommended for Aerospace and Defense Designs
Automotive and Transportation
View All
ADAS and AV
Body Electronics
Charging Station
Electric Two-Wheeler
EV, HEV and PHEV
IVN
Infotainment
ISO 26262 Automotive Functional Safety
Automotive Products
Recommended for Automotive
AUTOSAR Ecosystem
Electric Medium and Heavy-Duty Vehicles
Electric and Hybrid Maritime Vessels
Electric Railway Systems
Communications Infrastructure
View All
5G Network Infrastructure
Access Networks
Broadcast Video
Design Partners
FPGA Solutions for Communications Infrastructure
Transport Networks
Consumer
View All
Home Appliances
Intelligent Lighting and Control
Data Centers and Computing
View All
Data Center Solutions
Computing Solutions
Industrial
View All
Home Appliances
Intelligent Lighting and Control
Metering Solutions
Motor Control and Drive
Professional Audio
Smart Embedded Vision
Smart Building
Smart Factory
FPGAs for Industrial Applications
Robotics
IoT Solutions
View All
AliOS Things
Amazon Web Services
Microsoft Azure Cloud Computing
Cellular IoT
Smart Building
Smart Agriculture Solutions
Smart Factory
Smart Medical Solutions
Smart Mining and Construction
Products
IoT Development Kits
Design Partners
Medical
View All
Advanced Medical Technology
Clinical Devices
Dental Solutions
Diagnostic and Monitoring
Smart Medical Solutions
Diagnostic and Monitoring Solutions
Demonstrations and Design Files
Design Partners
Medical Imaging Semiconductor Technology
Sustainability
View All
Asset Tracking
Charging Station
Electric Two-Wheeler
Energy Storage System
EV, HEV and PHEV
HVAC
Liquid Detection
Motor Control for Energy Efficiency
Smart Agriculture Solutions
Smart Building
Smart Street Lighting
Solar Inverters
Design Partners
Technologies
View All
Networking and Connectivity
Edge AI
Edge Computing
Displays
Embedded Security
Functional Safety
Motor Control and Drive
Power Conversion
Tools
All Tools
MCU and MPU Development Tool Ecosystem
Mi-V RISC-V® Ecosystem
Search and Discover
Configure
Develop
Debug
Evaluation Boards
Qualify
Production
Archives
Search and Discover
View All
Development Tools Listing
Development Tools Selector
MPLAB® Discover Content Search Platform
Configure
View All
MPLAB® Code Configurator
MPLAB® Connect Configurator
MPLAB® Harmony v3
MPLAB® Network Creator
Microchip Graphics Suite (MGS)
ClockWorks® Configurator
Develop
View All
MPLAB® Tools for VS Code®
Zephyr® for Microchip
MPLAB® X IDE
MPLAB® XC Compilers
MPLAB® Ecosystem Downloads Archive
MPLAB® Machine Learning Development Suite
MPLAB® motorBench® Development Suite
MPLAB® PowerSmart™ Development Suite
Analog Development Tool Ecosystem
CLB Synthesizer
Development Tools for Arm® Core-Based MCUs
FPGA Design Tools
K2L Automotive Tools
Libraries, Code Examples and More
Trust Platform Design Suite
CMSIS Support for Microchip Devices
Debug
View All
Programmers and Debuggers
Data Visualizer
MPLAB® Data Visualizer
Evaluation Boards
View All
Development Tools Listing
Development Tools Selector (DTS)
Last Chance Deals
8-bit MCU Tools
16-bit MCU Tools
dsPIC® DSC Tools
32-bit MCU Tools
32-bit MPU Tools
64-bit MPU Tools
Analog Product Tools
FPGA Tools
Curiosity Development Boards
Curiosity Nano Development Platform
Xplained Boards
Maker and DIY Solutions
Development Tool Partners
Development Tool Repair Service (CiSAR)
Development Tools Warranty
Qualify
View All
MPLAB® Code Coverage
MPLAB® Development Ecosystem for Functional Safety
MPLAB® Analysis Tool Suite
Production
View All
MPLAB® Integrated Programming Environment (IPE)
Softlog Tools
Archives
View All
AVR® and SAM MCU Downloads Archive
MPLAB® Ecosystem Downloads Archive
MPLAB® Code Configurator
View All
MCC Melody
MCC Classic
MPLAB® Harmony v3
View All
MPLAB® Harmony v3 Articles and Documentation
Microchip Graphics Suite (MGS)
View All
Microchip Graphics Suite for Linux® OS
MPLAB® Tools for VS Code®
View All
MPLAB AI Coding Assistant
MPLAB® XC Compilers
View All
MPLAB® XC HPA
MPLAB® XC Compiler Advisor
Licenses
Analog Development Tool Ecosystem
View All
FilterLab Active Filter Designer
Programmers and Debuggers
View All
Atmel-ICE
MPLAB® ICD 5 In-Circuit Debugger
MPLAB® ICE 4 In-Circuit Emulator
MPLAB® PICkit™ 5 In-Circuit Debugger
MPLAB® PICkit™ Basic In-Circuit Debugger
MPLAB® Snap In-Circuit Debugger
Power Debugger
Development Tool Accessories
Development Tool Partners
View All
FreeRTOS Guide
AVR® and SAM MCU Downloads Archive
View All
Softpacks
Resources
View All
Reference Designs
MPLAB® Discover Content Search Platform
Dev Tool Selector
MPLAB® Mindi™ Software Library
Software Library
Technical Documentation
Package Outline Drawings
Export Control Data
Model Context Protocol (MCP) Server
Technical Documentation
View All
Application Notes
Data Sheets
Errata
Migration Documents
Product Briefs
Programming Specifications
Reference Manuals
User Guides
Package Outline Drawings
View All
FPGA Packaging
Technical Learning
View All
Microchip University On-Demand Courses
Developer Help Technical Training
MASTERs
Live FPGA Training
Videos
Podcasts
Case Studies
Academic Program
FIRST® Robotics Competition
Microchip Makes Community
Videos
View All
Coffee Break
Designs for the Edge
Ask Our Experts Video Series
Developer Help Videos
Podcasts
View All
Microchip Is ...
Beyond the Microchip
Case Studies
View All
Semtech USB 2.0 Connectivity Solution
PCIe® Interconnect Solution
Interoperability Testing With Toshiba
Predictive Maintenance for Smart Factories
IP Video Deployment With PoE
Rapid Prototyping of IoT Applications
Microchip Makes Community
View All
Frequently Asked Questions
About
View All
Careers
Corporate Overview
Contact Us
Corporate Responsibility
Events
Global Sales and Distribution
Investor Relations
Legal Information
News and Media
Careers
View All
Microchip Around the World
Intern and Graduate Programs
Mission, Vision and Values
Our Commitment to Employees
Working Here
Corporate Overview
View All
Artificial Intelligence (AI) at Microchip
Awards and Recognition
Global Manufacturing
Microchip FAQs
Notice of Fraudulent Behavior
Our Culture
Acquired Companies
Corporate Responsibility
View All
Our Company
Our People
Our Planet
Our Products
Our Supply Chain
Environmental Health and Safety
Legal Information
View All
Copyright Guidelines
Microchip Logos
Microchip Patents
Microchip Trademarks
Privacy Notice
Secure Document Extranet Privacy Notice
Website Terms and Conditions
News and Media
View All
News Releases
RSS Feeds
Microchip Blog
Videos
Microchip Around the World
View All
Americas
Asia-Pacific
Europe and the Middle East
Acquired Companies
View All
Actel FPGAs
Adaptec® Products
Atmel Products
Micrel Products
Microsemi Products
Neuronix AI Labs
Vectron® Products
true
Products /
FPGAs and PLDs /
FPGAs /
PolarFire® Mid-Range FPGAs
Block Diagram Key Benefits Documentation Product Table Design Tools Kits and Hardware 
[
PolarFire ® Mid-Range FPGAs
](https://www.microchip.com/en-us/products/fpgas-and-plds/fpga-news)    
See Latest FPGA News
Lowest-Power, Cost-Optimized, Mid-Range FPGAs
PolarFire ® FPGAs deliver award-winning performance with exceptional security, reliability and the lowest power consumption in their class. Spanning from 48K to 481K programmable Logic Elements (LEs), these mid-range devices include options with integrated 12.7 Gbps transceivers for high-speed serial connectivity in communications, imaging and embedded system applications.
Download PolarFire Data Sheet
Download PolarFire Core FPGAs Brochure 
Introducing PolarFire Core FPGAs
The PolarFire FPGA family now includes cost-optimized Core devices for applications that don't require high-speed serial transceivers. These FPGAs oﬀer up to 481K LEs with a wide range of logic densities, packaging options, fast I/O and conﬁguration ﬂexibility to meet diverse performance, power and cost requirements.
To view this video, please click manage cookies below and accept functional cookies.
Manage Cookies
Block Diagram
Key Benefits of PolarFire FPGAs
No results found
Cost-Optimized Architecture
Architecture and process optimizations for 50K–500K LE devices
Transceiver performance optimized for 12.7 Gbps, which yields smaller size
PolarFire Core FPGA family offers same PolarFire FPGA features without the transceivers for cost-sensitive applications
1.6 Gbps I/Os supporting DDR4/DDR3/LPDDR3, LVDS-hardened I/O gearing logic with CDR (supports SGMII/GbE links on GPIOs)
Best-in-class high-performance, hardened security IP in mid-range devices
Small form factor 11 × 11 mm package option
Power Optimization
Lowest power FPGAs: One-tenth (1/10) static power compared to competing devices
Transceivers optimized for 12.7 Gbps, which yields half the power of competing devices
Integrated hard IP: DDR PHY, PCIe ® endpoint/root port, crypto processor
Total power (static and dynamic): up to 50% lower power
PolarFire Core FPGA family offers same PolarFire FPGA features without the transceivers for even lower-power options
Documentation
Search Documentation [-]
All [-] Application Notes Application Notes [-] BSDL Files BSDL Files [-] Board Design Files Board Design Files [-] Brochures Brochures [-] Characterization Reports Characterization Reports [-] Data Sheets Data Sheets [-] Errata Errata [-] IBIS IBIS [-] Memory Maps Memory Maps [-] Packaging Specifications Packaging Specifications [-] Product Brief Product Brief [-] Reports Reports [-] Supporting Collateral Supporting Collateral [-] Thermal Models Thermal Models [-] Tools Tools [-] User Guide User Guide [-] White Paper White Paper
Showing for
Show
10
25
50
100
entries
Search:
Previous … 50 Next
Show
10
25
50
100
entries
Search:
Previous … 50 Next
Application Notes
Data Sheets
Overviews
Power Estimators/DDR Memory Analyzer
Reports
User Guides
Product Selector Guide
Application Notes
Demo Guides
Application Notes
Search:
Search:
Previous … 9 Next
×
Shasum Number:
Download Copy
Demo Guides
Search:
Search:
×
Shasum Number:
Download Copy
Product Data Sheets
Thermal Models
Errata
AEC-Q Reports
Characterization Reports
Validation Reports
Packaging/PPATS
BSDL Models
IBIS Models
S-parameters Models
Product Data Sheets
Search:
Search:
×
Shasum Number:
Download Copy
Thermal Models
Search:
Search:
×
Shasum Number:
Download Copy
Errata
Search:
Search:
×
Shasum Number:
Download Copy
AEC-Q Reports
Search:
Search:
×
Shasum Number:
Download Copy
Characterization Reports
Search:
Search:
×
Shasum Number:
Download Copy
Validation Reports
Search:
Search:
×
Shasum Number:
Download Copy
Packaging/PPATS
Search:
Search:
×
Shasum Number:
Download Copy
BSDL Models
Search:
Search:
Previous  Next
×
Shasum Number:
Download Copy
IBIS Models
Search:
Search:
×
Shasum Number:
Download Copy
Note:
IBIS Model Usage provides instructions on obtaining max/min source/sink current.
IBIS Background and Usage Application Notes provides signal integrity on PCBs.
S-Parameter Models
Search:
Search:
×
Shasum Number:
Download Copy
Product Overview
White Papers
Product Overviews
Search:
Search:
×
Shasum Number:
Download Copy
White Papers
Search:
Search:
×
Shasum Number:
Download Copy
Search:
Search:
×
Shasum Number:
Download Copy
Search:
Search:
×
Shasum Number:
Download Copy
User Guides
Register Maps
User Guides
Search:
Search:
×
Shasum Number:
Download Copy
Register Maps
Search:
Search:
×
Shasum Number:
Download Copy
PolarFire cost-optimized FPGAs deliver the lowest power at mid-range densities with 12.7 Gbps SerDes transceivers as well as best-in-class security and reliability. They offer unprecedented capabilities and value with 10G transceivers, advanced I/Os, security and DSP capabilities while maintaining all the advantages traditionally associated with nonvolatile FPGAs such as static power, security and single event upset (SEU) immunity. The devices are excellent for a wide range of applications within wireline access networks and cellular infrastructure, defense and commercial aviation markets, as well as industrial automation and IoT markets.
For details on specific military device offerings, please refer to the Product Overview. 
PolarFire Mid-Range FPGA Family
Note:
Devices in the same package and family type are pin compatible
The FCSG325 package has dimensions of 11 × 11 for MPF050 and MPF100 devices and 11 × 14.5 for MPF200 devices
PolarFire Core FPGA devices do not contain transceiver lanes or PCIe Gen 2 endpoints/root ports
Featured Applications
PolarFire FPGAs are excellent solutions for a wide range of applications within wireline access networks and cellular infrastructure, defense, smart embedded vision, commercial aviation markets, industrial automation and IoT markets.
No results found 
Communications
Learn More 
Defense
Learn More 
Industrial
Learn More 
Smart Embedded Vision
Learn More
Design Tools
Boost your design productivity with our comprehensive, easy-to-learn and easy-to-adopt development tools for designing with our FPGAs, SoC FPGAs and radiation-tolerant (rad-tolerant) FPGAs. In addition to our world-class Libero ® SoC Design Suite, our soft IP cores can complete your full platform design.
No results found 
Libero SoC Design Suite
This design suite enables high productivity with comprehensive, easy-to-learn and easy-to-adopt development tools for our power-efficient FPGAs.
Learn More 
SmartHLS™ Compiler
The SmartHLS compiler raises the abstraction level for faster design and easier verification of our FPGAs, SoC FPGAs and radiation-tolerant FPGAs.
Learn More 
IP Cores
Accelerate your time to market with our extensive suite of proven, optimized and easy-to-use IP cores for our FPGAs.
Learn More
No results found 
Mi-V Soft RISC-V ® Core
The MIV_RV32 is a soft processor core designed to implement the RISC-V ISA. The core includes a JTAG interface to facilitate debug access. Three optional bus interfaces are available for peripheral and memory accesses: AHB, APB3, and AXI, which can be configured as AXI3 or AXI4.
Learn More 
VectorBlox™ Accelerator SDK
With support for popular AI models and frameworks, VectorBlox accelerator SDK simplifies AI inferencing on PolarFire FPGAs, bridging the gap between software-centric AI development and hardware-optimized FPGA deployment.
Learn More
Kits and Hardware
PolarFire FPGA Kits
Previous
PCIe ® Root Port Adapter
The PCIe root port adapter is a hardware evaluation platform for evaluating and testing PolarFire FPGA PCIe root port capabilities, like the enumeration of an endpoint device and, low-speed and high-speed data transfers.
Learn More
PolarFire Video and Imaging Kit
Evaluate 4K image processing and rendering using dual camera sensors, numerous display interfaces and popular imaging and video protocols including MIPI ® CSI-2 TX, MIPI CSI-2 RX, HDMI ® 1.4 TX, HDMI 2.0, DSI and HD/3G SDI.
Learn More
PolarFire Evaluation Kit
This high-performance evaluation kit is well suited for high-speed transceiver evaluation, 10 Gigabit Ethernet, IEEE ® 1588, JESD204B, SyncE, CPRI and more.
Learn More
PolarFire Splash Kit
This kit enables general-purpose evaluation and development for the PolarFire FPGA. The kit includes Gigabit Ethernet RJ45, PCIe ®, USB and LPC FMC connectors and a PolarFire 300K LE FPGA with onboard DDR4 and SPI Flash memory.
Learn More
SDI FMC Daughter Card
This FMC daughter card is a hardware evaluation platform for evaluating and testing the Serial Digital Interface (SDI) IP.
Learn More
USXGMII FMC Daughter Card
This FMC daughter card is a hardware evaluation platform for evaluating and testing the quadrate PHY IP.
Learn More
CoaXPress ® FMC Daughter Card
This FMC daughter card is a hardware evaluation platform for evaluating and testing the 12.5 Gbps CoaXPress protocol.
Learn More
PCIe ® Root Port Adapter
The PCIe root port adapter is a hardware evaluation platform for evaluating and testing PolarFire FPGA PCIe root port capabilities, like the enumeration of an endpoint device and, low-speed and high-speed data transfers.
Learn More
PolarFire Video and Imaging Kit
Evaluate 4K image processing and rendering using dual camera sensors, numerous display interfaces and popular imaging and video protocols including MIPI ® CSI-2 TX, MIPI CSI-2 RX, HDMI ® 1.4 TX, HDMI 2.0, DSI and HD/3G SDI.
Learn More
PolarFire Evaluation Kit
This high-performance evaluation kit is well suited for high-speed transceiver evaluation, 10 Gigabit Ethernet, IEEE ® 1588, JESD204B, SyncE, CPRI and more.
Learn More
PolarFire Splash Kit
This kit enables general-purpose evaluation and development for the PolarFire FPGA. The kit includes Gigabit Ethernet RJ45, PCIe ®, USB and LPC FMC connectors and a PolarFire 300K LE FPGA with onboard DDR4 and SPI Flash memory.
Learn More
SDI FMC Daughter Card
This FMC daughter card is a hardware evaluation platform for evaluating and testing the Serial Digital Interface (SDI) IP.
Learn More
USXGMII FMC Daughter Card
This FMC daughter card is a hardware evaluation platform for evaluating and testing the quadrate PHY IP.
Learn More
CoaXPress ® FMC Daughter Card
This FMC daughter card is a hardware evaluation platform for evaluating and testing the 12.5 Gbps CoaXPress protocol.
Learn More
PCIe ® Root Port Adapter
The PCIe root port adapter is a hardware evaluation platform for evaluating and testing PolarFire FPGA PCIe root port capabilities, like the enumeration of an endpoint device and, low-speed and high-speed data transfers.
Learn More
Next
Programmers and Adapters
Previous
In-House-Programming
An optional In-House Programming (IHP) service is available if you are purchasing our devices in large volumes.
Learn More
FlashPro6
This latest-generation programmer supports the Windows ® and Linux ® operating systems in conjunction with Libero ® SoC Design Suite, FlashPro Express and SmartDebug software.
Learn More
FlashPro5
This fifth-generation programmer supports Windows and Linux environments.
Learn More
FlashPro4
This fourth-generation hardware programmer supports only Windows environments.
Learn More
Silicon Sculptor 4
This is a CE-compliant production device programmer.
Learn More
Silicon Sculptor Adapter Module
Silicon sculptor adapter modules are package specific. They depend on the product family, but are independent of gate count.
Learn More
ChipPro Programmer Baseboard
ChipPro is a quick and easy device programming solution for our FPGA devices.
Learn More
CPSOM-MPF100T-FCSG325
This System on Module (SoM) adapter card plugs into the ChipPro programmer baseboard.
Learn More
CPSOM-MPF200T-FCSG536
This SoM adapter card plugs into the ChipPro programmer baseboard.
Learn More
CPSOM-MPF300T-FCG484
This SoM adapter card plugs into the ChipPro programmer baseboard.
Learn More
In-House-Programming
An optional In-House Programming (IHP) service is available if you are purchasing our devices in large volumes.
Learn More
FlashPro6
This latest-generation programmer supports the Windows ® and Linux ® operating systems in conjunction with Libero ® SoC Design Suite, FlashPro Express and SmartDebug software.
Learn More
FlashPro5
This fifth-generation programmer supports Windows and Linux environments.
Learn More
FlashPro4
This fourth-generation hardware programmer supports only Windows environments.
Learn More
Silicon Sculptor 4
This is a CE-compliant production device programmer.
Learn More
Silicon Sculptor Adapter Module
Silicon sculptor adapter modules are package specific. They depend on the product family, but are independent of gate count.
Learn More
ChipPro Programmer Baseboard
ChipPro is a quick and easy device programming solution for our FPGA devices.
Learn More
CPSOM-MPF100T-FCSG325
This System on Module (SoM) adapter card plugs into the ChipPro programmer baseboard.
Learn More
CPSOM-MPF200T-FCSG536
This SoM adapter card plugs into the ChipPro programmer baseboard.
Learn More
CPSOM-MPF300T-FCG484
This SoM adapter card plugs into the ChipPro programmer baseboard.
Learn More
In-House-Programming
An optional In-House Programming (IHP) service is available if you are purchasing our devices in large volumes.
Learn More
Next
Third-Party Kits
Previous
Sundance DSP SoM3 PolarFire FPGA
This SoM based on a MPF300 PolarFire FPGA is well suited for high-security applications and other applications that require low power and small space.
Learn More
Aries Embedded M100PF SoM
The Aries Embedded SoM on PolarFire MPF100 device is well suited for a wide range of applications within wireline access networks and cellular infrastructure, defense, and commercial aviation markets.
Learn More
Arrow Everest Board
The Arrow Everest Evaluation Board on the MPF300TS device allows you to test your applications and designs immediately on hardware within a short amount of time.
Learn More
Future Avalanche Board
This low cost development board for Microchip PolarFire FPGAs allows you to quickly prototype with our low power mid-range FPGA platforms.
Learn More
HES-MPF500-M2S150
This board features a unique integration of our SmartFusion2 SoC FPGA and our PolarFire FPGA.
Learn More
Sundance Solar Express SE50
This board features a mini PCIe ® I/O and a processing module based on a PolarFire MPF300T FPGA.
Learn More
Sundance DSP SoM1 PolarFire FPGA
This SoM uses the powerful, low power and high-security MPF500T PolarFire FPGA, which features a small footprint, low power, high security, ample processing resources and multiple hardcore IPs.
Learn More
Sundance DSP SoM2 PolarFire FPGA
This is a SoM based on the MPF300 PolarFire FPGA. By using Sundance SOMs in your design, you can remove complexity from your development, increase the success rate and decreases time to market.
Learn More
Sundance DSP SoM3 PolarFire FPGA
This SoM based on a MPF300 PolarFire FPGA is well suited for high-security applications and other applications that require low power and small space.
Learn More
Aries Embedded M100PF SoM
The Aries Embedded SoM on PolarFire MPF100 device is well suited for a wide range of applications within wireline access networks and cellular infrastructure, defense, and commercial aviation markets.
Learn More
Arrow Everest Board
The Arrow Everest Evaluation Board on the MPF300TS device allows you to test your applications and designs immediately on hardware within a short amount of time.
Learn More
Future Avalanche Board
This low cost development board for Microchip PolarFire FPGAs allows you to quickly prototype with our low power mid-range FPGA platforms.
Learn More
HES-MPF500-M2S150
This board features a unique integration of our SmartFusion2 SoC FPGA and our PolarFire FPGA.
Learn More
Sundance Solar Express SE50
This board features a mini PCIe ® I/O and a processing module based on a PolarFire MPF300T FPGA.
Learn More
Sundance DSP SoM1 PolarFire FPGA
This SoM uses the powerful, low power and high-security MPF500T PolarFire FPGA, which features a small footprint, low power, high security, ample processing resources and multiple hardcore IPs.
Learn More
Sundance DSP SoM2 PolarFire FPGA
This is a SoM based on the MPF300 PolarFire FPGA. By using Sundance SOMs in your design, you can remove complexity from your development, increase the success rate and decreases time to market.
Learn More
Sundance DSP SoM3 PolarFire FPGA
This SoM based on a MPF300 PolarFire FPGA is well suited for high-security applications and other applications that require low power and small space.
Learn More
Next
Explore Other FPGA Kits and Hardware 
Support at Every Step
We are committed to partnering with you and making sure you have what you need to succeed.
Learn About Support [-]
About
Company
Careers
Contact Us
Media Center
Investor Relations
Corporate Responsibility [-]
Support
Microchip Forums
AVR Freaks
Design Help
Technical Support
Export Control Data
PCNs [-]
Quick Links
microchipDIRECT.com
Microchip University
myMicrochip
Blogs
Reference Designs
Parametric Search 
Microchip Technology Inc.
2355 West Chandler Blvd.
Chandler, Arizona, USA
© Copyright 1998-2026 Microchip Technology Inc. All rights reserved. Shanghai ICP Recordal No.09049794
Terms Of Use
Privacy Notice
Legal
Your Privacy Choices 
Live Chat
Need Help?
No problem. Chat with our engineering experts or schedule a call that's convenient for you.
Privacy Policy
Live Chat Schedule a call
{"SalesForceSecurePath":"https://microchip.my.salesforce-scrt.com","EmbeddedServiceName":"Messaging_For_Microchip","SalesForcePath":"https://microchip.my.site.com/ESWMessagingForMicrochi1755319480924","AgentAvailableHeader":"No problem. Chat with our engineering experts or schedule a call that's convenient for you.","ScheduleCallUrl":"https://microchip.my.site.com/schedulemeetingportal/s/","SalesforceOrgId":"00Do0000000KAkK","JsUrl":"https://microchip.my.site.com/ESWMessagingForMicrochi1755319480924/assets/js/bootstrap.min.js"} 
Privacy Preference Center
When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer.
Privacy Notice
Allow All
Manage Consent Preferences
Strictly Necessary Cookies
Always Active
These cookies are necessary for the Microchip website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not work. These cookies do not store any personally identifiable information.
Functional Cookies
[x]
Functional Cookies
By accepting these cookies, you allow Microchip to offer you enhanced functionality and personalized experiences on our website. These cookies may be set by us or trusted third-party providers whose services we integrate. Without these cookies, some features and services may not work as intended.
Targeting Cookies
[x]
Targeting Cookies
These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.
Performance Cookies
[x]
Performance Cookies
These cookies allow Microchip to count web page visits and traffic sources, so Microchip can measure and improve the performance of our experiences. These cookies help Microchip to know which experiences are the most and least popular and see how device owners interact with the experience. All information these technologies collect is aggregated. If the device owner does not allow these technologies, then Microchip will not know when the device owner visited or how the device owner interacted with our website
Cookie List
Clear
[-] checkbox label label
Apply Cancel
Consent Leg.Interest [-]
checkbox label label [-]
checkbox label label [-]
checkbox label label
Disable Optional Cookies Confirm My Choices