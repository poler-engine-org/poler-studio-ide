> Source: https://www.reddit.com/r/rust/comments/63wts9/why_are_there_so_many_linear_algebra_crates_which/

why are there so many linear algebra crates? Which one is "best"? : r/rust
Skip to main content why are there so many linear algebra crates? Which one is "best"? : r/rust
Open menu
Open navigation 
Go to Reddit Home 
r/rust
TRENDING TODAY
Get App
Get the Reddit app
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Navigation Skip to Right Sidebar
Back
 Go to rust
r/rust
• 9y ago
vitiral
Locked post
Stickied post
Archived post
View post in other languages
Report
why are there so many linear algebra crates? Which one is "best"?
CALLING ALL DATA TYPE LIBRARY MAINTAINERS: I would like your opinion! I have created an issue on "are we learning yet" to try and hash out a common conversion API that could be supported by all rust libraries and we would like your opinion!
I am looking to dive into basic machine learning, so naturally I went searching for a linear algebra library. I found (at least) 3:
ndarray: seems to support the most advanced features (BLAS, albeit experimentally) has been updated very recently.
nalgebra: seems to have the best documentation but is mostly for creating games (?). Also updated very recently
rulinalg: specifically for a machine learning crate, updated semi-recently. It looks like the author may want to convert to using ndarray as it's exported data types in the future
It seems to me that ndarray is the "community's choice" but I don't understand why all of the crates don't just use it for their core data types and build on top of it. Is it just that the community is young and nobody has put in the effort to unify around a common library in this area or is there something I'm missing?
Thanks, would love any feedback. Learning multiple libraries to do the same thing (and having this confusion) is not very good for rust as a language IMO.
Edit: additional libs
linxal: linear algebra library that largely connects ndarray to BLAS / LAPACK. Designed for machine learning.
cgmath computer graphics specific calculations
algebloat: linear algebra that is more similar to the C++ template libraries
sprs: library for sparse matrixes i.e. matricies in which most of the elements are zero
https://crates.io/crates/numeric
https://crates.io/crates/parenchyma
Read more
52
· 46
Comments Section
Andlon
•
9y ago
I'm one of the main contributors of rulinalg (pinging the author, u/SleepyCoder123).
I realize that from a user's perspective, the situation may be a little confusing. However, I think it's great that there are multiple libraries in development - they have different focus and goals, and this way there's more room for new ideas. Based on my understanding, the main differentiators seem to be:
ndarray: truly a marvelous feat of engineering, de facto choice for N-dimensional arrays. However, its genericity brings complexity and if you only need matrices and vectors, the added complexity may feel a little excessive (at least it does to me!).
nalgebra: superb documentation - I'm really envious! Main focus seems to be (or historically has been) on low-dimensional linear algebra (i.e. mainly 4x4 matrices or smaller) and as far as I know has been designed for use in games in mind.
rulinalg: aims to provide a great "out of the box" experience for high-dimensional linear algebra (i.e. "large" matrices and vectors), as it has no dependencies on external (non-rust) libraries. Since this library only exposes "matrices" and "vectors" (and not N-dimensional "arrays"), its data structures may perhaps be conceptually simpler to work with (in my admittedly biased opinion).
linxal: Brings LAPACK/BLAS support to ndarray. I'm not so familiar with this library as it's much newer than the others, but thankfully I see that u/masonium is already in this thread :-)
cgmath: very much specifically designed for computer graphics and/or game development
Now, as a contributor to rulinalg, I would love to recommend you to use rulinalg, but if you are looking for something that "just works" for machine learning purposes, I can't do so for the following reason: rulinalg's SVD - which is a fundamental algorithm for many machine learning problems - is fairly broken at the moment. Fixing this is at the very top of our TODO list, and hopefully should be resolved in the near future. Since linxal uses LAPACK as its backend, it is probably a better choice at the moment.
rulinalg is in active development (new contributors of any capacity are very welcome!), and there are a number of features currently not in any release. We're in the process of completely rewriting our decompositions (see decomposition). In the current release, only partial pivoting LU has been redesigned, but in the master branch and in pull requests pending review there are also:
an implementation of LU with complete pivoting (supporting rank estimation)
a redesigned Cholesky decomposition
a redesigned QR decomposition
Up next will be rewrites of our eigenvalue algorithms and SVD, which should fix our current issues.
While numpy is standard in the Python ecosystem, I'd be careful to consider it the holy grail of linear algebra library design - in my opinion, it is also fraught with design issues (which I don't want to get into at the moment). In Python, it is necessary to use N-dimensional arrays for speed, but if you are only interested in linear algebra, this design comes at the expense of significant added complexity (having to deal with N-dimensional arrays instead of just matrices and vectors) and often substantial increases in memory usage. I specifically started contributing to rulinalg because its vision best matches my own: it provides matrices and vectors, and it closely matches the corresponding mathematical concepts. Moreover, this is sufficient: you can express (afaik?) any linear algebra algorithm efficiently this way (though you'd probably have to view a vector as a column in a matrix to realize BLAS-3 potential, which rulinalg currently doesn't do). Any added array dimension beyond 2 is added complexity without significant benefits in this domain. This assumes you're not specifically working with tensors though.
Again, I want to reiterate that I belive ndarray to be a fantastic library. If you need N-dimensional arrays, it is the obvious choice. That said, it is in my humble opinion the wrong abstraction for linear algebra.
37
vitiral
OP
• 9y ago
Awesome reply, thank you so much for laying that all out!
I by no means think that numpy is any kind of "holy grail" of design. Rather, I think it would be great if we could have a similar kind of standardization.
I think one thing that is missing from your explanation, and something that I really want to know, is why rulinalg can't use ndarray as it's primary data type and for all of the "simple" operations (dot product, etc). Couldn't Matrix be replaced with ndarray::Array2 ? If there are deficiencies in ndarray, I wonder if they could be fixed with a pull request?
I'm not saying doing this would be easy -- I'm sure it would require a large refactor and would break the API of people using rulinalg (they will at least have to rename all instances of Matrix to Array2 ). Even though it is not easy, it seems like it would be simple -- largely a refactor and adding any minor features to ndarray that are needed. In addition, wouldn't it be worth it to be using a standard well-supported base? You would get BLAS support for free, along with anything else that ndarray got in the future. We could all work towards a common goal and be happier... or at least that is the dream.
5
Continue this thread
SleepyCoder123
•
9y ago
Sorry that I missed this discussion before. It is hard for me to add much to what has been said - there's a lot of fantastic information below (and in this parent comment) which I think conveys the situation well.
I'm keen to work with u/vitiral and others here to try and improve Rust's linear algebra ecosystem. Each library aims to solve a particular problem and it would be awesome if we could make it seamless for user's to switch between these when appropriate.
To answer (loosely) the question of why rulinalg exists, and why it doesn't use ndarray for its underlying data types. I created rulinalg because I wanted to be able to write a machine learning library without dragging in a number of non-rust dependencies (BLAS/LAPACK, etc.). This was a toy project and I thought it would be neat to have something that worked purely with Rust. At the time I didn't care so much about performance and wanted it to be super easy to use (and set up). This is still largely true though performance has been a big focus recently (more on this shortly). I could have built on top of ndarray but at the time things were less stable - from memory ndarray has just depreciated a large chunk of linear algebra code (I'd need to ask u/neutralinostar to confirm). Because of this and the added complexity that is required (and justified) for ndarray to support generic n-dimensional arrays and row/column major storage I decided it would be easiest to write a new library myself.
I also wanted to give a public shoutout to u/Andlon . He has been a champion of rulinalg lately - helping new user's to onboard, giving fantastic code reviews whilst teaching all of us, and putting in some fantastic PRs himself. He is also responsible for an impressive sweep of performance improvements over some complicated linear algebra algorithms - really cool stuff! He has put forward what I believe is a really exciting vision for the library in the future and is working hard to help this be realised. There are some really exciting things in the pipeline and I'm looking forward to seeing these come to life. Thanks u/Andlon!
5
Continue this thread
Andlon
•
9y ago
I forgot to mention another important fact: rulinalg currently doesn't support external BLAS libraries as a backend, which means that the performance is probably very far from optimal at the moment (our decompositions only use BLAS-2 algorithms, which is not ). BLAS integration is definitely on the roadmap though, and lately we've started to converge towards a design that will let us enable opt-in BLAS support.
The lack of BLAS support has been a common criticism of rulinalg. However, it has given us a lot of freedom in experimenting with the implementation and the design of the API.
3 
[deleted]
•
9y ago
If we take ndarray's two dimensional type Array2 with elements of A, it has these fields: Vec<A>, *mut A, usize, usize, isize, isize . In that sense I don't see how it is using much more memory than it should.
The Vec<A> storage can be compressed to just a capacity field maybe in the long run. (The pointer doesn't have to point to the first element in the vec and it is there for full generality).
2
Continue this thread
1 more reply 
[deleted]
•
9y ago
ndarray has the best BLUSS support actually ;-)
Like sebk said to me today, we're all in a big exploration of possibilities. New language, memory safety? Let's see, how do we even build data structures that let us compute efficiently even if it's memory safe?
The last month I've been working to give life to a new abstraction, an “NdProducer” as the basis of lock step function application and parallelization; finding a new data structure where iterators meet their limits. We are still in exploration!
I'm the maintainer of ndarray and I know that users may avoid it because it's complicated or not well documented and implementors because of its flexible memory layouts mean that algorithms need several cases to be fast in the best cases and still handle general layouts. We're working on making it better step by step. I'm very impressed by nalgebra's documentation site, really. I adore the ambition for docs and illustrations.
20
vitiral
OP
• 9y ago
haha, I mixed up the repo name (bluss/rust-ndarray) and BLAS. Fixed :)
Thanks for being the maintainer of such an important library. It seems to me like there is some amount of agreement that rust should use ndarray going forward -- but it's a long way from the kind of unifcation that numpy has for all the scientific libraries of python.
3
Continue this thread 
sebcrozet
•
9y ago
Historically, nalgebra has been created with games in mind but since v0.11 it became much more general-purpose. It still has a focus on features required for physics simulation but its features intend to be close to what can be found on Eigen (except that we don't have expression templates), including some of the Geometry module. I believe that the most distinctive features of nalgebra that cannot be found on the other libraries are:
The support of both dynamically-sized and statically-sized vectors/matrices (including statically-sized rectangular matrices). They all have a common interface.
A handful of types for transformations (rotations, isometries, similarities, etc). (You will find something similar but less complete on cgmath).
A set of traits for generic programming (see alga). Some might find them overly detailed, but nobody is forced to use them because most features of nalgebra are methods that don't require you to import any trait.
A lot of effort is put on the documentation.
Because of its design, nalgebra has two drawbacks that may make it harder to use for newcomers. First, the compile-time errors are not as good as with other libraries because of the use of type-level integers. This will get much better when rust will support integers as type parameters (if it ever does). Second, while the users guide is quite readable ( http://nalgebra.org), the documentation generated by rustdoc is very hard to browse. But I hope this will get better in the future if rustdoc end up being more flexible.
The actual matrix data storage structure depends on how the user parametrizes the Matrix size. For example, it uses (with N the scalar type):
A GenericArray if the matrix size is completely determined at compile-time.
A (Vec<N>, usize) if only its number of columns (or its number of rows) is determined at compile-time.
A (Vec<N>, usize, usize) if its number of rows and columns are unknown at compile-time.
A (N*, usize, usize, usize) if its number of rows, columns, and row-stride, are unknown at compile-time.
Etc.
So basically, we don't store a usize for information that are known at compile-time, including strides. Because of this flexibility requirement, we don't use, e.g., ndarray array as our internal data storage structure.
Regarding LAPACK integration, the crate nalgebra-lapack exists but is very outdated. I am currently working on re-integrating them. Note that with the current design of nalgebra, all LAPACK operators will work on both statically-sized and dynamically-sized matrices.
9
vitiral
OP
• 9y ago
the type-sized matrixes are awesome! I can't help but feel that such a feature would be welcome if it were added to ndarray though. u/neutralinostar what are your opinions on such a feature? It seems like it has clear benefits as it (obviously) reduces the amount of space such structures take up in memory. I also notice that such structures extend to being able to ACCESS matrixes with type level checking (and I assume additional speed) -- awesome!
Edit: I am asking if you would be open to such a feature if someone were to add it, not that you should have added work on your plate.
3
Continue this thread 
[deleted]
•
9y ago
Your docs are awesome.
Regarding alga, I'd like to inject my pragmatism. In my non-abstract world of traits, one of the traits a linear algebra scalar should implement is Debug (and why not Display, LowerExp). We need to println debug and besides that, print and format numbers.
That's intended to give a taste of what I think is a touch of pragmatism.
2
masonium
•
9y ago
Mine isn't up there :-(
I'm developing linxal, a linear algebra library that largely connects ndarray to BLAS / LAPACK in hopefully user-friendly manner. I haven't push out a new version recently, but it is definitely under actively development, and I would love to hear your feedback on it.
My own personal use of it is for implementing and exploring ML algorithms, so it is definitely designed with that in mind.
8
vitiral
OP
• 9y ago
Thanks, I added it. I'll have to check it out!
2 
[deleted]
•
9y ago
There is also cgmath. But that's Computer Graphics specific and only covers 2, 3 and 4 dimensional linear algebra.
7
vitiral
OP
• 9y ago
thanks! I'm definitely more interested in general purpose high dimensional array libraries though.
2
vks_
•
9y ago
There is also algebloat, which is more similar to the C++ template libraries.
5
1 more reply 
xgalaxy
•
9y ago
Holy crap. I'm in love with the nalgebra documentation.
4
mwalczyk
•
9y ago
I agree - that has to be one of the most beautiful doc sites I've seen. Awesome API as well
2
Jatentaki
•
9y ago
There's one aspect that hasn't been mentioned yet - sparse matrices. Is any of the libraries looking to cover that aspect?
3
2 more replies
ekjsm
•
9y ago
Maybe I'm misunderstanding something, so if I am correct me, because I share your confusion.
Having a native Rust BLAS implementation seems important to me in a linear algebra framework for various reasons. Not saying it's easy, but it's a thing that could be done / should be done.
ndarray seems like a great general array library, but as far as I can tell, it just plugs in to a foreign BLAS library for that stuff. linxal seems similar in this regard.
rulinalg seems to be focusing on native implementation of BLAS-type stuff, so it seems to be doing something a little different from what ndarray and linxal is doing.
I suppose you could argue that a native BLAS library would kind of be the missing link between the two.
2
1 more reply
vitiral
OP
• 9y ago
CALLING ALL DATA TYPE LIBRARY MAINTAINERS: I would like your opinion! I have created an issue on are we learning yet to try and hash out a common conversion API that could be supported by all rust libraries and we would like your opinion!
2 
[deleted]
•
9y ago
There are more libraries. Here are a few that deserve mention
https://crates.io/crates/numeric
https://crates.io/crates/parenchyma
https://crates.io/crates/sprs
2
vitiral
OP
• 9y ago
I included them, thanks!
3
TheFarwind
•
9y ago
Thank you for posting this -- I've been deeply confused when trying to figure out which crate to grab for linear algebra, and this helps a lot.
2
Related Answers Section
Related Answers
Best linear algebra crates for Rust
Comparison of nalgebra and faer in Rust
Overview of ndarray-linalg in Rust
Top Rust libraries for web development
Best practices for Rust error handling
New to Reddit?
Create your account and connect with a world of communities.
Continue with Email
Continue With Phone Number
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy.
More posts you may like
What is the state of linear algebra crates in Rust?  r/rust • 4y ago [
What is the state of linear algebra crates in Rust?
](https://www.reddit.com/r/rust/comments/tvcbzz/what_is_the_state_of_linear_algebra_crates_in_rust/) 33 upvotes · 3 comments
Recommendation for Linear Algebra Crate  r/rust • 8y ago [
Recommendation for Linear Algebra Crate
](https://www.reddit.com/r/rust/comments/7f2lq7/recommendation_for_linear_algebra_crate/) 12 upvotes · 5 comments
Whats the best intoductory linear algebra book? r/LinearAlgebra • 6mo ago [
Whats the best intoductory linear algebra book?
](https://www.reddit.com/r/LinearAlgebra/comments/1myus27/whats_the_best_intoductory_linear_algebra_book/) 19 upvotes · 28 comments
Why is linear algebra so important?  r/math • 4mo ago [
Why is linear algebra so important?
](https://www.reddit.com/r/math/comments/1onqy4s/why_is_linear_algebra_so_important/) 16 comments
Linear Algebra is awesome  r/math • 10mo ago [
Linear Algebra is awesome
](https://www.reddit.com/r/math/comments/1k6u1dj/linear_algebra_is_awesome/) 437 upvotes · 81 comments
How important is Linear Algebra?  r/computerscience • 1y ago [
How important is Linear Algebra?
](https://www.reddit.com/r/computerscience/comments/1jtgdi7/how_important_is_linear_algebra/) 93 upvotes · 46 comments
Best Course for Learning Linear Algebra?  r/learnmath • 1y ago [
Best Course for Learning Linear Algebra?
](https://www.reddit.com/r/learnmath/comments/1j1750u/best_course_for_learning_linear_algebra/) 8 upvotes · 4 comments
Linear Algebra in Rust  r/rust • 2y ago [
Linear Algebra in Rust
](https://www.reddit.com/r/rust/comments/1cwf572/linear_algebra_in_rust/) 22 upvotes · 12 comments
Rust crate/tutorial series to learn linear algebra  r/rust • 3mo ago [
Rust crate/tutorial series to learn linear algebra
](https://www.reddit.com/r/rust/comments/1pgoabt/rust_cratetutorial_series_to_learn_linear_algebra/) 26 upvotes · 11 comments
Best Books for Linear Algebra  r/learnmath • 5mo ago [
Best Books for Linear Algebra
](https://www.reddit.com/r/learnmath/comments/1nq8xik/best_books_for_linear_algebra/) 13 upvotes · 18 comments
Linear Algebra is Working with things that even you don't understand  r/mathmemes • 1y ago [
Linear Algebra is Working with things that even you don't understand
](https://www.reddit.com/r/mathmemes/comments/1j3939x/linear_algebra_is_working_with_things_that_even/)  797 upvotes · 65 comments
What is the best way to learn Linear Algebra for dummies  r/learnmath • 7mo ago [
What is the best way to learn Linear Algebra for dummies
](https://www.reddit.com/r/learnmath/comments/1maz7qz/what_is_the_best_way_to_learn_linear_algebra_for/) 15 upvotes · 18 comments
discussion: why is linear algebra interesting and/or important  r/learnmath • 19d ago [
discussion: why is linear algebra interesting and/or important
](https://www.reddit.com/r/learnmath/comments/1qyi2fj/discussion_why_is_linear_algebra_interesting/) 16 upvotes · 42 comments
With what lens do you think linear algebra is best learned?  r/math • 8mo ago [
With what lens do you think linear algebra is best learned?
](https://www.reddit.com/r/math/comments/1lmj6oo/with_what_lens_do_you_think_linear_algebra_is/) 56 upvotes · 37 comments
Starting linear algebra, any resources? r/LinearAlgebra • 1mo ago [
Starting linear algebra, any resources?
](https://www.reddit.com/r/LinearAlgebra/comments/1qbj953/starting_linear_algebra_any_resources/) 22 upvotes · 21 comments
Linear algebra is fun  r/mathmemes • 1y ago [
Linear algebra is fun
](https://www.reddit.com/r/mathmemes/comments/1jmo48m/linear_algebra_is_fun/)  796 upvotes · 30 comments
Which linear algebra library to use?  r/rust • 4y ago [
Which linear algebra library to use?
](https://www.reddit.com/r/rust/comments/wc5jhv/which_linear_algebra_library_to_use/) 21 upvotes · 6 comments
Benchmarking various crates for matrix multiplication  r/rust • 6y ago [
Benchmarking various crates for matrix multiplication
](https://www.reddit.com/r/rust/comments/fmigwt/benchmarking_various_crates_for_matrix/) 9 upvotes
Help me study for my first exam for linear algebra r/LinearAlgebra • 5mo ago [
Help me study for my first exam for linear algebra
](https://www.reddit.com/r/LinearAlgebra/comments/1nri3zu/help_me_study_for_my_first_exam_for_linear_algebra/)  6 upvotes · 14 comments
linear algebra done right not that useful - recommendations?  r/learnmath • 6mo ago [
linear algebra done right not that useful - recommendations?
](https://www.reddit.com/r/learnmath/comments/1mtmb3l/linear_algebra_done_right_not_that_useful/) 7 upvotes · 34 comments
Hi everyone, I am planning to start self-studying Linear Algebra this month, but I'm stuck on which resource to pick. r/LinearAlgebra • 1mo ago [
Hi everyone, I am planning to start self-studying Linear Algebra this month, but I'm stuck on which resource to pick.
](https://www.reddit.com/r/LinearAlgebra/comments/1qklkt4/hi_everyone_i_am_planning_to_start_selfstudying/) 15 upvotes · 27 comments
Fast Linear Algebra library for Rust  r/rust • 5y ago [
Fast Linear Algebra library for Rust
](https://www.reddit.com/r/rust/comments/obghx7/fast_linear_algebra_library_for_rust/) 38 upvotes · 15 comments
faer: efficient linear algebra library for rust - 0.23 release  r/rust • 5mo ago [
faer: efficient linear algebra library for rust - 0.23 release
](https://www.reddit.com/r/rust/comments/1nnrovi/faer_efficient_linear_algebra_library_for_rust/)  codeberg 285 upvotes · 40 comments
introducing faer, a linear algebra library in Rust  r/rust • 3y ago [
introducing faer, a linear algebra library in Rust
](https://www.reddit.com/r/rust/comments/z17l0g/introducing_faer_a_linear_algebra_library_in_rust/)  github 363 upvotes · 39 comments
Recommendation for a book for Linear Algebra r/LinearAlgebra • 4mo ago [
Recommendation for a book for Linear Algebra
](https://www.reddit.com/r/LinearAlgebra/comments/1osk1my/recommendation_for_a_book_for_linear_algebra/) 23 upvotes · 9 comments
Community Info Section
r/rust
Join
The Rust Programming Language
A place for all things related to the Rust programming language—an open-source systems language that emphasizes performance, reliability, and productivity.
Show more
Public
Anyone can view, post, and comment to this community
Top Posts
Reddit reReddit: Top posts of April 6, 2017
Reddit reReddit: Top posts of April 2017
Reddit reReddit: Top posts of 2017
Reddit Rules Privacy Policy User Agreement Your Privacy Choices Accessibility Reddit, Inc. © 2026. All rights reserved.
Expand Navigation
Expand Navigation
Collapse Navigation
Collapse Navigation 
0cAFcWeA5hVI8XcR80wt_lEawWbEKi-RJtPwVPC9fLMYyGOT2L7NtGUubsPg7L8JisSBBT2DdkuS3TQZSn-CX8kZSkcZd-pcn3kRgdgXF6P8vcgpJJEnVq20dHXpl-i1wRkxt0YZeEfoWvCFyMzJArIkJpApHjgw_TGDVDmT5pm9gQ97TqRjlIUpPXHmb8UxIL5L5CBPq7n52CGwN_76SKGNAmEoROgDsBabwMNHK1lBOdOAJjur6YeRaGfyjeC34enX7rtF-RAXPO6ZE-6iS6FHvU8lgqcFd7jBSsJQ9nKmDu4XKL0DJZyO4pKSj4eQL4D4hi5huiym43kQMPY0bS0eCY_4fmA0JqOPDiXq4xVbFvA9kWPbxilVEUUmfvRUZXAKqmXd5ARkMkRtX8qUNlV7OzJEUnj6Tr8KHDpwCeQMtXFRdN1e0__1Zu8fz_H5zHOM9ugK5r6zHuqkL-2ZiWHjRrM0019is9F4tKJuTrgcPFc8YYSyRL4wxIX2PZYUQ2juRPIucqHP4ZA1A6AwJirDBmD5oBsLgQ_mGBlYI4H-cAGEkFZXAvyrAEtKEEahlGHGrmeGa01CfDRM80EK5LkfFk-iRjShAnGAT2dSl8mgxE7mtYBYrGMW1NOhwrnK5uJHpS2KY8I-uSRXzWvLUJzlNrRDsUTEY7gRqhZCe6ZWqdatbsedP_4WHWGw-wdZL_BHfxMuO7w7ifQyx8afkPPSbpWPwPsKzwf4EEZqi0IrSGFWgd_hPOxPvBUHKO7C1Z80DkvccIbw1GGKZ31xAtqkSAV2sLAU7ezXr6TyxLL1UkqgSGMqJ_u1JdeyvMGYraE2_b9OaNTkpqEyM079hS122js6WyxpE0MQGdywcURPntuwvMzv2NDOnEHiSDtT3IXO1bMV7pdD2caKL15xbRChZZP4UU8x0tBDBiaCVduIVHEacsVo2lLX069reMFmVphPIE-dZAuHIS1dg6F4xVBslXHFU9Tie_jVMGu2sT6xWNEomRiI3xzm388dR402-Wg0Xuzs5EC0aUOwhVOrkPKtcUSJzsg3kCJ6tXm9HNtkSUa4b6NXJ83hEIuRWU9eDVJi7te3kYcqOHNrVf2_plH1OU9eoy4vEshrthtw2S6VYLII22zaU2vjpRkq42xpsTvkJo8w_x2Fr0z2jzhH59O71AN_ihFbGjzpX1V6_j5530jsQOPGQFV72L1o9s7oUMw4egFP2x5EiFCuSIfc9Di6OIK-VSKpavdCf2J6dquJSqq55Sb6sUu65F3AeShylKh9hLajMc2tLAeQE-jkW53ejMzc0LgCTUdKm8jVaYKw2gApjJdENsfqGdLBey_Mt5h2ew4RvztNLaYE_pY-i-1ax9WeLL-zZSeBlB37OpHm0vqmsnVwn-JyaufJdkQJTXJQSg5beivKATeOpt8ch39rn8YrOHu9sQ6ItthMIJL-DZYsCodunAlBGlqnhKOX607wVxFKhrxwsDTUJDvU3ELlKda7kKtaHxW65CLFt2z68GnQQ1Hj9PgbPqiXDf5K3zzast9KdokjvueRDdYbYnUa5QiAOBEtkuEoCQhGMNd35C34V5EbdbZm6o-XrPjsgqRYc3N-HClIizi3f0F--XzH2YSZqOD23cQEnCHx_QU57xUvN23EpGB2OgyWD86eMy1BQZwG2KU6Pk5rOmWT3ulDD1f3ONhE3XgEbCnd0GsKzWQD67lPBgwle1RlGEVtyCbaX-nTX51i9jDSAOK10ASGytD44q5zWgt1FMClxD0zu0DnUGISr1c2b32vYbSh0gTt-C_6CEXohgbCpRjUj_4B_u5qV6fTlThY7Sb5MnIoZmL_JPoLR4ygEM_k19qhbh75E47Q6qfhF5VwSY7M3GDx3JwOCAA6XDOJZhBvTNCBLMQlWPJea0iOgvBe_FH9QHB0JZzJLk0dMhSku6_wKn5j7jL-NRv8cCZbm0XteqH34F_7T7qCCcO0S0f_y4MqmX6yC9IGl6DhIg7E7dQfovfmbO6tmziVcFRXkleVnNCsjtj0W7lTXZino6p7DV30X6TaAHlMzqFXs8e9olM0HHs1O0XdPI_be0NxWnXuWeEYakqV9bQwAYb_oGfYu5owKRxF7fWsfzzWY7zu6C4TGqZxupKkNUxPl9rKos3Ot86oCLsd0DrJjHnjctCgyOB3QBnYltgxqjWEt9