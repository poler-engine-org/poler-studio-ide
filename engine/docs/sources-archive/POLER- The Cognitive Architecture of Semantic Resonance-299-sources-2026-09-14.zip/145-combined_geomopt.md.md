Содержимое pyscf/geomopt\n
\n## Файл: init.py\n
\n## Файл: addons.py\n
\n## Файл: ase_solver.py\n
\n## Файл: berny_solver.py\n
\n## Файл: combined_geomopt.md\n
\n## Файл: geometric_solver.py\n
\n## Файл: log.ini\n
\n## Файл: test/test_addons.py\n
\n## Файл: test/test_berny_solver.py\n
\n## Файл: test/test_geometric_solver.py\n
\n## Файл: test/test_pbc_geomopt_ase.py\n