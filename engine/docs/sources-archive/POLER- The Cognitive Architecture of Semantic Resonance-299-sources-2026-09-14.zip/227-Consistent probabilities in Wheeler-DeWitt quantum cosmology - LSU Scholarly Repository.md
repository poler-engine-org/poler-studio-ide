> Source: https://repository.lsu.edu/cgi/viewcontent.cgi?article=6149&context=physics_astronomy_pubs

Louisiana State University 
LSU Scholarly Repository 
Faculty Publications Department of Physics & Astronomy 
12-22-2010 
Consistent probabilities in Wheeler-DeWitt quantum cosmology 
David A. Craig Le Moyne College 
Parampreet Singh Perimeter Institute for Theoretical Physics 
Follow this and additional works at: https://repository.lsu.edu/physics_astronomy_pubs 
Recommended Citation Craig, D., & Singh, P. (2010). Consistent probabilities in Wheeler-DeWitt quantum cosmology. Physical Review D - Particles, Fields, Gravitation and Cosmology, 82 (12) https://doi.org/10.1103/ PhysRevD.82.123526 
This Article is brought to you for free and open access by the Department of Physics & Astronomy at LSU Scholarly Repository. It has been accepted for inclusion in Faculty Publications by an authorized administrator of LSU Scholarly Repository. For more information, please contact ir@lsu.edu. 
Consistent probabilities in Wheeler-DeWitt quantum cosmology 
David A. Craig∗ 
Department of Physics, Le Moyne College Syracuse, New York, 13214, USA 
Parampreet Singh† 
Perimeter Institute for Theoretical Physics Waterloo, Ontario, N2L 2Y5, Canada 
and Department of Physics, Louisiana State University 
Baton Rouge, Louisiana, 70803, USA 
We give an explicit, rigorous framework for calculating quantum probabilities in a model theory of quantum gravity. Specifically, we construct the decoherence functional for the Wheeler-DeWitt quantization of a flat Friedmann-Robertson-Walker cosmology with a free, massless, minimally coupled scalar field, thus providing a complete decoherent histories formulation for this quantum cosmological model. The decoherence functional is applied to study predictions concerning the model’s Dirac (relational) observables; the behavior of semiclassical states and superpositions of such states; and to study the singular behavior of quantum Wheeler-DeWitt universes. Within this framework, rigorous formulæ are given for calculating the corresponding probabilities from the wave function when those probabilities may be consistently defined, thus replacing earlier heuristics for interpreting the wave function of the universe with explicit constructions. It is shown according to a rigorously formulated standard, and in a quantum-mechanically consistent way, that in this quantization these models are generically singular. Independent of the choice of state we show that the probability for these Wheeler-DeWitt quantum universes to ever encounter a singularity is unity. In addition, the relation between histories formulations of quantum theory and relational Dirac observables is clarified. 
PACS numbers: 98.80.Qc,03.65.Yz,04.60.Ds,04.60.Kz 
∗ E-mail: craigda@lemoyne.edu † E-mail: psingh@phys.lsu.edu 
 
 
 
 
 
 
 
 
 
 I. INTRODUCTION 
To extract consistent physical predictions from a quantum theory of gravity describing the whole universe, it is not enough to have a physical Hilbert space, inner product and self-adjoint physical operators. One must also have a coherent framework within which to assign probabilities for the occurrence of events and phenomena. When applied to sub-systems of the universe this problem has a straightforward conventional solution provided by classical observers external to the sub-system who assign and measure these probabilities. The universe as a whole, on the other hand, is a closed quantum system for which there are no external classical observers performing measurements [1–3]. How, then, are quantum probabilities to be extracted from quantum amplitudes? 
An example of the kind of framework required is a generalization of the consistent or decoherent histories formulation of quantum mechanics developed by Griffiths [4, 5], Omnes [6, 7], Gell-Mann and Hartle [1, 2], and others, and adumbrated, particularly in the context of quantum gravity and quantum cosmology, by Hartle [3, 8], Halliwell [9–13], and others [14–16]. The broad outlines of this formalism will be described in section II below, and implemented explicitly and in detail for a simple quantum cosmological model – which may then serve as a guide or template for more complex models – in subsequent sections.1 
The necessity for a predictive framework for closed quantum systems supplementing the usual technical apparatus of quantum theory is particularly evident in situations in which one desires to extract predictions concerning correlations between variables, most particularly correlations extended in time. Examples of interest include predictions concerning approximately semiclassical behavior, or other correlations between the values of variables at different times. 
To be specific, it is well understood that it is not always possible to assign amplitudes to histories of such correlations in a self-consistent manner unless the interference between the alternatives vanishes, as illustrated by the classic example of two-slit quantum interference. Indeed, it is one of the signature characteristics of quantum theory that not every history that can be described can be assigned a meaningful probability. Most, in fact, cannot. For example, no meaningful probabilities can be assigned to the histories which specify which slit the particle passed through before arriving at a position y on the screen unless a mechanism exists to destroy interference between the possible alternative histories {(upper slit,y),(lower slit,y)} such as a measuring device to determine which slit the particle passed through, or coupling to an environment, which carries away – effectively, creates a record of [1, 2, 8, 9, 19] – essentially the same information.2 Only when there is no interference between independent alternative outcomes may probabilities be assigned in a consistent manner3 to each of those alternatives. 
What is needed, then, is an objective measure both of the interference between alternative histories of a system, and, when that interference vanishes, the probability of each such alternative history. 
Such a measure is provided by the decoherence functional, which measures both the interference between histories in a complete set of alternative possibilities, and, when meaningful (because interference between the alternatives vanishes), the probabilities of those histories [1–3, 8]. Specification of the state space, observables, dynamics, and decoherence functional of a system therefore permits internally consistent physical predictions to be made concerning that system independent of any notion of external observers, measuring apparatus, environments, or other ancillary notions that will not be available to a theory which seeks to describe closed systems such as the universe as a whole. 
More generally, because the entire universe is within the domain of the quantum theory of gravity, whatever the final form of this theory it must of necessity have associated with it either a decoherence functional, or some other predictive framework which explains how consistent quantum predictions can be extracted from it. 
Moreover, completely apart from the fundamental quantum question of when quantum probabilities are consistently defined, it has long been understood that the interpretation of the “wave of function of the universe” is itself perhaps not so clear. Indeed, there is a long history of debate in the context of quantum gravity/quantum cosmology of the question, given a “wave function of the universe”, just what should one do with it? (See [20] for one summary and discussions of some specific proposals.) In other words, just how does one extract meaningful physical predictions from a wave function defined on the superspace of gravitational degrees of freedom, especially given the diffeomorphism invariance of the underlying theory? To date, most of the answers to this question have relied upon heuristic arguments, rather than complete, internally consistent frameworks as we seek – on the foundation laid by Hartle – to supply here. 
It is the aim of the present work to supply an example of a complete, explicit realization of a “generalized quantum theory”4 that can address both of these questions in quantum gravity, by constructing a decoherence functional for a simple quantum cosmological model following the lead of [15]. We thereby supply an example of a quantum gravitational model in which predictions extracted from the wave function of the universe are on a firm footing. The 
1 Some of these results have been reported previously in [17, 18]. 2 Indeed, in essence the principal role of measurements by external observers in the traditional Copenhagan approach to prediction in 
quantum theory is to supply physical mechanisms which destroy interference among histories of the measured quantities in the measured subsystem. 
3 In the sense that the appropriate probability sum rules are satisfied. 4 As Hartle terms it.
 model is a Wheeler-DeWitt quantization of a flat, Friedmann-Robertson-Walker universe with a massless, minimally coupled scalar field; a companion work will construct the complete generalized quantum theory for a loop quantization of the same model [21]. Together, these examples provide a template for construction of generalized quantum theories for more complex quantum gravitational models, serving as a guide to strategies for tackling some of the technical and conceptual questions and problems that will arise in any complete predictive quantum theory of gravity. 
The Wheeler-DeWitt quantization of the model we consider is developed in detail in Ref. [22], where an inner product and physical Hilbert space were obtained and expectation values of Dirac observables studied. In the classical theory, the model has two disjoint solutions for a given value of the scalar field momentum. One of these is expanding which leads to a big bang in the past, and the other is contracting with a big crunch under future evolution. In the quantum theory, numerical simulations using states which are semi-classical at late times show that such states remain peaked on classical trajectories and the singularity present in the classical theory is thus not avoided in the quantum theory. With an appropriate choice of lapse, the model can also be solved exactly. One finds that arbitrary states which can be interpreted as describing an expanding universe have zero expectation value of the volume observable in the past [23]. Similarly, arbitrary states describing contracting universes lead to zero volume in the future. Though these studies reveal much about the quantization of the model and the resulting physical behavior, including the persistence of the classical singularity for generic expanding or contracting quantum states, important questions concerning quantum histories and their probabilities have so far remained unaddressed. Here we answer some of these questions. In particular, we construct a decoherence functional for the model universe and demonstrate how the prior results may be understood and refined within a consistent framework for quantum prediction. By way of example we address the question of whether this Wheeler-DeWitt quantized universe is ever singular. We show that the probability the quantum universe is singular is unity for arbitrary states in the physical Hilbert space. Of some special interest is the case where the quantum state is a superposition of contracting and expanding universes. Such a state might be regarded as an analog of a “Schrödinger’s cat” state in ordinary quantum mechanics – a quantum superposition of macroscopically distinct states. A careful consistent histories analysis reveals that even for such states the probability the universe avoids the singularity is zero, and a naive expectation that such a state may avoid the classical singularity turns out to be incorrect. 
The outline of the paper is as follows. Section II describes the overall framework of generalized quantum theory. In section III we give details of the cosmological model and its (canonical) quantization, including a discussion of the model’s observables. Section IV details the construction of the decoherence functional, including construction of class operators (histories) and the corresponding branch wave functions, and discusses the relationship between histories-based theories and relational observables. Section V runs through a selection of physical applications: volume (section V A); momentum of the scalar field (section V B); the behavior of semiclassical states (section V C); and finally, we give in section V D a detailed discussion of the behavior of these universes near the classical singularity. In particular, we show rigorously that in this quantization the universe is singular for all states – quantum mechanics does not resolve the classical singularity.5 Section VI closes with some discussion of conceptual and practical issues. 
II. GENERALIZED “CONSISTENT HISTORIES” QUANTUM THEORY 
As originally conceived by Hartle [8], “generalized quantum theory” is a distillation of the main ideas of the consistent histories program for quantum mechanics [1, 2] to its essential conceptual elements. The principal virtue of this abstraction is that it isolates those elements in a manner suitable for generalization to theories beyond the original domain of the program, non-relativistic particle mechanics. Thus the same fundamental structure may be applied equally well to particle mechanics as to relativistic field theories or a quantum theory of gravity, and implemented as naturally in a functional integral framework as in an operator quantization. 
The essential elements of any generalized quantum theory are: 
1. Fine-Grained Histories: The most refined descriptions of the universe it is possible to give. This might be the set of paths in a functional integral formulation, or the set of time-ordered products of one-dimensional Heisenberg projections onto physical observables in a Hilbert space quantization. 
2. Coarse-Grained Histories: Specification of the physically meaningful partitions of the set of fine-grained histories. In a covariant quantization of gravitation, for example, only diffeomorphism invariant classes would be expected to be intelligible. Coarse-grained sets of histories are called “coarse-grained histories”. Such histories correspond to the physically meaningful questions that may be asked of a system – “Which slit did the particle pass 
5 This result stands in stark contrast to the case of the loop quantization of the same model to be described in [21], in which the classical singularity is resolved for generic states.
 through?” Note that most – if not all – physical questions are of this highly coarse-grained character, not inquiring, in this example, into other details of the particle’s position. As such, it is the coarse-grained histories for which quantum mechanics must be able to determine whether probabilities are meaningful, and if so, what those probabilities are. 
3. Decoherence Functional: The decoherence functional both measures the quantum mechanical interference be-tween members of a set of alternative coarse-grained histories, and, when that interference vanishes, determines the probabilities of each member of that set. The decoherence functional is a natural generalization to closed quantum systems of the algebraic notion of quantum state [24, 25], and incorporates the system’s boundary conditions. Sets of histories with negligible interference between all pairs of members, as measured by the deco-herence functional, are said to decohere, or to be consistent.6 It is logically consistent to assign probabilities in an exhaustive set of alternative histories when, and only when, that set is decoherent according to the system’s decoherence functional. It is the criterion of consistency, rather than, for example, any notion of “measurement”, which determines the physically meaningful predictions of the theory. 
Quantum theory in Hilbert space 
For purposes of motivation and later comparison, we describe the formulation of ordinary Hilbert space quantum mechanics in the language of generalized quantum theory. 
1. Histories, class operators, and branch wave functions 
Consider a quantum theory for a system S on a Hilbert spaceH with Hamiltonian H and a family of observables Aα, labelled by the index α, with eigenvalues aαk (assumed discrete for notational convenience only.) Ranges of eigenvalues will be denoted ∆aαk . Projections onto the corresponding eigensubspaces will be written Pαak and Pα∆ak , where we have suppressed the superscript labelling the eigenvalues in order to minimize the notational clutter. 
For a given choice of observable Aαi at each time ti, an exclusive, exhaustive set of fine-grained histories for S may be regarded as the set of sequences of eigenvalues {h} = {(aα1 
k1 , aα2 
k2 , . . . , aαnkn )}, where each ki runs over the full range 
of the eigenvalues aαiki , corresponding to the family of histories in which observable Aαi has value aαiki at time ti. A 
different choice of observables (α1, α2, . . . , αn) leads to a different exclusive, exhaustive family of histories {h}. From the propagator 
U(ti, tj) = e−iH(ti−tj)/~ 
≡ U(ti − tj) (2.1) 
are constructed the Heisenberg projections 
Pαak(t) = U†(t)PαakU(t). (2.2) 
The fine-grained history h may then be conveniently represented by the operator (often called the “class operator”7 
for the history h) 
Ch = Pα1 ak1 
(t1)Pα2 ak2 
(t2) · · ·Pαnakn (tn) (2.3a) 
= U(t0 − t1)Pα1 ak1 
U(t1 − t2)Pα2 ak2 · · ·U(tn−1 − tn)PαnaknU(tn − t0) (2.3b) 
in the sense that the “branch wave function” 
|ψh〉 ≡ C†h|ψ〉 (2.4a) 
= U(t0 − tn)PαnaknU(tn − tn−1) · · ·U(t2 − t1)Pα1 ak1 
U(t1 − t0)|ψ〉 (2.4b) 
6 We use these terms interchangeably, being aware that some authors make more refined distinctions that will not be important here. Additionally, the notion of decoherence being applied here is closely related to, but ultimately distinct from, the idea of environmental decoherence [26, 27]. Indeed, from our point of view environmental decoherence may be regarded as a particular physical mechanism which leads to the decoherence (in the present sense) of the corresponding coarse-grained histories. 
7 Note that the time ordering employed here is opposite to the original definition of [1, 2] and that often found elsewhere in the literature. This choice, however, is more convenient in many formulæ, particularly in the definition of the decoherence functional.
 constructed from the initial state |ψ〉 is the (un-normalized) quantum state for a system which has followed this particular history.8 The projections implement, in the standard Copenhagen/von Neumann way of thinking, “wave function collapse”. From the present point of view, however, it is more natural to regard |ψ〉 as “the state” of the system, and the branch wave function merely as a tool from which one may ultimately construct the probabilities of individual histories. 
Note that since ∑ k P 
α ak 
= 1 for each observable α,∑ h 
Ch = ∑ k1 
∑ k2 
· · · ∑ kn 
Pα1 ak1 
(t1)Pα2 ak2 
(t2) · · ·Pαnakn (tn) (2.5a) 
= 1, (2.5b) 
corresponding to the fact that the set of fine-grained histories {h} represents a mutually exclusive, collectively ex-haustive description of the possible fine-grained histories of S. Accordingly,∑ 
h 
|ψh〉 = ∑ h 
C†h|ψ〉 (2.6a) 
= |ψ〉. (2.6b) 
Coarse-grained histories correspond to coarse-grainings of the projections at some or all of the times ti: 
Ch = ∑ 
ak1 ∈∆ak̄1 
∑ ak2 ∈∆ak̄2 
· · · ∑ 
akn∈∆ak̄n 
Pα1 ak1 
(t1)Pα2 ak2 
(t2) · · ·Pαnakn (tn), (2.7) 
where the bar denotes a coarse-graining including the more finely-grained history h. (It is not intended as a general signifier that h is coarse-grained. There is no special notation for that, since most histories of physical interest will be coarse-grained.) In general, these operators will not be simple products of projections as in (2.3), though they can be in simple cases; coarse-grained histories for which they are, are called “homogeneous”. Branch wave functions for coarse-grained histories are defined as in Eq. (2.4), and are obviously simply sums (superpositions) of the more finely-grained branch wave functions. 
2. The decoherence functional 
For a pure initial state |ψ〉, the decoherence functional of standard quantum theory is defined as9 
d(h, h′) = 〈ψh′ |ψh〉. (2.8) 
Note that from Eq. (2.6), the decoherence functional is normalized:∑ h,h′ 
d(h, h′) = 〈ψ |ψ〉 (2.9a) 
= 1. (2.9b) 
When interference between all the members of an exclusive, exhaustive set of coarse-grained histories {h} vanishes, 
d(h, h′) = 0, h 6= h′, (2.10) 
that set of histories is said to decohere, or be consistent.10 In such sets, the probabilities of the individual histories are then simply the diagonal elements of the decoherence functional, 
p(h) = d(h, h). (2.11) 
8 One must be slightly careful with this interpretation. Because of the leading factor of U in Eq. (2.4b), |ψh〉 as defined here is actually the initial state that under normal Schrödinger evolution (no collapses) from t0 to any t > tn will evolve into the state that has “followed” this particular history up to tn. See Section II 3 for an alternative normalization. 
9 For mixed initial states ρ, the definition is d(h, h′) = tr[h†ρh′]. In this form it is especially clear that the decoherence functional is a natural generalization of the notion of “quantum state” as it is employed in algebraic formulations of quantum mechanics [25]. Further generalizations are of course possible, resulting in a “generalized quantum theory” [3, 8], but the choice given here corresponds to quantum mechanics as it is usually done. 
10 Other criteria for decoherence are possible [19]. The condition (2.10), sometimes called “medium decoherence”, is the simplest, and, it appears, most broadly applicable [28].
 It is easily verified that this is simply the standard Lüders-von Neumann formula for probabilities of sequences of outcomes in ordinary quantum theory, when such probabilities may be defined – typically in measurement situations. In the framework of generalized (decoherent histories) quantum theory, however, no external notion of observers or measurement is required. It is the criterion (2.10) that determines when probabilities may be defined, and which ensures they are meaningful in the sense that probability sum rules are obeyed when histories are coarse-grained: 
p(h1 + h2) = p(h1) + p(h2) (2.12) 
in decoherent sets. Consistent sets are thus characterized by a diagonal decoherence functional, 
d(h, h′) = p(h) δh′h. (2.13) 
From Eqs. (2.9) and (2.10) it is clear that ∑ h p(h) = p(1) = 1 in decoherent sets of histories, as clearly must be the 
case. In quantizing simple cosmological models it will turn out to be possible, following the lead of [3, 8, 15], to pattern 
the construction of their generalized quantum theories in close analogy with that of ordinary particle mechanics, and many of the above formulæ – suitably re-interpreted – will be taken over wholesale. 
3. Comment: histories and branch wave functions 
A few comments concerning the definitions of class operators and branch wave functions are in order. First, fine-grained histories are sometimes defined without the trailing factor of U(tn− t0) in Eq. (2.3b), leading to 
the possibly more appealing expression for the branch wave function( alternate definition 
) |ψh〉 = PαnaknU(tn − tn−1) · · ·U(t2 − t1)Pα1 
ak1 U(t1 − t0)|ψ〉. (2.14) 
In this form, the branch wave function is precisely the quantum state of a system at the moment t = tn that has followed the history h up to that time. (See footnote 8.) On the other hand, with this choice, fine-grained histories are no longer simply products of Heisenberg projections, and no longer sum to unity. Rather,( 
alternate definition 
) ∑ h 
Ch = U(tn − t0). (2.15) 
Indeed, this normalization for class operators is rather more natural in functional integral formulations of quantum theory. Both conventions appear in the literature. Both definitions for fine-grained class operators, though, lead to the same decoherence functional, Eq. (2.8), since they differ only by an overall unitary factor. 
Second, it should be clearly understood that, as the definitions of branch wave functions and class operators so far stand, branch wave functions are not functions of t, and are not solutions of the Schrödinger equation. Indeed, one would not expect that they could be, since in the usual picture they represent the state that results from the initial state |ψ〉 under unitary evolution punctuated by discontinuous “collapses” onto the Pαiaki 
. 
In order to construct from the branch wave functions defined in Eq. (2.4) a truly spacetime wave function, we can define (returning to our original definitions, Eqs. (2.3)-(2.4)) 
Ch(t) = Ch U †(t− t0), (2.16) 
so that 
|ψh(t)〉 = C†h(t)|ψ〉 (2.17a) 
= U(t− t0)|ψh〉 (2.17b) 
= U(t− tn)PαnaknU(tn − tn−1) · · ·U(t2 − t1)Pα1 ak1 
U(t1 − t0)|ψ〉. (2.17c) 
|ψh(t)〉, so defined, is a solution of the Schrödinger equation for all t, even for t < tn. And this choice again clearly leaves the definition of the decoherence functional unchanged. With this definition, however,∑ 
h 
Ch(t) = U(t− t0) (2.18) 
rather than the identity, so that ∑ h 
|ψh(t)〉 = |ψ(t)〉. (2.19)
 Nonetheless, care must be taken. |ψh(t)〉 for t < tn is not in general the same as |ψ〉 evolved according to the Schrödinger equation punctuated by discontinuous “collapses” (projections) at the times ti until after the last projection under consideration, t > tn. As an extreme example, it will not normally be the case that |ψh(t0)〉 = |ψ〉. Rather, |ψh(t0)〉 = |ψh〉, while |ψh(tn)〉 is in fact the state given in Eq. (2.14) of a system at t = tn that has “followed” the history h up to that time, and |ψh(t)〉 the Schrödinger evolute of that state thereafter. (See footnote 8.) 
Henceforth, |ψh〉 will wherever appropriate refer to |ψh(t)〉 unless otherwise noted. 
III. FLAT SCALAR FRW AND ITS WHEELER-DEWITT QUANTIZATION 
In order to implement the decoherent histories program in quantum gravity we must have models over which there is essentially complete theoretical control: the physical Hilbert space, including especially the inner product; dynamics, including the propagator; observables and their spectral decompositions; and boundary conditions. Few such models are available. In this work we study the Wheeler-DeWitt quantization of a homogeneous and isotropic universe with a massless, minimally coupled scalar field. The quantization of this model has been recently developed in the context of loop quantum cosmology [22, 23]. In the following we revisit this Wheeler-DeWitt quantization using (except as indicated) the conventions introduced in these papers, to which we refer the reader for more details and a comparison to loop quantum cosmology. It should be emphasized that even though the model we consider is simple, it is rich enough to demonstrate some non-trivial aspects of the quantization of a gravitational theory; the consistent histories formalism; and the manner in which a probabilistic meaning can be given to the occurrence of a singularity in the Wheeler-DeWitt theory. It should also serve as a valuable guide for the consistent histories formulation of more complex models when the requisite theoretical control is achieved. 
A. Classical homogeneous and isotropic models 
The metric for homogeneous and isotropic Friedmann-Robertson-Walker (FRW) cosmologies may be decomposed as 
gab = −nanb + hab (3.1a) 
= −N2dtadtb + a2(t)q̊ab, (3.1b) 
where t is a global time, na = −N dta (so na is future-directed) with lapse N , and q̊ab is a fixed (Ltq̊ab = 0) fiducial metric on the spatial slices Σ – flat, in the case of k = 0 FRW spacetime which we consider below – and a(t) is the scale factor. If 3e is the volume element associated with q̊ab, the physical volume element (i.e. that associated with gab) is 
√ −g e = 
√ −g dt ∧ 3e = Na3 dt ∧ 3e. (3.2) 
The spatial 3-manifold Σ may be topologically IR3, or closed (such as a torus.) If Σ is topologically open, we 
introduce a fixed fiducial cell V to define the symplectic framework. The cell V has volume V̊ relative to q̊ab,∫ V 
3e = V̊ , (3.3) 
and all integrations are restricted to V. The choice of the topology of Σ plays little role in our analysis and without any loss of generality we assume it to be IR3 and take V to have unit volume V̊ . Note that the necessity to introduce the fiducial cell V does not arise if we consider a closed (k = +1) universe, in which case V̊ is simply the volume of Σ with respect to q̊ab. 
The gravitational part of the action Sgrav = ∫ LG/16πG can be computed from the Lagrangian density11 
LG = √ hN [KabK 
ab −K2 + 3R], (3.4) 
where Kab = 1 2Lnhab = ḣab/2N = (ȧ/aN)hab and 3R = 6k/a2. For the flat (k = 0) universe, the gravitational action 
becomes 
Sgrav = 3 
8πG 
∫ dt(−aȧ2), (3.5) 
11 This expression for LG, while giving the correct equations of motion and Hamiltonian for these models, leaves out boundary terms which either integrate to zero or are cancelled by the Gibbons-Hawking term in the full gravitational action. See [29, section E.2.28] and subsequent discussion.
 where we have carried out the integration over the unit volume of the fiducial cell, and chosen the lapse N to be equal to unity. The gravitational phase space variables are the scale factor a and its conjugate 
pa = − 3 
4πG aȧ, (3.6) 
for which 
{a, pa} = 1 . (3.7) 
The Hamiltonian Hgrav can then be obtained by a Legendre transformation. The total Hamiltonian can be written as 
H = −2πG 
3 
p2 a 
a +Hmatt, (3.8) 
where Hmatt is the matter Hamiltonian. We take the matter to be a massless, minimally coupled scalar field φ with action 
Smatt = 
∫ dt a3 φ̇ 
2 
2 (3.9) 
and Hamiltonian 
Hmatt = p2 φ 
2a3 , (3.10) 
where pφ denotes the momentum of the scalar field. The matter phase space variables φ and pφ satisfy {φ, pφ} = 1, 
and it is easy to see using Hamilton’s equations that pφ = a3 φ̇. Physical trajectories are solutions to the Hamiltonian constraint 
− a2 p2 a + 
3 
4πG p2 φ ≈ 0. (3.11) 
Here, however, we will work with a different set of gravitational phase space variables introduced in loop quantum cosmology [23] and related to the set (a, pa) by a canonical transformation. These are the volume of the universe εV = εa3 and its canonical conjugate 
β = −ε4πG 
3 
pa a2 , (3.12) 
which satisfy12 
{εV, β} = −4πG. (3.13) 
Solving the classical Hamiltonian constraint H ≈ 0, 
− β2V 2 + 4πG 
3 p2 φ ≈ 0, (3.14) 
one finds that β2 measures the energy density ρ = p2 φ/2V 
2 of the universe on classical solutions. Thus, εV and β 
are convenient phase space variables which capture the volume of the universe and its spacetime curvature.13 The complete phase space of the model is labelled by (εV, β, φ, pφ). 
The dynamical trajectories are obtained by solving Hamilton’s equations, which show that pφ is a constant of the motion, and 
φ = ± 1√ 12πG 
ln 
∣∣∣∣ VVo ∣∣∣∣+ φo, (3.15) 
where Vo and φo are constants of integration. Regarding the scalar field φ as an emergent “clock”, the classical trajectories correspond to disjoint expanding (+) and contracting (−) branches. There exists a past singularity (the big bang) in the expanding branch as φ → −∞. Similarly, the contracting branch faces a big crunch singularity as φ→∞. (See Fig. 1.) It is to be noted that all classical solutions of this model are singular. 
12 In comparison to the analysis in Ref. [23], we have put the Barbero-Immirzi parameter γ of loop quantum gravity equal to unity. In these equations ε = ±1 is an orientation factor that determines the orientation relative to a fiducial triad in terms of which q̊ab is expressed. It will play little obvious role in the analysis of the Wheeler-DeWitt theory, as will be described below, but its presence is necessary for the consistency of the quantization. 
13 Due to the constant equation of state of the scalar matter it is straightforward to see that energy density, and hence the Hubble rate β, is sufficient to completely capture the spacetime curvature.
 -0.5 
-0.4 
-0.3 
-0.2 
-0.1 
 0 
 0.1 
 0.2 
 0.3 
 0.4 
 0.5 
 0  10000  20000  30000  40000 
V 
φ 
FIG. 1. Classical trajectories (Eq. (3.15)) for a massless scalar field in a flat isotropic universe are shown for positive volume (ε = +1). The solid (red) curve corresponds to the expanding branch and the dashed (blue) curve to the contracting branch. The branches are disjoint, and singular in the past and future respectively. 
B. Wheeler-DeWitt quantization 
The canonical quantization of the classical model proceeds by promoting the classical phase variables and Poisson brackets to operators and commutators. The commutator between gravitational phase variables can be written as 
[εV̂ , β̂] = −4πG i~. (3.16) 
For convenience, following Ref. [22] we employ the dimensionless volume ν given by 
ν := ε V 
C l3p . (3.17) 
Here C is a dimensionless constant.14 In the ν, φ representation the action of ν̂ and φ̂ is multiplicative in the 
kinematical Hilbert space Hkin = L2(IR2, dνdφ), whereas β̂ and p̂φ act as differential operators: 
β̂ = 4π 
Clp i ∂ 
∂ν and p̂φ = −i~ ∂ 
∂φ . (3.18) 
14 In loop quantum cosmology its value is (4π/3)(3/2)/K, where K = 2 √ 
2/3 √ 
3 √ 
3 [22], but insofar as this paper is concerned the value 
of C is immaterial. Note we take lp = √ G~.
 
With this action, quantization of the classical constraint Eq. (3.14) results in the Wheeler-DeWitt equation (in the volume representation): 
∂2 φ Ψ(ν, φ) = 12πGν∂ν (ν∂ν Ψ(ν, φ)) =: −Θ(ν) Ψ(ν, φ) . (3.19) 
The choice of factor ordering corresponds to the Laplace-Beltrami operator of the DeWitt metric on the two dimen-sional configuration space (ν, φ) [22]. This will be the most appropriate choice for comparison with the case of loop quantum cosmology [22, 23]. 
The Wheeler-DeWitt equation thus takes the form of a Klein-Gordon equation in a static spacetime. The scalar field φ corresponds to the “time” and the operator Θ corresponds to the spatial Laplacian. Though the presence of such a notion of emergent “time” helps in the interpretation of various physical results, it should be emphasized that it is in no way vital to the analysis – though it will play a role in the quantum observables we choose to study in the sequel. Further, given the simple form of the Wheeler-DeWitt equation for this model one may also regard ν as a “clock” with respect to which one can measure the evolution of matter degrees of freedom and the spacetime curvature. 
It is important to note that because of the factor of ε in its definition, the volume variable ν ranges over the entire real line, −∞ < ν < ∞. However, as discussed in [22, 23, 30], since the action for the Wheeler-DeWitt model is invariant under a change of orientation ε→ −ε, physical states Ψ(ν, φ) may be taken to be symmetric in ν. It suffices, therefore, to restrict attention strictly to ν ≥ 0, and we will do so everywhere in the sequel. 
The operator Θ is positive definite and self-adjoint on (the symmetric sector of) L2(IR, ν−1dν) [22], with eigenfunc-tions in the volume representation 
ek(ν) = 1√ 2π eik ln |ν| (3.20) 
satisfying 
Θ(ν) ek(ν) = ω2 ek(ν) . (3.21) 
Here k is a real number for which ω = √ 
12πG|k|. These eigenfunctions form an orthonormal basis,15∫ ∞ 0 
dν 
ν ēk′(ν) ek(ν) = δ(k − k′) . (3.22) 
Any symmetric solution to the Wheeler-DeWitt equation Eq. (3.19) can be expanded in terms of the ek(ν) and expressed in terms of positive and negative frequency parts which satisfy the first order version of the quantum constraint Eq. (3.19): 
∓ i∂φ Ψ(ν, φ) = √ 
Θ Ψ(ν, φ) . (3.23) 
The positive and negative frequency sectors are disjoint (see below), resulting in two identical copies of the solution space. Restricting to the positive frequency sector, dynamical evolution is given by propagation with the negative root of Eq. (3.23): 
U(φ− φ0) = ei √ 
Θ(φ−φ0) . (3.24) 
Positive frequency solutions of Eq. (3.23) can be further written as a combination of “left-moving” (contracting) and “right-moving” (expanding) components in a plot of φ vs. ν. Evolution with Eq. (3.24) then leads to 
Ψ(ν, φ) = 1√ 2π 
∫ ∞ −∞ 
dk ψ(k) eikln ν eiω(φ−φ0) (3.25a) 
= 1√ 2π 
∫ 0 
−∞ dk ψ(k) eik(ln ν− 
√ 12πG(φ−φ0)) + 
1√ 2π 
∫ ∞ 0 
dk ψ(k) eik(ln ν+ √ 
12πG(φ−φ0)) 
(3.25b) 
= ΨR(ν−) + ΨL(ν+) , (3.25c) 
15 The normalization chosen here is appropriate to the choice to restrict attention to ν ≥ 0.
 
where ν± = ln ν ± √ 
12πG(φ− φ0). In order to determine the physical Hilbert space we first consider a set of Dirac observables – self-adjoint operators 
which commute with the constraint [31–33]. One of them is the invariant of the model, the momentum pφ of the scalar field which commutes with the Hamiltonian. Another observable which commutes with the Hamiltonian can be constructed by noting that φ plays the role of “time” in the model in the sense that it can be used to label the flow of the evolution operator. If we then consider a variable such as volume (ν) or energy density (ρ), its value at a fixed value of φ = φo is an invariant. Thus, even though ν does not commute with the Hamiltonian, the observable ν|φ is a Dirac observable.16 In general we can consider a local operator Â that does not (necessarily) commute with the constraint. The corresponding relational observable 
Â|φo |Ψ(φ)〉 = U(φ− φo)Â|Ψ(φo)〉 (3.26a) 
= U(φo − φ)†ÂU(φo − φ)|Ψ(φ)〉, (3.26b) 
giving the value of Â at φ = φo, will then be a Dirac observable. From Eq. (3.26), note that 
Â|φo = U(φo − φ)†ÂU(φo − φ), (3.27) 
so that Â|φo may be thought of as a “time-reversed” Heisenberg-picture observable. Note its action does depend on 
the minisuperspace slice φ on which it acts, so that when we are being careful we should write Â|φ∗(φ). The action of the Dirac observables preserves the positive and negative frequency subspaces and as noted it therefore 
suffices to consider only one of them to extract physical predictions. For the space of symmetric positive frequency solutions this action is given by 
ν̂|φo Ψ(ν, φ) = U(φ− φo) |ν̂|Ψ(ν, φo) (3.28) 
and 
p̂φ Ψ(ν, φ) = ~ √ 
Θ Ψ(ν, φ) . (3.29) 
In order to obtain the inner product we use the group averaging procedure [34, 35]. Here one finds a rigging map η : Ω → Ω∗ where Ω is a dense subspace of the (symmetric sector of the) auxiliary Hilbert space L2(IR2, ν−1dν dφ). The states (Ψ| ∈ Ω∗ are defined by considering the following action of the self-adjoint quantum constraint operator 
Ĥ: 
(Ψ| = ∫ dζ〈e−iζĤΨ′| (3.30) 
for |Ψ′〉 ∈ Ω. The inner product then results from the action (Ψ|Ψ′〉. It takes on the Schrödinger-like form [22] 
〈Φ |Ψ〉 = 
∫ φ=φo 
dν 
ν Φ̄(ν, φ) Ψ(ν, φ) (3.31) 
in the (ν, φ) representation,17 and under it the action of the Dirac observables is self-adjoint. (Here and henceforth all ν integrations will be taken over the range 0 ≤ ν < ∞ unless otherwise specified. Since the states are symmetric in ν, the only differences this choice induces are absolute value signs on the factor of ν in the measure, and 
√ 2’s in 
normalization.) In this inner product the left- and right-moving subspaces (respectively, contracting and expanding in the volume 
representation) are orthogonal, and matrix elements between them of any operator which leaves these subspaces invariant will be zero. 
Equipped with the essential apparatus of the quantum theory we may now proceed to define projection operators for the volume observable in the physical Hilbert space. First note that the eigenfunctions of Θ(ν) satisfy the identity∫ ∞ 
−∞ dk ēk(ν′) ek(ν) = δ(ln ν − ln ν′) . (3.32) 
16 These observables can be defined in a similar way if one chooses volume to be the “clock”. For example one could measure the value of φ at a given ν: φ|ν . 
17 The form of the inner product depends on the choice of representation. In terms of the curvature variable y = ln(β/βo)/ √ 
12πG, for example – restricting to β ≥ 0 for the same reason we restrict to ν ≥ 0 – the inner product takes on the Klein-Gordon form 
〈Φ |Ψ〉 = −i ∫ φ=φo 
dy Φ̄ ↔ ∂ φ Ψ [23].
 
Using the resolution of the identity in k ∫ ∞ −∞ 
dk|k〉〈k| = 1, (3.33) 
we can rewrite Eq.(3.32) in bra-ket notation (with ek(ν) = 〈ν |k〉) as 
〈ν|ν′〉 = δ(ln ν − ln ν′) . (3.34) 
The resolution of the identity for volume can then be written as18 
∫ ∞ 0 
dν 
ν |ν〉〈ν| = 1 . (3.35) 
We can now define the projector for the volume in the range ∆ν. This is obtained from Eq. (3.35) by restricting the integration to ∆ν: 
P∆ν = 
∫ ∆ν 
dν 
ν |ν〉〈ν| = 
∫ ∆ν 
dPν , (3.36) 
where dPν is an infinitesimal projector. In the next section we will see that given this projector one can consistently define class operators for the histories in which volume lies in the range ∆ν, leading to a natural consistent probability interpretation for the volume observable in agreement with the one obtained from the action of the corresponding Dirac observable. 
C. Semiclassical States 
Of particular interest will be quantum states which are semiclassical in the sense of being peaked on classical trajectories, Eq. (3.15). An example is the state 
Ψsc(ν, φ) = 1√ 2π 
1√√ πσ 
∫ ∞ −∞ 
dk e−(k−k̄)2/2σ2 
eik ln νeiω(φ−φ̄∓), (3.37) 
where ω = √ 
12πG|k| and φ̄± = ± ln ν̄/ √ 
12πG + φo, with the top sign for expanding/right-moving (k̄ < 0) and the 
bottom for contracting/left-moving (k̄ > 0) solutions. If ν̄  1 (equivalently, V̄  l3p) and p̄φ = √ 
12πG~|k̄|  ~ at φ = φo, this state remains peaked on the classical solution specified by νo = ν̄ at φ = φo throughout its evolution [23, 36]. For the flat FRW model with a massless scalar field this amounts to specifying semi-classical initial conditions at small spacetime curvatures in a large universe. 
Indeed, for this state it is straightforward to verify that while 
σln ν = 
√ 〈(ln ν)2〉 − 〈ln ν〉2 (3.38a) 
= 1√ 2σ , (3.38b) 
the value of σν = 
√ 〈ν2〉 − 〈ν〉2 grows exponentially away from the singularity on both branches: 
σ2 ν = e±2(φ−φ̄±)e 
1 2σ2 (e 
1 2σ2 − 1). (3.39) 
(See Sec. V A 1 for discussion of how these expectation values are calculated.) 
18 Note that the factor ν in the denominator is required by consistency with our normalization of the states and the inner product. With a different choice of normalization of states it is possible to rewrite the identity in a form in which ν does not appear in the denominator.
 
IV. THE DECOHERENCE FUNCTIONAL 
In this section, we describe the elements necessary to construct the decoherence functional for the model described in section III. In Ref. [15], a decoherence functional was constructed for a path integral quantization of (closed) type A minisuperspace models. Our definitions will largely follow the framework established in that work, with modifications appropriate to an open universe and canonical quantization. 
We describe in sequence the required elements: the class operators which describe physical histories (Section IV A); the corresponding branch wave functions, the amplitudes for each such history for a given state (Section IV B); and finally, the decoherence functional which measures the interference among the branch wave functions, and, when that interference vanishes, their probabilities (Section IV C). We will see that, with suitable adaptions of the basic definitions, the construction closely resembles that of ordinary non-relativistic particle mechanics. 
A. Class Operators 
Class operators describe potential physical histories – most generally, coarse-grained histories such as defined in Eq. (2.7). Homogeneous class operators describe possible sequences of (ranges of) values of observable quantities, with sums of them corresponding to coarse-grainings thereof. We will often refer to class operators simply as “histories”. 
Class operators correspond to the physical questions that may be asked of a given system. For the model under consideration these include “What is the physical volume of the fiducial cell when the scalar field has value φ∗?” “Does the volume of the cell ever drop below a particular value, let us say ν∗?” “Is the momentum of the scalar field conserved during evolution?” – and so forth. All such questions come in exclusive, exhaustive sets – at the most coarse-grained level, simply “Does the universe have property P, or not?” The sum of all the class operators in such an exclusive, exhaustive set must therefore be, in effect, the identity – as expressed in Eq. (2.5) – up to a possible overall unitary factor (see Section II 3). 
In non-relativistic quantum theory fine-grained class operators are given by Eq. (2.3). In quantum cosmology they may be constructed similarly for many questions of physical interest. 
In the model at hand, we have states |Ψ〉 with a unitary evolution in φ given by Eq. (3.24). Physical quantities of interest will include the values of volume and scalar momentum at given values of φ. To extract physical predictions concerning quantities of this kind, let us proceed as in ordinary quantum theory and define “Heisenberg projections” 
Pα∆aαk (φ) = U†(φ− φ0)Pα∆aαk 
U(φ− φ0), (4.1) 
where Pα∆aαk is the projection onto the range of eigenvalues ∆aαk of the operator Aα and φ0 is a fiducial value of the 
scalar field at which the quantum state is defined.19 The coarse-grained history 
h = (∆aα1 
k1 ,∆aα2 
k2 , . . . ,∆aαnkn ) (4.2) 
in which the variable α1 takes values in ∆aα1 
k1 at φ = φ1, variable α2 takes values in ∆aα2 
k2 at φ = φ2, and so on, then 
has the class operator 
Ch = Pα1 
∆ak1 (φ1)Pα2 
∆ak2 (φ2) · · ·Pαn∆akn 
(φn) (4.3a) 
= U(φ0 − φ1)Pα1 
∆ak1 U(φ1 − φ2)Pα2 
∆ak2 · · ·U(φn−1 − φn)Pαn∆akn 
U(φn − φ0), (4.3b) 
where again we suppress the superscripts on the eigenvalue ranges to minimize the clutter. They are normalized according to ∑ 
h 
Ch = ∑ k1 
∑ k2 
· · · ∑ kn 
Pα1 
∆ak1 (φ1)Pα2 
∆ak2 (φ2) · · ·Pαn∆akn 
(φn) (4.4a) 
= ∑ k1 
∑ k2 
· · · ∑ kn 
U(φ0 − φ1)Pα1 
∆ak1 U(φ1 − φ2) · · ·U(φn−1 − φn)Pαn∆akn 
U(φn − φ0) 
(4.4b) 
= U(φ0 − φ1)U(φ1 − φ2) · · ·U(φn−1 − φn)U(φn − φ0) (4.4c) 
= U(φ0 − φn)U(φn − φ0) (4.4d) 
= 1, (4.4e) 
19 Because the evolution in φ is unitary this fiducial value is completely arbitrary and may be adjusted at will to remain outside the region of coarse-grainings of physical interest.
 
the identity on the physical Hilbert space Hphys. For example, the class operator for the history in which the volume ν is in ∆ν when the scalar field φ = φ∗ is simply 
C∆ν|φ∗ = U†(φ∗ − φ0)P ν∆νU(φ∗ − φ0), (4.5) 
where P ν∆ν is given by Eq. (3.36). Note that we employ here projections onto ranges of values of the volume operator ν̂, not the Dirac observable ν̂|φ∗ . We will return to this point in Section IV D, once we have completed the definition of the decoherence functional. However, comparison of Eqs. (4.5) and (3.28) or (3.27) should be sufficient to suggest the thrust of that discussion. 
Remark: It is certainly not the case that all questions of physical interest may be directly captured by class operators of the specific form defined by Eq. (4.3) or coarse-grainings thereof. Indeed, this is not the case even in ordinary quantum theory. We give two examples. 
First, consider physical questions defined by coarse-grainings of minisuperspace by two-dimensional regions i.e. coarse-grainings by continuous ranges of φ and other variables. In the current quantization, where φ plays in effect the mathematical role of an emergent “time”, such questions are akin to questions in particle mechanics such as “Does the particle ever enter spacetime region R?” There are various approaches for tackling this and related problems, both in ordinary quantum mechanics [3, 37–40] and in quantum cosmology [10–16], but we shall not take up questions of this kind here – not least, because with currently available methods, it is very difficult to calculate anything except in the very simplest of cases even in particle mechanics.20 
As a second example, we can consider a reformulation of the present model in which the scale factor (or volume) is treated as a clock rather than the scalar field. The simplicity of the model allows this unitary equivalence between “space” (labeled by volume) and “time” (labeled by the field). In this way questions such as “What is the value of the scalar field at ν = νo?” may be coherently posed. Regardless, we will not take up questions of this kind here. 
B. Branch wave functions 
Class operators, as described in the previous sub-section, capture the physical questions that may be asked of a system. The branch wave functions |Ψh〉 constructed from an exclusive, exhaustive set of histories {h}, and a given quantum (“initial”) state |Ψ〉 specified at φ = φo, are then the amplitudes for that state to “follow” the histories h i.e. for the universe to have the properties described by h. 
Branch wave functions in non-relativistic particle mechanics are defined by Eq. (2.4), or Eq. (2.17) to define a state on spacetime that satisfies the Schrödinger equation everywhere. In quantum cosmology, the branch wave function for a state |Ψ〉 (in the physical Hilbert space) and history h may be constructed in the same way: 
|Ψh(φ)〉 = U(φ− φ0)C†h|Ψ〉. (4.6) 
This branch wave function is, by construction, a solution to the Wheeler-DeWitt equation everywhere. The extra propagator U , of course, simply evolves the branch wave function to any convenient φ = constant slice. (All inner products will of course be independent of this choice.) 
C. Decoherence functional 
Given a complete exclusive, exhaustive set of histories {h} and a quantum state |Ψ〉, the decoherence functional measures the interference among the branch wave functions |Ψh〉, and, if that interference vanishes, determines also the probabilities of each of the |Ψh〉 – in other words, the probability that a universe in the state |Ψ〉 has the properties described by the history h. If the interference does not vanish, then the set of physical questions {h} does not make sense in the quantum theory, in exactly the same way the question of which slit a particle passed through cannot be coherently analyzed when it is not recorded. 
The decoherence functional in non-relativistic quantum mechanics is defined according to Eq. (2.8). In quantum cosmology the decoherence functional may be constructed from the branch wave functions in essentially the same manner [15]:21 
d(h, h′) = 〈Ψh′ |Ψh〉. (4.7) 
20 Apropos of this point, it may be worth noting that it should be possible to express the decoherence functional in a form which is manifestly diffeomorphism invariant; see [15] for an example of what this looks like in a different (functional integral) quantization, a general discussion of diffeomorphism invariant physical alternatives, and one way of constructing the corresponding class operators. Alternative approaches which demand the class operators commute with the constraint are developed in [10–14, 16]. In the present canonical context, note that instead our branch wave functions – cf. Eq. (4.6) – are solutions of the constraint; see Sec. II 3. 
21 The (reasonably transparent) generalization of this definition to mixed states is also given in [15].
 
Decoherent sets of histories satisfy 
d(h, h′) = p(h) δh′h, (4.8) 
where p(h) is the probability for the history h. Note that as constructed, the decoherence functional for this model involves an inner product of branch wave functions on a minusuperspace slice of fixed φ. The unitary evolution in φ, and the fact that the branch wave functions |Ψh(φ)〉 are by construction everywhere solutions of the Wheeler-DeWitt equation, makes the specific choice of φ irrelevant in the definition of the branch wave functions and decoherence functional, and therefore may be selected for maximal convenience. This freedom will be exploited frequently in the sequel. 
In more general models where a unitary evolution in some effective clock variable like φ might not be available, it is more natural to define Eq. (4.7) on (mini)superspace slices that are spacelike in the DeWitt metric, e.g. on slices of constant scale factor – as is done, for example, in Ref. [15]. In this simple model, however, these choices are unitarily equivalent, as should be evident from Eq. (3.19). 
Indeed, so long as we can define normalizeable states on slices of superspace that are spacelike in the DeWitt metric, and a unitary evolution between such slices, we might expect Eq. (4.7) – or one of its simple generalizations, as in Ref. [15] – to be a suitable definition for the decoherence functional in a full theory of quantum gravity as well. 
D. Histories and relational observables 
We noted below Eq. (4.5) that the class operator for volume was defined using projections onto ranges of the volume operator ν̂, which is not a Dirac observable. We now clarify the relation between probabilities computed from class operators and the Dirac observables. 
To see this, consider a self-adjoint local operator Â that does not commute with the constraint and the corresponding relational observable given by Eq. (3.27). Assuming for definiteness the spectrum of Â to be continuous, take formally 
the spectral resolution of Â to be 
Â = 
∫ da a |a〉〈a| (4.9a) 
= 
∫ da aPa (4.9b) 
= 
∫ a dPa, (4.9c) 
with Pa ≡ |a〉〈a| and dPa ≡ Pa da. 
Class operators for ranges of values ∆a of Â may be constructed as 
C∆a|φ∗ = U†(φ∗ − φ0)PA∆aU(φ∗ − φ0), (4.10) 
the corresponding branch wave functions for a given state |Ψ〉 being given by Eq. (4.6), 
|Ψ∆a|φ∗ (φ)〉 = U(φ− φ0)C†∆a|φ∗ |Ψ〉. (4.11) 
Since the class operators are simply projections, the corresponding histories always decohere. (See Section V A 1 for details of the calculation in the case of the volume operator.) The probability that a ∈ ∆a is then given by 
p∆a(φ∗) = 〈Ψ∆a|φ∗ |Ψ∆a|φ∗ 〉 (4.12a) 
= 〈Ψ|C∆a|φ∗C † ∆a|φ∗ 
|Ψ〉 (4.12b) 
= 〈Ψ|C∆a|φ∗ |Ψ〉 (4.12c) 
= 〈Ψ|U†(φ∗ − φ0)PA∆aU(φ∗ − φ0)|Ψ〉 (4.12d) 
= 〈U(φ∗ − φ0)Ψ|PA∆aU(φ∗ − φ0)|Ψ〉 (4.12e) 
= 〈Ψ(φ∗)|PA∆a|Ψ(φ∗)〉. (4.12f) 
Taking ∆a to be the infinitesimal interval da, the probability that a ∈ da at φ = φ∗ is 
dpa(φ∗) = 〈Ψ(φ∗)|dPa|Ψ(φ∗)〉. (4.13)
 
To see the connection with the relational observable Eq. (3.27), let us find the average value of Â at φ = φ∗. If Â 
has a discrete spectrum this is simply ∑ a a pa(φ∗). Since we have taken Â to have a continuous spectrum, 
〈Â〉|φ∗ = 
∫ a dpa(φ∗) (4.14a) 
= 
∫ a 〈Ψ(φ∗)|dPa|Ψ(φ∗)〉 (4.14b) 
= 〈Ψ(φ∗)| ∫ a dPa|Ψ(φ∗)〉 (4.14c) 
= 〈Ψ(φ∗)|Â|Ψ(φ∗)〉 (4.14d) 
= 〈U(φ∗ − φ0)Ψ|Â U(φ∗ − φ0)|Ψ〉 (4.14e) 
= 〈Ψ|U(φ∗ − φ0)†Â U(φ∗ − φ0)|Ψ〉 (4.14f) 
= 〈Ψ|Â|φ∗ |Ψ〉, (4.14g) 
where the last step follows by comparison with Eq. (3.27). (The calculation is essentially unchanged if the spectrum 
of Â is chosen to be discrete.) We can thus see that the average value of Â at φ = φ∗ is naturally given by the 
expectation value of the relational observable Â|φ∗ in the state |Ψ〉. In other words, probabilities for histories of 
values of Â, which does not commute with the constraint, are naturally expressed in terms of the corresponding Dirac observable Â|φ∗ , which does. Put another way, histories formulations of quantum theory provide a natural framework for understanding the emergence of relational Dirac observables in theories with constraints.22 
We hope to explore this connection between histories formulations and relational observables further in another work. 
V. APPLICATIONS 
Now that the machinery for a consistent histories formulation of quantum cosmology in minisuperspace has been fully defined, we turn to application of the theory to extract physical predictions. We shall examine in turn predictions concerning the scalar momentum, the volume of the universe, the semiclassical behaviour of the universe, and, finally, the question of whether a quantum universe shares the inevitably singular fate of its classical counterpart. 
In each case the methodology for prediction is the same. For each physical question the corresponding class operators for an exclusive, exhaustive partition of the possible histories must be determined. Given the class operators and a choice of quantum state, it may be ascertained whether or not the set of histories decoheres. For some classes of questions, decoherence (or lack thereof) is generic, independent of the choice of state. In general, however, decoherence depends on the state. 
If the family of histories fails to decohere, then the question as formulated does not make sense in the quantum theory, in that probabilities may not be consistently assigned to the alternative histories. If the family does decohere, then probabilities may be assigned according to Eq. (4.8), and the relative likelihood of the alternatives assessed. 
We now proceed with this plan for each of our observable quantities. 
A. Volume 
We will examine predictions concerning the volume of (a fiducial cell of) a quantum universe, focusing on the specific cases of the volume at a given value of the scalar field, and of the volume at a sequence of values of the scalar field. In the first instance we shall find that decoherence is automatic, essentially because it is a prediction concerning the value of a single quantity on a single slice. For given choices of state we show how to calculate the probabilities explicitly, and exhibit a few examples. 
In the second instance, sequences of values of the volume at different values of the scalar field, decoherence is considerably more intricate, and indeed, in general will not occur. In subsequent sections we will exhibit two examples for which such histories do decohere, and again show how to calculate the probabilities and illustrate with some examples. 
We will employ these results to study in Section V D the question of whether our model quantum universes are singular in an appropriate sense. 
22 Note that it is not the role of φ as an effective “time” that is relevant here. Rather, what is important is the scheme for predictions concerning correlations between the values of different quantum variables.
 
1. Volume at a given value of φ 
The class operators for the question, “What is the volume of (a fiducial cell of) the universe when φ = φ∗?” are given by Eq. (4.5): 
C∆ν|φ∗ = U†(φ∗ − φ0)P ν∆νU(φ∗ − φ0), (5.1a) 
= P ν∆ν(φ∗), (5.1b) 
where the ranges ∆ν are chosen from a set {∆νi} of disjoint intervals that partition the full range of volumes 0 ≤ ν <∞, so that ∑ 
i 
C∆νi|φ∗ = 1, (5.2) 
the identity on Hphys. The corresponding branch wave functions are 
|Ψ∆ν|φ∗ (φ)〉 = U(φ− φ0)C†∆ν|φ∗ |Ψ〉, (5.3) 
where |Ψ〉 is the quantum state of the universe defined on a chosen slice φ = φ0. Since C∆ν|φ∗ is simply a projection, it is clear that the {C∆νi|φ∗} are orthogonal when the ranges are different: 
C∆νi|φ∗ · C†∆νj |φ∗ = C∆νi∩∆νj |φ∗ (5.4a) 
= C∆νi|φ∗ · δij , (5.4b) 
= C∆νi|φ∗ C†∆νi|φ∗ · δij , (5.4c) 
from which it is equally clear that 
〈Ψ∆νi|φ∗ |Ψ∆νj |φ∗ 〉 = 〈C†∆νi|φ∗Ψ |C†∆νj |φ∗Ψ〉 (5.5a) 
= 〈Ψ |C∆νi|φ∗ C†∆νj |φ∗Ψ〉 (5.5b) 
= 〈Ψ∆νi|φ∗ |Ψ∆νi|φ∗ 〉 · δij (5.5c) 
for any choice of state |Ψ〉, and thus this family of histories decoheres. From Eq. (5.1a), the probability that the volume of (a fiducial cell of) the universe lies in ∆ν when φ = φ∗ is then given by 
p∆ν(φ∗) = 〈Ψ∆ν|φ∗ |Ψ∆ν|φ∗ 〉 (5.6a) 
= 〈Ψ|C†∆ν|φ∗ |Ψ〉 (5.6b) 
= 〈Ψ|U†(φ∗ − φ0)P ν∆νU(φ∗ − φ0)|Ψ〉 (5.6c) 
= 〈U(φ∗ − φ0)Ψ|P ν∆νU(φ∗ − φ0)|Ψ〉 (5.6d) 
= 〈Ψ(φ∗)|P ν∆ν |Ψ(φ∗)〉 (5.6e) 
= 
∫ ∆ν 
dν 
ν |Ψ(ν, φ∗)|2 (5.6f) 
using Eq. (3.36). While this indeed may have been the expected result, it is important to note that it has here been derived within a fully coherent framework for constructing quantum probabilities. It is also worth emphasizing that the form of the result is crucially dependent on the form of the inner product in the volume representation. It is essential to know the form of the inner product and representative projections in a representation before drawing any conclusions concerning the interpretation of the wave function as a probability density from a formula like Eq. (5.6a). In other representations the formula for single probabilities will take on a different form. For example, for the curvature variable y noted in footnote 17, the probability formula for y takes on a Klein-Gordon form. This clearly illustrates the profound importance of framing quantum probabilities within a clear and self-consistent framework. 
Note in addition that with ∆ν taken to be an infinitesimal interval dν, Eq. (5.6f) – in conjunction with Eqs. (4.9) and (4.13) – can then by the calculation of Eq. (4.14) be employed to determine, in any given representation, the corresponding expression for an expectation value. For example, 〈νn〉 = 
∫ νndpν = 
∫ dν ν ν 
n|Ψ(ν, φ)|2. In Section V D we shall apply these results to a discussion of whether or not the quantum universe is singular, in 
the sense that the probability that the volume of (a fiducial cell of) the universe becomes zero at some value of the scalar field is unity for a given state |Ψ〉.
 
We complete this sub-section by calculating these probabilities for the semiclassical state given in Eq. (3.37). It is straightforward to show from Eq. (5.6) that the probability that such a universe will be found with volume in the range ∆ν = [ν1, ν2] at φ is given by 
psc∆ν(φ) = 1 
2 
{ erf(σ(ln ν2 ∓ 
√ 12πG(φ− φ̄∓)))− erf(σ(ln ν1 ∓ 
√ 12πG(φ− φ̄∓))) 
} (5.7a) 
= 1 
2 
{ erf(σ(ln 
ν2 
ν̄ ∓ √ 
12πG(φ− φo)))− erf(σ(ln ν1 
ν̄ ∓ √ 
12πG(φ− φo))) } . (5.7b) 
Here the upper sign is for expanding solutions and the lower, contracting. Thus, for example, the likelihood that a semiclassical universe will be found at small volume – i.e. with volume less than ν∗ – is 
psc∆ν∗(φ) = 1 
2 
{ 1 + erf(σ(ln 
ν∗ 
ν̄ ∓ √ 
12πG(φ− φo))) } , (5.8) 
where ∆ν∗ = [0, ν∗]. 
2. Volume at a sequence of values of φ 
Consider a sequence of values of the scalar field (φ1, φ2, . . . , φn). The class operators for the question, “What is the volume of (a fiducial cell of) the universe when φ = φ1, again when φ = φ2, and so forth through φ = φn?” are 
C∆ν1|φ1 ;∆ν2|φ2 
;··· ;∆νn|φn = P ν∆ν1 (φ1)P ν∆ν2 
(φ2) · · ·P ν∆νn(φn), (5.9) 
where the P ν∆ν(φ) are given by Eq. (4.1) and each of the sets of ranges ({∆ν1}, {∆ν2}, . . . , {∆νn}) again partition the interval 0 ≤ ν <∞. The branch wave functions are defined in the usual way, according to Eq. (4.6). 
Before any question of probabilities for such histories is addressed, it must be determined whether these histories decohere. Since the class operators Eq. (5.9) are no longer projections, it is neither obvious nor trivial that they do. Indeed, in general, histories of this kind will not be expected to decohere, no more than the histories asking which slit a particle passed through in the two-slit experiment decohere unless a recording apparatus is in place. We will, however, see three important examples for which they do, in Sections V B, V C, and V D. 
B. Scalar momentum 
Classically, the scalar momentum is a constant of the motion, {pφ, H} = 0 (cf. Eq. (3.11).) In the quantum theory, [p̂φ,Θ]Ψ = 0. Since p̂φ commutes with the constraint, it is a constant of the motion in the quantum theory as well. Thus, defining the relational observable p̂φ|φ∗ giving the value of p̂φ at φ = φ∗, we see from Eq. (3.26) that p̂φ|φ∗ = p̂φ. The meaning of this is that if we carry through a calculation for the probability p∆pφ(φ∗) for pφ to be found in ∆pφ similar to that which led to Eq. (5.6), we find that p∆pφ(φ∗) = p∆pφ is independent of φ∗. 
Moreover, if one considers histories of the form 
C∆pφ;1|φ1 ;∆pφ;2|φ2 
;··· ;∆pφ;n|φn = P pφ ∆pφ;1 
(φ1)P pφ ∆pφ;2 
(φ2) · · ·P pφ∆pφ;n (φn), (5.10) 
since P pφ ∆pφ 
(φ) = P pφ ∆pφ 
, every one of these class operators is zero except for those for which all the intervals ∆pφ are the same, which then reduce simply to a projection on that range of pφ. Thus the corresponding branch wave functions (for any initial state) decohere, and their probabilities are constant. This of course is just an expression of the fact that p̂φ is a constant of the motion i.e. does not change with evolution in φ. 
Constants of the motion in generalized quantum theory are discussed in greater depth in Ref. [41]. 
C. Semiclassical evolution 
More than one meaning may be assigned to the notion that a universe “behaves semiclassically”. The emergence of quasi-classical behavior of a quantum system typically involves the decoherence of histories corresponding to approximately classical trajectories due to correlations with – typically, but not necessarily – microscopic degrees of freedom, leading to quasi-classical equations of motion for the remainder [19, 26, 27]. In the present simple model, there are few degrees of freedom with which to correlate. Nonetheless, the model still displays decoherence for quasi-classical histories in the following way.
 
Consider a semiclassical state (such as Eq. (3.37)) that is peaked along some classical trajectory. Coarse-grain minisuperspace on a set of slices {φ1, φ2, . . . , φn} by ranges of volume {∆νik , k = 1...n} on each slice φk (so that ∪ik∆νik = [0,∞) for each k), chosen in such a way that on each slice one of the ranges ∆νclk straddles the classical trajectory on that slice.23 (See Fig. 2.) If the ∆νclk are chosen to be comparable in width or wider than24 the width given by Eq. (3.39), then essentially the only branch wave function that is not zero is 
|Ψcl〉 = P ν∆νcln (φn) · · ·P ν∆νcl2 (φ2)P ν∆νcl1 (φ1)|Ψ〉. (5.11) 
In this way, the family of histories (classical ,nonclassical) decoheres, and quasi-classical behavior is predicted for such states with probability one. “Large” universes are more robustly semiclassical because their spreading is pro-portionately small, according to Eq. (3.39). (One can make related arguments for the emergence of appropriately quasiclassical behavior for WKB states [3, 8, 15].) 
FIG. 2. Coarse-graining by ranges of values of the volume at different values of the scalar field. Histories consisting of ranges which straddle a particular classical trajectory are the “(semi-)classical” histories; all others describe “non-classical” behavior. Two histories are shown – one classical and one not. The first is a coarse-grained history (∆νcl1 ,∆νcl2 ,∆νcl3) describing a (semi-)classically expanding universe. The second history (∆ν1,∆ν2) describes a (very highly coarse-grained) “quantum bounce”, which asks whether a quantum universe may be peaked on a classical solution at both early and late values of φ. 
In models as simple as the present one, this is about as far as one can go. For studies of the emergence of quasiclassical behavior in more complex systems, see Refs. [19, 42]. 
D. Singularity in a Wheeler-DeWitt quantum universe 
In quantum theory there are various inequivalent meanings one might assign to the idea that a quantum universe is or is not “singular”. In this section we address the question of whether our model quantum universe is singular 
23 If we continue to regard φ as an effective “time”, the equivalent question in particle mechanics would be, “Is the particle in ∆x1 at time t1, in ∆x2 at time t2, and so on through ∆xn at time tn?” Clearly this is a coarse-grained way to inquire whether the particle has followed a particular path, in this case the one defined by the intervals ∆xi. 
24 One typical consequence of correlations with other degrees of freedom in more complicated models is stabilization of semiclassical wave packets against quantum spreading.
 
with explicit criteria based on the probabilities that various physical quantities assume values that signal a physical singularity. We study in particular the volume observable. Given that the scalar momentum pφ is a constant of motion in the quantum theory, knowledge concerning the volume observable directly implies the same for the energy density ρ̂|φ = (1/2)V̂ −1 
|φ p̂φV̂ −1 |φ , and hence the corresponding operators for spacetime curvature invariants. Indeed, 
the statement that the universe has zero volume in this model is equivalent to the statement that energy density and spacetime curvature invariants diverge. The conclusion will be that, according to all of these criteria, these Wheeler-DeWitt universes are singular for all choices of state. This includes, in particular, “Schrödinger’s Cat” states, generic (but possibly macroscopic) superpositions of left-moving (contracting) and right-moving (expanding) states. We will show analytically that in this quantization, completely generic quantum states of the universe are always singular. 
1. Volume singularity 
First, we study the question of the singularity of the universe by inquiring after the likelihood that the volume of (a fiducial cell of) the universe becomes zero. We shall show rigorously that the probability that the universe has zero volume at some value of the scalar field is unity for all choices of state. In particular, we will examine the behaviour of these probabilities analytically for generic states in the limit that the absolute value of the scalar field becomes large, with the result that the volume goes to zero with certainty for all left-moving (contracting) states as φ→ +∞, and for all right-moving (expanding) states as φ→ −∞. This turn out to be sufficient to imply that the probability that these universes assume zero volume at some value of φ is unity, independent of the choice of state |Ψ〉. 
To ask the question whether the volume of (a fiducial cell of) the universe becomes zero, at any value of φ partition the volume ν into the range ∆ν∗ = [0, ν∗] for some fixed volume ν∗, and its complement ∆ν∗ = (ν∗,∞). (See Fig. 3.) Since this is a coarse-graining defined on a slice of fixed φ, we know that the histories decohere. We would like to calculate the probabilities p∆ν∗(φ) and p∆ν∗(φ). These will be given by Eq. (5.6). 
FIG. 3. Coarse-graining of minisuperspace suitable for studying the probability that the universe assumes zero volume. Partition the volume ν into the range ∆ν∗ = [0, ν∗] (the shaded region in the figure) and its complement ∆ν∗ = (ν∗,∞). The quantum universe may be said to attain zero volume if the probability for the branch wave function |Ψ∆ν∗〉 is near unity while that for |Ψ∆ν∗〉 is near zero for arbitrary choices of ν∗.
 
To begin, let us consider separately states |ΨL〉 and |ΨR〉 that are purely left- (contracting) and right- (expanding) moving in the volume representation. We first note that in the quantum theory the left- and right- moving sectors are superselected by the Dirac observables, i.e. the action of Dirac observables does not mix these sectors (see Ref. [30] for details.) From Eq. (3.25), we know that ΨL(ν+) = 〈ν |ΨL(φ)〉 and ΨR(ν−) = 〈ν |ΨR(φ)〉 only depend on ν and φ in the combination ν± = φ± (12πG)−1/2 ln ν. For any fixed φ, the range ∆ν∗ = [0, ν∗] corresponds to ∆ν∗± = (∓∞, ν∗±], 
and with dν± = ±(12πG)−1/2dν/ν, 
pL∆ν∗(φ) = 
∫ ν∗ 
0 
dν 
ν |ΨL(ν+)|2 (5.12a) 
= κ 
∫ φ+κ−1 ln ν∗ 
−∞ dν+ |ΨL(ν+)|2, (5.12b) 
and similarly 
pR∆ν∗(φ) = −κ ∫ φ−κ−1 ln ν∗ 
∞ dν− |ΨR(ν−)|2, (5.13a) 
= κ 
∫ ∞ φ−κ−1 ln ν∗ 
dν− |ΨR(ν−)|2 (5.13b) 
where we have defined κ = √ 
12πG. From Eqs. (5.12)-(5.13) it is clear that since |ΨL,R〉 are normalized states, 
lim φ→−∞ 
pL∆ν∗(φ) = 0 lim φ→+∞ 
pL∆ν∗(φ) = 1 (5.14a) 
lim φ→−∞ 
pR∆ν∗(φ) = 1 lim φ→+∞ 
pR∆ν∗(φ) = 0 (5.14b) 
for any fixed choice of ν∗, no matter how small. These are precisely the results we should have expected: contracting universes will inevitably shrink to arbitrarily 
small volume, and expanding universes have inevitably grown from arbitrarily small volume. In this sense, then, purely expanding or contracting universes are inevitably singular at either φ = −∞ or +∞. 
While this may have been the expected result, a few points are worth emphasis. First, this result has been rigorously derived according to an explicit criterion within a fully coherent framework for deducing quantum probabilities. Second, while our intuition may be happy with this result for classical or semiclassical universes, we have made no such assumption concerning the states |ΨL〉 and |ΨR〉. Indeed, we made no assumption at all about these states other than that they are purely left- or right-moving.25 
What about more general states which are superpositions of left- and right-moving states? Indeed, a glance at Fig. 2 might lead one to wonder whether such a superposition might lead to the possibility of a “quantum bounce”, in which a superposition of (possibly macroscopic) expanding and contracting universes might be likely to be peaked on a large classical solution at both “early” and “late” values of φ – effectively “jumping” from one branch to the other. We shall show that in these models, this cannot occur. 
To see how this works, consider the superposition 
|Ψ〉 = |ΨL〉+ |ΨR〉. (5.15) 
Note, though, the states |ΨL,R〉 are no longer normalized. Rather 
〈Ψ |Ψ〉 = 〈ΨL |ΨL〉+ 〈ΨR |ΨR〉 (5.16a) 
≡ pL + pR (5.16b) 
= 1 (5.16c) 
since |Ψ〉 is normalized and the left- and right-moving sectors are orthogonal. pL and pR measure the “amount” of each state in |Ψ〉. We now find that, since the volume projections leave the L and R sectors invariant, 
p∆ν∗(φ) = pL∆ν∗(φ) + pR∆ν∗(φ), (5.17) 
25 Note that it was established in Ref. [23] that the expectation value of the volume hits zero (i) for generic left-moving states as φ→∞, and (ii) for generic right-moving states as φ→ −∞ . However, a consistent quantum probabilistic interpretation was lacking. Moreover, the present framework makes it possible to ask and answer much more precisely framed questions. Here, for example, we find the probability for the quantum universe to be found in a specific range of volumes – not simply calculate its average value. To illustrate why this is significant, note that the expectation value of the volume in a state which is a superposition of left- and right-moving modes (as in Eq. (5.15) below) will not asymptote to zero in either direction φ → ±∞. The expectation value cannot reveal that such states are nonetheless invariably singular – it is too coarse a diagnostic. For that, one requires a consistent quantum analysis of ranges of possible values of the volume at (at least) two values of φ, as discussed below.
 
with pL,R∆ν∗(φ) given again by Eqs. (5.12)-(5.13). Then 
lim φ→−∞ 
p∆ν∗(φ) = pR and lim φ→+∞ 
p∆ν∗(φ) = pL. (5.18) 
In between, we may expect p∆ν∗(φ) to drop even to very small values, especially for |ΨL,R〉 that are peaked on classical trajectories. By way of example, for a left- and right-moving superposition of the semiclassical states given in Eq. (3.37), from Eqs. (5.8) and (5.17) we find 
p∆ν∗(φ) = 1 
2 
{ 1 + pL erf(σL(ln 
ν∗ 
ν̄L + √ 
12πG(φ− φo))) + pR erf(σR(ln ν∗ 
ν̄R − √ 
12πG(φ− φo))) } . (5.19) 
The behaviour of pL∆ν∗(φ), pR∆ν∗(φ), and p∆ν∗(φ) is shown in Fig. 4. 
FIG. 4. The behavior of p∆ν∗(φ), the probability that the quantum universe will be found in the interval ∆ν∗ = [0, ν∗] (i.e. at small volume) for a sample superposition of expanding (R) and contracting (L) semiclassical states both peaked at large volume near φ = 0 (cf. Eqs. (3.37) and (5.7).) pL and pR give the relative “amount” of each component in the superposition, so that pL+pR = 1. (For the states shown in the figure, φo = 0, ν̄ = 10, 000, σ = 0.075, pL = 0.2, ν∗ = 2, and we have set lp = 1.) Also shown are pL∆ν∗(φ) and pR∆ν∗(φ), the probabilities that each component individually will be found at small volume. Note how pL∆ν∗(φ) asymptotes to pL as φ → +∞ and pR∆ν∗(φ) asymptotes to pR as φ → −∞, since the contracting component becomes singular for large φ, and the expanding component becomes singular for large negative φ. Similarly, each component asymptotes to 0 in the opposite direction. This plot may appear to imply the possibility of a “quantum bounce”, since at any given φ there is a non-zero probability that the universe may be found with volume ν > ν∗. A more careful consistent histories analysis shows that this possibility is not realized: the probability that the universe has large volume in both the “past” and “future” is zero. (After Ref. [18].) 
2. Absence of Quantum Bounce 
It may appear that this result leaves open the possibility of a quantum bounce for a universe in such a superposition, for at no value of φ does the probability that the volume of the universe goes to zero become in general close to unity. At any given value of φ, there is some probability for the universe to assume small volume, and some probability for it to be large. Is there not then a non-zero probability for the universe to be large in both the “past” and the “future”? This is not the case, however, in part because p∆ν∗(φ) is the wrong question to ask. 
This is so because it only inquires about the volume at a single value of φ. Indeed, for a universe which is a superposition of both expanding and contracting components, it is not surprising that at any given value of φ – including infinitely far in the “past” or “future” – there is a possibility the universe may be found in the “other”
 
state, the one that is not at arbitrarily small volume at that value of φ. For a “quantum bounce” there must be a possibility that the universe is large at two values of φ, both “early” and “late”. In other words, to properly address the question of a quantum bounce, we must consider histories of the form Eq. (5.9) for two values of φ. This is where the role of decoherence will be essential. 
In particular, we must ask the question, “What is the probability that the universe was never singular (had zero volume)?”, and the complementary question, “What is the probability that the universe was ever singular (had zero volume)?” We shall find that this family of histories is consistent, and that the answer to the former question is zero, and the latter, unity. 
The class operators for this coarse-graining are more subtle than one may at first expect. For concreteness let us consider a choice of two φ-slices, φ1 and φ2, and the corresponding partitions (∆ν∗1 ,∆ν 
∗ 1 ) and (∆ν∗2 ,∆ν 
∗ 2 ). The choice 
of these slices is such that we can probe the physics for both late and early times by taking for example φ1 → −∞ and φ2 → ∞. The class operator for the (very coarse-grained version of the) history “the universe has large volume at early as well as late times” (i.e. is found in both ∆ν∗1 and ∆ν∗2 ) is 
Cbounce(φ1, φ2) = C∆ν∗1 ;∆ν∗2 (5.20a) 
= P ν ∆ν∗1 
(φ1)P ν ∆ν∗2 
(φ2). (5.20b) 
Since the class operators for an exclusive, exhaustive set of histories must sum to unity, 
1 = C∆ν∗1 ;∆ν∗2 + C∆ν∗1 ;∆ν∗2 
+ C∆ν∗1 ;∆ν∗2 + C∆ν∗1 ;∆ν∗2 
, (5.21) 
the class operator for the complementary history “the universe is not found in both ∆ν∗1 and ∆ν∗2”, or in other words, “the universe will be in ∆ν∗1 (and) or ∆ν∗2 ,” is given by 
Csing(φ1, φ2) = 1− C∆ν∗1 ;∆ν∗2 (5.22a) 
= C∆ν∗1 ;∆ν∗2 + C∆ν∗1 ;∆ν∗2 
+ C∆ν∗1 ;∆ν∗2 (5.22b) 
= C∆ν∗1 ;∆ν∗2∪∆ν∗2 + C∆ν∗1∪∆ν∗1 ;∆ν∗2 
− C∆ν∗1 ;∆ν∗2 (5.22c) 
= C∆ν∗1 + C∆ν∗2 
− C∆ν∗1 ;∆ν∗2 , (5.22d) 
where it should be clear that, for example, C∆ν∗1 ;∆ν∗2 + C∆ν∗1 ;∆ν∗2 
= C∆ν∗1 ;∆ν∗2∪∆ν∗2 = C∆ν∗1 
, since the C∆ν1;∆ν2 are 
simply products of projections. One can see that the terms on the right hand side of Eq. (5.22b) encode the various ways in which the universe may find itself at small volume at one or both of φ1 and φ2. 
We now show that C†bounce|Ψ〉 = 0 if we take φ1 → −∞ and φ2 → +∞, and therefore the set of histories (bounce, singular) decoheres, with psing = 1. 
We will proceed by demonstrating that C†∆ν∗1 ;∆ν∗2 |Ψ〉 and C†∆ν∗1 ;∆ν∗2 
|Ψ〉 both vanish in this limit. To see how this works, let us calculate P ν∆ν(φ)|ΨL〉, again employing ν± = φ± κ−1 ln ν: 
P ν∆ν(φ)|ΨL〉 = U†(φ− φ0)P ν∆ν |ΨL(φ)〉 (5.23a) 
= U†(φ− φ0) 
∫ ∆ν 
dν 
ν |ν〉ΨL(ν, φ) (5.23b) 
= U†(φ− φ0)κ 
∫ ∆ν+ 
dν+|ν+〉ΨL(ν+), (5.23c) 
where we have introduced |ν±〉 ≡ |ν = exp(±κ(ν± − φ))〉, which satisfy 〈ν′± |ν±〉 = κ−1δ(ν′± − ν±) and 1 = 
κ ∫∞ −∞ dν±|ν±〉〈ν±|. Thus we see that 
lim φ→±∞ 
P ν∆ν∗(φ)|ΨL〉 = lim φ→±∞ 
U†(φ− φ0)κ 
∫ φ+κ−1 ln ν∗ 
−∞ dν+|ν+〉ΨL(ν+), (5.24a) 
= lim φ→±∞ 
U(φ0 − φ) 
{ |ΨL(φ)〉 0 
(5.24b) 
= 
{ |ΨL〉 φ→ +∞ 0 φ→ −∞ . (5.24c) 
Similarly, 
lim φ→±∞ 
P ν∆ν∗(φ)|ΨR〉 = 
{ 0 φ→ +∞ |ΨR〉 φ→ −∞ (5.25)
 
and in the same way 
lim φ→±∞ 
P ν ∆ν∗ 
(φ)|ΨL〉 = 
{ 0 φ→ +∞ |ΨL〉 φ→ −∞ (5.26) 
and 
lim φ→±∞ 
P ν ∆ν∗ 
(φ)|ΨR〉 = 
{ |ΨR〉 φ→ +∞ 0 φ→ −∞ . (5.27) 
In this way, given the general superposition Eq. (5.15), 
lim φ1→−∞ φ2→+∞ 
C†∆ν∗1 ;∆ν∗2 |Ψ〉 = lim 
φ1→−∞ φ2→+∞ 
P ν∆ν∗(φ2)P ν∆ν∗(φ1) { |ΨL〉+ |ΨR〉 
} (5.28a) 
= lim φ2→+∞ 
P ν∆ν∗(φ2)|ΨR〉 (5.28b) 
= 0, (5.28c) 
and in the same way 
lim φ1→−∞ φ2→+∞ 
C†∆ν∗1 ;∆ν∗2 |Ψ〉 = 0. (5.29) 
Defining formally 
Cbounce = lim φ1→−∞ φ2→+∞ 
Cbounce(φ1, φ2) (5.30) 
and 
Csing = lim φ1→−∞ φ2→+∞ 
Csing(φ1, φ2), (5.31) 
where Cbounce(φ1, φ2) and Csing(φ1, φ2) are given in Eqs. (5.20) and (5.22), we see that the branch wave functions are 
|Ψbounce〉 = C†bounce|Ψ〉 (5.32a) 
= 0 (5.32b) 
and 
|Ψsing〉 = C†sing|Ψ〉 (5.33a) 
= |ΨL〉+ |ΨR〉 (5.33b) 
= |Ψ〉. (5.33c) 
Since only one of the branch wave functions is not zero, the histories (bounce,singular) clearly decohere, and 
psing = 〈Ψsing |Ψsing〉 (5.34a) 
= 〈Ψ |Ψ〉 (5.34b) 
= 1. (5.34c) 
Note once again that we have made no assumptions on the state whatever – this result holds for all choices of state, highly quantum, highly classical, or even a Schrödinger cat-like superposition of expanding and collapsing universes. All quantum Wheeler-DeWitt universes will assume zero volume at some point in their history. There is no “quantum bounce”. 
It is important to emphasize that the question of whether a quantum universe can “bounce” is not trivial and can not be answered simply by examining the behaviour of |Ψ(φ)〉. As emphasized in Ref. [17], it is inherently a quantum question, and the role of decoherence is essential to its coherent analysis. This is because it is inherently a question about the value of the volume on two different φ-slices. In general such histories do not decohere,26 and 
26 Even for purely left- or right-moving states – never mind superpositions such as Eq. (5.15).
 
the question of what is the volume at two different values of φ makes in general no more quantum sense than the question of which slit a particle passed through in the case of two-slit interference.27 Indeed, it is only in the limit that φ1 → −∞ and φ2 → +∞ that we are assured in general that these histories do decohere; that the quantum question may be answered, in the sense that probabilities may be assigned; and that the answer turns out to be that, in this quantization, these model universes never “bounce”. 
We wish to be clear what is being asserted here. In tabletop quantum theory the proper manner in which to address a question of this kind is to calculate a conditional probability (transition amplitude) – if the universe is found to be at large volume in the “past”, what is the probability that it will also be at large volume in the “future”? That is essentially what Eq. (5.29) determines. The utility of such probabilities on the tabletop, however, is predicated on the assumption that the system has been measured to be at large volume in the past. For a closed system (such as the universe), however, external measurements do not exist, and the consistency of conditional probabilities calculated in this way can only be assured by decoherence of the corresponding histories. In other words, physically meaningful probabilities cannot be inferred from transition amplitudes unless the corresponding family of histories is consistent. In the case of the present example, for instance, the probabilities so calculated are only consistent in the limiting case of φ→ ±∞. 
VI. DISCUSSION 
An important conceptual issue in the application of quantum theory to the whole universe is to understand the way in which quantum probabilities can be assigned consistently to various phenomena. Since by definition the universe as a whole is a closed quantum system, one lacks the notion of external observers/apparatus which can be treated classically to “measure” the wavefunction of the universe. The fundamental inadequacy of the Copenhagen interpretation becomes clearly evident when applying quantum theory to the cosmos. The consistent histories framework in the form of Hartle’s generalized quantum mechanics has been advocated precisely to answer these questions for a quantum universe. In this work we have given an explicit example of a Wheeler-DeWitt quantum universe where non-trivial questions about decoherence between alternate histories can be posed and answered and probabilities for various events be computed consistently and rigorously. To our knowledge this work is the first of its kind where consistent probabilities for the occurrence of a singularity in a quantum gravitational model have been calculated without any assumption on the states in the physical Hilbert space. 
We have considered the Wheeler-DeWitt quantization of a flat homogeneous and isotropic universe with a free, massless, minimally coupled scalar field. Though the model is simple, it is non-trivial enough to pose interesting questions. Classically the model has two classes of solutions – expanding with a big bang singularity in the past, and contracting with big crunch singularity in the future. The physical Hilbert space, Dirac observables and their expectation values for this model have been studied recently [22, 23, 30]. The latter importantly showed that generic left- and right-moving Wheeler-DeWitt universes are singular; we extend that result to include superpositions of such states. Using the basic apparatus from these works we have completed its consistent histories analysis and extracted quantum probabilities. In contrast to interpreting the amplitude of the wavefunction heuristically as in previous work on this model, we have succeeded in rigorously deriving explicit formulæ for the quantum probabilities within a consistent framework. With these we were able to answer questions such as “What is the probability that a Wheeler-DeWitt universe ever hits the singularity?” Though one expected the answer to be unity (from intuition of the behavior of the wavefunction in open quantum systems,) it is here for the first time an explicit, internally consistent computation of the probability, taking proper care of the consistency of the corresponding quantum histories, has been shown to give this result. 
An interesting example of such a calculation concerned a quantum state which is a superposition of expanding and contracting universes. Such a state might be regarded as an analog of “Schrödinger’s cat” in quantum cosmology – a superposition of (potentially) macroscopically distinct states. For such states one may be tempted to ask: Because there is an amplitude for the universe to have large volume in the “past” (φ → −∞), and an amplitude for the universe to have large volume in the “future” (φ → +∞), is there not then an amplitude for the universe to have large volume in both the “past” and the “future”? Were it so, one would have shown that for such states there is an amplitude for Wheeler-DeWitt-quantized universes to avoid the cosmological singularity with a “quantum bounce” similar to that which appears in models of loop quantum cosmology [22, 23, 30]. As we have demonstrated, however, a careful consistent histories analysis shows that the answer to this question is “No”. As emphasized in Ref. [17], a “quantum bounce” is inherently a quantum question involving (at least) two slices of “time”, and only has a meaningful quantum answer if the corresponding histories decohere. We show, without making any assumption on 
27 As also in that case, one might expect coupling to other degrees of freedom to lead to decoherence [43–46].
 
the nature of the quantum state, that the corresponding branch wave functions do decohere, and the probability for such a bounce is zero. 
A feature of this analysis was the notion of an emergent time derived from one of the degrees of freedom in the phase space. Here this was taken to be the value of the scalar field, though the scale factor or volume of the universe would have served just as well. This enabled us to pose meaningful questions about expectation values of relational observables – viz. the volume of the universe at a given value of φ, and the momentum of the scalar field, and their probabilities. We found that the probabilities computed from class operators for quantum histories are consistent with expectation values of the Dirac (relational) observables, thus pointing to an overall coherence of the frameworks – the consistent histories approach applied to canonical quantization vs. an analysis purely in terms of relational observables. (We hope to explore further details of this relationship in a future work.) The consistent histories framework, however, enables a significantly more finely-grained study – which, we emphasize, can ask and answer questions simple study of expectation values cannot. 
While the model studied here is very simple, one may hope to employ the framework for construction of the decoherence functional developed in Refs. [3, 8, 13, 15] and here as a template for the consistent histories formulation of more sophisticated quantum gravitational models. Let us now point out the minimum features a model of quantum cosmology in the canonical setting should have for the present analysis to be extendible. One of the key requirements is the availability of the physical Hilbert space, inner product, and dynamics. One must also have available at least one non-trivial observable which can be consistently defined. If the corresponding “relational” Dirac observable can be constructed which correlates values of that observable with other degrees of freedom, it should be possible to frame a coherent consistent histories formulation in the same manner. In particular, it is not essential that the degrees of freedom used to define those correlations be monotonic, as they were in the present example. The presence of an “emergent time”, while convenient, is not essential to the formulation of a consistent histories framework. What matters is the ability to define correlations among degrees of freedom. 
The analysis presented will be extended to study probabilities for the (absence of) singularities in loop quantum cosmology in [21]. For the same model as considered here but in a loop quantization, we will show that the answers turn out to be strikingly different. We will demonstrate within the consistent histories framework that a loop quantum universe never encounters a singularity. The probability that the universe bounces turns out to be unity, thus providing a rigorous and consistent quantum probabilistic interpretation to the results so far inferred from the behavior of expectation values of Dirac observables. 
ACKNOWLEDGMENTS 
D.C. would like to thank the Perimeter Institute, where much of this work was completed, for its repeated hospitality. D.C. would also like to extend his gratitude to Helen Clark for her always gracious hospitality, which enabled significant portions of the writing of this work to be undertaken. P.S. is grateful to Abhay Ashtekar for the suggestion to investigate the consistent histories formalism. Research at the Perimeter Institute is supported by the Government of Canada through Industry Canada and by the Province of Ontario through the Ministry of Research and Innovation. 
[1] M. Gell-Mann and J. B. Hartle, in Proceedings of the 3rd international symposium on the foundations of quantum mechanics in the light of new technology, edited by S. Kobayashi, H. Ezawa, M. Murayama, and S. Nomura (Physical Society of Japan, Tokyo, 1990). 
[2] M. Gell-Mann and J. B. Hartle, in Complexity, Entropy, and the Physics of Information, SFI Studies in the Sciences of Complexity, Vol. VII, edited by W. Zurek (Addison-Wesley, Reading, 1990). 
[3] J. B. Hartle, in Gravitation and Quantizations, Proceedings of the 1992 Les Houches Summer School, edited by B. Julia and J. Zinn-Justin (North Holland, Amsterdam, 1995) arXiv:gr-qc/9304006. 
[4] R. B. Griffiths, J. Stat. Phys., 36, 219 (1984). [5] R. B. Griffiths, Consistent quantum theory (Cambridge University Press, Cambridge, 2008). [6] R. Omnès, J. Stat. Phys., 53, 893 (1988); 53, 933 (1988); 53, 957 (1988); 57, 357 (1989); Ann. Phys., 201, 354 (1990); 
Rev. Mod. Phys., 64, 339 (1992). [7] R. Omnès, The interpretation of quantum mechanics (Princeton University Press, Princeton, 1994). [8] J. B. Hartle, in [47]. [9] J. J. Halliwell, Phys. Rev., D60, 105031 (1999), arXiv:quant-ph/9902008 [quant-ph]. 
[10] J. J. Halliwell and J. Thorwart, Phys. Rev., D64, 124018 (2001), arXiv:gr-qc/0106095 [gr-qc]. [11] J. J. Halliwell and J. Thorwart, Phys. Rev., D65, 104009 (2002), arXiv:gr-qc/0201070 [gr-qc]. [12] J. J. Halliwell and P. Wallden, Phys. Rev., D73, 024011 (2006), arXiv:gr-qc/0509013 [gr-qc]. [13] J. J. Halliwell, Phys. Rev., D80, 124032 (2009), arXiv:0909.2597 [gr-qc].
 
[14] J. B. Hartle and D. Marolf, Phys. Rev., D56, 6247 (1997), arXiv:gr-qc/9703021 [gr-qc]. [15] D. A. Craig and J. B. Hartle, Phys. Rev., D69, 123525 (2004), arXiv:gr-qc/0309117v3 [gr-qc]. [16] C. Anastopoulos and K. Savvidou, Class. Quant. Grav., 22, 1841 (2005), arXiv:gr-qc/0410131 [gr-qc]. [17] D. A. Craig and P. Singh, Found. Phys. (2010), doi:10.1007/s10701-010-9422-6, in press, arXiv:1001.4311v1 [gr-qc]. [18] D. A. Craig and P. Singh, in Quantum Theory: Reconsideration of Foundations – 5, Vol. 1232, edited by A. Krennikhov 
(American Institute of Physics, New York, 2010) proceedings of the fifth Växjö conference on the foundations of quantum mechanics, 14-18 June 2009. 
[19] M. Gell-Mann and J. B. Hartle, Phys. Rev., D47, 3345 (1993), arXiv:gr-qc/9210010 [gr-qc]. [20] J. Halliwell, in [47]. [21] D. A. Craig and P. Singh, “Consistent probabilities in loop quantum cosmology,” (2010), in preparation. [22] A. Ashtekar, T. Pawlowski, and P. Singh, Phys. Rev., D74, 084003 (2006), arXiv:gr-qc/0607039 [gr-qc]. [23] A. Ashtekar, A. Corichi, and P. Singh, Phys. Rev., D77, 024046 (2008), arXiv:0710.3565 [gr-qc]. [24] C. J. Isham and N. Linden, J. Math. Phys., 35, 5452 (1994), arXiv:gr-qc/9405029 [gr-qc]. [25] D. A. Craig, “The geometry of consistency: decohering histories in generalized quantum theory,” (1997), unpublished, 
arXiv:quant-ph/9704031 [quant-ph]. [26] E. Joos, H. D. Zeh, C. Kiefer, D. Giulini, J. Kupsch, and I.-O. Stamatescu, Decoherence and the appearance of a classical 
world in quantum theory, 2nd ed. (Springer-Verlag, Berlin, 2003). [27] M. Schlosshauer, Decoherence and the quantum-to-classical transition (Springer-Verlag, Berlin, 2007). [28] L. Diosi, Phys. Rev. Lett., 92, 170401 (2004), arXiv:quant-ph/0310181 [quant-ph]. [29] R. M. Wald, General Relativity (University of Chicago Press, 1984). [30] A. Ashtekar, T. Pawlowski, and P. Singh, Phys. Rev., D73, 124038 (2006), arXiv:gr-qc/0604013 [gr-qc]. [31] C. Rovelli, Phys. Rev., D65, 124013 (2002), arXiv:gr-qc/0110035. [32] D. Marolf, Class. Quant. Grav., 12, 1199 (1995), arXiv:gr-qc/9404053. [33] B. Dittrich, Class. Quant. Grav., 23, 6155 (2006), arXiv:gr-qc/0507106. [34] A. Ashtekar, J. Lewandowski, D. Marolf, J. Mourao, and T. Thiemann, J. Math. Phys., 36, 6456 (1995), arXiv:gr-
qc/9504018 [gr-qc]. [35] D. Marolf, “Refined algebraic quantization: Systems with a single constraint,” (1995), arXiv:gr-qc/9508015. [36] A. Corichi and P. Singh, Phys. Rev. Lett., 100, 161302 (2008), arXiv:0710.4543 [gr-qc]. [37] N. Yamada and N. Takagi, Prog. Theor. Phys., 85, 985 (1991); 86, 599 (1991); 87, 77 (1992). [38] N. Yamada, Sci. Rep. Tohoku Uni., Series 8, 177 (1992); Phys. Rev., A54, 182 (1996). [39] J. Whelan, Phys. Rev., D50, 6344 (1994), arXiv:gr-qc/9406029. [40] R. Micanek and J. Hartle, Phys. Rev., A54, 3795 (1996), arXiv:quant-ph/9602023. [41] J. B. Hartle, R. Laflamme, and D. Marolf, Phys. Rev., D51, 7007 (1995), arXiv:gr-qc/9410006 [gr-qc]. [42] J. J. Halliwell, Phys. Rev., D58, 105015 (1998), arXiv:quant-ph/9805062; Phys. Rev. Lett., 83, 2481 (1999), arXiv:quant-
ph/9905094. [43] J. J. Halliwell, Phys. Rev., D39, 2912 (1989). [44] T. Padmanabhan, Phys. Rev., D39, 2924 (1989). [45] S. Habib and R. Laflamme, Phys. Rev., D42, 4056 (1990). [46] A. Barvinsky and A. Kamenshchik, Class. Quant. Grav., 7, 2285 (1990); Phys. Rev., D52, 743 (1995). [47] S. Coleman, J. B. Hartle, T. Piran, and S. Weinberg, eds., Quantum cosmology and baby universes: Proceedings of the 
1989 Jerusalem Winter School for Theoretical Physics, Vol. 7 (World Scientific, Singapore, 1991).