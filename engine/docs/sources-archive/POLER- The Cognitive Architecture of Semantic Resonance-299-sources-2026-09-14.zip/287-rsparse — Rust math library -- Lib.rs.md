> Source: https://lib.rs/crates/rsparse

rsparse — Rust math library // Lib.rs 
Lib.rs
› Science › Math
# sparse-linear-systems # sparse-linear-algebra # algebra # linear
rsparse
A Rust library for solving sparse linear systems using direct methods
by Ricard Lado, PhD and 2 contributors
Install
API reference
GitHub repo ( rlado)
18 releases (4 stable)
73 in Math
1,116 downloads per month
Used in 3 crates
MIT license
660KB
2.5K SLoC
rs parse
A Rust library for solving sparse linear systems using direct methods.   
Data structures
CSC matrix ( Sprs )
Triplet matrix ( Trpl )
Features
Convert from dense [ Vec< T>] or Vec< Vec< T>> matrix to CSC sparse matrix Sprs
Convert from sparse to dense Vec< Vec< T>>
Convert from a triplet format matrix Trpl to CSC Sprs
Sparse matrix addition [C=A+B]
Sparse matrix multiplication [C=A*B]
Transpose sparse matrices
Solve sparse linear systems
Solvers
lsolve: Solve a lower triangular system. Solves Lx=b where x and b are dense.
ltsolve: Solve L'x=b where x and b are dense.
usolve: Solve an upper triangular system. Solves Ux=b where x and b are dense
utsolve: Solve U'x=b where x and b are dense
cholsol: A\b solver using Cholesky factorization. Where A is a defined positive Sprs matrix and b is a dense vector
lusol: A\b solver using LU factorization. Where A is a square Sprs matrix and b is a dense vector
qrsol: A\b solver using QR factorization. Where A is a rectangular Sprs matrix and b is a dense vector
Examples
Basic matrix operations
Output:
Solve a linear system
Output:
Documentation
Documentation is available at docs.rs.
Sources
Davis, T. (2006). Direct Methods for Sparse Linear Systems. Society for Industrial and Applied Mathematics. https://doi.org/10.1137/1.9780898718881
CSparse: A Concise Sparse Matrix Package in C
No runtime deps
See also: sprs, nalgebra-sparse, russell_sparse, graphblas_sparse_linear_algebra, rlst, kryst, nalgebra-sparse-linalg, faer_gmres, stacked_linear_algebra_graph, faer-sparse, sprs-rssn
Lib.rs is an unofficial list of Rust/Cargo crates, created by kornelski. It contains data from multiple sources, including heuristics, and manually curated data. Content of this page is not necessarily endorsed by the authors of the crate. This site is not affiliated with nor endorsed by the Rust Project. If something is missing or incorrect, please file a bug.