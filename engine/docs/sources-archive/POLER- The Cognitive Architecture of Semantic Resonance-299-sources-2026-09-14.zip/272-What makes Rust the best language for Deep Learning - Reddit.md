> Source: https://www.reddit.com/r/rust/comments/1bixnh4/what_makes_rust_the_best_language_for_deep/

What makes Rust the best language for Deep Learning : r/rust
Skip to main content What makes Rust the best language for Deep Learning : r/rust
Open menu
Open navigation 
Go to Reddit Home 
r/rust
TRENDING TODAY
Get App
Get the Reddit app
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Navigation Skip to Right Sidebar
Back
 Go to rust
r/rust
• 2y ago
ksyiros
Locked post
Stickied post
Archived post
View post in other languages
Report
What makes Rust the best language for Deep Learning
Recently, several new Deep Learning Frameworks have emerged in Rust, including Burn, dfdx, and Candle. I'd like to offer my perspective on why Rust stands out as the best language for this purpose.
Firstly, a disclaimer: I am the main author of Burn, and I've shared much of the journey of developing the framework on this subreddit. I've outlined our plan to make Burn the fastest deep learning framework by leveraging automatic tensor operation fusion, a technique that typically enhances the performance of static graph frameworks.
Although Burn is an eager framework (similar to Candle and dfdx), it possesses a unique characteristic that has piqued the curiosity of many: all tensor operations are owned, necessitating the cloning of tensors if used multiple times. I've explained that adopting this API enables Burn to track the dynamic lifetime of each tensor, enabling automatic kernel fusion. This feature would not be possible in languages with garbage collectors or when memory is freed when a variable goes out of scope.
It's crucial that memory (or the reference count) is released precisely when it's possible, a capability already inherent in Rust's ownership system. Today, I'm pleased to share our latest blog post ( https://burn.dev/blog/fusion-tensor-operation-streams/) detailing how we leverage this characteristic of the language to make Burn the most flexible and performant framework without relying on static graphs. This technique uses both runtime and compile-time information to heavily optimize GPU operations. While more work is needed before claiming the title of the fastest framework, we're continuously adding more optimizations, and the foundation is solidly in place.
Rust is exceptionally well-suited for building the software infrastructure of AI, and I'm fully committed to contributing to it to the best of my ability! Hopefully, the community is receptive, and it can bring new people into Rust.
Read more
177
· 41
Comments Section
notParticularlyAnony
•
2y ago
Naively I'm curious how it compares to pytorch, as they are relatively mature and have large communities of users. Esp for machine vision applications.
But this does sound very exciting!
36 
ksyiros
OP
• 2y ago
Most vision neural network modules are implemented and we also provide a list of pre-trained models. We are currently adding YOLOX: https://github.com/tracel-ai/models
7 
iamsienna
•
2y ago
Every time I feel like I have a good handle on AI/ML architectures, I'm reminded that I know fuck all. I do find it to be interesting that memory movement is one of your performance pain points; it makes a lot of sense tho! Now I get to go read up on the rest of Burn 🔥
38
sabitm
•
2y ago
Very excited for the future of Rust machine/deep learning ecosystem. Having tried candle with much success with so little effort, I'm optimistic about what comes next!
9
sepease
•
2y ago
Are there any unique advantages with Rust for platforms that utilize shared memory (ie Apple Silicon)?
13
1 more reply 
Trader-One
•
2y ago
There is space for front ends which will provide keras like api and utilize burn as backend.
10 
antimora
•
2y ago
Yes it is possible. Burn is architected to allow this. Burn backends are separate crates. Candle is one of Burn's backends.
1 
Irtexx
•
2y ago
I'm very much looking forward to the day when a rust deep learning crate with a Keras like API is released. As a hobbyist, anything more complex than this is no longer fun to play with. And I think static typing that rust will bring will make it even easier to work with.
1 
matthieum
•
2y ago -(tmp * t * (-x.clone() * x).exp()) + 1.0
I think there's a missed opportunity here, specifically in the x.clone() * x part: a powi(2) operator would allow removing the clone.
5 
ksyiros
OP
• 2y ago
It's actually minus x multiplied by x, so I'm not sure we would carry the sign with x.powi(2).
1
Continue this thread
Shnatsel
•
2y ago
How does this compare to tinygrad? They claim to also have operation fusion behind the scenes and an easy-to-use Torch-like developer API.
3 
ksyiros
OP
• 2y ago
I'm not aware of how the TinyGrad internals work, but our process differs. We made Burn run on Libtorch before creating a custom backend with operation fusion, so that we can benchmark and compare speedups effectively. Also, TinyGrad has a strong focus on minimizing the number of lines of code to reduce complexity. However, I believe well-defined abstractions are superior in that aspect. In terms of speed, I think TinyGrad is still behind PyTorch, but our future CUDA backend should be very close if not faster than Libtorch, since we're going to use extra instructions to leverage tensor cores. This should result in performance similar to Libtorch CUDA, but with more fused operations as we add more optimizations.
4 
blackconqueror
•
2y ago
I want to know the difference too.
1
crusoe
•
2y ago
I have a sneaking suspicion that interaction nets along with the new MS so called 1 bit quant would really allow for deep simplification of NN. I wish I had the skills to understand enough to try and at least impl some trivial version.
4
tower120
•
2y ago
I would like to ask something loosely related - about matrices usage in DL.
I was told that DL rely heavily on sparse matrices. And I would like to ask - is there are places where you do something with sparse matrices on a CPU (besides uploading)? Or it's all on a GPU side?
2
ExitFederal1763
•
2y ago
I've encountered several questions similar to "What motivates users to transition to Rust in data science?" This response effectively clarifies the confusion!
2 
[deleted]
•
2y ago
The check of matrix shapes at compile time is missing in your library. It's very annoying.
Your library has no comparative advantage compared to pytorch. What is appalling in rust is the low-level abstraction. A good rust library should offer a more fine-grained control over the cuda runtime like forking streams,… At the moment everything is throwned to the main cuda stream. It would be great also to decouple the dtype of the data and the dtype of the matrix multiplication as cublas allows it.
1 
ksyiros
OP
• 2y ago
Const generics are not there yet and not ready for stable Rust, and while we do have an experimental feature for static tensor shape assertions, it's not very user-friendly and would worsen the DX more than it would help. You can look at our experiment here: https://github.com/tracel-ai/burn/blob/main/examples/named-tensor/src/lib.rs.
Despite this, Burn offers lots of competitive advantages. For instance, you can seamlessly swap between different backends and customize them with backend extensions. Our JIT compiler generates custom GPU kernels, and we support multithreading at the tensor level. Although we don't currently have a native CUDA backend (which is expected for the next release), we will eventually support multiple CUDA streams. We already support multiple streams of execution with our fusion backend, using native threads as stream indicators.
The core philosophy of Burn is to have a simple API that does almost all optimizations for you, which are often specific for each target platform, so a true multi-platform framework must do that. If you disagree with this approach and prefer a framework that places more responsibility on users for optimizing their models, Burn may not be the best fit for you.
TL;DR: Burn isn't a "low-level" framework that shifts the optimization burden onto users. Rather, we provide APIs designed to optimize models automatically.
3
Continue this thread
False_Register_8518
•
2y ago
As an ML engineer with experience in Python, I've been considering switching to Rust for its performance and safety benefits. However, the maturity of ML libraries in Rust has given me pause. I'm particularly interested in the burn library, which seems promising but is still in development.
Given that I'm accustomed to the well-established PyTorch ecosystem, the idea of transitioning to Rust involves a steep learning curve, not just for the language itself but also for adapting to its evolving ML frameworks. My main concerns are around whether burn will soon support native CUDA and offer performance on par with PyTorch.
Is it worth investing the time to make this switch now, assuming that burn and similar Rust libraries will mature and achieve comparable performance to PyTorch in the near future? Any insights or experiences from others who have ventured into Rust for ML would be greatly appreciated!
3 
sascharobi
•
2y ago
Burn and Candle don't support CUDA yet?
1
1 more reply
[deleted]
•
2y ago
Comment deleted by user 
ksyiros
OP
• 2y ago
The type system of Rust gives the framework more guarantee to perform memory optimizations, so fewer GPU reads, fewer GPU writes, and fewer GPU allocations. The speed of Rust only affect the framework overhead, which isn't the bottleneck even with Python.
6
Continue this thread
4 more replies 
crazyjoker96
•
2y ago
imho is the motivation that puts you to understand why your code does not work
0
Related Answers Section
Related Answers
Best Rust deep learning frameworks
Rust for data science and machine learning
Overview of Burn, dfdx, and Candle in Rust
Machine learning libraries available in Rust
Using Burn for tensor operations and autodiff
New to Reddit?
Create your account and connect with a world of communities.
Continue with Email
Continue With Phone Number
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy.
More posts you may like
Advanced Rust users, what is the most valuable skill to become more productive with the language?  r/rust • 23d ago [
Advanced Rust users, what is the most valuable skill to become more productive with the language?
](https://www.reddit.com/r/rust/comments/1qu5u50/advanced_rust_users_what_is_the_most_valuable/) 202 upvotes · 103 comments
Best way to learn Rust?  r/rust • 5mo ago [
Best way to learn Rust?
](https://www.reddit.com/r/rust/comments/1nvrl36/best_way_to_learn_rust/) 37 upvotes · 40 comments
Is the Rust Programming Language Book a good entry point for beginners?  r/rust • 1mo ago [
Is the Rust Programming Language Book a good entry point for beginners?
](https://www.reddit.com/r/rust/comments/1qblqsm/is_the_rust_programming_language_book_a_good/) 29 upvotes · 41 comments
Rust ML/deep learning frameworks  r/rust • 2y ago [
Rust ML/deep learning frameworks
](https://www.reddit.com/r/rust/comments/1crvvv1/rust_mldeep_learning_frameworks/) 4 upvotes · 5 comments
Rust as a language for Data Engineering  r/rust • 1mo ago [
Rust as a language for Data Engineering
](https://www.reddit.com/r/rust/comments/1qonyu2/rust_as_a_language_for_data_engineering/) 34 upvotes · 29 comments
Why I Choose RUST as my backend language  r/rust • 8mo ago [
Why I Choose RUST as my backend language
](https://www.reddit.com/r/rust/comments/1lfayze/why_i_choose_rust_as_my_backend_language/) 83 upvotes · 30 comments
Is anyone doing Machine Learning in Rust?  r/rust • 3y ago [
Is anyone doing Machine Learning in Rust?
](https://www.reddit.com/r/rust/comments/13eij5q/is_anyone_doing_machine_learning_in_rust/) 85 upvotes · 39 comments
Rust is a low-level systems language (not!)  r/rust • 5mo ago [
Rust is a low-level systems language (not!)
](https://www.reddit.com/r/rust/comments/1o4fmlg/rust_is_a_lowlevel_systems_language_not/) 269 upvotes · 146 comments
Rust can be the language of the AI era  r/rust • 2mo ago [
Rust can be the language of the AI era
](https://www.reddit.com/r/rust/comments/1q24aau/rust_can_be_the_language_of_the_ai_era/) 26 comments
Running python based Deep learning models in Rust  r/rust • 2y ago [
Running python based Deep learning models in Rust
](https://www.reddit.com/r/rust/comments/1bosge8/running_python_based_deep_learning_models_in_rust/) 2 upvotes · 5 comments
Which book do you feel is best, for learning Rust?  r/rust • 4mo ago [
Which book do you feel is best, for learning Rust?
](https://www.reddit.com/r/rust/comments/1otol7g/which_book_do_you_feel_is_best_for_learning_rust/) 21 comments
Does it make sense to learn Rust if you're into ML?  r/rust • 7mo ago [
Does it make sense to learn Rust if you're into ML?
](https://www.reddit.com/r/rust/comments/1m713d0/does_it_make_sense_to_learn_rust_if_youre_into_ml/) 37 upvotes · 55 comments
How was your experience learning Rust?  r/rust • 3mo ago [
How was your experience learning Rust?
](https://www.reddit.com/r/rust/comments/1p7u5s3/how_was_your_experience_learning_rust/) 35 upvotes · 56 comments
How to deal with deep rust?  r/airsoft • 2y ago [
How to deal with deep rust?
](https://www.reddit.com/r/airsoft/comments/1e7skgo/how_to_deal_with_deep_rust/)  3 450 upvotes · 114 comments
best way to learn rust?  r/rust • 2mo ago [
best way to learn rust?
](https://www.reddit.com/r/rust/comments/1pzp7um/best_way_to_learn_rust/) 30 comments
Deep Learning in Rust: Burn 0.4.0 released and plans for 2023  r/rust • 3y ago [
Deep Learning in Rust: Burn 0.4.0 released and plans for 2023
](https://www.reddit.com/r/rust/comments/101fpkl/deep_learning_in_rust_burn_040_released_and_plans/) 195 upvotes · 34 comments
Advice for removing deep rust on a large surface  r/metalworking • 2y ago [
Advice for removing deep rust on a large surface
](https://www.reddit.com/r/metalworking/comments/1al5ngo/advice_for_removing_deep_rust_on_a_large_surface/)  3 325 upvotes · 487 comments
How do remove deep rust ?  r/howto • 7y ago [
How do remove deep rust ?
](https://www.reddit.com/r/howto/comments/ar5ali/how_do_remove_deep_rust/)  9 upvotes · 10 comments
I just learned something that may be obvious to Rust experts  r/rust • 4mo ago [
I just learned something that may be obvious to Rust experts
](https://www.reddit.com/r/rust/comments/1omm4jk/i_just_learned_something_that_may_be_obvious_to/) 116 upvotes · 66 comments
Burn 0.14.0 Released: The First Fully Rust-Native Deep Learning Framework  r/rust • 2y ago [
Burn 0.14.0 Released: The First Fully Rust-Native Deep Learning Framework
](https://www.reddit.com/r/rust/comments/1f2n1iq/burn_0140_released_the_first_fully_rustnative/) 362 upvotes · 69 comments
Learning How to Program in Rust  r/rust • 21d ago [
Learning How to Program in Rust
](https://www.reddit.com/r/rust/comments/1qw9tkp/learning_how_to_program_in_rust/) 16 upvotes · 20 comments
What did you build while learning Rust ?  r/rust • 5mo ago [
What did you build while learning Rust ?
](https://www.reddit.com/r/rust/comments/1o3w69y/what_did_you_build_while_learning_rust/) 100 upvotes · 109 comments
What do you develop with Rust?  r/rust • 8mo ago [
What do you develop with Rust?
](https://www.reddit.com/r/rust/comments/1lyo284/what_do_you_develop_with_rust/) 231 upvotes · 262 comments
dfdx v0.10.0 - deep learning now with even more const generic goodness  r/rust • 3y ago [
dfdx v0.10.0 - deep learning now with even more const generic goodness
](https://www.reddit.com/r/rust/comments/yj8kn9/dfdx_v0100_deep_learning_now_with_even_more_const/) 89 upvotes · 13 comments
[D] Who is using Rust for Machine learning in production/research?  r/rust • 6y ago [
[D] Who is using Rust for Machine learning in production/research?
](https://www.reddit.com/r/rust/comments/fvehyq/d_who_is_using_rust_for_machine_learning_in/) 79 upvotes · 25 comments
View Post in
繁體中文
Русский
Community Info Section
r/rust
Join
The Rust Programming Language
A place for all things related to the Rust programming language—an open-source systems language that emphasizes performance, reliability, and productivity.
Show more
Public
Anyone can view, post, and comment to this community
Top Posts
Reddit reReddit: Top posts of March 19, 2024
Reddit reReddit: Top posts of March 2024
Reddit reReddit: Top posts of 2024
Reddit Rules Privacy Policy User Agreement Your Privacy Choices Accessibility Reddit, Inc. © 2026. All rights reserved.
Expand Navigation
Expand Navigation
Collapse Navigation
Collapse Navigation 
0cAFcWeA5tbU04geJ7vkLmvcQPzI_LNOkFiVJ9R07vQjNHe1tCcukYGirRt7AYPDp1KRfo-WSexeOtfGzMNdvm9OxKqM4Ib03UMm41SGV8gcMqXfywCIy97svT2NomvHqkMsy7IOJDF1oBtZekrV7HZwaz8ajQVsELEoXaDjPZbo1pG0fl6AFyuf-b7DsnkBKMqQqOy4tWwQe_mEoOtNMGIELwAgOSLd7VNBIkYw3Y0qQaaIFLgpNrofd4a_Zk0DjhXjThp8vl-IORSqhq8qfNeQ7hgw9-mvDAQ0VmgEJQSK9cVL5ILsXrd9BaSIXGcfAFTxctr4v8bUXK_bRe-aj5woLdJHjEZRR_r2rAzUoJFQOPFES_PZDNs2BkUL0FWWVT3Yyw5zK2lzPG79jBFlLjx-iWFBvpXwetJ3EAK7smvoKutbySUMPP7lnggaq7raL-z3BVEAvao_owfk0On8gKNyt1047M_wI0xSoQx3d0dcEI8mLVsAAlOYTim6omFNPGOjeACZ5NfxME7z4Ztpkeh0-XVZ_EFL-AB5JThpr2WStTK-hEMFf-yyK6SPbhz4lwVxjklSysI7wRCfQGlT9237JBz7o6vx0PP32Ei9uxtnGsM8iZIXgX09FvGHVM13LxnotYX9MVlC--tsKzhltYAchVK2hoBEx68b7Wp_hPN0K5jJ9s2S6U-ZV2bGXLAGIbrnF8ckPYnxjSTW1IVwfwMVIvlO3odWvXTV1_2_U5V1ZteWuGXv6bjQkCVYvb9H9QU7MDras_mkP7piND72R7bEV5i9WcNbrmLzq_vv6NIjDhP3aYkdkEIZWYAObTSIYYfIO8V59OrYOXnqR_mmA8Prd9AInft_gVIFJS9snh-Iw5j4nV_1LCi99ltI93qHY1A3gSnmoVBK3qpYPFmBdNN5_03ph_C9rFZ6pYwPfiZZgHUvgNtYrjOnsF526w_GzKjOv6CuwmZuePZmC98TLsSfVesw75_R8WG7rIMW_D76yyk794ykV42XbyYAF3nLV4X5ff4ahZmnpSJbvqgDpMDJHEWj3ENqE4A78oWiBqvxuh2zcsclwQTKXknEUj6BNOhqdO4DfwMzoVc_d4tonjaeqkzzU1PvZgt8Plc6xIdYYqV1ZgieB7SVfYqwe95Z0uejhYC-t517Mv4mldVB08b5N-0-0CowyGqDy11PNafNj1X9QBCAkhlaAN-DtJoARWdWDp7a2494TbM6svjE-asIkIH9x2Ao48UycoeOOJY4WJWs0pk4drVU_i_8ThhdpGp3yO974nHRnJGS7vZDMIWrp1BCX2bwd9AO3Gqf8Xju0xgFMa4Th8Le1Hnrarrl2UDRjV-442vQIAb14U-7ic6ydNMkdFGJc3IpWgDvuJu1qyk-bW4QKi62hAIw3e4_F9bAj_eNeszWiqvejW4QKgbHKaF7dQprb-JUg6hNknNHm3Xo7blg-hHB3fcRTSTadsoRAPTl3roLHfTIbeLS4WvqdhJYAi0i-GXWoIH-86GMZNSJ1tQauxM8ArurgJdLFFvK2HoLh4zJQGQHTidcEIxXOz195yuxCj625wJ6mh9WfoC6SVn1FDCvUUbN8UmTzMCgT1OGamvBdX95cdI67bcUAFMVnF_VTSgOCyS_8UiIBFjmSADffclsYcIs48JCwnVXRrd89QvY3tFplQx8u_gi4u7S-uJrhayLGG34N09QeW9k5AqJCO5VQdhj288PhSw5tGZzS-_GcNmlKy4bTKjly1x2-gnWPLsk0V3Ad8610hpt56zhBM4a4Swvhx1UMPB_WPXTU1efgHaDl8wVEaKHOJ4c_Uexo2LC8BuZUQoBUg4_kTyNN1A_wr_OiJqcorkL7GekeLsvq_FxVmS-IVY5ukce8JEetArNfFp48DXbvewKisj69KY-cn8UivITSrKpa5foM__xY3Wna8QirntRhjeZONqsgnX2bd7IadgOXgGghCk2oZ9An7hem5jy_V8QOpKVnku22auOoatSt8MaSl_t2ymRxj_V_3ayCH6d7AA3XUJDxZgeTKMudGDDa1BfxRviIXX1ITjS5zdoIOlvrucziuNMfm8MQ-jEVI-rpvzrijz0ztlto5mLMuceOEz9-4OFq_MxAemZqBkhKVUdUj-C2pB1kzwOToSEFUDyfgRZXexwjbXu8