> Source: https://www.lct.jussieu.fr/pagesperso/toulouse/enseignement/presentation_wft.pdf

Quantitative quantum chemistry: Introduction to wave-function methods 
Julien Toulouse Laboratoire de Chimie Théorique 
Sorbonne Université and CNRS, Paris, France Institut Universitaire de France 
Course 5C208 of Master 2 Chemistry Sorbonne Université, Paris 
www.lct.jussieu.fr/pagesperso/toulouse/enseignement/presentation_wft.pdf
 
Understanding the different quantum-chemistry wave-function methods is important for: 
 improving them and developing new ones; 
 using them in applications in an appropriate way. 
Recommended books: 
 J.-L. Rivail, Éléments de chimie quantique à l’usage des chimistes, EDP Sciences / CNRS Editions, 1999. 
 G. Berthier, Nécessaire de chimie théorique, Ellipses, 2009. 
 A. Szabo and N. S. Ostlund, Modern Quantum Chemistry, Dover Publications Inc., NY, 1996. 
 T. Helgaker, P. Jørgensen, J. Olsen, Molecular Electronic-Structure Theory, Wiley, 2002. 
My lecture notes: 
 M1 course: www.lct.jussieu.fr/pagesperso/toulouse/enseignement/introduction_qc.pdf 
 M2 course: www.lct.jussieu.fr/pagesperso/toulouse/enseignement/introduction_pt_cc.pdf 
 
1 Introduction 
2 The Hartree-Fock method 
3 Overview of post-Hartree-Fock methods 
4 Configuration interaction 
5 Perturbation theory 
6 Coupled-cluster theory 
7 Appendix 
 
1 Introduction Quantum many-electron problem The two families of electronic-structure methods 
 
 We consider an N-electron system (atom, molecule, solid) in the Born-Oppenheimer and non-relativistic approximations. 
 The electronic Hamiltonian in the position representation is, in atomic units, 
Ĥ = 
N∑ 
i 
ĥ(ri ) + 1 
2 
N∑ 
i 
N∑ 
j 6=i 
1 
|ri − rj | 
where ĥ(ri ) = −(1/2)∇2 ri + vne(ri ) is the one-electron Hamiltonian including the 
nuclei-electron interaction vne(ri ) = −∑ 
α Zα/|ri − Rα|.  Stationary states satisfy the time-independent Schrödinger equation 
ĤΨ(x1, x2, ..., xN) = EΨ(x1, x2, ..., xN) 
where Ψ(x1, x2, ..., xN) is a wave function written with space-spin coordinates xi = (ri , ωi ) (with ri ∈ R 
3 and ωi ∈ {↑,↓}) and E is the associated energy. 
 Because electrons are fermions, the wave function must be antisymmetric with respect to the exchange of two space-spin coordinates 
Ψ(..., xi , ..., xj , ...) = −Ψ(..., xj , ..., xi , ...) 
 Using Dirac bra-ket notations, we write 
 
 
 The ground-state electronic energy E0 can be expressed with the variational principle 
E0 = min Ψ 
〈Ψ|Ĥ|Ψ〉 
where the minimization is over all N-electron antisymmetric wave functions Ψ normalized to unity 〈Ψ|Ψ〉 = 1, and we recall that 
〈Ψ|Ĥ|Ψ〉 = ∫ ∫ 
· · · ∫ 
Ψ∗(x1, · · · , xN)ĤΨ(x1, · · · , xN) dx1 · · · dxN 
 Properties (such as dipole moments or optical spectra) can be essentially obtained as derivatives of the ground-state energy with respect to a perturbation. 
 For systems containing heavy atoms, we need to include relativistic effects, e.g. using the four-component Dirac Hamiltonian. 
 For photochemistry studies, we sometimes need to go beyond the Born-Oppenheimer approximation, e.g. calculating non-adiabatic couplings (or vibronic couplings) between the electronic and nuclear vibrational states. 
 We aim at about 1% accuracy on energy differences and other properties. 
 
1 Introduction Quantum many-electron problem The two families of electronic-structure methods 
 
 There are two main families of computational electronic-structure methods: wave-function methods and density-functional theory. 
 Wave-function methods directly try to approximate the wave function of a state of the 
system. 
 A hierachy of methods: Hartree-Fock, Configuration interaction, Perturbation theory, Coupled-cluster theory, ... 
 In principle, systematically improvable up to high accuracy  But computationally costly 
 Density-functional theory is based on a reformulation of the problem by expressing the 
energy as a functional of the one-electron density. 
 A plethora of approximate density functionals  Reasonably low computational cost  But not systematically improvable 
 Both wave-function methods and density-functional theory are still actively developed to improve accuracy and/or lower the computational cost. 
 We may add a less used yet powerful family of methods known as quantum Monte Carlo which use stochastic techniques to solve the Schrödinger equation. 
 
2 The Hartree-Fock method The Hartree-Fock wave function and energy The Hartree-Fock equations and orbital energies Spin symmetry: UHF and RHF RHF calculations in a basis set Examples: He atom and H2 molecule The electron correlation energy 
 
 The Hartree-Fock (HF) method consists in approximating the ground-state wave function Ψ0 as an antisymmetrized product of N spin orbitals {χi (x)}, denoted by Φ0, 
Φ0(x1, x2, ..., xN) = A [χ1(x1)χ2(x2) · · ·χN(xN)] 
with the antisymmetrizer A = 1/ √ N! 
∑N! n=1(−1)pn Pn where the sum is over the N! 
permutations Pn of the space-spin coordinates {x1, ..., xN} and pn is the number of pair inversions in Pn. 
 Φ0(x1, x2, ..., xN) can be conveniently expressed as a Slater determinant 
Φ0(x1, x2, ..., xN) = 1√ N! 
∣ ∣ ∣ ∣ ∣ ∣ ∣ ∣ ∣ 
χ1(x1) χ2(x1) · · · χN(x1) χ1(x2) χ2(x2) · · · χN(x2) 
... ... 
. . . ... 
χ1(xN) χ2(xN) · · · χN(xN) 
∣ ∣ ∣ ∣ ∣ ∣ ∣ ∣ ∣ 
 Often, shorthand notations are used: |Φ0〉 ≡ |χ1 χ2 · · · χN〉 ≡ |1 2 · · · N〉  The spin orbitals are usually written as the product a spatial orbital ψi (r) and a spin 
function α(ω) or β(ω) 
χi (x) = ψi (r)α(ω) or χi (x) = ψi (r)β(ω) 
with α(↑) = 1, α(↓) = 0 and β(↑) = 0, β(↓) = 1. 
 ∫ 
 
 The HF electronic energy is written in terms of integrals over these spin orbitals (using Slater’s rules for calculating expectation values over Slater determinants) 
EHF[{χa}] = 〈Φ0|Ĥ|Φ0〉 = N∑ 
a 
haa + 1 
2 
N∑ 
a 
N∑ 
b 
〈ab||ab〉 
where a and b refer to occupied spin orbitals in Φ0, haa are the one-electron integrals 
haa = 〈χa|ĥ|χa〉 = ∫ 
dx χ∗ a (x) ĥ χa(x) 
and 〈ab||ab〉 = 〈ab|ab〉 − 〈ab|ba〉 are the antisymmetrized two-electron integrals with 
〈ij |kl〉 = x 
dx1dx2 χ∗ i (x1)χ 
∗ j (x2)χk(x1)χl(x2) 
|r1 − r2| (in physicists’ notation) 
 It is important to remember that the antisymmetrized integral 〈ab||ab〉 includes a direct contribution 〈ab|ab〉 and an exchange contribution 〈ab|ba〉. 
 The spin orbitals are determined by minimizing the HF energy subject to the spin-orbital orthonormalization constraints 
EHF = min {χa} 
 
EHF[{χa}] 
 
2 The Hartree-Fock method The Hartree-Fock wave function and energy The Hartree-Fock equations and orbital energies Spin symmetry: UHF and RHF RHF calculations in a basis set Examples: He atom and H2 molecule The electron correlation energy 
 
 Using the method of Lagrange multipliers for the constrained minimization, we introduce the Lagrangian 
L[{χa}] = EHF[{χa}]− N∑ 
a 
εa (〈χa|χa〉 − 1) 
where εa is the Lagrange multiplier for the normalization constraint 〈χa|χa〉 = 1. 
Remark: To derive the equations, we can momentarily drop the orthogonality constraints 
〈χa|χb〉 = 0 for a 6= b. 
 The Lagrangian must be stationary with respect to variations of the spin orbitals χa(x) 
δL[{χa}] δχ∗ 
a (x) = 0 
 Mathematical note: For a functional L : χ 7→ L[χ] of the function χ : x 7→ χ(x), an infinitesimal variation δχ of χ leads to an infinitesimal variation of L which can be expressed as 
δL[χ] = 
∫ δL[χ] 
δχ(x) δχ(x)dx 
This defines the functional derivative of L[χ] with respect to χ(x): δL[χ] 
 
 
 The stationary conditions lead to the (canonical) HF eigenvalue equations 
f̂ χi (x) = εiχi (x) 
giving occupied and virtual HF spin orbitals χi (x) and associated orbital energies εi . 
 The one-electron HF Hamiltonian or Fock operator is 
f̂ = ĥ + v̂HF 
where v̂HF is the one-electron HF potential operator 
v̂HF = 
N∑ 
a 
Ĵa − K̂a 
composed of a Coulomb (or Hartree) operator and an exchange (or Fock) operator 
Ĵaχi (x1) = 
∫ 
dx2 χ∗ a (x2)χa(x2) 
|r1 − r2| χi (x1) and K̂aχi (x1) = 
∫ 
dx2 χ∗ a (x2)χi (x2) 
|r1 − r2| χa(x1) 
 The HF potential is a mean-field potential approximating the effect of the two-electron interaction (1/2) 
∑N 
i 
∑N 
j 6=i 1/|ri − rj | in an average way. 
 Since the HF potential depends the spin orbitals, the HF equations are a set of nonlinear integro-differential equations that must be solved iteratively. 
 
 
 The (canonical) HF (occupied or virtual) orbital energies are 
εi = 〈χi |f̂ |χi 〉 = ∫ 
χ∗ i (x) f̂ χi (x)dx = hii + 
N∑ 
a 
〈ia||ia〉 
 To find the meaning of εi , let us remove an electron from the occupied spin orbital c. Without relaxation of the orbitals, the new Slater determinant is 
|ΦN−1 c 〉 = âc |Φ0〉 = |1 · · · (c − 1) (c + 1) · · · N〉 
where âc is the annihilation operator of spin orbital c. 
 The HF ionization potential (IP) for spin orbital c is then found to be 
IPc = 〈ΦN−1 c |Ĥ|ΦN−1 
c 〉 − EHF = N∑ 
a 6=c 
haa + 1 
2 
N∑ 
a 6=c 
N∑ 
b 6=c 
〈ab||ab〉 − EHF 
= −hcc − 1 
2 
N∑ 
a 6=c 
〈ac||ac〉 − 1 
2 
N∑ 
b 6=c 
〈cb||cb〉 = −hcc − N∑ 
a 
〈ac||ac〉 
 We arrive at Koopmans’ theorem for an occupied spin orbital c: IPc = −εc 
 Similarly, Koopmans’ theorem states that the HF electron affinity (EA) for the virtual spin orbital r , i.e. EAr = EHF − 〈ΦN+1 
r |Ĥ|ΦN+1 r 〉 with |ΦN+1 
r 〉 = â†r |Φ0〉 where â†r is the creation operator for r , is given by 
 
 
2 The Hartree-Fock method The Hartree-Fock wave function and energy The Hartree-Fock equations and orbital energies Spin symmetry: UHF and RHF RHF calculations in a basis set Examples: He atom and H2 molecule The electron correlation energy 
 
 For an N-electron system, the total spin operator is Ŝ = ∑N 
i ŝi , where ŝi is the spin operator for electron i . 
 The spin operators Ŝz and Ŝ2 commute with the nonrelativistic Hamiltonian, [Ĥ, Ŝz ] = 0 and [Ĥ, Ŝ2] = 0, i.e. Ŝz and Ŝ2 represent symmetries of the system. 
 This implies that we can choose the eigenstates |Ψ〉 of H as simultaneously eigenstates of Ŝz and Ŝ2: 
Ĥ|Ψ〉 = E |Ψ〉 and Ŝz |Ψ〉 = MS |Ψ〉 and Ŝ 2|Ψ〉 = S(S + 1)|Ψ〉 
 So far, we have considered a HF Slater determinant of the form |ΦUHF 0 〉 = |χ1χ2 · · ·χN〉 
where each spin orbital is of the form χi = ψiα or χi = ψiβ but without any restrictions on the spatial orbitals of different spins. 
=⇒ This is called (spin-)unrestricted Hartree-Fock (UHF). 
 The UHF Slater determinant is an eigenstate of Ŝz , but in general not an eigenstate of Ŝ2 
Ŝz |ΦUHF 0 〉 = MS |ΦUHF 
0 〉 and Ŝ 2|ΦUHF 
0 〉 6= S(S + 1)|ΦUHF 0 〉 
 Thus, with UHF we generally have spin-symmetry breaking and the quantity 〈ΦUHF 
0 |Ŝ2|ΦUHF 0 〉 − S(S + 1) measures spin contamination (for a state of exact spin S). 
 
 In (spin-)restricted Hartree-Fock (RHF) for closed-shell states, the RHF Slater determinant is 
|ΦRHF 0 〉 = |ψ1α ψ1β ψ2α ψ2β · · ·ψN/2α ψN/2β〉 ≡ |1 1̄ 2 2̄ · · ·N/2 N/2〉 
i.e., we have N/2 pairs of spin orbitals sharing the same spatial orbital. 
 This RHF determinant is a proper eigenstate of both Ŝz and Ŝ2 
Ŝz |ΦRHF 0 〉 = MS |ΦRHF 
0 〉 and Ŝ 2|ΦRHF 
0 〉 = S(S + 1)|ΦRHF 0 〉 
with MS = 0 and S = 0, i.e. it is a spin singlet. 
 By summing over the spin coordinates, we find the closed-shell RHF energy 
ERHF = 2 
N/2 ∑ 
a 
haa + 
N/2 ∑ 
a 
N/2 ∑ 
b 
( 
2 〈ab|ab〉 ︸ ︷︷ ︸ 
Jab 
−〈ab|ba〉 ︸ ︷︷ ︸ 
Kab 
) 
where now a and b refer to occupied spatial orbitals, and we use the same notation as before for the one-electron and two-electron integrals now in terms of the spatial orbitals 
haa = 
∫ 
dr ψ∗ a (r) ĥ ψa(r) and 〈ij |kl〉 = 
x 
dr1dr2 ψ∗ 
i (r1)ψ ∗ j (r2)ψk(r1)ψl(r2) 
|r1 − r2| 
 Note that chemists’ notation is also often used: (ik|jl) = 〈ij |kl〉  Jab = 〈ab|ab〉 and Kab = 〈ab|ba〉 are the Coulomb and exchange integrals, respectively. 
 
 The closed-shell RHF equations are 
f̂ ψi (r) = εiψi (r) 
where f̂ is now the closed-shell Fock operator 
f̂ = ĥ + 
N/2 ∑ 
a 
2Ĵa − K̂a 
and Ĵa and K̂a are the Coulomb and exchange operators in terms of spatial orbitals 
Ĵaψi (r1) = 
∫ 
dr2 ψ∗ 
a (r2)ψa(r2) 
|r1 − r2| ψi (r1) and K̂aψi (r1) = 
∫ 
dr2 ψ∗ 
a (r2)ψi (r2) 
|r1 − r2| ψa(r1) 
 The (canonical) closed-shell RHF orbital energies are 
εi = 〈ψi |f̂ |ψi 〉 = ∫ 
ψ∗ i (r) f̂ ψi (r)dr = hii + 
N/2 ∑ 
a 
2Jia − Kia 
 Remark: for open-shell states, if we still use pairs of spin-orbitals sharing the same spatial orbital, we obtain (spin-)restricted open-shell Hartree-Fock (ROHF). 
 
2 The Hartree-Fock method The Hartree-Fock wave function and energy The Hartree-Fock equations and orbital energies Spin symmetry: UHF and RHF RHF calculations in a basis set Examples: He atom and H2 molecule The electron correlation energy 
 
 The spatial orbitals are expanded on a basis set {φµ(r)}µ=1,...,K 
ψi (r) = K∑ 
µ 
Cµiφµ(r) 
 In the basis, the RHF equations take the form a self-consistent generalized eigenvalue matrix equation F Ci = εi S Ci 
where Fµν = ∫ φ∗ µ(r) f̂ φν(r)dr are the elements of the closed-shell Fock matrix and 
Sµν = ∫ φ∗ µ(r)φν(r)dr are the elements of the overlap matrix. 
 The elements of the closed-shell Fock matrix are 
Fµν = H core µν + 
K∑ 
λ 
K∑ 
σ 
Pλσ 
( 
〈µσ|νλ〉 − 1 
2 〈µσ|λν〉 
) 
where Hcore µν = 
∫ φ∗ µ(r)ĥφν(r)dr are the elements of the one-electron Hamiltonian and 
Pλσ = 2 ∑N/2 
a CλaC ∗ σa are the elements of closed-shell density matrix. 
 In practice, we use atom-centered Gaussian-type orbital (GTO) basis sets 
φµ(r) = ∑ 
p 
dpµ gp(r) with gp(r) = Np r ℓp e 
−αp r 2 
Y mp 
ℓp (θ, φ) 
using spherical coordinates r = (r , θ, φ) around the nucleus center. 
 
 
2 The Hartree-Fock method The Hartree-Fock wave function and energy The Hartree-Fock equations and orbital energies Spin symmetry: UHF and RHF RHF calculations in a basis set Examples: He atom and H2 molecule The electron correlation energy 
 
 The ground-state RHF wave function of He atom is |ΦRHF 0 〉 = |1 1̄〉 , i.e. there is only 
one spatial (1s) orbital ψ1(r) doubly occupied by two electrons of opposite spins. 
 The ground-state RHF energy is 
ERHF = 2h11 + 2J11 − K11 = 2h11 + J11 
where we have used K11 = J11 = 〈11|11〉 = (11|11).  The occupied (1s) orbital energy is 
ε1 = h11 + 2J11 − K11 = h11 + J11 
and the first virtual (2s) orbital energy is 
ε2 = h22 + 2J12 − K12 
 In the complete basis set (CBS) limit, the RHF energy is 
ERHF = −2.8617... > Eexact = −2.9037... hartree 
=⇒ we are missing dynamic (or weak) electron correlation. 
and the occupied (1s) orbital energy is 
ε1 = −0.9180... vs IPexact = 0.9037... hartree 
=⇒ we are missing electron correlation for He and orbital relaxation for He+. 
 H2 
 We consider the H2 molecule with a distance R between the two protons Ha and Hb. 
 We work in a minimal basis set {φa(r), φb(r)}, composed of two identical 1s functions centered on Ha and Hb, respectively. 
 The ground-state RHF wave function is |ΦRHF 0 〉 = |1 1̄〉 ≡ |σgσg〉 where ψ1(r) ≡ ψσg(r) 
is the doubly occupied σg bonding orbital. 
 The ground-state UHF wave function is |ΦUHF 0 〉 = |ψ1α ψ2β〉 where ψ1(r) and ψ2(r) 
are allowed to be different. 
 Comparison RHF vs. UHF: 
-1.2 
-1.1 
-1.0 
-0.9 
-0.8 
-0.7 
-0.6 
-0.5 
-0.4 
 1  2  3  4  5  6 
 
 
 
 
 
 
Internuclear distance (bohr) 
RHF UHF 
Exact  Around the equilibrium, RHF = UHF 
and we are missing dynamic (or weak) correlation. 
 At dissociation, EUHF < ERHF, and RHF is missing static (or strong) correlation. 
 H2 
 In the dissociation limit (R → ∞), we have 
ψσg(r) = 1√ 2 (φa(r) + φb(r)) 
and so the RHF wave function becomes 
|ΦRHF 0 〉 = |σgσg〉 = 
1 
2 
( 
|ab̄〉+ |bā〉 ︸ ︷︷ ︸ 
correct neutral terms 
+ |aā〉+ |bb̄〉 ︸ ︷︷ ︸ 
spurious ionic terms 
) 
and the RHF energy goes to 
ERHF(H · · ·H) = 2haa ︸︷︷︸ 
2ERHF(H) 
+ 1 
2 Jaa 
︸︷︷︸ static correlation error 
 In the dissociation limit (R → ∞), the UHF wave function becomes 
|ΦUHF 0 〉 = |ab̄〉 or |ΦUHF 
0 〉 = |bā〉 and the UHF energy correctly goes to 
EUHF(H · · ·H) = 2haa = 2EUHF(H) 
but we have spin contamination 
〈ΦUHF 0 |Ŝ2|ΦUHF 
0 〉 = 1 6= 0 
due to spin-symmetry breaking of the UHF wave function which is a combination of a 
 
2 The Hartree-Fock method The Hartree-Fock wave function and energy The Hartree-Fock equations and orbital energies Spin symmetry: UHF and RHF RHF calculations in a basis set Examples: He atom and H2 molecule The electron correlation energy 
 
 Let us repeat that the HF potential v̂HF is an one-electron mean-field potential approximating the effect of the two-electron interaction (1/2) 
∑N 
i 
∑N 
j 6=i 1/|ri − rj | in an average way. 
 The effect of the electron-electron interaction beyond the HF approximation is called electron correlation. The difference between the exact ground-state energy E0 and the HF energy EHF is called the correlation energy 
Ec = E0 − EHF 
 Even though Ec is usually a small percentage of the total energy, it very often makes a large and crucial contribution to energy differences (such as reaction energies, reaction barrier heights, ...). It is therefore important to go beyond the HF approximation and calculate the value of the correlation energy, which is the goal of the post-HF methods. 
 
3 Overview of post-Hartree-Fock methods Full configuration interaction Single-reference post-HF methods Multi-reference post-HF methods 
 
 In FCI, the wave function is expanded in terms of the HF determinant Φ0, the singly excited determinants Φr 
a, the doubly excited determinants Φrs ab, and so on up 
to N-fold excited determinants: 
|ΨFCI〉 = c0|Φ0〉+ occ∑ 
a 
vir∑ 
r 
c r a |Φr 
a〉+ occ∑ 
a<b 
vir∑ 
r<s 
c rs ab|Φrs 
ab〉+ occ∑ 
a<b<c 
vir∑ 
r<s<t 
c rst abc |Φrst 
abc〉+ · · · 
and the coefficients c = (c0, c r a , c 
rs ab, c 
rst abc , ...) are found by minimizing the FCI energy 
EFCI = min c 〈ΨFCI|Ĥ|ΨFCI〉 (with the normalization constraint 〈ΨFCI|ΨFCI〉 = 1), which 
corresponds to diagonalizing Ĥ in the space spanned by all determinants. 
 In a finite basis set, FCI gives an upper bound to the exact ground-state energy: EFCI ≥ E0. In the limit of a complete basis set (K → ∞), FCI becomes exact: EFCI = E0. 
 The correlation energy Ec = E0 − EHF has a slow convergence with the basis size: the error on Ec typically decreases as O 
( K−1 
) . 
 Combinatorial explosion of number of determinants: Ndet = ( 2K N 
) = O 
( (2K )N 
) 
=⇒ necessity to find low-power-scaling approximations 
 To develop approximations to FCI, we identify two regimes of electron correlation: dynamic (or weak) correlation and static (or strong) correlation. 
 
3 Overview of post-Hartree-Fock methods Full configuration interaction Single-reference post-HF methods Multi-reference post-HF methods 
 
 Correlation is called “dynamic” or “weak” if c ra , c rs ab, ...≪ c0 
=⇒ HF is a good starting point 
 This corresponds to situations with a large HOMO-LUMO HF gap. Example: He atom, H2 molecule at equilibrium distance. 
 " Even if each coefficient is small, their total contribution can be large. 
 For dynamic correlation, one considers“single-reference”methods which are approximations to FCI assuming the predominance of the single HF determinant. 
 Three main families of single-reference post-HF methods: 
 Truncated configuration interaction (CI)  Møller-Plesset (MP) perturbation theory (PT)  Coupled-cluster (CC) theory 
 
 The FCI wave function is truncated at a given excitation level, e.g. keeping only single and double excitations (CISD): 
|ΨCISD〉 = c0|Φ0〉+ occ∑ 
a 
vir∑ 
r 
c r a |Φr 
a〉+ occ∑ 
a<b 
vir∑ 
r<s 
c rs ab|Φrs 
ab〉 
 The coefficients c = (c0, c r a , c 
rs ab) corresponding to the ground-state wave function are 
found by minimizing the CISD energy (with the constraint of the normalization of the wave function) 
ECISD = min c 〈ΨCISD|Ĥ|ΨCISD〉 
which, according to the variational principle, gives ECISD ≥ EFCI. 
 The CISD computational cost scales as O ( K 6 
) . 
 Serious shortcoming of truncated CI: it is not size-consistent. 
 We prefer methods that satisfy the size-consistency property: the energy of a system composed of two non-interacting fragments A and B is equal to the sum of the energies of the separate fragments: 
E (A · · ·B) = E (A) + E (B) 
This property is important in chemistry. There is also the related size-extensity 
 
 Perturbation theory starting from the HF Hamiltonian: Ĥ = F̂ + V̂ 
 The first-order wave function includes only doubly excited determinants: 
|Ψ(1)〉 = occ∑ 
a<b 
vir∑ 
r<s 
c rs,(1) ab |Φrs 
ab〉 with c rs,(1) ab = − 〈rs||ab〉 
εr + εs − εa − εb 
 The second-order energy gives the MP2 correlation energy: 
E MP2 c = 〈Φ0|V̂ |Ψ(1)〉 = − 
occ∑ 
a<b 
vir∑ 
r<s 
|〈ab||rs〉|2 εr + εs − εa − εb 
 MP2 is not variational (EMP2 can be lower than EFCI) but is size-consistent. 
 The MP2 computational cost scales as O ( K 5 
) . 
 MP2 is a simple largely used post-HF method that often reasonably accounts for dynamic/weak correlation. 
 However, accuracy is limited by missing higher-order terms. Including higher-order terms (MP3, MP4, etc...) can be computationally costly and the series does not generally converge! 
 
 In CC, the wave function is taken as an exponential of a truncated excitation expansion, e.g. with single and double excitations (CCSD): 
|ΨCCSD〉 = e T̂1+T̂2 |Φ0〉 
where T̂1 = occ∑ 
a 
vir∑ 
r 
t r a â 
† r âa and T̂2 = 
occ∑ 
a<b 
vir∑ 
r<s 
t rs ab â 
† r â 
† s âb âa are operators generating 
singly and doubly excited determinants when acting on the HF wave function |Φ0〉.  The CCSD wave function contains all excited determinants of the FCI wave 
function, but the coefficients of triply, quadruply, etc.. excited determinants are (antisymmetrized) products of the coefficients of singly and doubly excited determinants. 
 The amplitudes tra and trsab are found by projecting the Schrödinger equation Ĥ|ΨCCSD〉 = E |ΨCCSD〉 onto 〈Φr 
a| and 〈Φrs ab|. 
 CCSD is not variational (ECCSD can be lower than EFCI) but is size-consistent. 
 The CCSD computational cost scales as O ( K 6 
) . 
 CCSD is more accurate than MP2 because it contains higher-order terms. 
 Possibility to perturbatively add the triple-excitation operator T̂3 in the expansion =⇒ CCSD(T) which is often considered as the gold standard for dynamic/weak correlation with computational cost scaling as O 
( K 7 
) . 
 
3 Overview of post-Hartree-Fock methods Full configuration interaction Single-reference post-HF methods Multi-reference post-HF methods 
 
 Correlation is called “static” or “strong” if there are some coefficients in the FCI expansion that are not small compared to c0 =⇒ HF is NOT a good starting point 
 This corresponds to situations with a small HOMO-LUMO HF gap. Example: Be atom, H2 molecule at dissociation, transition metals (Fe, Cu, etc...). 
 Single-reference methods give too much importance to the HF determinant and tend to fail for static/strong correlation (e.g., MP2 diverges for zero HOMO-LUMO HF gap). 
 Instead of HF, we use now the multiconfiguration self-consistent field (MCSCF) method which is a multideterminant extension of HF: 
EMCSCF = min {cn,χi} 
〈ΨMCSCF|Ĥ|ΨMCSCF〉 with |ΨMCSCF〉 = ∑ 
n 
cn|Φn〉 
Usually, we include all determinants |Φn〉 that can be generated from a small orbital subspace, called complete active space (CAS) =⇒ accounts for static/strong correlation but combinatorial explosion with the size of the active space! 
 Starting from MCSCF, remaining dynamic/weak correlation can be added with 
multi-reference (MR) methods: 
 MRCI (e.g., MRCISD): not size-consistent but used for very small systems  MRPT (e.g., CASPT2, NEVPT2): fairly used but requires large enough CAS 
 
4 Configuration interaction General configuration interaction Configuration interaction singles doubles Examples: He atom and H2 molecule Lack of size-consistency of truncated configuration interaction 
 
 Configuration interaction is a general post-HF method consists in expanding the wave function in a set of Slater determinants: 
|ΨCI〉 = Ndet∑ 
I=1 
cI |ΦI 〉 
 The coefficients {cI} for the ground state are determined by minimizing the CI energy with the normalization constraint 〈ΨCI|ΨCI〉 = 
∑Ndet I=1 |cI |2 = 1 
ECI = min {cI } 
∑Ndet I=1 
|cI | 2=1 
〈ΨCI|Ĥ|ΨCI〉 
 The corresponding Lagrangian is 
L[{cI}] = 〈ΨCI|Ĥ|ΨCI〉 − ECI 
( 
〈ΨCI|ΨCI〉 − 1 ) 
= 
Ndet∑ 
I=1 
Ndet∑ 
J=1 
c ∗ I cJ〈ΦI |Ĥ|ΦJ〉 − ECI 
( Ndet∑ 
I=1 
|cI |2 − 1 ) 
where ECI acts as the Lagrange multiplier for the normalization constraint. 
 
 The stationary condition on the Lagrangian L 
∂L 
∂c∗I = 0 
leads to the CI eigenvalue equation 
Ndet∑ 
J=1 
〈ΦI |Ĥ|ΦJ〉cJ = ECI cI 
 In matrix form, the CI eigenvalue equation is 
 
    
〈Φ1|Ĥ|Φ1〉 〈Φ1|Ĥ|Φ2〉 · · · 〈Φ1|Ĥ|ΦNdet〉 〈Φ2|Ĥ|Φ1〉 〈Φ2|Ĥ|Φ2〉 · · · 〈Φ2|Ĥ|ΦNdet〉 
... ... 
. . . ... 
〈ΦNdet |Ĥ|Φ1〉 〈ΦNdet |Ĥ|Φ2〉 · · · 〈ΦNdet |Ĥ|ΦNdet〉 
 
    
 
    
c1 c2 ... 
cNdet 
 
    
= ECI 
 
    
c1 c2 ... 
cNdet 
 
    
where the matrix elements 〈ΦI |Ĥ|ΦJ〉 can be expressed in terms of one-electron and two-electron integrals. 
 Solutions of the CI eigenvalue equation give approximations to the ground and excited 
 
 Slater determinants generally do not satisfy the spin and spatial symmetries of the state considered. 
 To impose spin/spatial symmetry and simplify the calculation, one can form configuration state functions (CSFs) {|ΨI 〉}, i.e. fixed linear combinations of a few Slater determinants having the spin and spatial symmetries of the state considered 
|ΨI 〉 = ∑ 
J 
dJ,I |ΦJ〉 
and use them to expand the CI wave function 
|ΨCI〉 = NCSF∑ 
I=1 
cI |ΨI 〉 
 For example, for a closed-shell state, the singly excited determinants |Φr a〉 and |Φr̄ 
ā〉 (where a and r refer to spatial orbitals) are eigenstates of Ŝz but not of Ŝ2. One can form a spin-singlet adapted CSF as 
|1Ψr a〉 = 
1√ 2 
( |Φr 
a〉+ |Φr̄ ā〉 ) 
which is an eigenstate of Ŝ2 with eigenvalue 0. 
 
4 Configuration interaction General configuration interaction Configuration interaction singles doubles Examples: He atom and H2 molecule Lack of size-consistency of truncated configuration interaction 
 
 Ideally, one would like to perform CI using all Slater determinants that can be generated with the considered basis set, i.e. full configuration interaction (FCI) which gives the exact wave function within the basis set. 
 But the total number of determinants explodes combinatorially:Ndet = ( 2K N 
) = O 
( (2K )N 
) 
 For the vast majority of cases, one has thus to select a subset of determinants. This can be done either on-the-fly for each system (selected CI) or according to a predetermined truncation pattern (e.g., excitation levels). 
 The most common truncation is to keep only singly and doubly excited determinants, known as configuration interaction singles doubles (CISD): 
|ΨCISD〉 = c0|Φ0〉+ occ∑ 
a 
vir∑ 
r 
c r a |Φr 
a〉+ occ∑ 
a<b 
vir∑ 
r<s 
c rs ab|Φrs 
ab〉 
and again the coefficients (c0, c r a , c 
rs ab) for the ground state are found by minimizing the 
CISD energy ECISD = 〈ΨCISD|Ĥ|ΨCISD〉 (with the constraint of the normalization of the wave function). 
 
 We obtain a CISD eigenvalue equation with the following block structure:  
  
〈Φ0|Ĥ|Φ0〉 〈Φ0|Ĥ|Φr a〉 〈Φ0|Ĥ|Φrs 
ab〉 〈Φr′ 
a′ |Ĥ|Φ0〉 〈Φr′ 
a′ |Ĥ|Φr a〉 〈Φr′ 
a′ |Ĥ|Φrs ab〉 
〈Φr′s′ 
a′b′ |Ĥ|Φ0〉 〈Φr′s′ 
a′b′ |Ĥ|Φr a〉 〈Φr′s′ 
a′b′ |Ĥ|Φrs ab〉 
 
  
 
 
c0 
c ra c rsab 
 
 = ECISD 
 
 
c0 
c ra c rsab 
 
 
 A well-known simplication: when using HF orbitals, the matrix element between the HF determinant and any singly determinant vanishes 
〈Φ0|Ĥ|Φr a〉 = 〈Φr′ 
a′ |Ĥ|Φ0〉 = 0 
This is known as Brillouin’s theorem. 
 The proof of Brillouin’s theorem is immediate: 
〈Φ0|Ĥ|Φr a〉 = har + 
occ∑ 
b 
〈ab||rb〉 = far = 0 
since far is an off-diagonal matrix element of the Fock operator. 
 Doubly excited determinants make the most important contribution to the correlation energy. Singly excited determinants still contribute a little via their interaction with the doubly excited determinants. 
 
4 Configuration interaction General configuration interaction Configuration interaction singles doubles Examples: He atom and H2 molecule Lack of size-consistency of truncated configuration interaction 
 
 For the He atom, since there are only two electrons, CISD = FCI. 
 FCI ground-state energy using a family of basis sets of increasing size denoted by cc-pVXZ where X =D,T,Q,5,6: 
Total energy (hartree) 
cc-pVDZ -2.8876... cc-pVTZ -2.9002... cc-pVQZ -2.9024... cc-pV5Z -2.9032... cc-pV6Z -2.9034... 
Exact -2.9037... 
 The FCI total energy has a slow power-law convergence as O(X−3) = O(K−1). 
 H2 
 For the H2 molecule, again since there are only two electrons, CISD = FCI. 
 We work in a minimal basis set {φa(r), φb(r)}, composed of two identical 1s functions centered on Ha and Hb, respectively. This leads to two RHF molecular orbitals: - the bonding orbital: ψ1(r) ≡ ψσg(r) 
- the antibonding orbital: ψ2(r) ≡ ψσu(r) 
 In this basis, due to spatial symmetry, only two determinants contribute to the FCI ground-state wave function, i.e. the RHF determinant |Φ0〉 = |1 1̄〉 and the doubly 
excited determinant |Φ2 2̄ 1 1̄〉 = |2 2̄〉, 
|ΨFCI〉 = c1|1 1̄〉+ c2|2 2̄〉 
 The FCI 2× 2 matrix eigenvalue equation is ( 
〈1 1̄|Ĥ|1 1̄〉 〈1 1̄|Ĥ|2 2̄〉 〈2 2̄|Ĥ|1 1̄〉 〈2 2̄|Ĥ|2 2̄〉 
)( c1 c2 
) 
= EFCI 
( c1 c2 
) 
with matrix elements: 
〈1 1̄|Ĥ|1 1̄〉 = ERHF = 2h11 + J11 and 〈2 2̄|Ĥ|2 2̄〉 = E2 = 2h22 + J22 
and 〈1 1̄|Ĥ|2 2̄〉 = 〈2 2̄|Ĥ|1 1̄〉 = 〈1 1̄||2 2̄〉 = 〈1 1̄|2 2̄〉 = 〈1 1|2 2〉 = K12 
 H2 
 In the minimal basis, the FCI ground-state energy is 
EFCI = 1 
2 
( 
ERHF + E2 − √ 
(E2 − ERHF)2 + 4K 2 12 
) 
= ERHF +∆− √ 
∆2 + K 2 12 
where ∆ = (E2 − ERHF)/2 
 FCI energy curve in the minimal basis: 
-1.2 
-1.1 
-1.0 
-0.9 
-0.8 
-0.7 
-0.6 
-0.5 
-0.4 
 1  2  3  4  5  6 
T o 
ta l 
e n 
e rg 
y  ( 
h a 
rt re 
e ) 
Internuclear distance (bohr) 
RHF UHF FCI 
Exact 
 FCI corrects RHF at dissociation by including static (or strong) correlation 
 
 
4 Configuration interaction General configuration interaction Configuration interaction singles doubles Examples: He atom and H2 molecule Lack of size-consistency of truncated configuration interaction 
 
 We say that a method is size-consistent if the calculated energy of a system composed of two non-interacting fragments A and B is equal to the sum of the calculated energies of the separate fragments: 
E (A · · ·B) = E (A) + E (B) 
 The most serious drawback of truncated CI methods is that they are not size-consistent. 
 Let us show this on the example of two H2 molecules in a minimal basis set separated by an infinite distance: 
H2 ︸︷︷︸ 
fragment A 
· · · · · · H2 ︸︷︷︸ 
fragment B 
 We have two spatial RHF orbitals located on A, denoted by 1A and 2A, and two spatial RHF orbitals located on B, denoted by 1B and 2B . The RHF wave function of the total system is |ΦA ···B 
RHF 〉 = |1A 1̄A 1B 1̄B〉.  The CISD wave function of the total system is 
|ΨA ···B CISD 〉 = c1|1A 1̄A 1B 1̄B〉+ c2|2A 2̄A 1B 1̄B〉+ c3|1A 1̄A 2B 2̄B〉 
 all single excitations do not contribute by symmetry 
 all other double excitations (e.g., |2A 2̄B 1B 1̄B〉) do not contribute because they 
 
 The CISD 3× 3 matrix eigenvalue equation is  
 
2EA RHF K12 K12 
K12 EA RHF + EA 
2 0 K12 0 EA 
RHF + EA 2 
 
 
 
 
c1 c2 c3 
 
 = E A···B CISD 
 
 
c1 c2 c3 
 
 
where EA RHF = EB 
RHF = 2h11 + J11 is the RHF energy of one fragment, EA 2 = EB 
2 = 2h22 + J22 is the energy of a double excitation of one fragment, and K12 = 〈12|12〉 is the interaction integral between the orbitals 1 and 2 of one fragment. 
 The CISD ground-state energy is 
E A···B CISD = 
1 
2 
( 
3EA RHF + E 
A 2 − 
√ 
(EA 2 − EA 
RHF) 2 + 8K 2 
12 
) 
= 2EA RHF +∆− 
√ 
∆2 + 2K 2 12 
where ∆ = (EA 2 − EA 
RHF)/2 
 It is not equal to twice the CISD ground-state energy of one fragment 
E A···B CISD 6= 2EA 
CISD = 2EA RHF + 2∆− 2 
√ 
∆2 + K 2 12 
so CISD is not size-consistent. 
 To recover size-consistency, one would need to add quadruple excitations in the 
 
5 Perturbation theory General Rayleigh-Schrödinger perturbation theory Møller-Plesset perturbation theory 
 
 Consider a Hamiltonian Ĥλ depending on a coupling constant λ 
Ĥ λ = Ĥ 
(0) + λV̂ 
where Ĥ(0) is a zeroth-order Hamiltonian operator and V̂ is a perturbation operator. The“physical”Hamiltonian corresponds to λ = 1, i.e. Ĥ = Ĥλ=1. 
 Ĥ(0) is chosen such that its eigenstates Φn and associated eigenvalues E (0) n are known 
Ĥ (0)|Φn〉 = E 
(0) n |Φn〉 
and the eigenstates are chosen to be orthonormal, i.e. 〈Φn|Φm〉 = δn,m. 
 We want to determine the eigenstates Ψλ n and associated eigenvalues Eλ 
n of the Hamiltonian Ĥλ, e.g. for the ground state 
Ĥ λ|Ψλ 
0 〉 = E λ 0 |Ψλ 
0 〉 
 We assume that Eλ 0 and Ψλ 
0 can be expanded in powers of λ 
E λ 0 = E 
(0) 0 + λE 
(1) 0 + λ2 
E (2) 0 + · · · and |Ψλ 
0 〉 = |Ψ(0) 0 〉+ λ|Ψ(1) 
0 〉+ λ2|Ψ(2) 0 〉+ · · · 
where Ψ (0) 0 = Φ0. 
 It is convenient to choose the so-called intermediate normalization for Ψλ 0 : 
〈Φ0|Ψλ 〈Φ0|Ψ(i) 
 
 
 Insertion of the expansion of Ψλ 0 and Eλ 
0 into the eigenvalue equation gives ( 
Ĥ (0) + λV̂ 
)( 
|Φ0〉+ λ|Ψ(1) 0 〉+ λ2|Ψ(2) 
0 〉+ · · · ) 
= ( 
E (0) 0 + λE 
(1) 0 + λ2 
E (2) 0 + · · · 
)( 
|Φ0〉+ λ|Ψ(1) 0 〉+ λ2|Ψ(2) 
0 〉+ · · · ) 
 Looking at this equation order by order in λ, we recover at zeroth order 
Ĥ (0)|Φ0〉 = E 
(0) 0 |Φ0〉 
 At first order, we obtain 
Ĥ (0)|Ψ(1) 
0 〉+ V̂ |Φ0〉 = E (0) 0 |Ψ(1) 
0 〉+ E (1) 0 |Φ0〉 
 Projecting this equation on the bra state 〈Φ0| gives the first-order energy correction 
E (1) 0 = 〈Φ0|V̂ |Φ0〉 
 Projecting now on the bra states 〈Φn| for n 6= 0 gives 
E (0) n 〈Φn|Ψ(1) 
0 〉+ 〈Φn|V̂ |Φ0〉 = E (0) 0 〈Φn|Ψ(1) 
0 〉 leading to the first-order wave-function correction 
〈Φn|Ψ(1) 0 〉 = − 〈Φn|V̂ |Φ0〉 
 (0) 
(0) 
=⇒ |Ψ(1) 0 〉 = − 
∑ 
 
〈Φn|V̂ |Φ0〉 
(0) 
(0) 
|Φn〉 
 
 Similarly, at second order, we obtain 
Ĥ (0)|Ψ(2) 
0 〉+ V̂ |Ψ(1) 0 〉 = E 
(0) 0 |Ψ(2) 
0 〉+ E (1) 0 |Ψ(1) 
0 〉+ E (2) 0 |Φ0〉 
 Projecting this equation on the bra state 〈Φ0| gives the second-order energy correction 
E (2) 0 = 〈Φ0|V̂ |Ψ(1) 
0 〉 = − ∑ 
n 6=0 
|〈Φ0|V̂ |Φn〉|2 
E (0) n − E 
(0) 0 
 Note that E (2) 0 diverges if there is a state Φn (with n 6= 0) of energy E 
(0) n equals to E 
(0) 0 , 
i.e. if the zeroth-order Hamiltonian Ĥ(0) has a degenerate ground state. In this case, one must instead diagonalize the Hamiltonian in the degenerate space before applying perturbation theory, which is known as degenerate perturbation theory. 
 Similarly, one can show that the third-order energy correction has the following expression 
E (3) 0 = 〈Φ0|V̂ |Ψ(2) 
0 〉 
= ∑ 
n,m 6=0 
〈Φ0|V̂ |Φn〉〈Φn|V̂ |Φm〉〈Φm|V̂ |Φ0〉 (E 
(0) n − E 
(0) 0 )(E 
(0) m − E 
(0) 0 ) 
− E (1) 0 
∑ 
n 6=0 
|〈Φ0|V̂ |Φn〉|2 
(E (0) n − E 
(0) 0 )2 
 
5 Perturbation theory General Rayleigh-Schrödinger perturbation theory Møller-Plesset perturbation theory 
 
 Møller-Plesset (MP) perturbation theory is a particular case of Rayleigh-Schrödinger perturbation theory for which the zeroth-order Hamiltonian is chosen to be the Hartree-Fock (sometimes also simply called Fock) Hamiltonian 
Ĥ (0) = F̂ 
 The expression of F̂ in the position representation is 
F (x1, x2, ..., xN) = 
N∑ 
i 
f (xi ) 
 The corresponding perturbation operator V̂ is thus the difference between the electron-electron Coulomb interaction and the HF potential 
V (x1, x2, ..., xN) = 1 
2 
N∑ 
i 
N∑ 
i 6=j 
1 
|ri − rj | − 
N∑ 
i 
vHF(xi ) 
 
 The zeroth-order ground-state energy is given by the sum of occupied orbital energies 
E (0) 0 = 〈Φ0|F̂ |Φ0〉 = 
occ∑ 
a 
εa 
 The first-order energy correction is the expectation value of the HF determinant over the perturbation operator 
E (1) 0 = 〈Φ0|V̂ |Φ0〉 
Therefore, the sum of the zeroth-order energy and first-order energy correction just gives back the HF energy 
E (0) 0 + E 
(1) 0 = 〈Φ0|F̂ + V̂ |Φ0〉 = EHF 
 The second-order energy correction, also called the second-order Møller-Plesset (MP2) correlation energy, is 
E (2) 0 = E 
MP2 c = − 
∑ 
n 6=0 
|〈Φ0|V̂ |Φn〉|2 
E (0) n − E 
(0) 0 
where Φn can be a priori single, double, triple, ... excited determinants. 
 
 In fact, since V̂ is at most a two-body operator, according to Slater’s rules, triple and higher excitations with respect to Φ0 give vanishing matrix elements 〈Φ0|V̂ |Φn〉. 
 In addition, it turns out that single excitations only give a vanishing contribution 
〈Φ0|V̂ |Φr a〉 = 
occ∑ 
b 
〈ab||rb〉 − 〈a|v̂HF|r〉 = occ∑ 
b 
〈ab||rb〉 − occ∑ 
b 
〈ab||rb〉 = 0 
 It thus remains only the double excitations, Φn = Φrs ab. Only the two-body part of the 
perturbation operator gives a non-zero matrix element 
〈Φ0|V̂ |Φrs ab〉 = 〈ab||rs〉 
and the zeroth-order energy corresponding to the doubly-excited determinants Φrs ab is 
E (0) n = E 
rs,(0) ab = E 
(0) 0 + εr + εs − εa − εb 
 We arrive at the following expression for the MP2 correlation energy 
E MP2 c = − 
occ∑ 
a<b 
vir∑ 
r<s 
|〈ab||rs〉|2 εr + εs − εa − εb 
= −1 
4 
occ∑ 
a,b 
vir∑ 
r,s 
|〈ab||rs〉|2 εr + εs − εa − εb 
where we have used the antisymmetry property of the integrals, i.e. 〈ab||rs〉 = −〈ab||sr〉 = −〈ba||rs〉. 
 
 The MP2 correlation energy is always negative. 
 It diverges to −∞ if one energy denominator εr + εs − εa − εb is zero. This happens for systems with zero HF HOMO-LUMO gap, in which case MP perturbation theory cannot be applied. 
 The MP2 energy is 
EMP2 = EHF + E MP2 c 
Since it is not a variational theory, EMP2 is not necessarily above EFCI. 
 Similarly, it can be shown, after much work, that the third-order Møller-Plesset (MP3) energy correction has the following expression 
E (3) 0 = 
1 
8 
occ∑ 
a,b,c,d 
vir∑ 
r,s 
〈ab||rs〉〈rs||cd〉〈cd ||ab〉 (εr + εs − εa − εb)(εr + εs − εc − εd) 
+ 1 
8 
occ∑ 
a,b 
vir∑ 
r,s,t,u 
〈ab||rs〉〈rs||tu〉〈tu||ab〉 (εr + εs − εa − εb)(εt + εu − εa − εb) 
+ occ∑ 
a,b,c 
vir∑ 
r,s,t 
〈ab||rs〉〈cs||tb〉〈rt||ac〉 (εr + εs − εa − εb)(εr + εt − εa − εc) 
The calculation of the third- or higher-order terms is often considered as not worthwhile 
 
 The MP2 correlation energy can be rewritten as the sum of a direct and exchange term 
E MP2 c = −1 
2 
occ∑ 
a,b 
vir∑ 
r,s 
〈ab|rs〉〈rs|ab〉 εr + εs − εa − εb 
+ 1 
2 
occ∑ 
a,b 
vir∑ 
r,s 
〈ab|rs〉〈rs|ba〉 εr + εs − εa − εb 
 These terms can be represented by Feynman diagrams (also called Goldstone diagrams in quantum chemistry) 
EMP2 c = a r s b + a 
s r b 
 When starting from an unrestricted HF calculation, MP perturbation theory is correctly size consistent at each order. In terms of diagrams, this comes from the fact that each diagram contributing to the perturbative expansion of the energy is made of a single linked piece. Unlinked diagrams do not contribute. This is known as the linked-cluster theorem. 
 
6 Coupled-cluster theory The exponential ansatz Truncation of the cluster operator The coupled-cluster energy and the coupled-cluster equations Example: coupled-cluster doubles Coupled-cluster methods in practice 
 
 In coupled-cluster (CC) theory, one starts by an exponential ansatz for the CC wave function 
|ΨCC〉 = e T̂ |Φ0〉 
where |Φ0〉 is the HF wave function, and T̂ is the cluster (excitation) operator which is the sum of cluster operators of different excitation levels 
T̂ = T̂1 + T̂2 + · · ·+ T̂N 
 T̂1 is the cluster operator for the single excitations 
T̂1 = occ∑ 
a 
vir∑ 
r 
t r a â 
† r âa 
where tra are the single-excitation cluster amplitudes to be determined. 
We have used the second-quantization formalism: 
 âa is the annihilation operator of the spin orbital a 
 â † r is the creation operator of the spin orbital r 
 When the operator â†r âa acts on the HF single determinant |Φ0〉, it generates the 
single-excited determinant |Φr a〉 = â 
† r âa|Φ0〉 
 
 Similarly, T̂2 is the cluster operator for the double excitations 
T̂2 = occ∑ 
a<b 
vir∑ 
r<s 
t rs ab â 
† r â 
† s âb âa 
where trsab are the double-excitation cluster amplitudes to be determined. 
When the operator â†r â † s âb âa acts on the HF single determinant |Φ0〉, it generates the 
double-excited determinant |Φrs ab〉 = â†r â 
† s âb âa|Φ0〉. 
 And so on up to the T̂N cluster operator for N-fold excitations. 
 
 To understand the action of the operator eT̂ on the HF wave function |Φ0〉, one can expand the exponential and rearrange the operators in terms of excitation levels 
e T̂ = 1̂ + T̂ + 
T̂ 2 
2! + 
T̂ 3 
3! + · · ·+ T̂N 
N! = 1̂ + Ĉ1 + Ĉ2 + · · ·+ ĈN 
where the operator Ĉ1 generates single excitations, Ĉ2 generates double excitations, etc. 
 Noting that the cluster operators T̂1, T̂2, ..., T̂N commute with each other, we find for example for the first four excitation operators 
Ĉ1 = T̂1 
Ĉ2 = T̂2 + 1 
2 T̂ 
2 1 
Ĉ3 = T̂3 + T̂1T̂2 + 1 
6 T̂ 
3 1 
Ĉ4 = T̂4 + T̂1T̂3 + 1 
2 T̂ 
2 2 + 
1 
2 T̂ 
2 1 T̂2 + 
1 
24 T̂ 
4 1 
and so on. 
 
 The CC wave function has thus the same form as the FCI wave function (with intermediate normalization, i.e. c0 = 1) 
|ΨCC〉 =|Φ0〉+ occ∑ 
a 
vir∑ 
r 
c r a |Φr 
a〉+ occ∑ 
a<b 
vir∑ 
r<s 
c rs ab|Φrs 
ab〉 
+ 
occ∑ 
a<b<c 
vir∑ 
r<s<t 
c rst abc |Φrst 
abc〉+ occ∑ 
a<b<c<d 
vir∑ 
r<s<t<u 
c rstu abcd |Φrstu 
abcd〉+ · · · 
with coefficients related to the cluster amplitudes by 
c r a = t 
r a 
c rs ab = t 
rs ab + t 
r a ∗ tsb 
c rst abc = t 
rst abc + t 
r a ∗ tstbc + t 
r a ∗ tsb ∗ ttc 
c rstu abcd = t 
rstu abcd + t 
r a ∗ tstubcd + t 
rs ab ∗ ttucd + t 
r a ∗ tsb ∗ ttucd + t 
r a ∗ tsb ∗ ttc ∗ tud and so on. 
Here, ∗ means an antisymmetric product with respect to exchange of indices: 
t r a ∗ tsb = t 
r at 
s b − t 
r bt 
s a 
t r a ∗ tstbc = t 
r at 
st bc − t 
r bt 
st ac + t 
r c t 
st ab − t 
s at 
rt bc + t 
s bt 
rt ac − t 
s c t 
rt ab + t 
t at 
rs bc − t 
t bt 
rs ac + t 
t c t 
rs ab 
t r ∗ tsb ∗ ttc = t 
r at 
s bt 
t − t 
r at 
s t 
t − t 
r bt 
s at 
t − t 
r t 
s bt 
t + t 
r t 
s at 
t + t 
r bt 
s t 
t and so on. 
 
 Thus, the CC wave function contains all excited determinants, just as the FCI wave function. 
 If the cluster operator T̂ is not truncated, the CC wave function is just a nonlinear reparametrization of the FCI wave function with the same number of parameters. Optimizing the cluster amplitudes t = (tra , t 
rs ab, t 
rst abc , ...) so as to minimize the total energy 
would lead to the FCI wave function. 
 The interest of the CC approach only appears when the cluster operator is truncated. 
 
6 Coupled-cluster theory The exponential ansatz Truncation of the cluster operator The coupled-cluster energy and the coupled-cluster equations Example: coupled-cluster doubles Coupled-cluster methods in practice 
 
 For example, let us consider coupled-cluster singles doubles (CCSD) 
T̂ = T̂1 + T̂2 
 The expansion of eT̂ gives 
e T̂ = 1̂ + T̂1 + 
( 
T̂2 + 1 
2 T̂ 
2 1 
) 
+ 
( 
T̂1T̂2 + 1 
6 T̂ 
3 1 
) 
+ 
( 1 
2 T̂ 
2 2 + 
1 
2 T̂ 
2 1 T̂2 + 
1 
24 T̂ 
4 1 
) 
+ · · · 
 The CCSD wave function has the same form as the FCI wave function, i.e. it contains all excited determinants, but with coefficients now given by 
c r a = t 
r a 
c rs ab = t 
rs ab + t 
r a ∗ tsb 
c rst abc = t 
r a ∗ tstbc + t 
r a ∗ tsb ∗ ttc 
c rstu abcd = t 
rs ab ∗ ttucd + t 
r a ∗ tsb ∗ ttucd + t 
r a ∗ tsb ∗ ttc ∗ tud and so on. 
 The coefficients of the triple excitations c rstabc are now only approximated by products of single- and double-excitation amplitudes tra and tstbc , and similarly for all higher-level excitations. 
 In comparison with the CISD wave function, the CCSD wave function has many more excited determinants but the same number of free parameters t = (tra , t 
rs ab) to optimize! 
 
 Contrary to truncated CI, truncated CC is size-consistent, which directly stems from the exponential form of the CC wave function. 
 Proof: consider a system composed of two infinitely separated (and thus non-interacting) fragments A and B: 
Ĥ = ĤA + ĤB 
 If the HF calculation is size-consistent, the HF wave function is multiplicatively separable: |ΦA···B 
0 〉 = |ΦA 0 〉 ⊗ |ΦB 
0 〉 (where ⊗ is the antisymmetric tensor product) 
 Because the orbitals of each fragments do not overlap, the cluster operator of the system is additively separable: T̂A···B = T̂A + T̂B 
 We can then show that the CC wave function is multiplicatively separable: 
|ΨA···B CC 〉 =eT̂ 
A···B 
|ΦA···B 0 〉 
=eT̂ A+T̂B 
|ΦA 0 〉 ⊗ |ΦB 
0 〉 
=eT̂ A 
|ΦA 0 〉 ⊗ eT̂ 
B 
|ΦB 0 〉 
=|ΨA CC〉 ⊗ |ΨB 
CC〉 
 This implies that the CC energy is additively separable: 
ECC(A · · ·B) =〈ΨA···B CC |ĤA + ĤB |Ψ 
A···B CC 〉 
=〈ΨA CC|ĤA|Ψ 
A CC〉〈Ψ 
B CC|Ψ 
B CC〉+ 〈ΨA 
CC|Ψ A CC〉〈Ψ 
B CC|ĤB |Ψ 
B CC〉 
 
 
6 Coupled-cluster theory The exponential ansatz Truncation of the cluster operator The coupled-cluster energy and the coupled-cluster equations Example: coupled-cluster doubles Coupled-cluster methods in practice 
 
 We consider in all the following an arbitrary truncation level of the cluster operator. 
 The most natural way to calculate the CC amplitudes t and CC energy would be by using the variational method: 
E var CC = min 
t 〈ΨCC|Ĥ|ΨCC〉 
with the constraint 〈ΨCC|ΨCC〉 = 1. 
However, the CC wave function includes all excited determinants up to N-fold excitations which contribute to the expectation value, giving too complex equations to be efficiently solved. 
 A more convenient approach for obtaining the CC amplitudes and CC energy is the projection method: we require that ΨCC satisfies the Schrödinger equation 
(Ĥ − ECC)|ΨCC〉 = 0 
projected onto the space spanned by 〈Φ0|, 〈Φr a|, 〈Φrs 
ab|, 〈Φrst abc |,... 
〈Φ0|(Ĥ − ECC)|ΨCC〉 = 0 
〈Φr a|(Ĥ − ECC)|ΨCC〉 = 0 
〈Φrs ab|(Ĥ − ECC)|ΨCC〉 = 0 
〈Φrst abc |(Ĥ − ECC)|ΨCC〉 = 0 and so on. 
 
 Remember the expansion of |ΨCC〉 in terms of determinants 
|ΨCC〉 =|Φ0〉+ occ∑ 
a 
vir∑ 
r 
c r a |Φr 
a〉+ occ∑ 
a<b 
vir∑ 
r<s 
c rs ab|Φrs 
ab〉+ occ∑ 
a<b<c 
vir∑ 
r<s<t 
c rst abc |Φrst 
abc〉+ · · · 
with intermediate normalization, i.e. 〈Φ0|ΨCC〉 = 1 . 
 We see that the first projected equation, 〈Φ0|(Ĥ − ECC)|ΨCC〉 = 0, gives the CC energy 
ECC = 〈Φ0|Ĥ|ΨCC〉 = 〈Φ0|Ĥ|Φ0〉+ occ∑ 
a 
vir∑ 
r 
c r a〈Φ0|Ĥ|Φr 
a〉+ occ∑ 
a<b 
vir∑ 
r<s 
c rs ab〈Φ0|Ĥ|Φrs 
ab〉 
in which, according to Slater’s rules, triple and higher excitations do not contribute. 
 It turns out that the single-excitation term does not contribute thanks to Brillouin’s 
theorem 〈Φ0|Ĥ|Φr a〉 = 0 . We thus obtain the CC correlation energy 
E CC c = ECC − EHF = 
occ∑ 
a<b 
vir∑ 
r<s 
c rs ab〈Φ0|Ĥ|Φrs 
ab〉 = occ∑ 
a<b 
vir∑ 
r<s 
(trsab + t r a ∗ tsb)〈ab||rs〉 
 Except in the uninteresting case where the cluster operator T̂ is not truncated, the CC energy obtained with the projection method is not identical to the one that would have 
 
 
 The other projected equations determine the CC amplitudes 
〈Φr a|(Ĥ − ECC)e 
T̂ |Φ0〉 = 0 
〈Φrs ab|(Ĥ − ECC)e 
T̂ |Φ0〉 = 0 
〈Φrst abc |(Ĥ − ECC)e 
T̂ |Φ0〉 = 0 and so on. 
which are known as the unlinked CC amplitude equations. 
 They represent a system of coupled nonlinear equations for the amplitudes tra , t rs ab, t 
rst abc , 
etc. 
 To have the same number of equations as the number of unknown amplitudes, the projection space must correspond to the truncation level of the cluster operator. For example, for determining the CCSD amplitudes, one needs to consider projection onto single- and double-excited determinants only. 
 
 In practice, it is often more convenient to write the CC amplitude equations is a different 
way, by first multiplying from the left by the operator e−T̂ in the Schrödinger equation before projecting on the excited determinants 
〈Φr a|e−T̂ 
Ĥe T̂ |Φ0〉 = 0 
〈Φrs ab|e−T̂ 
Ĥe T̂ |Φ0〉 = 0 
〈Φrst abc |e−T̂ 
Ĥe T̂ |Φ0〉 = 0 and so on. 
which are known as the linked CC amplitude equations. 
 Although equivalent to the unlinked equations, the linked equations have the advantage of leading to more compact expressions which are manifestly size-consistent and at most quartic in the amplitudes (at any truncation level). 
 This last feature comes from the fact that the Baker-Campbell-Hausdorff (BCH) 
expansion of e−T̂ ĤeT̂ exactly terminates at fourth order because Ĥ contains at most a two-electron operator: 
e −T̂ 
Ĥe T̂ = Ĥ + [Ĥ, T̂ ] + 
1 
2! [[Ĥ, T̂ ], T̂ ] + 
1 
3! [[[Ĥ, T̂ ], T̂ ], T̂ ] + 
1 
4! [[[[Ĥ, T̂ ], T̂ ], T̂ ], T̂ ] 
 
6 Coupled-cluster theory The exponential ansatz Truncation of the cluster operator The coupled-cluster energy and the coupled-cluster equations Example: coupled-cluster doubles Coupled-cluster methods in practice 
 
 As an example, we now write down the complete equations in the case of coupled-cluster doubles (CCD). 
 In this case, the cluster operator only contains double excitations 
T̂ = T̂2 
 The CCD wave function thus contains double-excited determinants, quadruple-excited determinants, ... 
|ΨCCD〉 = |Φ0〉+ occ∑ 
a<b 
vir∑ 
r<s 
t rs ab|Φrs 
ab〉+ occ∑ 
a<b<c<d 
vir∑ 
r<s<t<u 
(trsab ∗ ttucd)|Φrstu abcd〉+ · · · 
where the coefficients of the quadruple excitations are given by the antisymmetrized product of the coefficients of the double excitations, and so on. 
 The CCD correlation energy is given by 
E CCD c = 
occ∑ 
a<b 
vir∑ 
r<s 
t rs ab〈ab||rs〉 
 
 The double-excitation amplitudes trsab can be determined from the unlinked CC amplitude equations: 
〈Φrs ab|(Ĥ − ECCD)|ΨCCD〉 = 0 
 After expanding ΨCCD, we get: 
〈Φrs ab|Ĥ|Φ0〉+ 
occ∑ 
c<d 
vir∑ 
t<u 
〈Φrs ab|Ĥ − ECCD|Φtu 
cd〉ttucd + 
occ∑ 
c<d 
vir∑ 
t<u 
〈Φrs ab|Ĥ|Φrstu 
abcd〉(trsab ∗ ttucd) = 0 
 Using 〈Φrs ab|Ĥ|Φ0〉 = 〈rs||ab〉 and 〈Φrs 
ab|Ĥ|Φrstu abcd〉 = 〈cd ||tu〉, 
and inserting ECCD = EHF + ECCD c gives 
〈rs||ab〉+ occ∑ 
c<d 
vir∑ 
t<u 
〈Φrs ab|Ĥ − EHF|Φtu 
cd〉ttucd + occ∑ 
c<d 
vir∑ 
t<u 
〈cd ||tu〉(trsab ∗ ttucd − t rs abt 
tu cd) = 0 
 The remaining matrix element is more complicated to calculate, but can be done with a bit of method and patience. We get: 
〈Φrs ab|Ĥ − EHF|Φtu 
cd〉 = (εr + εs − εa − εb)δa,cδb,dδr,tδs,u 
+〈rs||tu〉δa,dδb,d + 〈cd ||ab〉δr,tδs,u +〈ds||ub〉δa,cδr,t − 〈cs||ub〉δa,dδr,t −〈ds||tb〉δa,cδr,u + 〈cs||tb〉δa,dδr,u 
 
 The final CCD amplitude equations are: 
〈rs||ab〉+ (εr + εs − εa − εb)t rs ab + 
vir∑ 
t<u 
〈rs||tu〉ttuab + occ∑ 
c<d 
〈cd ||ab〉trscd 
+ occ∑ 
d 
vir∑ 
u 
〈ds||ub〉truad − occ∑ 
c 
vir∑ 
u 
〈cs||ub〉truca − occ∑ 
d 
vir∑ 
t 
〈ds||tb〉ttrad + occ∑ 
c 
vir∑ 
t 
〈cs||tb〉ttrca 
+ occ∑ 
c<d 
vir∑ 
t<u 
〈cd ||tu〉(trsab ∗ ttucd − t rs abt 
tu cd) = 0 
which are quadratic equations for t to be solved iteratively. 
 Let us consider now the expansion of the amplitudes in powers of the electron-electron interaction: trsab = t 
rs,(1) ab + t 
rs,(2) ab + · · · . The first-order amplitudes are given by 
〈rs||ab〉+ (εr + εs − εa − εb)t rs,(1) ab = 0 =⇒ t 
rs,(1) ab = − 〈rs||ab〉 
εr + εs − εa − εb 
Inserting this expression of t rs,(1) ab in the expression of the correlation energy, we get: 
occ∑ 
a<b 
vir∑ 
r<s 
t rs,(1) ab 〈ab||rs〉 = − 
occ∑ 
a<b 
vir∑ 
r<s 
|〈ab||rs〉|2 εr + εs − εa − εb 
= E MP2 c 
 
 
6 Coupled-cluster theory The exponential ansatz Truncation of the cluster operator The coupled-cluster energy and the coupled-cluster equations Example: coupled-cluster doubles Coupled-cluster methods in practice 
 
 The first level of CC approximation commonly used is coupled-cluster singles doubles (CCSD): 
T̂ = T̂1 + T̂2 
 CCSD is correct up to third order in the e-e interaction 
 The CCSD computational cost scales as O(N2 occN 
4 vir) 
 To obtain more accurate results, it is important to add the effect of the triple-excitation operator T̂3 perturbatively, which is known as coupled-cluster singles doubles and perturbative triples (CCSD(T)): 
 The second-order triple-excitation amplitudes t rst,(2) abc are calculated non-iteratively 
from the CCSD double-excitation amplitudes trsab 
 Parts of the fourth-order and fifth-order energy corrections involving the triple-excitation amplitudes are calculated and added to the CCSD energy 
ECCSD(T) = ECCSD + E (4) T + E 
(5) ST 
 The CCSD(T) computational cost scales as O(N3 occN 
4 vir) 
 
Atomization energies (in kJ/mol) of 16 small molecules: H2, CH2, CH4, H2O, NH3, HF, N2, F2, CO, HCN, C2H2, C2H4, CH2O, HNO, CO2, O3 
Normal distribution of errors for HF, MP2, CCSD, and CCSD(T) with different basis sets (DZ, TZ, QZ, 5Z, 6Z): 
With largest basis set (6Z): HF MP2 CCSD CCSD(T) Mean error (in kJ/mol) -423.1 29.7 -37.3 -4.7 Standard deviation (in kJ/mol) 179.3 36.8 29.4 3.8 
From T. Helgaker, High-Accuracy Quantum Chemistry, Lecture at UPMC, 2012 and 
 
 
Reaction enthalpies and their errors (in kJ/mol) of 14 reactions for B3LYP and CCSD(T): 
B3LYP CCSD(T) Exp. CH2 + H2 → CH4 -543 1 -543 1 -544(2) C2H2 + H2 → C2H4 -208 -5 -206 -3 -203(2) C2H2 + 3H2 → 2CH4 -450 -4 -447 -1 -446(2) CO + H2 → CH2O -34 -13 -23 -2 -21(1) N2 + 3H2 → 2NH3 -166 -2 -165 -1 -164(1) F2 + H2 → 2HF -540 23 -564 -1 -563(1) O3 + 3H2 → 3H2O -909 24 -946 -13 -933(2) CH2O + 2H2 → CH4 + H2O -234 17 -250 1 -251(1) H2O2 + H2 → 2H2O -346 19 -362 3 -365(2) CO + 3H2 → CH4 + H2O -268 4 -273 -1 -272(1) HCN + 3H2 → CH4 + NH3 -320 0 -321 -1 -320(3) HNO + 2H2 → H2O + NH3 -429 15 -446 -2 -444(1) CO2 + 4H2 → CH4 + 2H2O -211 33 -244 0 -244(1) 2CH2 → C2H4 -845 -1 -845 -1 -844(3) 
From T. Helgaker, High-Accuracy Quantum Chemistry, Lecture at UPMC, 2012 and 
T. Helgaker, P. Jørgensen, J. Olsen, Molecular Electronic-Structure Theory, Wiley, 2002. 
 N2 
Dissociation energy curve of N2 with cc-pVDZ basis set (with respect to the relative internuclear distance R/Re where Re = 2.074 bohr): 
From T. Kinoshita, O. Hino, and R. J. Bartlett, Journal of Chemical Physics 123, 074106 (2005) 
 
 
7 Appendix Slater’s rules for matrix elements Gaussian basis sets The formalism of second quantization 
 
Matrix elements where Φ0 is a reference Slater determinant, Φr a is a single-excited 
determinant, and Φrs ab is a double-excited determinant made of spin orbitals {|i〉} which 
are orthonormal 〈i |j〉 = δi,j : 
 Zero-electron operator (overlap): 
〈Φ0|Φ0〉 = 1 〈Φ0|Φr a〉 = 0 〈Φ0|Φrs 
ab〉 = 0 
 One-electron operator: Ô1 = ∑N 
i ĥ(xi ) 
〈Φ0|Ô1|Φ0〉 = occ∑ 
a 
〈a|ĥ|a〉 〈Φ0|Ô1|Φr a〉 = 〈a|ĥ|r〉 〈Φ0|Ô1|Φrs 
ab〉 = 0 
 Two-electron operator: Ô2 = ∑N 
i 
∑N 
j>i 1/rij 
〈Φ0|Ô2|Φ0〉 = 1 
2 
occ∑ 
a 
occ∑ 
b 
〈ab||ab〉 〈Φ0|Ô2|Φr a〉 = 
occ∑ 
b 
〈ab||rb〉 
〈Φ0|Ô2|Φrs ab〉 = 〈ab||rs〉 
 
 
7 Appendix Slater’s rules for matrix elements Gaussian basis sets The formalism of second quantization 
 
In quantum chemistry, we usually use Gaussian-type orbital (GTO) basis sets. 
 The atom-centered Gaussian primitive functions are of the form 
gp(r) = Np r ℓp e 
−αp r 2 
Y mp 
ℓp (θ, φ) 
using spherical coordinates r = (r , θ, φ) around the nucleus center. 
 The basis functions are generally fixed linear combinations (called contractions) of primitive functions: 
φµ(r) = ∑ 
p 
dpµ gp(r) 
 Many such GTO basis sets have been optimized for each atom. Widely used for wave-function calculations is the family of Dunning’s correlation-consistent polarized valence basis sets denoted by cc-pVXZ where X =D,T,Q,5,6. 
 Example for the C atom: 
Basis set cc-pVDZ cc-pVTZ cc-pVQZ cc-pV5Z cc-pV6Z Core basis functions 1s 1s 1s 1s 1s Valence basis functions 2s+2p 3s+3p 4s+4p 5s+5p 6s+6p Polarization basis functions 1d 2d+1f 3d+2f+1g 4d+3f+2g+1h 5d+4f+3g+2h+1i 
Total number of basis functions (K ∝ X3) 14 30 55 91 140 
 There are also basis sets augmented with diffuse basis functions: aug-cc-pVXZ 
 There are also basis sets with more core basis functions for core correlation: cc-pCVXZ 
 
7 Appendix Slater’s rules for matrix elements Gaussian basis sets The formalism of second quantization 
 
Second quantization is a very convenient formalism for dealing with many-body quantum systems. In particular, for electrons, it allows one to incorporate the antisymmetry property of the wave functions directly into an algebra of operators. 
We consider a set of spin orbitals {|i〉} which are orthonormal, 〈i |j〉 = δi,j . 
 Vaccum state: We define a vaccum state |vac〉 containing zero electron and normalized to one: 〈vac|vac〉 = 1. 
 Creation and annihilation operators: At each spin orbital i , we associate a creation operator â†i which acts on |vac〉 to create the state |i〉 corresponding to one electron in the spin orbital i 
â † i |vac〉 = |i〉 
At each spin orbital i , we also associate an annihilation operator âi which gives back the vaccum state |vac〉 when acting on the state |i〉 
âi |i〉 = |vac〉 
The creation operator â†i is the adjoint of the annihilation operator âi , and vice versa. 
If we try to create a spin orbital that has already been created, we get zero: â†i |i〉 = 0. If we try to annihilate a spin orbital that has not been created, we get zero: âi |vac〉 = 0. 
 
 Many-electron states: A many-electron state is created by acting sucessively with several creation operators on the vaccum state. For example, acting with the creation operator â†1 , â 
† 2 , ..., â 
† N gives 
a state corresponding to a Slater determinant with N electrons occupying the spin orbitals labeled by 1, 2, ...,N: 
â † 1 â 
† 2 · · · â†N |vac〉 = |1 2 · · · N〉 = |Φ0〉 
 Excitation operators: Excited determinants can be conveniently expressed as excitation operators acting on the reference determinant |Φ0〉. For example, the operator â†r âa generates a single excitation and the operator â†r â 
† s âb âa generates a double excitation: 
â † r âa|Φ0〉 = |Φr 
a〉 and â † r â 
† s âb âa|Φ0〉 = |Φrs 
ab〉 and so on. 
 Fermionic anticommutation rules: The previous rules imply that the creation and annihilation operators obey the fermionic anticommutation relations: 
{â†i , â † j } = â 
† i â 
† j + â 
† j â 
† i = 0 
{âi , âj} = âi âj + âj âi = 0 
{âi , â†j } = âi â † + â 
† âi = δi,j 