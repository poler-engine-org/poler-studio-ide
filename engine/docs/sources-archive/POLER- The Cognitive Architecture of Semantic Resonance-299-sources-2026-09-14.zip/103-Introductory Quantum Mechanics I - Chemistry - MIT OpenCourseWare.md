> Source: https://ocw.mit.edu/courses/5-73-introductory-quantum-mechanics-i-fall-2005/

Introductory Quantum Mechanics I | Chemistry | MIT OpenCourseWare
Browse Course Material
Syllabus
Calendar
Lecture Notes
Assignments
Exams 
Course Info
Instructor
Prof. Troy Van Voorhis
Departments
Chemistry
As Taught In
Fall 2005
Level
Graduate
Topics
Science
Physics
Quantum Mechanics
Learning Resource Types
grading Exam Solutions
grading Exams
notes Lecture Notes
assignment_turned_in Problem Set Solutions
assignment Problem Sets
Download Course
menu
search
Give Now
About OCW
Help & Faqs
Contact Us
search GIVE NOW about ocw help & faqs contact us
5.73 | Fall 2005 | Graduate
Introductory Quantum Mechanics I
Menu
Syllabus
Calendar
Lecture Notes
Assignments
Exams
Course Description
5.73 covers fundamental concepts of quantum mechanics: wave properties, uncertainty principles, Schrödinger equation, and operator and matrix methods. Basic applications of the following are discussed: one-dimensional potentials (harmonic oscillator), three-dimensional centrosymmetric potentials (hydrogen atom), and … Show more
5.73 covers fundamental concepts of quantum mechanics: wave properties, uncertainty principles, Schrödinger equation, and operator and matrix methods. Basic applications of the following are discussed: one-dimensional potentials (harmonic oscillator), three-dimensional centrosymmetric potentials (hydrogen atom), and angular momentum and spin. The course also examines approximation methods: variational principle and perturbation theory. Show less
Course Info
Instructor
Prof. Troy Van Voorhis
Departments
Chemistry
Topics
Science
Physics
Quantum Mechanics
Learning Resource Types
grading Exam Solutions
grading Exams
notes Lecture Notes
assignment_turned_in Problem Set Solutions
assignment Problem Sets 
The Born-Oppenheimer approximation fails when two electron states almost cross, also known as an “avoided crossing.” An avoided crossing is illustrated in the above plot of adiabatic electronic energy as a function of R. (Figure by Prof. Troy Van Voorhis.)
Download Course
Over 2,500 courses & materials
Freely sharing knowledge with learners and educators around the world. Learn more
© 2001–2026 Massachusetts Institute of Technology
Accessibility
Creative Commons License
Terms and Conditions
Proud member of:
© 2001–2026 Massachusetts Institute of Technology 
You are leaving MIT OpenCourseWare
close
Please be advised that external sites may have terms and conditions, including license rights, that differ from ours. MIT OCW is not responsible for any content on third party sites, nor does a link suggest an endorsement of those sites and/or their content.
Stay Here Continue