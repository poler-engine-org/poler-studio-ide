> Source: https://catalog.data.gov/dataset/nist-computational-chemistry-comparison-and-benchmark-database-srd-101

National Institute of Standards and Technology - NIST Computational Chemistry Comparison and Benchmark Database - SRD 101
Skip to main content 
An official website of the United States government
Here's how you know
Here's how you know 
Official websites use .gov
A .gov website belongs to an official government organization in the United States. 
Secure .gov websites use HTTPS
A lock ( ) or https:// means you've safely connected to the .gov website. Share sensitive information only on official, secure websites. 
Menu 
Data
Metrics
Organizations
User Guide
Contact
Search
NIST Computational Chemistry Comparison and Benchmark Database - SRD 101
Published by National Institute of Standards and Technology | National Institute of Standards and Technology | Catalog Last Checked: August 02, 2025 at 01:26 PM | Dataset Last Updated: October 01, 2016
The NIST Computational Chemistry Comparison and Benchmark Database is a collection of experimental and ab initio thermochemical properties for a selected set of gas-phase molecules. The goals are to provide a benchmark set of experimental data for the evaluation of ab initio computational methods and allow the comparison between different ab initio computational methods for the prediction of gas-phase thermochemical properties. The data files linked to this record are a subset of the experimental data present in the CCCBDB.
Resources
1 resource available
DOI access for NIST Computational Chemistry Comparison and Benchmark Database - SRD 101 TEXT/HTML Visit Page
Find Related Datasets
Search by Tags
Click any tag below to search for similar datasets
ab initio atomization enthalpy basis functions benchmark data benchmarks bond angle bond length cccbdb
chemistry computational chemistry dipole moment electron affinity hindered rotor homo lumo gap ideal gas integrated heat capacity isomerization enthalpies molecular geometry molecular polarizability molecular vibrations physics point group quantum chemistry thermochemical data thermochemistry vibration frequencies vibrational frequencies vibrational frequency vibrational zero point energy zero-point energies
22 more
Complete Metadata
@type
dcat:Dataset
accessLevel
public
accrualPeriodicity
irregular
bureauCode
contactPoint
describedByType
application/pdf
description
The NIST Computational Chemistry Comparison and Benchmark Database is a collection of experimental and ab initio thermochemical properties for a selected set of gas-phase molecules. The goals are to provide a benchmark set of experimental data for the evaluation of ab initio computational methods and allow the comparison between different ab initio computational methods for the prediction of gas-phase thermochemical properties. The data files linked to this record are a subset of the experimental data present in the CCCBDB.
distribution
identifier
FDB59097465D5200E043065706813E54101
keyword
landingPage
https://cccbdb.nist.gov/
language
license
https://www.nist.gov/open/license
modified
2016-10-01 00:00:00
programCode
publisher
references
theme
title
NIST Computational Chemistry Comparison and Benchmark Database - SRD 101
Contact
Have questions or suggestions about this dataset? Reach out to the contact below.
Name
Karl K. Irikura
Email
karl.irikura@nist.gov
Access & Use
License
https://www.nist.gov/open/license
Access Level
public
Dataset Information
Dataset Last Updated
October 01, 2016
Accrual Periodicity
irregular
Metadata Information
Catalog Last Checked
August 02, 2025 at 01:26 PM
Harvest Record
View Raw Data
About
Open Government
Website Policies
PERFORMANCE.GOV
Data.gov on Github
Follow @GSA 1,135 
data.gov
An official website of the GSA's Technology Transformation Services
About GSA
Accessibility statement
FOIA requests
No FEAR Act data
Office of the Inspector General
Performance reports
Privacy policy
Looking for U.S. government information and services?
Visit USA.gov