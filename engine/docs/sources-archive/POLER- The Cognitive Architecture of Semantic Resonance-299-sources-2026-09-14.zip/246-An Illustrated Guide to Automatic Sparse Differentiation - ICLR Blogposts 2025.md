> Source: https://iclr-blogposts.github.io/2025/blog/sparse-autodiff/

An Illustrated Guide to Automatic Sparse Differentiation | ICLR Blogposts 2025
ICLR Blogposts 2025 Toggle navigation
about
call for blogposts
submitting
reviewing
blog
past iterations 2026 2025 2024 2023 2022
An Illustrated Guide to Automatic Sparse Differentiation
In numerous applications of machine learning, Hessians and Jacobians exhibit sparsity, a property that can be leveraged to vastly accelerate their computation. While the usage of automatic differentiation in machine learning is ubiquitous, automatic sparse differentiation (ASD) remains largely unknown. This post introduces ASD, explaining its key components and their roles in the computation of both sparse Jacobians and Hessians. We conclude with a practical demonstration showcasing the performance benefits of ASD.
Authors
Affiliations
Adrian Hill
BIFOLD – Berlin Institute for the Foundations of Learning and Data, Machine Learning Group, Technical University of Berlin, Berlin, Germany
Guillaume Dalle
LVMT, ENPC, Institut Polytechnique de Paris, Univ Gustave Eiffel, Marne-la-Vallée, France
Alexis Montoison
Argonne National Laboratory, Lemont, USA
Published
April 28, 2025
Contents
Automatic differentiation
The chain rule
AD is matrix-free
Forward-mode AD
Reverse-mode AD
From Jacobian operators back to Jacobian matrices
Automatic sparse differentiation
Sparse matrices
Leveraging sparsity
Pattern detection and coloring
Pattern detection
Index sets
Efficient propagation
Abstract interpretation
Local and global patterns
Coloring
Graph formulation
Greedy algorithm
Bicoloring
Second order
Hessian-vector products
Second order pattern detection
Symmetric coloring
Applications
Demonstration
Necessary packages
Test function
Backend switch
Jacobian computation
Preparation
Coloring visualization
Performance benefits
Conclusion
First-order optimization is ubiquitous in machine learning (ML) but second-order optimization is much less common. The intuitive reason is that high-dimensional vectors (gradients) are cheap, whereas high-dimensional matrices (Hessians) are expensive. Luckily, in numerous applications of ML to science or engineering, Hessians and Jacobians exhibit sparsity: most of their coefficients are known to be zero. Leveraging this sparsity can vastly accelerate automatic differentiation (AD) for Hessians and Jacobians, while decreasing its memory requirements
Evaluating derivatives: principles and techniques of algorithmic differentiation [link] A. Griewank, A. Walther. Society for Industrial and Applied Mathematics. 2008.
[1]
. Yet, while traditional AD is available in many high-level programming languages like Python
PyTorch: An Imperative Style, High-Performance Deep Learning Library [HTML] A. Paszke, S. Gross, F. Massa, A. Lerer, J. Bradbury, G. Chanan, T. Killeen, Z. Lin, N. Gimelshein, L. Antiga, A. Desmaison, A. Kopf, E. Yang, Z. DeVito, M. Raison, A. Tejani, S. Chilamkurthy, B. Steiner, L. Fang, J. Bai, S. Chintala. Advances in Neural Information Processing Systems, Vol 32. Curran Associates, Inc. 2019.
[2]
JAX: composable transformations of Python+NumPy programs [link] J. Bradbury, R. Frostig, P. Hawkins, M.J. Johnson, C. Leary, D. Maclaurin, G. Necula, A. Paszke, J. VanderPlas, S. Wanderman-Milne, Q. Zhang. 2018.
[3]
and Julia
Differentiable Programming for Differential Equations: A Review [PDF] F. Sapienza, J. Bolibar, F. Schäfer, B. Groenke, A. Pal, V. Boussange, P. Heimbach, G. Hooker, F. Pérez, P. Persson, C. Rackauckas. arXiv. 2024. DOI: 10.48550/arXiv.2406.09699
[4]
, automatic sparse differentiation (ASD) is not as widely used. One reason is that the underlying theory was developed in the AD community, outside of the ML research ecosystem.
With this blog post, we aim to shed light on the inner workings of ASD, bridging the gap between the ML and AD communities by presenting well established techniques from the latter field. We start out with a short introduction to traditional AD, covering the computation of Jacobians in both forward and reverse mode. We then dive into the two primary components of ASD: sparsity pattern detection and matrix coloring. Having described the computation of sparse Jacobians, we move on to sparse Hessians.
After discussing applications in machine learning, we conclude with a practical demonstration of ASD, providing performance benchmarks and guidance on when to use ASD over AD.
Automatic differentiation
Let us start by covering the fundamentals of traditional AD. The reader can find more details in the recent book by Blondel and Roulet
The Elements of Differentiable Programming [PDF] M. Blondel, V. Roulet. arXiv. 2024. DOI: 10.48550/arXiv.2403.14606
[5]
, as well as Griewank and Walther
Evaluating derivatives: principles and techniques of algorithmic differentiation [link] A. Griewank, A. Walther. Society for Industrial and Applied Mathematics. 2008.
[1]
.
AD makes use of the compositional structure of mathematical functions like deep neural networks. To make things simple, we will mainly look at a differentiable function f f f composed of two differentiable functions g : R n → R p g: \mathbb{R}^{n} \rightarrow \mathbb{R}^{p} g: R n → R p and h : R p → R m h: \mathbb{R}^{p} \rightarrow \mathbb{R}^{m} h: R p → R m , such that f = h ∘ g : R n → R m f = h \circ g: \mathbb{R}^{n} \rightarrow \mathbb{R}^{m} f= h ∘ g: R n → R m . The insights gained from this toy example should translate directly to more deeply composed functions f = g ( L ) ∘ g ( L − 1 ) ∘ ⋯ ∘ g ( 1 ) f = g^{(L)} \circ g^{(L-1)} \circ \cdots \circ g^{(1)} f= g( L) ∘ g( L− 1) ∘ ⋯ ∘ g( 1) , and even computational graphs with more complex branching.
The chain rule
For a function f : R n → R m f: \mathbb{R}^{n} \rightarrow \mathbb{R}^{m} f: R n → R m and a point of linearization x ∈ R n \mathbf{x} \in \mathbb{R}^{n} x ∈ R n , the Jacobian matrix J f ( x ) J_f(\mathbf{x}) J f ( x) is the m × n m \times n m × n matrix of first-order partial derivatives, whose ( i , j ) (i,j) ( i, j) -th entry is
( J f ( x ) ) i , j = ∂ f i ∂ x j ( x ) ∈ R .
For a composed function
f = h ∘ g ,
the multivariate chain rule tells us that we obtain the Jacobian matrix of f f f by multiplying the Jacobian matrices of h h h and g g g :
J f ( x ) = J h ( g ( x ) ) ⋅ J g ( x ) .
Figure 1 illustrates this for n = 5 n=5 n= 5 , m = 4 m=4 m= 4 and p = 3 p=3 p= 3 . We will keep using these dimensions in following illustrations, even though the real benefits of ASD only appear as the dimension grows. 
Figure 1: Visualization of the multivariate chain rule for f = h ∘ g f = h \circ g f= h ∘ g .
AD is matrix-free
We have seen how the chain rule translates the compositional structure of a function into the product structure of its Jacobian matrix. In practice however, there is a problem: computing intermediate Jacobian matrices is inefficient and often intractable, especially with a dense matrix format. Examples of dense matrix formats include NumPy's ndarray , PyTorch's Tensor , JAX's Array and Julia's Matrix .
As a motivating example, let us take a look at a tiny convolutional layer. We consider a convolutional filter of size 5 × 5 5 \times 5 5 × 5 , a single input channel and a single output channel. An input of size 2 8 × 2 8 × 1 28 \times 28 \times 1 2 8 × 2 8 × 1 results in a 5 7 6 576 5 7 6 -dimensional output and therefore a 5 7 6 × 7 8 4 576 \times 784 5 7 6 × 7 8 4 Jacobian matrix, the structure of which is shown in Figure 2. All the white coefficients are structural zeros.
If we represent the Jacobian of each convolutional layer as a dense matrix, we waste time computing coefficients which are mostly zero, and we waste memory storing those zero coefficients. 
Figure 2: Structure of the Jacobian of a tiny convolutional layer.
In modern neural network architectures, which can contain over one trillion parameters, computing intermediate Jacobian matrices is not only inefficient: it exceeds available memory.
AD circumvents this limitation by using Jacobian operators that act exactly like Jacobian matrices but without explicitly storing every coefficient in memory. The Jacobian operator D f : x ⟼ D f ( x ) Df: \mathbf{x} \longmapsto Df(\mathbf{x}) D f: x ⟼ D f( x) is a linear map which provides the best linear approximation of f f f around a given point x \mathbf{x} x . Jacobian matrices are the representation of Jacobian operators in the standard basis.
We can now rephrase the chain rule as a composition of operators instead of a product of matrices:
D f ( x ) = D ( h ∘ g ) ( x ) = D h ( g ( x ) ) ∘ D g ( x ) .
Note that all terms in this formulation of the chain rule are Jacobian operators. A new visualization for our toy example can be found in Figure 3b. Our illustrations distinguish between matrices and operators by using solid and dashed lines respectively. 
Figure 3a: Chain rule using Jacobian matrices (solid outline). 
Figure 3b: Chain rule using matrix-free Jacobian operators (dashed outline).
We visualize “matrix entries” in Jacobian operators to build intuition. Even though following illustrations will sometimes put numbers onto these entries, Jacobian operators are best thought of as black-boxes.
Forward-mode AD
Now that we have translated the compositional structure of our function f f f into a compositional structure of Jacobian operators, we can evaluate them by propagating vectors through them, one subfunction at a time.
Figure 4 illustrates the propagation of a vector v 1 ∈ R n \mathbf{v}_1 \in \mathbb{R}^n v 1  ∈ R n from the right-hand side. Since we propagate in the order of the original function evaluation ( g g g then h h h ), this is called forward-mode AD. 
Figure 4: Evaluating Jacobian operators in forward mode.
In the first step, we evaluate D g ( x ) ( v 1 ) Dg(\mathbf{x})(\mathbf{v}_1) D g( x)( v 1 ) . Since this operation by definition corresponds to
v 2 = D g ( x ) ( v 1 ) = J g ( x ) ⋅ v 1 ∈ R p ,
it is commonly called a Jacobian-vector product (JVP) or pushforward.
While we stick to the term “JVP” due to its prevalence in the ML community, we want to emphasize that it is misleading: A JVP does not materialize and multiply a Jacobian matrix. Instead, it evaluates a matrix-free Jacobian operator.
The resulting vector v 2 \mathbf{v}_2 v 2  is then used to compute the subsequent JVP
v 3 = D h ( g ( x ) ) ( v 2 ) = J h ( g ( x ) ) ⋅ v 2 ∈ R m ,
which in accordance with the chain rule is equivalent to
v 3 = D f ( x ) ( v 1 ) = J f ( x ) ⋅ v 1 ,
the JVP of our composed function f f f .
The computational cost of one JVP of f f f is approximately the same as the cost of one evaluation of f f f . Note that we did not compute intermediate Jacobian matrices at any point – we only propagated vectors through Jacobian operators.
Reverse-mode AD
We can also propagate vectors through the Jacobian operators from the left-hand side, resulting in reverse-mode AD, shown in Figure 5. 
Figure 5: Evaluating Jacobian operators in reverse mode.
This is commonly called a vector-Jacobian product (VJP) or pullback. Just like forward mode, the cost of one VJP of f f f is approximately the same as the cost of one evaluation of f f f . However, the memory footprint is larger, as intermediate results of the computation of f f f must be kept in memory (e.g. hidden activations between layers). Reverse mode is also matrix-free: no intermediate Jacobian matrices are computed at any point.
Just like the term “JVP” in forward-mode, the term “VJP” is misleading. A VJP does not materialize and multiply a Jacobian matrix. Instead, it evaluates a matrix-free Jacobian operator.
From Jacobian operators back to Jacobian matrices
In a computationally expensive process we call materialization, we can turn a composition of Jacobian operators into a dense Jacobian matrix. Counterintuitively, this process does not materialize any intermediate Jacobian matrices.
Figure 6 demonstrates how to materialize Jacobian matrices column by column in forward mode. Evaluating the Jacobian operator D f ( x ) Df(\mathbf{x}) D f( x) on the i i i -th standard basis vector materializes the i i i -th column of the Jacobian matrix J f ( x ) J_{f}(\mathbf{x}) J f ( x) :
D f ( x ) ( e i ) = ( J f ( x ) ) i , :
Thus, recovering the full m × n m \times n m × n Jacobian matrix requires one JVP with each of the n n n standard basis vectors of the input space. Once again, we distinguish between Jacobian operators and materialized Jacobian matrices by using dashed and solid lines respectively. While we put numbers into the Jacobian operators for illustrative purposes, they are best thought of as black-box functions: 
Figure 6: Forward-mode AD materializes Jacobian matrices column-by-column.
As illustrated in Figure 7, we can also materialize Jacobian matrices row by row in reverse mode. Unlike forward mode in Figure 6, this requires one VJP with each of the m m m standard basis vectors of the output space. 
Figure 7: Reverse-mode AD materializes Jacobian matrices row-by-row.
These processes of materialization are computationally expensive due the fact that each JVP and VJP costs approximately as much as the evaluation of the function f f f itself.
Since neural networks are usually trained using scalar loss functions, reverse-mode AD only requires the evaluation of a single VJP to materialize a gradient, which is rather cheap (see Baur and Strassen
The complexity of partial derivatives [link] W. Baur, V. Strassen. Theoretical Computer Science, Vol 22(3), pp. 317--330. 1983. DOI: 10.1016/0304-3975(83)90110-X
[6]
). This makes reverse-mode AD the method of choice for machine learners, who typically use the term backpropagation.
Automatic sparse differentiation
Sparse matrices
Sparse matrices are matrices in which most elements are zero. As shown in Figure 8, we refer to Jacobian operators as “sparse operators” if they materialize to sparse matrices.  
Figure 8: A sparse Jacobian matrix and its corresponding sparse Jacobian operator.
When functions have many inputs and many outputs, a given output does not always depend on every single input. This endows the corresponding Jacobian matrix with a sparsity pattern, where zero coefficients denote an absence of (first-order) dependency. The previous case of a convolutional layer is a simple example. An even simpler example is an activation function applied element-wise, for which the Jacobian matrix is the identity matrix.
Leveraging sparsity
For now, we assume that the sparsity pattern of the Jacobian matrix is always the same, regardless of the input, and that we know it ahead of time. We say that two columns or rows of the Jacobian matrix are structurally orthogonal if, for every index, at most one of them has a nonzero coefficient. In other words, the sparsity patterns of the columns are non-overlapping vectors, whose dot product is always zero regardless of their actual values.
The core idea of ASD is that we can materialize multiple structurally orthogonal columns (or rows) with a single JVP (or VJP). This trick was first suggested in 1974 by Curtis, Powell and Reid
On the Estimation of Sparse Jacobian Matrices [link] A.R. Curtis, M.J.D. Powell, J.K. Reid. IMA Journal of Applied Mathematics, Vol 13(1), pp. 117--119. 1974. DOI: 10.1093/imamat/13.1.117
[7]
. Since Jacobian operators are linear maps and therefore additive, it always holds that for a set of basis vectors,
D f ( x ) ( e i + … + e j ) = D f ( x ) ( e i ) ⏟ ( J f ( x ) ) i , : + … + D f ( x ) ( e j ) ⏟ ( J f ( x ) ) j , : .
The components of the sum on the right-hand side each correspond to a column of the Jacobian matrix. If these columns are known to be structurally orthogonal, the sum can be uniquely decomposed into its components, a process known as decompression. Thus, a single JVP is enough to retrieve the nonzero coefficients of several columns at once.
This specific example using JVPs corresponds to forward-mode ASD and is visualized in Figure 9, where all structurally orthogonal columns have been colored in matching hues. By computing a single JVP with the vector e 1 + e 2 + e 5 \mathbf{e}_1 + \mathbf{e}_2 + \mathbf{e}_5 e 1 + e 2 + e 5  , we obtain the sum of the first, second and fifth column of our Jacobian matrix. 
Figure 9: Materializing structurally orthogonal columns of a Jacobian in forward mode.
A second JVP with the vector e 3 + e 4 \mathbf{e}_3 + \mathbf{e}_4 e 3 + e 4  gives us the sum of the remaining columns. We then assign the values in the resulting vectors back to the appropriate entries of the Jacobian matrix. This final decompression step is shown in Figure 10.  
Figure 10: Materializing a Jacobian with forward-mode ASD: (a) compressed evaluation of orthogonal columns (b) decompression to Jacobian matrix
The same idea can also be applied to reverse-mode AD, as shown in Figure 11. Instead of leveraging orthogonal columns, we rely on orthogonal rows. We can then materialize multiple rows in a single VJP.  
Figure 11: Materializing a Jacobian with reverse-mode ASD: (a) compressed evaluation of orthogonal rows (b) decompression to Jacobian matrix
Pattern detection and coloring
Unfortunately, our initial assumption had a major flaw. Since AD only gives us a composition of Jacobian operators, which are black-box functions, the structure of the corresponding Jacobian matrix is completely unknown. In other words, we cannot tell which rows and columns form structurally orthogonal groups without first materializing a Jacobian matrix. But if we materialize this matrix via traditional AD, then ASD isn't necessary anymore.
The solution to this problem is shown in Figure 12 (a): in order to find structurally orthogonal columns (or rows), we don't need to materialize the full Jacobian matrix. Instead, it is enough to detect the sparsity pattern of the matrix. This binary-valued pattern contains enough information to deduce structural orthogonality. From there, we use a coloring algorithm to group orthogonal columns (or rows) together. Such a coloring can be visualized on Figure 12 (b), where the yellow columns will be evaluated together (first JVP) and the light blue ones will be evaluated together (second JVP), for a total of 2 JVPs instead of 5.  
Figure 12: The first two steps of ASD: (a) sparsity pattern detection, (b) coloring of the sparsity pattern.
To sum up, ASD consists of four steps:
Pattern detection
Coloring
Compressed AD
Decompression
This compression-based pipeline is described at length by Gebremedhin, Manne and Pothen
What Color Is Your Jacobian? Graph Coloring for Computing Derivatives [link] A.H. Gebremedhin, F. Manne, A. Pothen. SIAM Review, Vol 47(4), pp. 629--705. Society for Industrial and Applied Mathematics. 2005. DOI: 10/cmwds4
[8]
in their landmark survey, or in Chapter 8 of the book by Griewank and Walther
Evaluating derivatives: principles and techniques of algorithmic differentiation [link] A. Griewank, A. Walther. Society for Industrial and Applied Mathematics. 2008.
[1]
. An alternative, direct pipeline is presented in Chapter 7 of the same book.
We now discuss the first two steps in more detail. These steps can be much slower than a single call to the function f f f , but they are usually much faster than a full computation of the Jacobian with AD. This makes the sparse procedure worth it even for moderately large matrices. Additionally, if we need to compute Jacobians multiple times (for different inputs) and are able to reuse the sparsity pattern and the coloring result, the cost of this prelude can be amortized over several subsequent evaluations.
Pattern detection
Mirroring the diversity of AD systems, there are also many possible approaches to sparsity pattern detection, each with its own advantages and tradeoffs. The work of Dixon
Automatic differentiation of large sparse systems [link] L.C.W. Dixon, Z. Maany, M. Mohseninia. Journal of Economic Dynamics and Control, Vol 14(2), pp. 299--311. 1990. DOI: 10.1016/0165-1889(90)90023-A
[9]
in the 1990's was among the first of many papers on this subject, most of which can be classified into operator overloading or source transformation techniques. There are also ways to detect a sparsity pattern by probing the Jacobian matrix coefficients with AD
Detecting Jacobian sparsity patterns by Bayesian probing [link] A. Griewank, C. Mitev. Mathematical Programming, Vol 93(1), pp. 1--25. 2002. DOI: 10.1007/s101070100281
[10]
, but we do not linger on them here.
The method we present corresponds to a binary version of a forward-mode AD system, similar in spirit to
Automatic differentiation of large sparse systems [link] L.C.W. Dixon, Z. Maany, M. Mohseninia. Journal of Economic Dynamics and Control, Vol 14(2), pp. 299--311. 1990. DOI: 10.1016/0165-1889(90)90023-A
[9]
and
Efficient computation of gradients and Jacobians by dynamic exploitation of sparsity in automatic differentiation [link] C.H. Bischof, P.M. Khademi, A. Buaricha, C. Alan. Optimization Methods and Software, Vol 7(1), pp. 1--39. Taylor & Francis. 1996. DOI: 10.1080/10556789608805642
[11]
, in which performance is gained by representing matrix rows as index sets.
Index sets
Our goal with sparsity pattern detection is to quickly compute the binary pattern of the Jacobian matrix. One way to achieve better performance than traditional AD is to encode row sparsity patterns as index sets. The i i i -th row of the Jacobian is given by
( J f ( x ) ) i , : = [ ∂ f i ∂ x j ( x ) ] 1 ≤ j ≤ n = [ ∂ f i ∂ x 1 ( x ) … ∂ f i ∂ x n ( x ) ] .
However, since we are only interested in the binary pattern
[ ∂ f i ∂ x j ( x ) ≠ 0 ] 1 ≤ j ≤ n ,
we can instead represent the sparsity pattern of the i i i -th row of a Jacobian matrix by the corresponding index set of non-zero values
{ j | ∂ f i ∂ x j ( x ) ≠ 0 } .
These equivalent sparsity pattern representations are illustrated in Figure 13. Each row index set tells us which inputs influenced a given output, at the first-order. For instance, output i = 2 i=2 i= 2 was influenced by inputs j = 4 j=4 j= 4 and j = 5 j=5 j= 5 . 
Figure 13: Sparsity pattern representations: (a) original matrix, (b) binary pattern, (c) row index sets.
Efficient propagation
Figure 14 shows the traditional forward mode pass we want to avoid: propagating a full identity matrix through a Jacobian operator would not only materialize the Jacobian matrix of f f f , but also all intermediate Jacobian matrices. As previously discussed, this is not a viable option due to its inefficiency and high memory requirements. 
Figure 14: Propagating an identity matrix in forward mode to obtain the Jacobian matrix.
Instead, we initialize an input vector with index sets corresponding to the identity matrix. An alternative view on this vector is that it corresponds to the index set representation of the Jacobian matrix of the input, since ∂ x i ∂ x j ≠ 0 \frac{\partial x_i}{\partial x_j} \neq 0 ∂ x j  ∂ x i   ≠ 0 only holds for i = j i=j i= j .
Our goal is to propagate this index set such that we get an output vector of index sets that corresponds to the Jacobian sparsity pattern. This idea is visualized in Figure 15. 
Figure 15: Propagating an index set through a Jacobian operator to obtain a sparsity pattern.
Abstract interpretation
Instead of going into implementation details, we want to provide some intuition on the second key ingredient of this typical forward-mode sparsity detection system: abstract interpretation.
We will demonstrate this on a second toy example, the function
f ( x ) = [ x 1 x 2 + sgn ( x 3 ) sgn ( x 3 ) x 4 2 ] .
The corresponding computational graph is shown in Figure 16, where circular nodes correspond to primitive functions, in this case addition, multiplication, division and the sign function. Scalar inputs x i x_i x i  and outputs y j y_j y j  are shown in rectangular nodes. Instead of evaluating the original compute graph for a given input x \mathbf{x} x , all inputs are seeded with their respective input index sets. Figure 16 annotates these index sets on the edges of the computational graph. 
Figure 16: Computational graph of the function f ( x ) = [ x 1 x 2 + sgn ( x 3 ) , sgn ( x 3 ) x 4 2 ] f(\mathbf{x}) = [x_1 x_2 + \text{sgn}(x_3),, \text{sgn}(x_3) \frac{x_4}{2} ] f( x)=[ x 1  x 2 + sgn( x 3 ), sgn( x 3 ) 2 x 4  ] , annotated with corresponding index sets.
Abstract interpretation means that we imbue the computational graph with a different meaning. Instead of computing its output value, each primitive function must accumulate the index sets of its inputs, then propagate these index sets to the output, but only if the corresponding derivative is non-zero anywhere in the input domain.
Since addition, multiplication and division globally have non-zero derivatives with respect to both of their inputs, the index sets of their inputs are accumulated and propagated. The sign function has a zero derivative for any input value. It therefore doesn't propagate the index set of its input and instead returns an empty set.
Figure 16 shows the resulting output index sets { 1 , 2 } {1, 2} { 1, 2} and { 4 } {4} { 4} for outputs 1 and 2 respectively. These match the analytic Jacobian matrix
J f ( x ) = [ x 2 x 1 0 0 0 0 0 sgn ( x 3 ) 2 ] .
Local and global patterns
The type of abstract interpretation shown above corresponds to global sparsity detection, computing index sets
{ j | ∂ f i ∂ x j ( x ) ≠ 0 for some x ∈ R n }
that are valid over the entire input domain. Another type of abstract interpretation can be implemented, in which the original primal computation is propagated alongside index sets, computing
{ j | ∂ f i ∂ x j ( x ) ≠ 0 }
for a specific input x \mathbf{x} x . These local sparsity patterns are strict subsets of global sparsity patterns, and can therefore result in fewer colors. However, they need to be recomputed when changing the input.
Coloring
Once we have detected a sparsity pattern, our next goal is to decide how to group the columns (or rows) of the Jacobian matrix. The columns (or rows) in each group will be evaluated simultaneously using a single JVP (or VJP), with a linear combination of basis vectors called a seed. If the members of the group are structurally orthogonal, then this gives all the necessary information to retrieve every nonzero coefficient of the matrix.
Graph formulation
Luckily, this grouping problem can be reformulated as graph coloring, which is very well studied. Let us build a graph G = ( V , E ) \mathcal{G} = (\mathcal{V}, \mathcal{E}) G=( V, E) with vertex set V \mathcal{V} V and edge set E \mathcal{E} E , such that each column is a vertex of the graph, and two vertices are connected if and only if their respective columns share a non-zero index. Put differently, an edge between vertices j 1 j_1 j 1  and j 2 j_2 j 2  means that columns j 1 j_1 j 1  and j 2 j_2 j 2  are not structurally orthogonal. Note that there are more efficient graph representations, summed up in
What Color Is Your Jacobian? Graph Coloring for Computing Derivatives [link] A.H. Gebremedhin, F. Manne, A. Pothen. SIAM Review, Vol 47(4), pp. 629--705. Society for Industrial and Applied Mathematics. 2005. DOI: 10/cmwds4
[8]
.
We want to assign to each vertex j j j a color c ( j ) c(j) c( j) , such that any two adjacent vertices ( j 1 , j 2 ) ∈ E (j_1, j_2) \in \mathcal{E} ( j 1 , j 2 ) ∈ E have different colors c ( j 1 ) ≠ c ( j 2 ) c(j_1) \neq c(j_2) c( j 1 ) ≠ c( j 2 ) . This constraint ensures that columns in the same color group are indeed structurally orthogonal. If we can find a coloring which uses the smallest possible number of distinct colors, it will minimize the number of groups, and thus the computational cost of the AD step.
Figure 17 shows an optimal coloring using two colors, whereas Figure 18 uses a suboptimal third color, requiring an extra JVP to materialize the Jacobian and therefore increasing the computational cost of ASD. Figure 19 shows an infeasible coloring: vertices 2 and 4 on the graph are adjacent, but share a color. This results in overlapping columns. 
Figure 17: Optimal graph coloring. 
Figure 18: Suboptimal graph coloring (vertex 1 could be colored in yellow). 
Figure 19: Infeasible graph coloring (vertices 2 and 4 are adjacent on the graph, but share a color).
If we perform column coloring, forward-mode AD is required, while reverse-mode AD is needed for row coloring.
Greedy algorithm
Unfortunately, the graph coloring problem is NP-hard: there is currently no way to solve it in polynomial time for every instance. The optimal solution is known only for specific patterns, such as banded matrices. However, efficient heuristics exist which generate good enough solutions in reasonable time. The most widely used heuristic is the greedy algorithm, which processes vertices one after the other. This algorithm assigns to each vertex the smallest color that is not already present among its neighbors, and it never backtracks. A crucial hyperparameter is the choice of ordering, for which various criteria have been proposed
ColPack: Software for graph coloring and related problems in scientific computing [link] A.H. Gebremedhin, D. Nguyen, M.M.A. Patwary, A. Pothen. ACM Transactions on Mathematical Software, Vol 40(1), pp. 1:1--1:31. 2013. DOI: 10.1145/2513109.2513110
[12]
.
Bicoloring
A more advanced coloring technique called bicoloring allows combining forward and reverse modes, because the recovery of the Jacobian matrix leverages both columns (JVPs) and rows (VJPs)
Computing a sparse Jacobian matrix by rows and columns [link] A.K.M.S. Hossain, T. Steihaug. Optimization Methods and Software, Vol 10(1), pp. 33--48. Taylor & Francis. 1998. DOI: 10.1080/10556789808805700
[13]
The Efficient Computation of Sparse Jacobian Matrices Using Automatic Differentiation [link] T.F. Coleman, A. Verma. SIAM Journal on Scientific Computing, Vol 19(4), pp. 1210--1233. Society for Industrial and Applied Mathematics. 1998. DOI: 10.1137/S1064827595295349
[14]
.
Figure 20 shows bicoloring on a toy example in which no pair of columns or rows is structurally orthogonal. Even with ASD, materializing the Jacobian matrix would require 5 5 5 JVPs in forward-mode or 4 4 4 VJPs in reverse mode. However, if we use both modes simultaneously, we can materialize the full Jacobian matrix by computing only 1 1 1 JVP and 1 1 1 VJP. 
Figure 20: Bicoloring on a toy example with a dense row and a dense column.
Second order
While first-order automatic differentiation AD focuses on computing the gradient or Jacobian matrix, second-order AD extends the same ideas to the Hessian matrix
∇ 2 f ( x ) = ( ∂ 2 f ( x ) ∂ x i ∂ x j ) i , j .
The Hessian contains second-order partial derivatives of a scalar function, essentially capturing the curvature of the function at a point. This is particularly relevant in optimization, where the Hessian provides crucial information about the function's local behavior. Specifically, the Hessian allows us to distinguish between local minima, maxima, and saddle points. By incorporating second-order information, optimization algorithms converge more robustly where the gradient alone doesn't provide enough information for effective search directions.
Hessian-vector products
For second-order AD, the key subroutine is the Hessian-vector product (HVP). The Hessian is the Jacobian matrix of the gradient function ∇ f : x ↦ ∇ f ( x ) \nabla f: \mathbf{x} \mapsto \nabla f(\mathbf{x}) ∇ f: x ↦ ∇ f( x) , that is,
∇ 2 f ( x ) = J ∇ f ( x ) .
An HVP computes the product of the Hessian matrix with a vector, which can be viewed as the JVP of the gradient function.
∇ 2 f ( x ) ⋅ v = D [ ∇ f ] ( x ) ( v )
Note that the gradient function is itself computed via a VJP of f f f . Thus, the HVP approach we described computes the JVP of a VJP, giving it the name “forward over reverse”. In forward-over-reverse HVPs, the complexity of a single product scales roughly with the complexity of the function f f f itself. This procedure was first considered by Pearlmutter
Fast Exact Multiplication by the Hessian [link] B.A. Pearlmutter. Neural Computation, Vol 6(1), pp. 147--160. 1994. DOI: 10.1162/neco.1994.6.1.147
[15]
and recently revisited in a 2024 ICLR blog post
How to compute Hessian-vector products? [link] M. Dagréou, P. Ablin, S. Vaiter, T. Moreau. The Third Blogpost Track at ICLR 2024. 2024.
[16]
. Note that other mode combinations are possible, like “forward over forward”, which has a higher complexity but is less expensive in terms of storage.
The Hessian has a symmetric structure (equal to its transpose), which means that matrix-vector products and vector-matrix products coincide. This explains why we don't need a VHP in addition to the HVP. This specificity can be exploited in the sparsity detection as well as in the coloring phase.
Second order pattern detection
Detecting the sparsity pattern of the Hessian is more complicated than for the Jacobian. This is because, in addition to the usual linear dependencies, we now have to account for nonlinear interactions in the computational graph. The operator overloading method of Walther
Computing sparse Hessians with automatic differentiation [link] A. Walther. ACM Transactions on Mathematical Software, Vol 34(1), pp. 3:1--3:15. 2008. DOI: 10.1145/1322436.1322439
[17]
was a pioneering effort towards Hessian sparsity detection, although more efficient alternatives quickly emerged
A new framework for the computation of Hessians [link] R.M. Gower, M.P. Mello. Optimization Methods and Software, Vol 27(2), pp. 251--273. Taylor & Francis. 2012. DOI: 10.1080/10556788.2011.580098
[18]
.
For instance, if f ( x ) f(\mathbf{x}) f( x) involves a term of the form x 1 + x 2 x_1 + x_2 x 1 + x 2  , it will not directly affect the Hessian. However, we cannot ignore this term, since multiplying it with x 3 x_3 x 3  to obtain an output f ( x ) = ( x 1 + x 2 ) x 3 f(\mathbf{x}) = (x_1 + x_2),x_3 f( x)=( x 1 + x 2 ) x 3  will yield non-zero coefficients at positions ( 1 , 3 ) (1, 3) ( 1, 3) , ( 3 , 1 ) (3, 1) ( 3, 1) , ( 2 , 3 ) (2, 3) ( 2, 3) and ( 3 , 2 ) (3, 2) ( 3, 2) . Thus, the abstract interpretation system used for second-order pattern detection needs a finer classification of primitive functions. It must distinguish between locally constant, locally linear, and locally nonlinear behavior in each argument, and distinguish between zero and non-zero cross-derivatives.
Symmetric coloring
When it comes to graph coloring for the Hessian, there are more options for decompression thanks to symmetry. Even if two columns in the Hessian are not structurally orthogonal, missing coefficients can be recovered by leveraging the corresponding rows instead of relying solely on the columns. In other words, if H i j H_{ij} H i j  is lost during compression because of colliding nonzero coefficients, there is still a chance to retrieve it through H j i H_{ji} H j i  . This backup storage enables the use of fewer distinct colors, reducing the complexity of the AD part compared to traditional row or column coloring.
Powell and Toint
On the Estimation of Sparse Hessian Matrices [link] M.J.D. Powell, P.L. Toint. SIAM Journal on Numerical Analysis, Vol 16(6), pp. 1060--1074. Society for Industrial and Applied Mathematics. 1979. DOI: 10.1137/0716078
[19]
were the first to notice symmetry-related optimizations, before Coleman and Moré
Estimation of sparse hessian matrices and graph coloring problems [link] T.F. Coleman, J.J. Moré. Mathematical Programming, Vol 28(3), pp. 243--270. 1984. DOI: 10.1007/BF02612334
[20]
made the connection to graph coloring explicit. While symmetric coloring and decompression are more computationally expensive than their nonsymmetric counterparts, this cost is typically negligible compared to the savings we get from fewer HVPs.
Applications
ASD is useful in applications which involve the computation of full Jacobian or Hessian matrices with sparsity. Let us discuss one of the examples given in the 2024 ICLR blog post How to compute Hessian-vector products?
How to compute Hessian-vector products? [link] M. Dagréou, P. Ablin, S. Vaiter, T. Moreau. The Third Blogpost Track at ICLR 2024. 2024.
[16]
: Newton's method. This canonical algorithm for nonlinear optimization uses Hessians within local steps of the form [ ∇ 2 f ( x ) ] − 1 ∇ f ( x ) [\nabla^2 f(\mathbf{x})]^{-1} \nabla f(\mathbf{x}) [ ∇ 2 f( x)]− 1 ∇ f( x) . The inverse [ ∇ 2 f ( x ) ] − 1 [\nabla^2f(\mathbf{x})]^{-1} [ ∇ 2 f( x)]− 1 is never created explicitly, since it suffices to solve a linear system ∇ 2 f ( x ) ⋅ v = ∇ f ( x ) \nabla^2f(\mathbf{x}) \cdot \mathbf{v} = \nabla f(\mathbf{x}) ∇ 2 f( x) ⋅ v= ∇ f( x) . As the blog post argues, for such systems, matrix-free iterative solvers combine well with Hessian operators because they only require successive evaluations of HVPs. The main advantage of iterative solvers is their small memory footprint and their ease of implementation.
However, when it is possible to materialize the whole Hessian matrix, direct linear solvers can be used (e.g. based on matrix factorization). As we have seen, ASD unlocks this option whenever the Hessian matrix is sparse enough. In terms of performance, computing a sparse Hessian matrix might require fewer HVPs overall than applying an iterative solver like the conjugate gradient method. The exact performance depends on the number of colors in the sparsity pattern of the Hessian, as well as the numerical precision expected from the iterative solver (which influences the number of iterations, hence the number of HVPs). In terms of numerical accuracy, direct solvers are more robust than their iterative counterparts. Finally, in terms of compatibility, some prominent nonlinear optimization libraries only support Hessian matrices, and not Hessian operators.
The same reasoning also applies to Jacobian matrices, which can appear in settings like Newton's method for root-finding, implicit differentiation
Efficient and Modular Implicit Differentiation [PDF] M. Blondel, Q. Berthet, M. Cuturi, R. Frostig, S. Hoyer, F. Llinares-López, F. Pedregosa, J. Vert. arXiv. 2022. DOI: 10.48550/arXiv.2105.15183
[21]
, or solvers for differential equations
Differentiable Programming for Differential Equations: A Review [PDF] F. Sapienza, J. Bolibar, F. Schäfer, B. Groenke, A. Pal, V. Boussange, P. Heimbach, G. Hooker, F. Pérez, P. Persson, C. Rackauckas. arXiv. 2024. DOI: 10.48550/arXiv.2406.09699
[22]
.
Demonstration
We complement this tutorial with a demonstration of automatic sparse differentiation in a high-level programming language, namely the Julia language
Julia: A Fresh Approach to Numerical Computing [link] J. Bezanson, A. Edelman, S. Karpinski, V.B. Shah. SIAM Review, Vol 59(1), pp. 65--98. 2017. DOI: 10.1137/141000671
[23]
. While still at an early stage of development, we hope that such an example of unified pipeline for sparse Jacobians and Hessians can inspire developers in other languages to revisit ASD.
The authors of this blog post are all developers of the ASD ecosystem in Julia. We use Julia for our demonstration since we are not aware of a similar ecosystem in Python or R. At the time of writing, PyTorch, TensorFlow, and JAX lack comparable sparsity detection and coloring capabilities. We are only aware of one JAX library for sparse differentiation, sparsejac , which does not support sparsity detection, uses less efficient graph encodings and has no functionality for symmetric (Hessian) matrices. The closest counterpart we know is coded in C, namely the combination of ADOL-C
Getting Started with ADOL-C [link] A. Walther. DROPS-IDN/v2/document/10.4230/DagSemProc.09061.10. Schloss Dagstuhl – Leibniz-Zentrum für Informatik. 2009. DOI: 10.4230/DagSemProc.09061.10
[24]
and ColPack
ColPack: Software for graph coloring and related problems in scientific computing [link] A.H. Gebremedhin, D. Nguyen, M.M.A. Patwary, A. Pothen. ACM Transactions on Mathematical Software, Vol 40(1), pp. 1:1--1:31. 2013. DOI: 10.1145/2513109.2513110
[12]
.
Necessary packages
Here are the packages we will use for this demonstration.
SparseConnectivityTracer.jl
SparseConnectivityTracer.jl [link] A. Hill, G. Dalle. 2024. DOI: 10.5281/zenodo.13961066 [25] : Sparsity pattern detection with operator overloading.
SparseMatrixColorings.jl
gdalle/SparseMatrixColorings.jl: v0.4.10 [link] G. Dalle, A. Montoison, A. Hill. 2024. DOI: 10.5281/zenodo.14077901 [26] : Greedy algorithms for colorings, decompression utilities.
ForwardDiff.jl
Forward-Mode Automatic Differentiation in Julia [PDF] J. Revels, M. Lubin, T. Papamarkou. arXiv. 2016. DOI: 10.48550/arXiv.1607.07892 [27] : Forward-mode AD and computation of JVPs.
DifferentiationInterface.jl
JuliaDiff/DifferentiationInterface.jl: DifferentiationInterface-v0.6.23 [link] G. Dalle, A. Hill, W. Tebbutt, A. Marcotte, A. Scheidegger, ExpandingMan, F. Wechsler, G. Gerlero, N. Schmitz, P. Yong, V.K. Dixit. 2024. DOI: 10.5281/zenodo.14191253 [28] : High-level interface bringing all of these together, originally inspired by
AbstractDifferentiation.jl: Backend-Agnostic Differentiable Programming in Julia [PDF] F. Schäfer, M. Tarek, L. White, C. Rackauckas. arXiv. 2022. DOI: 10.48550/arXiv.2109.12449 [29] .
This modular pipeline comes as a replacement and extension of a previous ASD system in Julia
Sparsity Programming: Automated Sparsity-Aware Optimizations in Differentiable Programming [link] S. Gowda, Y. Ma, V. Churavy, A. Edelman, C. Rackauckas. Program Transformations for ML Workshop at NeurIPS 2019. 2019.
[30]
. We also use a few other packages for data manipulation
DataFrames.jl: Flexible and Fast Tabular Data in Julia [link] M. Bouchet-Valat, B. Kamiński. Journal of Statistical Software, Vol 107, pp. 1--32. 2023. DOI: 10.18637/jss.v107.i04
[31]
and visualization
Makie.jl: Flexible high-performance data visualization for Julia [link] S. Danisch, J. Krumbiegel. Journal of Open Source Software, Vol 6(65), pp. 3349. 2021. DOI: 10.21105/joss.03349
[32]
.
Like in any other language, the first step is importing the dependencies:
The syntax we showcase is accurate as of the following package versions:
Test function
As our test function, we choose a very simple iterated difference operator. It takes a vector x ∈ R n \mathbf{x} \in \mathbb{R}^n x ∈ R n and outputs a slightly shorter vector y ∈ R n − k y \in \mathbb{R}^{n-k} y ∈ R n− k depending on the number of iterations k k k . In pure Julia, this is written as follows (using the built-in diff recursively):
Let us check that the function returns what we expect:
Backend switch
The key concept behind DifferentiationInterface.jl is that of backends. There are several AD systems in Julia, each with different features and tradeoff, that can be accessed through a common API. Here, we use ForwardDiff.jl as our AD backend:
To build an ASD backend, we bring together three ingredients corresponding to each step:
Jacobian computation
We can now compute the Jacobian of iter_diff (with respect to x \mathbf{x} x ) using either backend, and compare the results. Just like AD, ASD is fully automatic. It doesn't require the user to change any code besides specifying a backend:
In one case, we get a dense matrix, in the other it is sparse. Note that in Julia, linear algebra operations are optimized for sparse matrices, which means this format can be beneficial for downstream use. We now show that sparsity also unlocks faster computation of the Jacobian itself.
Preparation
Sparsity pattern detection and matrix coloring are performed in a so-called “preparation step”, whose output can be reused across several calls to jacobian (as long as the pattern stays the same).
Thus, to extract more performance, we can create this object only once
and then reuse it as much as possible, for instance inside the loop of an iterative algorithm (note the additional prep argument):
Inside the preparation result, we find the output of sparsity pattern detection
and the coloring of the columns:
Note that it uses only c = 4 c = 4 c= 4 different colors, which means we need 4 4 4 JVPs instead of the initial n = 1 0 n = 10 n= 1 0 to reconstruct the Jacobian.
Coloring visualization
We just saw that there is a discrepancy between the number of different colors c c c and the input size n n n . This ratio n / c n / c n/ c typically gets larger as the input grows, which makes sparse differentiation more and more competitive.
We illustrate this with the Jacobians of iter_diff for several values of n n n and k k k : 
Figure 21: Coloring numbers are often agnostic to the input size.
The main takeaway of Figure 21 is that in this case, the number of colors does not depend on the dimension n n n , only on the number of iterations k k k . In fact, iter_diff with k k k iterations gives rise to a banded Jacobian with k + 1 k+1 k+ 1 bands, for which we can easily verify that the optimal coloring uses as many colors as bands, i.e. c = k + 1 c = k+1 c= k+ 1 . For this particular case, the greedy coloring also happens to find the optimal solution.
Performance benefits
Here we present a benchmark for the Jacobian of iter_diff with varying n n n and fixed k k k . Our goal is to find out when sparse differentiation becomes relevant. Benchmark data can be generated with the following code:
It gives rise to the following performance curves (lower is better): 
Figure 22: Performance benefits of sparsity
As we can see on Figure 22, there are three main regimes:
For very small inputs, we gain nothing by leveraging sparsity.
For medium-sized inputs, sparsity handling is only useful if we can amortize the cost of detection and coloring.
For very large inputs, even the overhead of detection and coloring is worth paying as part of a sparse Jacobian computation.
Importantly, ASD can yield an asymptotic speedup compared to AD, not just a constant one. In our test case, the cost of a JVP for iter_diff scales with k n kn k n . Sparse differentiation requires c c c JVPs instead of n n n , so with c = k + 1 c = k+1 c= k+ 1 here its total cost scales as Θ ( k 2 n ) \Theta(k^2 n) Θ( k 2 n) instead of Θ ( k n 2 ) \Theta(k n^2) Θ( k n 2) . Thus, on the log-log plot of Figure 22, the ASD curve (without detection) has a slope of 1 1 1 while the AD curve has a slope of 2 2 2 .
Although the specific thresholds between regimes are problem-dependent, our conclusions hold in general.
Conclusion
By now, the reader should have a better understanding of how sparsity can be used for efficient differentiation.
But should it always be used? Here are a list of criteria to consider when choosing between AD and ASD:
Which derivative is needed? When computing gradients of scalar functions using reverse mode, sparsity can't be leveraged, as only a single VJP is required. In practice, ASD only speeds up derivatives like the Jacobian and Hessian which have a matrix form.
What operations will be performed on the derivative matrix? For a single matrix-vector product J v J \mathbf{v} J v , the Jacobian operator will always be faster. But if we want to solve linear systems J v = y J \mathbf{v} = \mathbf{y} J v= y , then it may be useful to compute the full Jacobian matrix first to leverage sparse factorization routines.
How expensive is the function at hand? This directly impacts the cost of a JVP, VJP or HVP, which scales with the cost of one function evaluation.
How sparse would the matrix be? This dictates the efficiency of sparsity detection and coloring, as well as the number of matrix-vector products necessary. While it may be hard to get an exact estimate, concepts like partial separability can help provide upper bounds
Computing the sparsity pattern of Hessians using automatic differentiation [link] R.M. Gower, M.P. Mello. ACM Transactions on Mathematical Software, Vol 40(2), pp. 10:1--10:15. 2014. DOI: 10.1145/2490254 [33] . In general, the relation between the number of colors c c c and the dimension n n n is among the most crucial quantities to analyze.
In simple settings (like finite differences, which create banded Jacobians), the sparsity pattern and optimal coloring can be derived manually. But as soon as the function becomes more complex, automating this process becomes essential to ensure wide usability. We hope that the exposition above will motivate the implementation of user-friendly ASD in a variety of programming languages and AD frameworks.
Footnotes
References
Evaluating derivatives: principles and techniques of algorithmic differentiation [link] Griewank, A. and Walther, A., 2008. Society for Industrial and Applied Mathematics.
PyTorch: An Imperative Style, High-Performance Deep Learning Library [HTML] Paszke, A., Gross, S., Massa, F., Lerer, A., Bradbury, J., Chanan, G., Killeen, T., Lin, Z., Gimelshein, N., Antiga, L., Desmaison, A., Kopf, A., Yang, E., DeVito, Z., Raison, M., Tejani, A., Chilamkurthy, S., Steiner, B., Fang, L., Bai, J. and Chintala, S., 2019. Advances in Neural Information Processing Systems, Vol 32. Curran Associates, Inc.
JAX: composable transformations of Python+NumPy programs [link] Bradbury, J., Frostig, R., Hawkins, P., Johnson, M.J., Leary, C., Maclaurin, D., Necula, G., Paszke, A., VanderPlas, J., Wanderman-Milne, S. and Zhang, Q., 2018.
Differentiable Programming for Differential Equations: A Review [PDF] Sapienza, F., Bolibar, J., Schäfer, F., Groenke, B., Pal, A., Boussange, V., Heimbach, P., Hooker, G., Pérez, F., Persson, P. and Rackauckas, C., 2024. arXiv. DOI: 10.48550/arXiv.2406.09699
The Elements of Differentiable Programming [PDF] Blondel, M. and Roulet, V., 2024. arXiv. DOI: 10.48550/arXiv.2403.14606
The complexity of partial derivatives [link] Baur, W. and Strassen, V., 1983. Theoretical Computer Science, Vol 22(3), pp. 317--330. DOI: 10.1016/0304-3975(83)90110-X
On the Estimation of Sparse Jacobian Matrices [link] Curtis, A.R., Powell, M.J.D. and Reid, J.K., 1974. IMA Journal of Applied Mathematics, Vol 13(1), pp. 117--119. DOI: 10.1093/imamat/13.1.117
What Color Is Your Jacobian? Graph Coloring for Computing Derivatives [link] Gebremedhin, A.H., Manne, F. and Pothen, A., 2005. SIAM Review, Vol 47(4), pp. 629--705. Society for Industrial and Applied Mathematics. DOI: 10/cmwds4
Automatic differentiation of large sparse systems [link] Dixon, L.C.W., Maany, Z. and Mohseninia, M., 1990. Journal of Economic Dynamics and Control, Vol 14(2), pp. 299--311. DOI: 10.1016/0165-1889(90)90023-A
Detecting Jacobian sparsity patterns by Bayesian probing [link] Griewank, A. and Mitev, C., 2002. Mathematical Programming, Vol 93(1), pp. 1--25. DOI: 10.1007/s101070100281
Efficient computation of gradients and Jacobians by dynamic exploitation of sparsity in automatic differentiation [link] Bischof, C.H., Khademi, P.M., Buaricha, A. and Alan, C., 1996. Optimization Methods and Software, Vol 7(1), pp. 1--39. Taylor & Francis. DOI: 10.1080/10556789608805642
ColPack: Software for graph coloring and related problems in scientific computing [link] Gebremedhin, A.H., Nguyen, D., Patwary, M.M.A. and Pothen, A., 2013. ACM Transactions on Mathematical Software, Vol 40(1), pp. 1:1--1:31. DOI: 10.1145/2513109.2513110
Computing a sparse Jacobian matrix by rows and columns [link] Hossain, A.K.M.S. and Steihaug, T., 1998. Optimization Methods and Software, Vol 10(1), pp. 33--48. Taylor & Francis. DOI: 10.1080/10556789808805700
The Efficient Computation of Sparse Jacobian Matrices Using Automatic Differentiation [link] Coleman, T.F. and Verma, A., 1998. SIAM Journal on Scientific Computing, Vol 19(4), pp. 1210--1233. Society for Industrial and Applied Mathematics. DOI: 10.1137/S1064827595295349
Fast Exact Multiplication by the Hessian [link] Pearlmutter, B.A., 1994. Neural Computation, Vol 6(1), pp. 147--160. DOI: 10.1162/neco.1994.6.1.147
How to compute Hessian-vector products? [link] Dagréou, M., Ablin, P., Vaiter, S. and Moreau, T., 2024. The Third Blogpost Track at ICLR 2024.
Computing sparse Hessians with automatic differentiation [link] Walther, A., 2008. ACM Transactions on Mathematical Software, Vol 34(1), pp. 3:1--3:15. DOI: 10.1145/1322436.1322439
A new framework for the computation of Hessians [link] Gower, R.M. and Mello, M.P., 2012. Optimization Methods and Software, Vol 27(2), pp. 251--273. Taylor & Francis. DOI: 10.1080/10556788.2011.580098
On the Estimation of Sparse Hessian Matrices [link] Powell, M.J.D. and Toint, P.L., 1979. SIAM Journal on Numerical Analysis, Vol 16(6), pp. 1060--1074. Society for Industrial and Applied Mathematics. DOI: 10.1137/0716078
Estimation of sparse hessian matrices and graph coloring problems [link] Coleman, T.F. and Moré, J.J., 1984. Mathematical Programming, Vol 28(3), pp. 243--270. DOI: 10.1007/BF02612334
Efficient and Modular Implicit Differentiation [PDF] Blondel, M., Berthet, Q., Cuturi, M., Frostig, R., Hoyer, S., Llinares-López, F., Pedregosa, F. and Vert, J., 2022. arXiv. DOI: 10.48550/arXiv.2105.15183
Differentiable Programming for Differential Equations: A Review [PDF] Sapienza, F., Bolibar, J., Schäfer, F., Groenke, B., Pal, A., Boussange, V., Heimbach, P., Hooker, G., Pérez, F., Persson, P. and Rackauckas, C., 2024. arXiv. DOI: 10.48550/arXiv.2406.09699
Julia: A Fresh Approach to Numerical Computing [link] Bezanson, J., Edelman, A., Karpinski, S. and Shah, V.B., 2017. SIAM Review, Vol 59(1), pp. 65--98. DOI: 10.1137/141000671
Getting Started with ADOL-C [link] Walther, A., 2009. DROPS-IDN/v2/document/10.4230/DagSemProc.09061.10. Schloss Dagstuhl – Leibniz-Zentrum für Informatik. DOI: 10.4230/DagSemProc.09061.10
SparseConnectivityTracer.jl [link] Hill, A. and Dalle, G., 2024. DOI: 10.5281/zenodo.13961066
gdalle/SparseMatrixColorings.jl: v0.4.10 [link] Dalle, G., Montoison, A. and Hill, A., 2024. DOI: 10.5281/zenodo.14077901
Forward-Mode Automatic Differentiation in Julia [PDF] Revels, J., Lubin, M. and Papamarkou, T., 2016. arXiv. DOI: 10.48550/arXiv.1607.07892
JuliaDiff/DifferentiationInterface.jl: DifferentiationInterface-v0.6.23 [link] Dalle, G., Hill, A., Tebbutt, W., Marcotte, A., Scheidegger, A., ExpandingMan,, Wechsler, F., Gerlero, G., Schmitz, N., Yong, P. and Dixit, V.K., 2024. DOI: 10.5281/zenodo.14191253
AbstractDifferentiation.jl: Backend-Agnostic Differentiable Programming in Julia [PDF] Schäfer, F., Tarek, M., White, L. and Rackauckas, C., 2022. arXiv. DOI: 10.48550/arXiv.2109.12449
Sparsity Programming: Automated Sparsity-Aware Optimizations in Differentiable Programming [link] Gowda, S., Ma, Y., Churavy, V., Edelman, A. and Rackauckas, C., 2019. Program Transformations for ML Workshop at NeurIPS 2019.
DataFrames.jl: Flexible and Fast Tabular Data in Julia [link] Bouchet-Valat, M. and Kamiński, B., 2023. Journal of Statistical Software, Vol 107, pp. 1--32. DOI: 10.18637/jss.v107.i04
Makie.jl: Flexible high-performance data visualization for Julia [link] Danisch, S. and Krumbiegel, J., 2021. Journal of Open Source Software, Vol 6(65), pp. 3349. DOI: 10.21105/joss.03349
Computing the sparsity pattern of Hessians using automatic differentiation [link] Gower, R.M. and Mello, M.P., 2014. ACM Transactions on Mathematical Software, Vol 40(2), pp. 10:1--10:15. DOI: 10.1145/2490254
For attribution in academic contexts, please cite this work as
BibTeX citation
0 Comments - powered by utteranc.es
Write Preview
Nothing to preview
Styling with Markdown is supported Comment Sign in with GitHub