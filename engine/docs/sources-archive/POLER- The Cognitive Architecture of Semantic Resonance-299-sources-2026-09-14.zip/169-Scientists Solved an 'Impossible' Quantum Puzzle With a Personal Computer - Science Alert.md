> Source: https://www.sciencealert.com/scientists-solved-an-impossible-quantum-puzzle-with-a-personal-computer

Scientists Solved an 'Impossible' Quantum Puzzle With a Personal Computer : ScienceAlert   Search
Space
Health
Environment
Humans
Tech
Nature
Physics
Society
Opinion
Explainer
About Us
Our Team
Follow Us
Big breakthroughs. Bold ideas. Straight to your inbox. Subscribe [x] Daily
Daily roundup [x] Editorial Spark: Our top stories
Contact
Privacy
Privacy Manager
Accessibility
Terms
© 2026 ScienceAlert Pty Ltd Search
Scientists Solved an 'Impossible' Quantum Puzzle With a Personal Computer
Physics 30 May 2026
By David Nield
Add ScienceAlert on Google 
A visual representation of tensor networks. (Lucy Reading-Ikkanda/Simons Foundation)
Efforts to advance quantum computing are also raising the bar for classical computing – showing that these conventional workhorses aren't done yet.
A specially tweaked classical computer system has just solved a physics problem so complex it was thought to be impossible without a quantum computer.
The problem is the simulation of what are called spin glasses, a state of matter where tiny atomic-level magnets are chaotically positioned.
Spin glasses are also quantum in nature – existing in a state of superposition, a blurry combination of possible alignments.
Last year, researchers  modeled a quantum spin glass system using the D-Wave Advantage2 quantum computer. An impressive feat, and one that could only be done by a quantum system, it was claimed at the time. 
Tensor networks were used to simplify the quantum entanglement data. (Lucy Reading-Ikkanda/Simons Foundation)
Now, a team from the Flatiron Institute in the US has achieved similar results from a classic computer setup, with the key innovation being new compression algorithms that process the necessary mountain of math in a more efficient way.
"It's this very powerful compression that can be very effective, but it's a pretty complex mathematical object," says physicist Joseph Tindall.
"This really is a bit of a frontier, because working with these objects – especially in three dimensions – is very untrodden.
"You need sophisticated codes and algorithms to deal with them; it's a software engineering challenge in itself."
Tindall and his team at the Flatiron Institute seem to have quite a knack for finding clever ways to enhance the capacity of classical computers. In 2024, they shattered expectations of what classical computing was thought to be capable of – and now it appears they've done it again.
A significant part of this latest challenge is that spin glasses exhibit quantum entanglement, where the disordered magnets in the material are 'bound' to each other in increasingly complex ways. As the system gets bigger, the amount of number-crunching needed to keep track of it rises exponentially. 
frameborder="0″ allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
The solution was tensor networks: a way of focusing on the most essential connections in the system, from which everything else can be figured out. The approach strips out redundant information, similar to a compressed zip file on a hard drive.
Tensor networks were combined with an older algorithm known as belief propagation, which extracts information from the simulation. Like tensor networks, belief propagation is incredibly efficient – so efficient that some of the initial calculations could be done on a normal laptop.
"It's a little more approximate than some of the other methods, but it's way cheaper, and we can run it much more directly on lots of harder problems," says physicist Miles Stoudenmire.
While the larger spin glass geometries modeled by the researchers required an expensive, high-level chipset and graphics card, rather than an off-the-shelf laptop, they were still using a computer that was very much classical in the traditional sense.
And the simulations run by the team showed results as good as or even better than those achieved by the quantum computer, for spin glass systems with cylindrical, diamond, and cubic lattice structures.
This can definitely be seen as a success for classical computing – with some clever extra math applied – but it's hardly a loss for quantum computing.
Understanding the areas in which quantum computers really do (and don't) have advantages over current hardware will help focus future research.
It also shows how classical computer systems can act as checks and supports for quantum computers.
Related: Atomic Clocks Could Reveal The Hidden Quantum Nature of Time Itself
There are still many questions about quantum computing and its potential capabilities, and studies like this one will help researchers reach answers more quickly.
"The good side of the classical versus quantum computing debate is that there's a lot of synergy between the kind of simulations we're interested in and the codes we write and what can be realized on these quantum computers," says Tindall.
"That can help guide us, and it can also help guide quantum computing researchers, because, obviously, the barrier for entry for us to simulate certain things is a lot easier than for them, because we don't have to build a quantum computer."
The research has been published in Science.
Big breakthroughs. Bold ideas. Straight to your inbox.
Big breakthroughs. Bold ideas. Straight to your inbox. Subscribe [x] Daily
Daily roundup [x] Editorial Spark: Our top stories 
Ancient Egyptian Mummy Found Wrapped In Something Never Seen Before Discover 
Most People Develop Diverticulosis in Their Gut by The Age of 80... So What Is It? Discover 
A Common Vitamin Has a Complicated Link to Cancer, Experts Reveal Discover 
New UFO Files Suggest Something Strange Is Happening in The Skies Discover 
Study Shows Meat Eaters Are More Likely to Live to 100, But There's a Catch Discover 
Ancient Egyptian Mummy Found Wrapped In Something Never Seen Before Here's something archaeologists don't see every day, or indeed ever: An ancient Egyptian mummy with an excerpt from the classic Greek text the Iliad plastered to its abdomen.
Undo 
Most People Develop Diverticulosis in Their Gut by The Age of 80... So What Is It? It's easy to see your body aging on the outside – wrinkles, dark spots, gray hair, the whole shebang – but as we grow older, our insides also inevitably change.
Undo 
A Common Vitamin Has a Complicated Link to Cancer, Experts Reveal Vitamins are usually framed in simple terms: Get the right amounts, and your body will shine.
Undo 
New UFO Files Suggest Something Strange Is Happening in The Skies The US Government has released a new trove of documents on various cases of "Unidentified Anomalous Phenomena" (UAPs) – many of which would have been described in the past as Unidentified Flying Objects or UFOs – including photos, videos, and reports of unexplained events sighted in the sky and in s
Undo
Get the latest science first
Subscribe [x] Daily
Daily roundup [x] Editorial Spark: Our top stories
Trending News
'Mammoth' Bones Kept in a Museum For 70 Years Turn Out to Be Entirely Different Animal Nature 4 days ago
Ancient Killer Is Rapidly Gaining Resistance to Antibiotics, Study Warns Health 2 days ago
A Common Blood Pressure Drug Boosts Lifespan And Slows Aging in Animals Health 1 day ago      