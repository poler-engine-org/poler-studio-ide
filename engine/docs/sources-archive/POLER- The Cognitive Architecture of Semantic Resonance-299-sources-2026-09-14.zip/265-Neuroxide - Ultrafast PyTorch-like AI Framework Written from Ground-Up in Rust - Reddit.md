> Source: https://www.reddit.com/r/rust/comments/1qah0qk/neuroxide_ultrafast_pytorchlike_ai_framework/

Neuroxide - Ultrafast PyTorch-like AI Framework Written from Ground-Up in Rust : r/rust
Skip to main content Neuroxide - Ultrafast PyTorch-like AI Framework Written from Ground-Up in Rust : r/rust
Open menu
Open navigation 
Go to Reddit Home 
r/rust
TRENDING TODAY
Get App
Get the Reddit app
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Navigation Skip to Right Sidebar
Back
 Go to rust
r/rust
• 2mo ago
TheDragonflyMaster
Locked post
Stickied post
Archived post
View post in other languages
Report
Neuroxide - Ultrafast PyTorch-like AI Framework Written from Ground-Up in Rust
Hello everyone,
GitHub: https://github.com/DragonflyRobotics/Neuroxide
I wish to finally introduce Neuroxide, the ultrafast, modular computing framework written from the ground up. As of now, this project supports full automatic differentiation, binary and unary ops, full Torch-like tensor manipulation, CUDA support, and a Torch-like syntax. It is meant to give a fresh look on modular design of AI frameworks while leveraging the power of Rust. It is written to be fully independent and not use any tensor manipulation framework. It also implements custom heap memory pools and memory block coalescing.
In the pipeline:
It will support virtual striding to reduce copying and multithreaded CPU computation (especially for autograd).
It will also begin supporting multi-gpu and cluster computing (for SLURM and HPC settings).
It's primary goal is to unify scientific and AI computing across platforms like Intel MKL/oneDNN, ROCm, CUDA, and Apple Metal.
It will also include a Dynamo-like graph optimizer and topological memory block compilation.
Finally, due to its inherent syntactical similarities to Torch and Tensorflow, I want Torchscript and Torch NN Modules to directly transpile to Neuroxide.
Please note that this is still under HEAVY development and I would like suggestions, comments, and most importantly contributions. It has been a year long project laced between university studies and contributions would drastically grow the project. Suggestions to improve and grow the project are also kindly appreciated! If contributor want a more polished Contributing.md, I can certainly get that to be more informative.
Sample program with Neuroxide (ReadMe may be slightly outdated with recent syntax changes):
Read more
137
· 20
Comments Section
psychelic_patch
•
2mo ago
Hei honestly rust needs a project like this to help it grow in the scientific community which is unfortunately plagued with python free types -- in some school nearby me it was reported that 100% projects had int type issues ; and in my last 2 year start up mission i had to come up with this aberration https://github.com/6r17/madtypes
So please take my upvote, much luck with your project, build it out serious I know the community might be difficult to shift especially considering the quality requirements - but it's really needed - maybe some labs would even pay for it tbh if it's really done meticulously
That said i'd still roll out my own lmao
44
TheDragonflyMaster
OP
• 2mo ago
Thanks for the reply. I think there is an appeal to free type Pythonic development for rapid prototyping. I think in the long run, doing prototyping in Python and finalizing in a more safe system like this has a lot of value. Torch is impressive at maintaining these safeties but I think there are many other benefits to a Rust based framework over Python. I can enforce traits and features ensuring full compatibility for new modules. Unlike Torch, if Neuroxide supports ROCm, it will enforcement as much compatibility as CUDA to even compile. That is very useful.
5
Comprehensive_Use713
•
2mo ago
Why not use Pydantic… maybe I am missing something
4
Continue this thread 
CanadianTuero
•
2mo ago
I've written a tensor/autograd library myself, and these are some of the things which you should think about sooner rather than later (if you haven't already) if you want to support as this may force you to redesign how things are implemented under the hood: in-place ops, saving/loading tensors from a file while their references are kept valid (i.e. an optimizer holding a tensor from a layer, loading from file, then continue to run the optimizer without having to reload the reference), user defined backends, user defined autograd ops. I would try and track the number of allocations you operations are making, as this can uncover excessive copies that are being made for things which shouldn't allocate at all (i.e. a reshape in forward/backward shouldn't allocate new data except for the tensor metadata).
But a project like this is certainly a good one to take on as it will teach you a lot!
11
TheDragonflyMaster
OP
• 1mo ago
Very useful!
1
thisismyfavoritename
•
2mo ago
is ultra fast better than blazing? Is there a standard scale
33 
afdbcreid
•
1mo ago
Python is the gold standard in AI and it declares that "ultra" > "blazing" .
7
narsilouu
•
2mo ago
Hey well done !!
Have you checked other projects that try to do the same like
https://github.com/tracel-ai/burn
https://github.com/huggingface/candle
https://github.com/chelsea0x3b/dfdx
You should at least check the dependencies and kernels, it might give you a bootleg in speeding this.
Good luck on this undertaking, it's not easy.
13
TheDragonflyMaster
OP
• 2mo ago
I have seen Burn, it is very impressive and very close to my project! Definitely need to inspire some efficiency improvements from there.
2
Continue this thread
PXaZ
•
2mo ago
Can you replace the vec![]s with []? Since they're literals the size can be known at compile time, eliminating the utility of Vec vis-a-vis an array. Could clean up the user experience, too.
I find it unintuitive to give the shape after the data---isn't it conventional to give shape first?
I keep looking for a Rust ML framework that statically checks shape at compile time (so much as it's known). Like const generics but where the const value can be an array, and the elements of the array can be Option to allow for unknown (dynamic) dimensions.
This is in fact a path of development that others are considering, see here and here.
You can get some of that now using the mdarray crate, discussed in the first link, with which the shape can be known at compile time. It allows both static and dynamic (i.e. unknown at compile time) dimensions, allowing both static and dynamic compute graphs.
It does seem like only a matter of time before such function is part of the language, or easily implemented using native language facilities, whereas now it is done using macros and limited to shapes of rank 6 or less. Perhaps you could help move that direction of development along. Compile-time checking of compute graphs would save a lot of duck-type nonsense unworthy of Rust, lol. (I love you, too, Ruby!)
5 
pokemonplayer2001
•
1mo ago
Have we dropped "blazing-fast" in favour of "ultrafast" now?
2 
madtowneast
•
2mo ago
Have you looked at
https://github.com/paiml
And how is this different?
1
TheDragonflyMaster
OP
• 2mo ago
Thank you for bringing that to my attention. It seems like paiml is a collection of Rust tools for AI and ML work. This is meant to be an entire platform like Torch for low level ML development. But I could be wrong since I am not familiar with this project.
1
Continue this thread
ZealousidealShoe7998
•
2mo ago
how much of a dropping replacement to torch-rs - pytorch is this currently.
i'm not much familiar since I only have built projects with pytorch using help of a llm.
but recently I translated a pytorch project into torch-rs and I was very impressed with the speed up results.
once I get more familiar with rust I would be willing to give more inputs and possibiliy help this project
1
Related Answers Section
Related Answers
Overview of Neuroxide AI framework in Rust
Best deep learning frameworks for Rust
Comparison of PyTorch and Rust for AI
AI assistant products similar to Meta AI
Reasons for Rust's popularity in AI and ML
New to Reddit?
Create your account and connect with a world of communities.
Continue with Email
Continue With Phone Number
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy.
More posts you may like
Built a small PyTorch-style deep learning framework in pure Rust (for my own model)  r/rust • 1mo ago [
Built a small PyTorch-style deep learning framework in pure Rust (for my own model)
](https://www.reddit.com/r/rust/comments/1qbbg2r/built_a_small_pytorchstyle_deep_learning/) 1 comment
Symbiont: A Zero Trust AI Agent Framework in Rust  r/rust • 7mo ago [
Symbiont: A Zero Trust AI Agent Framework in Rust
](https://www.reddit.com/r/rust/comments/1mq7212/symbiont_a_zero_trust_ai_agent_framework_in_rust/)  13 comments
Using existing trained model from PyTorch in my project?  r/rust • 2y ago [
Using existing trained model from PyTorch in my project?
](https://www.reddit.com/r/rust/comments/1ekdqub/using_existing_trained_model_from_pytorch_in_my/) 3 comments
[P] PyTorch bindings for Rust and OCaml  r/MachineLearning • 7y ago [
[P] PyTorch bindings for Rust and OCaml
](https://www.reddit.com/r/MachineLearning/comments/axy689/p_pytorch_bindings_for_rust_and_ocaml/) 98 upvotes · 22 comments
Transitioning From PyTorch to Burn  r/rust • 2y ago [
Transitioning From PyTorch to Burn
](https://www.reddit.com/r/rust/comments/1aqx9ei/transitioning_from_pytorch_to_burn/) 52 upvotes · 5 comments
Can-t Stop till you get enough: rewriting Pytorch in Rust  r/rust • 4mo ago [
Can-t Stop till you get enough: rewriting Pytorch in Rust
](https://www.reddit.com/r/rust/comments/1oodyoo/cant_stop_till_you_get_enough_rewriting_pytorch/)  bearblog 188 upvotes · 10 comments
(Machine Learning) I spent 12+ hours trying to interface with Python/Pytorch/Tensorflow before learning about a new pure-Rust Tensor implementation from Hugging Face called "Candle". By comparison, it's been a joy to work with so far.  r/rust • 2y ago [
(Machine Learning) I spent 12+ hours trying to interface with Python/Pytorch/Tensorflow before learning about a new pure-Rust Tensor implementation from Hugging Face called "Candle". By comparison, it's been a joy to work with so far.
](https://www.reddit.com/r/rust/comments/17odp2g/machine_learning_i_spent_12_hours_trying_to/)  github 147 upvotes · 15 comments
Are there any AI crates like pytorch?  r/rust • 4y ago [
Are there any AI crates like pytorch?
](https://www.reddit.com/r/rust/comments/x7x57f/are_there_any_ai_crates_like_pytorch/) 17 upvotes · 6 comments
Issue building with Rust Pytorch  r/rust • 2y ago [
Issue building with Rust Pytorch
](https://www.reddit.com/r/rust/comments/18mnri0/issue_building_with_rust_pytorch/) 2 comments
Issue building Pytorch with Rust  r/learnrust • 2y ago [
Issue building Pytorch with Rust
](https://www.reddit.com/r/learnrust/comments/18mnuf4/issue_building_pytorch_with_rust/) 3 upvotes · 1 comment
Setting up tch-rs to use pytorch from active python venv  r/rust • 2y ago [
Setting up tch-rs to use pytorch from active python venv
](https://www.reddit.com/r/rust/comments/1eoblgl/setting_up_tchrs_to_use_pytorch_from_active/) 1 upvote · 1 comment
Need your opinion! How are you using AI to code with Rust now?  r/rust • 5mo ago [
Need your opinion! How are you using AI to code with Rust now?
](https://www.reddit.com/r/rust/comments/1o1wrl0/need_your_opinion_how_are_you_using_ai_to_code/) 15 comments
[Project] Kuat: A Rust-based, Zero-Copy Dataloader for PyTorch (4.6x training speedup on T4/H100)  r/MachineLearning • 1mo ago [
[Project] Kuat: A Rust-based, Zero-Copy Dataloader for PyTorch (4.6x training speedup on T4/H100)
](https://www.reddit.com/r/MachineLearning/comments/1qig3ae/project_kuat_a_rustbased_zerocopy_dataloader_for/) 73 upvotes · 24 comments
Are there any reasonable approaches to profiling a Rust program?  r/rust • 4mo ago [
Are there any reasonable approaches to profiling a Rust program?
](https://www.reddit.com/r/rust/comments/1odc23v/are_there_any_reasonable_approaches_to_profiling/) 45 upvotes · 34 comments
Q: Building AI Agents in Rust  r/rust • 1y ago [
Q: Building AI Agents in Rust
](https://www.reddit.com/r/rust/comments/1hmh1ox/q_building_ai_agents_in_rust/) 14 upvotes · 35 comments
Is anyone doing Machine Learning in Rust?  r/rust • 3y ago [
Is anyone doing Machine Learning in Rust?
](https://www.reddit.com/r/rust/comments/13eij5q/is_anyone_doing_machine_learning_in_rust/) 85 upvotes · 39 comments
Advanced Rust users, what is the most valuable skill to become more productive with the language?  r/rust • 23d ago [
Advanced Rust users, what is the most valuable skill to become more productive with the language?
](https://www.reddit.com/r/rust/comments/1qu5u50/advanced_rust_users_what_is_the_most_valuable/) 202 upvotes · 103 comments
Burn Deep Learning Framework 0.11.0 Released: Just-in-Time Automatic Kernel Fusion & Founding Announcement  r/rust • 2y ago [
Burn Deep Learning Framework 0.11.0 Released: Just-in-Time Automatic Kernel Fusion & Founding Announcement
](https://www.reddit.com/r/rust/comments/188mnff/burn_deep_learning_framework_0110_released/) 139 upvotes · 9 comments
What makes Rust the best language for Deep Learning  r/rust • 2y ago [
What makes Rust the best language for Deep Learning
](https://www.reddit.com/r/rust/comments/1bixnh4/what_makes_rust_the_best_language_for_deep/) 177 upvotes · 41 comments
Deep Learning Frameworks Compared r/coding • 10y ago [
Deep Learning Frameworks Compared
](https://www.reddit.com/r/coding/comments/55b536/deep_learning_frameworks_compared/)  youtube 19 upvotes · 2 comments
Best way to get comfortable with Rust in 3 months? (moving from Python and Java)  r/rust • 1mo ago [
Best way to get comfortable with Rust in 3 months? (moving from Python and Java)
](https://www.reddit.com/r/rust/comments/1qphy6n/best_way_to_get_comfortable_with_rust_in_3_months/) 4 upvotes · 21 comments
Does it make sense to learn Rust if you're into ML?  r/rust • 7mo ago [
Does it make sense to learn Rust if you're into ML?
](https://www.reddit.com/r/rust/comments/1m713d0/does_it_make_sense_to_learn_rust_if_youre_into_ml/) 37 upvotes · 55 comments
[D] What's your deep learning framework of choice?  r/MachineLearning • 6y ago [
[D] What's your deep learning framework of choice?
](https://www.reddit.com/r/MachineLearning/comments/ehnh28/d_whats_your_deep_learning_framework_of_choice/) 23 comments
Best way to learn Rust?  r/rust • 5mo ago [
Best way to learn Rust?
](https://www.reddit.com/r/rust/comments/1nvrl36/best_way_to_learn_rust/) 37 upvotes · 40 comments
I never programmed in my life and I wanna learn rust, do you know any courses for that?  r/rust • 4mo ago [
I never programmed in my life and I wanna learn rust, do you know any courses for that?
](https://www.reddit.com/r/rust/comments/1ocdk7p/i_never_programmed_in_my_life_and_i_wanna_learn/) 63 comments
View Post in
Français
Community Info Section
r/rust
Join
The Rust Programming Language
A place for all things related to the Rust programming language—an open-source systems language that emphasizes performance, reliability, and productivity.
Show more
Public
Anyone can view, post, and comment to this community
Reddit Rules Privacy Policy User Agreement Your Privacy Choices Accessibility Reddit, Inc. © 2026. All rights reserved.
Expand Navigation
Expand Navigation
Collapse Navigation
Collapse Navigation 
0cAFcWeA5CTlRwYukzpSFTMWFuGqfRYuytEg1epWuEwrQM-Vd4Qqf_M1irDDf0XsiY8MP6QFsBBg3c17m4roem4Ja4oW80pKvaQPRcIV9LvMP4IyirTweIvEZtMG36zgy-4HbyluJL16AOqJScwWuQv07Olp2w7i6njTZcSQ0B7rYZ2Hsyk349THPtBnpoZRkC1JeudgD-VsHd8LUUW6C9OTozGot1NOdRSIjihs-pfcALLKbLPyDDX-1Ei1WDUXRZy8eiI6ZuGzAwf5CN2T4ifXttUd2J3urmFH3K_jP2byollUy9dhVR8BiJ8x7qAQsIjbspXp4_F2aLhQ7DvKDf29082ZjBiIuUXN87dnswetdmPjozVBX0sp5ycQT01adIMnnoPo5FN_Uuh6-KhY5nHqXBjbVqG8ZUdNtg6hDUnz2BJLtgeplzbXLVL-6MPcZWYd5rA4RrZMh_byND6p36a7B4vrZrgEcashmV2_C4yrAPAQuHgZGhAnJWicDttOAofjFCY7dJlzKHn5bRBcih33jeQeuhBqHuSBsXw8V5RPuWVlMhMC4Dyje3MLbV3Ib43_kMmpRWSX9bPS9MwT8cIuOL_bT4AIZV6LAL31KeT8U_qG2JzYPC8HYyLsKdmoHyUmWdy0k2PAWjXfjpcUdDet6lxweUnJI6JXYOl3gWOSU82zmusJkT4wCVn2u8BuKmgJNfwyIIaYKfWapWWGjeTo3z2R7vhxMfPlf5xRsl1tYTwbbAdgcwZBAXrcZBWH6w6e7MHwXA8R111tJmFJN03PUZU_pUUq1ujGfK5amYDZrrtOfIqIYuhD4SZCbk73wT6vsry1kh-ziYhiDCP5eB7mvpE4J9x3F4wsYjfcBWL79dh8DsnkHjJaqiX38dUnFJL29HQ8mIbUZdWZCQk0TIOhggXt73yD_74DobyS0FcCeSBJ8RkX-sd6lF27EwKH1leOW9U2OfKonHudEoVryN5VuYz7Oqh-L5XHeUOG8wxdrX6ZI-seP8FYZH-zvApMfauwo1B9gMHYVMs5beVN6eSMfnZU9dYLu_CYxL0rB0qrBb5epF81ZKigMRoC6ZPqMk_U06QfZwoezoC1ISSlVESMliFyVc8KZVTLoeS7sp4CMXVlgPQSRD-SBkBavXuG8PxjHWaadpXJBFwnzfnghNnKfaQ94pcVTKBrmF4fnUeolc9rOKhcExu5Wqfv0hH44NRVI0HDE0Ud6Hd3MxLKFs7n7QRTsIdJJIFl6vUM_iiT09qLUXCrbHOBB5Nf1cc7rBtI-lIzNpHwszLdpXeLXfk9wtIDMqH1B1FSycCBGxxLpWvQczMJJkRVrF5quFNjtC3vZvS2dTxXee0x_dA9zdYZTHBAszRWb0rnt4a8xEMBXKrfoTWg9oBC33wKecIDE6lCeEXPlGyM7BJDN1EiWVoz_2H8nydxia8oFgNwYN44m8KJmeFK2u2dEjArDPwyqE8VQOoydZ-LzUQj_hsUSUDY-SeRRwc3B3c3wBlN_aSJ8fp9eaeyuAtnSsE4DueXPAsVHF7HQoTEybJEZqGpOy83ZKGFFqKd94a6MZOGGT2ZTOFfE5Fw55aLJEP8qUVQcvP4q527YQvhf9cnSbVBDk4UOaUSOMrBbZ3ng8OmNyV_BYRWNJUOlGhYbsS5AtDVqiNzb1hOcmUNMVfWmAt85qI5GEzGAK8Da4SzvSNJZ6HYzYM0ntt6lD3Ag-5ECQVKr6EHqZyj1usEsSb07E9cfgBHcgqQWKIO7-Qi6byITW8fN0SN_iFnPRfUBv3bDJj74tbBOJ_-7NTWU9hGOaUN6C1ToBPYcCXm_rRrjlwDUund6x2OIk5eU2t4jQQpeYjIXzPTNjOZarQCNpVyALiM1cLJvi1Srz2YzM_2Spdm2Pr-eUrEIQMU0rgIggc9iJRuVrTp279VUdgZRRhMd20bmzpeOjtqQpo1HcQrp0bPtNrWJJXAEkZa2NCvJ1Bf61v4ZQ8PQkgdhuacFnA2hLHvCIKz_ZSP84HoVkjaaL6DFfHE6DLxikq-SQbiMDOYRBaYX8gOSm3edi-iDgVxXu2gWx7n9J3B0b41ld2VuEG2QDCfdXqb53t4pFlZtHp8LQWWOnq-hJg-nwpOnoQ85ak6vgq128tjbswjJ8NZVcFSHe1WPfCFI2DpfhbnHUy0a5uxhB-wJQfcs3YLvysN8r9LTK6Mc2DKicz4ijfA