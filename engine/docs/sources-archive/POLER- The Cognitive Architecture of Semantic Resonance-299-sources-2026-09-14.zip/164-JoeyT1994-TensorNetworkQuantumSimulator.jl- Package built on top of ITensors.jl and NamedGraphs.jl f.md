> Source: https://github.com/JoeyT1994/TensorNetworkQuantumSimulator.jl

GitHub - JoeyT1994/TensorNetworkQuantumSimulator.jl: Package built on top of ITensors.jl and NamedGraphs.jl for quantum simulation with tensor networks (TNs) of near-arbitrary geometry · GitHub
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
GitHub Stars
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
JoeyT1994 / TensorNetworkQuantumSimulator.jl Public
Notifications You must be signed in to change notification settings
Fork 17
Star 75
Code
Issues 0
Pull requests 3
Actions
Projects
Security and quality 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security and quality
Insights 
JoeyT1994/TensorNetworkQuantumSimulator.jl
main
22 Branches 26 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
MIT license
TensorNetworkQuantumSimulator
A Julia package for simulating quantum circuits, quantum dynamics and equilibrium physics with tensor networks (TNs) of near-arbitrary geometry. Built on top of ITensors and NamedGraphs.
The main workhorses of the simulation are belief propagation (BP) and the singular value decomposition for applying gates, and BP or boundary MPS for estimating expectation values and sampling.
Documentation
Full documentation is available at https://JoeyT1994.github.io/TensorNetworkQuantumSimulator.jl/, covering:
Getting Started — complete tutorial from lattice definition to measurement
Graphs — lattice constructors and graph utilities
Tensor Networks — TensorNetwork and TensorNetworkState types
Gate Application — circuits, simple update, and supported gates
Expectation Values — observables, norms, and reduced density matrices
Entanglement Entropy — von Neumann and Rényi entropies
Sampling — bitstring sampling with optional certification
Caches — BeliefPropagationCache and BoundaryMPSCache in depth
Advanced Topics — GPU support, loop corrections, precision control
API Reference — complete function reference
Installation
Quick Start
Usage Guide
Defining the Geometry
The starting point of most calculations is a NamedGraph that encodes the geometry of your tensor network. Vertices correspond to qubits (or qutrits, bosonic sites, etc.) and edges correspond to pairs of sites that directly interact. Built-in constructors are provided for common lattices:
Constructing a Tensor Network State
A TensorNetworkState (TNS) is a tensor network representation of your wavefunction, with the structure specified by the graph g . Product states can be constructed using string labels or numerical vectors:
The optional first argument sets the element type ( Float64 by default). Use ComplexF32 or ComplexF64 for complex-valued states.
Heisenberg Picture
You can also work directly in the Heisenberg picture, representing a many-body operator as a TNS in the "Pauli" basis. Each site encodes the coefficients of I, X, Y, Z:
Gates are then applied as conjugation by unitaries, and observables are extracted via traces (see examples/2dIsing_dynamics_Heisenbergpicture.jl ).
Building Circuits
A circuit is a Vector of gates to be applied sequentially. Each gate is specified as a tuple (gate_string, vertices, parameter) or as a raw ITensor :
The edge_color function identifies groups of non-overlapping edges. Non-overlapping gates within a group are applied in parallel during the simulation. The second argument should be the coordination number (maximum vertex degree) of the graph.
Applying Gates
Apply gates to the TNS using apply_gates . The apply_kwargs control bond dimension truncation during the SVD:
You can also pass a BeliefPropagationCache directly to reuse BP messages between gate applications:
Expectation Values
Compute expectation values with expect , choosing from several contraction algorithms:
If you already have an updated BeliefPropagationCache or BoundaryMPSCache , pass it directly to avoid redundant cache construction.
Norms, Inner Products and Reduced Density Matrices
All of these support the same algorithm options as expect : "exact" , "bp" , "boundarymps" , and (for norms) "loopcorrections" .
Sampling
Draw bitstring samples from the probability distribution defined by the squared amplitudes of the state:
BP-based sampling is also available via alg = "bp" .
Truncation
Reduce the bond dimension of an existing TNS:
Supported Gates
Gates are specified as tuples of the form (gate_string, vertices) or (gate_string, vertices, parameter) . The vertices can be a vector of one or two graph vertices, or a NamedEdge for two-qubit gates. All parameterised gates follow the Qiskit convention.
One-qubit gates (parameter in parentheses where required):
Two-qubit gates:
Custom gates can be defined by constructing the corresponding ITensor acting on the physical indices of the target qubits.
GPU Support
GPU support is enabled for all operations. Load the relevant Julia GPU package (e.g. CUDA.jl or Metal.jl) and transfer the state or cache:
Caches can also be transferred: CUDA.cu(BeliefPropagationCache(ψ)) . Significant speedups are seen on NVIDIA GPUs at moderate to large bond dimensions.
Algorithm Guide
Examples
See the examples/ directory for complete worked examples:
2D Ising dynamics ( 2dIsing_dynamics.jl ) -- time evolution on a square lattice with BP and boundary MPS measurements
3D Ising dynamics ( 3dIsing_dynamics.jl ) -- time evolution on a periodic 3D cubic lattice
Heavy-hex Ising dynamics ( heavyhexIsing_dynamics.jl ) -- evolution, measurement and sampling on a heavy-hexagonal lattice
Heisenberg picture ( 2dIsing_dynamics_Heisenbergpicture.jl ) -- operator evolution in the Pauli basis
Boundary MPS ( boundarymps.jl ) -- comparing BP, boundary MPS and exact expectation values
Loop corrections ( loopcorrections.jl ) -- improving BP norm estimates with loop corrections
We encourage users to read the literature listed below and explore the tests and source code to learn how the package works in detail.
Relevant Literature
Helpful reading for understanding the algorithms and the kind of simulations the library has been used for:
J. Tindall and M. Fishman, "Gauging tensor networks with belief propagation," SciPost Physics 15, 222 (2023). Link
J. Tindall, M. Fishman, E. M. Stoudenmire, and D. Sels, "Efficient Tensor Network Simulation of IBM's Eagle Kicked Ising Experiment," PRX Quantum 5, 010308 (2024). Link
G. Evenbly, N. Pancotti, A. Milsted, J. Gray, and G. K.-L. Chan, "Loop Series Expansions for Tensor Networks," Physical Review Research 8, 013245 (2026). Link
J. Tindall, A. Mello, M. Fishman, M. Stoudenmire, and D. Sels, "Dynamics of disordered quantum systems with two- and three-dimensional tensor networks," arXiv:2503.05693 (2025). Link
M. S. Rudolph and J. Tindall, "Simulating and Sampling from Quantum Circuits with 2D Tensor Networks," arXiv:2507.11424 (2025). Link
If you use this library in your research, please cite at minimum either:
M. S. Rudolph and J. Tindall, "Simulating and Sampling from Quantum Circuits with 2D Tensor Networks," arXiv:2507.11424 (2025). Link
or
J. Tindall and M. Fishman, "Gauging tensor networks with belief propagation," SciPost Physics 15, 222 (2023). Link
Upcoming Features
Applying gates to distant nodes of the TN via SWAP gates.
Infinite tensor network states
Finite temperature and ground state examples
Authors and Acknowledgements
The package was developed by Joseph Tindall ( JoeyT1994), an Associate Research Scientist at the Center for Computational Quantum Physics, Flatiron Institute NYC, and Manuel S. Rudolph ( MSRudolph), a PhD Candidate at EPFL, Switzerland, during a research stay at the Center for Computational Quantum Physics, Flatiron Institute NYC.
The package was strongly influenced by ITensorNetworks, a general tensor network package developed by Matt Fishman ( mtfishman), Joseph Tindall ( JoeyT1994) and others. The next generation of ITensorNetworks is currently being developed here. A quantum simulation package such as this will hopefully then be able to utilize many of its general features for working with tensor networks.
About
Package built on top of ITensors.jl and NamedGraphs.jl for quantum simulation with tensor networks (TNs) of near-arbitrary geometry
Resources
Readme
License
MIT license
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
75 stars
Watchers
2 watching
Forks
17 forks
Report repository
Releases 26
v0.3.7 Latest 3 weeks ago
+ 25 releases
Packages 0
No packages published
Contributors 8
Languages
Julia 100.0%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.