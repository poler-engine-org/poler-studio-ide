#!/usr/bin/env python3 """test_poler_v4.py — Тесты POLER-DYNAMIS v4.1: SUPREME LAW.
v4.1: Двухфазная стратегия. Закон един. Фаза 1 (η→∞): Fock-eig — предельный случай канонического уравнения. Фаза 2 (η<1):  POLER-flow — тонкая доводка с Δ_idem + J + K. """
import sys, os import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(file)))
from pyscf import gto, scf from poler_dynamis_v4 import ( PolerMode, DynamisParams, poler_scf_supreme, poler_vs_standard, verify_idempotency, verify_electron_count, )
def _run_mol_test(name, atom_str, basis, mode, params_overrides=None, bond_len=0.0, verbose=True): print("=" * 70) print(f"ТЕСТ: {name}") print("=" * 70)
if name == 'main': print("╔══════════════════════════════════════════════════════════════╗") print("║  POLER-DYNAMIS v4.1: SUPREME LAW — ДВУХФАЗНАЯ СТРАТЕГИЯ    ║") print("║  Фаза 1: Fock-eig (η→∞) — предельный случай закона       ║") print("║  Фаза 2: POLER-flow (Δ_idem + J + K) — тонкая доводка     ║") print("╚══════════════════════════════════════════════════════════════╝\n")