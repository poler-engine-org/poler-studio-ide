# --- FILE: ./analyze_gguf_structure_1.py ---

# Устанавливаем необходимые библиотеки
pip install pygguf numpy matplotlib

# Теперь создаем скрипт без команды pip внутри
cat > analyze_gguf_structure.py << 'EOF'
import struct
import json
import numpy as np
import os
from pathlib import Path
import matplotlib.pyplot as plt
from datetime import datetime

print("=== Анализ структуры GGUF файлов ===")

# Список GGUF файлов для анализа
gguf_files = [
("Оригинал", "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M.gguf"),
("POLER обработанный", "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"),
("POLER REPAIRED", "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_WORKING.gguf"),
]

# Функция для чтения базовой информации GGUF
def read_gguf_header(filename):
"""Читаем заголовок GGUF файла"""
print(f"\n📁 Анализ файла: {os.path.basename(filename)}")

if not os.path.exists(filename):
print(f" ❌ Файл не существует")
return None

file_size = os.path.getsize(filename)
print(f" Размер файла: {file_size / (1024**3):.2f} GB")

try:
with open(filename, 'rb') as f:
# Читаем магическое число
magic = f.read(4)
if magic != b'GGUF':
print(f" ❌ Неверный формат GGUF: {magic}")
return None

# Версия GGUF
version = struct.unpack(' print(f" Версия GGUF: {version}")

# Смещения
tensor_count = struct.unpack(' metadata_count = struct.unpack('
print(f" Количество тензоров: {tensor_count}")
print(f" Количество полей метаданных: {metadata_count}")

return {
'filename': filename,
'size_gb': file_size / (1024**3),
'version': version,
'tensor_count': tensor_count,
'metadata_count': metadata_count
}

except Exception as e:
print(f" ❌ Ошибка чтения: {e}")
return None

# Функция для сравнения файлов
def compare_files(files):
"""Сравниваем несколько GGUF файлов"""
print("\n" + "="*60)
print("📈 СРАВНЕНИЕ GGUF ФАЙЛОВ")
print("="*60)

headers = []
for name, path in files:
if os.path.exists(path):
header = read_gguf_header(path)
if header:
header['name'] = name
headers.append(header)
else:
print(f"\n❌ Файл не найден: {path}")

if not headers:
print("❌ Нет доступных файлов для анализа")
return []

# Выводим таблицу сравнения
print("\n╔════════════════════════════╦══════════╦══════════╦══════════════╗")
print("║ Файл ║ Размер ║ Тензоры ║ Версия GGUF ║")
print("╠════════════════════════════╬══════════╬══════════╬══════════════╣")

for h in headers:
name_display = h['name'][:24] + "..." if len(h['name']) > 24 else h['name']
print(f"║ {name_display:26} ║ {h['size_gb']:7.2f}GB ║ {h['tensor_count']:8} ║ {h['version']:11} ║")

print("╚════════════════════════════╩══════════╩══════════╩══════════════╝")

return headers

# Функция для визуализации
def visualize_comparison(headers):
"""Визуализация сравнения файлов"""
if len(headers) < 2:
return

# Создаем график
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# График 1: Размеры файлов
names = [h['name'] for h in headers]
sizes = [h['size_gb'] for h in headers]

bars1 = axes[0].bar(names, sizes, color=['blue', 'orange', 'green'][:len(names)])
axes[0].set_title('Размеры GGUF файлов (GB)')
axes[0].set_ylabel('Гигабайты')
axes[0].tick_params(axis='x', rotation=45)

# Добавляем значения на столбцы
for bar, size in zip(bars1, sizes):
axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
f'{size:.1f}GB', ha='center', va='bottom')

# График 2: Количество тензоров
tensor_counts = [h['tensor_count'] for h in headers]

bars2 = axes[1].bar(names, tensor_counts, color=['blue', 'orange', 'green'][:len(names)])
axes[1].set_title('Количество тензоров')
axes[1].set_ylabel('Тензоры')
axes[1].tick_params(axis='x', rotation=45)

for bar, count in zip(bars2, tensor_counts):
axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
f'{count}', ha='center', va='bottom')

plt.tight_layout()
plt.savefig('gguf_comparison.png', dpi=150, bbox_inches='tight')
print(f"\n📊 График сохранен: gguf_comparison.png")

# Сохраняем отчет
with open('gguf_analysis_report.txt', 'w') as f:
f.write(f"Отчет анализа GGUF файлов\n")
f.write(f"Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
f.write("="*60 + "\n\n")

for h in headers:
f.write(f"Файл: {h['name']}\n")
f.write(f" Путь: {h['filename']}\n")
f.write(f" Размер: {h['size_gb']:.2f} GB\n")
f.write(f" Версия GGUF: {h['version']}\n")
f.write(f" Тензоров: {h['tensor_count']}\n")
f.write(f" Метаданных: {h['metadata_count']}\n")
f.write("-"*40 + "\n")

print(f"📄 Отчет сохранен: gguf_analysis_report.txt")

# Основной анализ
print("🔍 Анализируем структуру нейросети Phi-3...")

# Сначала проверяем доступность файлов
available_files = []
for name, path in gguf_files:
if os.path.exists(path):
available_files.append((name, path))
print(f"✅ {name}: {os.path.basename(path)}")
else:
print(f"❌ {name}: Файл не найден ({path})")

if not available_files:
print("❌ Нет доступных GGUF файлов для анализа")
exit(1)

# Анализируем структуру
headers = compare_files(available_files)

# Визуализируем
if headers:
visualize_comparison(headers)

print("\n" + "="*60)
print("🎯 ВЫВОДЫ:")
print("="*60)
print("1. GGUF файлы содержат тензоры весов нейросети")
print("2. POLER обработка меняет распределение весов")
print("3. Разные версии могут иметь разное количество тензоров")
print("4. Для полного анализа нужны специальные инструменты")

print("\n🔧 Рекомендации:")
print("1. Используйте llama.cpp для подробного анализа")
print("2. Сравните веса до и после POLER обработки")
print("3. Проверьте изменение энтропии распределения весов")
EOF

# Запускаем анализ
python analyze_gguf_structure.py

# --- FILE: ./analyze_gguf_structure.py ---

# Сначала установим инструменты для анализа GGUF
pip install pygguf numpy matplotlib

# Создаем скрипт для анализа структуры GGUF файлов
cat > analyze_gguf_structure.py << 'EOF'
import struct
import json
import numpy as np
import os
from pathlib import Path
import matplotlib.pyplot as plt
from datetime import datetime

print("=== Анализ структуры GGUF файлов ===")

# Список GGUF файлов для анализа
gguf_files = [
("Оригинал", "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M.gguf"),
("POLER обработанный", "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"),
("POLER REPAIRED", "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_WORKING.gguf"),
]

# Функция для чтения базовой информации GGUF
def read_gguf_header(filename):
"""Читаем заголовок GGUF файла"""
print(f"\n📁 Анализ файла: {filename}")

if not os.path.exists(filename):
print(f" ❌ Файл не существует")
return None

file_size = os.path.getsize(filename)
print(f" Размер файла: {file_size / (1024**3):.2f} GB")

try:
with open(filename, 'rb') as f:
# Читаем магическое число
magic = f.read(4)
if magic != b'GGUF':
print(f" ❌ Неверный формат GGUF: {magic}")
return None

# Версия GGUF
version = struct.unpack(' print(f" Версия GGUF: {version}")

# Смещения
tensor_count = struct.unpack(' metadata_count = struct.unpack(' 
print(f" Количество тензоров: {tensor_count}")
print(f" Количество полей метаданных: {metadata_count}")

return {
'filename': filename,
'size_gb': file_size / (1024**3),
'version': version,
'tensor_count': tensor_count,
'metadata_count': metadata_count
}

except Exception as e:
print(f" ❌ Ошибка чтения: {e}")
return None

# Функция для извлечения тензоров и их статистики
def analyze_tensors(filename, max_tensors=20):
"""Анализ статистики тензоров"""
print(f"\n📊 Анализ тензоров в: {os.path.basename(filename)}")

try:
# Используем llama.cpp если он есть
import subprocess

llama_dir = "/home/vitalij/AI/llama.cpp"
if os.path.exists(llama_dir):
# Используем llama.cpp для получения информации
cmd = [os.path.join(llama_dir, "llama-cli"), 
"--model", filename, 
"--no-mmap", 
"--simple-io",
"--verbosity", "0"]

result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

# Парсим вывод
lines = result.stdout.split('\n')
tensor_info = []

for line in lines:
if 'tensor' in line.lower() and 'shape' in line.lower():
tensor_info.append(line.strip())
elif 'model size' in line.lower():
print(f" {line.strip()}")
elif 'parameters' in line.lower():
print(f" {line.strip()}")

if tensor_info:
print(f"\n Найдено {len(tensor_info)} тензоров (первые {min(10, len(tensor_info))}):")
for i, info in enumerate(tensor_info[:10]):
print(f" {i+1}. {info}")

# Также пробуем читать напрямую через struct
with open(filename, 'rb') as f:
f.read(24) # Пропускаем заголовок

# Читаем метаданные
print("\n Попытка чтения метаданных...")

# Пробуем найти известные поля
f.seek(0)
content = f.read(min(5000, file_size))

# Ищем текстовые поля
text_parts = []
for i in range(0, len(content) - 100, 100):
chunk = content[i:i+100]
try:
text = chunk.decode('utf-8', errors='ignore')
if any(keyword in text.lower() for keyword in ['phi', 'model', 'arch', 'name', 'desc']):
text_parts.append(text.strip())
except:
pass

if text_parts:
print(" Найденные текстовые поля:")
for text in text_parts[:5]:
if text and len(text) > 10:
print(f" - {text[:80]}...")

except Exception as e:
print(f" ❌ Ошибка анализа: {e}")

# Функция для сравнения файлов
def compare_files(files):
"""Сравниваем несколько GGUF файлов"""
print("\n" + "="*60)
print("📈 СРАВНЕНИЕ GGUF ФАЙЛОВ")
print("="*60)

headers = []
for name, path in files:
header = read_gguf_header(path)
if header:
header['name'] = name
headers.append(header)

# Выводим таблицу сравнения
print("\n╔════════════════════════════╦══════════╦══════════╦══════════════╗")
print("║ Файл ║ Размер ║ Тензоры ║ Версия GGUF ║")
print("╠════════════════════════════╬══════════╬══════════╬══════════════╣")

for h in headers:
name_display = h['name'][:24] + "..." if len(h['name']) > 24 else h['name']
print(f"║ {name_display:26} ║ {h['size_gb']:7.2f}GB ║ {h['tensor_count']:8} ║ {h['version']:11} ║")

print("╚════════════════════════════╩══════════╩══════════╩══════════════╝")

return headers

# Функция для визуализации
def visualize_comparison(headers):
"""Визуализация сравнения файлов"""
if len(headers) < 2:
return

# Создаем график
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# График 1: Размеры файлов
names = [h['name'] for h in headers]
sizes = [h['size_gb'] for h in headers]

bars1 = axes[0].bar(names, sizes, color=['blue', 'orange', 'green'])
axes[0].set_title('Размеры GGUF файлов (GB)')
axes[0].set_ylabel('Гигабайты')
axes[0].tick_params(axis='x', rotation=45)

# Добавляем значения на столбцы
for bar, size in zip(bars1, sizes):
axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
f'{size:.1f}GB', ha='center', va='bottom')

# График 2: Количество тензоров
tensor_counts = [h['tensor_count'] for h in headers]

bars2 = axes[1].bar(names, tensor_counts, color=['blue', 'orange', 'green'])
axes[1].set_title('Количество тензоров')
axes[1].set_ylabel('Тензоры')
axes[1].tick_params(axis='x', rotation=45)

for bar, count in zip(bars2, tensor_counts):
axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
f'{count}', ha='center', va='bottom')

plt.tight_layout()
plt.savefig('gguf_comparison.png', dpi=150, bbox_inches='tight')
print(f"\n📊 График сохранен: gguf_comparison.png")

# Сохраняем отчет
with open('gguf_analysis_report.txt', 'w') as f:
f.write(f"Отчет анализа GGUF файлов\n")
f.write(f"Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
f.write("="*60 + "\n\n")

for h in headers:
f.write(f"Файл: {h['name']}\n")
f.write(f" Путь: {h['filename']}\n")
f.write(f" Размер: {h['size_gb']:.2f} GB\n")
f.write(f" Версия GGUF: {h['version']}\n")
f.write(f" Тензоров: {h['tensor_count']}\n")
f.write(f" Метаданных: {h['metadata_count']}\n")
f.write("-"*40 + "\n")

print(f"📄 Отчет сохранен: gguf_analysis_report.txt")

# Основной анализ
print("🔍 Анализируем структуру нейросети Phi-3...")

# Сначала проверяем доступность файлов
available_files = []
for name, path in gguf_files:
if os.path.exists(path):
available_files.append((name, path))
print(f"✅ {name}: {path}")
else:
print(f"❌ {name}: Файл не найден")

if not available_files:
print("❌ Нет доступных GGUF файлов для анализа")
exit(1)

# Анализируем структуру
headers = compare_files(available_files)

# Визуализируем
if headers:
visualize_comparison(headers)

# Детальный анализ каждого файла
for name, path in available_files:
analyze_tensors(path)

print("\n" + "="*60)
print("🎯 ВЫВОДЫ:")
print("="*60)
print("1. GGUF файлы содержат тензоры весов нейросети")
print("2. POLER обработка меняет распределение весов")
print("3. Разные версии могут иметь разное количество тензоров")
print("4. Для полного анализа нужны специальные инструменты")

print("\n🔧 Рекомендации:")
print("1. Используйте llama.cpp для подробного анализа")
print("2. Сравните веса до и после POLER обработки")
print("3. Проверьте изменение энтропии распределения весов")
EOF

python analyze_gguf_structure.py
# --- FILE: ./analyze_model.py ---

#!/usr/bin/env python3
import os

model_path = '/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf'
size_gb = os.path.getsize(model_path) / (1024**3)

print(f"=== ОКОНЧАТЕЛЬНЫЙ АНАЛИЗ МОДЕЛИ ===")
print(f"Файл: {os.path.basename(model_path)}")
print(f"Размер: {size_gb:.2f} GB")
print()

print("=== РЕАЛЬНЫЕ ХАРАКТЕРИСТИКИ (из gguf-dump) ===")
print("1. ФОРМАТ: F16 (половинная точность)")
print(" • Все тензоры: F16")
print(f" • Размер соответствует F16: {size_gb:.2f} GB = ½ от F32")
print()

print("2. АРХИТЕКТУРА: Llama-стиль")
print(" • 32 трансформер-блока (blk.0 - blk.31)")
print(" • Скрытый размер: 1728")
print(" • Словарь: 32064 токена")
print()

print("3. СТРУКТУРА ВНИМАНИЯ:")
print(" • attn_qkv.weight: [2112, 9216]")
print(" • 2112 = 3 * 704 (Q, K, V проекции)")
print(" • Предположительно 32 головы внимания")
print()

print("4. FFN СЛОИ (гибридная структура):")
print(" • Большие FFN: 6720 → 3072 (5 таких блоков)")
print(" • Малые FFN: 4608 → 3072 (3 таких блока)")
print(" • Это MoE-подобная архитектура для эффективности")
print()

print("5. ВЫВОДНЫЕ СЛОИ:")
print(" • token_embd.weight: [1728, 32064]")
print(" • output.weight: [2520, 32064]")
print(" • output_norm.weight: [3072]")
print()

print("=== РАСЧЕТ ПАРАМЕТРОВ ===")
total_params = 2391894528 # Из предыдущего расчета
print(f"Общее количество параметров: {total_params:,}")
print(f"Модель: {total_params/1e9:.2f}B параметров")
print()

print("=== СРАВНЕНИЕ С ОРИГИНАЛЬНОЙ PHI-3-MINI ===")
print("Оригинальная Phi-3-mini имеет:")
print("• 3.8B параметров (у вас 2.39B)")
print("• Скрытый размер 3072 (у вас 1728)")
print("• 32 слоя (совпадает)")
print()
print("ВЫВОД: Это МОДИФИЦИРОВАННАЯ версия Phi-3-mini")
print("с уменьшенной размерностью (1728 вместо 3072)")
print("и гибридной FFN архитектурой.")

# Проверка POLER-эффекта
print("\n=== ПОЛИРОВКА (POLER) ===")
print("Файл обработан скриптом POLER, который:")
print("1. Применяет регуляризацию к весам")
print("2. Оптимизирует распределение значений")
print("3. Сохраняет в F16 для баланса качества/размера")
print()
print("Модель готова к использованию в llama.cpp!")

# --- FILE: ./citations.py ---

# -*- coding: utf-8 -*-
"""Automatically generate citations for a simulation."""

def cite(sim):
txt = """Simulations in this paper made use of the REBOUND N-body code \\citep{rebound}. """
bib = """@ARTICLE{rebound,
author = {{Rein}, H. and {Liu}, S. -F.},
title = "{REBOUND: an open-source multi-purpose N-body code for collisional dynamics}",
journal = {\\aap},
keywords = {methods: numerical, planets and satellites: rings, protoplanetary disks, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Mathematics - Dynamical Systems, Physics - Computational Physics},
year = 2012,
month = jan,
volume = {537},
eid = {A128},
pages = {A128},
doi = {10.1051/0004-6361/201118085},
archivePrefix = {arXiv},
eprint = {1110.4876},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2012A&A...537A.128R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
if sim.extras:
txt +="""The REBOUNDx package was used to incorporate additional physics \\citep{reboundx}. """
bib +="""@ARTICLE{reboundx,
author = {{Tamayo}, Daniel and {Rein}, Hanno and {Shi}, Pengshuai and {Hernandez}, David M.},
title = "{REBOUNDx: a library for adding conservative and dissipative forces to otherwise symplectic N-body integrations}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics},
year = 2020,
month = jan,
volume = {491},
number = {2},
pages = {2885-2901},
doi = {10.1093/mnras/stz2870},
archivePrefix = {arXiv},
eprint = {1908.05634},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2020MNRAS.491.2885T},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
if sim.integrator == "ias15":
txt += """The simulations were integrated using IAS15, a 15th order Gauss-Radau integrator \\citep{reboundias15}. """
bib += """@ARTICLE{reboundias15,
author = {{Rein}, Hanno and {Spiegel}, David S.},
title = "{IAS15: a fast, adaptive, high-order integrator for gravitational dynamics, accurate to machine precision over a billion orbits}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Astrophysics - Solar and Stellar Astrophysics, Mathematics - Numerical Analysis},
year = 2015,
month = jan,
volume = {446},
number = {2},
pages = {1424-1437},
doi = {10.1093/mnras/stu2164},
archivePrefix = {arXiv},
eprint = {1409.4779},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2015MNRAS.446.1424R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
if sim.integrator == "whfast":
txt += """The simulations were integrated using WHFast, a symplectic Wisdom-Holman integrator \\citep{reboundwhfast,wh}. """
bib += """@ARTICLE{reboundwhfast,
author = {{Rein}, Hanno and {Tamayo}, Daniel},
title = "{WHFAST: a fast and unbiased implementation of a symplectic Wisdom-Holman integrator for long-term gravitational simulations}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Mathematics - Numerical Analysis, Nonlinear Sciences - Chaotic Dynamics, Physics - Computational Physics},
year = 2015,
month = sep,
volume = {452},
number = {1},
pages = {376-388},
doi = {10.1093/mnras/stv1257},
archivePrefix = {arXiv},
eprint = {1506.01084},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2015MNRAS.452..376R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
bib += """@ARTICLE{wh,
author = {{Wisdom}, Jack and {Holman}, Matthew},
title = "{Symplectic maps for the N-body problem.}",
journal = {\\aj},
keywords = {Many Body Problem, Planetary Evolution, Pluto (Planet), Astronomical Maps, Gravitational Effects, Physics (General)},
year = 1991,
month = oct,
volume = {102},
pages = {1528-1538},
doi = {10.1086/115978},
adsurl = {https://ui.adsabs.harvard.edu/abs/1991AJ....102.1528W},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
if sim.ri_whfast.kernel != "default":
txt += """A high order kernel was used in WHFast to improved the accuracy of the integrations \\citep{reboundhighorder}. """
bib += """@ARTICLE{reboundhighorder,
author = {{Rein}, Hanno and {Tamayo}, Daniel and {Brown}, Garett},
title = "{High-order symplectic integrators for planetary dynamics and their implementation in REBOUND}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Physics - Computational Physics},
year = 2019,
month = nov,
volume = {489},
number = {4},
pages = {4632-4640},
doi = {10.1093/mnras/stz2503},
archivePrefix = {arXiv},
eprint = {1907.11335},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2019MNRAS.489.4632R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""

if sim.integrator == "whfast512":
txt += """The simulations were integrated using WHFast512, a symplectic Wisdom-Holman integrator using SIMD AVX512 instructions \\citep{reboundwhfast512,wh}. """
bib += """@ARTICLE{reboundwhfast512,
author = {{Javaheri}, Pejvak and {Rein}, Hanno and {Tamayp}, Daniel},
title = "{WHFast512: An N-body integrator for planetary systems optimized with AVX512 SIMD instructions}",
year = 2023,
}
"""
bib += """@ARTICLE{wh,
author = {{Wisdom}, Jack and {Holman}, Matthew},
title = "{Symplectic maps for the N-body problem.}",
journal = {\\aj},
keywords = {Many Body Problem, Planetary Evolution, Pluto (Planet), Astronomical Maps, Gravitational Effects, Physics (General)},
year = 1991,
month = oct,
volume = {102},
pages = {1528-1538},
doi = {10.1086/115978},
adsurl = {https://ui.adsabs.harvard.edu/abs/1991AJ....102.1528W},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""


if sim.integrator == "mercurius":
txt += """The simulations were integrated using the hybrid symplectic MERCURIUS integrator \\citep{reboundmercurius}. """
bib += """@ARTICLE{reboundmercurius,
author = {{Rein}, Hanno and {Hernandez}, David M. and {Tamayo}, Daniel and
{Brown}, Garett and {Eckels}, Emily and {Holmes}, Emma and
{Lau}, Michelle and {Leblanc}, R{\\'e}jean and {Silburt}, Ari},
title = "{Hybrid symplectic integrators for planetary dynamics}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Mathematics - Dynamical Systems},
year = 2019,
month = jun,
volume = {485},
number = {4},
pages = {5490-5497},
doi = {10.1093/mnras/stz769},
archivePrefix = {arXiv},
eprint = {1903.04972},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2019MNRAS.485.5490R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""

if sim.integrator == "trace":
txt += """The simulations were integrated using the hybrid time-reversible TRACE integrator \\citep{reboundtrace}. """
bib += """@ARTICLE{reboundtrace,
author = {{Lu}, Tiger and {Hernandez}, David M. and {Rein}, Hanno},
title = "{TRACE: a code for time-reversible astrophysical close encounters}",
journal = {\\mnras},
keywords = {Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Physics - Computational Physics},
year = 2024,
month = sep,
volume = {533},
number = {3},
pages = {3708-3723},
doi = {10.1093/mnras/stae1982},
archivePrefix = {arXiv},
eprint = {2405.03800},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2024MNRAS.533.3708L},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
}
"""

if sim.integrator == "janus":
txt += """The simulations were integrated using the time-reversible JANUS integrator \\citep{reboundjanus}. """
bib += """@ARTICLE{reboundjanus,
author = {{Rein}, Hanno and {Tamayo}, Daniel},
title = "{JANUS: a bit-wise reversible integrator for N-body dynamics}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Instrumentation and Methods for Astrophysics, Astrophysics - Cosmology and Nongalactic Astrophysics, Astrophysics - Earth and Planetary Astrophysics},
year = 2018,
month = jan,
volume = {473},
number = {3},
pages = {3351-3357},
doi = {10.1093/mnras/stx2479},
archivePrefix = {arXiv},
eprint = {1704.07715},
primaryClass = {astro-ph.IM},
adsurl = {https://ui.adsabs.harvard.edu/abs/2018MNRAS.473.3351R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""

if sim.integrator == "sei":
txt += """The simulations were integrated using the Symplectic Epicycle Integrator (SEI) \\citep{reboundsei}. """
bib += """@ARTICLE{reboundsei,
author = {{Rein}, Hanno and {Tremaine}, Scott},
title = "{Symplectic integrators in the shearing sheet}",
journal = {\\mnras},
keywords = {methods: numerical, celestial mechanics, planets and satellites: dynamical evolution and stability, planets and satellites: formation, planets and satellites: rings, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Galaxy Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Mathematics - Numerical Analysis},
year = 2011,
month = aug,
volume = {415},
number = {4},
pages = {3168-3176},
doi = {10.1111/j.1365-2966.2011.18939.x},
archivePrefix = {arXiv},
eprint = {1103.1376},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2011MNRAS.415.3168R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""

if sim.integrator == "saba":
txt += """The simulations were integrated using the SABA Integrator \\citep{reboundhighorder,saba}. """
bib += """@ARTICLE{reboundhighorder,
author = {{Rein}, Hanno and {Tamayo}, Daniel and {Brown}, Garett},
title = "{High-order symplectic integrators for planetary dynamics and their implementation in REBOUND}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Physics - Computational Physics},
year = 2019,
month = nov,
volume = {489},
number = {4},
pages = {4632-4640},
doi = {10.1093/mnras/stz2503},
archivePrefix = {arXiv},
eprint = {1907.11335},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2019MNRAS.489.4632R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
bib += """@ARTICLE{saba,
author = {{Laskar}, Jacques and {Robutel}, Philippe},
title = "{High order symplectic integrators for perturbed Hamiltonian systems}",
journal = {Celestial Mechanics and Dynamical Astronomy},
keywords = {SYMPLECTIC INTEGRATORS, HAMILTONIAN SYSTEMS, PLANETARY MOTION, LIE ALGEBRA, Astrophysics},
year = 2001,
month = jul,
volume = {80},
number = {1},
pages = {39-62},
archivePrefix = {arXiv},
eprint = {astro-ph/0005074},
primaryClass = {astro-ph},
adsurl = {https://ui.adsabs.harvard.edu/abs/2001CeMDA..80...39L},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""


if sim.simulationarchive_auto_interval!=0 or sim.simulationarchive_auto_walltime!=0 or sim.simulationarchive_auto_step!=0:
txt += """The Simulationarchive format was used to store fully reproducible simulation data \\citep{reboundsa}. """
bib += """@ARTICLE{reboundsa,
author = {{Rein}, Hanno and {Tamayo}, Daniel},
title = "{A new paradigm for reproducing and analyzing N-body simulations of planetary systems}",
journal = {\\mnras},
keywords = {methods: numerical, gravitation, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics},
year = 2017,
month = may,
volume = {467},
number = {2},
pages = {2377-2383},
doi = {10.1093/mnras/stx232},
archivePrefix = {arXiv},
eprint = {1701.07423},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2017MNRAS.467.2377R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""
if sim.N_var>0:
txt += """Variational equations were used to calculate trajectories of nearby orbits \\citep{reboundvar}. """
bib += """@ARTICLE{reboundvar,
author = {{Rein}, Hanno and {Tamayo}, Daniel},
title = "{Second-order variational equations for N-body simulations}",
journal = {\\mnras},
keywords = {gravitation, methods: numerical, planets and satellites: dynamical evolution and stability, Astrophysics - Earth and Planetary Astrophysics, Astrophysics - Instrumentation and Methods for Astrophysics, Mathematics - Classical Analysis and ODEs, Mathematics - Dynamical Systems},
year = 2016,
month = jul,
volume = {459},
number = {3},
pages = {2275-2285},
doi = {10.1093/mnras/stw644},
archivePrefix = {arXiv},
eprint = {1603.03424},
primaryClass = {astro-ph.EP},
adsurl = {https://ui.adsabs.harvard.edu/abs/2016MNRAS.459.2275R},
adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""




return txt, bib

# --- FILE: ./download_phi3.py ---

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import numpy as np
import os

print("=== Скачивание модели Phi-3-mini от Microsoft ===")

model_name = "microsoft/phi-3-mini-4k-instruct"

try:
print(f"Загрузка модели {model_name}...")

# Скачиваем токенизатор
print("Загрузка токенизатора...")
tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)

# Скачиваем модель
print("Загрузка модели (это может занять время и ~8GB диска)...")
model = AutoModelForCausalLM.from_pretrained(
model_name,
torch_dtype=torch.float16,
device_map="cpu",
trust_remote_code=True
)

print("✅ Модель успешно загружена!")

# Сохраняем веса в numpy формате
output_dir = "phi3_real_weights"
os.makedirs(output_dir, exist_ok=True)

print("Сохранение весов...")
state_dict = model.state_dict()
np_tensors = {}

for name, tensor in state_dict.items():
np_tensor = tensor.cpu().numpy()
np_tensors[name] = np_tensor

# Показываем прогресс для первых нескольких тензоров
if len(np_tensors) <= 5:
print(f" {name}: {np_tensor.shape}, {np_tensor.dtype}")

# Сохраняем
npz_path = os.path.join(output_dir, "weights.npz")
np.savez_compressed(npz_path, **np_tensors)

print(f"✅ Веса сохранены в {npz_path}")
print(f" Всего тензоров: {len(np_tensors)}")
print(f" Общий размер: {sum(t.nbytes for t in np_tensors.values()) / (1024**3):.2f} GB")

except Exception as e:
print(f"❌ Ошибка: {e}")
print("Убедитесь, что у вас установлены:")
print(" pip install transformers torch")
print("И достаточно места на диске (~8GB)")

# --- FILE: ./extract_meta_1.py ---

import sys
from gguf import GGUFReader # Потрібно встановити: pip install gguf

def read_gguf_meta(path):
reader = GGUFReader(path)
print("=== METADATA ===")
for key, val in reader.fields.items():
# Фільтруємо занадто довгі масиви, щоб не забити вивід
val_str = str(val)
if len(val_str) > 200:
val_str = val_str[:200] + "..."
print(f"{key}: {val_str}")

print("\n=== ARCHITECTURE INFO ===")
# Це покаже, скільки шарів, голів уваги тощо
if 'llm_load_print_meta' in dir(reader):
reader.llm_load_print_meta()

if __name__ == "__main__":
read_gguf_meta(sys.argv[1])
# --- FILE: ./extract_meta_2.py ---

import sys
from gguf import GGUFReader # Потрібно встановити: pip install gguf

def read_gguf_meta(path):
reader = GGUFReader(path)
print("=== METADATA ===")
for key, val in reader.fields.items():
# Фільтруємо занадто довгі масиви, щоб не забити вивід
val_str = str(val)
if len(val_str) > 200:
val_str = val_str[:200] + "..."
print(f"{key}: {val_str}")

print("\n=== ARCHITECTURE INFO ===")
# Це покаже, скільки шарів, голів уваги тощо
if 'llm_load_print_meta' in dir(reader):
reader.llm_load_print_meta()

if __name__ == "__main__":
read_gguf_meta(sys.argv[1])
# --- FILE: ./extract_meta.py ---

import sys
from gguf import GGUFReader # Потрібно встановити: pip install gguf

def read_gguf_meta(path):
reader = GGUFReader(path)
print("=== METADATA ===")
for key, val in reader.fields.items():
# Фільтруємо занадто довгі масиви, щоб не забити вивід
val_str = str(val)
if len(val_str) > 200:
val_str = val_str[:200] + "..."
print(f"{key}: {val_str}")

print("\n=== ARCHITECTURE INFO ===")
# Це покаже, скільки шарів, голів уваги тощо
if 'llm_load_print_meta' in dir(reader):
reader.llm_load_print_meta()

if __name__ == "__main__":
read_gguf_meta(sys.argv[1])
# --- FILE: ./extract_weights_from_gguf.py ---

#!/usr/bin/env python3
# extract_weights_from_gguf.py

from gguf import GGUFReader
import numpy as np
import pickle
from pathlib import Path

def extract_weights(gguf_path, output_dir="extracted_weights"):
"""Извлекает все веса из GGUF файла"""
print(f"Чтение GGUF: {gguf_path}")

reader = GGUFReader(gguf_path)

weights_dict = {}
metadata = {
"source_file": str(gguf_path),
"architecture": str(reader.get_field("general.architecture")[2][0]),
"tensor_count": len(reader.tensors),
"extraction_date": "сегодня"
}

print(f"Архитектура: {metadata['architecture']}")
print(f"Тензоров: {metadata['tensor_count']}")

for i, tensor in enumerate(reader.tensors):
name = tensor[0]
data = tensor[2] # numpy array

if data is not None:
weights_dict[name] = data
if i < 5: # Показать первые 5
print(f" {name}: {data.shape}, {data.dtype}")

# Сохраняем
output_dir = Path(output_dir)
output_dir.mkdir(exist_ok=True)

# Сохраняем веса
weights_file = output_dir / "weights.npz"
np.savez_compressed(weights_file, **weights_dict)

# Сохраняем метаданные
meta_file = output_dir / "metadata.pkl"
with open(meta_file, 'wb') as f:
pickle.dump(metadata, f)

print(f"\n✅ Извлечено {len(weights_dict)} тензоров")
print(f"✅ Сохранено в: {output_dir}")

return weights_dict, metadata

if __name__ == "__main__":
# Пример использования
extract_weights(
"../Phi-3-mini-4k-instruct-Q4_K_M.gguf",
"phi3_weights"
)
# --- FILE: ./fix_phi3_metadata.py ---

#!/usr/bin/env python3
# fix_phi3_metadata.py - Исправление конкретных полей метаданных в GGUF

import struct
from pathlib import Path
from collections import OrderedDict

def read_string(f):
"""Читает строку из GGUF файла"""
length = struct.unpack(' return f.read(length).decode('utf-8')

def write_string(f, s):
"""Записывает строку в GGUF файла"""
f.write(struct.pack(' f.write(s.encode('utf-8'))

def fix_metadata():
input_file = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_WORKING.gguf"
output_file = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_FIXED.gguf"

print(f"Исправление метаданных в файле: {input_file}")

# 1. Создаем исправленные значения для обязательных полей
fixes = OrderedDict([
("general.name", ("Phi3", 8)), # STRING type=8
("phi3.context_length", (4096, 5)), # UINT32 type=5
("phi3.embedding_length", (3072, 5)),
("phi3.block_count", (32, 5)),
("phi3.feed_forward_length", (8192, 5)),
("phi3.attention.head_count", (32, 5)),
("phi3.attention.head_count_kv", (32, 5)),
("phi3.attention.layer_norm_rms_epsilon", (1e-5, 6)), # FLOAT32 type=6
("phi3.rope.dimension_count", (96, 5)),
("phi3.rope.freq_base", (10000.0, 6)),
("general.file_type", (15, 5)), # Q4_K_M это тип 15
("general.quantization_version", (2, 5)),
("tokenizer.ggml.model", ("llama", 8)), # КРИТИЧЕСКОЕ ПОЛЕ!
("tokenizer.ggml.bos_token_id", (1, 5)),
("tokenizer.ggml.eos_token_id", (32000, 5)),
("tokenizer.ggml.unknown_token_id", (0, 5)),
("tokenizer.ggml.padding_token_id", (32000, 5)),
])

# 2. Копируем файл и заменяем метаданные
with open(input_file, 'rb') as fin, open(output_file, 'wb') as fout:
# Копируем заголовок (первые 40 байт)
header = fin.read(40)
fout.write(header)

# Читаем заголовок для получения информации
magic, version, tensor_count, kv_count = struct.unpack(' print(f"GGUF версия: {version}, KV пар: {kv_count}, Тензоров: {tensor_count}")

# 3. Проходим по всем KV парам и заменяем нужные
for i in range(kv_count):
pos = fin.tell()
key = read_string(fin)
value_type = struct.unpack(' 
# Читаем значение в зависимости от типа
if value_type == 5: # UINT32
value = struct.unpack(' fin.seek(-4, 1) # Возвращаемся назад
elif value_type == 6: # FLOAT32
value = struct.unpack(' fin.seek(-4, 1)
elif value_type == 8: # STRING
value = read_string(fin)
fin.seek(-(8 + len(value)), 1) # Возвращаемся
else:
# Пропускаем неизвестные типы
print(f" Пропускаем {key}: неизвестный тип {value_type}")
continue

# Проверяем, нужно ли исправлять это поле
if key in fixes:
new_value, new_type = fixes[key]
print(f" Исправляем {key}: {value} -> {new_value}")

# Записываем исправленное значение
fout.write(struct.pack(' fout.write(key.encode('utf-8'))
fout.write(struct.pack(' 
if new_type == 5: # UINT32
fout.write(struct.pack(' elif new_type == 6: # FLOAT32
fout.write(struct.pack(' elif new_type == 8: # STRING
write_string(fout, new_value)
else:
# Копируем как есть
fin.seek(pos)
chunk = fin.read(
8 + len(key) + 4 + 
(4 if value_type in [5, 6] else 8 + len(value) if value_type == 8 else 0)
)
fout.write(chunk)

# 4. Копируем остаток файла (тензоры)
print("Копирование тензорных данных...")
remaining = fin.read()
fout.write(remaining)

print(f"\n✅ Исправленный файл создан: {output_file}")

# 5. Быстрая проверка
print("\nПроверка исправленных полей:")
with open(output_file, 'rb') as f:
f.seek(40) # Пропускаем заголовок

# Читаем количество KV пар
f.seek(24, 0) # Смещение для kv_count
kv_count = struct.unpack(' f.seek(40) # Возвращаемся к началу KV данных

for i in range(min(kv_count, 10)): # Первые 10 полей
key = read_string(f)
value_type = struct.unpack(' 
if value_type == 5:
value = struct.unpack(' elif value_type == 6:
value = struct.unpack(' elif value_type == 8:
value = read_string(f)
else:
continue

if key in fixes:
print(f" {key} = {value}")

if __name__ == "__main__":
fix_metadata()
# --- FILE: ./get_vocab.py ---

import sys
from llama_cpp import Llama

# Шлях до моделі (перевір, чи він правильний)
MODEL_PATH = "/home/vitalij/AI/Phi-3-medium-128k-instruct-Q4_K_M.gguf"
OUTPUT_FILE = "phi3_full_vocabulary.txt"

def extract_tokens():
print(f"⚙️ [EXTRACTOR] Ініціалізація моделі...", flush=True)

try:
llm = Llama(
model_path=MODEL_PATH,
n_ctx=2048, # Щоб не сварився на контекст
embedding=False, 
n_gpu_layers=0, # Тільки CPU (надійніше)
verbose=False # <--- ТИША! Ніяких C++ логів
)
except Exception as e:
print(f"❌ Помилка: {e}")
return

vocab_size = llm.n_vocab()
print(f"✅ Модель завантажена! Знайдено токенів: {vocab_size}", flush=True)
print(f"✍️ Починаю запис у файл {OUTPUT_FILE}...", flush=True)

tokens_list = []

for token_id in range(vocab_size):
try:
# Отримуємо байти
token_bytes = llm.detokenize([token_id])

# Декодуємо (з заміною битих символів на )
token_text = token_bytes.decode('utf-8', errors='replace')

# Екрануємо спецсимволи для збереження структури файлу
token_text_safe = token_text.replace('\n', '\\n').replace('\t', '\\t')

tokens_list.append(f"{token_id}\t{token_text_safe}")

# Показуємо прогрес кожні 5000 слів
if token_id % 5000 == 0:
print(f" ... оброблено {token_id}/{vocab_size}", flush=True)

except Exception as e:
tokens_list.append(f"{token_id}\t[ERROR]")

with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
f.write('\n'.join(tokens_list))

print(f"\n🎉 ГОТОВО! Перевір файл {OUTPUT_FILE}", flush=True)

if __name__ == "__main__":
extract_tokens()
# --- FILE: ./gguf_dump_structure.py ---

#!/usr/bin/env python3
from gguf import GGUFReader
import sys
import numpy as np

def dump(obj, name, depth=0, max_depth=2):
indent = " " * depth
print(f"{indent}{name}: {type(obj)}")

if depth >= max_depth:
return

if isinstance(obj, dict):
for k, v in list(obj.items())[:10]:
dump(v, f"{name}[{repr(k)}]", depth + 1, max_depth)

elif isinstance(obj, (list, tuple)):
for i, v in enumerate(obj[:10]):
dump(v, f"{name}[{i}]", depth + 1, max_depth)

else:
attrs = [a for a in dir(obj) if not a.startswith("_")]
for a in attrs[:10]:
try:
v = getattr(obj, a)
dump(v, f"{name}.{a}", depth + 1, max_depth)
except Exception as e:
print(f"{indent} {name}.{a} -> ERROR: {e}")

def main(path):
print("=== OPENING GGUF ===")
r = GGUFReader(path)

print("\n=== TOP LEVEL ===")
dump(r, "GGUFReader", max_depth=1)

print("\n=== FIELDS ===")
dump(r.fields, "fields", max_depth=2)

print("\n=== TENSORS ===")
dump(r.tensors, "tensors", max_depth=2)

print("\n=== DONE ===")

if __name__ == "__main__":
if len(sys.argv) != 2:
print("usage: python3 gguf_dump_structure.py model.gguf")
sys.exit(1)

main(sys.argv[1])

# --- FILE: ./gguf_fix_metadata.py ---

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import traceback
import inspect
from collections import OrderedDict

import numpy as np
from gguf import GGUFReader, GGUFWriter


def _print_methods(obj, title: str):
print(f"\n=== {title} ===")
cls = obj if isinstance(obj, type) else obj.__class__
print("Class:", cls)
names = [n for n in dir(obj) if not n.startswith("_")]
for n in names:
try:
v = getattr(obj, n)
if callable(v):
try:
sig = str(inspect.signature(v))
except Exception:
sig = "(signature unavailable)"
print(f" - {n}{sig}")
except Exception:
pass


def _reader_field_to_plain(field_obj):
"""
gguf.gguf_reader.ReaderField выглядит как последовательность:
[0]=offset/int, [1]=type_str, [2..]=lists
Мы не интерпретируем смысл — просто возвращаем как есть,
чтобы попытаться передать это writer'у тем методом, который доступен.
"""
try:
return list(field_obj)
except Exception:
# на случай если объект неитерируемый
return field_obj


def _try_copy_fields(writer: GGUFWriter, fields: "OrderedDict[str, object]"):
"""
Пытаемся скопировать KV/fields максимально “по-API”, без фантазий.
Поддерживаем несколько вариантов методов, потому что gguf API менялся.
"""
# кандидаты: add_field, add_kv, add_key_value, add_metadata, etc
candidates = []
for name in ("add_field", "add_kv", "add_key_value", "add_metadata", "add_meta"):
if hasattr(writer, name) and callable(getattr(writer, name)):
candidates.append(name)

if not candidates:
raise RuntimeError(
"Не найден ни один метод для добавления KV/fields в GGUFWriter. "
"Нужен add_field/add_kv/add_key_value и т.п."
)

print("\n[fix] Found writer KV methods:", candidates)

# Важно: поля GGUF.* обычно writer генерит сам.
# Мы переносим всё, кроме GGUF.version / counts
skipped = 0
copied = 0

for k, f in fields.items():
if k.startswith("GGUF."):
skipped += 1
continue

payload = _reader_field_to_plain(f)

ok = False
last_err = None

# пробуем каждым найденным методом
for m in candidates:
fn = getattr(writer, m)
try:
# варианты сигнатур бывают разные:
# 1) fn(key, field_obj)
# 2) fn(key, type_str, values)
# 3) fn(key, *payload)
try:
fn(k, f) # самый прямой
ok = True
break
except Exception as e1:
last_err = e1

# если field_obj не принимается — пробуем распаковать
if isinstance(payload, list) and len(payload) >= 2:
# часто payload = [offset, type_str, values...]
# offset нам не нужен
type_str = payload[1]
rest = payload[2:]

# пробуем: key, type, values
try:
fn(k, type_str, rest)
ok = True
break
except Exception as e2:
last_err = e2

# пробуем: key, type, *values
try:
fn(k, type_str, *rest)
ok = True
break
except Exception as e3:
last_err = e3

# пробуем: key, *payload[1:]
try:
fn(k, *payload[1:])
ok = True
break
except Exception as e4:
last_err = e4

# пробуем: key, payload
try:
fn(k, payload)
ok = True
break
except Exception as e5:
last_err = e5

except Exception as e:
last_err = e

if not ok:
raise RuntimeError(f"Не смог добавить field '{k}'. Последняя ошибка: {last_err}")

copied += 1

print(f"[fix] fields copied={copied}, skipped(GGUF.*)={skipped}")


def _tensor_name(rt):
# ReaderTensor индексируется: [0]=name
try:
return rt[0]
except Exception:
# запасной вариант
return getattr(rt, "name", None)


def main():
ap = argparse.ArgumentParser()
ap.add_argument("--orig", required=True, help="Оригинальный GGUF (с правильными KV/metadata)")
ap.add_argument("--poler", required=True, help="POLER_MAX GGUF (с переписанными весами)")
ap.add_argument("--out", required=True, help="Куда сохранить repaired GGUF")
ap.add_argument("--dry-run", action="store_true", help="Только диагностика API, без записи")
args = ap.parse_args()

print("[open] orig :", args.orig)
print("[open] poler:", args.poler)

ra = GGUFReader(args.orig)
rb = GGUFReader(args.poler)

print("\n=== QUICK CHECK ===")
print("orig: fields =", len(getattr(ra, "fields", {})), "tensors =", len(getattr(ra, "tensors", [])))
print("poler: fields =", len(getattr(rb, "fields", {})), "tensors =", len(getattr(rb, "tensors", [])))

# Мини-диагностика: какие поля реально потерялись
orig_keys = set(ra.fields.keys())
poler_keys = set(rb.fields.keys())
missing_in_poler = sorted(list(orig_keys - poler_keys))
extra_in_poler = sorted(list(poler_keys - orig_keys))

print("\n[diff] KV missing in POLER (count):", len(missing_in_poler))
if len(missing_in_poler) <= 60:
for k in missing_in_poler:
print(" -", k)
else:
print(" (слишком много для вывода, покажу первые 60)")
for k in missing_in_poler[:60]:
print(" -", k)

print("\n[diff] KV extra in POLER (count):", len(extra_in_poler))
if extra_in_poler:
for k in extra_in_poler[:60]:
print(" +", k)

# Диагностика writer API
print("\n=== WRITER API DIAG ===")
_print_methods(GGUFWriter, "GGUFWriter class methods (callables)")
if args.dry_run:
print("\n[dry-run] stop here.")
return

# Пытаемся создать writer максимально нейтрально
# (у разных версий gguf сигнатура может отличаться)
w = None
writer_errs = []

for ctor_try in (
lambda: GGUFWriter(args.out, "phi3"),
lambda: GGUFWriter(args.out, "llama"),
lambda: GGUFWriter(args.out),
):
try:
w = ctor_try()
break
except Exception as e:
writer_errs.append(e)

if w is None:
print("\n[ERROR] Не удалось создать GGUFWriter. Ошибки конструктора:")
for e in writer_errs:
print(" -", repr(e))
raise SystemExit(2)

# 1) копируем KV из оригинала
try:
_try_copy_fields(w, ra.fields)
except Exception:
print("\n[ERROR] copying fields failed:")
traceback.print_exc()
_print_methods(w, "GGUFWriter instance methods (callables)")
raise SystemExit(3)

# 2) записываем тензоры из POLER
print("\n[fix] writing tensors from POLER...")
count = 0
for rt in rb.tensors:
name = _tensor_name(rt)
if not name:
raise RuntimeError("Не смог получить имя тензора из ReaderTensor")

# get_tensor(name) должен вернуть np.ndarray / memmap
arr = rb.get_tensor(name)

# Важно: GGUFWriter из gguf 0.17.1 принимает только F16/F32/F64/ints.
# POLER_MAX у тебя F16 — должно зайти.
try:
w.add_tensor(name, np.array(arr, copy=False))
except Exception:
print(f"\n[ERROR] add_tensor failed for '{name}':")
traceback.print_exc()
raise SystemExit(4)

count += 1
if count % 20 == 0:
print(f" tensors written: {count}/{len(rb.tensors)}")

print(f"[fix] tensors written total: {count}")

# 3) finalize/write
try:
w.write_header_to_file()
w.write_kv_data_to_file()
w.write_tensors_to_file()
w.close()
except Exception:
print("\n[ERROR] writing GGUF failed:")
traceback.print_exc()
raise SystemExit(5)

print("\n✅ REPAIRED DONE:", args.out)


if __name__ == "__main__":
main()

# --- FILE: ./gguf_inspect_diff.py ---

#!/usr/bin/env python3
import argparse
import json
import numpy as np
from gguf import GGUFReader

def summarize(v):
if isinstance(v, np.ndarray):
return {
"type": "ndarray",
"shape": list(v.shape),
"dtype": str(v.dtype),
"min": float(v.min()) if v.size else None,
"max": float(v.max()) if v.size else None,
"mean": float(v.mean()) if v.size else None,
"std": float(v.std()) if v.size else None,
}
if isinstance(v, (list, tuple)):
return {
"type": type(v).__name__,
"len": len(v),
"preview": v[:5],
}
return {
"type": type(v).__name__,
"value": v,
}

def value_diff(va, vb):
if type(va) != type(vb):
return True, "type_mismatch"

if isinstance(va, np.ndarray):
if va.shape != vb.shape:
return True, f"shape {va.shape} != {vb.shape}"
if va.dtype != vb.dtype:
return True, f"dtype {va.dtype} != {vb.dtype}"
if not np.allclose(va, vb, atol=1e-6):
return True, "values_changed"
return False, None

if isinstance(va, (list, tuple)):
if len(va) != len(vb):
return True, f"len {len(va)} != {len(vb)}"
return va != vb, None

return va != vb, None

def main():
ap = argparse.ArgumentParser()
ap.add_argument("--a", required=True)
ap.add_argument("--b", required=True)
ap.add_argument("--out", required=True)
args = ap.parse_args()

ra = GGUFReader(args.a)
rb = GGUFReader(args.b)

report = {
"kv": {},
"tensors": {},
}

# ---- KV METADATA ----
keys_a = set(ra.fields.keys())
keys_b = set(rb.fields.keys())

report["kv"]["only_in_a"] = sorted(keys_a - keys_b)
report["kv"]["only_in_b"] = sorted(keys_b - keys_a)
report["kv"]["changed"] = {}

for k in sorted(keys_a & keys_b):
va = ra.fields[k].data
vb = rb.fields[k].data
changed, reason = value_diff(va, vb)
if changed:
report["kv"]["changed"][k] = {
"reason": reason,
"a": summarize(va),
"b": summarize(vb),
}

# ---- TENSORS ----
tensors_a = set(ra.tensors.keys())
tensors_b = set(rb.tensors.keys())

report["tensors"]["only_in_a"] = sorted(tensors_a - tensors_b)
report["tensors"]["only_in_b"] = sorted(tensors_b - tensors_a)
report["tensors"]["changed"] = {}

for k in sorted(tensors_a & tensors_b):
ta = ra.tensors[k].data
tb = rb.tensors[k].data
changed, reason = value_diff(ta, tb)
if changed:
report["tensors"]["changed"][k] = {
"reason": reason,
"a": summarize(ta),
"b": summarize(tb),
}

with open(args.out, "w") as f:
json.dump(report, f, indent=2)

print(f"✅ GGUF diff report written to {args.out}")

if __name__ == "__main__":
main()

# --- FILE: ./inspector.py ---

import sys
import numpy as np
from llama_cpp import Llama

# === КОНФИГУРАЦИЯ ===
MODEL_PATH = "/home/vitalij/AI/Phi-3-medium-128k-instruct-Q4_K_M.gguf"

def cosine_similarity(v1, v2):
"""Физика смыслов: насколько близки два вектора"""
norm_v1 = np.linalg.norm(v1)
norm_v2 = np.linalg.norm(v2)
if norm_v1 == 0 or norm_v2 == 0:
return 0.0
return np.dot(v1, v2) / (norm_v1 * norm_v2)

def run_inspection():
print(f"⚙️ ЗАГРУЗКА ЯДРА: {MODEL_PATH}")
try:
# n_ctx=2048 - ставим немного больше памяти для теста
llm = Llama(
model_path=MODEL_PATH,
embedding=True,
n_gpu_layers=-1,
n_ctx=2048, 
verbose=False
)
except Exception as e:
print(f"❌ ОШИБКА ЗАГРУЗКИ: {e}")
return

print("✅ ЯДРО АКТИВНО.")
print(f"📊 Параметры модели:")
print(f" - Размер вектора (Embedding Dim): {llm.n_embd()}")

# --- ТЕСТ 1: ИЗВЛЕЧЕНИЕ СМЫСЛА ---
print("\n🔬 ТЕСТ 1: ИЗВЛЕЧЕНИЕ ВЕКТОРА")
word = "Архитектура"

# ИСПРАВЛЕНИЕ: Передаем текст напрямую. Библиотека сама сделает магию.
# embed() возвращает список векторов (по одному на токен).
# Мы берем [-1] - это вектор, в котором сконденсирован смысл всего слова.
raw_output = llm.embed(word)
embedding = np.array(raw_output[-1])

print(f" Слово: '{word}'")
print(f" Вектор получен! Размерность: {len(embedding)}")
print(f" Сигнатура (первые 5 чисел): {embedding[:5]}")

# --- ТЕСТ 2: ПРОВЕРКА ПОНИМАНИЯ (КОСИНУС) ---
print("\n🔬 ТЕСТ 2: ФИЗИКА СМЫСЛОВ (КОРОЛЬ - МУЖЧИНА + ЖЕНЩИНА)")

def get_vec(text):
# Функция-обертка для получения чистого вектора
output = llm.embed(text)
# Если слово разбилось на несколько токенов, берем последний,
# так как он содержит контекст предыдущих (механизм attention)
return np.array(output[-1])

v_king = get_vec("Король")
v_man = get_vec("Мужчина")
v_woman = get_vec("Женщина")
v_queen = get_vec("Королева")

# Проверка "яблока" для контраста
v_apple = get_vec("Яблоко")

# Арифметика: Король - Мужчина + Женщина
v_synthetic = v_king - v_man + v_woman

# Проверяем, похоже ли это на Королеву
sim_queen = cosine_similarity(v_synthetic, v_queen)
sim_apple = cosine_similarity(v_synthetic, v_apple)

print(f" Резонанс (Синтез <-> Королева): {sim_queen:.4f}")
print(f" Резонанс (Синтез <-> Яблоко): {sim_apple:.4f}")

if sim_queen > sim_apple:
print("✅ УСПЕХ: Векторная арифметика работает. Смыслы извлечены.")
else:
print("⚠️ ОШИБКА: Смысловой шум.")

if __name__ == "__main__":
run_inspection()
# --- FILE: ./particle.py ---

from ctypes import Structure, c_double, c_int, byref, memmove, sizeof, c_uint32, c_uint, c_uint64, string_at, POINTER, c_char, c_void_p
import math
import sys

def notNone(a):
"""
Returns True if array a contains at least one element that is not None. Returns False otherwise.
"""
return a.count(None) != len(a)

class Particle(Structure):
"""
The main REBOUND particle data structure. 
This is an abstraction of the reb_particle structure in C.
The Particle fields are set at the end of simulation.py to avoid circular references.

Attributes
----------
x, y, z : float 
Particle positions
vx, vy, vz : float 
Particle velocities
ax, ay, az : float 
Particle accelerations
m : float 
Particle mass
r : float 
Particle radius
last_collision : float 
Last time the particle had a physical collision (if checking for collisions)
c : c_void_p (C void pointer) 
Pointer to the cell the particle is currently in (if using tree code)
hash : c_uint32 
Particle hash (permanent identifier for the particle)
ap : c_void_p (C void pointer)
Pointer to additional parameters one might want to add to particles
_sim : POINTER(rebound.Simulation)
Internal pointer to the parent simulation (used in C version of REBOUND)
a, e, inc, Omega, omega, f : float
(Kepler Elements) Semi-major axis, eccentricity, inclination, longitude of the ascending node, argument of periapsis, and true anomaly respectively. The Keplerian Elements are in Jacobi coordinates (with mu = G*Minc, where Minc is the total mass from index 0 to the particle's index, inclusive).
"""
def __repr__(self):
""" 
Returns a string with the position and velocity of the particle.
"""
return '<{0}.{1} object at {2}, m={3} x={4} y={5} z={6} vx={7} vy={8} vz={9}>'.format(self.__module__, type(self).__name__, hex(id(self)), self.m, self.x, self.y, self.z, self.vx, self.vy, self.vz)


def __init__(self, simulation=None, particle=None, m=None, x=None, y=None, z=None, vx=None, vy=None, vz=None, primary=None, a=None, P=None, e=None, inc=None, Omega=None, omega=None, pomega=None, f=None, M=None, E=None, l=None, theta=None, T=None, r=None, date=None, variation=None, variation2=None, h=None, k=None, ix=None, iy=None, pal_h=None, pal_k=None, pal_ix=None, pal_iy=None, hash=0, jacobi_masses=False):
"""
Initializes a Particle structure. Rather than explicitly creating 
a Particle structure, users may use the ``add()`` member function 
of a Simulation instance, which will both create a Particle and 
then add it to the simulation with one function call.

This function accepts either cartesian positions and velocities, 
classical orbital elements together with the reference Particle 
(the primary), as well as orbital parameters defined by Pal (2009).

For convenience, optional keywords that are not passed default 
to zero (mass, cartesian and orbital elements). 

Whenever initializing a particle from orbital elements, one must 
specify either the semimajor axis or the period of the orbit.

For classical orbital parameters, one can specify the longitude 
of the ascending node by passing Omega, to specify the pericenter 
one can pass either omega or pomega (not both), and for the 
longitude/anomaly one can pass one of f, M, l or theta. 
See ipython_examples/OrbitalElements.ipynb for examples. 
See also Murray & Dermott Solar System Dynamics for formal 
definitions of angles in orbital mechanics.

All angles should be specified in radians.


Parameters
----------
simulation : Simulation 
Simulation instance associated with this particle (Required if passing orbital elements or setting up a variation).
particle : Particle, optional 
If a particle is passed, a copy of that particle is returned.
If a variational particle is initialized, then ``particle`` is 
original particle that will be varied. 
m : float 
Mass (Default: 0)
x, y, z : float 
Positions in Cartesian coordinates (Default: 0)
vx, vy, vz : float 
Velocities in Cartesian coordinates (Default: 0)
primary : Particle 
Primary body for converting orbital elements to cartesian (Default: center of mass of the particles in the passed simulation, i.e., this will yield Jacobi coordinates as one progressively adds particles) 
a : float 
Semimajor axis (a or P required if passing orbital elements)
P : float
Orbital period (a or P required if passing orbital elements)
e : float 
Eccentricity (Default: 0)
inc : float 
Inclination (Default: 0)
Omega : float 
Longitude of ascending node (Default: 0)
omega : float 
Argument of pericenter (Default: 0)
pomega : float 
Longitude of pericenter (Default: 0)
f : float 
True anomaly (Default: 0)
M : float 
Mean anomaly (Default: 0)
E : float 
Eccentric anomaly (Default: 0)
l : float 
Mean longitude (Default: 0)
theta : float 
True longitude (Default: 0)
T : float 
Time of pericenter passage 
h or pal_h : float 
h variable, see Pal (2009) for a definition (Default: 0)
k or pal_k : float 
k variable, see Pal (2009) for a definition (Default: 0)
ix or pal_ix : float 
ix variable, see Pal (2009) for a definition (Default: 0)
iy or pal_iy : float 
iy variable, see Pal (2009) for a definition (Default: 0)
r : float 
Particle radius (only used for collisional simulations)
date : string 
For consistency with adding particles through horizons. Not used here.
variation : string (Default: None)
Set this string to the name of an orbital parameter to initialize the particle as a variational particle.
Can be one of the following: m, a, e, inc, omega, Omega, f, k, h, lambda, ix, iy.
variation2 : string (Default: None)
Set this string to the name of a second orbital parameter to initialize the particle as a second order variational particle. Only used for second order variational equations. 
Can be one of the following: m, a, e, inc, omega, Omega, f, k, h, lambda, ix, iy.
hash : c_uint32 
Unsigned integer identifier for particle. Can pass an integer directly, or a string that will be converted to a hash. User is responsible for assigning unique hashes.
jacobi_masses: bool
Whether to use jacobi primary mass in orbit initialization. Particle mass will still be set to physical value (Default: False)
Examples
--------

>>> sim = rebound.Simulation()
>>> sim.add(m=1.)
>>> p1 = rebound.Particle(simulation=sim, m=0.001, a=0.5, e=0.01)
>>> p2 = rebound.Particle(simulation=sim, m=0.0, x=1., vy=1.)
>>> p3 = rebound.Particle(simulation=sim, m=0.001, a=1.5, h=0.1, k=0.2, l=0.1)
>>> p4 = rebound.Particle(simulation=sim, m=0.001, a=1.5, omega="uniform") # omega will be a random number between 0 and 2pi

""" 

# Unpickling
binarydata = None
if isinstance(simulation, bytes):
# simulation is actually a bytes array with the particle data
binarydata = simulation
if isinstance(particle, bytes):
# simulation is actually a bytes array with the particle data
binarydata = particle
if binarydata is not None:
if len(binarydata) != sizeof(self):
raise ValueError("Binary particle data does not have the right size.")
buft = c_char * len(binarydata)
buf = buft.from_buffer_copy(binarydata)
memmove(byref(self), byref(buf), sizeof(self))
self.c = 0
self.sim = 0
self.ap = 0
return

# Random initialization of particle angles
clibrebound.reb_random_uniform.restype = c_double
if simulation is not None:
# Will use random seed stored in simulation.
simp = byref(simulation)
else:
# Will use random seed based on time.
simp = 0
if Omega == "uniform":
Omega = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if omega == "uniform":
omega = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if pomega == "uniform":
pomega = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if f == "uniform":
f = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if M == "uniform":
M = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if E == "uniform":
E = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if l == "uniform":
l = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if theta == "uniform":
theta = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))
if inc == "uniform":
inc = clibrebound.reb_random_uniform(simp, c_double(0.0), c_double(math.pi*2.0))

self.hash = hash # set via the property, which checks for type

if isinstance(primary, (str,int)):
primary = simulation.particles[primary]


if variation:
if primary is None:
primary = simulation.particles[0]
# Find particle to differenciate
lc = locals().copy()
del lc["self"]
del lc["variation"]
del lc["variation2"]
if particle is None:
particle = Particle(**lc)
# First or second order?
if variation and variation2:
variation_order = 2
else:
variation_order = 1
# Shortcuts for variable names
if variation == "l":
variation = "lambda"
if variation2 == "l":
variation2 = "lambda"
if variation == "i":
variation = "inc"
if variation2 == "i":
variation2 = "inc"

variationtypes = ["m","a","e","inc","omega","Omega","f","k","h","lambda","ix","iy"]
if variation_order==1:
if variation in variationtypes:
method = getattr(clibrebound, 'reb_particle_derivative_'+variation)
method.restype = Particle
p = method(c_double(simulation.G), primary, particle)
else:
raise ValueError("Variational particles can only be initializes using the derivatives with respect to one of the following: %s."%", ".join(variationtypes))
elif variation_order==2:
if variation in variationtypes and variation2 in variationtypes:
# Swap variations if needed
vi1 = variationtypes.index(variation)
vi2 = variationtypes.index(variation2)
if vi2 < vi1:
variation, variation2 = variation2, variation

method = getattr(clibrebound, 'reb_particle_derivative_'+variation+'_'+variation2)
method.restype = Particle
p = method(c_double(simulation.G), primary, particle)
else:
raise ValueError("Variational particles can only be initializes using the derivatives with respect to one of the following: %s."%", ".join(variationtypes))
else:
raise ValueError("Variational equations beyond second order are not implemented.")
self.m = p.m
self.x = p.x
self.y = p.y
self.z = p.z
self.vx = p.vx
self.vy = p.vy
self.vz = p.vz
return 

if particle is not None:
memmove(byref(self), byref(particle), sizeof(self))
return
cart = [x,y,z,vx,vy,vz]
orbi = [primary,a,P,e,inc,Omega,omega,pomega,f,M,E,l,theta,T]
if pal_h is not None:
if h is not None:
raise ValueError("Both h and pal_h were given.")
h = pal_h
if pal_k is not None:
if k is not None:
raise ValueError("Both k and pal_k were given.")
k = pal_k
if pal_ix is not None:
if ix is not None:
raise ValueError("Both ix and pal_ix were given.")
ix = pal_ix
if pal_iy is not None:
if iy is not None:
raise ValueError("Both iy and pal_iy were given.")
iy = pal_iy
pal = [h,k,ix,iy]

self.ax = 0.
self.ay = 0.
self.az = 0.
if m is None:
self.m = 0.
else:
self.m = m 
if r is None:
self.r = 0.
else:
self.r = r
self.last_collision = 0.
self.c = None
self.ap = None

if notNone([e,inc,omega,pomega,Omega,M,f,E,theta,T]) and notNone(pal):
raise ValueError("You cannot mix Pal coordinates (h,k,ix,iy) with the following orbital elements: e,inc,Omega,omega,pomega,f,M,E,theta,T. If a longitude/anomaly is needed in Pal coordinates, use l.")
if notNone(cart) and notNone(orbi):
raise ValueError("You cannot pass cartesian coordinates and orbital elements (and/or primary) at the same time.")
if notNone(orbi):
if simulation is None:
raise ValueError("Need to specify simulation when initializing particle with orbital elements.")
if primary is None:
clibrebound.reb_simulation_com.restype = Particle
primary = clibrebound.reb_simulation_com(byref(simulation)) # this corresponds to adding in Jacobi coordinates
if jacobi_masses is True:
interior_mass = 0
for p in simulation.particles:
interior_mass += p.m
# orbit conversion uses mu=G*(p.m+primary.m) so set prim.m=Mjac-m so mu=G*Mjac
primary.m = simulation.particles[0].m*(self.m + interior_mass)/interior_mass - self.m
if a is None and P is None:
raise ValueError("You need to pass either a semimajor axis or orbital period to initialize the particle using orbital elements.")
if a is not None and P is not None:
raise ValueError("You can pass either the semimajor axis or orbital period, but not both.")
if a is None:
a = (P**2*simulation.G*(primary.m + self.m)/(4.*math.pi**2))**(1./3.)
if notNone(pal):
# Pal orbital parameters
if h is None:
h = 0.
if k is None:
k = 0.
if l is None:
l = 0.
if ix is None:
ix = 0.
if iy is None:
iy = 0.
if((ix*ix + iy*iy) > 4.0):
raise ValueError("Passed (ix, iy) coordinates are not valid, squared sum exceeds 4.")
clibrebound.reb_particle_from_pal.restype = Particle
p = clibrebound.reb_particle_from_pal(c_double(simulation.G), primary, c_double(self.m), c_double(a), c_double(l), c_double(k), c_double(h), c_double(ix), c_double(iy))
else:
# Normal orbital parameters
if e is None:
e = 0.
if inc is None:
inc = 0.
if Omega is None: # we require that Omega be passed if you want to specify longitude of node
Omega = 0.

pericenters = [omega, pomega] # Need omega for C function. Can specify it either directly or through pomega indirectly. 
numNones = pericenters.count(None)

if numNones == 0:
raise ValueError("Can't pass both omega and pomega")
if numNones == 2: # Neither passed. Default to 0.
omega = 0.
if numNones == 1:
if pomega is not None: # Only have to find omega is pomega was passed
if math.cos(inc) > 0: # inc is in range [-pi/2, pi/2] (prograde), so pomega = Omega + omega
omega = pomega - Omega
else:
omega = Omega - pomega # for retrograde orbits, pomega = Omega - omega

longitudes = [f,M,E,l,theta,T] # can specify longitude through any of these. Need f for C function.
numNones = longitudes.count(None)

if numNones < 5:
raise ValueError("Can only pass one longitude/anomaly in the set [f, M, E, l, theta, T]")
if numNones == 6: # none of them passed. Default to 0.
f = 0.
if numNones == 5: # Only one was passed. Calculate f.
if f is not None:
pass # Nothing to be done
elif theta is not None: # theta is next easiest
if math.cos(inc) > 0: # for prograde orbits, theta = Omega + omega + f
f = theta - Omega - omega
else:
f = Omega - omega - theta # for retrograde, theta = Omega - omega - f
elif l is not None: 
if math.cos(inc) > 0: # for prograde orbits, l = Omega + omega + M
M = l - Omega - omega
else:
M = Omega - omega - l # for retrograde, l = Omega - omega - M
f = M_to_f(e, M)
elif T is not None: # works for both elliptical and hyperbolic orbits
# TODO: has accuracy problems for M=n*(t-T) << 1
n = (simulation.G*(primary.m+self.m)/abs(a**3))**0.5
M = n*(simulation.t - T)
f = M_to_f(e, M)
elif M is not None:
f = M_to_f(e, M)
elif E is not None:
f = E_to_f(e, E)

err = c_int()
clibrebound.reb_particle_from_orbit_err.restype = Particle
p = clibrebound.reb_particle_from_orbit_err(c_double(simulation.G), primary, c_double(self.m), c_double(a), c_double(e), c_double(inc), c_double(Omega), c_double(omega), c_double(f), byref(err))
if err.value == 1:
raise ValueError("Can't set e exactly to 1.")
if err.value == 2:
raise ValueError("Eccentricity must be greater than or equal to zero.")
if err.value == 3:
raise ValueError("Bound orbit (a > 0) must have e < 1.")
if err.value == 4:
raise ValueError("Unbound orbit (a < 0) must have e > 1.")
if err.value == 5:
raise ValueError("Unbound orbit can't have f beyond the range allowed by the asymptotes set by the hyperbola.")
if err.value == 6:
raise ValueError("Primary has no mass.")
self.x = p.x
self.y = p.y
self.z = p.z
self.vx = p.vx
self.vy = p.vy
self.vz = p.vz
else:
if x is None:
x = 0.
if y is None:
y = 0.
if z is None:
z = 0.
if vx is None:
vx = 0.
if vy is None:
vy = 0.
if vz is None:
vz = 0.
self.x = x
self.y = y
self.z = z
self.vx = vx
self.vy = vy
self.vz = vz

def copy(self):
"""
Returns a deep copy of the particle. The particle is not added to any simulation by default.
"""
np = Particle()
memmove(byref(np), byref(self), sizeof(self))
return np

# Pickling method
def __reduce__(self):
return (Particle, (string_at(byref(self), size=sizeof(self)),))

def orbit(self, primary=None, G=None):
""" 
Returns a rebound.Orbit object with the keplerian orbital elements
corresponding to the particle around the passed primary
(rebound.Particle) If no primary is passed, defaults to Jacobi coordinates
(with mu = G*Minc, where Minc is the total mass from index 0 to the particle's index, inclusive). 

Examples
--------

>>> sim = rebound.Simulation()
>>> sim.add(m=1.)
>>> sim.add(x=1.,vy=1.)
>>> orbit = sim.particles[1].orbit(sim.particles[0]) # Heliocentric coordinates
>>> print(orbit.e) # gives the eccentricity

Parameters
----------
primary : rebound.Particle
Central body (Optional. Default uses Jacobi coordinates)
G : float
Gravitational constant (Optional. Default takes G from simulation in which particle is in)

Returns
-------
A rebound.Orbit object 
"""
if not self._sim:
# Particle not in a simulation
if primary is None:
raise ValueError("Particle does not belong to any simulation and no primary given. Cannot calculate orbit.")
if G is None:
raise ValueError("Particle does not belong to any simulation and G not given. Cannot calculate orbit.")
else:
G = c_double(G)
else:
# First check whether this is particles[0]
clibrebound.reb_simulation_particle_index.restype = c_int
index = clibrebound.reb_simulation_particle_index(byref(self)) # first check this isn't particles[0]
if index == 0 and primary is None:
raise ValueError("Orbital elements for particle[0] not implemented unless primary is provided")

if primary is None: # Use default, i.e., Jacobi coordinates
clibrebound.reb_simulation_jacobi_com.restype = Particle # now return jacobi center of mass
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
G = c_double(self._sim.contents.G)

err = c_int()
clibrebound.reb_orbit_from_particle_err.restype = Orbit
o = clibrebound.reb_orbit_from_particle_err(G, self, primary, byref(err))

if err.value == 1:
raise ValueError("Primary has no mass.")
if err.value == 2:
raise ValueError("Particle and primary positions are the same.")

return o

def sample_orbit(self, Npts=100, primary=None, samplingAngle=None, duplicateEndpoint=None):
"""
Returns a nested list of xyz positions along the osculating orbit of the particle. 
If primary is not passed, returns xyz positions along the Jacobi osculating orbit
(with mu = G*Minc, where Minc is the total mass from index 0 to the particle's index, inclusive). 

Parameters
----------
Npts : int, optional 
Number of points along the orbit to return (default: 100)
primary : rebound.Particle, optional
Primary to use for the osculating orbit (default: Jacobi center of mass)
samplingAngle: str, optional
This determines which angle is sampled linearly. Can be:
- "M" (mean anomaly)
- "E" (eccentric anomaly) 
- "f" (true anomaly)
duplicateEndpoint: bool, optional
If true, then the first and last point will be identical for closed orbits. This is useful for some plotting tools. The default is true for eccentric orbits. The argument has no effect for hyperbolic orbits (because the endpoints are not identical).
"""
if primary is None:
primary = self.jacobi_com
o = self.orbit(primary=primary)

phases_f = []
if samplingAngle is not None:
if any(c not in "EMf" for c in samplingAngle):
raise ValueError("Unknown character in samplingAngle.")

if o.a < 0.: # hyperbolic orbit
#a = o.a
if samplingAngle is None:
samplingAngle = "Mf"
Nptsangle = {}
for angle in samplingAngle[1:]:
Nptsangle[angle] = (Npts-1)//len(samplingAngle) # one point is reserved for actual position
Nptsangle[samplingAngle[0]] = Npts-1-sum(Nptsangle.values())
if "M" in samplingAngle:
phi = math.acos(-1./o.e)*0.999
Npts = Nptsangle["M"]
dphi = 2*phi/(Npts-1)
for i in range(Npts):
f = M_to_f(o.e, phi)
phases_f.append(f)
phi -= dphi
if "E" in samplingAngle:
phi = math.acos(-1./o.e)*0.999
Npts = Nptsangle["E"]
dphi = 2*phi/(Npts-1)
for i in range(Npts):
f = E_to_f(o.e, phi)
phases_f.append(f)
phi -= dphi
if "f" in samplingAngle:
phi = math.acos(-1./o.e)*0.999
Npts = Nptsangle["f"]
dphi = 2*phi/(Npts-1)
for i in range(Npts):
f = mod2pi(phi)
phases_f.append(f)
phi -= dphi
else: # circular orbit
#a = primary.m/(primary.m+self.m)*o.a
if samplingAngle is None:
samplingAngle = "Ef"
if duplicateEndpoint is None:
duplicateEndpoint = True
Nptsangle = {}
for angle in samplingAngle[1:]:
Nptsangle[angle] = (Npts-1)//len(samplingAngle) # one point is reserved for actual position
Nptsangle[samplingAngle[0]] = Npts-1-sum(Nptsangle.values())
if "M" in samplingAngle:
Npts = Nptsangle["M"]
dphi = 2.*math.pi/(Npts-1 if duplicateEndpoint else Npts) # one point is reserved for the end point
for i in range(Npts):
f = M_to_f(o.e, i*dphi)
phases_f.append(f)
if "E" in samplingAngle:
Npts = Nptsangle["E"]
dphi = 2.*math.pi/(Npts-1 if duplicateEndpoint else Npts) # one point is reserved for the end point
for i in range(Npts):
f = E_to_f(o.e, i*dphi)
phases_f.append(f)
if "f" in samplingAngle:
Npts = Nptsangle["f"]
dphi = 2.*math.pi/(Npts-1 if duplicateEndpoint else Npts) # one point is reserved for the end point
for i in range(Npts):
f = i*dphi
f = mod2pi(f)
phases_f.append(f)

# add actual position
f = mod2pi(o.f)
phases_f.append(f)
phases_f.sort()

pts_pre = []
pts_post = []

#clibrebound.reb_particle_com_of_pair.restype = Particle
#primary = clibrebound.reb_particle_com_of_pair(primary, self)

for f in phases_f:
newp = Particle(a=o.a, f=f, inc=o.inc, omega=o.omega, Omega=o.Omega, e=o.e, m=self.m, primary=primary, simulation=self._sim.contents)
if f<=o.f:
pts_pre.append(newp.xyz)
else:
pts_post.append(newp.xyz)

return pts_post + pts_pre

# Simple operators for particles.

def __eq__(self, other):
# This ignores the pointer values
if not isinstance(other,Particle):
return NotImplemented
clibrebound.reb_particle_diff.restype = c_int
ret = clibrebound.reb_particle_diff(self, other)
return not ret

def __pow__(self, other):
if not isinstance(other, Particle):
return NotImplemented 
clibrebound.reb_particle_distance.restype = c_double
return clibrebound.reb_particle_distance(byref(self), byref(other))
def __add__(self, other):
if not isinstance(other, Particle):
return NotImplemented 
c = self.copy()
return c.__iadd__(other)

def __iadd__(self, other):
if not isinstance(other, Particle):
return NotImplemented 
clibrebound.reb_particle_iadd(byref(self), byref(other))
return self

def __sub__(self, other):
if not isinstance(other, Particle):
return NotImplemented 
c = self.copy()
return c.__isub__(other)

def __isub__(self, other):
if not isinstance(other, Particle):
return NotImplemented 
clibrebound.reb_particle_isub(byref(self), byref(other))
return self

def __mul__(self, other):
try:
other = float(other)
except:
return NotImplemented 
c = self.copy()
return c.__imul__(other)

def __imul__(self, other):
try:
other = float(other)
except:
return NotImplemented 
clibrebound.reb_particle_imul(byref(self), c_double(other))
return self

def __rmul__(self, other):
try:
other = float(other)
except:
return NotImplemented 
c = self.copy()
return c.__imul__(other)

def __div__(self, other):
return self.__truediv__(other)

def __idiv__(self, other):
return self.__itruediv__(other)

def __truediv__(self, other):
try:
other = float(other)
except:
return NotImplemented 
c = self.copy()
if other==0.:
raise ZeroDivisionError
return c.__imul__(1./other)

def __itruediv__(self, other):
try:
other = float(other)
except:
return NotImplemented 
if other==0.:
raise ZeroDivisionError
return self.__imul__(1./other)

def rotate(self, q):
if not isinstance(q, Rotation):
raise NotImplementedError
clibrebound.reb_particle_irotate(byref(self), q)

@property
def index(self):
clibrebound.reb_simulation_particle_index.restype = c_int
return clibrebound.reb_simulation_particle_index(byref(self)) 

@property
def xyz(self):
"""
Get or set the xyz position coordinates of the particle.
"""
return [self.x, self.y, self.z]
@xyz.setter
def xyz(self, value):
if len(value)!=3:
raise AttributeError("Can only set xyz positions to array with length 3")
self.x = float(value[0])
self.y = float(value[1])
self.z = float(value[2])

@property
def vxyz(self):
"""
Get or set the xyz velocity coordinates of the particle.
"""
return [self.vx, self.vy, self.vz]
@vxyz.setter
def vxyz(self, value):
if len(value)!=3:
raise AttributeError("Can only set xyz velocities to array with length 3")
self.vx = float(value[0])
self.vy = float(value[1])
self.vz = float(value[2])

@property
def d(self):
return self.orbit().d
@property
def v(self):
return self.orbit().v 
@property
def h(self):
return self.orbit().h
@property
def hvec(self):
h = self.orbit().hvec
return [h.x, h.y, h.z]
@property
def P(self):
return self.orbit().P
@P.setter
def P(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, P=value, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, f=o.f) 
self._copy_coordinates(newP)
@property
def n(self):
return self.orbit().n 
@property
def a(self):
return self.orbit().a 
@a.setter
def a(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=value, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, f=o.f) 
self._copy_coordinates(newP)
@property
def rhill(self):
return self.orbit().rhill
@property
def e(self):
return self.orbit().e 
@e.setter
def e(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=value, inc=o.inc, omega=o.omega, Omega=o.Omega, f=o.f) 
self._copy_coordinates(newP)
@property
def evec(self):
e = self.orbit().evec
return [e.x, e.y, e.z]
@property
def inc(self):
return self.orbit().inc 
@inc.setter
def inc(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=value, omega=o.omega, Omega=o.Omega, f=o.f) 
self._copy_coordinates(newP)
@property
def Omega(self):
return self.orbit().Omega 
@Omega.setter
def Omega(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=o.omega, Omega=value, f=o.f) 
self._copy_coordinates(newP)
@property
def omega(self):
return self.orbit().omega 
@omega.setter
def omega(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=value, Omega=o.Omega, f=o.f) 
self._copy_coordinates(newP)
@property
def pomega(self):
return self.orbit().pomega 
@pomega.setter
def pomega(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, pomega=value, Omega=o.Omega, f=o.f) 
self._copy_coordinates(newP)
@property
def f(self):
return self.orbit().f 
@f.setter
def f(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, f=value) 
self._copy_coordinates(newP)
@property
def M(self):
return self.orbit().M 
@M.setter
def M(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, M=value) 
self._copy_coordinates(newP)
@property
def l(self):
return self.orbit().l 
@l.setter
def l(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, l=value) 
self._copy_coordinates(newP)
@property
def theta(self):
return self.orbit().theta 
@theta.setter
def theta(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, theta=value) 
self._copy_coordinates(newP)
@property
def T(self):
return self.orbit().T
@T.setter
def T(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, e=o.e, inc=o.inc, omega=o.omega, Omega=o.Omega, T=value) 
self._copy_coordinates(newP)
# Pal coordinates
@property
def pal_h(self):
return self.orbit().pal_h
@pal_h.setter
def pal_h(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, l=o.l, pal_h=value, pal_k=o.pal_k, pal_ix=o.pal_ix, pal_iy=o.pal_iy)
self._copy_coordinates(newP)
@property
def pal_k(self):
return self.orbit().pal_k
@pal_k.setter
def pal_k(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, l=o.l, pal_h=o.pal_h, pal_k=value, pal_ix=o.pal_ix, pal_iy=o.pal_iy)
self._copy_coordinates(newP)
@property
def pal_ix(self):
return self.orbit().pal_ix
@pal_ix.setter
def pal_ix(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, l=o.l, pal_h=o.pal_h, pal_k=o.pal_k, pal_ix=value, pal_iy=o.pal_iy)
self._copy_coordinates(newP)
@property
def pal_iy(self):
return self.orbit().pal_iy
@pal_iy.setter
def pal_iy(self,value):
o = self.orbit()
clibrebound.reb_simulation_jacobi_com.restype = Particle
primary = clibrebound.reb_simulation_jacobi_com(byref(self))
if self._sim is None:
raise RuntimeError("Cannot modify particle which is not a member of a simulation.")
newP = Particle(simulation=self._sim.contents, primary=primary, m=self.m, a=o.a, l=o.l, pal_h=o.pal_h, pal_k=o.pal_k, pal_ix=o.pal_ix, pal_iy=value)
self._copy_coordinates(newP)
# Other properties
@property
def jacobi_com(self):
clibrebound.reb_simulation_jacobi_com.restype = Particle
return clibrebound.reb_simulation_jacobi_com(byref(self))
# Calculate center of mass with another particle
def com_with(self, p):
clibrebound.reb_particle_com_of_pair.restype = Particle
return clibrebound.reb_particle_com_of_pair(p, self)
@property
def hash(self):
"""
Get or set the particle's hash. If set to a string, the corresponding integer hash is calculated.
"""
return c_uint32(self._hash)
@hash.setter
def hash(self, value):
PY3 = sys.version_info[0] == 3
hash_types = c_uint32, c_uint, c_uint64
if PY3:
string_types = str,
int_types = int,
else:
string_types = basestring,
int_types = int, long,
if isinstance(value, hash_types):
self._hash = value.value
elif isinstance(value, string_types):
self._hash = hash(value).value
elif isinstance(value, int_types):
self._hash = value
else:
raise AttributeError("Hash must be set to an integer, a ctypes.c_uint32 or a string. See UniquelyIdentifyingParticlesWithHashes.ipynb ipython_example.")

def _copy_coordinates(self, p):
"""
Copy coordinates (and only coordinates) from particle p to self
"""
self.xyz = p.xyz
self.vxyz = p.vxyz

from .simulation import Simulation
from . import clibrebound
from .tools import E_to_f, M_to_f, mod2pi
from .orbit import Orbit
from .rotation import Rotation
from .hash import hash

if sizeof(c_void_p)==4:
# Add padding for 32 bit
Particle._fields_ = [("x", c_double),
("y", c_double),
("z", c_double),
("vx", c_double),
("vy", c_double),
("vz", c_double),
("ax", c_double),
("ay", c_double),
("az", c_double),
("m", c_double),
("r", c_double),
("last_collision", c_double),
("c", c_void_p),
("_pad1", c_char*4),
("_hash", c_uint32),
("_pad2", c_char*4),
("ap", c_void_p),
("_pad3", c_char*4),
("_sim", POINTER(Simulation)),
("_pad4", c_char*4),
]
else:
Particle._fields_ = [("x", c_double),
("y", c_double),
("z", c_double),
("vx", c_double),
("vy", c_double),
("vz", c_double),
("ax", c_double),
("ay", c_double),
("az", c_double),
("m", c_double),
("r", c_double),
("last_collision", c_double),
("c", c_void_p),
("_hash", c_uint32),
("ap", c_void_p),
("_sim", POINTER(Simulation)),
]

# --- FILE: ./phi3_final_repair.py ---

#!/usr/bin/env python3
# phi3_final_repair.py - ФИНАЛЬНОЕ ИСПРАВЛЕНИЕ

import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter
import json
from datetime import datetime

def create_fixed_phi3():
"""Создает исправленный GGUF файл с правильными метаданными"""

original = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
poler = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
output = "Phi-3-mini-4k-instruct-Q4_K_M_FIXED.gguf"

log_file = f"phi3_fix_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

def log(msg):
timestamp = datetime.now().strftime("%H:%M:%S")
print(f"[{timestamp}] {msg}")
with open(log_file, 'a') as f:
f.write(f"[{timestamp}] {msg}\n")

log("="*60)
log("ФИНАЛЬНОЕ ИСПРАВЛЕНИЕ PHI-3 МОДЕЛИ")
log(f"Оригинал: {original}")
log(f"POLER: {poler}")
log(f"Выход: {output}")
log("="*60)

try:
# 1. Читаем оригинал
log("[1/4] Чтение оригинала...")
ra = GGUFReader(original)

# 2. Читаем POLER (только тензоры)
log("[2/4] Чтение POLER...")
rb = GGUFReader(poler)

# 3. Создаем writer
log("[3/4] Создание GGUF...")
w = GGUFWriter(output, "phi3")

# ========== ПРАВИЛЬНЫЕ МЕТАДАННЫЕ ==========
log("Добавление метаданных...")

# Правильные значения для Phi-3-mini-4k-instruct
metadata = {
# Общие поля
"general.name": "Phi-3-mini-4k-instruct",
"general.file_type": 15, # Q4_K_M
"general.quantization_version": 2,
"general.architecture": "phi3",

# Архитектура Phi-3
"phi3.context_length": 4096,
"phi3.embedding_length": 3072,
"phi3.block_count": 32,
"phi3.feed_forward_length": 8192,
"phi3.attention.head_count": 32,
"phi3.attention.head_count_kv": 32,
"phi3.attention.layer_norm_rms_epsilon": 1e-5,
"phi3.rope.dimension_count": 96,
"phi3.rope.freq_base": 10000.0,

# КРИТИЧЕСКИЕ ПОЛЯ ТОКЕНИЗАТОРА
"tokenizer.ggml.model": "llama",
"tokenizer.ggml.pre": "default",
"tokenizer.ggml.bos_token_id": 1,
"tokenizer.ggml.eos_token_id": 32000,
"tokenizer.ggml.unknown_token_id": 0,
"tokenizer.ggml.padding_token_id": 32000,
"tokenizer.ggml.add_bos_token": True,
"tokenizer.ggml.add_eos_token": False,
}

# Типы GGUF: 5=UINT32, 6=FLOAT32, 8=STRING, 9=BOOL
type_map = {
int: 5, float: 6, str: 8, bool: 9
}

for key, value in metadata.items():
try:
vtype = type_map[type(value)]
w.add_key_value(key, value, vtype)
log(f" ✓ {key} = {value}")
except Exception as e:
log(f" ⚠️ {key}: {e}")

# ========== ТОКЕНИЗАТОР ==========
log("Добавление токенизатора...")

try:
# Токены (важно: оригинал имеет 32064 токена, а не 64133!)
if "tokenizer.ggml.tokens" in ra.fields:
tokens_field = ra.fields["tokenizer.ggml.tokens"]
if len(tokens_field) >= 3:
tokens_data = tokens_field[2]

# Правильно конвертируем токены
tokens = []
for i, token in enumerate(tokens_data):
if i >= 32064: # Берем только правильное количество
break

if isinstance(token, (np.ndarray, np.memmap)):
if token.dtype == np.uint8:
try:
tokens.append(bytes(token).decode('utf-8', errors='ignore'))
except:
tokens.append(str(token.tolist()))
else:
tokens.append(str(token.tolist()))
else:
tokens.append(str(token))

w.add_token_list(tokens)
log(f" ✓ Токены: {len(tokens)}")

# Scores
if "tokenizer.ggml.scores" in ra.fields:
scores_field = ra.fields["tokenizer.ggml.scores"]
if len(scores_field) >= 3:
scores_data = scores_field[2]
scores = [float(s) for s in scores_data[:32064]] # Ограничиваем
w.add_token_scores(scores)
log(f" ✓ Scores: {len(scores)}")

# Token types
if "tokenizer.ggml.token_type" in ra.fields:
ttypes_field = ra.fields["tokenizer.ggml.token_type"]
if len(ttypes_field) >= 3:
ttypes_data = ttypes_field[2]
ttypes = [int(t) for t in ttypes_data[:32064]] # Ограничиваем
w.add_token_types(ttypes)
log(f" ✓ Token types: {len(ttypes)}")

except Exception as e:
log(f" ⚠️ Ошибка токенизатора: {e}")
import traceback
log(traceback.format_exc())

# ========== ТЕНЗОРЫ ИЗ POLER ==========
log("[4/4] Добавление тензоров из POLER...")

tensor_data_list = []
tensor_count = 0

for tensor in rb.tensors:
if tensor_count >= 195: # Phi-3 имеет 195 тензоров
break

name = tensor.name
dtype = tensor.tensor_type
data = tensor.data

if data is None:
continue

# Добавляем информацию о тензоре
w.add_tensor_info(
name=name,
tensor_shape=list(data.shape),
tensor_dtype=data.dtype,
tensor_nbytes=int(data.nbytes),
raw_dtype=dtype,
)

tensor_data_list.append(data)
tensor_count += 1

if tensor_count <= 3:
log(f" ✓ {name}: shape={data.shape}")

log(f" Всего тензоров: {tensor_count}")

# ========== ЗАПИСЬ ФАЙЛА ==========
log("Запись GGUF файла...")

# Открываем для записи
w.open_output_file(output)

# Записываем заголовки
w.write_header_to_file()
w.write_kv_data_to_file()
w.write_ti_data_to_file()

# Записываем тензоры
log(f"Запись данных тензоров...")
for i, data in enumerate(tensor_data_list):
if i % 20 == 0:
log(f" Тензор {i+1}/{len(tensor_data_list)}")
w.write_tensor_data(data)

w.close()

# ========== ПРОВЕРКА ==========
log("\n" + "="*60)
log("✅ ФАЙЛ СОЗДАН УСПЕШНО!")

if Path(output).exists():
size_mb = Path(output).stat().st_size / (1024**2)
log(f"✅ Размер: {size_mb:.2f} MB")
log(f"✅ Тензоры: {tensor_count}")

# Быстрая проверка структуры
try:
# Простая проверка первых байтов
with open(output, 'rb') as f:
magic = f.read(4)
if magic == b'GGUF':
log("✅ GGUF магия верна")
except Exception as e:
log(f"⚠️ Базовая проверка: {e}")

# Сохраняем отчет
report = {
"status": "success",
"output": output,
"size_mb": round(size_mb, 2),
"tensors": tensor_count,
"created": datetime.now().isoformat(),
"log": log_file
}

with open("phi3_final_report.json", "w") as f:
json.dump(report, f, indent=2)

log(f"\n✅ Отчет: phi3_final_report.json")

log("\n🎉 МОДЕЛЬ ГОТОВА К ТЕСТИРОВАНИЮ!")
log(f"\nКоманда для теста:")
log(f" ~/AI/llama.cpp/build/bin/llama-cli \\")
log(f" -m {output} \\")
log(f" -n 50 \\")
log(f" -p 'Hello' \\")
log(f" --temp 0.7")

else:
log("❌ Файл не создан!")

return True

except Exception as e:
log(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
import traceback
log(traceback.format_exc())
return False

if __name__ == "__main__":
print("="*60)
print("ФИНАЛЬНОЕ ИСПРАВЛЕНИЕ PHI-3 МОДЕЛИ")
print("="*60)

success = create_fixed_phi3()

if success:
print("\n" + "="*60)
print("✅ МОДЕЛЬ СОЗДАНА УСПЕШНО!")
print("="*60)
else:
print("\n" + "="*60)
print("❌ ОШИБКА СОЗДАНИЯ")
print("="*60)
# --- FILE: ./phi3_minimal_repair.py ---

#!/usr/bin/env python3
# phi3_minimal_repair.py - Минимальный, но рабочий ремонт

import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter
import json
from datetime import datetime

def create_minimal_phi3():
"""Создает минимальный, но рабочий GGUF файл"""

original = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
poler = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
output = "Phi-3-mini-4k-instruct-Q4_K_M_MINIMAL.gguf"

log_file = f"phi3_minimal_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

def log(msg):
timestamp = datetime.now().strftime("%H:%M:%S")
print(f"[{timestamp}] {msg}")
with open(log_file, 'a') as f:
f.write(f"[{timestamp}] {msg}\n")

log("="*60)
log("МИНИМАЛЬНОЕ ИСПРАВЛЕНИЕ PHI-3")
log(f"Оригинал: {original}")
log(f"POLER: {poler}")
log(f"Выход: {output}")
log("="*60)

try:
# 1. Читаем оригинал только для основных параметров
log("[1/4] Чтение оригинала...")
ra = GGUFReader(original)

# 2. Читаем POLER (только тензоры)
log("[2/4] Чтение POLER...")
rb = GGUFReader(poler)

# 3. Создаем writer
log("[3/4] Создание GGUF...")
w = GGUFWriter(output, "phi3")

# ========== МИНИМАЛЬНЫЕ МЕТАДАННЫЕ ==========
log("Добавление минимальных метаданных...")

# Берем только самые важные поля из оригинала
def get_simple_value(field_name, default=None):
try:
if field_name in ra.fields:
field = ra.fields[field_name]
if len(field) >= 3:
value = field[2]
# Если это numpy массив с одним элементом
if isinstance(value, (np.ndarray, np.memmap)) and value.size == 1:
return value.item()
# Если это массив байтов (строка)
elif isinstance(value, (np.ndarray, np.memmap)) and value.dtype == np.uint8:
try:
return bytes(value).decode('utf-8', errors='ignore')
except:
return str(value)
# Если это уже скаляр
else:
return value
except:
pass
return default

# Добавляем самые важные поля ВРУЧНУЮ
# Типы GGUF: 5=UINT32, 6=FLOAT32, 8=STRING, 9=BOOL

# 1. Обязательные поля модели
w.add_name("Phi-3-mini-4k-instruct")
w.add_context_length(4096)
w.add_embedding_length(3072)
w.add_block_count(32)
w.add_feed_forward_length(8192)
w.add_head_count(32)
w.add_head_count_kv(32)
w.add_layer_norm_rms_eps(1e-5)
w.add_rope_dimension_count(96)

# 2. Квантование
w.add_file_type(15) # Q4_K_M
w.add_quantization_version(2)

# 3. КРИТИЧЕСКИЕ поля токенизатора
w.add_key_value("tokenizer.ggml.model", "llama", 8) # STRING

# Простые значения без сложной обработки
w.add_bos_token_id(1)
w.add_eos_token_id(32000)
w.add_unk_token_id(0)
w.add_pad_token_id(32000)
w.add_add_bos_token(True)
w.add_add_eos_token(False)

log(" ✓ Добавлено 15 основных полей")

# ========== ПРОСТОЙ ТОКЕНИЗАТОР ==========
log("Создание простого токенизатора...")

# Создаем минимальный список токенов
# Phi-3 имеет 32064 токена, создаем простой список
simple_tokens = []
for i in range(32064):
if i == 0:
simple_tokens.append("")
elif i == 1:
simple_tokens.append("")
elif i == 32000:
simple_tokens.append("<|endoftext|>")
else:
simple_tokens.append(f"<{i}>")

w.add_token_list(simple_tokens)

# Простые scores (все нули)
simple_scores = [0.0] * 32064
w.add_token_scores(simple_scores)

# Простые token types (все нормальные токены)
simple_types = [1] * 32064 # 1 = NORMAL
simple_types[0] = 2 # UNKNOWN
simple_types[1] = 3 # CONTROL
simple_types[32000] = 3 # CONTROL

w.add_token_types(simple_types)

log(f" ✓ Создан токенизатор с {len(simple_tokens)} токенами")

# ========== ТЕНЗОРЫ ИЗ POLER ==========
log("[4/4] Добавление тензоров из POLER...")

tensor_data_list = []
tensor_names = []

for tensor in rb.tensors:
name = tensor.name
dtype = tensor.tensor_type
data = tensor.data

if data is None:
continue

# Добавляем информацию о тензоре
w.add_tensor_info(
name=name,
tensor_shape=list(data.shape),
tensor_dtype=data.dtype,
tensor_nbytes=int(data.nbytes),
raw_dtype=dtype,
)

tensor_data_list.append(data)
tensor_names.append(name)

if len(tensor_names) <= 3:
log(f" ✓ {name}: shape={data.shape}")

log(f" Всего тензоров: {len(tensor_data_list)}")

# ========== ЗАПИСЬ ФАЙЛА ==========
log("Запись GGUF файла...")

try:
w.open_output_file(output)
w.write_header_to_file()
w.write_kv_data_to_file()
w.write_ti_data_to_file()

log(f"Запись {len(tensor_data_list)} тензоров...")
for i, data in enumerate(tensor_data_list):
if i % 20 == 0:
log(f" Тензор {i+1}/{len(tensor_data_list)}")
w.write_tensor_data(data)

w.close()

# ========== ПРОВЕРКА ==========
log("\n" + "="*60)
log("✅ ФАЙЛ СОЗДАН УСПЕШНО!")

if Path(output).exists():
size_mb = Path(output).stat().st_size / (1024**2)
log(f"✅ Размер: {size_mb:.2f} MB")
log(f"✅ Тензоры: {len(tensor_data_list)}")

# Простая проверка структуры
with open(output, 'rb') as f:
magic = f.read(4)
if magic == b'GGUF':
log("✅ GGUF магия верна")

# Сохраняем отчет
report = {
"status": "success",
"output": output,
"size_mb": round(size_mb, 2),
"tensors": len(tensor_data_list),
"tensor_names": tensor_names[:10], # Первые 10
"created": datetime.now().isoformat()
}

with open("phi3_minimal_report.json", "w") as f:
json.dump(report, f, indent=2)

log(f"\n✅ Отчет: phi3_minimal_report.json")

log("\n🎉 МОДЕЛЬ ГОТОВА К ТЕСТИРОВАНИЮ!")
log(f"\nКоманда для теста:")
log(f" ~/AI/llama.cpp/build/bin/llama-cli \\")
log(f" -m {output} \\")
log(f" -n 20 \\")
log(f" -p 'Hello'")

return True
else:
log("❌ Файл не создан!")
return False

except Exception as e:
log(f"❌ Ошибка записи: {e}")
import traceback
log(traceback.format_exc())
return False

except Exception as e:
log(f"\n❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
import traceback
log(traceback.format_exc())
return False

if __name__ == "__main__":
print("="*60)
print("МИНИМАЛЬНОЕ ИСПРАВЛЕНИЕ PHI-3 МОДЕЛИ")
print("="*60)

success = create_minimal_phi3()

if success:
print("\n" + "="*60)
print("✅ МОДЕЛЬ СОЗДАНА УСПЕШНО!")
print("="*60)
else:
print("\n" + "="*60)
print("❌ ОШИБКА СОЗДАНИЯ")
print("="*60)
# --- FILE: ./problem_8.py ---

# Import the rebound module
import rebound

# Create a REBOUND simulation
sim = rebound.Simulation()

# Set variables (defaults are G=1, t=0, dt=0.01)
k = 0.01720209895 # Gaussian constant 
sim.G = k*k # Gravitational constant

# Setup particles (data taken from NASA Horizons)
# This could also be easily read in from a file.
sim.add( m=1.00000597682, x=-4.06428567034226e-3, y=-6.08813756435987e-3, z=-1.66162304225834e-6, vx=+6.69048890636161e-6, vy=-6.33922479583593e-6, vz=-3.13202145590767e-9) # Sun
sim.add( m=1./1047.355, x=+3.40546614227466e+0, y=+3.62978190075864e+0, z=+3.42386261766577e-2, vx=-5.59797969310664e-3, vy=+5.51815399480116e-3, vz=-2.66711392865591e-6) # Jupiter
sim.add( m=1./3501.6, x=+6.60801554403466e+0, y=+6.38084674585064e+0, z=-1.36145963724542e-1, vx=-4.17354020307064e-3, vy=+3.99723751748116e-3, vz=+1.67206320571441e-5) # Saturn
sim.add( m=1./22869., x=+1.11636331405597e+1, y=+1.60373479057256e+1, z=+3.61783279369958e-1, vx=-3.25884806151064e-3, vy=+2.06438412905916e-3, vz=-2.17699042180559e-5) # Uranus
sim.add( m=1./19314., x=-3.01777243405203e+1, y=+1.91155314998064e+0, z=-1.53887595621042e-1, vx=-2.17471785045538e-4, vy=-3.11361111025884e-3, vz=+3.58344705491441e-5) # Neptune
sim.add( m=0, x=-2.13858977531573e+1, y=+3.20719104739886e+1, z=+2.49245689556096e+0, vx=-1.76936577252484e-3, vy=-2.06720938381724e-3, vz=+6.58091931493844e-4) # Pluto

# Set the center of momentum to be at the origin
sim.move_to_com()

# timestep counter
steps = 0 
# Integrate until t=1e4 (unit of time in this example is days)
for i in range(10):
t = 1.0e3*i
sim.integrate(t)
# Print particle positions 
for p in sim.particles:
# time x y z 
print(sim.t, p.x, p.y, p.z)


# --- FILE: ./problem.py ---

# Import the rebound module 
import rebound

# Add particles
# We work in units where G=1. 
sim = rebound.Simulation()
sim.add(m=1. ) # Test particle
sim.add(m=1e-3,x=1.,vy=1. ) # Planet

# Move particles so that the center of mass is (and stays) at the origin 
sim.move_to_com()

# You can provide a function, written in python to REBOUND.
# This function gets called every time the forces are evaluated.
# Simple add any any additional (non-gravitational) forces to the 
# particle accelerations. Here, we add a simple drag force. This 
# will make the planet spiral into the star.
ps = sim.particles
def dragforce(reb_sim):
dragcoefficient = 1e-2
for p in ps:
p.ax += -dragcoefficient * p.vx
p.ay += -dragcoefficient * p.vy
p.az += -dragcoefficient * p.vz

# Tell rebound which function to call
sim.additional_forces = dragforce

# Integrate until t=100 (roughly 16 orbits at 1 AU) 
sim.integrate(100.)

# Output something at the end (the planet will be at ~0.1 AU)
for p in ps:
print(p.x, p.y, p.z)

# --- FILE: ./repair_fixed.py ---

#!/usr/bin/env python3
# repair_fixed.py

import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter

ORIG = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
POLER = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
OUT = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_FIXED.gguf"

print(f"=== PHI-3 REPAIR (FIXED VERSION) ===")
print(f"Original: {ORIG}")
print(f"Poler: {POLER}")
print(f"Output: {OUT}")

ra = GGUFReader(ORIG)
rb = GGUFReader(POLER)

w = GGUFWriter(OUT, "phi3")

# ---------- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ----------
def _extract_scalar(v):
if isinstance(v, (list, np.ndarray, np.memmap)):
if len(v) == 1:
return v[0]
else:
return v[0]
return v

def _to_str(v):
if isinstance(v, (np.ndarray, np.memmap)):
if v.dtype == np.uint8:
try:
if v.size == 1:
return chr(int(v[0]))
else:
return bytes(v.tolist()).decode('utf-8', errors='ignore')
except:
return str(v.tolist())
else:
if v.size == 1:
return str(v.item())
else:
return str(v.tolist())

if isinstance(v, (bytes, bytearray)):
try:
return v.decode('utf-8', errors='ignore')
except:
return str(v)

return str(v)

def _to_int(v):
v = _extract_scalar(v)

if isinstance(v, (np.integer,)):
return int(v)

if isinstance(v, (np.ndarray, np.memmap)):
if v.size == 1:
return int(v.reshape(-1)[0])

return int(v)

def _to_float(v):
v = _extract_scalar(v)

if isinstance(v, (np.floating,)):
return float(v)

if isinstance(v, (np.ndarray, np.memmap)):
if v.size == 1:
return float(v.reshape(-1)[0])

return float(v)

# ---------- ПРОЦЕСС ВОССТАНОВЛЕНИЯ ----------
print("\n[1/6] Copying metadata from original...")

# Копируем ВСЕ поля из оригинала (кроме тензоров)
for key, field in ra.fields.items():
# Пропускаем тензоры
if any(x in key for x in ['tensor', 'weight', 'bias']):
continue

values = field[2]
types = field[3]

# Для скалярных значений
if len(values) == 1:
value = values[0]

# Определяем тип для GGUFWriter
if isinstance(value, (int, np.integer)):
w.add_key_value(key, _to_int(value), 3) # TYPE_UINT32
elif isinstance(value, (float, np.floating)):
w.add_key_value(key, _to_float(value), 1) # TYPE_FLOAT32
elif isinstance(value, (str, bytes, np.bytes_)):
w.add_key_value(key, _to_str(value), 4) # TYPE_STRING
elif isinstance(value, bool):
w.add_key_value(key, bool(value), 8) # TYPE_BOOL
else:
print(f" Skipping {key}: unknown type {type(value)}")
else:
# Для массивов
w.add_key_value(key, values, types[0])

print("[2/6] Processing tokenizer arrays...")

# Токены нужно обработать отдельно
tokens_raw = ra.get_field("tokenizer.ggml.tokens")[2]
scores_raw = ra.get_field("tokenizer.ggml.scores")[2]
ttypes_raw = ra.get_field("tokenizer.ggml.token_type")[2]

# Конвертируем токены в строки
tokens = []
for token in tokens_raw:
tokens.append(_to_str(token))

# Конвертируем scores и token_types
scores = []
for score in scores_raw:
scores.append(_to_float(score))

ttypes = []
for ttype in ttypes_raw:
ttypes.append(_to_int(ttype))

w.add_token_list(tokens)
w.add_token_scores(scores)
w.add_token_types(ttypes)

print(f" Tokens: {len(tokens)}, Scores: {len(scores)}, Token types: {len(ttypes)}")

print("[3/6] Copying tensors from POLER model...")

# Копируем тензоры из POLER модели
tensor_payloads = []
tensor_count = 0

for t in rb.tensors:
name = t[0]
qtype = t[1] # GGMLQuantizationType
data = t[2] # numpy.memmap

# Используем реальную форму данных
real_shape = list(data.shape)

# Проверяем форму (для отладки)
if len(real_shape) > 4:
print(f" ⚠️ Tensor {name}: {len(real_shape)}D -> {real_shape}")
# Ограничиваем 4 измерениями
real_shape = real_shape[:4]

# Добавляем информацию о тензоре
w.add_tensor_info(
name=name,
tensor_shape=real_shape,
tensor_dtype=data.dtype,
tensor_nbytes=int(data.nbytes),
raw_dtype=qtype,
)

tensor_payloads.append(data)
tensor_count += 1

if tensor_count <= 3:
print(f" {name}: shape={real_shape}, dtype={data.dtype}")

print(f" Total tensors: {tensor_count}")

print("[4/6] Writing GGUF file...")

try:
w.open_output_file(Path(OUT))
print(" Writing header...")
w.write_header_to_file()

print(" Writing KV data...")
w.write_kv_data_to_file()

print(" Writing TI data...")
w.write_ti_data_to_file()

print(" Writing tensor data...")
for i, data in enumerate(tensor_payloads):
if i % 20 == 0 or i == len(tensor_payloads) - 1:
print(f" Tensor {i+1}/{len(tensor_payloads)}")
w.write_tensor_data(data)

w.close()

print("\n✅ REPAIR COMPLETED SUCCESSFULLY!")
print(f"✅ Output file: {OUT}")

# Проверяем размер файла
if Path(OUT).exists():
size_mb = Path(OUT).stat().st_size / (1024 * 1024)
print(f"✅ File size: {size_mb:.2f} MB")

print("\nTo test:")
print(f" cd ~/AI")
print(f" ~/AI/llama.cpp/build/bin/llama-cli \\")
print(f" -m {OUT} \\")
print(f" -n 10 \\")
print(f" -p 'Hello'")

except Exception as e:
print(f"\n❌ ERROR: {e}")
import traceback
traceback.print_exc()

print("\n=== DONE ===")
# --- FILE: ./repair_fixed_v2.py ---

#!/usr/bin/env python3
# repair_fixed_v2_with_log.py

import sys
import io
import datetime
import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter
from gguf.constants import GGUFValueType

# =========================================================
# IN-MEMORY LOGGING (MODE A)
# =========================================================
LOG_FILE = f"repair_log_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

_log_buffer = io.StringIO()
_real_stdout = sys.stdout
_real_stderr = sys.stderr

class MemoryTee:
def __init__(self, *streams):
self.streams = streams

def write(self, data):
for s in self.streams:
s.write(data)

def flush(self):
for s in self.streams:
s.flush()

sys.stdout = MemoryTee(_real_stdout, _log_buffer)
sys.stderr = MemoryTee(_real_stderr, _log_buffer)

print(f"📄 Full log will be saved at the end to: {LOG_FILE}")

# =========================================================
# FILES
# =========================================================
ORIG = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
POLER = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
OUT = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_FIXED.gguf"

print("=== PHI-3 REPAIR (FIXED VERSION v2 + FULL LOG) ===")
print(f"Original: {ORIG}")
print(f"Poler: {POLER}")
print(f"Output: {OUT}")

ra = GGUFReader(ORIG)
rb = GGUFReader(POLER)
w = GGUFWriter(OUT, "phi3")

# =========================================================
# HELPERS
# =========================================================
def _extract_scalar(v):
if isinstance(v, (list, np.ndarray, np.memmap)):
return v[0]
return v

def _to_str(v):
if isinstance(v, (np.ndarray, np.memmap)):
if v.dtype == np.uint8:
try:
return bytes(v.tolist()).decode("utf-8", errors="ignore")
except:
return str(v.tolist())
return str(v.tolist() if v.size > 1 else v.item())
if isinstance(v, (bytes, bytearray)):
return v.decode("utf-8", errors="ignore")
return str(v)

def _to_int(v):
v = _extract_scalar(v)
return int(v)

def _to_float(v):
v = _extract_scalar(v)
return float(v)

def _get_gguf_type(value):
if isinstance(value, (int, np.integer)):
return GGUFValueType.UINT32
if isinstance(value, (float, np.floating)):
return GGUFValueType.FLOAT32
if isinstance(value, (str, bytes, np.bytes_)):
return GGUFValueType.STRING
if isinstance(value, bool):
return GGUFValueType.BOOL
if isinstance(value, list) and value:
return _get_gguf_type(value[0])
return GGUFValueType.UINT32

# =========================================================
# [1/6] METADATA
# =========================================================
print("\n[1/6] Copying metadata from original...")

w.add_name("Phi-3-mini-4k-instruct")
w.add_context_length(_to_int(ra.get_field("phi3.context_length")[2][0]))
w.add_embedding_length(_to_int(ra.get_field("phi3.embedding_length")[2][0]))
w.add_feed_forward_length(_to_int(ra.get_field("phi3.feed_forward_length")[2][0]))
w.add_block_count(_to_int(ra.get_field("phi3.block_count")[2][0]))
w.add_head_count(_to_int(ra.get_field("phi3.attention.head_count")[2][0]))
w.add_head_count_kv(_to_int(ra.get_field("phi3.attention.head_count_kv")[2][0]))
w.add_layer_norm_rms_eps(
_to_float(ra.get_field("phi3.attention.layer_norm_rms_epsilon")[2][0])
)
w.add_rope_dimension_count(
_to_int(ra.get_field("phi3.rope.dimension_count")[2][0])
)

kv_count = 0
for key, field in ra.fields.items():
if any(x in key for x in ("tensor", "weight", "bias")):
continue
if key.startswith("phi3.") and any(
key.endswith(x) for x in (
"context_length", "embedding_length", "feed_forward_length",
"block_count", "head_count", "head_count_kv",
"layer_norm_rms_epsilon", "dimension_count"
)
):
continue

values = field[2]
types = field[3]

try:
if len(values) == 1:
v = values[0]
if isinstance(v, (np.ndarray, np.memmap)):
v = _to_str(v) if v.dtype == np.uint8 else v.item()
w.add_key_value(key, v, _get_gguf_type(v))
else:
w.add_key_value(key, values.tolist(), types[0])
kv_count += 1
except Exception as e:
print(f" ⚠️ Skip KV {key}: {e}")

print(f" Added KV pairs: {kv_count}")

# =========================================================
# [2/6] TOKENIZER
# =========================================================
print("[2/6] Processing tokenizer...")

tokens = [_to_str(t) for t in ra.get_field("tokenizer.ggml.tokens")[2]]
scores = [_to_float(s) for s in ra.get_field("tokenizer.ggml.scores")[2]]
ttypes = [_to_int(t) for t in ra.get_field("tokenizer.ggml.token_type")[2]]

w.add_token_list(tokens)
w.add_token_scores(scores)
w.add_token_types(ttypes)

w.add_bos_token_id(_to_int(ra.get_field("tokenizer.ggml.bos_token_id")[2][0]))
w.add_eos_token_id(_to_int(ra.get_field("tokenizer.ggml.eos_token_id")[2][0]))
w.add_pad_token_id(_to_int(ra.get_field("tokenizer.ggml.padding_token_id")[2][0]))
w.add_unk_token_id(_to_int(ra.get_field("tokenizer.ggml.unknown_token_id")[2][0]))
w.add_add_bos_token(bool(ra.get_field("tokenizer.ggml.add_bos_token")[2][0]))
w.add_add_eos_token(bool(ra.get_field("tokenizer.ggml.add_eos_token")[2][0]))

print(f" Tokens: {len(tokens)}")

# =========================================================
# [3/6] QUANTIZATION
# =========================================================
print("[3/6] Adding quantization info...")
w.add_file_type(_to_int(ra.get_field("general.file_type")[2][0]))
w.add_quantization_version(
_to_int(ra.get_field("general.quantization_version")[2][0])
)

# =========================================================
# [4/6] TENSORS
# =========================================================
print("[4/6] Copying tensors from POLER model...")

tensor_payloads = []
for i, (name, qtype, data) in enumerate(rb.tensors):
shape = list(data.shape)[:4]
w.add_tensor_info(
name=name,
tensor_shape=shape,
tensor_dtype=data.dtype,
tensor_nbytes=int(data.nbytes),
raw_dtype=qtype,
)
tensor_payloads.append(data)
if i < 3:
print(f" {name}: shape={shape}, dtype={data.dtype}")

print(f" Total tensors: {len(tensor_payloads)}")

# =========================================================
# [5/6][6/6] WRITE
# =========================================================
print("[5/6] Writing GGUF file...")
try:
w.open_output_file(Path(OUT))
w.write_header_to_file()
w.write_kv_data_to_file()
w.write_ti_data_to_file()

print("[6/6] Writing tensor data...")
for i, data in enumerate(tensor_payloads):
if i % 20 == 0 or i == len(tensor_payloads) - 1:
print(f" Tensor {i+1}/{len(tensor_payloads)}")
w.write_tensor_data(data)

w.close()
print("✅ REPAIR COMPLETED SUCCESSFULLY")

except Exception as e:
print("❌ ERROR OCCURRED")
import traceback
traceback.print_exc()

print("=== DONE ===")

# =========================================================
# SAVE FULL LOG (ONE FILE)
# =========================================================
sys.stdout = _real_stdout
sys.stderr = _real_stderr

with open(LOG_FILE, "w", encoding="utf-8") as f:
f.write(_log_buffer.getvalue())

print(f"📄 Full log saved to {LOG_FILE}")

# --- FILE: ./repair_phi3_corrected.py ---

[вставьте код выше]

# --- FILE: ./repair_phi3_final.py ---

#!/usr/bin/env python3
# repair_phi3_final.py - ФИНАЛЬНАЯ ВЕРСИЯ

import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter
from gguf.constants import GGUFValueType
import json
from datetime import datetime

class Phi3Repair:
def __init__(self):
self.orig = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
self.poler = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
self.output = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_FINAL.gguf"

self.log_file = f"repair_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
self.errors = []

def log(self, message):
timestamp = datetime.now().strftime("%H:%M:%S")
print(f"[{timestamp}] {message}")
with open(self.log_file, 'a') as f:
f.write(f"[{timestamp}] {message}\n")

def convert_value(self, value):
"""Конвертируем numpy/memmap значения в Python типы"""
if isinstance(value, (np.ndarray, np.memmap)):
if value.dtype == np.uint8:
try:
# Строковые значения
if value.ndim == 1:
return bytes(value).decode('utf-8', errors='ignore')
elif value.ndim == 0:
return chr(int(value))
except:
return str(value.tolist())
elif value.size == 1:
# Скалярные значения
return value.item()
else:
# Массивы
return value.tolist()
elif isinstance(value, (bytes, bytearray)):
try:
return value.decode('utf-8', errors='ignore')
except:
return str(value)
elif isinstance(value, list) and len(value) == 1:
return self.convert_value(value[0])

return value

def get_field_value(self, reader, field_name, default=None):
"""Безопасно получаем значение поля"""
try:
field = reader.get_field(field_name)
if field and len(field) >= 3:
value = field[2]
return self.convert_value(value)
except Exception as e:
self.log(f"⚠️ Cannot get field {field_name}: {e}")

return default

def repair(self):
self.log("="*60)
self.log("PHI-3 REPAIR - FINAL VERSION")
self.log(f"Original: {self.orig}")
self.log(f"Poler: {self.poler}")
self.log(f"Output: {self.output}")
self.log("="*60)

# Проверяем файлы
if not Path(self.orig).exists():
self.log(f"❌ Original file not found: {self.orig}")
return False

if not Path(self.poler).exists():
self.log(f"❌ Poler file not found: {self.poler}")
return False

try:
# Читаем модели
self.log("[1/5] Reading original model...")
ra = GGUFReader(self.orig)

self.log("[2/5] Reading POLER model...")
rb = GGUFReader(self.poler)

# Создаем writer
self.log("[3/5] Creating output GGUF file...")
w = GGUFWriter(self.output, "phi3")

# ========== КОПИРУЕМ МЕТАДАННЫЕ ==========
self.log("[4/5] Copying metadata...")

# Список уже добавленных полей (чтобы избежать дублирования)
added_fields = set()

# Добавляем обязательные поля по одному
required_fields = [
("general.name", "Phi-3-mini-4k-instruct"),
("general.file_type", 17),
("general.quantization_version", 2),
("phi3.context_length", 4096),
("phi3.embedding_length", 3072),
("phi3.block_count", 32),
("phi3.feed_forward_length", 8192),
("phi3.attention.head_count", 32),
("phi3.attention.head_count_kv", 32),
("phi3.attention.layer_norm_rms_epsilon", 1e-5),
("phi3.rope.dimension_count", 128),
("phi3.rope.freq_base", 10000.0),
]

for field_name, default in required_fields:
value = self.get_field_value(ra, field_name, default)
if value is not None:
# Определяем тип
if isinstance(value, (int, np.integer)):
vtype = GGUFValueType.UINT32
elif isinstance(value, (float, np.floating)):
vtype = GGUFValueType.FLOAT32
elif isinstance(value, str):
vtype = GGUFValueType.STRING
elif isinstance(value, bool):
vtype = GGUFValueType.BOOL
else:
vtype = GGUFValueType.UINT32

try:
w.add_key_value(field_name, value, vtype)
added_fields.add(field_name)
self.log(f" ✓ {field_name} = {value}")
except Exception as e:
self.log(f" ⚠️ Failed to add {field_name}: {e}")

# Копируем остальные поля из оригинала
kv_count = 0
for key in ra.fields.keys():
# Пропускаем уже добавленные и тензоры
if key in added_fields or 'tensor' in key:
continue

try:
field = ra.get_field(key)
if field and len(field) >= 3:
value = field[2]
vtype = field[3][0] if field[3] else GGUFValueType.UINT32

# Конвертируем значение
converted = self.convert_value(value)

# Добавляем поле
w.add_key_value(key, converted, vtype)
kv_count += 1

if kv_count % 20 == 0:
self.log(f" Added {kv_count} fields...")
except Exception as e:
self.log(f" ⚠️ Skipping {key}: {e}")

self.log(f" Total metadata fields: {len(added_fields) + kv_count}")

# ========== ТОКЕНИЗАТОР ==========
self.log("Adding tokenizer...")

# Токены
tokens = []
tokens_value = self.get_field_value(ra, "tokenizer.ggml.tokens")
if tokens_value and isinstance(tokens_value, list):
for token in tokens_value:
tokens.append(self.convert_value(token))
elif tokens_value:
tokens.append(self.convert_value(tokens_value))

# Scores
scores = []
scores_value = self.get_field_value(ra, "tokenizer.ggml.scores")
if scores_value:
if isinstance(scores_value, list):
scores = [float(self.convert_value(s)) for s in scores_value]
else:
scores = [float(self.convert_value(scores_value))]

# Token types
token_types = []
ttypes_value = self.get_field_value(ra, "tokenizer.ggml.token_type")
if ttypes_value:
if isinstance(ttypes_value, list):
token_types = [int(self.convert_value(t)) for t in ttypes_value]
else:
token_types = [int(self.convert_value(ttypes_value))]

if tokens:
w.add_token_list(tokens)
if scores:
w.add_token_scores(scores)
if token_types:
w.add_token_types(token_types)

self.log(f" Tokens: {len(tokens)}")

# Token IDs
bos_id = self.get_field_value(ra, "tokenizer.ggml.bos_token_id", 27)
eos_id = self.get_field_value(ra, "tokenizer.ggml.eos_token_id", 27)
pad_id = self.get_field_value(ra, "tokenizer.ggml.padding_token_id", 31)
unk_id = self.get_field_value(ra, "tokenizer.ggml.unknown_token_id", 31)

w.add_bos_token_id(int(bos_id))
w.add_eos_token_id(int(eos_id))
w.add_pad_token_id(int(pad_id))
w.add_unk_token_id(int(unk_id))

# Flags
add_bos = self.get_field_value(ra, "tokenizer.ggml.add_bos_token", True)
add_eos = self.get_field_value(ra, "tokenizer.ggml.add_eos_token", True)
w.add_add_bos_token(bool(add_bos))
w.add_add_eos_token(bool(add_eos))

# ========== ТЕНЗОРЫ ==========
self.log("[5/5] Copying tensors from POLER model...")

tensor_count = 0
tensor_shapes = []

# Новый формат GGUFReader возвращает объекты Tensor
for tensor in rb.tensors:
name = tensor.name
dtype = tensor.tensor_type # Тип квантования
data = tensor.data # numpy массив

# Используем РЕАЛЬНУЮ форму данных
real_shape = list(data.shape) if data is not None else []

# Исправляем проблемные формы
if len(real_shape) > 4:
self.log(f" 🔧 Fixing {name}: {len(real_shape)}D -> {real_shape[:4]}")
real_shape = real_shape[:4]

# Добавляем тензор
w.add_tensor(
name=name,
tensor=data,
raw_shape=real_shape,
raw_dtype=dtype
)

tensor_count += 1
tensor_shapes.append((name, real_shape))

if tensor_count <= 5:
self.log(f" {name}: shape={real_shape}, dtype={data.dtype if data is not None else 'None'}")
elif tensor_count % 50 == 0:
self.log(f" Processed {tensor_count} tensors...")

self.log(f" Total tensors: {tensor_count}")

# ========== ЗАПИСЬ ФАЙЛА ==========
self.log("Writing GGUF file...")

w.write()
w.close()

# Проверяем результат
self.log("\n" + "="*60)
self.log("✅ REPAIR COMPLETED SUCCESSFULLY!")
self.log(f"✅ Output file: {self.output}")

if Path(self.output).exists():
size_mb = Path(self.output).stat().st_size / (1024 * 1024)
self.log(f"✅ File size: {size_mb:.2f} MB")

# Быстрая проверка
try:
test_reader = GGUFReader(self.output)
self.log(f"✅ Architecture: {test_reader.architecture}")
self.log(f"✅ Tensors: {len(test_reader.tensors)}")
self.log(f"✅ Has tokenizer: 'tokenizer.ggml.tokens' in fields")

# Сохраняем отчет о тензорах
report = {
"repair_date": datetime.now().isoformat(),
"original_model": self.orig,
"poler_model": self.poler,
"output_model": self.output,
"tensor_count": tensor_count,
"file_size_mb": size_mb,
"tensor_shapes": [{"name": name, "shape": shape} for name, shape in tensor_shapes[:20]],
"metadata_fields": len(added_fields) + kv_count
}

with open("repair_report.json", "w") as f:
json.dump(report, f, indent=2)

self.log(f"✅ Report saved to: repair_report.json")

except Exception as e:
self.log(f"⚠️ Quick test failed: {e}")

self.log("\n" + "="*60)
self.log("🎉 МОДЕЛЬ ГОТОВА К ТЕСТИРОВАНИЮ!")
self.log("\nКоманда для теста:")
self.log(f" ~/AI/llama.cpp/build/bin/llama-cli \\")
self.log(f" -m {self.output} \\")
self.log(f" -n 100 \\")
self.log(f" -p 'Hello, tell me about quantum computing'")
self.log("="*60)

return True

except Exception as e:
self.log(f"\n❌ CRITICAL ERROR: {e}")
import traceback
error_details = traceback.format_exc()
self.log(error_details)
with open("repair_error.log", "w") as f:
f.write(error_details)

return False

if __name__ == "__main__":
repair = Phi3Repair()
success = repair.repair()

if success:
print("\n✅ Восстановление завершено успешно!")
print(f"📋 Лог сохранен в: {repair.log_file}")
else:
print("\n❌ Восстановление не удалось")
print(f"📋 Лог ошибок в: {repair.log_file}")
print("Проверьте файл repair_error.log для деталей")
# --- FILE: ./repair_phi3_proper.py ---

#!/usr/bin/env python3
# repair_phi3_proper.py - ПРАВИЛЬНОЕ ВОССТАНОВЛЕНИЕ

import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter
from gguf.constants import GGUFValueType
import json
from datetime import datetime
import struct

class Phi3ProperRepair:
def __init__(self):
self.orig = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
self.poler = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
self.output = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_PROPER.gguf"

self.log_file = f"repair_proper_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

def log(self, message):
timestamp = datetime.now().strftime("%H:%M:%S")
print(f"[{timestamp}] {message}")
with open(self.log_file, 'a') as f:
f.write(f"[{timestamp}] {message}\n")

def get_simple_value(self, reader, field_name, default=None):
"""Простое получение значения поля"""
try:
if field_name in reader.fields:
field = reader.fields[field_name]
if len(field) >= 3:
value = field[2]

# Если это массив с одним элементом
if isinstance(value, (np.ndarray, np.memmap)):
if value.size == 1:
return value.item()
elif value.dtype == np.uint8:
try:
return bytes(value).decode('utf-8', errors='ignore')
except:
return str(value)
# Если это список
elif isinstance(value, (list, tuple)) and len(value) == 1:
return value[0]

return value
except Exception as e:
self.log(f"⚠️ Cannot get {field_name}: {e}")

return default

def repair(self):
self.log("="*60)
self.log("PHI-3 PROPER REPAIR")
self.log(f"Original: {self.orig}")
self.log(f"Poler: {self.poler}")
self.log(f"Output: {self.output}")
self.log("="*60)

try:
# 1. Читаем оригинал только для метаданных
self.log("[1/5] Reading original model...")
ra = GGUFReader(self.orig)

# 2. Читаем POLER только для ТЕНЗОРОВ
self.log("[2/5] Reading POLER model...")
rb = GGUFReader(self.poler)

# Проверяем тензоры POLER
self.log(f" POLER has {len(rb.tensors)} tensors")
if len(rb.tensors) > 0:
t = rb.tensors[0]
self.log(f" First tensor: {t.name}, shape={t.data.shape}, dtype={t.data.dtype}")

# 3. Создаем writer
self.log("[3/5] Creating output...")
w = GGUFWriter(self.output, "phi3")

# ========== МИНИМАЛЬНЫЕ МЕТАДАННЫЕ ==========
self.log("[4/5] Adding minimal metadata...")

# ТОЛЬКО самые необходимые поля
metadata = {
"general.name": "Phi-3-mini-4k-instruct",
"general.file_type": 17,
"general.quantization_version": 2,
"general.architecture": "phi3",
"phi3.context_length": 4096,
"phi3.embedding_length": 3072,
"phi3.block_count": 32,
"phi3.feed_forward_length": 8192,
"phi3.attention.head_count": 32,
"phi3.attention.head_count_kv": 32,
"phi3.attention.layer_norm_rms_epsilon": 1e-5,
"phi3.rope.dimension_count": 128,
"phi3.rope.freq_base": 10000.0,
}

for key, default in metadata.items():
value = self.get_simple_value(ra, key, default)

# Определяем тип
if isinstance(value, (int, np.integer)):
vtype = GGUFValueType.UINT32
try:
w.add_key_value(key, int(value), vtype)
self.log(f" ✓ {key} = {int(value)}")
except Exception as e:
self.log(f" ⚠️ {key}: {e}")

elif isinstance(value, (float, np.floating)):
vtype = GGUFValueType.FLOAT32
try:
w.add_key_value(key, float(value), vtype)
self.log(f" ✓ {key} = {float(value)}")
except Exception as e:
self.log(f" ⚠️ {key}: {e}")

elif isinstance(value, str):
vtype = GGUFValueType.STRING
try:
w.add_key_value(key, str(value), vtype)
self.log(f" ✓ {key} = '{str(value)}'")
except Exception as e:
self.log(f" ⚠️ {key}: {e}")

elif isinstance(value, bool):
vtype = GGUFValueType.BOOL
try:
w.add_key_value(key, bool(value), vtype)
self.log(f" ✓ {key} = {bool(value)}")
except Exception as e:
self.log(f" ⚠️ {key}: {e}")

# ========== ТОКЕНИЗАТОР ==========
self.log("Adding tokenizer...")

# Простое добавление токенизатора
try:
# Токены
tokens = []
if "tokenizer.ggml.tokens" in ra.fields:
tokens_data = ra.fields["tokenizer.ggml.tokens"][2]
for token in tokens_data:
if isinstance(token, (np.ndarray, np.memmap)) and token.dtype == np.uint8:
try:
tokens.append(bytes(token).decode('utf-8', errors='ignore'))
except:
tokens.append(str(token))
else:
tokens.append(str(token))

if tokens:
w.add_token_list(tokens)
self.log(f" ✓ Tokens: {len(tokens)}")

# Token IDs
bos_id = self.get_simple_value(ra, "tokenizer.ggml.bos_token_id", 27)
eos_id = self.get_simple_value(ra, "tokenizer.ggml.eos_token_id", 27)
pad_id = self.get_simple_value(ra, "tokenizer.ggml.padding_token_id", 31)
unk_id = self.get_simple_value(ra, "tokenizer.ggml.unknown_token_id", 31)

w.add_bos_token_id(int(bos_id))
w.add_eos_token_id(int(eos_id))
w.add_pad_token_id(int(pad_id))
w.add_unk_token_id(int(unk_id))

# Flags
add_bos = self.get_simple_value(ra, "tokenizer.ggml.add_bos_token", True)
add_eos = self.get_simple_value(ra, "tokenizer.ggml.add_eos_token", True)

w.add_add_bos_token(bool(add_bos))
w.add_add_eos_token(bool(add_eos))

except Exception as e:
self.log(f"⚠️ Tokenizer error: {e}")

# ========== ТЕНЗОРЫ ИЗ POLER ==========
self.log("[5/5] Adding tensors from POLER...")

tensor_count = 0
for tensor in rb.tensors:
name = tensor.name
dtype = tensor.tensor_type
data = tensor.data

if data is None:
self.log(f" ⚠️ {name}: No data, skipping")
continue

# ИСПОЛЬЗУЕМ РЕАЛЬНУЮ ФОРМУ ИЗ ДАННЫХ!
real_shape = list(data.shape)

try:
# ВАЖНО: используем add_tensor вместо add_tensor_info
w.add_tensor(
name=name,
tensor=data,
raw_shape=real_shape,
raw_dtype=dtype
)

tensor_count += 1

if tensor_count <= 3:
self.log(f" ✓ {name}: shape={real_shape}, dtype={data.dtype}")

except Exception as e:
self.log(f" ❌ {name}: Failed - {e}")

self.log(f" Total tensors added: {tensor_count}")

# ========== ЗАПИСЬ ==========
self.log("Writing GGUF file...")

try:
w.write()
w.close()

self.log("\n" + "="*60)
self.log("✅ SUCCESS!")

if Path(self.output).exists():
size_mb = Path(self.output).stat().st_size / (1024 * 1024)
self.log(f"✅ File: {self.output}")
self.log(f"✅ Size: {size_mb:.2f} MB")
self.log(f"✅ Tensors: {tensor_count}")

# Сохраняем отчет
report = {
"success": True,
"output": self.output,
"size_mb": size_mb,
"tensors": tensor_count,
"timestamp": datetime.now().isoformat()
}

with open("repair_success.json", "w") as f:
json.dump(report, f, indent=2)

self.log("\n🎉 МОДЕЛЬ ВОССТАНОВЛЕНА!")
self.log(f"\nТестирование:")
self.log(f" ~/AI/llama.cpp/build/bin/llama-cli \\")
self.log(f" -m {self.output} \\")
self.log(f" -n 50 \\")
self.log(f" -p 'Hello'")

else:
self.log("❌ Output file not created!")

except Exception as e:
self.log(f"\n❌ Write failed: {e}")
import traceback
self.log(traceback.format_exc())

return True

except Exception as e:
self.log(f"\n❌ CRITICAL: {e}")
import traceback
self.log(traceback.format_exc())
return False

def main():
repair = Phi3ProperRepair()
success = repair.repair()

if success:
print("\n" + "="*60)
print("✅ Восстановление завершено!")
print(f"📋 Лог: {repair.log_file}")
print("="*60)
else:
print("\n" + "="*60)
print("❌ Ошибка восстановления")
print(f"📋 Лог: {repair.log_file}")
print("="*60)

if __name__ == "__main__":
main()
# --- FILE: ./repair_phi3_working.py ---

#!/usr/bin/env python3
# repair_phi3_working.py - РАБОЧАЯ ВЕРСИЯ

import numpy as np
from pathlib import Path
from gguf import GGUFReader, GGUFWriter
from gguf.constants import GGUFValueType
import json
from datetime import datetime

class Phi3WorkingRepair:
def __init__(self):
self.orig = "Phi-3-mini-4k-instruct-Q4_K_M.gguf"
self.poler = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_MAX.gguf"
self.output = "Phi-3-mini-4k-instruct-Q4_K_M_POLER_REPAIRED_WORKING.gguf"

self.log_file = f"repair_working_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

def log(self, message):
timestamp = datetime.now().strftime("%H:%M:%S")
print(f"[{timestamp}] {message}")
with open(self.log_file, 'a') as f:
f.write(f"[{timestamp}] {message}\n")

def get_field_value(self, reader, field_name, default=None):
"""Правильное получение значения поля"""
try:
if field_name in reader.fields:
field = reader.fields[field_name]
if len(field) >= 3:
value = field[2]

# Если это массив
if isinstance(value, (np.ndarray, np.memmap)):
if value.size == 1:
# Скаляр
return value.item()
elif value.dtype == np.uint8:
# Строка
try:
return bytes(value).decode('utf-8', errors='ignore')
except:
return str(value.tolist())
else:
# Числовой массив
if value.size > 1:
# Возвращаем первый элемент если это список чисел
return value[0] if len(value) > 0 else default
elif isinstance(value, (list, tuple)):
# Уже список
if len(value) == 1:
return value[0]
elif len(value) > 0:
return value[0] # Первый элемент

return value
except Exception as e:
self.log(f"⚠️ Cannot get {field_name}: {e}")

return default

def repair(self):
self.log("="*60)
self.log("PHI-3 WORKING REPAIR")
self.log(f"Original: {self.orig}")
self.log(f"Poler: {self.poler}")
self.log(f"Output: {self.output}")
self.log("="*60)

try:
# 1. Читаем оригинал
self.log("[1/5] Reading original model...")
ra = GGUFReader(self.orig)

# 2. Читаем POLER
self.log("[2/5] Reading POLER model...")
rb = GGUFReader(self.poler)

self.log(f" POLER tensors: {len(rb.tensors)}")

# 3. Создаем writer
self.log("[3/5] Creating output...")
w = GGUFWriter(self.output, "phi3")

# ========== МЕТАДАННЫЕ ==========
self.log("[4/5] Adding metadata...")

# Минимальный набор полей
metadata_pairs = [
("general.name", "Phi-3-mini-4k-instruct", GGUFValueType.STRING),
("general.file_type", 17, GGUFValueType.UINT32),
("general.quantization_version", 2, GGUFValueType.UINT32),
("phi3.context_length", 4096, GGUFValueType.UINT32),
("phi3.embedding_length", 3072, GGUFValueType.UINT32),
("phi3.block_count", 32, GGUFValueType.UINT32),
("phi3.feed_forward_length", 8192, GGUFValueType.UINT32),
("phi3.attention.head_count", 32, GGUFValueType.UINT32),
("phi3.attention.head_count_kv", 32, GGUFValueType.UINT32),
("phi3.attention.layer_norm_rms_epsilon", 1e-5, GGUFValueType.FLOAT32),
("phi3.rope.dimension_count", 128, GGUFValueType.UINT32),
("phi3.rope.freq_base", 10000.0, GGUFValueType.FLOAT32),
]

for key, default, vtype in metadata_pairs:
value = self.get_field_value(ra, key, default)
try:
if vtype == GGUFValueType.UINT32:
w.add_key_value(key, int(value), vtype)
elif vtype == GGUFValueType.FLOAT32:
w.add_key_value(key, float(value), vtype)
elif vtype == GGUFValueType.STRING:
w.add_key_value(key, str(value), vtype)
else:
w.add_key_value(key, value, vtype)

self.log(f" ✓ {key} = {value}")
except Exception as e:
self.log(f" ⚠️ {key}: {e}")

# ========== ТОКЕНИЗАТОР ==========
self.log("Adding tokenizer...")

try:
# Токены
tokens = []
if "tokenizer.ggml.tokens" in ra.fields:
tokens_field = ra.fields["tokenizer.ggml.tokens"]
if len(tokens_field) >= 3:
tokens_data = tokens_field[2]
for token in tokens_data:
if isinstance(token, (np.ndarray, np.memmap)):
if token.dtype == np.uint8:
try:
tokens.append(bytes(token).decode('utf-8', errors='ignore'))
except:
tokens.append(str(token))
else:
tokens.append(str(token))
else:
tokens.append(str(token))

if tokens:
w.add_token_list(tokens)
self.log(f" ✓ Tokens: {len(tokens)}")

# Token IDs - безопасное получение
bos_id = self.get_field_value(ra, "tokenizer.ggml.bos_token_id")
eos_id = self.get_field_value(ra, "tokenizer.ggml.eos_token_id")
pad_id = self.get_field_value(ra, "tokenizer.ggml.padding_token_id")
unk_id = self.get_field_value(ra, "tokenizer.ggml.unknown_token_id")

# Значения по умолчанию если None
bos_id = int(bos_id) if bos_id is not None else 27
eos_id = int(eos_id) if eos_id is not None else 27
pad_id = int(pad_id) if pad_id is not None else 31
unk_id = int(unk_id) if unk_id is not None else 31

w.add_bos_token_id(bos_id)
w.add_eos_token_id(eos_id)
w.add_pad_token_id(pad_id)
w.add_unk_token_id(unk_id)

# Flags
add_bos = self.get_field_value(ra, "tokenizer.ggml.add_bos_token")
add_eos = self.get_field_value(ra, "tokenizer.ggml.add_eos_token")

add_bos = bool(add_bos) if add_bos is not None else True
add_eos = bool(add_eos) if add_eos is not None else True

w.add_add_bos_token(add_bos)
w.add_add_eos_token(add_eos)

except Exception as e:
self.log(f"⚠️ Tokenizer error: {e}")
import traceback
self.log(traceback.format_exc())

# ========== ТЕНЗОРЫ ==========
self.log("[5/5] Adding tensors from POLER...")

tensor_count = 0
tensor_data_list = [] # Будем хранить данные для записи

for tensor in rb.tensors:
name = tensor.name
dtype = tensor.tensor_type
data = tensor.data

if data is None:
self.log(f" ⚠️ {name}: No data")
continue

# Реальная форма
real_shape = list(data.shape)

# Добавляем информацию о тензоре
w.add_tensor_info(
name=name,
tensor_shape=real_shape,
tensor_dtype=data.dtype,
tensor_nbytes=int(data.nbytes),
raw_dtype=dtype,
)

# Сохраняем данные для записи
tensor_data_list.append(data)
tensor_count += 1

if tensor_count <= 3:
self.log(f" ✓ {name}: shape={real_shape}, dtype={data.dtype}")
elif tensor_count % 50 == 0:
self.log(f" Processed {tensor_count} tensors...")

self.log(f" Total tensors: {tensor_count}")

# ========== ЗАПИСЬ ФАЙЛА (СТАРЫЙ API) ==========
self.log("Writing GGUF file...")

try:
# Открываем файл для записи
w.open_output_file(self.output)

# Записываем заголовок
w.write_header_to_file()

# Записываем метаданные
w.write_kv_data_to_file()

# Записываем информацию о тензорах
w.write_ti_data_to_file()

# Записываем данные тензоров
self.log(f"Writing tensor data ({len(tensor_data_list)} tensors)...")
for i, data in enumerate(tensor_data_list):
if i % 20 == 0:
self.log(f" Tensor {i+1}/{len(tensor_data_list)}")
w.write_tensor_data(data)

w.close()

self.log("\n" + "="*60)
self.log("✅ SUCCESSFULLY CREATED GGUF FILE!")

if Path(self.output).exists():
size_mb = Path(self.output).stat().st_size / (1024 * 1024)
self.log(f"✅ File: {self.output}")
self.log(f"✅ Size: {size_mb:.2f} MB")
self.log(f"✅ Tensors: {tensor_count}")

# Проверяем структуру
try:
test_reader = GGUFReader(self.output)
self.log(f"✅ Architecture: {test_reader.architecture}")
self.log(f"✅ Fields: {len(test_reader.fields)}")
self.log(f"✅ Tensors in output: {len(test_reader.tensors)}")
except Exception as e:
self.log(f"⚠️ Test read failed: {e}")

# Сохраняем отчет
report = {
"success": True,
"output_file": self.output,
"file_size_mb": round(size_mb, 2),
"tensor_count": tensor_count,
"created_at": datetime.now().isoformat(),
"log_file": self.log_file
}

with open("repair_final_report.json", "w") as f:
json.dump(report, f, indent=2)

self.log(f"\n✅ Report saved: repair_final_report.json")

self.log("\n🎉 МОДЕЛЬ ГОТОВА К ТЕСТИРОВАНИЮ!")
self.log(f"\nКоманда для теста:")
self.log(f" ~/AI/llama.cpp/build/bin/llama-cli \\")
self.log(f" -m {self.output} \\")
self.log(f" -n 100 \\")
self.log(f" -p 'Hello, how are you?'")

else:
self.log("❌ Output file not found!")

return True

except Exception as e:
self.log(f"\n❌ Write failed: {e}")
import traceback
self.log(traceback.format_exc())
return False

except Exception as e:
self.log(f"\n❌ CRITICAL ERROR: {e}")
import traceback
self.log(traceback.format_exc())
return False

def main():
repair = Phi3WorkingRepair()
success = repair.repair()

if success:
print("\n" + "="*60)
print("✅ ВОССТАНОВЛЕНИЕ ЗАВЕРШЕНО УСПЕШНО!")
print(f"📋 Лог: {repair.log_file}")
print(f"📊 Отчет: repair_final_report.json")
print("="*60)
else:
print("\n" + "="*60)
print("❌ ОШИБКА ВОССТАНОВЛЕНИЯ")
print(f"📋 Лог ошибок: {repair.log_file}")
print("="*60)

if __name__ == "__main__":
main()
# --- FILE: ./simulation.py ---

from ctypes import Structure, c_double, POINTER, c_uint32, c_int, c_uint, c_int64, c_uint64, c_void_p, c_char_p, CFUNCTYPE, byref, create_string_buffer, addressof, c_char, c_size_t, string_at, sizeof 
from . import clibrebound, Escape, NoParticles, Encounter, Collision, GenericError 
from .citations import cite
from .units import units_convert_particle, check_units, convert_G, hash_to_unit
from .hash import hash as rebhash, HashPointerPair
from .vectors import Vec3d, Vec3dBasic, Vec6d
import os
import sys
import warnings

# Avoid unboxing strings. See
# https://sourceforge.net/p/ctypes/mailman/message/8469497/
class allocated_c_char_p(c_char_p):
pass

import types

### The following enum and class definitions need to
### consitent with those in rebound.h

INTEGRATORS = {"ias15": 0, "whfast": 1, "sei": 2, "leapfrog": 4, "none": 7, "janus": 8, "mercurius": 9, "saba": 10, "eos": 11, "bs": 12, "whfast512":21, "trace":25}
BOUNDARIES = {"none": 0, "open": 1, "periodic": 2, "shear": 3}
GRAVITIES = {"none": 0, "basic": 1, "compensated": 2, "tree": 3, "mercurius": 4, "jacobi": 5, "trace": 6}
COLLISIONS = {"none": 0, "direct": 1, "tree": 2, "line": 4, "linetree": 5}
# Format: Majorerror, id, message
BINARY_WARNINGS = [
(True, 1, "Cannot read binary file. Check filename and file contents."),
(False, 2, "Binary file was saved with a different version of REBOUND. Binary format might have changed."),
(False, 4, "You have to reset function pointers after creating a reb_simulation struct with a binary file."),
(False, 8, "Binary file might be corrupted. Number of particles found does not match particle number expected."),
(True, 16, "Error while reading binary file (file was closed).",),
(True, 32, "Index out of range.",),
(True, 64, "Error while trying to seek file.",),
(False, 128, "Encountered unknown field in file. File might have been saved with a different version of REBOUND."),
(True, 256, "Integrator type is not supported by this simulationarchive version."),
(False, 512, "The binary file seems to be corrupted. An attempt has been made to read the uncorrupted parts of it."),
(True, 1024, "Reading old Simulationarchives (version < 2) is no longer supported. If you need to read such an archive, use a REBOUND version <= 3.26.3"),
]

# Note: name conflict with exception "Collision"
class CollisionS(Structure):
_fields_ = [("p1", c_int),
("p2", c_int),
("gb", Vec6d),
("ri", c_int)]

def __repr__(self):
return '<{0}.{1} object at {2}, p1={3}, p2={4}>'.format(self.__module__, type(self).__name__, hex(id(self)), self.p1, self.p2)



class Simulation(Structure):
"""
This is the REBOUND Simulation Class.
In encapsulated an entire REBOUND simulation and is an abstraction of the C struct reb_simulation.

### Examples

Most simulation parameters can be directly changed with the property syntax:

>>> sim = rebound.Simulation()
>>> sim.G = 1. # Sets the graviational constant (default 1)
>>> sim.softening = 1. # Sets the graviational softening parameter (default 0)
>>> sim.testparticle_type = 1 # Allows massive particles to feel influence from testparticles (default 0)
>>> sim.dt = 0.1 # Sets the timestep (will change for adaptive integrators such as IAS15).
>>> sim.t = 0. # Sets the current simulation time (default 0)
>>> print(sim.N) # Gets the current number of particles
>>> print(sim.N_active) # Gets the current number of active particles

By calling rebound.Simulation() as shown above, you create a new simulation object
The following example creates a simulation, saves it to a file and then creates
a copy of the simulation stored in the binary file.

>>> sim = rebound.Simulation()
>>> sim.add(m=1.)
>>> sim.add(m=1.e-3,x=1.,vy=1.)
>>> sim.save_to_file("simulation.bin")
>>> sim_copy = rebound.Simulation("simulation.bin")

Similarly, you can create a simulation from a Simulationarchive
by specifying the snapshot you want to load. 

>>> sim = rebound.Simulation("archive.bin", 34)

or 

>>> sim = rebound.Simulation(filename="archive.bin", snapshot=34)

Finally, you can also create a new Simulation by passing a bytes object of a 
Simulationarchive to Simulation():

>>> sim = rebound.Simulation(open("archive.bin","rb").read())

"""
def __new__(cls, *args, **kw):
# Create a new simulation if no arguments given
if len(args)==0:
sim = super(Simulation,cls).__new__(cls)
clibrebound.reb_simulation_init(byref(sim))
return sim

# If first argument is of type bytes, then unpickle a Simulation
if isinstance(args[0], bytes):
l = len(args[0]) 
buft = c_char * l
buf = buft.from_buffer_copy(args[0])
# Note: Not calling Simulationarchive.
# Doing this manually here because we need to keep the reference to buf.
# So we can later access the contents of the archive to get the simulation.
sa = Simulationarchive.__new__(Simulationarchive, None, None)
w = c_int(0)
clibrebound.reb_simulationarchive_init_from_buffer_with_messages(byref(sa), byref(buf), c_size_t(l), None, byref(w))
sim = super(Simulation,cls).__new__(cls)
clibrebound.reb_simulation_init(byref(sim))
clibrebound.reb_simulation_create_from_simulationarchive_with_messages(byref(sim),byref(sa),c_int64(-1),byref(w))
for majorerror, value, message in BINARY_WARNINGS:
if w.value & value:
if majorerror:
raise RuntimeError(message)
else: 
# Just a warning
warnings.warn(message, RuntimeWarning)
return sim

# Create simulation from Simulationarchive
if isinstance(args[0], Simulationarchive):
sa = args[0]
else:
# Otherwise assume first argument is filename
filename = args[0]
if "filename" in kw:
filename = kw["filename"]
sa = Simulationarchive(filename,process_warnings=False)

snapshot = -1
if len(args)>1:
snapshot = args[1]
if "snapshot" in kw:
snapshot = kw["snapshot"]

if sa is not None:
# Recreate exisitng simulation 
sim = super(Simulation,cls).__new__(cls)
clibrebound.reb_simulation_init(byref(sim))
w = sa.warnings # warnings will be appended to previous warnings (as to not repeat them) 
clibrebound.reb_simulation_create_from_simulationarchive_with_messages(byref(sim),byref(sa),c_int64(snapshot),byref(w))
for majorerror, value, message in BINARY_WARNINGS:
if w.value & value:
if majorerror:
raise RuntimeError(message)
else: 
# Just a warning
warnings.warn(message, RuntimeWarning)
return sim

# Still here? Then an error occured.
raise RuntimeError("Can not create Simulation.")

def __init__(self,filename=None,snapshot=None):
self.save_messages = 1 # Warnings will be checked within python

def __repr__(self):
return '<{0}.{1} object at {2}, N={3}, t={4}>'.format(self.__module__, type(self).__name__, hex(id(self)), self.N, self.t)

@classmethod
def from_simulationarchive(cls, simulationarchive, snapshot=-1):
return cls(filename=filename,snapshot=snapshot)

@classmethod
def from_file(cls, filename, snapshot=-1):
return cls(filename=filename, snapshot=snapshot)

def copy(self):
"""
Returns a deep copy of a REBOUND simulation. You need to reset 
any function pointers on the copy. 

Returns
------- 
A rebound.Simulation object.

"""
w = c_int(0)
sim = Simulation()
clibrebound.reb_simulation_copy_with_messages(byref(sim),byref(self),byref(w))
for majorerror, value, message in BINARY_WARNINGS:
if w.value & value:
if majorerror:
raise RuntimeError(message)
else: 
# Just a warning
warnings.warn(message, RuntimeWarning)
return sim

def start_server(self, port=1234):
"""
Start webserver on specified port. 
The default port is 1234.
You can access a running server by opening a web browser
at http://localhost:1234 or http://127.0.0.1:1234
"""
clibrebound.reb_simulation_start_server.restype = c_int
ret_value = clibrebound.reb_simulation_start_server(byref(self), c_int(port))
self.process_messages()

def stop_server(self, port=1234):
"""
Stop the webserver.
"""
ret_value = clibrebound.reb_simulation_stop_server(byref(self))
self.process_messages()


def widget(self, port=None, host="localhost", size=(500,500)):
if port is not None:
port = int(port)
if self._server_data:
if self._server_data.contents.port != port:
raise RuntimeError("Server is running already on port %d but port %d was requested."%(self._server_data.contents.port, port))
if not self._server_data:
if port is not None:
self.start_server(port=port)
else:
self.start_server()
if not self._server_data:
raise RuntimeError("Server did not start up immediately. Try again in a few seconds.")
port = int(self._server_data.contents.port)
from IPython.display import IFrame
width, height = size
display(IFrame("http://"+host+":"+"%d"%port, width, height))

def cite(self):
"""
Generate citations

This function generates citations to papers relevant to the current 
setting of the simulation.
"""

txt, bib = cite(self)
# one could check for REBOUNDx here, then append txt and bib accordingly
print(txt + "\n\n\n" + bib)

@property
def simulationarchive_filename(self):
"""
Returns the current Simulationarchive filename in use. 
Do not set manually. Use sim.save_to_file() instead
"""
return self._simulationarchive_filename

# Message and memory management functions
def process_messages(self):
clibrebound.reb_simulation_get_next_message.restype = c_int
buf = create_string_buffer(c_int.in_dll(clibrebound, "reb_max_messages_length").value)
while clibrebound.reb_simulation_get_next_message(byref(self), buf):
msg = buf.value.decode("ascii")
if msg[0]=='w':
warnings.warn(msg[1:], RuntimeWarning)
elif msg[0]=='e':
raise RuntimeError(msg[1:])

# Pickling methods: return Simulationarchive binary
def __reduce__(self):
buf = c_char_p()
size = c_size_t()
clibrebound.reb_simulation_save_to_stream(byref(self), byref(buf), byref(size))
s = bytes(string_at(buf, size=size.value)) #make copy
clibrebound.reb_simulation_output_free_stream(buf) # free original
return (Simulation, (s,))

# Other operators

def __del__(self):
if self._b_needsfree_ == 1: # to avoid, e.g., sim.particles[1]._sim.contents.G creating a Simulation instance to get G, and then freeing the C simulation when it immediately goes out of scope
clibrebound.reb_simulation_free_pointers(byref(self))

def __eq__(self, other):
# This ignores the walltime parameter
if not isinstance(other,Simulation):
return NotImplemented
clibrebound.reb_simulation_diff.restype = c_int
ret = clibrebound.reb_simulation_diff(byref(self), byref(other),c_int(2))
return not ret

def diff(self, other):
if not isinstance(other,Simulation):
return NotImplemented
clibrebound.reb_simulation_diff_char.restype = allocated_c_char_p
output = clibrebound.reb_simulation_diff_char(byref(other), byref(self))
print(output.value.decode("utf-8"))
clibrebound.reb_free(output)

def __add__(self, other):
if not isinstance(other,Simulation):
return NotImplemented
c = self.copy()
return c.__iadd__(other)

def __iadd__(self, other):
if not isinstance(other,Simulation):
return NotImplemented
clibrebound.reb_simulation_iadd.restype = c_int
ret = clibrebound.reb_simulation_iadd(byref(self), byref(other))
if ret==-1:
raise RuntimeError("Cannot add simulations. Check that the simulations have the same number of particles")
return self

def __sub__(self, other):
if not isinstance(other,Simulation):
return NotImplemented
c = self.copy()
return c.__isub__(other)

def __isub__(self, other):
if not isinstance(other,Simulation):
return NotImplemented
clibrebound.reb_simulation_isub.restype = c_int
ret = clibrebound.reb_simulation_isub(byref(self), byref(other))
if ret==-1:
raise RuntimeError("Cannot subtract simulations. Check that the simulations have the same number of particles")
return self

def __mul__(self, other):
try:
other = float(other)
except:
return NotImplemented
c = self.copy()
c.multiply(other, other)
return c

def __imul__(self, other):
try:
other = float(other)
except:
return NotImplemented
self.multiply(other, other)
return self

def __rmul__(self, other):
try:
other = float(other)
except:
return NotImplemented
c = self.copy()
c.multiply(other, other)
return c

def __div__(self, other):
return self.__truediv__(other)

def __idiv__(self, other):
return self.__itruediv__(other)

def __truediv__(self, other):
try:
other = float(other)
except:
return NotImplemented
c = self.copy()
if other==0.:
raise ZeroDivisionError
c.multiply(1./other, 1./other)
return c

def __itruediv__(self, other):
try:
other = float(other)
except:
return NotImplemented
if other==0.:
raise ZeroDivisionError
self.multiply(1./other, 1./other)
return self

def multiply(self, scalar_pos, scalar_vel):
try:
scalar_pos = float(scalar_pos)
scalar_vel = float(scalar_vel)
except:
raise ValueError("Cannot multiply simulation with non-scalars.")
clibrebound.reb_simulation_imul(byref(self), c_double(scalar_pos), c_double(scalar_vel))

def rotate(self, q):
from .rotation import Rotation
if not isinstance(q, Rotation):
return NotImplemented
clibrebound.reb_simulation_irotate(byref(self), q)

#ODE functions
def create_ode(self, length, needs_nbody=True):
clibrebound.reb_ode_create.restype = POINTER(ODE)
ode_p = clibrebound.reb_ode_create(byref(self), c_int(length))
ode_p.contents.needs_nbody = c_uint(needs_nbody)
return ODE.from_address(addressof(ode_p.contents))

# Status functions
def status(self, showParticles=True, showAllFields=True):
""" 
Prints a summary of the current status 
of the simulation.
"""
from rebound import __version__, __build__
s= ""
s += "---------------------------------\n"
s += "REBOUND version: \t%s\n" %__version__
s += "REBOUND built on: \t%s\n" %__build__
s += "Number of particles: \t%d\n" %self.N 
s += "Selected integrator: \t" + self.integrator + "\n" 
s += "Simulation time: \t%.16e\n" %self.t
s += "Current timestep: \t%f\n" %self.dt
s += "---------------------------------\n"
if self.N>0 and showParticles:
for p in self.particles:
s += str(p) + "\n"
s += "---------------------------------\n"
print(s, end="")
if showAllFields:
print("The following fields have non-default values:")
newsim = Simulation()
clibrebound.reb_simulation_diff_char.restype = c_char_p
output = clibrebound.reb_simulation_diff_char(byref(newsim), byref(self))
print(output.decode("utf-8"))



# Set function pointer for additional forces
@property
def additional_forces(self):
"""
Get or set a function pointer for calculating additional forces in the simulation.

The argument can be a python function or something that can 
be cast to a C function of type CFUNCTYPE(None,POINTER(Simulaton)). 
If the forces are velocity dependent, the flag 
force_is_velocity_dependent needs to be set to 1. Otherwise,
the particle structures might contain incorrect velocity 
values.
"""
raise AttributeError("You can only set C function pointers from python.")
@additional_forces.setter
def additional_forces(self, func):
self._afp = AFF(func)
self._additional_forces = self._afp

@property
def pre_timestep_modifications(self):
"""
Get or set a function pointer for pre-timestep modifications.

The argument can be a python function or something that can be cast to a C function or a
python function.
"""
raise AttributeError("You can only set C function pointers from python.")
@pre_timestep_modifications.setter
def pre_timestep_modifications(self, func):
self._pretmp = AFF(func)
self._pre_timestep_modifications = self._pretmp

@property
def post_timestep_modifications(self):
"""
Get or set a function pointer for post-timestep modifications.

The argument can be a python function or something that can be cast to a C function or a
python function.
"""
raise AttributeError("You can only set C function pointers from python.")
@post_timestep_modifications.setter
def post_timestep_modifications(self, func):
self._posttmp = AFF(func)
self._post_timestep_modifications = self._posttmp

@property
def heartbeat(self):
"""
Set a function pointer for a heartbeat function.
The heartbeat function is called every timestep and can be used
to monitor long simulations, check for stalled simulations and 
output debugging information.

The argument can be a python function or something that can be 
cast to a C function or a python function.

The function called will receive a pointer to the simulation
object as its argument.

Examples
--------

>>> import rebound
>>> sim = rebound.Simulation()
>>> sim.add(m=1.)
>>> sim.add(m=1e-3, a=1)
>>> def heartbeat(sim):
>>> # sim is a pointer to the simulation object,
>>> # thus use contents to access object data.
>>> # See ctypes documentation for details.
>>> print(sim.contents.t)
>>> sim.heartbeat = heartbeat
>>> sim.integrate(1.)

"""
raise AttributeError("You can only set C function pointers from python (not get).")
@heartbeat.setter
def heartbeat(self, func):
self._hb = AFF(func)
self._heartbeat = self._hb

@property 
def coefficient_of_restitution(self):
"""
Get or set a function pointer that defined the coefficient of restitution.
"""
raise AttributeError("You can only set C function pointers from python.")
@coefficient_of_restitution.setter
def coefficient_of_restitution(self, func):
self._corfp = CORFF(func)
self._coefficient_of_restitution = self._corfp

@property 
def collision_resolve(self):
"""
Get or set a function pointer for collision resolving routine.

Possible options for setting:
1) Function pointer
2) "merge": two colliding particles will merge) 
3) "hardsphere": two colliding particles will bounce off using a set coefficient of restitution
"""
raise AttributeError("You can only set C function pointers from python.")
@collision_resolve.setter
def collision_resolve(self, func):
if func == "merge":
clibrebound.reb_simulation_set_collision_resolve.restype = None
clibrebound.reb_simulation_set_collision_resolve(byref(self), clibrebound.reb_collision_resolve_merge)
elif func == "hardsphere":
clibrebound.reb_simulation_set_collision_resolve.restype = None
clibrebound.reb_simulation_set_collision_resolve(byref(self), clibrebound.reb_collision_resolve_hardsphere)
elif func == "halt":
clibrebound.reb_simulation_set_collision_resolve.restype = None
clibrebound.reb_simulation_set_collision_resolve(byref(self), clibrebound.reb_collision_resolve_halt)
else:
self._colrfp = COLRFF(func)
self._collision_resolve = self._colrfp

@property 
def free_particle_ap(self):
"""
Get or set a function pointer for freeing the ap pointer whenever sim.remove is called.
"""
raise AttributeError("You can only set C function pointers from python.")
@free_particle_ap.setter
def free_particle_ap(self, func):
self._fpa = FPA(func)
self._free_particle_ap = self._fpa

# Setter/getter of parameters and constants
@property 
def N_real(self):
"""
Get the current number of real (i.e. no variational/shadow) particles in the simulation.
"""
return self.N-self.N_var

@property
def integrator(self):
"""
Get or set the integrator module.

Available integrators include:

- ``'IAS15'`` (default)
- ``'WHFast'``
- ``'SEI'``
- ``'LEAPFROG'``
- ``'JANUS'``
- ``'MERCURIUS'``
- ``'WHCKL'`` 
- ``'WHCKM'`` 
- ``'WHCKC'`` 
- ``'SABA4'`` 
- ``'SABACL4'`` 
- ``'SABACM4'`` 
- ``'SABA(10,6,4)'`` 
- ``'EOS'`` 
- ``'BS'`` 
- ``'WHFast512'``
- ``'TRACE'``
- ``'none'``

Check the online documentation for a full description of each of the integrators. 
"""
i = self._integrator
for name, _i in INTEGRATORS.items():
if i==_i:
return name
return i
@integrator.setter
def integrator(self, value):
if isinstance(value, int):
self._integrator = c_int(value)
elif isinstance(value, basestring):
value = value.lower()
if value in INTEGRATORS: 
self._integrator = INTEGRATORS[value]
# Shortcuts
elif value=="wh":
self.integrator = "whfast"
self.ri_whfast.corrector = 0
self.ri_whfast.kernel = "default"
elif value=="whc":
self.integrator = "whfast"
self.ri_whfast.corrector = 17
self.ri_whfast.kernel = "default"
elif value=="whckl":
self.integrator = "whfast"
self.ri_whfast.corrector = 17
self.ri_whfast.kernel = "lazy"
elif value=="whckm":
self.integrator = "whfast"
self.ri_whfast.corrector = 17
self.ri_whfast.kernel = "modifiedkick"
elif value=="whckc":
self.integrator = "whfast"
self.ri_whfast.corrector = 17
self.ri_whfast.kernel = "composition"
elif value[0:4]=="saba" and len(value)>4:
self.integrator = "saba"
self.ri_saba.type = value[4:]
else:
raise ValueError("Integrator not found.")

@property
def boundary(self):
"""
Get or set the boundary module.

Available boundary modules are:

- ``'none'`` (default)
- ``'open'``
- ``'periodic'``
- ``'shear'``

Check the online documentation for a full description of each of the modules. 
"""
i = self._boundary
for name, _i in BOUNDARIES.items():
if i==_i:
return name
return i
@boundary.setter
def boundary(self, value):
if isinstance(value, int):
self._boundary = c_int(value)
elif isinstance(value, basestring):
value = value.lower()
if value in BOUNDARIES: 
self._boundary = BOUNDARIES[value]
else:
raise ValueError("Warning. Boundary condition module not found.")

@property
def gravity(self):
"""
Get or set the gravity module.

Available gravity modules are:

- ``'none'`` 
- ``'basic'`` (default)
- ``'compensated'``
- ``'tree'``

Check the online documentation for a full description of each of the modules. 
"""
i = self._gravity
for name, _i in GRAVITIES.items():
if i==_i:
return name
return i
@gravity.setter
def gravity(self, value):
if isinstance(value, int):
self._gravity = c_int(value)
elif isinstance(value, basestring):
value = value.lower()
if value in GRAVITIES: 
self._gravity = GRAVITIES[value]
else:
raise ValueError("Warning. Gravity module not found.")

@property
def collision(self):
"""
Get or set the collision module.

Available collision modules are:

- ``'none'`` (default)
- ``'direct'``
- ``'tree'``
- ``'line'`` 
- ``'linetree'``

Check the online documentation for a full description of each of the modules. 
"""
i = self._collision
for name, _i in COLLISIONS.items():
if i==_i:
return name
return i
@collision.setter
def collision(self, value):
if isinstance(value, int):
self._collision = c_int(value)
elif isinstance(value, basestring):
value = value.lower()
if value in COLLISIONS: 
self.collision = COLLISIONS[value]
else:
raise ValueError("Warning. Collision module not found.")

# Units

@property
def units(self):
"""
Tuple of the units for length, time and mass. Can be set in any order, and strings are not case-sensitive. See ipython_examples/Units.ipynb for more information. You can check the units' exact values and add Additional units in rebound/rebound/units.py. Units should be set before adding particles to the simulation (will give error otherwise).

Currently supported Units 
-------------------------

Times:
Hr : Hours
Yr : Julian years
Jyr : Julian years
Sidereal_yr : Sidereal year
Yr2pi : Year divided by 2pi, with year defined as orbital period of planet at 1AU around 1Msun star
Kyr : Kiloyears (Julian)
Myr : Megayears (Julian)
Gyr : Gigayears (Julian)

Lengths:
M : Meters
Cm : Centimeters
Km : Kilometers
AU : Astronomical Units

Masses:
Kg : Kilograms
Msun : Solar masses
Mmercury : Mercury masses
Mvenus : Venus masses
Mearth : Earth masses
Mmars : Mars masses
Mjupiter : Jupiter masses
Msaturn : Saturn masses
Muranus : Neptune masses
Mpluto : Pluto masses

Examples
--------

>>> sim = rebound.Simulation()
>>> sim.units = ('yr', 'AU', 'Msun')

"""

return {'length':hash_to_unit(self.python_unit_l), 'mass':hash_to_unit(self.python_unit_m), 'time':hash_to_unit(self.python_unit_t)}

@units.setter
def units(self, newunits):
newunits = check_units(newunits) 
if self.N>0: # some particles are loaded
raise AttributeError("Error: You cannot set the units after populating the particles array. See ipython_examples/Units.ipynb.")
self.update_units(newunits) 

def update_units(self, newunits): 
clibrebound.reb_hash.restype = c_uint32
self.python_unit_l = clibrebound.reb_hash(c_char_p(newunits[0].encode("ascii")))
self.python_unit_t = clibrebound.reb_hash(c_char_p(newunits[1].encode("ascii")))
self.python_unit_m = clibrebound.reb_hash(c_char_p(newunits[2].encode("ascii")))
self.G = convert_G(newunits)

def equal_units(self, sim2):
"""
Compares of this simulation to another simulation.

Returns
-------
True if both simulations use the same units. False otherwise.
"""
if not isinstance(sim2,Simulation):
raise AttributeError("Error: Argument is not a Simulation object.")

return self.python_unit_l == sim2.python_unit_l and self.python_unit_m == sim2.python_unit_m and self.python_unit_t == sim2.python_unit_t

def convert_particle_units(self, *args): 
"""
Will convert the units for the simulation (i.e. convert G) as well as the particles' cartesian elements.
Must have set sim.units ahead of calling this function, so REBOUND knows what units to convert from.

Parameters
----------
3 strings corresponding to units of time, length and mass. Can be in any order and aren't case-sensitive. You can add new units to rebound/rebound/units.py
"""
if self.python_unit_l == 0 or self.python_unit_m == 0 or self.python_unit_t == 0:
raise AttributeError("Must set sim.units before calling convert_particle_units in order to know what units to convert from.")
new_l, new_t, new_m = check_units(args)
for p in self.particles:
units_convert_particle(p, hash_to_unit(self.python_unit_l), hash_to_unit(self.python_unit_t), hash_to_unit(self.python_unit_m), new_l, new_t, new_m)
self.update_units((new_l, new_t, new_m))

# Variational Equations
def add_variation(self,order=1,first_order=None, first_order_2=None, testparticle=-1):
""" 
This function adds a set of variational particles to the simulation. 

If there are N real particles in the simulation, this functions adds N additional variational 
particles. To see how many particles (real and variational) are in a simulation, use ``'sim.N'``. 
To see how many variational particles are in a simulation use ``'sim.N_var'``.

Currently Leapfrog, WHFast and IAS15 support first order variational equations. IAS15 also
supports second order variational equations.

Parameters
----------
order : integer, optional
By default, the function adds a set of first order variational particles to the simulation. Set this flag to 2 for second order.
first_order : Variation, optional
Second order variational equations depend on their corresponding first order variational equations. 
This parameter expects the Variation object corresponding to the first order variational equations. 
first_order_2 : Variation, optional
Same as first_order. But allows to set two different indicies to calculated off-diagonal elements. 
If omitted, then first_order will be used for both first order equations.
testparticle : int, optional
If set to a value >= 0, then only one variational particle will be added and be treated as a test particle.


Returns
-------
Returns Variation object (a copy--you can only modify it through its particles property or vary method). 
"""
cur_N_var_config = self.N_var_config
if order==1:
index = clibrebound.reb_simulation_add_variation_1st_order(byref(self),c_int(testparticle))
elif order==2:
if first_order is None:
raise AttributeError("Please specify corresponding first order variational equations when initializing second order variational equations.")
if first_order_2 is None:
first_order_2 = first_order
index = clibrebound.reb_simulation_add_variation_2nd_order(byref(self),c_int(testparticle),c_int(first_order.index),c_int(first_order_2.index))
else:
raise AttributeError("Only variational equations of first and second order are supported.")

# Need a copy because location of original might shift if more variations added
s = Variation.from_buffer_copy(self.var_config[cur_N_var_config])

return s

# MEGNO
def init_megno(self, seed=None):
"""
This function initialises the chaos indicator MEGNO particles and enables their integration.

MEGNO is short for Mean Exponential Growth of Nearby orbits. It can be used to test
if a system is chaotic or not. In the backend, the integrator is integrating an additional set
of particles using the variational equation. Note that variational equations are better 
suited for this than shadow particles. MEGNO is currently only supported in the IAS15 
and WHFast integrators.

This function also needs to be called if you are interested in the Lyapunov exponent as it is
calculate with the help of MEGNO. See Rein and Tamayo 2015 for details on the implementation.

For more information on MEGNO see e.g. https://dx.doi.org/10.1051/0004-6361:20011189
"""
if seed is None:
clibrebound.reb_simulation_init_megno(byref(self))
else:
clibrebound.reb_simulation_init_megno_seed(byref(self), c_uint(seed))

def megno(self):
"""
Return the current MEGNO value.
Note that you need to call init_megno() before the start of the simulation.
"""
if self._calculate_megno==0:
raise RuntimeError("MEGNO cannot be calculated. Make sure to call init_megno() after adding all particles but before integrating the simulation.")

clibrebound.reb_simulation_megno.restype = c_double
return clibrebound.reb_simulation_megno(byref(self))

def lyapunov(self):
"""
Return the current Lyapunov Characteristic Number (LCN).
Note that you need to call init_megno() before the start of the simulation.
Different definitions of the LCN exist. Here, we're following Eq 24 of 
Cincotta and Simo (2000): https://aas.aanda.org/articles/aas/abs/2000/20/h1686/h1686.html.
To get a timescale (the Lyapunov timescale), take the inverse of this quantity.
"""
if self._calculate_megno==0:
raise RuntimeError("Lyapunov Characteristic Number cannot be calculated. Make sure to call init_megno() after adding all particles but before integrating the simulation.")

clibrebound.reb_simulation_lyapunov.restype = c_double
return clibrebound.reb_simulation_lyapunov(byref(self))

# Particle add function, used to be called particle_add() and add_particle() 
def add(self, particle=None, **kwargs): 
"""
Adds a particle to REBOUND. Accepts one of the following:

1) A single Particle structure.
2) The particle's mass and a set of cartesian coordinates: m,x,y,z,vx,vy,vz.
3) The primary as a Particle structure, the particle's mass and a set of orbital elements: primary,m,a,anom,e,omega,inv,Omega,MEAN (see :class:`.Orbit` for the definition of orbital elements).
4) A name of an object (uses NASA Horizons to look up coordinates)
5) A list of particles or names.
"""
if particle is not None:
if isinstance(particle, Particle):
if (self.gravity == "tree" or self.collision == "tree") and self.root_size <=0.:
raise ValueError("The tree code for gravity and/or collision detection has been selected. However, the simulation box has not been configured yet. You cannot add particles until the the simulation box has a finite size.")
if particle._sim:
if not self.equal_units(particle._sim.contents):
warnings.warn("Particle is being adding from a simulation that uses different units.", RuntimeWarning)
clibrebound.reb_simulation_add(byref(self), particle)
elif isinstance(particle, list):
for p in particle:
self.add(p, **kwargs)
elif isinstance(particle,str):
if self.python_unit_l == 0 or self.python_unit_m == 0 or self.python_unit_t == 0:
self.units = ('AU', 'yr2pi', 'Msun')
self.G = 1.0
builtindatasets = ["solar system", "outer solar system"]
if particle.lower() == "solar system": # built in test dataset
data.add_solar_system(self)
elif particle.lower() == "outer solar system": # built in test dataset
data.add_outer_solar_system(self)
else:
if "frame" not in kwargs:
if hasattr(self, 'default_plane'):
kwargs["plane"] = self.default_plane # allow ASSIST to set default plane
mass_unit = hash_to_unit(self.python_unit_m) # For manually provided masses
self.add(horizons.query_horizons_for_particle(mass_unit, particle, **kwargs), hash=particle)
units_convert_particle(self.particles[-1], 'km', 's', 'kg', hash_to_unit(self.python_unit_l), hash_to_unit(self.python_unit_t), hash_to_unit(self.python_unit_m))
else: 
raise ValueError("Argument passed to add() not supported.")
else: 
self.add(Particle(simulation=self, **kwargs))
self.process_messages()

# Particle getter functions
@property
def particles(self):
"""
Returns a Particles object that allows users to access particles like a dictionary using indices, hashes, or strings. 

The Particles object uses pointers and thus the contents update 
as the simulation progresses. Note that the pointers could change,
for example when a particle is added or removed from the simulation. 
"""
particles = Particles(self)
return particles

@particles.deleter
def particles(self):
"""
Remove all particles from the simulation
"""
clibrebound.reb_simulation_remove_all_particles(byref(self))
self.process_messages()

def remove(self, index=None, hash=None, keep_sorted=True):
""" 
Removes a particle from the simulation.

Parameters
----------
index : int, optional
Specify particle to remove by index.
hash : c_uint32 or string, optional
Specifiy particle to remove by hash (if a string is passed, the corresponding hash is calculated).
keep_sorted : bool, optional
By default, remove preserves the order of particles in the particles array. 
Might set it to zero in cases with many particles and many removals to speed things up.
"""
if index is not None:
clibrebound.reb_simulation_remove_particle(byref(self), index, keep_sorted)
if hash is not None:
hash_types = c_uint32, c_uint, c_uint64
PY3 = sys.version_info[0] == 3
if PY3:
string_types = str,
int_types = int,
else:
string_types = basestring,
int_types = int, long
if isinstance(hash, string_types):
clibrebound.reb_simulation_remove_particle_by_hash(byref(self), rebhash(hash), keep_sorted)
elif isinstance(hash, int_types):
clibrebound.reb_simulation_remove_particle_by_hash(byref(self), c_uint32(hash), keep_sorted)
elif isinstance(hash, hash_types):
clibrebound.reb_simulation_remove_particle_by_hash(byref(self), hash, keep_sorted)

self.process_messages()

# Orbit calculation
def orbits(self, primary=None, jacobi_masses=False):
""" 
Calculate orbital parameters for all particles in the simulation.
By default, this functions returns the orbits in Jacobi coordinates. 

If MEGNO is enabled, variational particles will be ignored.

Parameters
----------

primary : rebound.Particle, optional
Set the primary against which to reference the osculating orbit. Default (use Jacobi center of mass).
For heliocentric coordinates, pass the central object to this parameter. 
jacobi_masses: bool
Whether to use jacobi primary mass in orbit calculation. (Default: False)

Returns
-------
Returns an array of Orbits of length N-1.
"""
orbits = []

if primary is None:
jacobi = True
primary = self.particles[0]
clibrebound.reb_particle_com_of_pair.restype = Particle
else:
jacobi = False

for p in self.particles[1:self.N_real]:
if jacobi_masses is True:
interior_mass = primary.m
# orbit conversion uses mu=G*(p.m+primary.m) so set prim.m=Mjac-m so mu=G*Mjac
primary.m = self.particles[0].m*(p.m + interior_mass)/interior_mass - p.m
orbits.append(p.orbit(primary=primary))
primary.m = interior_mass # back to total mass of interior bodies to update com
else:
orbits.append(p.orbit(primary=primary))
if jacobi is True: # update com to include current particle for next iteration
primary = clibrebound.reb_particle_com_of_pair(primary, p)

return orbits

# COM calculation 
def com(self, first=0, last=None):
"""
Returns the center of momentum for all particles in the simulation.

Parameters
----------
first: int, optional
If ``first`` is specified, only calculate the center of momentum starting
from index=``first``.
last : int or None, optional
If ``last`` is specified only calculate the center of momentum up to 
(but excluding) index=``last``. Same behavior as Python's range function.

Examples
--------
>>> sim = rebound.Simulation()
>>> sim.add(m=1, x=-20)
>>> sim.add(m=1, x=-10)
>>> sim.add(m=1, x=0)
>>> sim.add(m=1, x=10)
>>> sim.add(m=1, x=20)
>>> com = sim.com()
>>> com.x
0.0 
>>> com = sim.com(first=2,last=4) # Considers indices 2,3
>>> com.x
5.0

"""
if last is None:
last = self.N_real
clibrebound.reb_simulation_com_range.restype = Particle
return clibrebound.reb_simulation_com_range(byref(self), c_int(first), c_int(last))

# Tools
def serialize_particle_data(self,**kwargs):
"""
Fast way to access serialized particle data via numpy arrays.

This function can directly set the values of numpy arrays to
current particle data. This is significantly faster than accessing
particle data via `sim.particles` as all the copying is done 
on the C side. 
No memory is allocated by this function.
It expects correctly sized numpy arrays as arguments. The argument
name indicates what kind of particle data is written to the array. 

Possible argument names are "hash", "m", "r", "xyz", "vxvyvz", and 
"xyzvxvyvz". The datatype for the "hash" array needs to be uint32. 
The other arrays expect a datatype of float64. The lengths of 
"hash", "m", "r" arrays need to be at least sim.N. The lengths of 
xyz and vxvyvz need to be at least 3*sim.N. The length of
"xyzvxvyvz" arrays need to be 6*sim.N. Exceptions are raised 
otherwise.

Note that this routine is only intended for special use cases
where speed is an issue. For normal use, it is recommended to
access particle data via the `sim.particles` array. Be aware of
potential issues that arise by directly accesing the memory of
numpy arrays (see numpy documentation for more details).

Examples
--------
This sets an array to the xyz positions of all particles:

>>> import numpy as np
>>> a = np.zeros((sim.N,3),dtype="float64")
>>> sim.serialize_particle_data(xyz=a)
>>> print(a)

To get all current radii of particles:

>>> a = np.zeros(sim.N,dtype="float64")
>>> sim.serialize_particle_data(r=a)
>>> print(a)

To get all current radii and hashes of particles:

>>> a = np.zeros(sim.N,dtype="float64")
>>> b = np.zeros(sim.N,dtype="uint32")
>>> sim.serialize_particle_data(r=a,hash=b)
>>> print(a,b)

"""
N = self.N
possible_keys = ["hash","m","r","xyz","vxvyvz","xyzvxvyvz"]
d = {x:None for x in possible_keys}
for k,v in kwargs.items():
if k in d:
if k == "hash":
if v.dtype!= "uint32":
raise AttributeError("Expected 'uint32' data type for '%s' array."%k)
if v.size raise AttributeError("Array '%s' is not large enough."%k)
d[k] = v.ctypes.data_as(POINTER(c_uint32))
else:
if v.dtype!= "float64":
raise AttributeError("Expected 'float64' data type for %s array."%k)
if k in ["xyz", "vxvyvz"]:
minsize = 3*N
elif k in ["xyzvxvyvz"]:
minsize = 6*N
else:
minsize = N
if v.size raise AttributeError("Array '%s' is not large enough."%k)
d[k] = v.ctypes.data_as(POINTER(c_double))
else:
raise AttributeError("Only '%s' are currently supported attributes for serialization." % "', '".join(d.keys()))

clibrebound.reb_simulation_get_serialized_particle_data(byref(self), d["hash"], d["m"], d["r"], d["xyz"], d["vxvyvz"], d["xyzvxvyvz"])

def set_serialized_particle_data(self,**kwargs):
"""
Fast way to set serialized particle data via numpy arrays.
This is the inverse of Simulation.serialize_particle_data()
and uses the same syntax
"""

N = self.N
possible_keys = ["hash","m","r","xyz","vxvyvz","xyzvxvyvz"]
d = {x:None for x in possible_keys}
for k,v in kwargs.items():
if k in d:
if k == "hash":
if v.dtype!= "uint32":
raise AttributeError("Expected 'uint32' data type for '%s' array."%k)
if v.size raise AttributeError("Array '%s' is not large enough."%k)
d[k] = v.ctypes.data_as(POINTER(c_uint32))
else:
if v.dtype!= "float64":
raise AttributeError("Expected 'float64' data type for %s array."%k)
if k in ["xyz", "vxvyvz"]:
minsize = 3*N
elif k in ["xyzvxvyvz"]:
minsize = 6*N
else:
minsize = N
if v.size raise AttributeError("Array '%s' is not large enough."%k)
d[k] = v.ctypes.data_as(POINTER(c_double))
else:
raise AttributeError("Only '%s' are currently supported attributes for serialization." % "', '".join(d.keys()))

clibrebound.reb_simulation_set_serialized_particle_data(byref(self), d["hash"], d["m"], d["r"], d["xyz"], d["vxvyvz"], d["xyzvxvyvz"])

def move_to_hel(self):
"""
This function moves all particles in the simulation to the heliocentric frame.
Note that the simulation will not stay in the heliocentric frame during integrations
as the heliocentric frame is not an inertial frame.
"""
clibrebound.reb_simulation_move_to_hel(byref(self))

def move_to_com(self):
"""
This function moves all particles in the simulation to a center of momentum frame.
In that frame, the center of mass is at the origin and does not move.
It makes sense to call this function at the beginning of the integration, especially 
for the high accuracy integrators IAS15 and WHFast.
"""
clibrebound.reb_simulation_move_to_com(byref(self))

def energy(self):
"""
Returns the sum of potential and kinetic energy of all particles in the simulation.
"""
clibrebound.reb_simulation_energy.restype = c_double
return clibrebound.reb_simulation_energy(byref(self))

def angular_momentum(self):
"""
Returns a list of the three (x,y,z) components of the total angular momentum of all particles in the simulation.
"""
clibrebound.reb_simulation_angular_momentum.restype = Vec3dBasic
return Vec3d(clibrebound.reb_simulation_angular_momentum(byref(self)))

def ias15_timescale(self):
"""
Returns the gravitational timescale in code units. See Pham, Rein, Spiegel 2023 for details. 
"""
clibrebound.reb_integrator_ias15_timescale.restype = c_double
return clibrebound.reb_integrator_ias15_timescale(byref(self))

def configure_box(self, boxsize, N_root_x=1, N_root_y=1, N_root_z=1):
"""
Initialize the simulation box.

This function only needs to be called it boundary conditions other than "none"
are used. In such a case the boxsize must be known and is set with this function.

Parameters
----------
boxsize : float
The size of one root box.
N_root_x, N_root_y, N_root_z : int, optional
The number of root boxes in each direction. The total size of the simulation box
will be ``N_root_x * boxsize``, ``N_root_y * boxsize`` and ``N_root_z * boxsize``.
By default, there will be exactly one root box in each direction.
"""
clibrebound.reb_simulation_configure_box(byref(self), c_double(boxsize), c_int(N_root_x), c_int(N_root_y), c_int(N_root_z))
return

# Output to file (Simulationarchive)
def save_to_file(self, filename, interval=None, walltime=None, step=None, delete_file=False):
"""
Saves a simulation to a file (Simulationarchive binary format). 

If just the filename is passed, then the simulation is saved immediately. 
You can also automate taking snapshots during a simulation. For that specify
the interval at which outputs are required. You can do that using either
`interval` (physical time), `walltime` (in seconds), or `step` 
(the number of timesteps in-between snapshots). 


Arguments
---------
filename : str
Filename of the binary file.
interval : float
Interval between outputs in code units.
walltime : float
Interval between outputs in wall time (seconds). 
Useful when using IAS15 with adaptive timesteps. 
step : int
Interval between outputs in number of timesteps. 
Useful when outputs need to be spaced exactly.
delete_file: bool
False (default) appends to file if it exists.
True deletes the file first.

Examples
--------
The following example shows how to output a simulation and
then read it back in. 

>>> sim = rebound.Simulation()
>>> sim.add(m=1.)
>>> sim.save_to_file("test.bin")
>>> sim2 = rebound.Simulation("test.bin")

The following example creates a simulation, then 
initializes the Simulationarchive and integrates
it forward in time. 

>>> sim = rebound.Simulation()
>>> sim.add(m=1.)
>>> sim.add(m=1.e-3,x=1.,vy=1.)
>>> sim.save_to_file("sa.bin",interval=1000.)
>>> sim.integrate(1e8)

The Simulationarchive can later be read in using the following syntax:

>>> sa = rebound.Simulationarchive("sa.bin")
>>> sim = sa[0] # get the first snapshot in the SA file (initial conditions)
>>> sim = sa[-1] # get the last snapshot in the SA file

"""
if delete_file and os.path.isfile(filename):
os.remove(filename)

modes = sum(1 for i in [interval, walltime,step] if i is not None)

if modes == 0:
# Immediately save to file.
clibrebound.reb_simulation_save_to_file(byref(self), c_char_p(filename.encode("ascii")))
elif modes == 1:
if delete_file:
# reset intervals so that automate functions in C set sim->next consistently
self.simulationarchive_auto_interval = 0
self.simulationarchive_auto_walltime = 0
self.simulationarchive_auto_step = 0
if interval:
clibrebound.reb_simulation_save_to_file_interval(byref(self), c_char_p(filename.encode("ascii")), c_double(interval))
if walltime:
clibrebound.reb_simulation_save_to_file_walltime(byref(self), c_char_p(filename.encode("ascii")), c_double(walltime))
if step:
clibrebound.reb_simulation_save_to_file_step(byref(self), c_char_p(filename.encode("ascii")), c_uint64(step))
self.process_messages()
else:
raise AttributeError("Cannot specify more than one of interval, walltime, or step.")

def output_screenshot(self, filename):
"""
Saves a screenshot of the current WebGL visualization to a file in png format.

The web server needs to be started, and a web browser needs to be 
connected to the server in order to take screen shots.

Arguments
---------
filename : str
Filename of the output file.

Examples
--------
The following example take a screenshot of a simulation.

>>> sim = rebound.Simulation()
>>> sim.integrator = "whfast"
>>> sim.add(m=1.)
>>> sim.add(a=1.)
>>> sim.widget() # this connects one client
>>> sim.output_screenshot("screenshot.png")
"""

clibrebound.reb_simulation_output_screenshot(byref(self), c_char_p(filename.encode("ascii")))
self.process_messages()

# Integration
def step(self):
"""
Perform exactly one integration step with REBOUND. This function is rarely needed.
Instead, use integrate().
"""
clibrebound.reb_simulation_step(byref(self))
self.process_messages()

def steps(self, N_steps):
"""
Perform exactly N_steps integration steps with REBOUND. This function is rarely needed.
Instead, use integrate().
"""
clibrebound.reb_simulation_steps(byref(self),c_uint(N_steps))
self.process_messages()

def integrate(self, tmax, exact_finish_time=1):
"""
Main integration function. Call this function when you have setup your simulation and want to integrate it forward (or backward) in time. The function might be called many times to integrate the simulation in steps and create outputs in-between steps.

Parameters
----------
tmax : float
The final time of your simulation. If the current time is 100, and tmax=200, then after the calling the integrate routine, the time has advanced to t=200. If tmax is larger than or equal to the current time, no integration will be performed.
exact_finish_time: int, optional
This argument determines whether REBOUND should try to finish at the exact time (tmax) you give it or if it is allowed to overshoot. Overshooting could happen if one starts at t=0, has a timestep of dt=10 and wants to integrate to tmax=25. With ``exact_finish_time=1``, the integrator will choose the last timestep such that t is exactly 25 after the integration, otherwise t=30. Note that changing the timestep does affect the accuracy of symplectic integrators negatively.

Exceptions
----------
Exceptions are thrown when no more particles are left in the simulation or when a generic integration error occured. 
If you specified exit_min_distance or exit_max_distance, then additional exceptions might thrown for escaping particles or particles that undergo a clos encounter.

Examples
-------- 
The typical usage is as follows. Note the use of ``np.linspace`` to create equally spaced outputs. 
Using ``np.logspace`` can be used to easily produce logarithmically spaced outputs.

>>> import numpy as np
>>> for time in np.linspace(0,100.,10): 
>>> sim.integrate(time)
>>> perform_output(sim)

"""
self.exact_finish_time = c_int(exact_finish_time)
ret_value = clibrebound.reb_simulation_integrate(byref(self), c_double(tmax))
if ret_value == 1:
self.process_messages()
raise GenericError("An error occured during the integration.")
if ret_value == 2:
if self._N_odes>0:
raise NoParticles("No particles found. Will exit. Use BS integrator to integrate user-defined ODEs without any particles present.");
else:
raise NoParticles("No more particles left in simulation.")
if ret_value == 3:
raise Encounter("Two particles had a close encounter (d if ret_value == 4:
raise Escape("A particle escaped (r>exit_max_distance).")
if ret_value == 5:
pass # User caused exit. Do not raise error message
if ret_value == 6:
raise KeyboardInterrupt
if ret_value == 7:
raise Collision("Two particles collided (d < r1+r2)")
self.process_messages()

def stop(self):
"""
Call this function to stop an integration, for example
from the heartbeat function.
"""
clibrebound.reb_simulation_stop(byref(self))

def reset_integrator(self):
"""
Call this function to reset temporary integrator variables
"""
clibrebound.reb_simulation_reset_integrator(byref(self))

def synchronize(self):
"""
Call this function if safe-mode is disabled and you need to synchronize particle positions and velocities between timesteps.
"""
clibrebound.reb_simulation_synchronize(byref(self))
self.process_messages()

def update_tree(self):
"""
Call this function to update the tree structure manually after removing particles.
"""
clibrebound.reb_simulation_update_tree(byref(self))


class timeval(Structure):
_fields_ = [("tv_sec",c_int64),("tv_usec",c_int64)]

from .particle import Particle
from .particles import Particles


from .integrators.bs import ODE, IntegratorBS
from .integrators.whfast import IntegratorWHFast
from .integrators.whfast512 import IntegratorWHFast512
from .integrators.janus import IntegratorJanus
from .integrators.sei import IntegratorSEI
from .integrators.eos import IntegratorEOS
from .integrators.ias15 import IntegratorIAS15
from .integrators.saba import IntegratorSABA
from .integrators.mercurius import IntegratorMercurius
from .integrators.trace import IntegratorTRACE

from .variation import Variation

# Setting up fields after class definition (because of self-reference)

class ServerData(Structure):
_fields_ = [
("r", POINTER(Simulation)),
("_screenshot", c_void_p),
("_N_screenshot", c_size_t),
("_status_before_screenshot", c_int),
("port", c_int),
("need_copy", c_int),
("ready", c_int),
# other fields not needed.
]

Simulation._fields_ = [
("t", c_double),
("G", c_double),
("softening", c_double),
("dt", c_double),
("dt_last_done", c_double),
("steps_done", c_uint64),
("N", c_uint),
("N_var", c_int),
("N_var_config", c_int),
("var_config", POINTER(Variation)),
("_var_rescale_warning", c_int),
("N_active", c_int),
("testparticle_type", c_int),
("testparticle_hidewarnings", c_int),
("_particle_lookup_table", POINTER(HashPointerPair)),
("hash_ctr", c_int),
("N_lookup", c_int),
("N_allocated_lookup", c_int),
("N_allocated", c_uint),
("_particles", POINTER(Particle)),
("gravity_cs", POINTER(Vec3dBasic)),
("N_allocated_gravity_cs", c_int),
("_tree_root", c_void_p),
("_tree_needs_update", c_int),
("opening_angle2", c_double),
("_status", c_int),
("exact_finish_time", c_int),
("force_is_velocity_dependent", c_uint),
("gravity_ignore", c_uint),
("_output_timing_last", c_double),
("save_messages", c_int),
("messages", c_void_p),
("exit_max_distance", c_double),
("exit_min_distance", c_double),
("usleep", c_double),
("_display_view", c_void_p),
("_display_data", c_void_p), # not needed from python
("_server_data", POINTER(ServerData)),
("track_energy_offset", c_int),
("energy_offset", c_double),
("walltime", c_double),
("walltime_last_step", c_double),
("walltime_last_steps", c_double),
("_walltime_last_steps_sum", c_double),
("_walltime_last_steps_N", c_int),
("python_unit_t",c_uint32),
("python_unit_l",c_uint32),
("python_unit_m",c_uint32),
("boxsize", Vec3dBasic),
("boxsize_max", c_double),
("root_size", c_double),
("N_root", c_int),
("N_root_x", c_int),
("N_root_y", c_int),
("N_root_z", c_int),
("N_ghost_x", c_int),
("N_ghost_y", c_int),
("N_ghost_z", c_int),
("collision_resolve_keep_sorted", c_int),
("collisions", c_void_p),
("N_allocated_collisions", c_int),
("collisions_N", c_uint),
("minimum_collision_velocity", c_double),
("collisions_plog", c_double),
("collisions_log_n", c_int64),
("_calculate_megno", c_int),
("_megno_Ys", c_double),
("_megno_Yss", c_double),
("_megno_cov_Yt", c_double),
("_megno_var_t", c_double),
("_megno_mean_t", c_double),
("_megno_mean_Y", c_double),
("_megno_initial_t", c_double),
("_megno_n", c_int64),
("rand_seed",c_uint),
("simulationarchive_version", c_int),
("simulationarchive_auto_interval", c_double),
("simulationarchive_auto_walltime", c_double),
("simulationarchive_auto_step", c_uint64),
("simulationarchive_next", c_double),
("simulationarchive_next_step", c_uint64),
("_simulationarchive_filename", c_char_p),
("_collision", c_int),
("_integrator", c_int),
("_boundary", c_int),
("_gravity", c_int),
("ri_sei", IntegratorSEI), 
("ri_whfast", IntegratorWHFast),
("ri_whfast512", IntegratorWHFast512),
("ri_saba", IntegratorSABA),
("ri_ias15", IntegratorIAS15),
("ri_mercurius", IntegratorMercurius),
("ri_trace", IntegratorTRACE),
("ri_janus", IntegratorJanus),
("ri_eos", IntegratorEOS),
("ri_bs", IntegratorBS),
("_odes", POINTER(POINTER(ODE))),
("_N_odes", c_int),
("_N_allocated_odes", c_int),
("_odes_warnings", c_int),
("_additional_forces", CFUNCTYPE(None,POINTER(Simulation))),
("_pre_timestep_modifications", CFUNCTYPE(None,POINTER(Simulation))),
("_post_timestep_modifications", CFUNCTYPE(None,POINTER(Simulation))),
("_heartbeat", CFUNCTYPE(None,POINTER(Simulation))),
("_key_callback", CFUNCTYPE(c_int,POINTER(Simulation), c_int)),
("_coefficient_of_restitution", CFUNCTYPE(c_double,POINTER(Simulation), c_double)),
("_collision_resolve", CFUNCTYPE(c_int,POINTER(Simulation), CollisionS)),
("_free_particle_ap", CFUNCTYPE(None, POINTER(Particle))),
("_extras_cleanup", CFUNCTYPE(None, POINTER(Simulation))),
("extras", c_void_p),
]


AFF = CFUNCTYPE(None,POINTER(Simulation))
CORFF = CFUNCTYPE(c_double,POINTER(Simulation), c_double)
COLRFF = CFUNCTYPE(c_int, POINTER(Simulation), CollisionS)
FPA = CFUNCTYPE(None, POINTER(Particle))

# Check if Simulation has same size upon import. Nothing will work if there is a mismatch.
clibrebound.reb_simulation_struct_size.res_type = c_size_t
simulation_size_c = clibrebound.reb_simulation_struct_size()

if simulation_size_c != sizeof(Simulation):
raise ImportError("Size of C struct `reb_simulation` differs from size of python class `Simulation`. This will lead to undefined behaviour. Make sure the C and Python versions of REBOUND are up-to-date and consistent. If you have installed REBOUND from source, you might need to recompile / reinstall the python package.")


# Import at the end to avoid circular dependence
from . import horizons
from . import data
from .simulationarchive import Simulationarchive

# --- FILE: ./token_list1_extractor.py ---

import sys
import os

# ПУТЬ К ТВОЕЙ МОДЕЛИ
MODEL_PATH = "/home/vitalij/AI/Phi-3-medium-128k-instruct-Q4_K_M.gguf"

print(f"🔍 [DEBUG] Проверка существования файла: {os.path.exists(MODEL_PATH)}")

try:
print("⏳ [DEBUG] Импорт llama_cpp...")
from llama_cpp import Llama
print("✅ [DEBUG] Импорт успешен.")
except ImportError as e:
print(f"❌ [CRITICAL] Не удалось импортировать llama_cpp: {e}")
sys.exit(1)

print("⚙️ [DEBUG] Попытка инициализации Llama с verbose=True...")

try:
# ВКЛЮЧАЕМ VERBOSE! Это покажет логи C++
llm = Llama(
model_path=MODEL_PATH,
n_ctx=2048,
n_gpu_layers=0, # Принудительно CPU, чтобы исключить GPU глюки
verbose=True # <--- Самое важное сейчас
)
print("✅ [SUCCESS] Модель загружена! Python жив.")

print(f"📊 Размер словаря: {llm.n_vocab()}")

except Exception as e:
print(f"\n❌ [PYTHON ERROR] Перехвачена ошибка Python: {e}")

print("🏁 [DEBUG] Скрипт завершен штатно.")
# --- FILE: ./token_list_extractor_1.py ---

import sys
from llama_cpp import Llama

# ПУТЬ К ТВОЕЙ МОДЕЛИ
MODEL_PATH = "/home/vitalij/AI/Phi-3-medium-128k-instruct-Q4_K_M.gguf"
OUTPUT_FILE = "phi3_full_vocabulary.txt"

def extract_tokens():
print(f"⚙️ [EXTRACTOR] Подключение к {MODEL_PATH} для извлечения словника...")
try:
# Загружаем LLama
llm = Llama(
model_path=MODEL_PATH,
n_ctx=2048, # <--- ДОДАНО: Встановлюємо явний ліміт контексту, щоб прибрати попередження
embedding=False, # Не тратим время на эмбеддинги
n_gpu_layers=0, # Запускаем без GPU (для словника CPU достатньо швидкий)
verbose=False
)
except Exception as e:
print(f"❌ ОШИБКА ЗАГРУЗКИ: {e}")
return

vocab_size = llm.n_vocab()
print(f"📊 Обнаружено токенов: {vocab_size}")

tokens_list = []

# Итерируемся по всем ID от 0 до N_vocab
for token_id in range(vocab_size):
try:
# llm.detokenize() превращает ID обратно в текст
token_bytes = llm.detokenize([token_id])

# Декодируем байты в строку
# replace - замінить помилкові байти на спецсимвол, щоб ми бачили, де проблема
token_text = token_bytes.decode('utf-8', errors='replace')

# --- DYNAMIS NOTE: Обробка пробілів ---
# SentencePiece/Llama токенайзери часто використовують символ ' ' (U+2581) замість пробілу.
# Твій код прибирає звичайні пробіли на початку. Це робить список чистішим для очей,
# але технічно змінює токен. Я залишаю це як є, якщо твоя мета — читабельність.
if token_text.startswith(' '):
token_text = token_text[1:]

# Экранируем перенос строки и табуляцию, чтобы не ломать структуру файла .txt
token_text_safe = token_text.replace('\n', '\\n').replace('\t', '\\t')

# Сохраняем ID и очищенный текст
tokens_list.append(f"{token_id}\t{token_text_safe}")

if token_id % 5000 == 0:
print(f" ... обработано {token_id}/{vocab_size}")

except Exception as e:
tokens_list.append(f"{token_id}\t[DECODE_ERROR]")

# Сохранение в файл
with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
f.write('\n'.join(tokens_list))

print(f"\n✅ ГОТОВО! Полный словарь ({vocab_size} токенов) сохранен в {OUTPUT_FILE}")

if __name__ == "__main__":
extract_tokens()

# --- FILE: ./token_list_extractor(1).py ---

import sys
from llama_cpp import Llama

# ПУТЬ К ТВОЕЙ МОДЕЛИ
MODEL_PATH = "/home/vitalij/AI/Phi-3-medium-128k-instruct-Q4_K_M.gguf"
OUTPUT_FILE = "phi3_full_vocabulary.txt"

def extract_tokens():
print(f"⚙️ [EXTRACTOR] Подключение к {MODEL_PATH} для извлечения словника...")
try:
# Загружаем LLama, нам нужен только токенизатор
llm = Llama(
model_path=MODEL_PATH,
embedding=False, # Не тратим время на эмбеддинги
n_gpu_layers=0, # Запускаем без GPU (быстрее)
verbose=False
)
except Exception as e:
print(f"❌ ОШИБКА ЗАГРУЗКИ: {e}")
return

vocab_size = llm.n_vocab()
print(f"📊 Обнаружено токенов: {vocab_size}")

tokens_list = []

# Итерируемся по всем ID от 0 до N_vocab
for token_id in range(vocab_size):
try:
# llm.detokenize() превращает ID обратно в текст
# ignore - для обработки служебных символов и мусора
token_bytes = llm.detokenize([token_id])
token_text = token_bytes.decode('utf-8', errors='ignore')

# Фильтрация для читаемости: убираем лишние пробелы (BPE артефакты)
if token_text.startswith(' '):
token_text = token_text[1:]

# Сохраняем ID и очищенный текст
tokens_list.append(f"{token_id}\t{token_text}")

if token_id % 5000 == 0:
print(f" ... обработано {token_id}/{vocab_size}")

except Exception as e:
# На случай, если какой-то ID пустой или не декодируется
tokens_list.append(f"{token_id}\t[DECODE_ERROR]")

# Сохранение в файл
with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
f.write('\n'.join(tokens_list))

print(f"\n✅ ГОТОВО! Полный словарь ({vocab_size} токенов) сохранен в {OUTPUT_FILE}")

if __name__ == "__main__":
extract_tokens()
# --- FILE: ./token_list_extractor.py ---

import sys
from llama_cpp import Llama

# ПУТЬ К ТВОЕЙ МОДЕЛИ
MODEL_PATH = "/home/vitalij/AI/Phi-3-medium-128k-instruct-Q4_K_M.gguf"
OUTPUT_FILE = "phi3_full_vocabulary.txt"

def extract_tokens():
print(f"⚙️ [EXTRACTOR] Подключение к {MODEL_PATH} для извлечения словника...")
try:
# Загружаем LLama, нам нужен только токенизатор
llm = Llama(
model_path=MODEL_PATH,
embedding=False, # Не тратим время на эмбеддинги
n_gpu_layers=0, # Запускаем без GPU (быстрее)
verbose=False
)
except Exception as e:
print(f"❌ ОШИБКА ЗАГРУЗКИ: {e}")
return

vocab_size = llm.n_vocab()
print(f"📊 Обнаружено токенов: {vocab_size}")

tokens_list = []

# Итерируемся по всем ID от 0 до N_vocab
for token_id in range(vocab_size):
try:
# llm.detokenize() превращает ID обратно в текст
# ignore - для обработки служебных символов и мусора
token_bytes = llm.detokenize([token_id])
token_text = token_bytes.decode('utf-8', errors='ignore')

# Фильтрация для читаемости: убираем лишние пробелы (BPE артефакты)
if token_text.startswith(' '):
token_text = token_text[1:]

# Сохраняем ID и очищенный текст
tokens_list.append(f"{token_id}\t{token_text}")

if token_id % 5000 == 0:
print(f" ... обработано {token_id}/{vocab_size}")

except Exception as e:
# На случай, если какой-то ID пустой или не декодируется
tokens_list.append(f"{token_id}\t[DECODE_ERROR]")

# Сохранение в файл
with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
f.write('\n'.join(tokens_list))

print(f"\n✅ ГОТОВО! Полный словарь ({vocab_size} токенов) сохранен в {OUTPUT_FILE}")

if __name__ == "__main__":
extract_tokens()
# --- FILE: ./universal_model_full_10.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_1.py ---

"""
universal_model_full.py

Полная (детерминированная) реализация Универсальной Аналитической Модели,
которую ты описал в текстовом файле:

- Базисные векторы V_i
- Вход I(t)
- Матрица весов w_ij и оператор G_i
- Активность A_i(t)
- Память P[n]_i(t)
- Энтропия S(t)
- Топологический интеграл Sigma(t)
- Контекст C(t)
- Оператор T_i(t) = LSTM + k-means
- Итоговый функционал F = ∫ f(t) dt

Всё сделано без рандома, чтобы результаты были воспроизводимыми и чисто аналитическими.
"""

from __future__ import annotations
import numpy as np
import math
from dataclasses import dataclass
from typing import Tuple, Dict


# ============================
# КОНФИГУРАЦИЯ МОДЕЛИ
# ============================

@dataclass
class UniversalConfig:
N: int = 10 # размерность базисных векторов V_i
M_dim: int = 10 # размерность после tau (берём = N по умолчанию)
k_B: float = 1.0 # "энтропийный" коэффициент
lambda_decay: float = 0.5 # λ в P[n]
alpha_kmeans: float = 0.5 # вес k-means в T_i
kappa_scale: float = 0.1 # κ в A_i(t)
dt: float = 0.1
t0: float = 0.0
tn: float = 5.0
memory_horizon: float = 1.0 # "n" в P[n]
# параметры LSTM
lstm_hidden_dim: int = 1
# режим для входа I(t): "static" или "oscill"
input_mode: str = "oscill" # "static" даёт ровно то, что ты уже видел


# ============================
# LSTM-ЯЧЕЙКА НА NUMPY
# ============================

class LSTMCell:
"""
Минималистичная, но полноценная LSTM-ячейка.
hidden_dim может быть >1, но по умолчанию 1.
"""

def __init__(self, input_dim: int, hidden_dim: int = 1):
self.input_dim = input_dim
self.hidden_dim = hidden_dim

size_x = (4 * hidden_dim, input_dim)
size_h = (4 * hidden_dim, hidden_dim)

self.W_x = np.zeros(size_x, dtype=float)
self.W_h = np.zeros(size_h, dtype=float)
self.b = np.zeros(4 * hidden_dim, dtype=float)

# Детерминированная инициализация через sin/cos:
for r in range(4 * hidden_dim):
for c in range(input_dim):
self.W_x[r, c] = math.sin((r + 1) * (c + 1)) * 0.1
for r in range(4 * hidden_dim):
for c in range(hidden_dim):
self.W_h[r, c] = math.cos((r + 1) * (c + 1)) * 0.1

def step(
self,
x_t: np.ndarray,
h_prev: np.ndarray,
c_prev: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
"""
x_t: shape (input_dim,)
h_prev, c_prev: shape (hidden_dim,)
"""
x_t = x_t.reshape(1, -1) # (1, input_dim)
h_prev_vec = h_prev.reshape(1, -1) # (1, hidden_dim)

z = (self.W_x @ x_t.T + self.W_h @ h_prev_vec.T + self.b.reshape(-1, 1)).flatten()

# разбиваем на 4 блока по hidden_dim
hdim = self.hidden_dim
i = 1.0 / (1.0 + np.exp(-z[0:hdim])) # input gate
f = 1.0 / (1.0 + np.exp(-z[hdim:2*hdim])) # forget gate
o = 1.0 / (1.0 + np.exp(-z[2*hdim:3*hdim])) # output gate
g = np.tanh(z[3*hdim:4*hdim]) # candidate

c_t = f * c_prev + i * g
h_t = o * np.tanh(c_t)
return h_t, c_t


# ============================
# K-MEANS ДЛЯ 1D+ (ПОСТР)
# ============================

def kmeans_1d(values: np.ndarray, n_clusters: int = 2, n_iter: int = 5) -> np.ndarray:
"""
Простой k-means по одномерным значениям (как в аналитической модели).
"""
vals = values.astype(float)
v_min, v_max = float(vals.min()), float(vals.max())
if v_min == v_max:
return np.array([v_min] * n_clusters, dtype=float)
centers = np.linspace(v_min, v_max, n_clusters)
for _ in range(n_iter):
# assign
assignments = np.argmin(np.abs(vals[:, None] - centers[None, :]), axis=1)
# recompute
for k_c in range(n_clusters):
mask = assignments == k_c
if np.any(mask):
centers[k_c] = float(vals[mask].mean())
return centers


# ============================
# ОСНОВНОЙ КЛАСС МОДЕЛИ
# ============================

class UniversalAnalyticalModel:
def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time_grid = np.arange(cfg.t0, cfg.tn + cfg.dt, cfg.dt)
self.num_steps = len(self.time_grid)
self.memory_steps = int(cfg.memory_horizon / cfg.dt)

# 1. Базисные векторы V_i (канонический базис)
self.V = np.eye(cfg.N)

# 2. Входные веса w_j
self.w = np.array([j + 1 for j in range(cfg.N)], dtype=float)
self.w /= self.w.sum()

# 3. Матрица w_ij
self.w_ij = self._build_w_ij()

# 4. Метаданные D, D_i, K_i, O_emb
self.D = self._build_D()
self.D_i = self._build_D_i()
self.K_i = self._build_K_i()
self.O_emb = self._build_O_emb()

# 5. Предрасчёт Sigma(t)
self.Sigma_t_values = np.zeros(self.num_steps, dtype=float)

# 6. LSTM и скрытые состояния для каждого i
self.lstm = LSTMCell(input_dim=cfg.N, hidden_dim=cfg.lstm_hidden_dim)
self.hidden_h = np.zeros((cfg.N, cfg.lstm_hidden_dim), dtype=float)
self.hidden_c = np.zeros((cfg.N, cfg.lstm_hidden_dim), dtype=float)

# 7. Матрица взаимодействий W_ij
self.W_mat = self._build_interaction_matrix()

# сразу считаем Sigma(t)
self._compute_sigma_trajectory()

# ---------- Конструкции матриц ----------

def _build_w_ij(self) -> np.ndarray:
N = self.cfg.N
w_ij = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
w_ij[i, j] = 1.0 / (1.0 + i + j)
w_ij[i] /= w_ij[i].sum()
return w_ij

def _build_D(self) -> np.ndarray:
N, M_dim = self.cfg.N, self.cfg.M_dim
D = np.zeros((M_dim, N), dtype=float)
for a in range(M_dim):
for b in range(N):
D[a, b] = math.sin((a + 1) * (b + 1)) / (1.0 + a + b)
return D

def _build_D_i(self) -> np.ndarray:
N = self.cfg.N
D_i = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
D_i[i, j] = math.cos((i + 1) * (j + 1)) / (1.0 + i + j)
return D_i

def _build_K_i(self) -> np.ndarray:
N = self.cfg.N
K_i = np.zeros((N, 3), dtype=float)
for i in range(N):
K_i[i, 0] = (i + 1) / N
K_i[i, 1] = ((i + 1) ** 2) / (N ** 2)
K_i[i, 2] = 1.0 / (i + 2)
return K_i

def _build_O_emb(self) -> np.ndarray:
N = self.cfg.N
O_emb = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
O_emb[i, j] = (i + 1 + j + 1) / (2.0 * N)
return O_emb

# ---------- Вход I(t) ----------

def I_t(self, t_index: int) -> np.ndarray:
"""
I(t) = ∑ w_j V_j, но с возможностью небольшой осцилляции по времени,
чтобы не иметь строго статичную систему.
"""
base = self.w.copy()
if self.cfg.input_mode == "static":
return base
else:
# осцилляции веса вокруг базового w (мягко, чтобы не ломать нормировку)
t = self.time_grid[t_index]
osc = 0.1 * np.sin(0.7 * t + np.arange(self.cfg.N))
x = base * (1.0 + osc)
s = x.sum()
if s == 0:
return base
return x / s

# ---------- tau & S(t) блок ----------

@staticmethod
def tau_operator(x: np.ndarray, D_param: np.ndarray) -> np.ndarray:
return np.tanh(D_param @ x)

def S_vec_t(self, t_index: int) -> np.ndarray:
"""
S(t) в смысле вектора после tau(I(t), D)
"""
x = self.I_t(t_index)
return self.tau_operator(x, self.D)

def _A_from_D(self, D_param: np.ndarray) -> float:
return float(np.mean(D_param))

def _build_interaction_matrix(self) -> np.ndarray:
N = self.cfg.N
W_mat = np.zeros((N, N), dtype=float)
A_D = self._A_from_D(self.D)
for i in range(N):
for j in range(N):
vi = self.V[i]
vj = self.V[j]
denom = np.linalg.norm(vi) * np.linalg.norm(vj)
if denom == 0:
cos_ij = 0.0
else:
cos_ij = float(np.dot(vi, vj) / denom)
W_mat[i, j] = cos_ij * A_D
return W_mat

def M_t(self, t_index: int) -> np.ndarray:
"""
M(t) = W * S(t)
"""
S_vec = self.S_vec_t(t_index)
N = self.cfg.N
if S_vec.shape[0] != N:
if S_vec.shape[0] > N:
S_vec = S_vec[:N]
else:
S_vec = np.pad(S_vec, (0, N - S_vec.shape[0]))
return self.W_mat @ S_vec

def entropy_S_t(self, t_index: int) -> float:
"""
Энтропия S(t) = -∑ p_i ln p_i, где p_i нормализованный |M(t)|
"""
m_vec = np.abs(self.M_t(t_index))
if m_vec.sum() == 0:
p = np.ones_like(m_vec) / len(m_vec)
else:
p = m_vec / m_vec.sum()
return float(-np.sum(p * np.log(p + 1e-12)))

# ---------- A_i(t), P[n]_i(t), Sigma(t) ----------

def distance_objects(self, i: int, j: int) -> float:
return float(np.linalg.norm(self.O_emb[i] - self.O_emb[j]))

def A_i_t(self, i: int, t_index: int) -> float:
N = self.cfg.N
d_sum = 0.0
for j in range(N):
if j == i:
continue
d_sum += self.distance_objects(i, j)
d_avg = d_sum / (N - 1)
C_i = (i + 1) / N
Norm_att = 0.9
return (
self.cfg.kappa_scale
* (d_avg ** 2)
* C_i
* Norm_att
)

def P_n_i(self, i: int, t_index: int) -> float:
"""
P[n]_i(t) = интеграл A_i(t') exp(-λ (t - t')) dt' по окну памяти
"""
t_current = self.time_grid[t_index]
total = 0.0
start_index = max(0, t_index - self.memory_steps)
for idx in range(start_index, t_index + 1):
t_prime = self.time_grid[idx]
A_val = self.A_i_t(i, idx)
total += A_val * math.exp(-self.cfg.lambda_decay * (t_current - t_prime)) * self.cfg.dt
return total

def _kappa_input(self, x: np.ndarray) -> float:
return float(np.linalg.norm(x))

def _compute_sigma_trajectory(self):
"""
Σ(t) = ∫ S(I(t')) * κ(A(t')) dt'
"""
cfg = self.cfg
acc = 0.0
for ti, _t in enumerate(self.time_grid):
# S(I(t')): энтропия входа
Ivec = self.I_t(ti)
p = np.abs(Ivec)
if p.sum() == 0:
p = np.ones_like(p) / len(p)
else:
p = p / p.sum()
S_I = -np.sum(p * np.log(p + 1e-12))

# средняя A(t')
A_mean = 0.0
for i in range(cfg.N):
A_mean += self.A_i_t(i, ti)
A_mean /= cfg.N

acc += S_I * self._kappa_input(np.array([A_mean])) * cfg.dt
self.Sigma_t_values[ti] = acc

# ---------- Контекст C(t) ----------

def C_context_scalar(self, t_index: int) -> float:
"""
C(Input, Σ, K_i) сведён к скаляру C(t), зависящему
от входа и накопленной Σ(t).
"""
Ivec = self.I_t(t_index)
kappa_in = self._kappa_input(Ivec)

acc_vec = np.zeros(self.cfg.N, dtype=float)
for i in range(self.cfg.N):
v_comb = np.zeros(self.cfg.N, dtype=float)
for j in range(self.cfg.N):
v_comb += self.w_ij[i, j] * self.V[j]
acc_vec += v_comb * kappa_in

sigma_factor = 1.0 + self.Sigma_t_values[t_index]
return float(np.mean(acc_vec) * sigma_factor)

# ---------- T_i(t) = LSTM(Input_i, K_i) + α*k-means(D_i) ----------

def T_i_t(self, i: int, t_index: int) -> float:
"""
Полная формула T_i:
- LSTM(Input(t), K_i) через скрытые состояния h_i, c_i
- плюс α * kmeans(D_i)
"""
cfg = self.cfg

x_t = self.I_t(t_index)
k_params = self.K_i[i]

# модифицируем предыдущее состояние через K_i
h_prev = self.hidden_h[i] + 0.1 * k_params[0]
c_prev = self.hidden_c[i] + 0.1 * k_params[1]

h_t, c_t = self.lstm.step(x_t, h_prev, c_prev)
self.hidden_h[i] = h_t
self.hidden_c[i] = c_t

# k-means по строке D_i[i]
centers = kmeans_1d(self.D_i[i], n_clusters=2, n_iter=5)
kmeans_val = float(centers.mean())

# берём, например, среднее по hidden_dim
h_scalar = float(h_t.mean())

return h_scalar + self.cfg.alpha_kmeans * kmeans_val

# ---------- Итоговый функционал F(t), F ----------

def compute_F(self) -> Tuple[float, Dict[str, np.ndarray]]:
"""
Считаем:
f(t) = (∑_i A_i(t) P[n]_i(t) T_i(t)) * exp(-S(t)/k_B) * C(t)
F = ∫ f(t) dt
Возвращает F_total и словарь массивов по времени.
"""
cfg = self.cfg
F_total = 0.0

F_t_values = []
S_t_values = []
A0_vals = []
P0_vals = []

for t_index, t in enumerate(self.time_grid):
S_val = self.entropy_S_t(t_index)
S_t_values.append(S_val)

C_val = self.C_context_scalar(t_index)

inner_sum = 0.0
for i in range(cfg.N):
A_val = self.A_i_t(i, t_index)
P_val = self.P_n_i(i, t_index)
T_val = self.T_i_t(i, t_index)
inner_sum += A_val * P_val * T_val

if i == 0:
A0_vals.append(A_val)
P0_vals.append(P_val)

integrand = inner_sum * math.exp(-S_val / cfg.k_B) * C_val
F_t_values.append(integrand)
F_total += integrand * cfg.dt

arrays = dict(
F_t=np.array(F_t_values),
S_t=np.array(S_t_values),
A0_t=np.array(A0_vals),
P0_t=np.array(P0_vals),
Sigma_t=self.Sigma_t_values.copy(),
time=self.time_grid.copy(),
W_mat=self.W_mat.copy(),
)
return F_total, arrays


# ============================
# CLI-ТЕСТ (как твой test)
# ============================

if __name__ == "__main__":
cfg = UniversalConfig()
model = UniversalAnalyticalModel(cfg)
F_val, arrays = model.compute_F()

print("\n==============================================")
print(" UNIVERSAL ANALYTICAL MODEL - FULL VERSION")
print("==============================================")
print(f"Time interval: [{cfg.t0}, {cfg.tn}] with dt = {cfg.dt}, steps = {model.num_steps}")
print(f"Dimension N (V_i, I(t), etc.): {cfg.N}")
print("----------------------------------------------")
print("F =", F_val)
print("==============================================\n")

try:
import matplotlib.pyplot as plt

t_vals = arrays["time"]

# A_0(t) и P[n]_0(t)
plt.figure()
plt.plot(t_vals, arrays["A0_t"], label="A_0(t)")
plt.plot(t_vals, arrays["P0_t"], label="P[n]_0(t)")
plt.xlabel("t")
plt.ylabel("value")
plt.title("Activity A_0(t) and Accumulation P[n]_0(t)")
plt.legend()
plt.tight_layout()
plt.savefig("A0_P0_vs_t_full.png")

# S(t)
plt.figure()
plt.plot(t_vals, arrays["S_t"])
plt.xlabel("t")
plt.ylabel("S(t)")
plt.title("Entropy S(t)")
plt.tight_layout()
plt.savefig("S_t_full.png")

# Σ(t)
plt.figure()
plt.plot(t_vals, arrays["Sigma_t"])
plt.xlabel("t")
plt.ylabel("Sigma(t)")
plt.title("Topology Sigma(t)")
plt.tight_layout()
plt.savefig("Sigma_t_full.png")

# f(t) и накопленный интеграл
plt.figure()
plt.plot(t_vals, arrays["F_t"], label="integrand f(t)")
F_cum = np.cumsum(arrays["F_t"]) * cfg.dt
plt.plot(t_vals, F_cum, label="cumulative F(t)")
plt.xlabel("t")
plt.ylabel("value")
plt.title("Instantaneous and cumulative F(t)")
plt.legend()
plt.tight_layout()
plt.savefig("F_t_and_cumulative_full.png")

# Heatmap W_{ij}
plt.figure()
plt.imshow(arrays["W_mat"], aspect="auto")
plt.colorbar(label="W_ij")
plt.xlabel("j")
plt.ylabel("i")
plt.title("Interaction matrix W_ij")
plt.tight_layout()
plt.savefig("W_matrix_heatmap_full.png")

print(
"Plots saved:",
"A0_P0_vs_t_full.png, S_t_full.png, Sigma_t_full.png, "
"F_t_and_cumulative_full.png, W_matrix_heatmap_full.png",
)

except Exception as e:
print("Plotting skipped due to error:", e)

# --- FILE: ./universal_model_full_2.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_3.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_4.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_5.py ---

"""
universal_model_full.py

Полная (детерминированная) реализация Универсальной Аналитической Модели,
которую ты описал в текстовом файле:

- Базисные векторы V_i
- Вход I(t)
- Матрица весов w_ij и оператор G_i
- Активность A_i(t)
- Память P[n]_i(t)
- Энтропия S(t)
- Топологический интеграл Sigma(t)
- Контекст C(t)
- Оператор T_i(t) = LSTM + k-means
- Итоговый функционал F = ∫ f(t) dt

Всё сделано без рандома, чтобы результаты были воспроизводимыми и чисто аналитическими.
"""

from __future__ import annotations
import numpy as np
import math
from dataclasses import dataclass
from typing import Tuple, Dict


# ============================
# КОНФИГУРАЦИЯ МОДЕЛИ
# ============================

@dataclass
class UniversalConfig:
N: int = 10 # размерность базисных векторов V_i
M_dim: int = 10 # размерность после tau (берём = N по умолчанию)
k_B: float = 1.0 # "энтропийный" коэффициент
lambda_decay: float = 0.5 # λ в P[n]
alpha_kmeans: float = 0.5 # вес k-means в T_i
kappa_scale: float = 0.1 # κ в A_i(t)
dt: float = 0.1
t0: float = 0.0
tn: float = 5.0
memory_horizon: float = 1.0 # "n" в P[n]
# параметры LSTM
lstm_hidden_dim: int = 1
# режим для входа I(t): "static" или "oscill"
input_mode: str = "oscill" # "static" даёт ровно то, что ты уже видел


# ============================
# LSTM-ЯЧЕЙКА НА NUMPY
# ============================

class LSTMCell:
"""
Минималистичная, но полноценная LSTM-ячейка.
hidden_dim может быть >1, но по умолчанию 1.
"""

def __init__(self, input_dim: int, hidden_dim: int = 1):
self.input_dim = input_dim
self.hidden_dim = hidden_dim

size_x = (4 * hidden_dim, input_dim)
size_h = (4 * hidden_dim, hidden_dim)

self.W_x = np.zeros(size_x, dtype=float)
self.W_h = np.zeros(size_h, dtype=float)
self.b = np.zeros(4 * hidden_dim, dtype=float)

# Детерминированная инициализация через sin/cos:
for r in range(4 * hidden_dim):
for c in range(input_dim):
self.W_x[r, c] = math.sin((r + 1) * (c + 1)) * 0.1
for r in range(4 * hidden_dim):
for c in range(hidden_dim):
self.W_h[r, c] = math.cos((r + 1) * (c + 1)) * 0.1

def step(
self,
x_t: np.ndarray,
h_prev: np.ndarray,
c_prev: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
"""
x_t: shape (input_dim,)
h_prev, c_prev: shape (hidden_dim,)
"""
x_t = x_t.reshape(1, -1) # (1, input_dim)
h_prev_vec = h_prev.reshape(1, -1) # (1, hidden_dim)

z = (self.W_x @ x_t.T + self.W_h @ h_prev_vec.T + self.b.reshape(-1, 1)).flatten()

# разбиваем на 4 блока по hidden_dim
hdim = self.hidden_dim
i = 1.0 / (1.0 + np.exp(-z[0:hdim])) # input gate
f = 1.0 / (1.0 + np.exp(-z[hdim:2*hdim])) # forget gate
o = 1.0 / (1.0 + np.exp(-z[2*hdim:3*hdim])) # output gate
g = np.tanh(z[3*hdim:4*hdim]) # candidate

c_t = f * c_prev + i * g
h_t = o * np.tanh(c_t)
return h_t, c_t


# ============================
# K-MEANS ДЛЯ 1D+ (ПОСТР)
# ============================

def kmeans_1d(values: np.ndarray, n_clusters: int = 2, n_iter: int = 5) -> np.ndarray:
"""
Простой k-means по одномерным значениям (как в аналитической модели).
"""
vals = values.astype(float)
v_min, v_max = float(vals.min()), float(vals.max())
if v_min == v_max:
return np.array([v_min] * n_clusters, dtype=float)
centers = np.linspace(v_min, v_max, n_clusters)
for _ in range(n_iter):
# assign
assignments = np.argmin(np.abs(vals[:, None] - centers[None, :]), axis=1)
# recompute
for k_c in range(n_clusters):
mask = assignments == k_c
if np.any(mask):
centers[k_c] = float(vals[mask].mean())
return centers


# ============================
# ОСНОВНОЙ КЛАСС МОДЕЛИ
# ============================

class UniversalAnalyticalModel:
def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time_grid = np.arange(cfg.t0, cfg.tn + cfg.dt, cfg.dt)
self.num_steps = len(self.time_grid)
self.memory_steps = int(cfg.memory_horizon / cfg.dt)

# 1. Базисные векторы V_i (канонический базис)
self.V = np.eye(cfg.N)

# 2. Входные веса w_j
self.w = np.array([j + 1 for j in range(cfg.N)], dtype=float)
self.w /= self.w.sum()

# 3. Матрица w_ij
self.w_ij = self._build_w_ij()

# 4. Метаданные D, D_i, K_i, O_emb
self.D = self._build_D()
self.D_i = self._build_D_i()
self.K_i = self._build_K_i()
self.O_emb = self._build_O_emb()

# 5. Предрасчёт Sigma(t)
self.Sigma_t_values = np.zeros(self.num_steps, dtype=float)

# 6. LSTM и скрытые состояния для каждого i
self.lstm = LSTMCell(input_dim=cfg.N, hidden_dim=cfg.lstm_hidden_dim)
self.hidden_h = np.zeros((cfg.N, cfg.lstm_hidden_dim), dtype=float)
self.hidden_c = np.zeros((cfg.N, cfg.lstm_hidden_dim), dtype=float)

# 7. Матрица взаимодействий W_ij
self.W_mat = self._build_interaction_matrix()

# сразу считаем Sigma(t)
self._compute_sigma_trajectory()

# ---------- Конструкции матриц ----------

def _build_w_ij(self) -> np.ndarray:
N = self.cfg.N
w_ij = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
w_ij[i, j] = 1.0 / (1.0 + i + j)
w_ij[i] /= w_ij[i].sum()
return w_ij

def _build_D(self) -> np.ndarray:
N, M_dim = self.cfg.N, self.cfg.M_dim
D = np.zeros((M_dim, N), dtype=float)
for a in range(M_dim):
for b in range(N):
D[a, b] = math.sin((a + 1) * (b + 1)) / (1.0 + a + b)
return D

def _build_D_i(self) -> np.ndarray:
N = self.cfg.N
D_i = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
D_i[i, j] = math.cos((i + 1) * (j + 1)) / (1.0 + i + j)
return D_i

def _build_K_i(self) -> np.ndarray:
N = self.cfg.N
K_i = np.zeros((N, 3), dtype=float)
for i in range(N):
K_i[i, 0] = (i + 1) / N
K_i[i, 1] = ((i + 1) ** 2) / (N ** 2)
K_i[i, 2] = 1.0 / (i + 2)
return K_i

def _build_O_emb(self) -> np.ndarray:
N = self.cfg.N
O_emb = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
O_emb[i, j] = (i + 1 + j + 1) / (2.0 * N)
return O_emb

# ---------- Вход I(t) ----------

def I_t(self, t_index: int) -> np.ndarray:
"""
I(t) = ∑ w_j V_j, но с возможностью небольшой осцилляции по времени,
чтобы не иметь строго статичную систему.
"""
base = self.w.copy()
if self.cfg.input_mode == "static":
return base
else:
# осцилляции веса вокруг базового w (мягко, чтобы не ломать нормировку)
t = self.time_grid[t_index]
osc = 0.1 * np.sin(0.7 * t + np.arange(self.cfg.N))
x = base * (1.0 + osc)
s = x.sum()
if s == 0:
return base
return x / s

# ---------- tau & S(t) блок ----------

@staticmethod
def tau_operator(x: np.ndarray, D_param: np.ndarray) -> np.ndarray:
return np.tanh(D_param @ x)

def S_vec_t(self, t_index: int) -> np.ndarray:
"""
S(t) в смысле вектора после tau(I(t), D)
"""
x = self.I_t(t_index)
return self.tau_operator(x, self.D)

def _A_from_D(self, D_param: np.ndarray) -> float:
return float(np.mean(D_param))

def _build_interaction_matrix(self) -> np.ndarray:
N = self.cfg.N
W_mat = np.zeros((N, N), dtype=float)
A_D = self._A_from_D(self.D)
for i in range(N):
for j in range(N):
vi = self.V[i]
vj = self.V[j]
denom = np.linalg.norm(vi) * np.linalg.norm(vj)
if denom == 0:
cos_ij = 0.0
else:
cos_ij = float(np.dot(vi, vj) / denom)
W_mat[i, j] = cos_ij * A_D
return W_mat

def M_t(self, t_index: int) -> np.ndarray:
"""
M(t) = W * S(t)
"""
S_vec = self.S_vec_t(t_index)
N = self.cfg.N
if S_vec.shape[0] != N:
if S_vec.shape[0] > N:
S_vec = S_vec[:N]
else:
S_vec = np.pad(S_vec, (0, N - S_vec.shape[0]))
return self.W_mat @ S_vec

def entropy_S_t(self, t_index: int) -> float:
"""
Энтропия S(t) = -∑ p_i ln p_i, где p_i нормализованный |M(t)|
"""
m_vec = np.abs(self.M_t(t_index))
if m_vec.sum() == 0:
p = np.ones_like(m_vec) / len(m_vec)
else:
p = m_vec / m_vec.sum()
return float(-np.sum(p * np.log(p + 1e-12)))

# ---------- A_i(t), P[n]_i(t), Sigma(t) ----------

def distance_objects(self, i: int, j: int) -> float:
return float(np.linalg.norm(self.O_emb[i] - self.O_emb[j]))

def A_i_t(self, i: int, t_index: int) -> float:
N = self.cfg.N
d_sum = 0.0
for j in range(N):
if j == i:
continue
d_sum += self.distance_objects(i, j)
d_avg = d_sum / (N - 1)
C_i = (i + 1) / N
Norm_att = 0.9
return (
self.cfg.kappa_scale
* (d_avg ** 2)
* C_i
* Norm_att
)

def P_n_i(self, i: int, t_index: int) -> float:
"""
P[n]_i(t) = интеграл A_i(t') exp(-λ (t - t')) dt' по окну памяти
"""
t_current = self.time_grid[t_index]
total = 0.0
start_index = max(0, t_index - self.memory_steps)
for idx in range(start_index, t_index + 1):
t_prime = self.time_grid[idx]
A_val = self.A_i_t(i, idx)
total += A_val * math.exp(-self.cfg.lambda_decay * (t_current - t_prime)) * self.cfg.dt
return total

def _kappa_input(self, x: np.ndarray) -> float:
return float(np.linalg.norm(x))

def _compute_sigma_trajectory(self):
"""
Σ(t) = ∫ S(I(t')) * κ(A(t')) dt'
"""
cfg = self.cfg
acc = 0.0
for ti, _t in enumerate(self.time_grid):
# S(I(t')): энтропия входа
Ivec = self.I_t(ti)
p = np.abs(Ivec)
if p.sum() == 0:
p = np.ones_like(p) / len(p)
else:
p = p / p.sum()
S_I = -np.sum(p * np.log(p + 1e-12))

# средняя A(t')
A_mean = 0.0
for i in range(cfg.N):
A_mean += self.A_i_t(i, ti)
A_mean /= cfg.N

acc += S_I * self._kappa_input(np.array([A_mean])) * cfg.dt
self.Sigma_t_values[ti] = acc

# ---------- Контекст C(t) ----------

def C_context_scalar(self, t_index: int) -> float:
"""
C(Input, Σ, K_i) сведён к скаляру C(t), зависящему
от входа и накопленной Σ(t).
"""
Ivec = self.I_t(t_index)
kappa_in = self._kappa_input(Ivec)

acc_vec = np.zeros(self.cfg.N, dtype=float)
for i in range(self.cfg.N):
v_comb = np.zeros(self.cfg.N, dtype=float)
for j in range(self.cfg.N):
v_comb += self.w_ij[i, j] * self.V[j]
acc_vec += v_comb * kappa_in

sigma_factor = 1.0 + self.Sigma_t_values[t_index]
return float(np.mean(acc_vec) * sigma_factor)

# ---------- T_i(t) = LSTM(Input_i, K_i) + α*k-means(D_i) ----------

def T_i_t(self, i: int, t_index: int) -> float:
"""
Полная формула T_i:
- LSTM(Input(t), K_i) через скрытые состояния h_i, c_i
- плюс α * kmeans(D_i)
"""
cfg = self.cfg

x_t = self.I_t(t_index)
k_params = self.K_i[i]

# модифицируем предыдущее состояние через K_i
h_prev = self.hidden_h[i] + 0.1 * k_params[0]
c_prev = self.hidden_c[i] + 0.1 * k_params[1]

h_t, c_t = self.lstm.step(x_t, h_prev, c_prev)
self.hidden_h[i] = h_t
self.hidden_c[i] = c_t

# k-means по строке D_i[i]
centers = kmeans_1d(self.D_i[i], n_clusters=2, n_iter=5)
kmeans_val = float(centers.mean())

# берём, например, среднее по hidden_dim
h_scalar = float(h_t.mean())

return h_scalar + self.cfg.alpha_kmeans * kmeans_val

# ---------- Итоговый функционал F(t), F ----------

def compute_F(self) -> Tuple[float, Dict[str, np.ndarray]]:
"""
Считаем:
f(t) = (∑_i A_i(t) P[n]_i(t) T_i(t)) * exp(-S(t)/k_B) * C(t)
F = ∫ f(t) dt
Возвращает F_total и словарь массивов по времени.
"""
cfg = self.cfg
F_total = 0.0

F_t_values = []
S_t_values = []
A0_vals = []
P0_vals = []

for t_index, t in enumerate(self.time_grid):
S_val = self.entropy_S_t(t_index)
S_t_values.append(S_val)

C_val = self.C_context_scalar(t_index)

inner_sum = 0.0
for i in range(cfg.N):
A_val = self.A_i_t(i, t_index)
P_val = self.P_n_i(i, t_index)
T_val = self.T_i_t(i, t_index)
inner_sum += A_val * P_val * T_val

if i == 0:
A0_vals.append(A_val)
P0_vals.append(P_val)

integrand = inner_sum * math.exp(-S_val / cfg.k_B) * C_val
F_t_values.append(integrand)
F_total += integrand * cfg.dt

arrays = dict(
F_t=np.array(F_t_values),
S_t=np.array(S_t_values),
A0_t=np.array(A0_vals),
P0_t=np.array(P0_vals),
Sigma_t=self.Sigma_t_values.copy(),
time=self.time_grid.copy(),
W_mat=self.W_mat.copy(),
)
return F_total, arrays


# ============================
# CLI-ТЕСТ (как твой test)
# ============================

if __name__ == "__main__":
cfg = UniversalConfig()
model = UniversalAnalyticalModel(cfg)
F_val, arrays = model.compute_F()

print("\n==============================================")
print(" UNIVERSAL ANALYTICAL MODEL - FULL VERSION")
print("==============================================")
print(f"Time interval: [{cfg.t0}, {cfg.tn}] with dt = {cfg.dt}, steps = {model.num_steps}")
print(f"Dimension N (V_i, I(t), etc.): {cfg.N}")
print("----------------------------------------------")
print("F =", F_val)
print("==============================================\n")

try:
import matplotlib.pyplot as plt

t_vals = arrays["time"]

# A_0(t) и P[n]_0(t)
plt.figure()
plt.plot(t_vals, arrays["A0_t"], label="A_0(t)")
plt.plot(t_vals, arrays["P0_t"], label="P[n]_0(t)")
plt.xlabel("t")
plt.ylabel("value")
plt.title("Activity A_0(t) and Accumulation P[n]_0(t)")
plt.legend()
plt.tight_layout()
plt.savefig("A0_P0_vs_t_full.png")

# S(t)
plt.figure()
plt.plot(t_vals, arrays["S_t"])
plt.xlabel("t")
plt.ylabel("S(t)")
plt.title("Entropy S(t)")
plt.tight_layout()
plt.savefig("S_t_full.png")

# Σ(t)
plt.figure()
plt.plot(t_vals, arrays["Sigma_t"])
plt.xlabel("t")
plt.ylabel("Sigma(t)")
plt.title("Topology Sigma(t)")
plt.tight_layout()
plt.savefig("Sigma_t_full.png")

# f(t) и накопленный интеграл
plt.figure()
plt.plot(t_vals, arrays["F_t"], label="integrand f(t)")
F_cum = np.cumsum(arrays["F_t"]) * cfg.dt
plt.plot(t_vals, F_cum, label="cumulative F(t)")
plt.xlabel("t")
plt.ylabel("value")
plt.title("Instantaneous and cumulative F(t)")
plt.legend()
plt.tight_layout()
plt.savefig("F_t_and_cumulative_full.png")

# Heatmap W_{ij}
plt.figure()
plt.imshow(arrays["W_mat"], aspect="auto")
plt.colorbar(label="W_ij")
plt.xlabel("j")
plt.ylabel("i")
plt.title("Interaction matrix W_ij")
plt.tight_layout()
plt.savefig("W_matrix_heatmap_full.png")

print(
"Plots saved:",
"A0_P0_vs_t_full.png, S_t_full.png, Sigma_t_full.png, "
"F_t_and_cumulative_full.png, W_matrix_heatmap_full.png",
)

except Exception as e:
print("Plotting skipped due to error:", e)

# --- FILE: ./universal_model_full_6.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_7.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_8.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./universal_model_full_9.py ---

"""
universal_model_full.py

Полная (детерминированная) реализация Универсальной Аналитической Модели,
которую ты описал в текстовом файле:

- Базисные векторы V_i
- Вход I(t)
- Матрица весов w_ij и оператор G_i
- Активность A_i(t)
- Память P[n]_i(t)
- Энтропия S(t)
- Топологический интеграл Sigma(t)
- Контекст C(t)
- Оператор T_i(t) = LSTM + k-means
- Итоговый функционал F = ∫ f(t) dt

Всё сделано без рандома, чтобы результаты были воспроизводимыми и чисто аналитическими.
"""

from __future__ import annotations
import numpy as np
import math
from dataclasses import dataclass
from typing import Tuple, Dict


# ============================
# КОНФИГУРАЦИЯ МОДЕЛИ
# ============================

@dataclass
class UniversalConfig:
N: int = 10 # размерность базисных векторов V_i
M_dim: int = 10 # размерность после tau (берём = N по умолчанию)
k_B: float = 1.0 # "энтропийный" коэффициент
lambda_decay: float = 0.5 # λ в P[n]
alpha_kmeans: float = 0.5 # вес k-means в T_i
kappa_scale: float = 0.1 # κ в A_i(t)
dt: float = 0.1
t0: float = 0.0
tn: float = 5.0
memory_horizon: float = 1.0 # "n" в P[n]
# параметры LSTM
lstm_hidden_dim: int = 1
# режим для входа I(t): "static" или "oscill"
input_mode: str = "oscill" # "static" даёт ровно то, что ты уже видел


# ============================
# LSTM-ЯЧЕЙКА НА NUMPY
# ============================

class LSTMCell:
"""
Минималистичная, но полноценная LSTM-ячейка.
hidden_dim может быть >1, но по умолчанию 1.
"""

def __init__(self, input_dim: int, hidden_dim: int = 1):
self.input_dim = input_dim
self.hidden_dim = hidden_dim

size_x = (4 * hidden_dim, input_dim)
size_h = (4 * hidden_dim, hidden_dim)

self.W_x = np.zeros(size_x, dtype=float)
self.W_h = np.zeros(size_h, dtype=float)
self.b = np.zeros(4 * hidden_dim, dtype=float)

# Детерминированная инициализация через sin/cos:
for r in range(4 * hidden_dim):
for c in range(input_dim):
self.W_x[r, c] = math.sin((r + 1) * (c + 1)) * 0.1
for r in range(4 * hidden_dim):
for c in range(hidden_dim):
self.W_h[r, c] = math.cos((r + 1) * (c + 1)) * 0.1

def step(
self,
x_t: np.ndarray,
h_prev: np.ndarray,
c_prev: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
"""
x_t: shape (input_dim,)
h_prev, c_prev: shape (hidden_dim,)
"""
x_t = x_t.reshape(1, -1) # (1, input_dim)
h_prev_vec = h_prev.reshape(1, -1) # (1, hidden_dim)

z = (self.W_x @ x_t.T + self.W_h @ h_prev_vec.T + self.b.reshape(-1, 1)).flatten()

# разбиваем на 4 блока по hidden_dim
hdim = self.hidden_dim
i = 1.0 / (1.0 + np.exp(-z[0:hdim])) # input gate
f = 1.0 / (1.0 + np.exp(-z[hdim:2*hdim])) # forget gate
o = 1.0 / (1.0 + np.exp(-z[2*hdim:3*hdim])) # output gate
g = np.tanh(z[3*hdim:4*hdim]) # candidate

c_t = f * c_prev + i * g
h_t = o * np.tanh(c_t)
return h_t, c_t


# ============================
# K-MEANS ДЛЯ 1D+ (ПОСТР)
# ============================

def kmeans_1d(values: np.ndarray, n_clusters: int = 2, n_iter: int = 5) -> np.ndarray:
"""
Простой k-means по одномерным значениям (как в аналитической модели).
"""
vals = values.astype(float)
v_min, v_max = float(vals.min()), float(vals.max())
if v_min == v_max:
return np.array([v_min] * n_clusters, dtype=float)
centers = np.linspace(v_min, v_max, n_clusters)
for _ in range(n_iter):
# assign
assignments = np.argmin(np.abs(vals[:, None] - centers[None, :]), axis=1)
# recompute
for k_c in range(n_clusters):
mask = assignments == k_c
if np.any(mask):
centers[k_c] = float(vals[mask].mean())
return centers


# ============================
# ОСНОВНОЙ КЛАСС МОДЕЛИ
# ============================

class UniversalAnalyticalModel:
def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time_grid = np.arange(cfg.t0, cfg.tn + cfg.dt, cfg.dt)
self.num_steps = len(self.time_grid)
self.memory_steps = int(cfg.memory_horizon / cfg.dt)

# 1. Базисные векторы V_i (канонический базис)
self.V = np.eye(cfg.N)

# 2. Входные веса w_j
self.w = np.array([j + 1 for j in range(cfg.N)], dtype=float)
self.w /= self.w.sum()

# 3. Матрица w_ij
self.w_ij = self._build_w_ij()

# 4. Метаданные D, D_i, K_i, O_emb
self.D = self._build_D()
self.D_i = self._build_D_i()
self.K_i = self._build_K_i()
self.O_emb = self._build_O_emb()

# 5. Предрасчёт Sigma(t)
self.Sigma_t_values = np.zeros(self.num_steps, dtype=float)

# 6. LSTM и скрытые состояния для каждого i
self.lstm = LSTMCell(input_dim=cfg.N, hidden_dim=cfg.lstm_hidden_dim)
self.hidden_h = np.zeros((cfg.N, cfg.lstm_hidden_dim), dtype=float)
self.hidden_c = np.zeros((cfg.N, cfg.lstm_hidden_dim), dtype=float)

# 7. Матрица взаимодействий W_ij
self.W_mat = self._build_interaction_matrix()

# сразу считаем Sigma(t)
self._compute_sigma_trajectory()

# ---------- Конструкции матриц ----------

def _build_w_ij(self) -> np.ndarray:
N = self.cfg.N
w_ij = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
w_ij[i, j] = 1.0 / (1.0 + i + j)
w_ij[i] /= w_ij[i].sum()
return w_ij

def _build_D(self) -> np.ndarray:
N, M_dim = self.cfg.N, self.cfg.M_dim
D = np.zeros((M_dim, N), dtype=float)
for a in range(M_dim):
for b in range(N):
D[a, b] = math.sin((a + 1) * (b + 1)) / (1.0 + a + b)
return D

def _build_D_i(self) -> np.ndarray:
N = self.cfg.N
D_i = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
D_i[i, j] = math.cos((i + 1) * (j + 1)) / (1.0 + i + j)
return D_i

def _build_K_i(self) -> np.ndarray:
N = self.cfg.N
K_i = np.zeros((N, 3), dtype=float)
for i in range(N):
K_i[i, 0] = (i + 1) / N
K_i[i, 1] = ((i + 1) ** 2) / (N ** 2)
K_i[i, 2] = 1.0 / (i + 2)
return K_i

def _build_O_emb(self) -> np.ndarray:
N = self.cfg.N
O_emb = np.zeros((N, N), dtype=float)
for i in range(N):
for j in range(N):
O_emb[i, j] = (i + 1 + j + 1) / (2.0 * N)
return O_emb

# ---------- Вход I(t) ----------

def I_t(self, t_index: int) -> np.ndarray:
"""
I(t) = ∑ w_j V_j, но с возможностью небольшой осцилляции по времени,
чтобы не иметь строго статичную систему.
"""
base = self.w.copy()
if self.cfg.input_mode == "static":
return base
else:
# осцилляции веса вокруг базового w (мягко, чтобы не ломать нормировку)
t = self.time_grid[t_index]
osc = 0.1 * np.sin(0.7 * t + np.arange(self.cfg.N))
x = base * (1.0 + osc)
s = x.sum()
if s == 0:
return base
return x / s

# ---------- tau & S(t) блок ----------

@staticmethod
def tau_operator(x: np.ndarray, D_param: np.ndarray) -> np.ndarray:
return np.tanh(D_param @ x)

def S_vec_t(self, t_index: int) -> np.ndarray:
"""
S(t) в смысле вектора после tau(I(t), D)
"""
x = self.I_t(t_index)
return self.tau_operator(x, self.D)

def _A_from_D(self, D_param: np.ndarray) -> float:
return float(np.mean(D_param))

def _build_interaction_matrix(self) -> np.ndarray:
N = self.cfg.N
W_mat = np.zeros((N, N), dtype=float)
A_D = self._A_from_D(self.D)
for i in range(N):
for j in range(N):
vi = self.V[i]
vj = self.V[j]
denom = np.linalg.norm(vi) * np.linalg.norm(vj)
if denom == 0:
cos_ij = 0.0
else:
cos_ij = float(np.dot(vi, vj) / denom)
W_mat[i, j] = cos_ij * A_D
return W_mat

def M_t(self, t_index: int) -> np.ndarray:
"""
M(t) = W * S(t)
"""
S_vec = self.S_vec_t(t_index)
N = self.cfg.N
if S_vec.shape[0] != N:
if S_vec.shape[0] > N:
S_vec = S_vec[:N]
else:
S_vec = np.pad(S_vec, (0, N - S_vec.shape[0]))
return self.W_mat @ S_vec

def entropy_S_t(self, t_index: int) -> float:
"""
Энтропия S(t) = -∑ p_i ln p_i, где p_i нормализованный |M(t)|
"""
m_vec = np.abs(self.M_t(t_index))
if m_vec.sum() == 0:
p = np.ones_like(m_vec) / len(m_vec)
else:
p = m_vec / m_vec.sum()
return float(-np.sum(p * np.log(p + 1e-12)))

# ---------- A_i(t), P[n]_i(t), Sigma(t) ----------

def distance_objects(self, i: int, j: int) -> float:
return float(np.linalg.norm(self.O_emb[i] - self.O_emb[j]))

def A_i_t(self, i: int, t_index: int) -> float:
N = self.cfg.N
d_sum = 0.0
for j in range(N):
if j == i:
continue
d_sum += self.distance_objects(i, j)
d_avg = d_sum / (N - 1)
C_i = (i + 1) / N
Norm_att = 0.9
return (
self.cfg.kappa_scale
* (d_avg ** 2)
* C_i
* Norm_att
)

def P_n_i(self, i: int, t_index: int) -> float:
"""
P[n]_i(t) = интеграл A_i(t') exp(-λ (t - t')) dt' по окну памяти
"""
t_current = self.time_grid[t_index]
total = 0.0
start_index = max(0, t_index - self.memory_steps)
for idx in range(start_index, t_index + 1):
t_prime = self.time_grid[idx]
A_val = self.A_i_t(i, idx)
total += A_val * math.exp(-self.cfg.lambda_decay * (t_current - t_prime)) * self.cfg.dt
return total

def _kappa_input(self, x: np.ndarray) -> float:
return float(np.linalg.norm(x))

def _compute_sigma_trajectory(self):
"""
Σ(t) = ∫ S(I(t')) * κ(A(t')) dt'
"""
cfg = self.cfg
acc = 0.0
for ti, _t in enumerate(self.time_grid):
# S(I(t')): энтропия входа
Ivec = self.I_t(ti)
p = np.abs(Ivec)
if p.sum() == 0:
p = np.ones_like(p) / len(p)
else:
p = p / p.sum()
S_I = -np.sum(p * np.log(p + 1e-12))

# средняя A(t')
A_mean = 0.0
for i in range(cfg.N):
A_mean += self.A_i_t(i, ti)
A_mean /= cfg.N

acc += S_I * self._kappa_input(np.array([A_mean])) * cfg.dt
self.Sigma_t_values[ti] = acc

# ---------- Контекст C(t) ----------

def C_context_scalar(self, t_index: int) -> float:
"""
C(Input, Σ, K_i) сведён к скаляру C(t), зависящему
от входа и накопленной Σ(t).
"""
Ivec = self.I_t(t_index)
kappa_in = self._kappa_input(Ivec)

acc_vec = np.zeros(self.cfg.N, dtype=float)
for i in range(self.cfg.N):
v_comb = np.zeros(self.cfg.N, dtype=float)
for j in range(self.cfg.N):
v_comb += self.w_ij[i, j] * self.V[j]
acc_vec += v_comb * kappa_in

sigma_factor = 1.0 + self.Sigma_t_values[t_index]
return float(np.mean(acc_vec) * sigma_factor)

# ---------- T_i(t) = LSTM(Input_i, K_i) + α*k-means(D_i) ----------

def T_i_t(self, i: int, t_index: int) -> float:
"""
Полная формула T_i:
- LSTM(Input(t), K_i) через скрытые состояния h_i, c_i
- плюс α * kmeans(D_i)
"""
cfg = self.cfg

x_t = self.I_t(t_index)
k_params = self.K_i[i]

# модифицируем предыдущее состояние через K_i
h_prev = self.hidden_h[i] + 0.1 * k_params[0]
c_prev = self.hidden_c[i] + 0.1 * k_params[1]

h_t, c_t = self.lstm.step(x_t, h_prev, c_prev)
self.hidden_h[i] = h_t
self.hidden_c[i] = c_t

# k-means по строке D_i[i]
centers = kmeans_1d(self.D_i[i], n_clusters=2, n_iter=5)
kmeans_val = float(centers.mean())

# берём, например, среднее по hidden_dim
h_scalar = float(h_t.mean())

return h_scalar + self.cfg.alpha_kmeans * kmeans_val

# ---------- Итоговый функционал F(t), F ----------

def compute_F(self) -> Tuple[float, Dict[str, np.ndarray]]:
"""
Считаем:
f(t) = (∑_i A_i(t) P[n]_i(t) T_i(t)) * exp(-S(t)/k_B) * C(t)
F = ∫ f(t) dt
Возвращает F_total и словарь массивов по времени.
"""
cfg = self.cfg
F_total = 0.0

F_t_values = []
S_t_values = []
A0_vals = []
P0_vals = []

for t_index, t in enumerate(self.time_grid):
S_val = self.entropy_S_t(t_index)
S_t_values.append(S_val)

C_val = self.C_context_scalar(t_index)

inner_sum = 0.0
for i in range(cfg.N):
A_val = self.A_i_t(i, t_index)
P_val = self.P_n_i(i, t_index)
T_val = self.T_i_t(i, t_index)
inner_sum += A_val * P_val * T_val

if i == 0:
A0_vals.append(A_val)
P0_vals.append(P_val)

integrand = inner_sum * math.exp(-S_val / cfg.k_B) * C_val
F_t_values.append(integrand)
F_total += integrand * cfg.dt

arrays = dict(
F_t=np.array(F_t_values),
S_t=np.array(S_t_values),
A0_t=np.array(A0_vals),
P0_t=np.array(P0_vals),
Sigma_t=self.Sigma_t_values.copy(),
time=self.time_grid.copy(),
W_mat=self.W_mat.copy(),
)
return F_total, arrays


# ============================
# CLI-ТЕСТ (как твой test)
# ============================

if __name__ == "__main__":
cfg = UniversalConfig()
model = UniversalAnalyticalModel(cfg)
F_val, arrays = model.compute_F()

print("\n==============================================")
print(" UNIVERSAL ANALYTICAL MODEL - FULL VERSION")
print("==============================================")
print(f"Time interval: [{cfg.t0}, {cfg.tn}] with dt = {cfg.dt}, steps = {model.num_steps}")
print(f"Dimension N (V_i, I(t), etc.): {cfg.N}")
print("----------------------------------------------")
print("F =", F_val)
print("==============================================\n")

try:
import matplotlib.pyplot as plt

t_vals = arrays["time"]

# A_0(t) и P[n]_0(t)
plt.figure()
plt.plot(t_vals, arrays["A0_t"], label="A_0(t)")
plt.plot(t_vals, arrays["P0_t"], label="P[n]_0(t)")
plt.xlabel("t")
plt.ylabel("value")
plt.title("Activity A_0(t) and Accumulation P[n]_0(t)")
plt.legend()
plt.tight_layout()
plt.savefig("A0_P0_vs_t_full.png")

# S(t)
plt.figure()
plt.plot(t_vals, arrays["S_t"])
plt.xlabel("t")
plt.ylabel("S(t)")
plt.title("Entropy S(t)")
plt.tight_layout()
plt.savefig("S_t_full.png")

# Σ(t)
plt.figure()
plt.plot(t_vals, arrays["Sigma_t"])
plt.xlabel("t")
plt.ylabel("Sigma(t)")
plt.title("Topology Sigma(t)")
plt.tight_layout()
plt.savefig("Sigma_t_full.png")

# f(t) и накопленный интеграл
plt.figure()
plt.plot(t_vals, arrays["F_t"], label="integrand f(t)")
F_cum = np.cumsum(arrays["F_t"]) * cfg.dt
plt.plot(t_vals, F_cum, label="cumulative F(t)")
plt.xlabel("t")
plt.ylabel("value")
plt.title("Instantaneous and cumulative F(t)")
plt.legend()
plt.tight_layout()
plt.savefig("F_t_and_cumulative_full.png")

# Heatmap W_{ij}
plt.figure()
plt.imshow(arrays["W_mat"], aspect="auto")
plt.colorbar(label="W_ij")
plt.xlabel("j")
plt.ylabel("i")
plt.title("Interaction matrix W_ij")
plt.tight_layout()
plt.savefig("W_matrix_heatmap_full.png")

print(
"Plots saved:",
"A0_P0_vs_t_full.png, S_t_full.png, Sigma_t_full.png, "
"F_t_and_cumulative_full.png, W_matrix_heatmap_full.png",
)

except Exception as e:
print("Plotting skipped due to error:", e)

# --- FILE: ./universal_model_full.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()
# --- FILE: ./запуск_1.py ---

import sys
import subprocess
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton
from PyQt5.QtCore import Qt

MODEL_PATH = "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M.gguf"
LLAMA_BIN = "/home/vitalij/AI/llama.cpp/build/bin/llama-cli"


class ChatWindow(QWidget):
def __init__(self):
super().__init__()

self.setWindowTitle("POLER MiniChat")
self.setGeometry(200, 200, 600, 500)

layout = QVBoxLayout()

self.chat_box = QTextEdit()
self.chat_box.setReadOnly(True)
layout.addWidget(self.chat_box)

self.input_box = QLineEdit()
self.input_box.setPlaceholderText("Введите сообщение…")
layout.addWidget(self.input_box)

self.send_button = QPushButton("Отправить")
self.send_button.clicked.connect(self.send_message)
layout.addWidget(self.send_button)

self.setLayout(layout)

def send_message(self):
user_text = self.input_box.text().strip()
if not user_text:
return

self.chat_box.append(f"Вы: {user_text}")
self.input_box.clear()

# Простая подача текста без chat-template
prompt = user_text

cmd = [
LLAMA_BIN,
"-m", MODEL_PATH,
"--no-interactive",
"--n-predict", "200",
"-p", prompt,
]

# потоковый запуск
process = subprocess.Popen(
cmd,
stdout=subprocess.PIPE,
stderr=subprocess.DEVNULL,
text=True,
bufsize=1
)

answer = ""

for line in process.stdout:
line = line.strip()

# фильтрация системных сообщений (метаданные, логотипы)
if line.startswith("build:") or line.startswith("main:") or line.startswith("llama"):
continue
if line.startswith("<|system|>") or line.startswith("<|user|>"):
continue

if line != "":
answer += line + " "

answer = answer.strip()
if not answer:
answer = "(пустой ответ)"

self.chat_box.append(f"ИИ: {answer}\n")


if __name__ == "__main__":
app = QApplication(sys.argv)
window = ChatWindow()
window.show()
sys.exit(app.exec_())

# --- FILE: ./запуск.py ---

import sys
import subprocess
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton
from PyQt5.QtCore import Qt

MODEL_PATH = "/home/vitalij/AI/Phi-3-mini-4k-instruct-Q4_K_M.gguf"
LLAMA_BIN = "/home/vitalij/AI/llama.cpp/build/bin/llama-cli"


class ChatWindow(QWidget):
def __init__(self):
super().__init__()

self.setWindowTitle("POLER MiniChat")
self.setGeometry(200, 200, 600, 500)

layout = QVBoxLayout()

self.chat_box = QTextEdit()
self.chat_box.setReadOnly(True)
layout.addWidget(self.chat_box)

self.input_box = QLineEdit()
self.input_box.setPlaceholderText("Введите сообщение…")
layout.addWidget(self.input_box)

self.send_button = QPushButton("Отправить")
self.send_button.clicked.connect(self.send_message)
layout.addWidget(self.send_button)

self.setLayout(layout)

def send_message(self):
user_text = self.input_box.text().strip()
if not user_text:
return

self.chat_box.append(f"Вы: {user_text}")
self.input_box.clear()

# Простая подача текста без chat-template
prompt = user_text

cmd = [
LLAMA_BIN,
"-m", MODEL_PATH,
"--no-interactive",
"--n-predict", "200",
"-p", prompt,
]

# потоковый запуск
process = subprocess.Popen(
cmd,
stdout=subprocess.PIPE,
stderr=subprocess.DEVNULL,
text=True,
bufsize=1
)

answer = ""

for line in process.stdout:
line = line.strip()

# фильтрация системных сообщений (метаданные, логотипы)
if line.startswith("build:") or line.startswith("main:") or line.startswith("llama"):
continue
if line.startswith("<|system|>") or line.startswith("<|user|>"):
continue

if line != "":
answer += line + " "

answer = answer.strip()
if not answer:
answer = "(пустой ответ)"

self.chat_box.append(f"ИИ: {answer}\n")


if __name__ == "__main__":
app = QApplication(sys.argv)
window = ChatWindow()
window.show()
sys.exit(app.exec_())

# --- FILE: ./универсальная_аналитическая_модель.py ---

# -*- coding: utf-8 -*-
"""Универсальная Аналитическая Модель

Automatically generated by Colab.

Original file is located at
https://colab.research.google.com/drive/1fCBqsAfALOfuahMeHCcgsZSY6qhPgtWy
"""

#
# universal_model_full.py
# Генерирует топологические и контекстные поля для POLER-системы.
# Эти поля (Sigma_t, S_t, C_t) используются для адаптации
# внутренней динамики физического слоя.
#
from __future__ import annotations
import math
import numpy as np

class UniversalConfig:
"""Конфигурация для Универсальной Аналитической Модели."""
def __init__(self):
self.time_end = 5.0
self.dt = 0.1
self.sigma_base = 0.1
self.s_base = 0.05

class UniversalAnalyticalModel:
"""
Модель генерирует поля Σ(t), S(t) (Топология/Энтропия)
и C(t) (Контекст/Наблюдатель), которые используются
POLER-системой для саморегуляции.
"""

def __init__(self, cfg: UniversalConfig):
self.cfg = cfg
self.time = np.arange(0.0, cfg.time_end + cfg.dt, cfg.dt)
self.num_steps = len(self.time)

def _compute_sigma(self) -> np.ndarray:
"""
Топологическое поле Sigma(t): моделирует "сложность" или
"напряжение" системы. Растет со временем, но стабилизируется.
"""
# Сигма растет экспоненциально, но ограничена (tanh-функция)
t_normalized = self.time / self.cfg.time_end
sigma = self.cfg.sigma_base + 0.5 * np.tanh(3.0 * t_normalized)
return sigma

def _compute_S(self) -> np.ndarray:
"""
Энтропийное поле S(t): моделирует "неопределенность" или "шум".
Немного убывает, затем растет, отражая внутренний цикл.
"""
t_normalized = self.time / self.cfg.time_end
S = self.cfg.s_base * (1.0 + 0.5 * np.sin(2 * np.pi * t_normalized) * np.exp(-t_normalized / 2.0))
return S

def C_context_scalar(self, t_index: int) -> float:
"""
Скаляр Контекста C(t): Используется для мягкого масштабирования.
Здесь — простая линейная функция, зависящая от времени.
"""
t = self.time[t_index]
return 0.3 + 0.2 * (t / self.cfg.time_end)

def compute_F(self) -> tuple[float, dict]:
"""
Основной расчет модели. F - финишное значение для отладки.
"""
Sigma_t = self._compute_sigma()
S_t = self._compute_S()

arrays = dict(
time=self.time,
Sigma_t=Sigma_t,
S_t=S_t,
)

# Вычисление финального значения F (для теста)
F_val = Sigma_t[-1] * S_t.mean()

return F_val, arrays

# Пример использования (не запускается, только для структуры)
# cfg = UniversalConfig()
# model = UniversalAnalyticalModel(cfg)
# F, arrays = model.compute_F()