> Source: https://docs.rs/sprs

sprs - Rust
Docs.rs
sprs-0.11.4
sprs 0.11.4
Permalink
Docs.rs crate page
MIT OR Apache-2.0
Links
Repository
crates.io
Source
Owners
vbarrielle
mulimoen
Dependencies
alga ^0.9.0 normal optional
approx ^0.5 normal optional
ndarray >=0.15.0, <0.18 normal
num-complex ^0.4.0 normal
num-traits ^0.2.0 normal
num_cpus ^1.13.0 normal optional
rayon ^1.7.0 normal optional
serde ^1.0.0 normal optional
smallvec ^1.4.0 normal
bencher ^0.1.0 dev
bincode ^2.0.1 dev
image ^0.25.2 dev
num-derive ^0.4 dev
rand ^0.9 dev
tempfile ^3.1.0 dev
tobj ^4.0 dev
Versions
53.76% of the crate is documented
Platform
aarch64-apple-darwin
aarch64-unknown-linux-gnu
i686-pc-windows-msvc
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
Crate sprs
Settings
Help
sprs 0.11.4
All Items
Sections
Features
Quick Examples
Crate Items
Re-exports
Modules
Structs
Enums
Traits
Functions
Type Aliases
Crates
sprs 
Crate sprs Copy item path
Source
Search
Settings
Help
Summary
Expand description
sprs is a sparse linear algebra library for Rust.
It features a sparse matrix type, CsMat , and a sparse vector type, CsVec , both based on the compressed storage scheme.
§ Features
sparse matrix/sparse matrix addition, multiplication.
sparse vector/sparse vector addition, dot product.
sparse matrix/dense matrix addition, multiplication.
sparse triangular solves.
powerful iteration over the sparse structure, enabling easy extension of the library.
matrix construction using the triplet format, vertical and horizontal stacking, block construction.
sparse cholesky solver in the separate crate sprs-ldl .
fully generic integer type for the storage of indices, enabling compact representations.
planned interoperability with existing sparse solvers such as SuiteSparse .
§ Quick Examples
Matrix construction:
Constructing matrix using the more efficient direct sparse constructor
Matrix vector multiplication:
Matrix matrix multiplication, addition:
Re-exports §
pub use crate::indexing:: [SpIndex](https://docs.rs/indexing/trait.SpIndex.html); pub use crate::sparse::CompressedStorage:: [CSC](https://docs.rs/enum.CompressedStorage.html); pub use crate::sparse::CompressedStorage:: [CSR](https://docs.rs/enum.CompressedStorage.html); pub use [SymmetryCheck](https://docs.rs/enum.SymmetryCheck.html)::*; pub use [PermutationCheck](https://docs.rs/enum.PermutationCheck.html)::*;
Modules §
approx
Traits for comparing vectors and matrices using the approx traits
array_backend
Fixed size arrays usable for sparse matrices.
binop
Sparse matrix addition, subtraction
errors
Error type for sprs
indexing
Abstraction over types of indices
io
Serialization and deserialization of sparse matrices
linalg
Sparse linear algebra
num_kinds
Trait to be able to know at runtime if a generic scalar is an integer, a float or a complex.
num_matrixmarket
prod
Sparse matrix product
smmp
Implementation of the paper Bank and Douglas, 2001, Sparse Matrix Multiplication Package (SMPP)
special_mats
Common sparse matrices
stack
vec
visu
Structs §
CsIter
CsMatBase
Compressed matrix in the CSR or CSC format, with sorted indices.
CsVecBase
A sparse vector, storing the indices of its non-zero data.
IndPtrBase
Permutation
TriMatBase
Sparse matrix in the triplet format.
TriMatIter
An iterator over elements of a sparse matrix, in the triplet format
Enums §
CompressedStorage
Describe the storage of a CsMat
FillInReduction
The different kinds of fill-in-reduction algorithms supported by sprs
PermutationCheck
Configuration enum to ask for permutation checks in algorithms
SymmetryCheck
Configuration enum to ask for symmetry checks in algorithms
Traits §
DenseVector
A trait for types representing dense vectors, useful for expressing algorithms such as sparse-dense dot product, or linear solves.
DenseVectorMut
Trait for dense vectors that can be modified, useful for expressing algorithms which compute a resulting dense vector, such as solvers.
MulAcc
Trait for types that have a multiply-accumulate operation, as required in dot products and matrix products.
SparseMat
A trait for common members of sparse matrices
Functions §
assign_to_dense
Assign a sparse matrix into a dense matrix
bmat
Specify a sparse matrix by constructing it from blocks of other matrices
hstack
Construct a sparse matrix by horizontally stacking other matrices
is_symmetric
kronecker_product
Compute the Kronecker product between two matrices
perm_is_valid
permute_cols
Compute the matrix resulting from the product A * P
permute_rows
Compute the matrix resulting from the product P * A
transform_mat_papt
Compute the square matrix resulting from the product P * A * P^T
transform_mat_paq
Compute the matrix resulting from the product P * A * Q, using the same number of operations and allocation as for computing either P * A or A * Q by itself.
vstack
Construct a sparse matrix by vertically stacking other matrices
Type Aliases §
CsMat
CsMatI
CsMatVecView
CsMatView
CsMatViewI
CsMatViewMut
CsMatViewMutI
CsStructure
CsStructureI
CsStructureView
CsStructureViewI
CsVec
CsVecI
CsVecView
CsVecViewI
CsVecViewMut
CsVecViewMutI
IndPtr
IndPtrView
Ix1
Ix2
PermOwned
PermOwnedI
PermView
PermViewI
Shape
The shape of a matrix. This a 2-tuple with the first element indicating the number of rows, and the second element indicating the number of columns.
TriMat
TriMatI
TriMatView
TriMatViewI
TriMatViewMut
TriMatViewMutI