> Source: https://www.researchgate.net/publication/2263610_Cryptography_with_Dynamical_Systems

ResearchGate - Temporarily Unavailable 
Access denied
You do not have access to www.researchgate.net.
The site owner may have set restrictions that prevent you from accessing the site.
Ray ID: a08579f25c4473db
Timestamp: 2026-06-08 05:25:30 UTC
Your IP address: 74.125.212.230
Requested URL: www.researchgate.net/publication/2263610_Cryptography_with_Dynamical_Systems
Error reference number: 1020
Server ID: FL_397F349
User-Agent: Google-NotebookLM
Ray ID: a08579f25c4473db
Client IP: 74.125.212.230
© 2008-2026 ResearchGate GmbH. All rights reserved.