> Source: https://en.wikipedia.org/wiki/Kohn%E2%80%93Sham_equations

Kohn–Sham equations - Wikipedia
Jump to content [-]
Main menu
Main menu
move to sidebar hide
Navigation
Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Contribute
Help
Learn to edit
Community portal
Recent changes
Upload file
Special pages
Search
Search [-]
Appearance
Donate
Create account
Log in [-]
Personal tools
Donate
Create account
Log in
 Edit with pride and win! Participate in Wiki Loves Pride 2026
Contents
move to sidebar hide
(Top)
1 Description
2 History
3 Kohn–Sham potential
4 References [-]
Toggle the table of contents
Kohn–Sham equations
[-]
9 languages
বাংলা
Català
فارسی
Français
日本語
Polski
Русский
Українська
中文
Edit links
Article
Talk [-]
English
Read
Edit
View history [-]
Tools
Tools
move to sidebar hide
Actions
Read
Edit
View history
General
What links here
Related changes
Upload file
Permanent link
Page information
Cite this page
Get shortened URL
Edit interlanguage links
Print/export
Download as PDF
Printable version
In other projects
Wikidata item
Appearance
move to sidebar hide
Text
[-] 0 Small [x] 1 Standard [-] 2 Large
This page always uses small font size
Width
[x] 1 Standard [-] 0 Wide
The content is as wide as possible for your browser window.
Color
[-] os Automatic [x] day Light [-] night Dark
This page is always in light mode.
From Wikipedia, the free encyclopedia
Schrödinger equation of a fictitious system of non-interacting particles
The Kohn-Sham equations are a set of mathematical equations used in quantum mechanics to simplify the complex problem of understanding how electrons behave in atoms and molecules. They introduce fictitious non-interacting electrons and use them to find the most stable arrangement of electrons, which helps scientists understand and predict the properties of matter at the atomic and molecular scale.
Description
[ edit]
In physics and quantum chemistry, specifically density functional theory, the Kohn–Sham equation is the non-interacting Schrödinger equation (more clearly, Schrödinger-like equation) of a fictitious system (the " Kohn–Sham system") of non-interacting particles (typically electrons) that generate the same density as any given system of interacting particles. [1] [2]
In the Kohn–Sham theory the introduction of the noninteracting kinetic energy functional T s into the energy expression leads, upon functional differentiation, to a collection of one-particle equations whose solutions are the Kohn–Sham orbitals.
The Kohn–Sham equation is defined by a local effective (fictitious) external potential in which the non-interacting particles move, typically denoted as v s( r) or v eff( r), called the Kohn–Sham potential. If the particles in the Kohn–Sham system are non-interacting fermions (non-fermion density functional theory has been studied), [3] [4] the Kohn–Sham wavefunction is a single Slater determinant constructed from a set of orbitals that are the lowest-energy solutions to ( − ℏ 2 2 m ∇ 2 + v eff ( r ) ) φ i ( r ) = ε i φ i ( r ) . {\displaystyle \left(-{\frac {\hbar ^{2}}{2m}}\nabla ^{2}+v_{\text{eff}}(\mathbf {r} )\right)\varphi _{i}(\mathbf {r} )=\varepsilon _{i}\varphi _{i}(\mathbf {r} ).} 
This eigenvalue equation is the typical representation of the Kohn–Sham equations. Here ε i is the orbital energy of the corresponding Kohn–Sham orbital φ i {\displaystyle \varphi _{i}} 
, and the density for an N-particle system is
ρ ( r ) = ∑ i N | φ i ( r ) | 2 . {\displaystyle \rho (\mathbf {r} )=\sum _{i}^{N}|\varphi _{i}(\mathbf {r} )|^{2}.} 
History
[ edit]
The Kohn–Sham equations are named after Walter Kohn and Lu Jeu Sham, who introduced the concept at the University of California, San Diego, in 1965.
Kohn received a Nobel Prize in Chemistry in 1998 for the Kohn–Sham equations and other work related to density functional theory (DFT). [5]
Kohn–Sham potential
[ edit]
In Kohn–Sham density functional theory, the total energy of a system is expressed as a functional of the charge density as
E [ ρ ] = T s [ ρ ] + ∫ d r v ext ( r ) ρ ( r ) + E H [ ρ ] + E xc [ ρ ] , {\displaystyle E[\rho ]=T_{s}[\rho ]+\int d\mathbf {r} ,v_{\text{ext}}(\mathbf {r} )\rho (\mathbf {r} )+E_{\text{H}}[\rho ]+E_{\text{xc}}[\rho ],} 
where T s is the Kohn–Sham kinetic energy, which is expressed in terms of the Kohn–Sham orbitals as
T s [ ρ ] = ∑ i = 1 N ∫ d r φ i ∗ ( r ) ( − ℏ 2 2 m ∇ 2 ) φ i ( r ) , {\displaystyle T_{s}[\rho ]=\sum _{i=1}^{N}\int d\mathbf {r} ,\varphi _{i}^{*}(\mathbf {r} )\left(-{\frac {\hbar ^{2}}{2m}}\nabla ^{2}\right)\varphi _{i}(\mathbf {r} ),} 
v ext is the external potential acting on the interacting system (at minimum, for a molecular system, the electron–nuclei interaction), E H is the Hartree (or Coulomb) energy
E H [ ρ ] = e 2 2 ∫ d r ∫ d r ′ ρ ( r ) ρ ( r ′ ) | r − r ′ | , {\displaystyle E_{\text{H}}[\rho ]={\frac {e^{2}}{2}}\int d\mathbf {r} \int d\mathbf {r} ',{\frac {\rho (\mathbf {r} )\rho (\mathbf {r} ')}{|\mathbf {r} -\mathbf {r} '|}},} 
and E xc is the exchange–correlation energy. The Kohn–Sham equations are found by varying the total energy expression with respect to a set of Kohn-Sham orbitals subject to the constraint that they are orthogonal, [6] this yields a time-independent Schrödinger equation with a scalar potential equal to the Kohn–Sham potential
v eff ( r ) = v ext ( r ) + e 2 ∫ ρ ( r ′ ) | r − r ′ | d r ′ + δ E xc [ ρ ] δ ρ ( r ) , {\displaystyle v_{\text{eff}}(\mathbf {r} )=v_{\text{ext}}(\mathbf {r} )+e^{2}\int {\frac {\rho (\mathbf {r} ')}{|\mathbf {r} -\mathbf {r} '|}},d\mathbf {r} '+{\frac {\delta E_{\text{xc}}[\rho ]}{\delta \rho (\mathbf {r} )}},} 
where the last term
v xc ( r ) ≡ δ E xc [ ρ ] δ ρ ( r ) , {\displaystyle v_{\text{xc}}(\mathbf {r} )\equiv {\frac {\delta E_{\text{xc}}[\rho ]}{\delta \rho (\mathbf {r} )}},} 
is the exchange–correlation potential. This term, and the corresponding energy expression, are the only unknowns in the Kohn–Sham approach to density functional theory. An approximation that does not vary the orbitals is Harris functional theory.
The Kohn–Sham orbital energies ε i, in general, have little physical meaning (see Koopmans' theorem). The sum of the orbital energies is related to the total energy as
E = ∑ i N ε i − E H [ ρ ] + E xc [ ρ ] − ∫ δ E xc [ ρ ] δ ρ ( r ) ρ ( r ) d r . {\displaystyle E=\sum {i}^{N}\varepsilon {i}-E{\text{H}}[\rho ]+E{\text{xc}}[\rho ]-\int {\frac {\delta E_{\text{xc}}[\rho ]}{\delta \rho (\mathbf {r} )}}\rho (\mathbf {r} ),d\mathbf {r} .} 
Because the orbital energies are non-unique in the more general restricted open-shell case, this equation only holds true for specific choices of orbital energies (see Koopmans' theorem).
References
[ edit]
^ Kohn, Walter; Sham, Lu Jeu (1965). "Self-Consistent Equations Including Exchange and Correlation Effects". Physical Review. 140 (4A): A1133– A1138. Bibcode: 1965PhRv..140.1133K. doi: 10.1103/PhysRev.140.A1133.
^ Parr, Robert G.; Yang, Weitao (1994). Density-Functional Theory of Atoms and Molecules. Oxford University Press. ISBN 978-0-19-509276-9 . OCLC 476006840. OL 7387548M.
^ Wang, Hongmei; Zhang, Yunbo (2013). "Density-functional theory for the spin-1 bosons in a one-dimensional harmonic trap". Physical Review A. 88 (2) 023626. arXiv: 1304.1328. Bibcode: 2013PhRvA..88b3626W. doi: 10.1103/PhysRevA.88.023626. S2CID 119280339.
^ Hu, Yayun; Murthy, G.; Rao, Sumathi; Jain, J. K. (2021). "Kohn-Sham density functional theory of Abelian anyons". Physical Review B. 103 (3) 035124. arXiv: 2010.09872. Bibcode: 2021PhRvB.103c5124H. doi: 10.1103/PhysRevB.103.035124. S2CID 224802789.
^ "The Nobel Prize in Chemistry 1998". NobelPrize.org. Retrieved 2023-09-15.
^ Tomas Arias (2004). "Kohn–Sham Equations". P480 notes. Cornell University. Archived from the original on 2020-02-18. Retrieved 2021-01-14. 
Retrieved from " https://en.wikipedia.org/w/index.php?title=Kohn–Sham_equations&oldid=1322016408"
Categories:
Density functional theory
Electron
Quantum mechanics
Equations of physics
Hidden categories:
Articles with short description
Short description is different from Wikidata
This page was last edited on 13 November 2025, at 23:11 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policy
About Wikipedia
Disclaimers
Contact Wikipedia
Legal & safety contacts
Code of Conduct
Developers
Statistics
Cookie statement
Mobile view
Search
Search [-]
Toggle the table of contents
Kohn–Sham equations
9 languages Add topic 