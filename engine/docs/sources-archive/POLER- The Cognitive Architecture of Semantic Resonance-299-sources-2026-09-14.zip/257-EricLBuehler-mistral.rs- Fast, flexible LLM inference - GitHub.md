> Source: https://github.com/EricLBuehler/mistral.rs

GitHub - EricLBuehler/mistral.rs: Fast, flexible LLM inference
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
EricLBuehler / mistral.rs Public
Notifications You must be signed in to change notification settings
Fork 532
Star 6.6k
Fast, flexible LLM inference
License
MIT license
6.6k stars 532 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 189
Pull requests 97
Discussions
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Discussions
Actions
Projects
Security
Insights
EricLBuehler/mistral.rs
master
78 Branches 41 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
MIT license
Fast, flexible LLM inference.
| Documentation | Rust SDK | Python SDK | Discord |
Why mistral.rs?
Any HuggingFace model, zero config: Just mistralrs run -m user/model . Auto-detects architecture, quantization, chat template.
True multimodality: Vision, audio, speech generation, image generation, embeddings.
Not another model registry: Use HuggingFace models directly. No converting, no uploading to a separate service.
Full quantization control: Choose the precise quantization you want to use, or make your own UQFF with mistralrs quantize .
Built-in web UI: mistralrs serve --ui gives you a web interface instantly.
Hardware-aware: mistralrs tune benchmarks your system and picks optimal quantization + device mapping.
Flexible SDKs: Python package and Rust crate to build your projects.
Quick Start
Install
Linux/macOS:
Windows (PowerShell):
Manual installation & other platforms
Run Your First Model
Then visit http://localhost:1234/ui for the web chat interface.
The mistralrs CLI
The CLI is designed to be zero-config: just point it at a model and go.
Auto-detection: Automatically detects model architecture, quantization format, and chat template
All-in-one: Single binary for chat, server, benchmarks, and web UI ( run , serve , bench )
Hardware tuning: Run mistralrs tune to automatically benchmark and configure optimal settings for your hardware
Format-agnostic: Works with Hugging Face models, GGUF files, and UQFF quantizations seamlessly
Full CLI documentation
Web Chat Demo
  
What Makes It Fast
Performance
Continuous batching support by default on all devices.
CUDA with FlashAttention V2/V3, Metal, multi-GPU tensor parallelism
PagedAttention for high throughput continuous batching on CUDA or Apple Silicon, prefix caching (including multimodal)
Quantization ( full docs)
In-situ quantization (ISQ) of any Hugging Face model
GGUF (2-8 bit), GPTQ, AWQ, HQQ, FP8, BNB support
⭐ Per-layer topology: Fine-tune quantization per layer for optimal quality/speed
⭐ Auto-select fastest quant method for your hardware
Flexibility
LoRA & X-LoRA with weight merging
AnyMoE: Create mixture-of-experts on any base model
Multiple models: Load/unload at runtime
Agentic Features
Integrated tool calling with Python/Rust callbacks
⭐ Web search integration
⭐ MCP client: Connect to external tools automatically
Full feature documentation
Supported Models
Text Models
Granite 4.0
SmolLM 3
DeepSeek V3
GPT-OSS
DeepSeek V2
Qwen 3 Next
Qwen 3 MoE
Phi 3.5 MoE
Qwen 3
GLM 4
GLM-4.7-Flash
GLM-4.7 (MoE)
Gemma 2
Qwen 2
Starcoder 2
Phi 3
Mixtral
Phi 2
Gemma
Llama
Mistral
Vision Models
Qwen 3-VL
Qwen 3-VL MoE
Gemma 3n
Llama 4
Gemma 3
Mistral 3
Phi 4 multimodal
Qwen 2.5-VL
MiniCPM-O
Llama 3.2 Vision
Qwen 2-VL
Idefics 3
Idefics 2
LLaVA Next
LLaVA
Phi 3V
Speech Models
Voxtral (ASR/speech-to-text)
Dia
Image Generation Models
FLUX
Embedding Models
Embedding Gemma
Qwen 3 Embedding
Request a new model | Full compatibility tables
Python SDK
Python SDK | Installation | Examples | Cookbook
Rust SDK
API Docs | Crate | Examples
Docker
For quick containerized deployment:
Docker images
For production use, we recommend installing the CLI directly for maximum flexibility.
Documentation
For complete documentation, see the Documentation.
Quick Links:
CLI Reference - All commands and options
HTTP API - OpenAI-compatible endpoints
Quantization - ISQ, GGUF, GPTQ, and more
Device Mapping - Multi-GPU and CPU offloading
MCP Integration - MCP integration documentation
Troubleshooting - Common issues and solutions
Configuration - Environment variables for configuration
Contributing
Contributions welcome! Please open an issue to discuss new features or report bugs. If you want to add a new model, please contact us via an issue and we can coordinate.
Credits
This project would not be possible without the excellent work at Candle. Thank you to all contributors!
mistral.rs is not affiliated with Mistral AI.
Back to Top
About
Fast, flexible LLM inference
Topics
rust llm uqff
Resources
Readme
License
MIT license
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
6.6k stars
Watchers
45 watching
Forks
532 forks
Report repository
Releases 40
v0.7.0 Latest last month
+ 39 releases
Packages 1
mistral.rs
Uh oh!
There was an error while loading. Please reload this page.
Contributors 76
+ 62 contributors
Languages
Rust 82.5%
Cuda 10.3%
Metal 4.5%
JavaScript 1.0%
Python 0.8%
Jinja 0.3%
Other 0.6%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.