> Source: https://arxiv.org/html/2512.12036v1

Accelerating Sparse Matrix-Matrix Multiplication on GPUs with Processing Near HBMs
 Back to arXiv  
 Back to arXiv
This is experimental HTML to improve accessibility. We invite you to report rendering errors. Use Alt+Y to toggle on accessible reporting links and Alt+Shift+Y to toggle off. Learn more about this project and help improve conversions.
Why HTML? Report Issue Back to Abstract Download PDF 
Table of Contents
Abstract
I Introduction
II Background
III Optimized Hash-based Multi-phase SpGEMM on GPU
III-A Algorithm Overview
III-B Row-grouping Phase
III-C Allocation Phase
III-D Accumulation Phase
IV Near Memory Processing: HBM-AIA
IV-A Motivation of AIA
IV-B HBM-AIA on Modern GPU
IV-C AIA Ranged index Illustration
IV-D AIA Kernel on SpGEMM
V Benchmarks/Applications
V-A MCL
V-B Graph Contraction
V-C Graph Neural Network
VI Experimental Results
VI-A Matrix Self-product Performance
VI-B Graph Analytical Workload Performance
VI-C Graph Neural Network Training Performance
VII Conclusion
License: CC BY-NC-ND 4.0
arXiv:2512.12036v1 [cs.DC] 12 Dec 2025
Accelerating Sparse Matrix-Matrix Multiplication on GPUs with Processing Near HBMs
Report issue for preceding element
Shiju Li , Younghoon Min , Hane Yie , Hoshik Kim , Soohong Ahn §, Joonseop Sim §, Chul-Ho Lee ‡, Jongryool Kim  
SOLAB, SK hynix America, San Jose, USA §
AMS, SK hynix, Icheon, Korea ‡
Texas State University, San Marcos, USA
shiju.li, younghoon.min, stella.yie, hoshik1.kim, soohong.ahn, joonseop.sim, jongryool.kim@sk.com
chulho.lee@txstate.edu
Report issue for preceding element
Abstract
Report issue for preceding element
Sparse General Matrix-Matrix Multiplication (SpGEMM) is a fundamental operation in numerous scientific computing and data analytics applications, often bottlenecked by irregular memory access patterns. This paper presents Hash-based Multi-phase SpGEMM on GPU and the Acceleration of Indirect Memory Access (AIA) technique, a novel custom near-memory processing approach to optimizing SpGEMM on GPU HBM. Our hardware-software co-designed framework for SpGEMM demonstrates significant performance improvements over state-of-the-art methods, particularly in handling complex, application-specific workloads.
Report issue for preceding element
We evaluate our approach on various graph workloads, including graph contraction, Markov clustering, and Graph Neural Networks (GNNs), showcasing its practical applicability. For graph analytics applications, AIA demonstrates up to 17.3% time reduction from the software-only implementation, while achieving time reduction of 76.5% for Graph Contraction and 58.4% for Markov Clustering compared to cuSPARSE. For GNN training applications with structured global pruning, our hybrid approach delivers an average of 1.43 × \times speedup over software-only implementation across six benchmark datasets and three architectures (GCN, GIN, GraphSAGE), and shows 1.95 × \times speedup for GNN workloads when compared to cuSPARSE, with up to 4.18 × \times gains on large-scale datasets.
Report issue for preceding element
I Introduction
Report issue for preceding element
Sparse General Matrix-Matrix Multiplication (SpGEMM) plays a pivotal role in computational science, machine learning, and graph analytics. The general matrix-matrix multiplication (GEMM), which multiplies a m × k m\times k matrix 𝐀 \mathbf{A} with a k × n k\times n matrix 𝐁 \mathbf{B} to produce a m × n m\times n matrix 𝐂 = 𝐀𝐁 \mathbf{C}=\mathbf{A}\mathbf{B} , is a simple yet fundamental matrix operation in many applications such as algebraic multigrid methods [ bell2012exposing] , multi-source breadth-first search [ bulucc2011combinatorial] , recursive formulations of all-pairs shortest-paths algorithms [ d2007r] , clustering coefficient [ azad2015parallel] , graph contraction [ gilbert2008unified] , Markov clustering [ van2000graph] , and graph neural networks (GNNs) [ ma2021deep, hamilton2020graph, huang2022characterizing] . However, these applications often require exploiting sparsity in both input and output matrices to optimize storage and computational efficiency. GNNs are a compelling application for SpGEMM optimization because they rely on sparse matrix operations for feature aggregation and propagation across neighborhoods. Recently, it has been shown in [ peng2024maxk] that optimized sparse operations can achieve an average of 3.2 × \times speedup over state-of-the-art GNN frameworks.
Report issue for preceding element
However, the efficient execution of SpGEMM on modern GPUs faces several fundamental challenges, despite GPUs offering superior peak floating-point performance and memory bandwidth compared to CPUs. The primary challenges arise from the irregular nature of sparse computations. The irregular memory access patterns create a strong mismatch between data access patterns and memory layout, leading to limited spatial locality and cache effectiveness. While compressed representations of sparse matrices reduce memory footprint, they incur significant overheads in accessing and processing metadata. These challenges are manifested in three critical aspects: (1) the unknown number of non-zero entries in the resulting matrix (or matrix product) prior to computation, (2) expensive parallel insert operations at random positions within the resulting matrix, and (3) load balancing issues that arise when handling input matrices with diverse sparsity structures.
Report issue for preceding element
Despite attempts to address these challenges with various approaches, including dedicated hardware accelerators and software optimizations [ naumov2010cusparse, dalton2015optimizing] , previous GPU SpGEMM methods have shown limited success. They either perform well only for relatively regular sparse matrices or introduce significant memory overhead for specific sparsity patterns [ demouth2012sparse, bell2012exposing] . Moreover, existing GPU implementations have struggled to consistently outperform well-optimized CPU approaches, highlighting the difficulty in fully utilizing GPUs' massive parallelism for sparse matrix operations [ wang2014intel] .
Report issue for preceding element
On the other hand, the advancement in 3D integration technologies has made it more viable to couple compute units close to the memory, a concept known as processing near memory (PNM) [ singh2019near] . Processing right at the “home” of data can significantly reduce data movement. Furthermore, modern GPUs are equipped with high bandwidth memory (HBM) [ lee201425] , which adopts a vertically stacked architecture that allows for greater capacity and bandwidth. Therefore, we leverage the concept of processing near GPU HBM to effectively tackle the challenges of SpGEMM.
Report issue for preceding element
In this paper, we propose and implement the Acceleration of Indirect Memory Access (AIA) solution, a novel processing-near-HBM approach to enhance performance in handling indirect memory access patterns in SpGEMM operations, thereby accelerating the overall computation. We introduce the AIA technique, designed to assist the primary computational core in sparse data computations, specifically targeting SpGEMM operations on HBM GPUs. Our work makes three key contributions through the co-design of hardware and software for accelerating SpGEMM on GPUs:
Report issue for preceding element
• We implement an optimized Hash-Based multiphase SpGEMM algorithm on H200 GPU that systematically addresses the fundamental challenges of sparse matrix multiplication through intelligent workload distribution and adaptive memory management. Our three-phase approach (row-grouping, allocation, and accumulation) employs sophisticated hash tables with collision resolution and dual thread assignment strategies (PWPR and TBPR) optimized for different workload characteristics. Report issue for preceding element
• We introduce a novel Processing-Near-HBM hardware technique, Acceleration of Indirect memory Access (AIA), that transforms SpGEMM's irregular memory access patterns into efficient sequential streams. The AIA solution, integrated between GPU cores and HBM stacks, implements ranged indirect access functionality specifically designed for SpGEMM's two-level indirection patterns. Our hardware solution improves L1 cache hit ratios from 64.41% to 75.14% in accumulation phases and from 64.66% to 88.15% in allocation phases. Report issue for preceding element
• Our hybrid hardware-software solution delivers substantial improvements across diverse workloads. For matrix self-product operations, our AIA-enhanced implementation achieves an average 80.5% runtime reduction and 6.87× throughput improvement compared to cuSPARSE. For graph analytics applications, AIA demonstrates an average of 76.5% improvement for Graph Contraction and 58.4% for Markov Clustering compared to cuSPARSE. Most significantly, for GNN training with structured pruning, our approach delivers 30.3% average training time reduction over the software-only implementation, and 48.6% over cusparse, across diverse GNN benchmark datasets and three GNN model(GCN, GIN, GraphSAGE), with large-scale datasets like Products achieving up to 76.1% speedup. These results establish the practical impact of our co-designed solution for production-scale applications. Report issue for preceding element
II Background
Report issue for preceding element
Memory Wall and Indirect Memory Access.
Report issue for preceding element
Memory wall represents a critical bottleneck in modern computing systems, particularly affecting graph analysis, sparse linear algebra, and various other applications [ chen2018tvm, kocberber2013meet, mislove2007measurement] . This challenge primarily stems from irregular memory access patterns, where data are arbitrarily accessed with poor locality, resulting in frequent cache misses and high latency when fetching data from the memory hierarchy. A key pattern contributing to this bottleneck is indirect memory access, typically appearing as x  [ a  [ i ] ] x[a[i]] , where array a a 's values serve as indices to access array x x . This pattern becomes even more complex in the form of ranged indirect access ( x  [ a  [ i ] ] , x  [ a  [ i ] + 1 ] , x  [ a  [ i ] + 2 ] , … ) (x[a[i]],x[a[i]+1],x[a[i]+2],...) , commonly seen in graph algorithms processing adjacency lists, where a  [ i ] a[i] might point to the start of a vertex's neighbor list in array x x , and multiple consecutive elements are accessed from that point. Such patterns pose significant challenges for conventional hardware prefetchers, as they require understanding both irregular access patterns and variable-length ranges of accessed data.
Report issue for preceding element
GPU-Centric Near Memory Processing and Challenges.
Report issue for preceding element
The integration of near-memory processing with GPU HBM architectures presents both opportunities and significant challenges. Several notable architectures have explored this concept in GPU contexts, with TOM [ hsieh2016transparent] pioneering a novel approach using lightweight GPU cores integrated into 3D-stacked memories, supported by an automatic compiler framework for offload decisions. Building on this foundation, Pattnaik et al. [ pattnaik2016scheduling] advanced the concept with an NMC-assisted GPU architecture featuring an affinity prediction model for kernel execution placement. Recent research has particularly focused on leveraging HBM's unique capabilities for near-memory processing. DNN-PIM [ liu2018processing] introduced a heterogeneous architecture incorporating both programmable ARM cores and fixed-function units in the HBM logic layer. Complementing this work, Boroumand et al. [ boroumand2018google] evaluated PNM architectures for consumer applications, carefully considering the practical constraints of area and power budgets in HBM implementations.
Report issue for preceding element
Despite these advances, four fundamental challenges must be addressed for effective implementation. First, the programming model must efficiently integrate with existing GPU frameworks while providing mechanisms to determine optimal code placement between host and near-memory units [ liu2018processing, boroumand2018google] . Second, memory management requires sophisticated data mapping strategies between GPU cores and HBM stacks, as demonstrated by MONDRIAN [ drumond2017mondrian] , which emphasized the importance of hardware-software co-design in optimizing memory access patterns. Third, virtual memory support must align with GPU memory management systems while maintaining efficient address translation mechanisms, a challenge effectively addressed in TESSERACT [ ahn2015scalable] and subsequent works [ ahn2015pim] . Finally, cache coherency remains a critical challenge in maintaining consistency between GPU cores and near-memory processing units, with recent work by Farmahini et al. [ farmahini2015nda] proposing innovative solutions for optimizing HBM bandwidth utilization and minimizing unnecessary off-chip traffic.
Report issue for preceding element
Prior SpGEMM Algorithms.
Report issue for preceding element
The evolution of SpGEMM algorithms reflects ongoing efforts to optimize sparse matrix multiplication across different hardware architectures. Traditional approaches can be categorized into three main strategies: outer product, inner product, and row-wise methods. The outer product method, exemplified by Dalton et al. [ dalton2015optimizing] , computes the contribution of each non-zero element in matrix A and B independently, requiring efficient merging of intermediate results. Inner product methods, as implemented by Demouth [ demouth2012sparse] , compute each element of the output matrix through dot products of corresponding rows and columns, facing challenges with memory locality. Row-wise methods, adopted by Naumov et al. [ naumov2010cusparse] , process each row of the output matrix independently, offering better parallelism but requiring careful load balancing strategies.
Report issue for preceding element
On GPU platforms, SpGEMM implementations have evolved from basic CSR-based approaches to sophisticated hybrid formats and specialized algorithms. Early implementations struggled with the irregular nature of sparse matrix operations, but recent advances have introduced various optimizations. Hash-based approaches, as demonstrated by Liu and Vinter [ liu2014efficient] , use hash tables to accumulate partial products efficiently. Sort-based methods, exemplified by Nagasaka et al. [ nagasaka2017high] , offer better memory coalescing but incur sorting overhead. Hybrid methods, such as those proposed by Gremse et al. [ gremse2015gpu] , combine multiple strategies to balance computation and memory access efficiency.
Report issue for preceding element
Despite these advancements, existing implementations still face fundamental challenges in fully utilizing GPU capabilities for SpGEMM operations. The irregular memory access patterns create a strong mismatch between data access patterns and memory layout, leading to limited spatial locality and cache effectiveness, which causes frequent data movement between memory hierarchies. Processing-Near-HBM solutions offer a promising approach to address these challenges by reducing data movement and enhancing memory access efficiency.
Report issue for preceding element
SpGEMM Accelerates GNN
Report issue for preceding element
Recent works have explored several promising approaches to GNNs through SpGEMM. SpGEMM accelerates GNN through strategic transformation of computational patterns and exploitation of induced sparsity. MaxK-GNN [ peng2024maxk] demonstrates the most dramatic approach, converting traditional SpMM operations into SpGEMM by introducing MaxK nonlinearity that sparsifies feature matrices to 87.5% sparsity. This transformation reduces global memory traffic by over 90% and achieves 3 − 7 × 3-7\times kernel-level speedups on NVIDIA GPUs, with L1 cache hit rates improving from 1.53% to 22.16%. Shivdikar et al. [ shivdikar2024neurachip] also propose a novel GNN spatial accelerator using spgemm on the sparsified feature matrix. PruneGNN [ gurevin2024prunegnn] takes a complementary approach through structured dimension-wise pruning, selectively using SpGEMM for backpropagation steps where both weight and gradient matrices are sparse, achieving 2 × 2\times average speedup on A100 GPUs through SIMD-aware kernel design. Tripathy et al. [ tripathy2024distributed] reframes GNN neighborhood sampling as a matrix-based bulk sampling technique, expressing sampling as SpGEMM operations to efficiently process multiple minibatches simultaneously. This matrix-based approach allows complex sampling procedures to be represented through a series of SpGEMM operations: computing probabilities, performing rejection sampling, and executing row and column extractions, enabling 2.5 − 8.46 × 2.5-8.46\times speedups for distributed training by processing multiple minibatches simultaneously. These implementations address SpGEMM's fundamental challenges—irregular memory access patterns, load imbalance, and accumulation bottlenecks—through techniques including warp-level edge partitioning, shared memory buffering, and row-wise product algorithms that reduce computational complexity from O  ( E  d ) O(Ed) to O  ( E  k ) O(Ek) where k ≪ d k\ll d , which collectively demonstrate SpGEMM's critical role in addressing the computational bottlenecks in GNNs, especially for large-scale graphs, while maintaining comparable accuracy to dense implementations.
Report issue for preceding element
III Optimized Hash-based Multi-phase SpGEMM on GPU
Report issue for preceding element
This section presents our optimized SpGEMM algorithm designed to leverage GPU architectural features while addressing the fundamental challenges of sparse matrix multiplication. Our approach employs a multi-phase strategy with intelligent workload distribution and adaptive memory management to maximize GPU utilization.
Report issue for preceding element
III-A Algorithm Overview
Report issue for preceding element
Our SpGEMM implementation follows the row-wise product method known as Gustavson's algorithm [ gustavson1978two] and is based on state-of-the-art hash-based SpGEMM libraries [ nagasaka2017high, parger2020speck, du2022opsparse] . For input matrices 𝐀 \mathbf{A} and 𝐁 \mathbf{B} , the algorithm computes the output matrix 𝐂 \mathbf{C} one row at a time. For each row i i of 𝐀 \mathbf{A} , every non-zero element A i , k A_{i,k} is used to scale the entire k k -th row of matrix 𝐁 \mathbf{B} . The row index k k of matrix 𝐁 \mathbf{B} is determined by the column index of the non-zero value A i , k A_{i,k} from matrix 𝐀 \mathbf{A} . All of these resulting scaled rows are then accumulated (added together, column-by-column) into the i i -th row of the output matrix 𝐂 \mathbf{C} .
Report issue for preceding element
In the implementation, we use a three-phase approach to systematically address the challenges of unknown output sparsity, irregular memory access patterns, and load imbalance. It begins with a row-grouping phase for workload analysis and preprocessing, which is then followed by an allocation phase to learn the structure of the output matrix and allocate GPU resources accordingly. It concludes with an accumulation phase to generate the out matrix. Each phase is carefully designed to exploit GPU parallelism while minimizing memory overheads.
Report issue for preceding element
Computing 𝐂 = 𝐀𝐁 \mathbf{C}=\mathbf{A}\mathbf{B} for sparse matrices 𝐀 \mathbf{A} and 𝐁 \mathbf{B} requires processing varying numbers of intermediate products for different output rows. For each row of 𝐂 \mathbf{C} , the number of intermediate products, denoted as IP, can be obtained using Algorithm 1. This metric indicates the amount of the workload needed to obtain each row of 𝐂 \mathbf{C} , so it is used as a basis for our load-balancing strategy.
Report issue for preceding element
Input: Matrix 𝐀 \mathbf{A} in CSR format ( r  p  t A , c  o  l A ) (rpt_{A},col_{A}) , Matrix 𝐁 \mathbf{B} row pointers ( r  p  t B ) (rpt_{B})
Output: i  n  t  e  r  m  e  d  i  a  t  e  C  o  u  n  t intermediateCount for each row
1 for i = 0 i=0 to l  e  n  ( r  p  t A ) − 1 len(rpt_{A})-1 do
2 c  o  u  n  t ← 0 count\leftarrow 0
3 for j = r  p  t A  [ i ] j=rpt_{A}[i] to r  p  t A  [ i + 1 ] − 1 rpt_{A}[i+1]-1 do
4 c  o  l ← c  o  l A  [ j ] col\leftarrow col_{A}[j]
5 c  o  u  n  t ← c  o  u  n  t + ( r  p  t B  [ c  o  l + 1 ] − r  p  t B  [ c  o  l ] ) count\leftarrow count+(rpt_{B}[col+1]-rpt_{B}[col])
6 end for
7 i  n  t  e  r  m  e  d  i  a  t  e  C  o  u  n  t  [ i ] ← c  o  u  n  t intermediateCount[i]\leftarrow count
8 end for
Algorithm 1 Intermediate Product Counting Report issue for preceding element
III-B Row-grouping Phase
Report issue for preceding element
To address workload imbalance inherent in SpGEMM, we implement a two-stage grouping mechanism that organizes matrix rows based on computational characteristics without physically reordering the matrix.
Report issue for preceding element
Initial Grouping. The rows of matrix 𝐀 \mathbf{A} are classified into four groups based on the number of intermediate products using logarithmic binning. Then, each row of matrix 𝐀 \mathbf{A} is reordered based on which group it belongs to. We have a map between the original row IDs and their sorted IDs according to their group. Let M  a  p  [ i ] Map[i] be the original row ID that corresponds to index i i in the sorted IDs.
Report issue for preceding element
TABLE I: GPU resource allocations for different groups
Report issue for preceding element
Input: Matrix 𝐀 \mathbf{A} : ( r  p  t A , c  o  l A ) (rpt_{A},col_{A}) , Matrix 𝐁 \mathbf{B} : ( r  p  t B , c  o  l B ) (rpt_{B},col_{B}) , T  a  b  l  e  [ ] Table[] , M  a  p Map
Output: T  a  b  l  e  [ ] Table[] with unique column indices, u  n  i  q  u  e  C  o  u  n  t uniqueCount for row i i
1 g  _  t  h  r  e  a  d  I  d  x = b  l  o  c  k  I  d  x ∗ b  l  o  c  k  D  i  m + t  h  r  e  a  d  I  d  x g_{threadIdx}=blockIdx*blockDim+threadIdx ,
2 l  a  n  e  I  d  x ← t  h  r  e  a  d  I  d  x %  4 laneIdx\leftarrow threadIdx%4 , i ← M  a  p  [ g  _  t  h  r  e  a  d  I  d  x / 4 ] i\leftarrow Map[g_{threadIdx}/4]
3 for j = r  p  t A  [ i ] + l  a  n  e  I  d  x j=rpt_{A}[i]+laneIdx to r  p  t A  [ i + 1 ] − 1 rpt_{A}[i+1]-1 𝐬𝐭𝐞𝐩 \mathbf{step} 4 4 do
4 c  o  l ← c  o  l A  [ j ] col\leftarrow col_{A}[j]
5 for k = r  p  t B  [ c  o  l ] k=rpt_{B}[col] to r  p  t B  [ c  o  l + 1 ] − 1 rpt_{B}[col+1]-1 do
6 k  e  y ← c  o  l B  [ k ] key\leftarrow col_{B}[k]
7 u  n  i  q  u  e  C  o  u  n  t ← uniqueCount\leftarrow InsertIntoTable ( k  e  y ) (key)
8 end for
9
10 end for
11 __syncwarp()
12 if L  a  n  e  I  d  x = 0 LaneIdx=0 then
13 r  p  t C  [ i + 1 ] ← r  p  t C  [ i ] + u  n  i  q  u  e  C  o  u  n  t rpt_{C}[i+1]\leftarrow rpt_{C}[i]+uniqueCount
14 end if
Algorithm 2 PWPR SpGEMM-Allocation Phase Report issue for preceding element
Input: Matrix 𝐀 \mathbf{A} : ( r  p  t A , c  o  l A ) (rpt_{A},col_{A}) , Matrix 𝐁 \mathbf{B} : ( r  p  t B , c  o  l B ) (rpt_{B},col_{B}) , T  a  b  l  e  [ ] Table[] , M  a  p Map
Output: T  a  b  l  e  [ ] Table[] with unique column indices, u  n  i  q  u  e  C  o  u  n  t uniqueCount for row i i
1 w  a  r  p  I  d  x ← t  h  r  e  a  d  I  d  x / 32 warpIdx\leftarrow threadIdx/32 , l  a  n  e  I  d  x ← t  h  r  e  a  d  I  d  x %  32 laneIdx\leftarrow threadIdx%32
2 #  w  a  r  p  s ← b  l  o  c  k  D  i  m / 32 #warps\leftarrow blockDim/32 , i ← M  a  p  [ b  l  o  c  k  I  d  x ] i\leftarrow Map[blockIdx]
3
4 1ex for j = r  p  t A  [ i ] + w  a  r  p  I  d  x j=rpt_{A}[i]+warpIdx to r  p  t A  [ i + 1 ] − 1 rpt_{A}[i+1]-1 𝐬𝐭𝐞𝐩 \mathbf{step} #  w  a  r  p  s #warps do
5 c  o  l ← c  o  l A  [ j ] col\leftarrow col_{A}[j]
6 for k = r  p  t B  [ c  o  l ] + l  a  n  e  I  d  x k=rpt_{B}[col]+laneIdx to r  p  t B  [ c  o  l + 1 ] − 1 rpt_{B}[col+1]-1 𝐬𝐭𝐞𝐩 \mathbf{step} 32 32 do
7 k  e  y ← c  o  l B  [ k ] key\leftarrow col_{B}[k]
8 u  n  i  q  u  e  C  o  u  n  t ← uniqueCount\leftarrow InsertIntoTable ( k  e  y ) (key)
9 end for
10
11 end for
12
13 __syncthreads()
14
15 if t  h  r  e  a  d  I  d  x = 0 threadIdx=0 then
16 r  p  t C  [ i + 1 ] ← r  p  t C  [ i ] + u  n  i  q  u  e  C  o  u  n  t rpt_{C}[i+1]\leftarrow rpt_{C}[i]+uniqueCount
17 end if
Algorithm 3 TBPR SpGEMM-Allocation Phase Report issue for preceding element
GPU Resource Allocation. Each row in a different group is assigned a different number of threads according to its corresponding workload. The ones with heavier workloads are assigned larger thread blocks. Each group is also processed independently, potentially for better load balancing and resource utilization. Furthermore, a hash table is created for each group in shared memory, where its size is proportional to the group's workload. This hash table is used to obtain the results of intermediate products. Table I summarizes the allocation of GPU resources for different groups.
Report issue for preceding element
III-C Allocation Phase
Report issue for preceding element
The allocation phase determines the structure of the output matrix 𝐂 \mathbf{C} by identifying unique column indices in each row without computing actual values. Multiple CUDA kernels are launched with different streams in this phase, enabling parallel execution across groups.
Report issue for preceding element
Thread Assignment Strategies. We implement two complementary thread assignment approaches optimized for different workload characteristics, namely, partial warp per row (PWPR) and thread block per row (TBPR), as shown in Algorithm 2 and Algorithm 3.
Report issue for preceding element
PWPR assigns four threads for each row of matrix 𝐀 \mathbf{A} for the light workload, i.e., Group 0. Each thread processes a portion of non-zero elements from matrix 𝐀 \mathbf{A} and their corresponding rows from matrix 𝐁 \mathbf{B} . The outer loop distributes the non-zero elements in matrix 𝐀 \mathbf{A} among the four threads in a cyclic manner (or a strided pattern) for coalesced memory access. Each tread retrieves the non-zero elements at the rows of matrix 𝐁 \mathbf{B} , each of which is indicated by the column index of each non-zero element of matrix 𝐀 \mathbf{A} . The warp-level synchronization is then done to ensure consistency before updating the row pointers of the output matrix 𝐂 \mathbf{C} .
Report issue for preceding element
TBPR assigns each block (i.e., multiples of warps) for each row of matrix 𝐀 \mathbf{A} for the moderate to heavy workloads, i.e., Groups 1–3. TBPR works in a similar way to PWPR, but based on both warp-level and thread-level parallelisms. At each time, each block processes one non-zero element from matrix 𝐀 \mathbf{A} and its corresponding row from matrix 𝐁 \mathbf{B} in a cyclic fashion. However, unlike PWPR, the inner loop distributes the process of retrieving the non-zero elements at the rows of matrix 𝐁 \mathbf{B} , each of which is indicated by the column index of each non-zero element of 𝐀 \mathbf{A} , across 32 threads (a warp). This dual-level approach maximizes memory bandwidth utilization–multiple warps process different parts of matrix 𝐀 \mathbf{A} simultaneously while threads within each warp access consecutive non-zero elements of matrix 𝐁 \mathbf{B} .
Report issue for preceding element
Hash Table. Algorithm 4 implements a collision-free hash table using linear probing. It begins with an empty hash table (initialized to − 1 -1 ) and a counter to track unique elements. When processing a new column index, it first computes a hash position using multiplication and modulo operations for balanced distribution within the hash table. It then enters a loop that handles three possible scenarios: finding an existing entry, inserting a new entry, and resolving a collision. The hash table employs atomic Compare-And-Swap operations to safely handle concurrent insertions in parallel.
Report issue for preceding element
The size of the hash table is first set to the value of IP obtained from Algorithm 1 and then determined by the number of columns with nnz entries, i.e., u  n  i  q  u  e  C  o  u  n  t uniqueCount . For each row with a large number of nnz entries, we use a two-phase approach. It first attempts to use a shared memory hash table and then falls back to global memory if the shared memory capacity is exceeded. This approach ensures efficient handling of varying row sizes while maximizing performance.
Report issue for preceding element
Input: k  e  y key , (valA,valB)
Output: u  n  i  q  u  e  C  o  u  n  t uniqueCount ,( T  a  b  l  e Table , T  a  b  l  e  v  a  l Tableval )
1 T  a  b  l  e  [ ] ← − 1 Table[]\leftarrow-1 , u  n  i  q  u  e  C  o  u  n  t ← 0 , uniqueCount\leftarrow 0, ( T  a  b  l  e  v  a  l  [ ] ← 0 Tableval[]\leftarrow 0 ) h  a  s  h  P  o  s ← ( k  e  y ∗ m  u  l  t  i  p  l  i  e  r ) %  t  a  b  l  e  S  i  z  e hashPos\leftarrow(key*multiplier)%tableSize
2 while true do
3 if T  a  b  l  e  [ h  a  s  h  P  o  s ] = k  e  y Table[hashPos]=key then
4 (atomicAdd ( & T  a  b  l  e  v  a  l  [ h  a  s  h  P  o  s ] , v  a  l  A × v  a  l  B ) (&Tableval[hashPos],valA\times valB) ) break
5 else
6 if T  a  b  l  e  [ h  a  s  h  P  o  s ] = − 1 Table[hashPos]=-1 then
7 o  l  d  V  a  l  u  e ← a  t  o  m  i  c  C  A  S  ( T  a  b  l  e + h  a  s  h  P  o  s , − 1 , k  e  y ) oldValue\leftarrow atomicCAS(Table+hashPos,-1,key)
8 if o  l  d  V  a  l  u  e = − 1 oldValue=-1 then
9 u  n  i  q  u  e  C  o  u  n  t ← u  n  i  q  u  e  C  o  u  n  t + 1 uniqueCount\leftarrow uniqueCount+1
10 (atomicAdd ( & T  a  b  l  e  v  a  l  [ h  a  s  h  P  o  s ] , v  a  l  A × v  a  l  B ) (&Tableval[hashPos],valA\times valB) ) break
11 end if
12
13 else
14 h  a  s  h  P  o  s ← ( h  a  s  h  P  o  s + 1 ) %  t  a  b  l  e  S  i  z  e hashPos\leftarrow(hashPos+1)%tableSize
15 end if
16
17 end if
18
19 end while
Algorithm 4 InsertIntoTable & (AddInTable) Report issue for preceding element
Input: Output From allocation phase, Matrix 𝐀 \mathbf{A} : ( r  p  t A , c  o  l A , v  a  l A ) (rpt_{A},col_{A},val_{A}) , matrix 𝐁 \mathbf{B} : ( r p t B , c o l B , v a l B (rpt_{B},col_{B},val_{B} ), T  a  b  l  e  [ ] Table[] , T  a  b  l  e  v  a  l  [ ] Tableval[]
Output: nnz entry of matrix 𝐂 \mathbf{C} on row i i : ( c  o  l C , v  a  l C ) i (col_{C},val_{C})_{i}
1 g  _  t  h  r  e  a  d  I  d  x = b  l  o  c  k  I  d  x ∗ b  l  o  c  k  D  i  m + t  h  r  e  a  d  I  d  x g_{threadIdx}=blockIdx*blockDim+threadIdx ,
2 l  a  n  e  I  d  x ← t  h  r  e  a  d  I  d  x %  4 laneIdx\leftarrow threadIdx%4 , i ← M  a  p  [ g  _  t  h  r  e  a  d  I  d  x / 4 ] i\leftarrow Map[g_{threadIdx}/4]
3
4 for j = r  p  t A  [ i ] + l  a  n  e  I  d  x j=rpt_{A}[i]+laneIdx to r  p  t A  [ i + 1 ] − 1 rpt_{A}[i+1]-1 𝐬𝐭𝐞𝐩 \mathbf{step} 4 4 do
5 c  o  l  I  d  x A ← c  o  l A  [ j ] colIdx_{A}\leftarrow col_{A}[j]
6 v  a  l  A ← v  a  l A  [ j ] valA\leftarrow val_{A}[j]
7 for k = r  p  t B  [ c  o  l  I  d  x A ] k=rpt_{B}[colIdx_{A}] to r  p  t B  [ c  o  l  I  d  x A + 1 ] − 1 rpt_{B}[colIdx_{A}+1]-1 do
8 k  e  y ← c  o  l B  [ k ] key\leftarrow col_{B}[k]
9 v  a  l  B ← v  a  l B  [ k ] valB\leftarrow val_{B}[k]
10 T  a  b  l  e  [ ] Table[] , T  a  b  l  e  v  a  l  [ ] Tableval[] ← \leftarrow AddInTable ( k  e  y , v  a  l  A , v  a  l  B ) (key,valA,valB)
11 end for
12
13 end for
14
15 __syncwarp()
16
17 s  t  a  r  t  P  o  s ← r  p  t C  [ i ] startPos\leftarrow rpt_{C}[i]
18 for i  d  x = l  a  n  e  I  d  x idx=laneIdx to u  n  i  q  u  e  C  o  u  n  t − 1 uniqueCount-1 𝐬𝐭𝐞𝐩 \mathbf{step} 4 4 do
19 c  o  l C  [ s  t  a  r  t  P  o  s + i  d  x ] ← T  a  b  l  e  [ i  d  x ] col_{C}[startPos+idx]\leftarrow Table[idx]
20 v  a  l C  [ s  t  a  r  t  P  o  s + i  d  x ] ← T  a  b  l  e  v  a  l  [ i  d  x ] val_{C}[startPos+idx]\leftarrow Tableval[idx]
21 end for
22 __syncwarp()
23 ( c o l C , v a l C ) i = B i t o n i c S o r t ( (col_{C},val_{C})_{i}=BitonicSort(
24 c  o  l C  [ s  t  a  r  t  P  o  s ] , … , c  o  l C  [ s  t  a  r  t  P  o  s + u  n  i  q  u  e  C  o  u  n  t − 1 ] , col_{C}[startPos],...,col_{C}[startPos+uniqueCount-1],
v a l C [ s t a r t P o s ] , … , v a l C [ s t a r t P o s + u n i q u e C o u n t − 1 ] ) val_{C}[startPos],...,val_{C}[startPos+uniqueCount-1])
Algorithm 5 PWPR SpGEMM-Accumulation Phase Report issue for preceding element
III-D Accumulation Phase
Report issue for preceding element
This final phase combines the results of intermediate products to obtain the elements of the output matrix 𝐂 \mathbf{C} in three steps. Similar to the allocation phase, we also implement two complementary thread assignment approaches, where the PWPR approach is shown in Algorithm 5. The accumulation algorithm performs the final value computation phase of SpGEMM, building upon the structure determined in the allocation phase. This algorithm maintains the same 4-thread or entire threadblock cooperative approach but now focuses on computing actual numerical results rather than just identifying output structure.
Report issue for preceding element
Value Computation and Accumulation. The algorithm maintains dual hash tables – one for column indices and another for accumulated values. As intermediate products are computed, the hash table accumulates contributions to each unique column position. When multiple multiplication paths produce values for the same column index, atomic operations ensure correct accumulation. This phase simultaneously counts the total non-zero elements per row, essential for CSR format construction.
Report issue for preceding element
Element Gathering. Once accumulation completes, threads collaboratively extract the computed (column, value) pairs from the hash table into contiguous memory. Each thread is assigned specific hash table entries to process, ensuring balanced workload distribution and coalesced memory access patterns during the gathering operation.
Report issue for preceding element
Column Index Sorting. The final stage sorts the gathered elements by column index to maintain CSR format requirements. Each thread determines its assigned element's position through parallel comparison operations against other elements in the same row. Based on these computed positions, threads write their elements directly to the appropriate locations in global memory.
Report issue for preceding element
This three-step organization enables efficient parallel processing while guaranteeing correctness of the CSR output, balancing the competing demands of accumulation accuracy, memory efficiency, and computational throughput.
Report issue for preceding element
IV Near Memory Processing: HBM-AIA
Report issue for preceding element 
Figure 1: H200 GPU with AIA agent on HBM Report issue for preceding element
Our proposed hardware solution integrates Indirect Access capabilities with the GPU's High Bandwidth Memory (HBM) to accelerate Sparse General Matrix-Matrix Multiplication (SpGEMM). This integration leverages the GPU's parallel processing power while addressing the irregular memory access patterns inherent in SpGEMM operations.
Report issue for preceding element
IV-A Motivation of AIA
Report issue for preceding element
Hash-based multi-phase SpGEMM faces three critical bottlenecks. First, the grouping phase requires massive atomic operations on global memory, consuming over 10% of execution time despite its O  ( #  ( r  o  w ) ) O(#(row)) complexity. Second, the hashing method's random access patterns cause severe bank conflicts in shared memory. Third, hash table sizing presents an unavoidable trade-off: large tables matching maximum nnz per row cause high collision rates, while uniform sizing underutilizes hardware for smaller rows.
Report issue for preceding element
These issues arise from the fundamental mismatch between SpGEMM's irregular memory access patterns and GPU architecture. The AIA technique addresses this by transforming random accesses into sequential streams through processing-near-HBM architecture. By implementing ranged indirect access at the HBM level, AIA converts SpGEMM's two-level indirection into predictable patterns that better utilize the memory hierarchy while reducing data movement and eliminating intermediate memory allocations.
Report issue for preceding element
IV-B HBM-AIA on Modern GPU
Report issue for preceding element
The SpGEMM hardware solution integrates AIA functionality directly into the GPU's memory hierarchy. The figure 1 shows the layout of Streaming Multiprocessors (SMs) and HBM Stacks in the H200 GPU. The HBM subsystem consists of 6 stacks (Stack 1 shown in detail), with each stack containing multiple HBM dies. The AIA engines are embedded within the HBM Controller at the base of each stack, positioned strategically between the memory dies and the GPU cores. This placement enables the AIA engines to perform indirect memory access operations directly at the memory level, transforming irregular access patterns into efficient sequential streams before data traverses the memory hierarchy. The 141 GB Global Memory capacity is distributed across the HBM stacks, with the AIA engines managing data gathering operations locally within each stack. This architecture minimizes data movement by processing indirect accesses near the memory source, reducing pressure on the L2 cache and PCIe/NVlink interfaces. The AIA engines work in conjunction with the GPU's cache hierarchy—gathering and coalescing scattered data accesses at the HBM level ensures that when data reaches the L1 and L2 caches, it arrives in more cache-friendly sequential patterns, thereby improving overall cache utilization and reducing memory access latency for sparse matrix operations.
Report issue for preceding element
IV-C AIA Ranged index Illustration
Report issue for preceding element 
Figure 2: AIA ranged index Report issue for preceding element
Figure 2 compares traditional CPU+DRAM indirect memory access (left) with the GPU+AIA PNHBM approach (right). In the traditional approach, the CPU performs N N iterations where each iteration requires two separate memory transactions: first sending a request for index b  [ i ] b[i] and receiving its value, then using that value to request the range a  [ b  [ i ] ] a[b[i]] through a  [ b  [ i ] + R − 1 ] a[b[i]+R-1] , resulting in 2  N 2N total memory round trips with associated latency penalties. In contrast, the GPU+AIA PNHBM approach consolidates this into a single operation where the GPU sends one AIA range request with parameters ( d  s  t , N , R , a , b ) (dst,N,R,a,b) to the AIA Engine located within the Processing Near HBM (PNHBM), which then performs all N N indirect lookups locally near the memory—fetching each b  [ i ] b[i] and retrieving the corresponding range a  [ b  [ i ] ] a[b[i]] to a  [ b  [ i ] + R − 1 ] a[b[i]+R-1] internally—before returning all results in a single bulk response stream. This transformation from 2N processor-memory round-trips to just one request-response pair eliminates the latency overhead of multiple communications, while the AIA Engine's internal switching network (shown in the interconnect diagram) efficiently routes the indirect memory accesses within the HBM stack, converting inherently random access patterns into optimized sequential streams that better utilize memory bandwidth and reduce overall access latency.
Report issue for preceding element
IV-D AIA Kernel on SpGEMM
Report issue for preceding element
The GPU kernel for SpGEMM is integrated using the AIA (ranged index R = 2 R=2 ) approach. Each thread processes a row of matrix 𝐀 \mathbf{A} , using AIA to efficiently gather the required data from matrix 𝐁 \mathbf{B} . The AIA-range2 technique effectively addresses the fundamental challenge of irregular memory access patterns inherent in SpGEMM operations by transforming the two-level indirection problem into optimized sequential data streams. In SpGEMM, computing the result matrix 𝐂 = 𝐀𝐁 \mathbf{C}=\mathbf{A}\mathbf{B} requires accessing matrix 𝐁 \mathbf{B} 's rows corresponding to the non-zero column indices in each row of matrix 𝐀 \mathbf{A} , creating a complex indirect access pattern. As illustrated in Figure 3, the AIA solution maps GPU block IDs to matrix rows through load-balanced mapping, where each group of rows has similar computational complexity. For block i i processing row j j , the first AIA-range2 function computes a  i  a  _  1  [ 2  i ] = r  p  t A  [ M  a  p  [ i ] ] aia_1[2i]=rpt_{A}[Map[i]] and a  i  a  _  1  [ 2  i + 1 ] = r  p  t A  [ M  a  p  [ i ] + 1 ] aia_1[2i+1]=rpt_{A}[Map[i]+1] to define the range of non-zero elements in matrix 𝐀 \mathbf{A} , while the second AIA-range2 function a  i  a  _  2  [ 2  j ] = r  p  t B  [ c  o  l A  [ j ] ] aia_2[2j]=rpt_{B}[col_{A}[j]] and a  i  a  _  2  [ 2  j + 1 ] = r  p  t B  [ c  o  l A  [ j ] + 1 ] aia_2[2j+1]=rpt_{B}[col_{A}[j]+1] define the corresponding ranges in matrix 𝐁 \mathbf{B} . This approach enables the GPU cores to efficiently gather the required data from HBM in a more predictable pattern, significantly improving cache utilization and reducing memory latency. The grouping strategy enhances load balancing by ensuring that threads within the same block process rows with similar sparsity characteristics, while the ranged indirect access mechanism converts the traditionally irregular SpGEMM memory access patterns into optimized sequential streams that better match the GPU's memory hierarchy design.
Report issue for preceding element 
Figure 3: AIA on SpGEMM: A Toy Example Report issue for preceding element
This kernel structure allows for efficient parallelization of the SpGEMM operation while leveraging the AIA capabilities to handle irregular memory accesses. By integrating AIA functionality into the HBM-equipped GPU architecture, our solution provides a powerful platform for accelerating SpGEMM operations, addressing the key challenges of irregular memory access and load balancing in sparse matrix computations.
Report issue for preceding element
V Benchmarks/Applications
Report issue for preceding element
This section introduces the benchmarks and applications we evaluate to demonstrate the effectiveness of our AIA-accelerated SpGEMM implementation. We focus on key graph algorithms and sparse matrix operations that frequently occur in scientific computing and data analytics. Typical candidates include Markov Clustering (MCL), and Graph Contraction, and the widely used Graph Neural Network (GNN). In each application, we explain where and how SpGEMM can be applied.
Report issue for preceding element
V-A MCL
Report issue for preceding element
The Markov Cluster (MCL) algorithm is an unsupervised graph clustering method that simulates stochastic flows on graphs to detect natural clusters. It operates on the principle that random walks on a graph will tend to get trapped within densely connected regions, corresponding to clusters. The algorithm begins by converting the input graph into a column stochastic matrix. It then iteratively applies two main operations: expansion and inflation. The expansion step, implemented as matrix multiplication or exponentiation, simulates random walks and allows flow to spread out. The inflation step, realized through the Hadamard power followed by normalization, strengthens intra-cluster connections while weakening inter-cluster connections. A crucial intermediate step, pruning, is applied to maintain sparsity by removing small entries and retaining only the top-k entries in each column. This process is repeated until convergence, typically when changes between successive iterations become negligible. The final matrix is interpreted to extract clusters, often represented as the connected components of the graph implied by the matrix. MCL's effectiveness in detecting clusters in various network types, coupled with its mathematical elegance, has made it a popular choice in bioinformatics and other fields dealing with complex network data.
Report issue for preceding element
Input: Weighted network G G , expansion parameter e e , inflation parameter r r , pruning threshold θ \theta , k k
Output: c  l  u  s  t  e  r  s clusters
1 AddSelfLoops  ( G ) \text{AddSelfLoops}(G)
2 A ← ColumnStochasticMatrix  ( G ) A\leftarrow\text{ColumnStochasticMatrix}(G)
3 ColumnNormalize  ( A ) \text{ColumnNormalize}(A)
4
5 while change in successives iterations do
// Expansion: random walks from all vertices
6 B ← A e B\leftarrow A^{e}
7
// Prune: Sparsify the matrix
8 C ← Prune  ( B , θ , k ) C\leftarrow\text{Prune}(B,\theta,k)
9 for each column j j in C C do
10 Remove entries C i  j < θ C_{ij}<\theta
11 Keep only top- k k entries in column j j
12
13 end for
14
// Inflation: strengthen intra-cluster connections
15 for each entry C i  j C_{ij} in C C do
16 C i  j ← ( C i  j ) r C_{ij}\leftarrow(C_{ij})^{r}
17
18 end for
19
20 A ← ColumnNormalize  ( C ) A\leftarrow\text{ColumnNormalize}(C)
21
22 end while
23
24 c  l  u  s  t  e  r  s ← InterpretMatrix  ( A ) clusters\leftarrow\text{InterpretMatrix}(A)
return c  l  u  s  t  e  r  s clusters
Algorithm 6 Markov Cluster (MCL) Algorithm Report issue for preceding element
V-B Graph Contraction
Report issue for preceding element
Graph contraction is a fundamental operation in graph theory and algorithm design that reduces the size of a graph by merging nodes with shared labels. This process is particularly useful in iterative graph algorithms where the problem can be solved on progressively smaller subgraphs. The algorithm efficiently implements contraction through matrix multiplication, utilizing a strategically constructed sparse matrix S S . Given a graph G G and a set of node labels, the algorithm first determines the number of nodes n n and the maximum label value m m . It then creates the sparse matrix S S of dimensions m  ×  n m\texttimes n , where each column corresponds to a node's original label, and each row represents a new label in the contracted graph. The matrix S S contains only ones, with their positions determined by the node labels. The contraction is then performed by the matrix multiplication C = S  ×  G  ×  S T C=S\texttimes G\texttimes S^{T} , where G G is the original graph's adjacency matrix and S T S^{T} is the transpose of S S . This operation effectively combines rows and columns of G G that share labels, resulting in a new, smaller adjacency matrix C C representing the contracted graph. The left multiplication by S S combines rows with the same label, while the right multiplication by S T S^{T} combines columns, ensuring that edges between merged nodes are properly accounted for in the contracted graph.
Report issue for preceding element
Input: Graph G G , node labels l  a  b  e  l  s labels
Output: Contracted graph C C
1
2 n ← length  ( G ) n\leftarrow\text{length}(G) ;
3 m ← max  ( l  a  b  e  l  s ) m\leftarrow\max(labels) ;
4 S ← sparse ( l a b e l s , 1 : n , 1 , m , n ) S\leftarrow\text{sparse}(labels,1:n,1,m,n) ;
5 C ← S × G × S T C\leftarrow S\times G\times S^{T} ;
return C C
Algorithm 7 Graph Contraction Report issue for preceding element
V-C Graph Neural Network
Report issue for preceding element 
Figure 4: GNN with Pruning Layer Report issue for preceding element
There are two promising approaches to accelerate Graph Neural Networks (GNNs) through sparse-sparse matrix multiplication (SpGEMM). One is to introduce pruning that sparsifies feature matrices, effectively transforming conventional SpMM operations into more efficient SpGEMM operations for full-batch training. The other is to formulate neighborhood sampling operations as Matrix-based Bulk sampling, where SpGEMM can be used for sampling in mini-batch training.
Report issue for preceding element
GNN large graph full-batch training represents a challenging computational domain, particularly in forward propagation steps. Consider a graph G = ( V , E , A ) G=(V,E,A) containing | V | |V| nodes and | E | |E| edges, where the adjacency matrix A ∈ ℝ | V | × | V | A\in\mathbb{R}^{|V|\times|V|} exhibits high sparsity. Traditional GNN forward propagation follows X l = A ⋅ h  ( X l − 1 ) X_{l}=A\cdot h(X_{l-1}) , where X l X_{l} represents the node features at layer l l , and h  ( X l − 1 ) h(X_{l-1}) denotes transformed features from the previous layer. These operations typically employ SpMM (Sparse-Dense Matrix Multiplication), becoming computationally intensive for large graphs.
Report issue for preceding element
In the forward pass of GNN using pruning techniques, the computation begins with features from the prior layer, which undergo processing through a pruning layer, say a top-K layer, that applies top-k selection-based sparsification to maintain only the most significant activations while eliminating lower-magnitude connections, effectively transforming conventional SpMM operations into more efficient SpGEMM operations, significantly reducing global memory traffic compared to traditional SpMM. The forward computation is mathematically reformulated as:
Report issue for preceding element
X l = A ⋅ TopK  ( X l − 1 , k )  W l X_{l}=A\cdot\text{TopK}(X_{l-1},k)W_{l}
(1)
where TopK  ( X l − 1 , k ) \text{TopK}(X_{l-1},k) retains only the top-k values per sample or globally, creating a sparse representation:
Report issue for preceding element
TopK  ( X l − 1 , k ) = X l − 1 ⊙ M k \text{TopK}(X_{l-1},k)=X_{l-1}\odot M_{k}
(2)
with M k M_{k} being a binary mask where M k  [ i , j ] = 1 M_{k}[i,j]=1 if X l − 1  [ i , j ] X_{l-1}[i,j] is among the top-k values, and 0 otherwise.
Report issue for preceding element
The corresponding backward propagation also benefits from sparsity, expressed as:
Report issue for preceding element
∂ ℒ ∂ X l − 1 = M k ⊙ ( A T ⋅ ∂ ℒ ∂ X l  W l T ) \frac{\partial\mathcal{L}}{\partial X_{l-1}}=M_{k}\odot\left(A^{T}\cdot\frac{\partial\mathcal{L}}{\partial X_{l}}W_{l}^{T}\right)
(3)
where the mask M k M_{k} from the forward pass ensures gradients flow only through the top-k selected elements, naturally implementing gradient sparsity without additional computation. This winner-take-all gradient routing reinforces the importance of high-magnitude activations during training while maintaining computational efficiency through sparse operations.
Report issue for preceding element
For mini-batch training scenarios, the matrix-based bulk sampling approach expresses GNN neighborhood sampling as a series of SpGEMM operations. This framework formulates various sampling algorithms using the same matrix abstraction, as outlined in Algorithm 1. Each algorithm takes as input: (1) a sparse adjacency matrix A A , (2) a sparse sampler-dependent matrix Q L Q^{L} that holds minibatch vertices, (3) batch size b b , and (4) sampling parameter s s . The output is a list of sampled adjacency matrices A 0  …  A L − 1 A^{0}\ldots A^{L-1} for a minibatch, where each A l A^{l} is used in layer l l 's aggregation step during forward propagation.
Report issue for preceding element
The algorithm follows a consistent three-step framework for each layer l l from L L down to 1: First, it computes probability distributions via SpGEMM as P ← Q l  A P\leftarrow Q^{l}A , where matrix P P holds one distribution per row. Second, it applies algorithm-specific normalization with NORM  ( P ) \text{NORM}(P) . Third, it performs sampling with Q l − 1 ← SAMPLE  ( P , b , s ) Q^{l-1}\leftarrow\text{SAMPLE}(P,b,s) using Inverse Transform Sampling to select s s non-zeros per row of P P . Finally, it extracts the sampled adjacency submatrix with A l ← EXTRACT  ( A , Q l , Q l − 1 ) A^{l}\leftarrow\text{EXTRACT}(A,Q^{l},Q^{l-1}) by selecting rows from vertices in Q l Q^{l} and columns from vertices in Q l − 1 Q^{l-1} . Different sampling algorithms implement specialized versions of the NORM and EXTRACT functions. For GraphSAGE, each row of P P represents the neighborhood of a batch vertex. For LADIES, each row of P P represents the distribution across the aggregated neighborhood of the entire batch. This uniform representation enables extending the approach to sample multiple minibatches in bulk, enhancing efficiency through communication-avoiding SpGEMM algorithms in distributed settings.
Report issue for preceding element
This matrix-based approach enables efficient processing of multiple minibatches while reducing communication overhead through communication-avoiding SpGEMM algorithms when distributed across devices.
Report issue for preceding element
VI Experimental Results
Report issue for preceding element
Hardware Configuration. All experiments were conducted on a Linux server with a 3.2GHz AMD EPYC 9555 64-Core CPU and 1.5 TB RAM. Our AIA solution is implemented on an NVIDIA H200 GPU.
Methodology. We compare our AIA accelerated SpGEMM against the original implementation without the AIA technique and the classic baseline (cuSPARSE library). Performance is evaluated based on execution time or FLOPS for matrix multiplication, where the latter is calculated as twice the number of intermediate products divided by execution time.
Report issue for preceding element
TABLE II: Matrix Data Report issue for preceding element
VI-A Matrix Self-product Performance
Report issue for preceding element
We selected 10 square matrices from the University of Florida Sparse Matrix Collection, commonly used for evaluating sparse matrix computations on GPUs. Table II summarizes the characteristics of these matrices, which vary significantly in size, sparsity, and non-zero element distribution.
Report issue for preceding element
Cache Hit Ratio: Figure 5 shows the L1 cache hit ratio for the scircuit and cage15 datasets, comparing implementations with and without AIA across accumulation and allocation phases. AIA significantly improves cache utilization in both phases for both datasets. For scircuit, the hit ratio increases from 64.41% to 75.14% in the accumulation phase and from 64.66% to 88.15% in the allocation phase. Similarly, for cage15, improvements are observed from 35.94% to 50.02% in the accumulation phase and from 64.01% to 84.10% in the allocation phase. These results demonstrate AIA's effectiveness in optimizing memory access patterns, particularly in the allocation phase.
Report issue for preceding element 
Figure 5: L1 Cache Hit Ratio Comparison Report issue for preceding element
Runtime and GFLOPS Analysis: Figure 6 presents the runtime and GFLOPS performance comparison of matrix self-product operations. The AIA-enhanced implementation achieves an average 80.5% runtime reduction compared to cuSPARSE, with execution times dropping from 240.48ms to 46.84ms on average. Individual improvements range from moderate gains on smaller matrices to dramatic speedups on large-scale problems—cage15 shows a 70.5% reduction (262.5ms vs 888.4ms) while wb-edu demonstrates 81.0% improvement (189.0ms vs 993.0ms). The GFLOPS comparison reveals a 6.87× average throughput improvement over cuSPARSE, with exceptional gains on scientific datasets like Wind Tunnel (9.4× speedup) and Protein (6.1× speedup). In runtime measurements, AIA achieves reductions ranging from 10-27% compared to the software-only approach, with particularly notable improvements on large-scale matrices. These consistent performance advantages across diverse matrix structures, from road networks to web graphs, validate the effectiveness of our hardware acceleration in optimizing irregular memory access patterns inherent in SpGEMM operations.
Report issue for preceding element
VI-B Graph Analytical Workload Performance
Report issue for preceding element 
Figure 6: Runtime and GFLOPS Comparison Report issue for preceding element 
Figure 7: SpGeMM Graph Applications Performance Improvement (AIA vs. Without AIA) Report issue for preceding element 
Figure 8: SpGeMM Graph Applications Performance Improvement (AIA vs. cuSPARSE) Report issue for preceding element
Figure 7 and Figure 8 illustrate the performance improvements achieved by AIA over without-AIA and cuSPARSE for two graph applications: Graph Contraction and Markov Clustering (MCL). For Graph Contraction, AIA shows significant improvements ranging from 4.1% to 17.3%. The most notable improvements are observed with RoadNet-TX (17.3%) and Wind Tunnel (12.0%) datasets. Web-Google shows 8.9% improvement, while Protein, Economics, and amazon0601 demonstrate 7.4%, 5.8%, and 4.1% improvements, respectively. Markov Clustering exhibits strong performance gains across all datasets. Wind Tunnel dataset achieves the highest improvement at 13.8%, followed by web-Google at 10.2%. Other datasets show consistent gains: RoadNet-TX (9.0%), amazon0601 (8.3%), Economics (7.2%), and Protein (5.0%). MCL's improvement percentages, particularly for complex datasets like Wind Tunnel and web-Google, suggest that AIA is especially effective for iterative graph algorithms with multiple SpGEMM operations.
Report issue for preceding element
Comparing our AIA-enhanced SpGEMM implementation against cuSPARSE for Graph Contraction and Markov Clustering, the AIA approach achieves significant speedups, averaging 76.5% for Graph Contraction and 58.4% for MCL, with peak improvements reaching 91.1% (Protein) and 88.7% (Economics), respectively. These consistent performance gains across diverse matrix structures, from road networks to scientific datasets, demonstrate the effectiveness of our hardware acceleration in transforming irregular memory access patterns into efficient sequential streams, yielding an overall average speedup of 67.5% over cuSPARSE.
Report issue for preceding element
VI-C Graph Neural Network Training Performance
Report issue for preceding element
We evaluate the effectiveness of our SpGEMM implementation on a full-batch Graph Neural Network training workload containing pruning layers across six benchmark datasets in Table III and three GNN architectures (GCN, GIN, and GraphSAGE). Our experimental analysis demonstrates substantial performance improvements over baselines and reveals important scalability characteristics.
Report issue for preceding element
TABLE III: Dataset Characteristics for SpGEMM Performance Evaluation
Report issue for preceding element
Training Time Analysis with AIA. Figure 10 presents the training time improvements achieved through AIA acceleration. The results demonstrate consistent performance gains across all datasets and models, with an overall average improvement of 30.3%. Notably, larger graphs exhibit more substantial improvements: Products (2.4M nodes) achieves 67.4%, 65.4%, and 65.3% speedup for GCN, GIN, and SAGE respectively, while Yelp (717K nodes) shows 52.2%, 50.1%, and 47.9% improvements. The performance gains correlate positively with graph size, indicating superior scalability of our approach. Smaller graphs such as Flickr demonstrate modest improvements (15.0%, 10.1%, 7.6%), while medium-sized graphs like Protein and Arxiv show intermediate gains of 20-25%. This trend validates our hypothesis that AIA's benefits amplify with increasing memory access irregularity characteristic of larger graphs.
Report issue for preceding element
AIA Performance Comparison with cuSPARSE. Figure 11 quantifies the performance improvement of our AIA implementation compared to the cuSPARSE baseline. The results show an average improvement of 48.6% across all configurations. The most significant gains are observed on the Products dataset (76.1%, 75.1%, 75.9% for GCN, GIN, and SAGE respectively) and Protein dataset (64.9%, 65.2%, 65.3%). Reddit and Yelp datasets demonstrate consistent improvements in the 54-60% range, while Arxiv shows moderate gains of approximately 20%. The relatively uniform performance across different GNN architectures (standard deviation ¡ 2% for most datasets) indicates that our optimization is architecture-agnostic and broadly applicable to various GNN formulations.
Report issue for preceding element
Scalability Analysis. Figure 9 illustrates the relationship between graph size and AIA improvement ratio on spgemm operation, revealing a strong positive correlation (Pearson's r = 0.94). The improvement percentage increases from 15.30% for Flickr (89K nodes) to 89.16% for Products (2.4M nodes), with an average improvement of 41.7% across all datasets. The superlinear scaling behavior observed for graphs exceeding 500K nodes can be attributed to two factors: (i) increased memory access irregularity in larger graphs amplifies the benefits of AIA's indirect access optimization, and (ii) the higher reuse distance in large graphs better utilizes AIA's prefetching capabilities. The exception observed for Reddit (233K nodes), showing 23.07% improvement despite its size, suggests that graph topology and sparsity patterns also influence AIA effectiveness.
Report issue for preceding element
AIA demonstrates superior scalability with graph size, achieving up to 89.16% improvement for the largest tested dataset, confirming its effectiveness for production-scale GNN workloads. The consistent performance improvements across GCN, GIN, and GraphSAGE architectures (variance ¡ 3% within datasets) validate the generalizability of our approach across diverse GNN formulations. The combination of structured pruning with AIA acceleration yields multiplicative benefits, with total training time reductions averaging 30.3% beyond pruning alone, demonstrating the complementary nature of algorithmic and architectural optimizations. These results establish our AIA-enhanced SpGEMM as an effective acceleration technique for GNN training, particularly valuable for large-scale graph applications where memory access patterns dominate computational bottlenecks.
These improvements across different applications consistently demonstrate AIA's effectiveness in handling complex, application-specific workloads beyond basic SpGEMM operations. The results are particularly impressive for larger, more complex datasets and iterative algorithms, validating AIA's scalability and practical applicability in real-world graph processing scenarios.
Report issue for preceding element 
Figure 9: SpGEMM AIA Time Reduction vs Graph Size (AIA vs. Without AIA) Report issue for preceding element 
Figure 10: Training time reduction ratio with AIA for prunned GNN (AIA vs. Without AIA) Report issue for preceding element 
Figure 11: Training time reduction ratio with AIA for prunned GNN (AIA vs. cuSPARSE) Report issue for preceding element
VII Conclusion
Report issue for preceding element
This paper presents the Acceleration of Indirect memory Access (AIA) , a novel Processing-Near-HBM solution for optimizing SpGEMM operations on GPUs. Our implementation achieves significant performance improvements across multiple evaluation metrics. For basic SpGEMM operations, our hash-based implementation with AIA delivers 80.5% runtime reduction and 6.87 × \times throughput improvement compared to cuSPARSE. Cache utilization analysis reveals substantial improvements, with L1 cache hit ratios increasing from 64.41% to 75.14% in accumulation phases and from 64.66% to 88.15% in allocation phases. In practical graph applications, AIA shows up to 17.3% runtime reduction over the non-AIA baseline. When compared to cuSPARSE, Graph Contraction achieves 76.5% runtime reduction, and Markov Clustering achieves 58.4% runtime reduction. For GNN training workloads with structured pruning, our approach delivers an average of 1.95 × \times speedup, with large-scale datasets like Products (2.4M nodes) achieving up to 4.18 × \times speedup while maintaining model accuracy.
Report issue for preceding element
These results establish AIA as an effective solution for accelerating sparse matrix operations on modern GPU architectures, particularly valuable for large-scale graph processing and iterative algorithms that rely heavily on SpGEMM operations.
Report issue for preceding element
Report Issue
Report Github Issue
Title: Content selection saved. Describe the issue below: Description:
Submit without Github Submit in Github
Report Issue for Selection
Generated by L A T E xml
Instructions for reporting errors
We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the methods listed below:
Click the "Report Issue" button.
Open a report feedback form via keyboard, use " Ctrl + ?".
Make a text selection and click the "Report Issue for Selection" button near your cursor.
You can use Alt+Y to toggle on and Alt+Shift+Y to toggle off accessible reporting links at each section.
Our team has already identified the following issues. We appreciate your time reviewing and reporting rendering errors we may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability should not be a barrier to accessing research. Thank you for your continued support in championing open access for all.
Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a list of packages that need conversion, and welcome developer contributions.