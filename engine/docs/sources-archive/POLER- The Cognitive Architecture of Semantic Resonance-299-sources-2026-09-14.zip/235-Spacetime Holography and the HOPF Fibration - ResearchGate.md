> Source: https://www.researchgate.net/publication/226279997_Spacetime_Holography_and_the_HOPF_Fibration

(PDF) Spacetime Holography and the HOPF Fibration
Home
Physical Sciences
Quantum Physics
Quantum Mechanics
Article PDF Available
Spacetime Holography and the HOPF Fibration
April 2005
Foundations of Physics Letters 18(2):183-193
DOI: 10.1007/s10702-005-3961-7
Authors:
Lawrence Crowell
Institute for Advanced Study
Robert Betts
The Open University
Download full-text PDF Read full-text
Download full-text PDF
Read full-text
Download citation
Copy link Link copied
Read full-text
Download citation
Copy link Link copied
Citations (1)
References (13)
Abstract
Quantum mechanics and general relativity share an equivalence with respect to the holographic principle. Large-scale fluctuations predicted by the holographic principle may be derived from the quantum mechanics of spin. As holographic theories, quantum mechanics and general relativity in quaternionic bases are formally similar. Gravitation may not be properly quantized and unified with quantum fields in the usual manner, but rather gravitation and Dirac quantum fields as two separate spinor fields that form pairs which define octonions. 
Discover the world's research
25+ million members
160+ million publication pages
2.3+ billion citations
Join for free 
Public Full-text 1
Content uploaded by Lawrence Crowell
Author content
All content in this area was uploaded by Lawrence Crowell on May 28, 2015
Content may be subject to copyright.
SP ACETIME HOLOGRAPHY AND THE HOPF
FIBRA TION
Lawrence B. Cro well a and Robert Betts b
a Alpha Institute of A dvance d Study
Budapest, Hungary
E-mail:lcrowell@swcp.com
b University of Massachusetts
Department of Mathematics
Boston Harbor Campus
Received
Quantum mechanics and general relativit y share an equivalence with
respect to the holographic principle. Large scale ﬂuctuations predicted
by the holographic principle may be derived from the quan tum mechan-
ics of spin. As holographic theories, quantum mechanics and general
relativity in quaternionic bases are formally similar. Gravitation may
not be properly “quantized” and uniﬁed with quantum ﬁelds in the
usual manner, but rather gravitation and Dirac quantum ﬁelds as t wo
separate spinor ﬁelds that form pairs which deﬁne octonions.
Key words: Holographic principle, Hopf bibration, super Hamiltonian,
metric ﬂuctuations, Bott periodicity, octonions.
HOLOGRAPHIC PRINCIPLE FROM QUANTUM
THEOR Y OF SPIN
The holographic principle states that ﬁelds in a volume of spacetime
are determined by ﬁelds on the boundary of that space [1]. As such
measured ﬂuctuations in a length δL are related to the Planck scale
according to ( δL/L) 3'( L p/L) 2, L p= p G~/c 3[2]. This principle
may be derived from basic notions of spin in quantum mec hanics.
Start with the spins in 3-space { S x, S y, S z} that are represented
1
by Pauli matrices. The standard equations of motion are
δS i
t = i
~ ω ij k S j S k,(1)
where t ∼ p G~/c 5= t p. δS/t is a functional derivative
lim  → 0( S( t+ t)− h S i( t)) that deﬁnes δS = h t, δ S/t i as a phys-
ical ﬂuctuation. The frequency of the system is ω= ( n+ 1/ 2) ω 0,
and ω 0= 2 π/t, where the p eriodicity of the system is t >> t p. The
square of the spin ﬂuctuation is
 δS
S  2= 4 π 2( n+ 1/ 2) 2  t p
t  2,(2)
and is a measure of the ﬂuctuation on the energy surface embedded in
phase space. The ﬂuctuation in the volume δV s ∼( δS) 3 is
δV s=− i[ δ S 0, δ S 00]
· δ S =~ δS 000
· δ S '~  t p
t  2 S 2.(3)
With V s=~ 3 ω 3 t 3 and δV s=~ 3 ω 3( δ t) 3, Eq. 3 is
ω 3( δt) 3' 4 π 2  S
~  2  t p
t  2.(4)
Since S= ( n+ 1/ 2)~, this leads to the ﬁnal result
 δt
t  3'( n+ 1/ 2) 2
2 π  t p
t  2,(5)
which is similar to the result for time ﬂuctuations due to the holo-
graphic principle.
It is of physical interest that the abov e used absolutely nothing
involving general relativit y, except a fundamental cutoﬀ in the scale of
spacetime. This is given by the U(1) ﬁbration π− 1 C 1 → C P 1. Yet
the same result may be derived using general relativity. The above
suggests that general relativity and quantum mec hanics are identical
when it comes to the holographic principle. The SU (2) spinor algebra
of general relativity, reduced to the U(1) algebra for horizons, [4] with
respect to the diﬀeomorphism constraint is an event horizon the induces
a censorship, which has its analogue in decoherence that acts as a
quantum censorship [5].
2
SPINOR GRA VITY AND SP A CETIME
FLUCTUA TIONS
An analysis of metric ﬂuctuations may be conducted with the Dirac
operator. The relationship between the Dirac ﬁeld and general relativ-
ity is easily seen with the “Diracology” tr( γ µ γ ν) = 4 g µν , for the Dirac
operator i∂ µ( γ µ ψ). This has a position dependent representation of the
Dirac matrices γ µ= γ µ( x). The Dirac operator is then expanded as
∂ µ( γ µ ψ) = γ µ ∂ µ ψ+ Γ µ νµ γ ν ψ, (6)
where Γ µ νµ is the Christoﬀel symbol for a spacetime connection. This
is consistent with the cov ariant constancy of the metric D σ g µν = 0.
The holographic ﬂuctuation of the metric is δg µν ∼( L p/L) 2/ 3 g µν ,
with δg µν = 4( δ γ µ) γ ν+ 4 γ µ δγ ν.(7)
F or the Dirac ﬁeld there is the conserved current J µ= i ¯
ψγ µ ψ, and
spacetime ﬂuctuations are such that δJ µ= 0, or
( δ ¯
ψ) γ µ ψ+ ¯
ψγ µ δ ψ + ¯
ψ( δγ µ) ψ= 0.(8)
Fluctuations of the ﬁeld are coupled to metric ﬂuctuations, and the
spinor ﬁeld is dependent inhomogenously upon local metric ﬂuctua-
tions. This coupling appears questionable, and an additional gauge-like
term is required.
Now write the ﬂuctuation according to δ= δx µ( δ/δ x µ) so
Eq. 8 becomes a functional diﬀerential equation. It is evident that we
are not able to write this functional derivativ e according to a cov ariant
derivativ e with a geodesic connection. A quantum spacetime ﬂuctua-
tion induces a motion of a test mass that deviates from the standard
geodesic equation of motion. The connection is then going to be tor-
sional, or equivalently it will con tain a teleparallel connection. This
requires a torsional construction of this functional derivativ e according
to connection terms with spinor content so con tinuity is preserv ed and
ψ ﬂuctuates in a homogeneous manner.
The Wheeler-DeWitt equation is a quantum form of the Hamil-
tonian constraint equation H= 0 in the ADM space plus time for-
malism of general relativity. The Wheeler-DeWitt equation is then
ˆ
H Ψ = 0, where Ψ is the w ave functional for a spacial surface and the
Hamiltonian operator is
ˆ
H= G ijkl ˆ π ij ˆ π kl − √ gR(3),(9)
and ˆ π ij =− iδ/δg ij are momentum operators conjugate to spa-
cial metric elements. Classically an additional momentum Hamiltonian
3
constraint H i=− 2 ∂ j π ij = 0 is required. ADM relativity treats
spacetime as foliated by spacial surfaces that are “pushed” forwar d by
lapse functions. W e consider the spacetime manifold M decomposed
into Σ(3) × R, where Σ(3)
t is a spacelike region and R is a real interv al
[3]. On M we have the metric g µν that is cov ariantly constan t with
respect to the operator ∇ µ. The spacetime M is foliated into spacelike
slices Σ(3)
t, where the parameter is a deﬁned along R and deﬁnes the
vector ﬁeld t µ= ∂ µ t. Thus for some Σ(3)
t we hav e the future directed
normal vector n µ, and the Gauss fundamental forms
h µν = g µν + n µ n ν, K µν =−(1/ 2) L n h µν .(10)
Given a projector operator P i µ its action on h µν is to deﬁne h iν , and
so projects h µν from M to Σ(3)
t according to P i µ P j ν h µν = h ij. This
then deﬁnes the Gauss fundamental forms on Σ(3)
t. The lapse and shift
functions for the foliation are then N=− t µ n µ and N i= h i µ t µ with
t µ= N n µ+ N µ.
The connection term for the ﬂuctuation induced functional
derivativ e should then contain spinor v ariables in addition to the spa-
tial momentum π ij. This invites the ansatz that ﬂuctuations requires
a connection term δ → δ+ Ω of the form
Ω=Γ ij π ij − i √ g[ γ µ, γ ν] ∇ µ ψ ν,(11)
such that ψ j is a Majorana spinor variable, ∇ µ is a cov ariant deriv ative,
and
Γ ij = 1
2  γ i ψ j+ γ j ψ i .(12)
This is then a gauge term associated with a functional derivative of the
Dirac matrix for δγ µ → δ γ µ+ Ω γ µ and δJ µ= 0.
This particular choice for the connection is motiv ated by the
fact that it constructs a spinor version of the Hamiltonian constraint
equation by anticomm utation
{ Ω( x), Ω( x 0)}= δ( x− x 0) γ µ ˆ
H spin
µ,(13)
where for µ= 0 this is the Hamiltonian operator and µ > 0 gives
the Hamiltonian momentum constraint operator. The ordinary Hamil-
tonian operators are modiﬁed by ˆ
H spin
µ= ψ j ˆ
H µ ψ j. These operators
vanish when they act upon the wa ve functional of the universe Ψ. F or
| g ij( x) i a state vector for the metric the ov erlap of two nearb y metric
states is h g ij( x)| g kl( x 0) i= δ ik δ j l + h g 0
ij| γ µ ˆ
H spin
µ| g 0
jl i.(14a)
4
This is analogous to the variation x+ δx = x+ ˙ xδt with the
variation in action δS = pδx − H δt. So for x and x 0 close the overlap
of state vectors gives h g( x)| g( x 0) i= 1 + h g( x)| γ µ H spin
µ| g( x 0) i. Then
from completeness sums this will construct a general path integral for
the transition between any widely separated metric conﬁgurations,
h g ij| g 0
ij i= Z D[ g ij ] e iS/~.(14b)
The ﬂuctuation operator Ω deﬁnes a Hamiltonian that acts upon the
cosmological wav e function as H µ Ψ = 0. That it is derived b y equation
13 illustrates that Ω is a supersymmetric generator, and further the
Hamiltonian it deﬁnes annules the cosmological wa ve function, which
is probably a state function of a total “nothingness,”or the v acuum.
At this stage a spinorial Hamiltonian is derived and
ˆ
H= R dx ˆ
H 0= h ˆ
H i+ δ ˆ
H, where the expected value is zero.
The ﬂuctuation satisﬁes ˆ
H Ψ = δ ˆ
H Ψ = 0. The ﬂuctuation of the
metric is shown below to hav e a topological content. To illustrate this
we return to a nonspinor framework for torsion. The topological con-
tent is then identiﬁed with i √ g[ γ µ, γ ν] ∇ µ ψ ν in equation 11, with a
cohomology that is identiﬁed with the topology of the Hopf ﬁbration.
A torsional connection is one where there is exists an accelera-
tion that deviates the motion of a particle from a geodesic. Accelera-
tions in spacetime are a= d u/dτ, with u 2=− 1, and so a
· u= 0.
Assume that an observer in a rest frame observes this accelerated sys-
tem so at that instant u= n. Then the accelerated frame can be seen
according to the cov ariant constancy of the metric h µν ,
Dh µν
dτ = 0 = Dn µ
dτ n ν,(15)
where the second fundamental form may be expressed with the Lie
derivativ e as
L h µν = n µ; ν+ n ν; µ+ n µ a ν+ n ν a µ.(16)
The acceleration is then a µ= n ν ∇ ν n µ, with ∇ ν denoting the cov ariant
derivativ e. The cov ariant deriv ative of the normal is
n µ; ν= 1
2 n( µ; ν)+ 1
2 n[ µ; ν]=− K µν − n µ a ν+ 1
2 n[ µ; ν].(17)
n[ µ; ν] is the antisymmetric ∇[ µ ψ µ] term in Eq. 11. For an accelerated
particle the normal n µ pertains to a classical spacial manifold, with
t µ= ∂ µ t and n[ µ; ν]= 0 so the ﬂuctuation vanishes classically.
5
Let the normal n µ pertains to a manifold Σ(3) within a foliation
of spacial manifolds that is one “path” within a quantum superposi-
tion of foliations and spacial manifolds. We consider this foliation as
deﬁned by a path integral that deﬁnes the transition from g ij to g 0
ij
This foliation in the spacial metric indicates the existence of quantum
ﬂuctuations in the spacial manifold that have their classical analogues
in variations. The variation in the action is then deﬁned betw een the
volumes Σ(3) and Σ 0(3). This variation is a bubble in spacetime δ n
· Σ(3),
where Σ(3) is a vector dual to the volume form for Σ(3). The standard
action
S= Z d 4 x(− g)− 1/ 2 R= Z d 4 x(− g)− 1/ 2 ( T rK ) 2− T r( K 2) + R(3) 
(18)
can be seen to be derived from
S= Z d 4 x(− g)− 1/ 2  n µ[; ν n ν; µ]+ R(3) ,(19)
where n µ[; ν n ν; µ] is the kinetic energy component of the Lagrangian. We
then have that the v ariation in the action results in
g ρν n σν ρ − n ν; νσ + 1
2 R(3); σ= 0,(20)
and
K µν; ρ− g µν K σ σ; ρ+ ( n µ a ν); ρ− 1
2 n[ µ; ν]; ρ= 0.(21)
The antisymmetric term n[ µ; ν]= ∇[ µ ψ ν] are torsional metric
ﬂuctuations. Consider a ﬂuctuation in the scalar t= t 0+ δ t, where
δt may be complex valued in general. The time vector t µ= t 0 µ+ δt µ,
where δt µ is a ﬂuctuation in the vector ﬁeld, is physically motiv ated by
above discussions of quantum ﬂuctuations. As t µ= N n µ+ N µ then
δn µ= 1
N δt µ, and so δ n µ= n µ; ν δx ν. It is evident that dt = t µ dx µ,
but with ﬂuctuations t µ dx µ= ( t 0 µ+ δt µ) dx µ. Since the ﬂuctuation
δt µ is not determined by K i j it is not the result of the application of
a diﬀerential operator on t. By the deﬁnition of n µ the same applies.
There is a cocyle associated with b oth t µ and n µ. We then consider this
ﬂuctuation as a loop that takes t 0 to t= t 0+ δt and back, as parame-
terized according to an additional variable suc h as a scalar ﬁeld. A lo op
integral H dt is by Stok es' law R t µ; ν dx µ ∧ dx ν. This then evaluates the
antisymmetric tensor n[ µ; ν]= ∇[ µ ψ ν] on a tw o-chain. Since quantum
ﬂuctuations vanish under expectations h δt i= 0, exp ectations of this
antisymmetric term in turn v anishes. However, quadratic terms in the
ﬂuctuation and this antisymmetric tensor are delta function correlated
and reﬂect Markovian statistics, so h( δt) 2 i 6= 0. t µ is dual to Σ 3 and so
6
H dt is deﬁned by H 3( M, R) = Z. This result is seen b elow as having
a connection to the Hopf ﬁbration and Bott periodicity. These ﬂuctua-
tions will then have a holographic in terpretation inherited through the
ﬁbration.
OPOLOGY AND THE HOPF FIBRA TION
In the above analysis ﬂuctuations hav e a cohomology that suggests
the holographic principle. This is related to the antisymmetric term
i √ g[ γ µ, γ ν] ∇[ µ ψ ν] with a U(1) content. The theory for quater-
nionic quantum gravit y is S L(2, Q) and the U(1) ﬁbration deﬁnes
a P SL(2, Q) pro jective space. This construction is parallel to the
structure for the nonrelativistic spin 1/ 2 theory above.
The nonrelativistic spin 1/ 2 theory and ﬂuctuations (Eq. 1) is
deﬁned by the Hopf ﬁbration
S 1  → S 3 → S 2,(22)
and this easily deﬁnes the holographic ﬂuctuations. The two sphere is
the energy surface and the three sphere is the the phase space. The La-
grangian is a constraint that deﬁnes this ﬁbration. In general relativity
the U(1) ﬁber corresponds to ﬁelds on the event horizon that deﬁne a
Hilbert space H e[4]. The ﬁelds in the volume remov ed from the event
horizon obey S O(3, 1) × Z 2' S L(2, C) or S U(2) × S U(1, 1), and
these deﬁne the Hilbert space H v. The S U (2) valued ﬁelds are reduced
to U(1) valued ﬁelds on an ev ent horizon. The total Hilbert space for
quantum gravit y would then be H v ⊗ H e. The S U(2)/Z 2' SO(3)
valued ﬁelds are constrained to exist on a t wo sphere with a bundle
connection deﬁned by the Hopf ﬁbration. This is a basic spin system.
As demonstrated above spin systems generically hav e a similar struc-
ture to general relativity, and the holographic principle obtains from
quantum mechanics with no references to spacetime ph ysics.
The spinorial theory of spacetime ﬂuctuation has the same basic
structure, but where the ﬂuctuations are written according to connec-
tion terms. The spinorial ﬂuctuations of spacetime is also an example
of the Hopf ﬁbration [6]
S 3  → S 7 → S 4.(23)
The holographic principle is inherited by quaternions through the Hopf
ﬁbration by
S 1  → S 3 → S 2
↓
S 3  → S 7 → S 4.(24)
7
The quaternionic projective map will by the Hopf construction inherit
holographic ﬂuctuations that have small but measurable eﬀects on a
large scale.
The ﬂuctuation in the time vector further is an indication of a
fundamental property of the Hopf ﬁbration, the Bott periodicity. R.
Bott computed the the homotopy groups of the topological groups O( n)
for n → ∞. This resulted in a p eriodicity π n+8( O( ∞)) = π n( O( ∞))
with speciﬁc values [7]:
π 0( O( ∞)) = Z 2, π 1( O( ∞)) = Z 2,
π 2( O( ∞)) = 0, π 3( O( ∞)) = Z,
π 4( O( ∞)) = 0, π 5( O( ∞)) = 0,
π 6( O( ∞)) = 0, π 7( O( ∞)) = Z.
(25)
The division algebras on the reals, complexes, quaternions, and octo-
nions are formed from vector spaces with dimensions 1, 2, 4, 8 and
Cayley num bers by [8]
R → R, R 2 → C, R 4 → H, R 8 → O,(26)
where π 3( O( ∞)) = Z indicates the quaternions [8]. The map
S 3 → O( ∞) deﬁnes the orthogonal transformations of the divi-
sion algebra for the quaternions. The homotopy group then deter-
mines the topology in that dimension. The cohomological nature of
the time vector is given b y H 3( M, R) ∼ π 3( M)/commutators with
π 3( M) → π 3( O( ∞)), and quaternionic nature of spacetime ﬂuctua-
tions are given by the Hopf ﬁbration.
The above model of quantum gravit y is quaterionic, and shares
problems inherent with quantum gra vity models that have been ad-
vanced. Essentially this type of model in a strong coupling limit ex-
hibits diﬃculties with divergences. This has b een the case with string
theories at the Hagedorn temperature as well. However, the abov e con-
struction indicates that this theory describes the Bott perio dicity, for
quantum metric ﬂuctuations are purely topological. That this type of
theory has topological information similar to that expected by Bott pe-
riodicity suggests that this is only an approximate theory that emerges
from a lower lev el in the Hopf ﬁbration with octonions. In such an
approach there is nonassociativity between ﬁeld operators, and there
is a new level in the uncertaint y in physics. Within this extended un-
certainty the div ergences that obtain in current theories are absorbed.
This would hav e parallels with the how quantum uncertain ty absorbed
the inﬁnities in classical mechanical attempts to understand atomic
physics.
8
IS QUANTUM GRA VITY OCTONIONIC?
The octonions O are a nonassociative and noncommutative set of ba-
sis elements of a normed division algebra. Any octonion may then be
written as o= P 8
i=1 o i e i. The basis elements e i, i = 1, ... 8 are
then various square roots of − 1 with e 2
i=− 1. The anticomm u-
tivity of octonions e i e j=− e j e i leads to the general product rule
e i e j= υ ijk e k− δ ij , so that a triplet pro duct may be diﬀerently
associated,
( e i e j) e k= g ik e j− g j k e i− δ ij e k,
e i( e j e k) = g ik e j− g ij e k− δ jk e i,
(27)
where υ ijk are to b e determined, and g ij is the metric in seven dimen-
sions determined by υ ijm υ k lm = ( g ik g jl − g il g jk ). This gives the
result
( e i e j) e k− e i( e j e k)=( g ij − δ ij) e k−( g jk − δ j k) e i.(28)
This multiplication rule produces the F ano plane. This results in the
triality associative product or bracket [ a, b, c]=( ab) c− a( bc)
Any octonion o may be written as the linear combination
o= o 0 1+
7
X
i=1
o i e i.(29)
Octonion conjugation may be deﬁned according to ab = b ¯ a, and
deﬁnes the inner product on this basis mapped from R 8 as
h a, b i= X
i
a i b j= 1
2( ab + ba) = 1
2( b ¯ a+ ¯ ab) (30)
Octonions are a pairing of quaternions. The elements of O are then
formed by Q ⊕ p Q and deﬁned 16 elements. These elements are not
matrices, since matrices are associative. This will lead to two copies
of Q where the nontrivial elements of eac h are paired up with the unit
matrix γ 4= 1 4 × 4. The octonions have 16 elements, these are pairs
of identical matrices, and there are 8 independent matrices. With one
of these matrices being the unit matrix, there are then seven of these
elements that are the “square root”of the negative unit matrix.
An octonionic quantum gravity w ould possess the o ctonionic
projective map on S L(2, O) and will be deﬁned by the Hopf ﬁbration
S 7  → S 15 → S 8.(31)
9
The holographic ﬂuctuations will similarly obtain in the octonionic do-
main as they do in the quaternionic domain. This mean that the initial
discussion on how quantum theory and gra vitation are similar by their
results on length ﬂuctuations is fully realized when quaternionic quan-
tum theory and spinorial gravitation are “democratically” em bedded
into a single system.
The Cayley num bers 1, 2, 4, 8 deﬁne the sets R, C, Q, O
as division algebras where for xy = 0 then either x= 0 or
y= 0. The reals are w ell ordered, commutative, and associa-
tive. C loses the well ordered property, Q loses commutativity, and
O loses associativity. The o ctonions are a nonassociative set of ba-
sis elements { 1, e i}, i = 1, ... , 7 deﬁned on the F ano plane.
F or a choice of multiplication table, elemen ts with the indicial triples
124, 346, 615, 523, 371, 574, 672, are are the nonzero octonion cyclic
elements. In general, octonions ob ey the nonassociative rule
( e i e j) e k− e i( e j e k) = υ ijkl e l.(32)
The associator is evaluated as ( e i e j) e k=− e i( e j e k) for associative
triplets of basis elements e i. Here υ ij kl is a structure constant for the
multiplication of octonions. Hence there is a context sensitivity asso-
ciated with multiplication that depends upon whether the ( ) is on the
left or the right. This structure is demonstrated to give rise to right
and left eigenvectors for the elemen ts e 4, e 7, which are SL(2, Q) eigen-
operators. A Galois co de emerges from the octonions from this that has
deep algebraic content for graphic and com binatoric representations [9].
The discussion on ADM relativity focused on the torsional as-
pects of quantum ﬂuctuations. The nonassociativity of octonions is a
measure of the torsional nature of in the geometry of the Hopf ﬁbration.
The seven associative subgroups identiﬁed below indicate quaternions
that have zero nonassociative torsion, but associators across elements
of these triplets exhibit torsion where geodesic description according
to commutators fails. The Hopf ﬁbration in fact indicates maps from
S 0, S 1, S 3 and S 7 resp ectively to S 1, S 2, S 4, and S 8 deﬁne holonomies
of a line bundle and are a S 1 with a U(1) Lie algebra. There are maps
R P 1 → S 1, C P 1 → S 2, Q P 1 → S 4, O P 1 → S 8(33)
for which there is an inﬁnite set of geodesics on each S n, and restricts
this conditions only for n= 1, 2, 4, 8 and not for n > 8.
CONCLUDING REMARK
F rom the physical introduction of quantum ﬂuctuations of the met-
ric as torsional, the torsional nature of octonions imp oses a further
uncertainty on these observ ables. This additional torsion to quantum
10
gravity, as a pair of quaternions, would mean that in some represen-
tation one quaternion pertains to the quantum theory of Dirac ﬁelds
and the other to quaternionic quantum gravit y. Quantum gravity then
has an octonionic structure. This appears to b e the most natural ap-
proach to the uniﬁcation of general relativity a nd quantum mechanics.
The ﬁelds of nature will then be described by commutators expressed
according to associators. These ﬁelds on the complete Hopf ﬁbration
will run from the spin zero scalar ﬁeld up to the spin-2 graviton. Given
any four octonions a, b, c, d, the commutator [ ab, cd] will then in gen-
eral be expressed according to nontrivial associators [10]. This means
that ﬁelds ψ( a) are over an octonion basis, and their spin conten t will
deﬁne bi-octonion, quater-octonion, and o cto-octonion structures with
exceptional algebraic representations.
This nonassociative theory of spinorial quantum gra vity may be
probably reasonable for metric ﬂuctuations at least an order of magni-
tude larger than the Planck length. This is near the Hagedorn temper-
ature in string theory, where strong coupling results in a divergence.
Quaternionic quantum mechanics and gra vitation embedded as equals
into the octonions may result in a fully acceptable theory of quant um
gravity that carries holographic c haracteristics up to or very near the
Planck length.
REFERENCES
G. 't Ho oft, Class. Quant. Grav. 16, (1999) 395-405.
Y. J. Ng, “Spacetime foam,” Int J. Mod. Phys. 11 1585 (2002).
C. Miser, K. Thorne, and J. Wheeler, Gravitation, Chap. 21 (F ree-
man, San F rancisco, 1973).
A. Ashtekar, J. Baez, and K. Krasno v, Adv. The or. Math. Phys.
4 1-94 (2004).
H. D. Zeh, “One the interpretation of measurement in quantum
theory,” F ound. Phys. 1, 69 (1970); “What is achieved by deco-
herence,” http://www.arxiv.org/PS cache/quan t-ph/pdf/9610/
9610014.pdf.
H. Hopf, “Ub er die Abbildungen der dreidimendionalen Sph¨ are
auf die Kugelﬂ¨ ache,” Math. Ann. 104 (5), (1931) 637-665.
J. Baez, “The o ctonions,”http://www.arxiv.org/pdf/math.RA/
I. Porteous, “Cliﬀord algebras and the classical groups”, Cam-
bridge Studies in Advanc ed Mathematics 50, Cam bridge Univer-
sity Press: Cambridge (1995).
G. Dixon, Nouvo. Cim. B 105, 349 (1990).
V. Dzh unushaliev, “Nonperturbative operator quantization of
strongly nonlinear ﬁelds,” F ound. Phys. Lett. 16, 1 57-70 (2003).
11
Citations (1)
References (13)
... where O is the normed, noncommutative and nonassociative division algebra of octonions [4], [6] . Let a ∈ S 4 , b ∈ S 8 , with U a , U b the corresponding open neighborhoods....
A uniformly convergent Series for ζ ( s ) \zeta(s) and closed Formulas, that include Catalan Numbers
Article
Full-text available
Aug 2010
 Robert Betts
There exists an infinite series of ratios by which one can derive the Riemann zeta function ζ ( s ) \zeta(s) from Catalan numbers and central binomial coefficients which appear in the terms of the series. While admittedly the derivation is not deep it does indicate some combinatorial aspect to the Riemann zeta function. But we actually do find also four additional new closed formulas, which include a formula by which one can compute ζ ( s ) \zeta(s) for a countably infinite number of discrete positive values for s where the formula contains Catalan numbers not in infinite series. The Riemann zeta function has applications in physics, such as in computations related to the Casimir effect. Our result indicates a link between the Riemann zeta function, combinatorics, Catalan numbers, the central binomial coefficient and the content of a hypersphere, under certain conditions. Comment: 27 pages. Parts of the original submission have been edited out for inclusion in a future submission on this topic. In Subsection 3.1 and in Subsection 4.2 the terms in the series expansion for ζ ( s ) \zeta(s) should be understood to be 1 / k s 1/k^{s} , k = 1 , 2 , … k = 1, 2, \ldots
View
Show abstract
SPACETIME FOAM
Article
Full-text available
Jan 2002
INT J MOD PHYS D
 Jack Ng
Spacetime is composed of a fluctuating arrangement of bubbles or loops called spacetime foam, or quantum foam. We use the holographic principle to deduce its structure, and show that the result is consistent with gedanken experiments involving spacetime measurements. We propose to use laser-based atom interferometry techniques to look for spacetime fluctuations. Our analysis makes it clear that the physics of quantum foam is inextricably linked to that of black holes. A negative experimental result, therefore, might have non-trivial ramifications for semiclassical gravity and black hole physics.
View
Show abstract
Trans-Planckian particles and the quantization of time
Article
Full-text available
Feb 1999
 Gerard t Hooft
Trans-Planckian particles are elementary particles accelerated such that their energies surpass the Planck value . There are several reasons to believe that trans-Planckian particles do not represent independent degrees of freedom in Hilbert space, but they are controlled by the cis-Planckian particles. A way to learn more about the mechanisms at work here, is to study black hole horizons, starting from the scattering matrix ansatz. By compactifying one of the three physical spatial dimensions, the scattering matrix ansatz can be exploited more efficiently than before. The algebra of operators on a black hole horizon allows for a few distinct representations. It is found that this horizon can be seen as being built up from string bits with unit length, each of which are described by a representation of the Lorentz group. We then demonstrate how the holographic principle works for this case, by constructing the operators corresponding to a field . The parameter t turns out to be quantized in units of , where R is the period of the compactified dimension.
View
Show abstract
Derivation of the standard model
Article
Full-text available
Mar 1990
 Geoffrey Dixon
The structure of theU(1)×SU(2) electroweak theory is constructable in a natural way on the Pauli algebra,P.P is isomorphic to the tensor productC⊗Q of the complexes and quaternions, two of the three division algebras, the octonionsO the third. Following the pattern established onP≃C⊗Q, an extended model is built uponC⊗Q⊗O. The gauge symmetry derived for this algebra isU(1)×SU(2)×SU(3), and in all other respects the model features that result exactly mirror the salient features of the standard model, including particle family replication. La structtura della teoria elettrodeboleU(1)×SU(2) si può formulare in un modo naturale sull'algebra di Pauli,P.P è isomorfico rispetto al prodotto tensorialeC⊗Q dei complessi e dei quaternioni, che sono due delle tre algebre di divisione, gli ottonioniO sono la terza. Seguendo lo schema stabilito suP≃C⊗Q, si costruisce un modello esteso suC⊗Q⊗O. La simmetria di gauge dedotta per questa algebra èU(1)×SU(2)♪SU(3) e in tutti gli altri aspetti le caratteristiche del modello che risultano rispecchiano esattamente le caratteristiche salienti del modello standard, compresa la replica della famiglia di particelle. СтруктураU(1)×SU(2) электрослабой теории может быть сконструирована естественным образом на алгебре Паули,P· P является изоморфным тензорному произведениюC⊗Q комплексов и кватернионов, две из трех-частичных алгебр, октонионыO-третья. Следуя образцу, установленному наP≃C⊗Q, строится обобщенная модель наC⊗Q⊗O. Калибровочная симметрия, выведенная для этой алгебры, представляетU(1)×SU(2)×SU(3). Во всех других аспектах полученная модель показывает, что результат точно отражает характерные особенности стандартной модели, включая копирование семейства частиц.
View
Show abstract
The Octonions
Article
Full-text available
May 2001
 John Baez
The octonions are the largest of the four normed division algebras. While somewhat neglected due to their nonassociativity, they stand at the crossroads of many interesting fields of mathematics. Here we describe them and their relation to Clifford algebras and spinors, Bott periodicity, projective and Lorentzian geometry, Jordan algebras, and the exceptional Lie groups. We also touch upon their applications in quantum logic, special relativity and supersymmetry.
View
Show abstract
Nonperturbative Operator Quantization of Strongly Nonlinear Fields
Article
Full-text available
Apr 2001
 Vladimir Dzhunushaliev
At present an algebra of strongly interacting fields is unknown. In this paper it is assumed that the operators of a strongly nonlinear field can form a non-associative algebra. It is shown that such an algebra can be described as an algebra of some pairs. The comparison of presented techniques with the Green's functions method in superconductivity theory is made. A possible application to the QCD and High-Tc superconductivity theory is discussed.
View
Show abstract
Quantum Geometry of Isolated Horizons and Black Hole Entropy
Article
Full-text available
Jun 2000
 Abhay Ashtekar
 John Baez
 Kirill Krasnov
Using the earlier developed classical Hamiltonian framework as the point of departure, we carry out a non-perturbative quantization of the sector of general relativity, coupled to matter, admitting non-rotating isolated horizons as inner boundaries. The emphasis is on the quantum geometry of the horizon. Polymer excitations of the bulk quantum geometry pierce the horizon endowing it with area. The intrinsic geometry of the horizon is then described by the quantum Chern-Simons theory of a U(1) connection on a punctured 2-sphere, the horizon. Subtle mathematical features of the quantum Chern-Simons theory turn out to be important for the existence of a coherent quantum theory of the horizon geometry. Heuristically, the intrinsic geometry is flat everywhere except at the punctures. The distributional curvature of the U(1) connection at the punctures gives rise to quantized deficit angles which account for the overall curvature. For macroscopic black holes, the logarithm of the number of these horizon microstates is proportional to the area, irrespective of the values of (non-gravitational) charges. Thus, the black hole entropy can be accounted for entirely by the quantum states of the horizon geometry. Our analysis is applicable to all non-rotating black holes, including the astrophysically interesting ones which are very far from extremality. Furthermore, cosmological horizons (to which statistical mechanical considerations are known to apply) are naturally incorporated. An effort has been made to make the paper self-contained by including short reviews of the background material.
View
Show abstract
Clifford algebras, matrix algebras and classical groups
Article
Jan 1985
G.P. Wene
View
Cli ord Algebras and the Classical Groups
Article
Oct 1995
Ian R. Porteous
Linear spaces 2. Real and complex algebras 3. Exact sequences 4. Real quadratic spaces 5. The classification of quadratic spaces 6. Anti-involutions of R(n) 7. Anti-involutions of C(n) 8. Quarternions 9. Quarternionic linear spaces 10. Anti-involutions of H(n) 11. Tensor products of algebras 12. Anti-involutions of 2K(n) 13. The classical groups 14. Quadric Grassmannians 15. Clifford algebras 16. Spin groups 17. Conjugation 18. 2x2 Clifford matrices 19. The Cayley algebra 20. Topological spaces 21. Manifolds 22. Lie groups 23. Conformal groups 24. Triality.
View
Show abstract
On the Interpretation of Measurement in Quantum Theory
Article
Mar 1970
H. D. Zeh
It is demonstrated that neither the arguments leading to inconsistencies in the description of quantum-mechanical measurement nor those explaining the process of measurement by means of thermodynamical statistics are valid. Instead, it is argued that the probability interpretation is compatible with an objective interpretation of the wave function.
View
Show abstract
Ǖber die Abbildungen der dreidimensionalen Sphäre auf die KugelOäche
Article
Dec 1931
Heinz Hopf
Unter einer „Abbildung“ eines Komplexes (oder auch einer beliebigen Menge) A „auf“ einen Komplex B verstehen wir stets eine eindeutige und stetige, nicht notwendig eineindeutige, Abbildung von A, bei der die Menge der Bildpunkte zu B gehört. Zwei Abbildungen von A auf B nennen wir zu derselben „Klasse“ gehörig, wenn man sie stetig ineinander überführen kann, d.h. wenn es eine sie enthaltende stetige Schar von Abbildungen von A auf B gibt, und wir bezeichnen eine Abbildung als „topologisch wesentlich“, wenn bei jeder Abbildung der durch sie bestimmten Klasse die Bildmenge aus allen Punkten von B besteht, d. h. wenn es unmöglich ist, durch stetige Abänderung der Abbildung einen Punkt von B von der Bedeckung durch die Bildmenge zu befreien.
View
Show abstract
Show more
Recommended publications
Discover more about: Quantum Mechanics
Article
A Source of the Inertial and Gravitational Properties of the Matter Objects
January 2012
· Advanced Studies in Theoretical Physics
Vladimír Skalský
From the analysis of the relativistic and quantum-mechanical properties of particles it results that the source of inertial and gravitational properties of matter objects are the quantum fluctuations of particles in a local space-time (field).
Read more
Article
Full-text available
BMS & Squeezed States
January 2016
 Lawrence Crowell
A highly correlated set of quantum gravitation states, which admittedly we do not fully understand, might give rise to a worm hole with a negative vacuum energy. This might only exist for a small number of quantum states and not persist as a quantization on the large. If the wormhole becomes unstable then the coherent sets of states will be partitioned into entangled states. This unstable ... [Show full abstract] collapse of the wormhole likely results in a pair of entangled black holes. It is most plausible that if traversable wormholes exists that they are quantum mechanical or that black holes can be a quantum superposition with a wormhole state or quantum fluctuate into a wormhole.
View full-text
Article
Full-text available
Tsirelson Bound, Entanglement & Gravity
November 2016
 Lawrence Crowell
This paper illustrates an isomorphism between the Tsirelson bound of quantum mechanics and the spacetime metric. This illustrates how spacetime could be seen as quantum mechanics in disguise. The extension of this with gauge fields and gravitation illustrates further how spacetime can be seen as the result of quantum mechanics or quantum fields.
View full-text
Article
Full-text available
HOLOGRAPHIC BOUNDS ON HILBERT SPACE
October 2003
· International Journal of Modern Physics D
 Lawrence Crowell
The size of Hilbert space for quantum gravity is examined in the light of the holographic principle. The fluctuation of lengths results in a bound on the amount of quantum information that may exist in a volume of space, and prevent divergences at the Planck energy.
View full-text
Interested in research on Quantum Mechanics?
Join ResearchGate to discover and stay up-to-date with the latest research from leading experts in Quantum Mechanics and many other scientific topics.
Join for free
ResearchGate iOS App Get it from the App Store now.
Install
Keep up with your stats and more
Access scientific knowledge from anywhere
or
Discover by subject area
Recruit researchers
Join for free
Login Email Tip: Most researchers use their institutional email address as their ResearchGate login Password Forgot password? [x] yes Keep me logged in Log in or Continue with Google Welcome back! Please log in. Email · Hint Tip: Most researchers use their institutional email address as their ResearchGate login Password Forgot password? [x] yes Keep me logged in Log in or Continue with Google No account? Sign up
Company
About us
News
Careers
Support
Help Center
Business solutions
Advertising
Recruiting
© 2008-2026 ResearchGate GmbH. All rights reserved.
Terms
Privacy
Copyright
Imprint
Consent preferences 