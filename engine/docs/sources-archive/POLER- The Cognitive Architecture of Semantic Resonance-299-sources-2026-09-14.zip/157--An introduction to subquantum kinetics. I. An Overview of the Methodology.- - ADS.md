> Source: https://ui.adsabs.harvard.edu/abs/1985IJGS...11..279L/abstract

"An introduction to subquantum kinetics. I. An Overview of the Methodology." - Astrophysics Data System
Skip to main content
Now on article abstract page
Toggle navigation
[
ads
](#) 
SciX Transition Resources
SciX is the evolution of ADS, bringing its powerful capabilities into new domains. SciX will become the sole interface in late 2026.
Visit SciX
Learn about SciX
Feedback
Submit Updates
General Feedback
 ORCID
Sign in to ORCID to claim papers in the ADS.
About
Transition to SciX
About ADS
What's New
ADS Blog
ADS Help Pages
ADS Legacy Services
Careers@ADS
Sign Up
Log In
ADS is currently experiencing an issue with missing recent ArXiv preprints. Please be assured the records are in the system and we are actively working on a solution to propagate them to the search engine.
Close
Search Bar to Enter New Query
quick field: Author First Author Abstract Year Fulltext Select a field or operator
abstract
abstract only
acknowledgements
affiliation
arXiv category
author count
author
bibcode
bibliographic group
bib abbrev, e.g. ApJ
body of article
data archive
collection
citation count
doctype
doi
entdate
first author
fulltext
identifier
inst
keyword
object
orcid
page
property
publication full name
date published
title
uat
volume
year
citations()
pos()
references()
reviews()
similar()
topn()
trending()
useful()
single wildcard: ?
wildcard: *
exact match: =
All Search Terms
Your search returned 0 results
Your search returned 0 results
Show Menu Full Text Sources
view
Abstract
Citations (1)
References (5)
Co-Reads
Similar Papers
Volume Content
Graphics
Metrics
Export Citation
"An introduction to subquantum kinetics. I. An Overview of the Methodology."
Show affiliations Loading affiliations affiliations loading
Laviolette, Paul A.
Abstract
A new methodology is described whereby microphysical phenomena are modeled as emergent manifestations of nonequilibrium, reaction-diffusion processes assumed to take place at the subquantum level. Space is assumed to be filled with a bath of unobservable subquantum entities called subphysical units which are present in an assortment of types. These units diffuse and continually react with one another according to certain well-defined reaction processes which may be specified in the form of a set of kinetic equations. Thus space is modeled as a vast reaction-diffusion medium. It is noted that in certain types of reaction-diffusion systems, the concentrations of the subphysical unit components may become inhomogeneously distributed both spatially and spatiotemporally. It is proposed that such concentration patterns are of a kind that could serve as useful analogs of particles, fields, and electromagnetic waves.
Publication:
International Journal of General Systems, Vol. 11, p. 279-293
Pub Date:
November 1985
Bibcode:
1985IJGS...11..279L Copied!
Keywords:
open system;
reaction-diffusion system;
subquantum kinetics;
fields;
subatomic particles;
space;
dissipative structure;
chemical waves;
nonequilibrium thermodynamics
Feedback/Corrections?
No Sources Found
© The SAO Astrophysics Data System
adshelp[at]cfa.harvard.edu
The ADS is operated by the Smithsonian Astrophysical Observatory under NASA Cooperative Agreement 80NSSC25M7105
*The material contained in this document is based upon work supported by a National Aeronautics and Space Administration (NASA) grant or cooperative agreement. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author and do not necessarily reflect the views of NASA.
Resources
About ADS
ADS Help
System Status
What's New
Careers@ADS
Web Accessibility Policy
Social
@adsabs
ADS Blog
Project
Switch to basic HTML
Privacy Policy
Terms of Use
Smithsonian Astrophysical Observatory
Smithsonian Institution
NASA
🌓
View page in SciX
×
Back How may we help you?
[
Missing/Incorrect Record
Submit a missing record or correct an existing record.](/feedback/correctabstract)
[
Missing References
Submit missing references to an existing ADS record.](/feedback/missingreferences)
[
Associated Articles
Submit associated articles to an existing record (e.g. arXiv / published paper).](/feedback/associatedarticles)
[
General Feedback
Send your comments and suggestions for improvements.](javascript:void(0);)
Name
Email
Feedback
Submit
You can also reach us at adshelp [at] cfa.harvard.edu
This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.
Close without submitting
Alert