> Source: https://docs.rs/nalgebra-sparse

nalgebra_sparse - Rust
Docs.rs
nalgebra-sparse-0.11.0
nalgebra-sparse 0.11.0
Permalink
Docs.rs crate page
Apache-2.0
Links
Homepage
Documentation
Repository
crates.io
Source
Owners
sebcrozet
Dependencies
matrixcompare-core ^0.1.0 normal optional
nalgebra ^0.34 normal
num-traits ^0.2 normal
pest ^2 normal optional
pest_derive ^2 normal optional
proptest ^1.0 normal optional
serde ^1.0 normal optional
itertools ^0.13 dev
matrixcompare ^0.3.0 dev
nalgebra ^0.34 dev
serde_json ^1.0 dev
tempfile ^3.3 dev
Versions
100% of the crate is documented
Platform
aarch64-apple-darwin
aarch64-unknown-linux-gnu
i686-pc-windows-msvc
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
Crate nalgebra_sparse
Settings
Help
nalgebra_sparse 0.11.0
All Items
Sections
Goals
Highlighted current features
Current state
Usage
Supported matrix formats
Example: COO -> CSR -> matrix-vector product
Crate Items
Re-exports
Modules
Structs
Enums
Crates
nalgebra_sparse 
Crate nalgebra_sparse Copy item path
Source
Search
Settings
Help
Summary
Expand description
Sparse matrices and algorithms for nalgebra.
This crate extends nalgebra with sparse matrix formats and operations on sparse matrices.
§ Goals
The long-term goals for this crate are listed below.
Provide proven sparse matrix formats in an easy-to-use and idiomatic Rust API that naturally integrates with nalgebra .
Provide additional expert-level APIs for fine-grained control over operations.
Integrate well with external sparse matrix libraries.
Provide native Rust high-performance routines, including parallel matrix operations.
§ Highlighted current features
CSR, CSC and COO formats, and conversions between them.
Common arithmetic operations are implemented. See the ops module.
Sparsity patterns in CSR and CSC matrices are explicitly represented by the SparsityPattern type, which encodes the invariants of the associated index data structures.
Matrix market format support when the io feature is enabled.
proptest strategies for sparse matrices when the feature proptest-support is enabled.
matrixcompare support for effortless (approximate) comparison of matrices in test code (requires the compare feature).
§ Current state
The library is in an early, but usable state. The API has been designed to be extensible, but breaking changes will be necessary to implement several planned features. While it is backed by an extensive test suite, it has yet to be thoroughly battle-tested in real applications. Moreover, the focus so far has been on correctness and API design, with little focus on performance. Future improvements will include incremental performance enhancements.
Current limitations:
Limited or no availability of sparse system solvers.
Limited support for complex numbers. Currently only arithmetic operations that do not rely on particular properties of complex numbers, such as e.g. conjugation, are supported.
No integration with external libraries.
§ Usage
Add the following to your Cargo.toml file:
§ Supported matrix formats
What format is best to use depends on the application. The most common use case for sparse matrices in science is the solution of sparse linear systems. Here we can differentiate between two common cases:
Direct solvers. Typically, direct solvers take their input in CSR or CSC format.
Iterative solvers. Many iterative solvers require only matrix-vector products, for which the CSR or CSC formats are suitable.
The COO format is primarily intended for matrix construction. A common pattern is to use COO for construction, before converting to CSR or CSC for use in a direct solver or for computing matrix-vector products in an iterative solver. Some high-performance applications might also directly manipulate the CSR and/or CSC formats.
§ Example: COO -> CSR -> matrix-vector product
Re-exports §
pub extern crate [nalgebra](https://docs.rs/nalgebra/0.34.1/x86_64-unknown-linux-gnu/nalgebra/index.html) as na;
Re-exports [§](https://docs.rs/nalgebra-sparse#reexports-1)
pub use self::coo:: [CooMatrix](https://docs.rs/coo/struct.CooMatrix.html); pub use self::csc:: [CscMatrix](https://docs.rs/csc/struct.CscMatrix.html); pub use self::csr:: [CsrMatrix](https://docs.rs/csr/struct.CsrMatrix.html);
Modules [§](https://docs.rs/nalgebra-sparse#modules)
[convert](https://docs.rs/convert/index.html) Routines for converting between sparse matrix formats. [coo](https://docs.rs/coo/index.html) An implementation of the COO sparse matrix format. [csc](https://docs.rs/csc/index.html) An implementation of the CSC sparse matrix format. [csr](https://docs.rs/csr/index.html) An implementation of the CSR sparse matrix format. [factorization](https://docs.rs/factorization/index.html) Matrix factorization for sparse matrices. [io](https://docs.rs/io/index.html) Functionality for importing and exporting sparse matrices to and from files. [ops](https://docs.rs/ops/index.html) Sparse matrix arithmetic operations. [pattern](https://docs.rs/pattern/index.html) Sparsity patterns for CSR and CSC matrices. [proptest](https://docs.rs/proptest/index.html) Functionality for integrating nalgebra-sparsewithproptest .
Structs [§](https://docs.rs/nalgebra-sparse#structs)
[SparseFormatError](https://docs.rs/struct.SparseFormatError.html) Errors produced by functions that expect well-formed sparse format data.
Enums [§](https://docs.rs/nalgebra-sparse#enums)
[SparseEntry](https://docs.rs/enum.SparseEntry.html) An entry in a sparse matrix. [SparseEntryMut](https://docs.rs/enum.SparseEntryMut.html) A mutable entry in a sparse matrix. [SparseFormatErrorKind](https://docs.rs/enum.SparseFormatErrorKind.html) The type of format error described by a [SparseFormatError](https://docs.rs/struct.SparseFormatError.html) .