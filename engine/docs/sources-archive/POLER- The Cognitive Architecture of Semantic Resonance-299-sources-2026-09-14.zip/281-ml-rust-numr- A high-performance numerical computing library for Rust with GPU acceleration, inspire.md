> Source: https://github.com/ml-rust/numr

GitHub - ml-rust/numr: A high-performance numerical computing library for Rust with GPU acceleration, inspired by Numpy
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
ml-rust / numr Public
Notifications You must be signed in to change notification settings
Fork 0
Star 19
A high-performance numerical computing library for Rust with GPU acceleration, inspired by Numpy
crates.io/crates/numr
License
Apache-2.0 license
19 stars 0 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 1
Pull requests 0
Discussions
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Discussions
Actions
Projects
Security
Insights
ml-rust/numr
main
2 Branches 5 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
Apache-2.0 license
numr
Foundational numerical computing for Rust numr provides n-dimensional tensors, linear algebra, FFT, statistics, and automatic differentiation—with native GPU acceleration across CPU, CUDA, and WebGPU backends. numr is like Numpy in Rust but built with gradients, GPUs, and modern dtypes built-in from day one.
What numr Is
A foundation library - Mathematical building blocks for higher-level libraries and applications.
For SciPy-equivalent functionality (optimization, ODE, interpolation, signal), see solvr.
Why numr?
vs NumPy
vs Rust Ecosystem
Fragmented libraries that don't interoperate and lack GPU support. numr consolidates everything:
A Rust developer should never need to look elsewhere for numerical computing.
Architecture
numr is designed with a simple principle: same code, any backend.
Operations
numr implements a comprehensive set of tensor operations across CPU, CUDA, and WebGPU:
Core Arithmetic
UnaryOps: neg, abs, sqrt, exp, log, sin, cos, tan, sinh, cosh, tanh, floor, ceil, round, and more
BinaryOps: add, sub, mul, div, pow, maximum, minimum (all with NumPy-style broadcasting)
ScalarOps: tensor-scalar arithmetic
TypeConversionOps: cast (convert between dtypes)
UtilityOps: clamp, fill, arange, linspace, eye
Shape and Data Movement
ShapeOps: cat, stack, split, chunk, repeat, pad, roll
IndexingOps: gather, scatter, gather_nd, scatter_reduce, index_select, masked_select, masked_fill, embedding_lookup, bincount, argmax, argmin
SortingOps: sort, argsort, topk, unique, nonzero, searchsorted
Reductions
ReduceOps: sum, mean, max, min, prod (with precision variants)
CumulativeOps: cumsum, cumprod, logsumexp
Comparisons and Logical
CompareOps: eq, ne, lt, le, gt, ge
LogicalOps: logical_and, logical_or, logical_xor, logical_not
ConditionalOps: where (ternary conditional)
Activation & Normalization Functions
ActivationOps: relu, sigmoid, silu, gelu, leaky_relu, elu, softmax
NormalizationOps: rms_norm, layer_norm
ConvOps: conv1d, conv2d, depthwise_conv2d (with stride, padding, dilation, groups)
These are mathematical functions commonly used in ML, but numr itself is not an ML framework.
Linear Algebra
MatmulOps: matmul, matmul_bias (fused GEMM+bias)
LinalgOps: solve, lstsq, pinverse, inverse, det, trace, matrix_rank, diag, matrix_norm, kron, khatri_rao
ComplexOps: conj, real, imag, angle (for complex tensor support)
Statistics and Probability
StatisticalOps: var, std, skew, kurtosis, quantile, percentile, median, cov, corrcoef
RandomOps: rand, randn, randint, multinomial, bernoulli, poisson, binomial, beta, gamma, exponential, chi_squared, student_t, f_distribution
MultivariateRandomOps: multivariate_normal, wishart, dirichlet
QuasirandomOps: Sobol, Halton sequences
Distance Metrics
DistanceOps: euclidean, manhattan, cosine, hamming, jaccard, minkowski, chebyshev, correlation
Algorithm Modules
Linear Algebra ( numr::linalg ):
Decompositions: LU, QR, Cholesky, SVD, Schur, full eigendecomposition, generalized eigenvalues
Solvers: solve, lstsq, pinverse
Matrix functions: exp, log, sqrt, sign
Utilities: det, trace, rank, matrix norms
Fast Fourier Transform ( numr::fft ):
FFT/IFFT (1D, 2D, ND) - Stockham algorithm
Real FFT (RFFT/IRFFT)
Matrix Multiplication ( numr::matmul ):
Tiled GEMM with register blocking
Bias fusion support
Special Functions ( numr::special ):
Error functions: erf, erfc, erfinv
Gamma functions: gamma, lgamma, digamma
Beta functions: beta, betainc
Incomplete gamma: gammainc, gammaincc
Bessel functions: J₀, J₁, Y₀, Y₁, I₀, I₁, K₀, K₁
Elliptic integrals: ellipk, ellipe
Hypergeometric functions: hyp2f1, hyp1f1
Airy functions: airy_ai, airy_bi
Legendre functions: legendre_p, legendre_p_assoc, sph_harm
Fresnel integrals: fresnel_s, fresnel_c
Polynomial Operations ( numr::polynomial ):
polyroots, polyval, polyfromroots, polymul
Sparse Tensors ( numr::sparse , feature-gated):
Formats: CSR, CSC, COO
Operations: SpGEMM (sparse matrix multiplication), SpMV (sparse matrix-vector), DSMM (dense-sparse matrix)
Dtypes
numr supports a wide range of numeric types:
Every operation supports every compatible dtype. No hardcoded f32-only kernels.
Backends
All backends implement identical algorithms with native kernels—no cuBLAS, MKL, or vendor library dependencies.
SIMD Acceleration
The CPU backend automatically detects and uses the best available SIMD instruction set at runtime:
Vectorized operations include:
Element-wise: add, sub, mul, div, neg, abs, sqrt, exp, log, sin, cos, tanh, and more
Reductions: sum, max, min, prod with horizontal SIMD reductions
Activations: sigmoid, silu, gelu, leaky_relu, elu
Normalization: softmax, rms_norm, layer_norm, logsumexp
Matrix multiplication: tiled GEMM with FMA microkernels
Special functions: erf, erfc, bessel, gamma (with polynomial approximations)
Why Native Kernels?
numr uses native kernels (SIMD, PTX, WGSL) by default—not cuBLAS/MKL wrappers.
You're not locked out of vendor libraries—numr's kernel system is extensible. Use native kernels for portability and transparency, or swap in cuBLAS/MKL for maximum vendor-optimized performance. Other libraries don't give you this choice.
Quick Start
CPU Example
GPU Example (CUDA)
Backend-Generic Code
Linear Algebra
FFT
Statistics and Distributions
Installation
CPU-only (default)
With GPU Support
With Optional Features
Feature Flags
Building from Source
How numr Fits in the Stack
numr is the foundation that everything else builds on:
numr : solvr :: NumPy : SciPy
When numr's kernels improve, everything above improves automatically.
Kernels and Extensibility
numr provides default kernels for all operations. You can also:
Use default kernels: All operations work out of the box with optimized kernels:
CPU: SIMD-vectorized kernels (AVX-512/AVX2 on x86-64, NEON on ARM64)
CUDA: Native PTX kernels (compiled at build time, loaded on first use)
WebGPU: WGSL compute shaders for cross-platform GPU
Replace specific kernels: Swap in your own optimized kernels for performance-critical paths
Add new operations: Define new traits and implement kernels for all backends
For detailed guidance on writing custom kernels, adding new operations, and backend-specific optimization techniques, see docs/extending-numr.md.
License
Apache-2.0
About
A high-performance numerical computing library for Rust with GPU acceleration, inspired by Numpy
crates.io/crates/numr
Topics
science math hpc numpy computing
Resources
Readme
License
Apache-2.0 license
Uh oh!
There was an error while loading. Please reload this page.
Activity
Custom properties
Stars
19 stars
Watchers
1 watching
Forks
0 forks
Report repository
Releases
5 tags
Languages
Rust 86.9%
Cuda 11.8%
WGSL 1.3%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.