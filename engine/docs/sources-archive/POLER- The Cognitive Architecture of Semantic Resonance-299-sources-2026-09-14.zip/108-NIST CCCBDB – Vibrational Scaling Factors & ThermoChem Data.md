> Source: https://joaquinbarroso.com/2020/07/23/nist-cccbdb-vibrational-scaling-factors-thermochem-data/

NIST CCCBDB – Vibrational Scaling Factors & ThermoChem Data – Dr. Joaquin Barroso's Blog
Skip to content
Home
About me
Research Team
Group Photos
Research
Galleries
CCIQS – Joint Center for Research in Sustainable Chemistry
Cluj-Napoca, Romania
Dracula's Castle
Summer in Hungary
Leave a question!
Links
Donations (New!)
Search
Search for: Search 
Dr. Joaquin Barroso's Blog
Scientific log of a computational chemist – "Make like a molecule and React!"
Computational Chemistry, Internet, Spectroscopy, Theoretical Chemistry, Thermodynamics
NIST CCCBDB – Vibrational Scaling Factors & ThermoChem Data
Date: July 23, 2020 Author: joaquinbarroso 0 Comments
The Computational Chemistry Comparison and Benchmark DataBase (CCCBDB) from the National Institute of Standards and Technology (NIST) collects experimental and calculated thermochemistry—related values for 1968 common molecules, constituting a vast source of benchmarks for various kinds of calculations.
In particular, scaling factors for vibrational frequencies are very useful when calculating vibrational spectra. These scaling factors are arranged by levels of theory ranging from HF to MP2, DFT, and multireference methods. These scaling factors are obtained by least squares regression between experimental and calculated frequencies for a set of molecules at a given level of theory.
Aside from vibrational spectroscopy, a large number of structural and energetic properties can be found and estimated for small molecules. A quick formation enthalpy can be calculated from experimental data and then compared to the reported theoretical values at a large number of levels of theory. Moments of inertia, enthalpies, entropies, charges, frontier orbital gaps, and even some odd values or even calculations gone awry are pointed out for you to know if you're dealing with a particularly problematic system. The CCCB Database includes tutorials and input/output files for performing these kinds of calculations around thermochemistry, making it also a valuable learning resource.
Every computational chemist should be aware of this site, particularly when collaborating with experimentalists or when carrying calculations trying to replicate experimental data. The vastness of the site calls for a long dive to explore their possibilities and capabilities for more accurate calculations.
Rate this:
i
4 Votes
In case you wanna share this:
Share on Facebook (Opens in new window) Facebook
Email a link to a friend (Opens in new window) Email
Share on X (Opens in new window) X
Print (Opens in new window) Print
Share on Reddit (Opens in new window) Reddit
Share on LinkedIn (Opens in new window) LinkedIn
Share on Tumblr (Opens in new window) Tumblr
Share on Pinterest (Opens in new window) Pinterest
Like Loading...
Useful Thermochemistry from Gaussian Calculations August 7, 2019 In "Computational Chemistry"
Post Calculation Addition of Empirical Dispersion – Fixing interaction energies June 13, 2018 In "Computational Chemistry"
Absorption and Emission Spectra with Gaussian 16 March 30, 2026 In "Computational Chemistry"
CCCBDB DFT Energy Energy levels Free Energy Free Energy Change Free energy of solvation HF MP2 NIST Scaling Factors Thermochemistry Thermodynamics Vibrational Spectroscopy 
Published by joaquinbarroso
Computational and theoretical chemist in his early forties, in love with life, science, baseball, and literature. Science literacy makes us responsible citizens, it is therefore a scientific duty to talk, write, and engage with the general public; as Feynman said, if you find science boring, your learning from the wrong teacher. "Make like a molecule and react!" View all posts by joaquinbarroso
Post navigation
Previous Previous post: On Putting up with Rejections Letters
Next Next post: Orbital Contributions to Excited States
Leave a comment Cancel reply
Write a comment...
Log in or provide your name and email to leave a comment. [-]
Email me new posts [x] instantly
Instantly [-] daily Daily [-] weekly Weekly [-]
Email me new comments [-]
Save my name, email, and website in this browser for the next time I comment.
Comment
Δ
Subscribe
Enter your email address to subscribe to this blog and receive notifications of new posts by email.
Email Address:
Sign me up!
Join 1,926 other subscribers
July 2020
« Jun Aug »
Visitors
Tags
#CompChem #RealTimeChemCarnival ACS AIM Alumni amazement Articles Atoms in Molecules Bacteriochlorophyll basis set Blog Blogging calixarenes CCIQS CConnectionGFCHK::Parse_GFCHK() Chemistry Computational and Theoretical Chemistry computational chemist Computational Chemistry DFT DNA drug carriers drug delivery Excited States Fenna-Matthews-Olson FMO G09 G16 Gaussian GaussView History of science Inorganic Chemistry Internet IRC IYC 2011 Journals Mathematics Models molecular dynamics MultiWFN NBO Nobel Prize Orbitals paper Papers Photochemistry photosynthesis QST2 QST3 quantum chemistry Quantum Mechanics Random thoughts Reaction Mechanism RealTimeChem Research RMFQT Science Silaghi-Dumitrescu Software Sustainability symposium Talks TD-DFT Teaching Theoretical Chemistry theoretical chemists theoretical physical chemistry Thesis Transition State Tricks Twitter UBB UNAM Visualization white papers
Categories
Alumni Articles Blogging Chemistry Computational Chemistry DFT Gaussian Internet Mathematics Models Molecular Dynamics NBO Paper Photochemistry Photosysnthesis Publications Quantum Mechanics Random thoughts Research Science Software Talks TD-DFT Teaching Theoretical Chemistry Tricks Twitter Uncategorized Visualization White papers
Archives
Archives
Select Month
May 2026 (2)
March 2026 (1)
January 2026 (1)
December 2025 (1)
October 2025 (2)
September 2025 (1)
August 2025 (2)
June 2025 (2)
February 2025 (1)
January 2025 (2)
September 2024 (1)
August 2024 (1)
January 2024 (1)
December 2023 (1)
October 2023 (1)
September 2023 (2)
August 2023 (1)
July 2023 (1)
June 2023 (1)
May 2023 (1)
March 2023 (1)
February 2023 (1)
January 2023 (1)
November 2022 (1)
September 2022 (1)
June 2022 (3)
May 2022 (2)
March 2022 (1)
February 2022 (1)
December 2021 (1)
November 2021 (2)
September 2021 (1)
March 2021 (1)
January 2021 (1)
December 2020 (2)
November 2020 (1)
October 2020 (2)
August 2020 (1)
July 2020 (3)
June 2020 (1)
April 2020 (1)
March 2020 (2)
February 2020 (1)
January 2020 (1)
December 2019 (1)
October 2019 (2)
August 2019 (2)
June 2019 (1)
May 2019 (2)
March 2019 (1)
February 2019 (1)
January 2019 (1)
December 2018 (3)
November 2018 (2)
October 2018 (2)
September 2018 (2)
June 2018 (1)
May 2018 (3)
January 2018 (4)
December 2017 (3)
November 2017 (1)
October 2017 (4)
September 2017 (2)
August 2017 (4)
July 2017 (3)
June 2017 (2)
April 2017 (1)
March 2017 (3)
February 2017 (2)
December 2016 (1)
November 2016 (3)
October 2016 (1)
September 2016 (1)
June 2016 (3)
May 2016 (2)
April 2016 (2)
February 2016 (1)
January 2016 (1)
December 2015 (1)
November 2015 (3)
October 2015 (3)
August 2015 (2)
July 2015 (1)
June 2015 (2)
May 2015 (3)
February 2015 (1)
December 2014 (2)
November 2014 (1)
October 2014 (3)
August 2014 (1)
July 2014 (1)
June 2014 (4)
May 2014 (2)
April 2014 (1)
March 2014 (1)
February 2014 (2)
January 2014 (2)
December 2013 (1)
November 2013 (2)
October 2013 (2)
September 2013 (3)
July 2013 (1)
June 2013 (1)
May 2013 (1)
April 2013 (6)
March 2013 (3)
February 2013 (1)
December 2012 (1)
November 2012 (1)
October 2012 (1)
September 2012 (3)
August 2012 (1)
July 2012 (1)
June 2012 (2)
May 2012 (1)
April 2012 (1)
February 2012 (1)
January 2012 (3)
December 2011 (1)
November 2011 (2)
October 2011 (1)
September 2011 (2)
August 2011 (2)
June 2011 (3)
April 2011 (1)
March 2011 (1)
January 2011 (1)
November 2010 (3)
October 2010 (1)
August 2010 (3)
July 2010 (2)
June 2010 (1)
May 2010 (1)
April 2010 (1)
February 2010 (1)
January 2010 (1)
December 2009 (2)
November 2009 (1)
September 2009 (3)
August 2009 (3)
July 2009 (3)
June 2009 (2)
May 2009 (4)
April 2009 (1)
March 2009 (4)
ACI Scholarly Blog Index
Follow me on Mendeley
Joaquin Barroso Flores is a member of Chemistry on Mendeley.
Blogroll
A Chemist in Theory
Behind NMR lines
chem-bla-ics
Doctor Galactic
Henry Rzepa's blog
Steven Bachrach
Stuart Cantrill's blog
The Collapsed Wavefunction
The Curious Wavefunction
The Organic Solution
WordPress.com
WordPress.org
Search
Search for: Search
My twits
Tweets by joaquinbarroso
RSS
RSS - Posts
RSS - Comments
Networked blogs
Follow this blog
© 2026 Dr. Joaquin Barroso's Blog
Blog at WordPress.com. Do Not Sell or Share My Personal Information
Comment
Reblog
Subscribe Subscribed
Dr. Joaquin Barroso's Blog Join 1,368 other subscribers Sign me up
Already have a WordPress.com account? Log in now.
Dr. Joaquin Barroso's Blog
Subscribe Subscribed
Sign up
Log in
Copy shortlink
Report this content
View post in Reader
Manage subscriptions
Collapse this bar Close and accept
Privacy & Cookies: This site uses cookies. By continuing to use this website, you agree to their use.
To find out more, including how to control cookies, see here: Cookie Policy
%d  