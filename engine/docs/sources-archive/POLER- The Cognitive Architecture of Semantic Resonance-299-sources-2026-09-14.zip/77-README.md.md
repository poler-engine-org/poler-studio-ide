POLER v0.3.3 — Continuous Factorization Engine
Build
Requires Rust toolchain (rustup.rs):
Binary will be at target/release/poler033
Run
Key Optimization: Half-Bit Factor Encoding
For semiprimes p*q=N, both factors are less than sqrt(N) < 2^(nb/2). So we only need nb/2+1 bits per factor, NOT nb bits. This halves the binary search space exponentially:
16-bit N: npq=16 (65K combos) instead of npq=32 (4B combos)
24-bit N: npq=26 (67M combos) instead of npq=48 (impossible)
v0.3.3: 4 Fixes Ported from POLER-DYNAMIS v5
1. J != 0 — History-dependent resonance (temporal echo R[n])
2. Sigma = secant-Hessian (true topological curvature)
3. gamma(t) dynamic — Feynman annealing
4. Early termination — stop when E_best=0
Scaling Results — POLYNOMIAL, NOT EXPONENTIAL!
Curve Fit Analysis
Polynomial degree 2: R² = 0.985
Polynomial degree 3: R² = 0.990
Exponential: R² = -3.19 (REJECTED)
The scaling is POLYNOMIAL (degree 2-3), not exponential. This is experimental evidence that the continuous method does NOT hit the exponential barrier on this NP-hard problem.
Parameters (v0.3.3 new)