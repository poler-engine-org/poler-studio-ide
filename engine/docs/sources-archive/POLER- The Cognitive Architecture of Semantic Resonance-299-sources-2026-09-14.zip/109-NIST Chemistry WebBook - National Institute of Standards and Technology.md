> Source: https://webbook.nist.gov/chemistry/

NIST Chemistry WebBook
Jump to content
National Institute of Standards and Technology
NIST Chemistry WebBook, SRD 69
Home
Search
Name
Formula
IUPAC identifier
CAS number
More options
NIST Data
SRD Program
Science Data Portal
Material Data Division
About
FAQ
Credits
More documentation
NIST Chemistry WebBook
NIST Standard Reference Database SRD Number 69
Last update to data: 2025 DOI: https://doi.org/10.18434/T4D303
View: Search Options, Models and Tools, Special Data Collections, Documentation, Changes, Notes
[▷](javascript:toggle_div('Credits','Show Credits','Hide Credits');) Credits
Neutral Thermochemical data
compiled by Hussein Y. Afeefy, Joel F. Liebman, Stephen E. Stein, Donald R. Burgess, Jr.
Entropy and Heat Capacity of Organic Compounds
compiled by Glushko Thermocenter, Moscow
Condensed Phase Heat Capacity data
compiled by Eugene S. Domalski, Elizabeth D. Hearing
Ionization Energetics (IE, AE) data
compiled by Sharon G. Lias, Henry M. Rosenstock, Keith Draxl, Bruce W. Steiner, John T. Herron, John L. Holmes, Rhoda D. Levin, Joel F. Liebman, Sherif A. Kafafi
Ionization Energy data
evaluated by Sharon G. Lias
Negative Ion Energetics data
compiled by John E. Bartmess
Thermochemistry of Cluster Ion data
compiled by Michael N. Mautner and Sharon G. Lias
Metal Ion Clustering Data
compiled by Robert C. Dunbar
Proton Affinity data
compiled and evaluated by Edward P. Hunter, Sharon G. Lias
Vibrational and Electronic Energy Level data
compiled by Marilyn E. Jacox
Vibrational Frequency data
compiled by Takehiko Shimanouchi
Constants of Diatomic Molecules
compiled by Klaus P. Huber, Gerhard H. Herzberg (data prepared by Jean W. Gallagher, Russell D. Johnson, III)
Organometallic Thermochemical data
compiled by José A. Martinho Simões
Heat of Sublimation data
compiled by James S. Chickos
Heat of Fusion data
compiled by James S. Chickos, William E. Acree, Jr., Joel F. Liebman, Students of Chem 202 (Introduction to the Literature of Chemistry), University of Missouri – St. Louis
Boiling Point data
compiled by Robert L. Brown, Stephen E. Stein
Henry's Law Constants
compiled by Rolf Sander
Thermophysical Properties of Fluid Systems
Eric W. Lemmon, Ian H. Bell, Marcia L. Huber, Mark O. McLinden
UV/Visible Spectra
compiled by Victor Talrose, Eugeny B. Stern, Antonina A. Goncharova, Natalia A. Messineva, Natalia V. Trusova, Margarita V. Efimkina, Alexander N. Yermakov, Alexy A. Usov, Axlexander A. Leskin
Thermodynamics Source Database
compiled by Thermodynamics Research Center, NIST Boulder Laboratories, Chris Muzny director
Names, 2-D Structures, Retention Indexes, Mass and IR Spectra data
compiled by NIST Mass Spectrometry Data Center, William E. Wallace director
Quantitative Infrared Database
Pamela M. Chu, Franklin R. Guenther, George C. Rhoderick, Walter J. Lafferty
Evaluated Infrared Reference Spectra
Coblentz Society, Inc.
IARPA / PNNL Liquid Phase IR Spectra
Tanya L. Myers, Russell G. Tonkyn, Ashley M. Oeck, Tyler O. Danby, John S. Loring, Matthew S. Taubman, Stephen W. Sharpe, Jerome C. Birnbaum, Timothy J. Johnson
IARPA / PNNL Solid Phase IR Spectra
Timothy J. Johnson, Tanya L. Myers, Yin-Fong Su, Russell G. Tonkyn, Molly Rose K. Kelly-Gorham, Tyler O. Danby
THz Spectral Database
Edwin J. Heilweil, Matthew B. Campbell
3-D Structures
created by Karl K. Irikura, Thomas C. Allison, Katherine C. Hafner, Stuart C. Ness, Daniel X. Du, Jeffrey W. Qiu, Alexander H. Yang, Helen M. Park, J.K. Skerritt, Mariya S. Shevchuk, Michael Y. Liou, Niranjan B. Ravi, Sonia F. Dermer, Ethan N. Ho, Emily W. Jin, Sejal N. Aggarwal, Sarah N. Pan, Daniel S. Graham, Sarah E. Wollman, Yvonne Niyonzima, Avi M. Newman, Ashley M. Zhang, Ann Marie Martin, Nimit Patel, Abbie Tran, Joseph Tseytlin, Nathan S. Kau, Joel F. Liebman
Miscellaneous data entry and editing
Pamela J. Christian, Diane H. Frizzell, Janiel J. Reed
General Editor Peter J. Linstrom
Editor Emeritus W. Gary Mallard
NIST reserves the right to charge for access to this database in the future.
Search Options Jump to top of page
Models and Tools Jump to top of page
Thermophysical Properties of Fluid Systems: High accuracy data for a select group of fluids.
Group Additivity Based Estimates: Estimates of gas phase thermodynamic properties based on a submitted structure.
Formula Browser: Locates chemical species by building up a chemical formula in Hill order.
Special Data Collections Jump to top of page
Benchmark Spray Combustion Database: A collection of spray combustion data from experiments conducted at NIST.
Droplet Laden Flow Data: Results from experiments involving flow over cylinders.
Documentation Jump to top of page
Frequently asked questions
Version history
A Guide to the NIST Chemistry WebBook: A guide to this site and the data available from it.
Gas-Phase Ion Thermochemistry: An in-depth explanation of gas phase ion data available from this site.
NIST Organic Thermochemistry Archive: A description of the primary source of thermochemical data for this site.
Organometallic Thermochemistry Database: A description of the organometallic thermochemistry database included in this site.
Vibrational and Electronic Energy Levels of Polyatomic Transient Molecules: A description of vibrational and electronic energy level data for molecules with three or more atoms.
Computed 3-D Structures: A description of the manner in which the 3 dimensional structures on this site were generated.
Evaluated Infrared Spectra: A description of one of the collections of IR spectra available on this site.
IARPA / PNNL Liquid Phase IR Spectra: A description of liquid phase quantitative infrared spectra measured at PNNL.
IARPA / PNNL Solid Phase IR Spectra: A description of solid phase quantitative infrared spectra measured at PNNL.
Quantitative Infrared Database: A description of the NIST Quantitative Infrared Database.
THz Spectral Database: A description of THz infrared spectra measured by NIST.
UV/Vis Database User's Guide: A description of the UV/Vis spectra available from this site.
Gas Chromatographic Retention Data: A description of the retention index data available from this site.
Citation Guide: A Guide to the proper citation of data from this site.
Recent changes to this site Jump to top of page
Last update to the site: March, 2025.
Recent changes:
Updated chemical identifiers.
Changed colors for plots to be more accessible.
Updated anion thermochemistry data.
Notes Jump to top of page
This site provides thermochemical, thermophysical, and ion energetics data compiled by NIST under the Standard Reference Data Program.
The National Institute of Standards and Technology (NIST) uses its best efforts to deliver a high quality copy of the Database and to verify that the data contained therein have been selected on the basis of sound scientific judgment. However, NIST makes no warranties to that effect, and NIST shall not be liable for any damage that may result from errors or omissions in the Database.
NIST is an agency of the U.S. Department of Commerce.
The NIST Chemistry WebBook was developed in part with funds from the Systems Integration for Manufacturing Applications (SIMA) program at NIST.
Customer support for NIST Standard Reference Data products.
© 2026 by the U.S. Secretary of Commerce on behalf of the United States of America. All rights reserved.
Copyright for NIST Standard Reference Data is governed by the Standard Reference Data Act.
Site Privacy
Accessibility
Privacy Program
Copyrights (Note: This site is covered by copyright.)
Vulnerability Disclosure
No Fear Act Policy
FOIA
Environmental Policy
Scientific Integrity
Information Quality Standards
Commerce.gov
Science.gov
USA.gov
Vote.gov