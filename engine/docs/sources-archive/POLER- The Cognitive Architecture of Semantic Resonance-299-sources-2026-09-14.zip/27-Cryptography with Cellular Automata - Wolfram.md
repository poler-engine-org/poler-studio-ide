> Source: https://content.wolfram.com/sw-publications/2020/07/cryptography-cellular-automata.pdf

