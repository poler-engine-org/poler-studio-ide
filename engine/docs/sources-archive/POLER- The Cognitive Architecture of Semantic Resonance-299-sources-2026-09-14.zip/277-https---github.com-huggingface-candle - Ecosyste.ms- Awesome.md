> Source: https://awesome.ecosyste.ms/projects/github.com%2Fhuggingface%2Fcandle

https://github.com/huggingface/candle | Ecosyste.ms: Awesome
ecosyste.ms
All services
Data
Packages
Repositories
Advisories
Tools
Dependency Parser
Dependency Resolver
SBOM Parser
License Parser
Digest
Archives
Diff
Summary
Indexes
Timeline
Commits
Issues
Sponsors
Docker
Open Collective
Dependabot
Applications
Funds
Dashboards
Experiments
OST
Papers
Awesome
Ruby
Awesome
An open API service indexing awesome lists of open source software.
Support
GitHub
API
https://github.com/huggingface/candle
Minimalist ML framework for Rust
https://github.com/huggingface/candle
*Last synced: 10 months ago
JSON representation*
Minimalist ML framework for Rust
Host: GitHub
URL: https://github.com/huggingface/candle
Owner: huggingface
License: apache-2.0
Created: 2023-06-19T16:06:31.000Z (over 2 years ago)
Default Branch: main
Last Pushed: 2025-04-28T07:19:46.000Z (10 months ago)
Last Synced: 2025-04-28T10:11:22.700Z (10 months ago)
Language: Rust
Size: 12 MB
Stars: 17,088
Watchers: 169
Forks: 1,086
Open Issues: 521
Metadata Files:
Readme: README.md
Changelog: CHANGELOG.md
License: LICENSE-APACHE
Awesome Lists containing this project
awesome-genai - Candle - ML framework for Rust (Tools)
awesome-rust - huggingface/candle - core](https://crates.io/crates/candle-core)]- a minimalist ML framework with a focus on easiness of use and on performance (including GPU support) (Libraries / Artificial Intelligence)
StarryDivineSky - huggingface/candle
awesome-rust - huggingface/candle - core](https://crates.io/crates/candle-core)] - a minimalist ML framework with a focus on easiness of use and on performance (including GPU support) (Libraries / Artificial Intelligence)
awesome-yolo-object-detection - Candle
awesome-llm-and-aigc - Candle
awesome-llmops - Candle - square`) | (Training / Frameworks for Training)
awesome-cuda-and-hpc - Candle
awesome-rust-list - Candle
awesome - huggingface/candle - Minimalist ML framework for Rust (Rust)
fucking-awesome-rust - huggingface/candle - core](https://crates.io/crates/candle-core)] - a minimalist ML framework with a focus on easiness of use and on performance (including GPU support) (Libraries / Artificial Intelligence)
awesome-rust-neural-network - candle - mkl-src, cudarc, metal, accelerate-src | 2025-06-07 | (Neural Networks)
fucking-awesome-machine-learning - candle - Candle is a minimalist ML framework for Rust with a focus on performance (including GPU support) and ease of use. (Rust / General-Purpose Machine Learning)
awesome-machine-learning - candle - Candle is a minimalist ML framework for Rust with a focus on performance (including GPU support) and ease of use. (Rust / General-Purpose Machine Learning)
awesome-yew - candle-wasm-examples - Candle is a minimalist ML framework for Rust with a focus on performance (including GPU support) and ease of use. Try our online demos: whisper, LLaMA2, T5, yolo, [Segment (Projects)
Awesome-LLMOps - Candle - commit/huggingface/candle?color=green) (Training / Framework)
awesome-machine-learning - candle - Candle is a minimalist ML framework for Rust with a focus on performance (including GPU support) and ease of use. (Rust / General-Purpose Machine Learning)
awesome-rust-with-stars - huggingface/candle - core) | a minimalist ML framework with a focus on easiness of use and on performance (including GPU support) | 2026-01-24 | (Libraries / Artificial Intelligence)
awesome-repositories - huggingface/candle - Minimalist ML framework for Rust (Rust)
awesome - huggingface/candle - Minimalist ML framework for Rust (Rust)
README
cargo run should display a tensor of shape Tensor[[2, 4], f32].
Having installed candle with Cuda support, simply define the device to be on GPU:
For more advanced examples, please have a look at the following section.
Check out our examples
These online demos run entirely in your browser:
yolo: pose estimation and object recognition.
whisper: speech recognition.
LLaMA2: text generation.
T5: text generation.
Phi-1.5, and Phi-2: text generation.
Segment Anything Model: Image segmentation.
BLIP: image captioning.
We also provide a some command line based examples using state of the art models:
LLaMA v1, v2, and v3: general LLM, includes the SOLAR-10.7B variant.
Falcon: general LLM.
Codegeex4: Code completion,code interpreter,web search,fuction calling,repository-level
GLM4: Open Multilingual Multimodal Chat LMs by THUDM
Gemma v1 and v2: 2b and 7b+/9b general LLMs from Google Deepmind.
RecurrentGemma: 2b and 7b Griffin based models from Google that mix attention with a RNN like state.
Phi-1, Phi-1.5, Phi-2, and Phi-3: 1.3b, 2.7b, and 3.8b general LLMs with performance on par with 7b models.
StableLM-3B-4E1T: a 3b general LLM pre-trained on 1T tokens of English and code datasets. Also supports StableLM-2, a 1.6b LLM trained on 2T tokens, as well as the code variants.
Mamba: an inference only implementation of the Mamba state space model.
Mistral7b-v0.1: a 7b general LLM with better performance than all publicly available 13b models as of 2023-09-28.
Mixtral8x7b-v0.1: a sparse mixture of experts 8x7b general LLM with better performance than a Llama 2 70B model with much faster inference.
StarCoder and StarCoder2: LLM specialized to code generation.
Qwen1.5: Bilingual (English/Chinese) LLMs.
RWKV v5 and v6: An RNN with transformer level LLM performance.
Replit-code-v1.5: a 3.3b LLM specialized for code completion.
Yi-6B / Yi-34B: two bilingual (English/Chinese) general LLMs with 6b and 34b parameters.
Quantized LLaMA: quantized version of the LLaMA model using the same quantization techniques as llama.cpp.
Stable Diffusion: text to image generative model, support for the 1.5, 2.1, SDXL 1.0 and Turbo versions.
Wuerstchen: another text to image generative model.
yolo-v3 and yolo-v8: object detection and pose estimation models.
segment-anything: image segmentation model with prompt.
SegFormer: transformer based semantic segmentation model.
Whisper: speech recognition model.
EnCodec: high-quality audio compression model using residual vector quantization.
MetaVoice: foundational model for text-to-speech.
Parler-TTS: large text-to-speech model.
T5, Bert, JinaBert : useful for sentence embeddings.
DINOv2: computer vision model trained using self-supervision (can be used for imagenet classification, depth evaluation, segmentation).
VGG, RepVGG: computer vision models.
BLIP: image to text model, can be used to generate captions for an image.
CLIP: multi-model vision and language model.
TrOCR: a transformer OCR model, with dedicated submodels for hand-writing and printed recognition.
Marian-MT: neural machine translation model, generates the translated text from the input text.
Moondream: tiny computer-vision model that can answer real-world questions about images.
Run them using commands like:
In order to use CUDA add --features cuda to the example command line. If you have cuDNN installed, use --features cudnn for even more speedups.
There are also some wasm examples for whisper and llama2.c. You can either build them with trunk or try them online: whisper, llama2, T5, Phi-1.5, and Phi-2, Segment Anything Model.
For LLaMA2, run the following command to retrieve the weight files and start a test server:
And then head over to http://localhost:8081/.
Useful External Resources
candle-tutorial: A very detailed tutorial showing how to convert a PyTorch model to Candle.
candle-lora: Efficient and ergonomic LoRA implementation for Candle. candle-lora has
out-of-the-box LoRA support for many models from Candle, which can be found here.
optimisers: A collection of optimisers including SGD with momentum, AdaGrad, AdaDelta, AdaMax, NAdam, RAdam, and RMSprop.
candle-vllm: Efficient platform for inference and serving local LLMs including an OpenAI compatible API server.
candle-ext: An extension library to Candle that provides PyTorch functions not currently available in Candle.
candle-coursera-ml: Implementation of ML algorithms from Coursera's Machine Learning Specialization course.
kalosm: A multi-modal meta-framework in Rust for interfacing with local pre-trained models with support for controlled generation, custom samplers, in-memory vector databases, audio transcription, and more.
candle-sampling: Sampling techniques for Candle.
gpt-from-scratch-rs: A port of Andrej Karpathy's Let's build GPT tutorial on YouTube showcasing the Candle API on a toy problem.
candle-einops: A pure rust implementation of the python einops library.
atoma-infer: A Rust library for fast inference at scale, leveraging FlashAttention2 for efficient attention computation, PagedAttention for efficient KV-cache memory management, and multi-GPU support. It is OpenAI api compatible.
llms-from-scratch-rs: A comprehensive Rust translation of the code from Sebastian Raschka's Build an LLM from Scratch book.
If you have an addition to this list, please submit a pull request.
Features
Simple syntax, looks and feels like PyTorch.
Model training.
Embed user-defined ops/kernels, such as flash-attention v2.
Backends.
Optimized CPU backend with optional MKL support for x86 and Accelerate for macs.
CUDA backend for efficiently running on GPUs, multiple GPU distribution via NCCL.
WASM support, run your models in a browser.
Included models.
Language Models.
LLaMA v1, v2, and v3 with variants such as SOLAR-10.7B.
Falcon.
StarCoder, StarCoder2.
Phi 1, 1.5, 2, and 3.
Mamba, Minimal Mamba
Gemma v1 2b and 7b+, v2 2b and 9b.
Mistral 7b v0.1.
Mixtral 8x7b v0.1.
StableLM-3B-4E1T, StableLM-2-1.6B, Stable-Code-3B.
Replit-code-v1.5-3B.
Bert.
Yi-6B and Yi-34B.
Qwen1.5, Qwen1.5 MoE.
RWKV v5 and v6.
Quantized LLMs.
Llama 7b, 13b, 70b, as well as the chat and code variants.
Mistral 7b, and 7b instruct.
Mixtral 8x7b.
Zephyr 7b a and b (Mistral-7b based).
OpenChat 3.5 (Mistral-7b based).
Text to text.
T5 and its variants: FlanT5, UL2, MADLAD400 (translation), CoEdit (Grammar correction).
Marian MT (Machine Translation).
Text to image.
Stable Diffusion v1.5, v2.1, XL v1.0.
Wurstchen v2.
Image to text.
BLIP.
TrOCR.
Audio.
Whisper, multi-lingual speech-to-text.
EnCodec, audio compression model.
MetaVoice-1B, text-to-speech model.
Parler-TTS, text-to-speech model.
Computer Vision Models.
DINOv2, ConvMixer, EfficientNet, ResNet, ViT, VGG, RepVGG, ConvNeXT, ConvNeXTv2, MobileOne, EfficientVit (MSRA), MobileNetv4, Hiera, FastViT.
yolo-v3, yolo-v8.
Segment-Anything Model (SAM).
SegFormer.
File formats: load models from safetensors, npz, ggml, or PyTorch files.
Serverless (on CPU), small and fast deployments.
Quantization support using the llama.cpp quantized types.
How to use
Cheatsheet:
Structure
candle-core: Core ops, devices, and Tensor struct definition
candle-nn: Tools to build real models
candle-examples: Examples of using the library in realistic settings
candle-kernels: CUDA custom kernels
candle-datasets: Datasets and data loaders.
candle-transformers: transformers-related utilities.
candle-flash-attn: Flash attention v2 layer.
candle-onnx: ONNX model evaluation.
FAQ
Why should I use Candle?
Candle's core goal is to make serverless inference possible. Full machine learning frameworks like PyTorch are very large, which makes creating instances on a cluster slow. Candle allows deployment of lightweight binaries.
Secondly, Candle lets you remove Python from production workloads. Python overhead can seriously hurt performance, and the GIL is a notorious source of headaches.
Finally, Rust is cool! A lot of the HF ecosystem already has Rust crates, like safetensors and tokenizers.
Other ML frameworks
dfdx is a formidable crate, with shapes being included in types. This prevents a lot of headaches by getting the compiler to complain about shape mismatches right off the bat. However, we found that some features still require nightly, and writing code can be a bit daunting for non rust experts.
We're leveraging and contributing to other core crates for the runtime so hopefully both crates can benefit from each other.
burn is a general crate that can leverage multiple backends so you can choose the best engine for your workload.
tch-rs Bindings to the torch library in Rust. Extremely versatile, but they bring in the entire torch library into the runtime. The main contributor of tch-rs is also involved in the development of candle.
Common Errors
Missing symbols when compiling with the mkl feature.
If you get some missing symbols when compiling binaries/tests using the mkl or accelerate features, e.g. for mkl you get:
or for accelerate:
This is likely due to a missing linker flag that was needed to enable the mkl library. You can try adding the following for mkl at the top of your binary:
or for accelerate:
Cannot run the LLaMA examples: access to source requires login credentials
This is likely because you're not permissioned for the LLaMA-v2 model. To fix this, you have to register on the huggingface-hub, accept the LLaMA-v2 model conditions, and set up your authentication token. See issue #350 for more details.
Missing cute/cutlass headers when compiling flash-attn
cutlass is provided as a git submodule so you may want to run the following command to check it in properly.
Compiling with flash-attention fails
This is a bug in gcc-11 triggered by the Cuda compiler. To fix this, install a different, supported gcc version - for example gcc-10, and specify the path to the compiler in the NVCC_CCBIN environment variable.
Linking error on windows when running rustdoc or mdbook tests
Make sure you link all native libraries that might be located outside a project target, e.g., to run mdbook tests, you should run:
Extremely slow model load time with WSL
This may be caused by the models being loaded from /mnt/c, more details on stackoverflow.
Tracking down errors
You can set RUST_BACKTRACE=1 to be provided with backtraces when a candle error is generated.
CudaRC error
If you encounter an error like this one called Result::unwrap()on anErr value: LoadLibraryExW { source: Os { code: 126, kind: Uncategorized, message: "The specified module could not be found." } } on windows. To fix copy and rename these 3 files (make sure they are in path). The paths depend on your cuda version. c:\Windows\System32\nvcuda.dll -> cuda.dll c:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.4\bin\cublas64_12.dll -> cublas.dll c:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.4\bin\curand64_10.dll -> curand.dll