> Source: https://www.nist.gov/pml/fundamental-physical-constants

Fundamental Physical Constants | NIST
Skip to main content 
An official website of the United States government
Here's how you know
Here's how you know 
Official websites use .gov
A .gov website belongs to an official government organization in the United States. 
Secure .gov websites use HTTPS
A lock ( A locked padlock ) or https:// means you've safely connected to the .gov website. Share sensitive information only on official, secure websites.
https://www.nist.gov/pml/fundamental-physical-constants 
Search NIST 
Menu
Close
Publications
What We Do
All Topics
Advanced communications
Artificial intelligence
Bioscience
Buildings and construction
Chemistry
Cybersecurity and Privacy
Electronics
Energy
Environment
Fire
Forensic science
Health
Information technology
Infrastructure
Manufacturing
Materials
Mathematics and statistics
Metrology
Nanotechnology
Neutron research
Performance excellence
Physics
Public safety
Quantum information science
Resilience
Standards
Transportation
Labs & Major Programs
Assoc Director of Laboratory Programs
Laboratories
Communications Technology Laboratory
Engineering Laboratory
Information Technology Laboratory
Material Measurement Laboratory
Physical Measurement Laboratory
User Facilities
NIST Center for Neutron Research
CNST NanoFab
Research Test Beds
Research Projects
Tools & Instruments
Major Programs
Baldrige Performance Excellence Program
CHIPS for America Initiative
Manufacturing Extension Partnership (MEP)
Office of Advanced Manufacturing
Special Programs Office
Technology Partnerships Office
Services & Resources
Measurements and Standards
Calibration Services
Laboratory Accreditation (NVLAP)
Quality System
Standard Reference Materials (SRMs)
Standard Reference Instruments (SRIs)
Standards.gov
Time Services
Office of Weights and Measures
Software
Data
Chemistry WebBook
National Vulnerability Database
Physical Reference Data
Standard Reference Data (SRD)
Storefront
License & Patents
Computer Security Resource Center (CSRC)
NIST Research Library
News & Events
News
Events
Blogs
NIST In Focus
Feature Stories
Awards
Video Gallery
Image Gallery
Media Contacts
About NIST
About Us
Leadership
Organization Structure
Budget & Planning
Contact Us
Visit
Careers
Student programs
Work with NIST
History
NIST Digital Archives
NIST Museum
NIST and the Nobel
Educational Resources
Physical Measurement Laboratory
About PML Expand or Collapse
Events
PML Brochure
PML Leadership
PML Working for You
Staff Directory
Calibrations Customer Survey (external link)
Divisions Expand or Collapse
Applied Physics
Microsystems and Nanotechnology
Nanoscale Device Characterization
Quantum Measurement
Quantum Physics
Quantum Sensors
Radiation Physics
Sensor Science
Time and Frequency
Weights & Measures
Products/Services Expand or Collapse
The Official U.S. Time
Amazing Stories of Measurement
General Interest
Measurements & Calibrations
Measuring The Cosmos
Million-Pound Makeover
NIST-on-a-Chip Portal
Physical Reference Data
Quantum Networks at NIST
SI Redefinition Portal
Special Publications & Tutorials
Working With Us
News/Multimedia
Programs/Projects
Facilities Expand or Collapse
Boulder MicroFabrication Facility
CNST NanoFab
Electron Beam Ion Trap (EBIT)
Hi-Res UV & Optical Spectro. Facility
Low-background IR Radiation Facility
Neutron Imaging Facility (NIF)
Neutron Interferometer Facility (NIOF)
Precision Imaging Facility
Radiopharmaceutical Standardization Laboratory
Synchrotron Ultraviolet Radiation Facility SURF III
W.M. Keck Optical Meas. Lab
Email Newsletter
Connect with us
GovDelivery
Fundamental Physical Constants
Share 
Facebook
Linkedin
X.com
[Email](mailto:?subject=NIST.gov&body=Check out this site https://www.nist.gov/pml/fundamental-physical-constants)
Values of Fundamental Physical Constants
Searchable Bibliography of Fundamental Constants
International System of Units (SI)
Guidelines for Evaluating and Expressing Measurement Uncertainty
Values of Fundamental Physical Constants 
Eite Tiesinga, Peter J. Mohr, David B. Newell, and Barry N. Taylor
This database gives values of the basic constants and conversion factors of physics and chemistry resulting from the 2022 least-squares adjustment of the fundamental physical constants as published by the CODATA Task Group on Fundamental Constants and recommended for international use by CODATA.
Searchable Bibliography of Fundamental Constants 
Peter J. Mohr and Barry N. Taylor
This searchable database gives the citations for the most important theoretical and experimental publications relevant to the fundamental physical constants and closely related precision measurements published since the mid 1980s. Earlier papers of particular interest are also included. The database is updated on a daily basis through the addition of papers from the current literature and made more comprehensive through the addition of earlier papers.
International System of Units (SI) 
David B. Newell and Eite Tiesinga
This is a description of the SI, the modern metric system of measurement. Long the language universally used in science, the SI has become the dominant language of international commerce and trade. Included are: 1) descriptions of base and derived SI units; 2) conversion factors from non-SI to SI units; and 3) rules and style conventions for spelling, printing, and using units of the SI (with SI prefixes), and for expressing values of quantities, including the results of measurements.
Guidelines for Evaluating and Expressing Measurement Uncertainty 
Barry N. Taylor and Chris E. Kuyatt
This publication gives the NIST policy on expressing measurement uncertainty. Further, it succinctly summarizes the International Organization for Standardization (ISO) 100-page Guide to the Expression of Uncertainty in Measurement on which the NIST policy is based. Appendix D clarifies and gives additional guidance on a number of topics related to measurement uncertainty, including the use of certain terms such as accuracy and precision.
NIST Uncertainty Machine 
Metrology, Atomic / molecular / quantum, Nuclear physics and Reference data
Contacts 
PML webmaster pml-webmaster@nist.gov
Created June 10, 2009, Updated May 9, 2024
Was this page helpful?
HEADQUARTERS
100 Bureau Drive
Gaithersburg, MD 20899
301-975-2000
Webmaster | Contact Us | Our Other Offices
X.com Facebook LinkedIn Instagram YouTube Giphy RSS Feed Mailing List
How are we doing? Feedback
Site Privacy
Accessibility
Privacy Program
Copyright & Disclaimers
Vulnerability Disclosure
No Fear Act Policy
FOIA
Environmental Policy
Scientific Integrity
Information Quality Standards
Commerce.gov
Science.gov
USA.gov
Vote.gov
Back to top