> Source: https://github.com/matthew-mcateer/Keras_pruning

GitHub - matthew-mcateer/Keras_pruning: A walkthrough of how to prune keras models, using both weight-pruning and unit/neuron-pruning.
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
matthew-mcateer / Keras_pruning Public
Notifications You must be signed in to change notification settings
Fork 14
Star 30
A walkthrough of how to prune keras models, using both weight-pruning and unit/neuron-pruning.
30 stars 14 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 1
Pull requests 0
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
matthew-mcateer/Keras_pruning
master
1 Branch 0 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
Keras pruning
 
A walkthrough of how to prune keras models using both weight-pruning and unit-pruning.
Overview
There are multiple ways of optimizing neural-network-based machine learning algorithms. One of these optimizations is the removal of connections between neurons and layers, and thus speeding up computation by reducing the overal number of parameters.
Networks generally look like the one on the left: every neuron in the layer below has a connection to the layer above; but this means that we have to multiply a lot of floats together. Ideally, we'd only connect each neuron to a few others and save on doing some of the multiplications; this is called a “sparse” network.
Given a layer of a neural network R e L U ( x W ) are two well-known ways to prune it:
Weight pruning: set individual weights in the weight matrix to zero. This corresponds to deleting connections as in the figure above.
Here, to achieve sparsity of k we rank the individual weights in weight matrix W according to their magnitude (absolute value) | w i , j | , and then set to zero the smallest k .
Unit/Neuron pruning: set entire columns to zero in the weight matrix to zero, in effect deleting the corresponding output neuron.
Here to achieve sparsity of k we rank the columns of a weight matrix according to their L2-norm | w | = ∑ i = 1 N ( x i ) 2 and delete the smallest k .
Naturally, as you increase the sparsity and delete more of the network, the task performance will progressively degrade. This repo serves as a demonstration of both weight and unit pruning and compare the performance across both the MNIST and FMNIST datasets.
Requirements
Tensorflow
Numpy
Pandas
Matplotlib
Seaborn
Installation Instructions
There are two ways to run this notebook:
Running in-browser (Google Colab)
Open this notebook in Google Colab (by following this link)
Running locally
Clone this repository with the following command: git clone https://github.com/matthew-mcateer/Keras_pruning.git
Run jupyter Model_pruning_exploration.ipynb
Optional: before running the notebook, create a separate environment using conda and install the Requirements above in the environment. Activate your conda environment before running Jupyter.
References/Resources
"Pruning deep neural networks to make them fast and small", Jacob's Computer Vision and Machine Learning blog
Molchanov, Pavlo, et al. "Pruning convolutional neural networks for resource efficient inference." arXiv preprint arXiv:1611.06440 (2016).
Li, Hao, et al. "Pruning filters for efficient convnets." arXiv preprint arXiv:1608.08710 (2016).
Saliency map. Wikipedia. https://en.wikipedia.org/wiki/Saliency_map
http://yann.lecun.com/exdb/publis/pdf/lecun-90b.pdf
Frankle, Jonathan, and Michael Carbin. "The lottery ticket hypothesis: Finding sparse, trainable neural networks." arXiv preprint arXiv:1803.03635 (2018).
Zhang, Jiayao, Guangxu Zhu, and Robert W. Heath Jr. "Grassmannian Learning: Embedding Geometry Awareness in Shallow and Deep Learning." arXiv preprint arXiv:1808.02229 (2018).
Generating Large Images From Latent Vectors. David Ha's blog
Zhou, Hattie, et al. "Deconstructing lottery tickets: Zeros, signs, and the supermask." arXiv preprint arXiv:1905.01067 (2019).
About
A walkthrough of how to prune keras models, using both weight-pruning and unit/neuron-pruning.
Topics
visualization machine-learning tutorial neural-network jupyter-notebook pruning optimization-algorithms colab-notebook
Resources
Readme
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
30 stars
Watchers
0 watching
Forks
14 forks
Report repository
Releases
No releases published
Packages 0
No packages published
Languages
Jupyter Notebook 100.0%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.