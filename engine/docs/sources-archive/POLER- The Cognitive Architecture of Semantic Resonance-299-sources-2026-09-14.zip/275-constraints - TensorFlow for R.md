> Source: https://tensorflow.rstudio.com/reference/keras/constraints

TensorFlow for R – constraints
We use cookies
This website uses cookies and other tracking technologies to improve your browsing experience for the following purposes: to enable basic functionality of the website, to provide a better experience on the website, to measure your interest in our products and services and to personalize marketing interactions. Privacy Policy
I agree I decline Change my preferences 
TensorFlow for R
Search
Install
Tutorials
Guides
Examples
Reference
tensorflow
keras
tfdatasets
tfautograph
website 
On this page
constraints
Weight constraints
Description
Usage
Arguments
Details
Section
Custom constraints
See Also
Edit this page
View source
Report an issue
R/constraints.R
constraints
Weight constraints
Description
Functions that impose constraints on weight values.
Usage
Arguments
Arguments
Description
max_value
The maximum norm for the incoming weights.
axis
The axis along which to calculate weight norms. For instance, in a dense layer the weight matrix has shape input_dim, output_dim , set axis to 0 to constrain each weight vector of length input_dim, . In a convolution 2D layer with dim_ordering="tf" , the weight tensor has shape rows, cols, input_depth, output_depth , set axis to c(0, 1, 2) to constrain the weights of each filter tensor of size rows, cols, input_depth .
min_value
The minimum norm for the incoming weights.
rate
The rate for enforcing the constraint: weights will be rescaled to yield (1 - rate) * norm + rate * norm.clip(low, high). Effectively, this means that rate=1.0 stands for strict enforcement of the constraint, while rate<1.0 means that weights will be rescaled at each step to slowly move towards a value inside the desired interval.
Details
constraint_maxnorm() constrains the weights incident to each hidden unit to have a norm less than or equal to a desired value.
constraint_nonneg() constraints the weights to be non-negative
constraint_unitnorm() constrains the weights incident to each hidden unit to have unit norm.
constraint_minmaxnorm() constrains the weights incident to each hidden unit to have the norm between a lower bound and an upper bound.
Section
Custom constraints
You can implement your own constraint functions in R. A custom constraint is an R function that takes weights ( w ) as input and returns modified weights. Note that keras backend() tensor functions (e.g. k_greater_equal() ) should be used in the implementation of custom constraints. For example: ```
nonneg_constraint <- function(w) {
w * k_cast(k_greater_equal(w, 0), k_floatx())
}
layer_dense(units = 32, input_shape = c(784),
`` Note that models which use custom constraints cannot be serialized using save_model_hdf5() `. Rather, the weights of the model should be saved and restored using` save_model_weights_hdf5()`.
See Also
Dropout: A Simple Way to Prevent Neural Networks from Overfitting Srivastava, Hinton, et al. 2014 KerasConstraint
Proudly supported by
Copyright © 2015-2022 The TensorFlow Authors and RStudio, PBC.