> Source: https://en.wikipedia.org/wiki/Outline_of_computer_science

Outline of computer science - Wikipedia
Jump to content [-]
Main menu
Main menu
move to sidebar hide
Navigation
Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Contribute
Help
Learn to edit
Community portal
Recent changes
Upload file
Special pages
Search
Search [-]
Appearance
Donate
Create account
Log in [-]
Personal tools
Donate
Create account
Log in
Contents
move to sidebar hide
(Top)
1 Subfields Toggle Subfields subsection
1.1 Mathematical foundations
1.2 Algorithms and data structures
1.3 Artificial intelligence
1.4 Communication and security
1.5 Computer architecture
1.6 Computer graphics
1.7 Concurrent, parallel, and distributed systems
1.8 Databases
1.9 Programming languages and compilers
1.10 Scientific computing
1.11 Software engineering
1.12 Theory of computation
2 History
3 Professions
4 Data and data structures
5 Programming paradigms
6 See also
7 External links [-]
Toggle the table of contents
Outline of computer science
[-]
4 languages
العربية
Azərbaycanca
فارسی
中文
Edit links
Article
Talk [-]
English
Read
Edit
View history [-]
Tools
Tools
move to sidebar hide
Actions
Read
Edit
View history
General
What links here
Related changes
Upload file
Permanent link
Page information
Cite this page
Get shortened URL
Download QR code
Expand all
Edit interlanguage links
Print/export
Download as PDF
Printable version
In other projects
Wikidata item
Appearance
move to sidebar hide
Birthday mode (Baby Globe)
[-] 0 Disabled [x] 1 Enabled Learn more about Birthday mode
Text
[-] 0 Small [x] 1 Standard [-] 2 Large
This page always uses small font size
Width
[x] 1 Standard [-] 0 Wide
The content is as wide as possible for your browser window.
Color (beta)
[-] os Automatic [x] day Light [-] night Dark
This page is always in light mode.
From Wikipedia, the free encyclopedia
Overview of and topical guide to computer science
Computer science (also called computing science) is the study of the theoretical foundations of information and computation and their implementation and application in computer systems. One well known subject classification system for computer science is the ACM Computing Classification System devised by the Association for Computing Machinery.
Computer science can be described as all of the following:
Academic discipline
Science
Applied science
Subfields
[ edit]
Mathematical foundations
[ edit]
Coding theory – Useful in networking, programming, system development, and other areas where computers communicate with each other.
Game theory – Useful in artificial intelligence and cybernetics.
Discrete mathematics – Study of discrete structures. Used in digital computer systems.
Graph theory – Foundations for data structures and searching algorithms.
Mathematical logic – Boolean logic and other ways of modeling logical queries; the uses and limitations of formal proof methods.
Number theory – Theory of the integers. Used in cryptography as well as a test domain in artificial intelligence.
Algorithms and data structures
[ edit]
Algorithms – Sequential and parallel computational procedures for solving a wide range of problems.
Data structures – The organization and manipulation of data.
Artificial intelligence
[ edit]
Outline of artificial intelligence
Artificial intelligence – The implementation and study of systems that exhibit an autonomous intelligence or behavior of their own.
Automated reasoning – Solving engines, such as used in Prolog, which produce steps to a result given a query on a fact and rule database, and automated theorem provers that aim to prove mathematical theorems with some assistance from a programmer.
Computer vision – Algorithms for identifying three-dimensional objects from a two-dimensional picture.
Soft computing, the use of inexact solutions for otherwise extremely difficult problems:
Machine learning – Development of models that are able to learn and adapt without following explicit instructions, by using algorithms and statistical models to analyze and draw inferences from patterns in data.
Evolutionary computing – Biologically inspired algorithms.
Natural language processing – Building systems and algorithms that analyze, understand, and generate natural (human) languages.
Robotics – Algorithms for controlling the behavior of robots.
Communication and security
[ edit]
Networking – Algorithms and protocols for reliably communicating data across different shared or dedicated media, often including error correction.
Computer security – Practical aspects of securing computer systems and computer networks.
Cryptography – Applies results from complexity, probability, algebra, and number theory to invent and break codes, and analyze the security of cryptographic protocols.
Computer architecture
[ edit]
Computer architecture – The design, organization, optimization, and verification of a computer system, mostly about CPUs and Memory subsystems (and the bus connecting them).
Operating systems – Systems for managing computer programs and providing the basis of a usable system.
Computer graphics
[ edit]
Computer graphics – Algorithms both for generating visual images synthetically, and for integrating or altering visual and spatial information sampled from the real world.
Image processing – Determining information from an image through computation.
Information visualization – Methods for representing and displaying abstract data to facilitate human interaction for exploration and understanding.
Concurrent, parallel, and distributed systems
[ edit]
Parallel computing – The theory and practice of simultaneous computation; data safety in any multitasking or multithreaded environment.
Concurrency (computer science) – Computing using multiple concurrent threads of execution, devising algorithms for solving problems on various processors to achieve maximal speed-up compared to sequential execution.
Distributed computing – Computing using multiple computing devices over a network to accomplish a common objective or task, and thereby reducing the latency involved in single processor contributions for any task.
Databases
[ edit]
Outline of databases
Relational databases – the set theoretic and algorithmic foundation of databases.
Structured Storage – non-relational databases such as NoSQL databases.
Data mining – Study of algorithms for searching and processing information in documents and databases; closely related to information retrieval.
Programming languages and compilers
[ edit]
Compiler theory – Theory of compiler design, based on Automata theory.
Programming language pragmatics – Taxonomy of programming languages, their strength, and weaknesses. Various programming paradigms, such as object-oriented programming.
Programming language theory – Theory of programming language design
Formal semantics – rigorous mathematical study of the meaning of programs.
Type theory – Formal analysis of the types of data, and the use of these types to understand properties of programs — especially program safety.
Scientific computing
[ edit]
Computational science – constructing mathematical models and quantitative analysis techniques and using computers to analyze and solve scientific problems.
Numerical analysis – Approximate numerical solution of mathematical problems such as root-finding, integration, the solution of ordinary differential equations; the approximation of special functions.
Symbolic computation – Manipulation and solution of expressions in symbolic form, also known as Computer algebra.
Computational physics – Numerical simulations of large non-analytic systems
Computational chemistry – Computational modelling of theoretical chemistry in order to determine chemical structures and properties
Bioinformatics and Computational biology – The use of computer science to maintain, analyze, store biological data and to assist in solving biological problems such as Protein folding, function prediction and Phylogeny.
Computational neuroscience – Computational modelling of neurophysiology.
Computational linguistics
Computational logic – Use of logic to perform or reason about computation
Computational engineering – Field of algorithmic training
Software engineering
[ edit]
Outline of software engineering
Formal methods – Mathematical approaches for describing and reasoning about software design.
Software engineering – The principles and practice of designing, developing, and testing programs, as well as proper engineering practices.
Algorithm design – Using ideas from algorithm theory to creatively design solutions to real tasks.
Computer programming – The practice of using a programming language to implement algorithms.
Human–computer interaction – The study and design of computer interfaces that people use.
Reverse engineering – The application of the scientific method to the understanding of arbitrary existing software.
Theory of computation
[ edit]
Main article: Theory of computation
Automata theory – Different logical structures for solving problems.
Computability theory – What is calculable with the current models of computers. Proofs developed by Alan Turing and others provide insight into the possibilities of what may be computed and what may not.
List of unsolved problems in computer science
Computational complexity theory – Fundamental bounds (especially time and storage space) on classes of computations.
Quantum computing theory – Explores computational models involving quantum superposition of bits.
History
[ edit]
History of computer science
List of pioneers in computer science
History of Artificial Intelligence
History of operating systems
Professions
[ edit]
Computer Scientist
Programmer (Software developer)
Teacher/ Professor
Software engineer
Software architect
Software tester
Hardware engineer
Data analyst
Interaction designer
Network administrator
Data scientist
Data and data structures
[ edit]
Data structure
Data type
Associative array and Hash table
Array
List
Tree
String
Matrix (computer science)
Database
Programming paradigms
[ edit]
Imperative programming/ Procedural programming
Functional programming
Logic programming
Declarative Programming
Event-Driven Programming
Object oriented programming
Class
Inheritance
Object
See also
[ edit]
Abstraction
Big O notation
Closure
Compiler
Cognitive science
External links
[ edit]
Computer science at Wikipedia's sister projects
Definitions from Wiktionary
Media from Commons
News from Wikinews
Quotations from Wikiquote
Texts from Wikisource
Textbooks from Wikibooks
Resources from Wikiversity
List of Computer Scientists
Glossary of Computer Science
show
v
t
e
Computer science
Note: This template roughly follows the 2012 ACM Computing Classification System.
Hardware
Printed circuit board
Peripheral
Integrated circuit
Very-large-scale integration
System on a chip (SoC)
Energy consumption (green computing)
Electronic design automation
Hardware acceleration
Processor
Size / Form
Computer systems organization
Computer architecture
Computational complexity
Dependability
Embedded system
Real-time computing
Cyber-physical system
Fault tolerance
Wireless sensor network
Networks
Network architecture
Network protocol
Network components
Network scheduler
Network performance evaluation
Network service
Software organization
Interpreter
Middleware
Virtual machine
Operating system
Software quality
Software notations and tools
Programming paradigm
Programming language
Compiler
Domain-specific language
Modeling language
Software framework
Integrated development environment
Software configuration management
Software library
Software repository
Software development
Control flow
Software development process
Requirements analysis
Software design
Software construction
Software deployment
Software engineering
Software maintenance
Programming team
Open-source model
Theory of computation
Model of computation
Stochastic
Formal language
Automata theory
Computability theory
Computational complexity theory
Logic
Semantics
Algorithms
Algorithm design
Analysis of algorithms
Algorithmic efficiency
Randomized algorithm
Computational geometry
Mathematics of computing
Discrete mathematics
Probability
Statistics
Mathematical software
Information theory
Mathematical analysis
Numerical analysis
Theoretical computer science
Computational problem
Information systems
Database management system
Information storage systems
Enterprise information system
Social information systems
Geographic information system
Decision support system
Process control system
Multimedia information system
Data mining
Digital library
Computing platform
Digital marketing
World Wide Web
Information retrieval
Security
Cryptography
Formal methods
Security hacker
Security services
Intrusion detection system
Hardware security
Network security
Information security
Application security
Human-centered computing
Interaction design
Augmented reality
Virtual reality
Social computing
Ubiquitous computing
Visualization
Accessibility
Human–computer interaction
Mobile computing
Concurrency
Concurrent computing
Parallel computing
Distributed computing
Multithreading
Multiprocessing
Artificial intelligence
Computational intelligence
Natural language processing
Knowledge representation and reasoning
Computer vision
Automated planning and scheduling
Search methodology
Control method
Philosophy of artificial intelligence
Distributed artificial intelligence
Machine learning
Supervised learning
Unsupervised learning
Reinforcement learning
Multi-task learning
Cross-validation
Graphics
Animation
Rendering
Photograph manipulation
Graphics processing unit
Image compression
Solid modeling
Applied computing
Quantum computing
E-commerce
Enterprise software
Computational mathematics
Computational physics
Computational chemistry
Computational biology
Computational social science
Computational engineering
Differentiable computing
Computational healthcare
Digital art
Electronic publishing
Cyberwarfare
Electronic voting
Video games
Word processing
Operations research
Educational technology
Document management
Specialized Platform Development
Thermodynamic computing
Category
Outline
Glossaries
show
v
t
e
Wikipedia outlines
General reference
Culture and the arts
Geography and places
Health and fitness
History and events
Mathematics and logic
Natural and physical sciences
People and self
Philosophy and thinking
Religion and belief systems
Society and social sciences
Technology and applied sciences 
Retrieved from " https://en.wikipedia.org/w/index.php?title=Outline_of_computer_science&oldid=1336461923"
Categories:
Outlines of computing and engineering
Outlines
Computer science
Computing-related lists
Hidden categories:
Articles with short description
Short description is different from Wikidata
Pages using Sister project links with default search
This page was last edited on 3 February 2026, at 23:04 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policy
About Wikipedia
Disclaimers
Contact Wikipedia
Legal & safety contacts
Code of Conduct
Developers
Statistics
Cookie statement
Mobile view
Search
Search [-]
Toggle the table of contents
Outline of computer science
4 languages Add topic 