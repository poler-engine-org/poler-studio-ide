> Source: https://www.reddit.com/r/rust/comments/16laxhi/on_the_state_of_sparse_matrix_computation/

On the state of sparse matrix computation : r/rust
Skip to main content On the state of sparse matrix computation : r/rust
Open menu
Open navigation 
Go to Reddit Home 
r/rust
TRENDING TODAY
Get App
Get the Reddit app
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Navigation Skip to Right Sidebar
Back
 Go to rust
r/rust
• 2y ago
camilo16
Locked post
Stickied post
Archived post
View post in other languages
Report
On the state of sparse matrix computation
This is a short post to indicate the current state of things in rust and hopefully motivate the community to improve things. As of the moment of writing sparse matrices and thus scientific computing in general is quite poor in rust, from my search these are the linear algebra crates:
Nalgebra: Supports sparse matrices but has no solvers, making the matrices have little utility.
sprs: Supports sparse matrices, has nice utilities for constructing them, iterating over the entries and other nice to haves. Only supports LDL decomposition so it cannot be used for non-symmetric problems.
rsparse: Supports sparse matrices, supports multiple solvers including LU. Does not support iterating over the entries of a matrix, does not support sparse vectors, and has in gneral a very poorly designed API, for example matrices are initialised from a vector of vectors instead of a single dimensional vector with an indicator for row or column major order. No support for scalars other than f64.
faer: No support for sparse matrices.
It is a little sad for this to be the case, you can technically achieve anything with rust at the moment, but you will need to combine multiple crates and add the overhead for the glue code. It is particularly sad that sprs and rsparse are borderline good enough but have disjoint features such that if the crate were merged it would yield a perfectly usable library.
Hopefully this will not be the state of things in a couple of years.
Read more
50
· 8
Comments Section
reflexpr-sarah-
•
2y ago
faer author here, sparse matrix algorithms are not nearly as well documented as dense matrix ones, and unfortunately many of the implementation tricks to speed them up are proprietary. i plan to eventually support them in some way but this will take a lot of time and effort if we want to have something competitive with the state of the art solvers
31
ibkvictor
•
22d ago
Hi Sarah,
I love what you are doing with Faer. I would love to contribute. Would love to chat sometime about this?
-Victor.
1
Continue this thread 
lebensterben
•
2y ago
peroxide also has some level of sparse matrix support
https://github.com/axect/peroxide/blob/377dc967344fc16febe7b3cbcbcbb3d50ad96117/src/structure/sparse.rs
5 
[deleted]
•
2y ago
I feel like scientific computation in Rust has structural issues to fight with. There's no central crate of scientific traits, like abstract N-d-arrays. In Python Numpy essentially takes over that role. Anyone writing scientific compute systems makes them compatible with Numpy. But this is imperfect, since np.ndarray is a concrete type, and thus incures runtime overhead.
Julia fixes that by providing the AbstractArray type as part of the standard library. Any algorithms author can make their implementation work with it and they will know their algorithm will be usable in most projects. OTOH, anyone can implement data structrues that conform to the AbstractArray interface. That way if you come up with a new magical way of storing data, it can immediately be used by the whole ecosystem.
8 
camilo16
OP
• 2y ago
you can just make an implementation that does not rely on a lingua franca like that. Eigen in C++ is perfectly usable without having an ndarray equivalent.
2 
nablachez
•
2y ago
How feasible would it be to have C++->Rust bindings for Eigen?
2 
rikus671
•
2y ago
Eigen is heavily templated, and not just for generics. It uses expression templates. I'm not aware of any interop that would be able to make Eigen in Rust anywhere near Eigen in C++ in term of flexibility and abstraction.
I'd love to be proven wrong though
Maybe redesigning the interfaces for Rust, but using Eigen under-the-hood would be easier....
5
Related Answers Section
Related Answers
Best practices for Rust error handling
Rust's error handling is a powerful and flexible system, but it can also be complex and challenging to master. Here are some best practices and insights from the Rust community to help you handle errors effectively in your projects:
General Principles
Design Errors Thoughtfully: Instead of simply forwarding errors, design them to provide meaningful context and actionable information. "I actually don't like it when string interpolation is used errors. It feels messy. I wish there was something like tracing::event! where you can add items that are relevant to the context in a more natural way, without having to shove them into a string."
Balance Granularity: Aim for the right level of granularity in your error types. Too many specific error types can be cumbersome, while too few may not provide enough detail. "I like bevy's granularity of errors: there's not really a god error enum, but rather multiple error enums for each related set of functions/methods."
Use Structured Errors: Structured errors can make debugging and handling errors much easier by providing detailed context. "The biggest change I made was leveraging the type system to guarantee things I rely on wherever possible."
Popular Crates for Error Handling
anyhow : Ideal for application-level error handling where you don't need to branch based on the error type. "Anyhow for errors where you don't need to branch based on cause, thiserr for when you want to handle different errors in different ways or want to expose different types of errors like in a crate."
thiserror : Best for library-level error handling where you need to define specific error types. "Write 1 error enum either for each crate or each module depending on the size of the crate. Use thiserror and the #[from] macro to seamlessly package up foreign errors."
snafu : Offers a balance between anyhow and thiserror with flexible error types and context attachment. "Snafu has a best of both worlds (anyhow/thiserror) type approach, Whatever for stringly typed errors with an easy migration path onto more concrete error types."
error-stack : Provides a way to attach custom context and track call stacks. "Error stack takes all the pain out of working with errors."
Combining anyhow and thiserror
Mixed Approach: Use thiserror for defining specific error types in libraries and anyhow for general error handling in applications. "The most common approach seems to be anyhow for binaries and enums with thiserror for libraries."
Hybrid Error Types: Combine thiserror with anyhow to create comprehensive error types. "I've found a good balance for error handling in that I always combine anyhow and thiserror ."
Handling Specific Scenarios
IO Errors: Use crates like fs-err to provide more detailed context for IO errors. "For that I use https://github.com/andrewhickman/fs-err."
Custom Context: Attach additional information to errors using traits or custom error types. "From a developer point of view, it can take any Error or Response type and do this: call_something_that_might_error().amend(|e| e.add_context(\"during xyz operation\").set_code('E832'))?; "
Design by Contract
Preconditions and Postconditions: Use design by contract to define clear preconditions and postconditions for functions, which can help in designing robust error handling. "We can't talk about errors without talking about contracts (Design by Contract discipline)."
Additional Tips
Avoid String Interpolation in Errors: Use structured logging or tracing to add context to errors instead of embedding it directly in the error message. "I actually don't like it when string interpolation is used errors. It feels messy."
Consider Retriability: Design errors to indicate whether an operation is retriable, which can be useful for higher-level error handling. "I find the embedding retriability in the error questionable."
Use #[non_exhaustive] for Public Enums: This can help maintain compatibility when adding new error variants. "Clippy recommends publicly exported enums to be annotated with #[non_exhaustive] for basically the same reason."
By following these best practices and utilizing the rich ecosystem of Rust error handling crates, you can write more robust and maintainable code.
Rust Programming Communities
<>{"c":[{"e":"ra:subreddit","id":"t5_2s7lj"},{"e":"ra:subreddit","id":"t5_3amtr"},{"e":"ra:subreddit","id":"t5_32iyy"},{"e":"ra:subreddit","id":"t5_2xks2"},{"e":"ra:subreddit","id":"t5_2xks8"},{"e":"ra:subreddit","id":"t5_39apg"}],"content_type":"subreddit","e":"ra:grid"}<>
See Answer
How to optimize Rust code performance
Common pitfalls for Rust beginners
Top libraries for Rust development
Rust vs Go: performance comparison
New to Reddit?
Create your account and connect with a world of communities.
Continue with Email
Continue With Phone Number
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy.
More posts you may like
What do you use a "sparse matrix" for? r/learnprogramming • 2y ago [
What do you use a "sparse matrix" for?
](https://www.reddit.com/r/learnprogramming/comments/1d6n6os/what_do_you_use_a_sparse_matrix_for/) 6 upvotes · 15 comments
faer 0.19 release, a general purpose (dense/sparse) linear algebra library  r/rust • 2y ago [
faer 0.19 release, a general purpose (dense/sparse) linear algebra library
](https://www.reddit.com/r/rust/comments/1d1sfhj/faer_019_release_a_general_purpose_densesparse/)  github 130 upvotes · 5 comments
sprs, a sparse matrix library  r/rust • 11y ago [
sprs, a sparse matrix library
](https://www.reddit.com/r/rust/comments/3kd3bz/sprs_a_sparse_matrix_library/) 35 upvotes · 5 comments
Any tools to solve sparse matrices?  r/rust • 2y ago [
Any tools to solve sparse matrices?
](https://www.reddit.com/r/rust/comments/1ea85op/any_tools_to_solve_sparse_matrices/) 10 upvotes · 13 comments
What are Sparse Matrices and what are the operations that can be performed on them?  r/askscience • 13y ago [
What are Sparse Matrices and what are the operations that can be performed on them?
](https://www.reddit.com/r/askscience/comments/1pbjay/what_are_sparse_matrices_and_what_are_the/) 18 upvotes · 8 comments
faer 0.16 release, a general purpose (dense/sparse) linear algebra library  r/rust • 2y ago [
faer 0.16 release, a general purpose (dense/sparse) linear algebra library
](https://www.reddit.com/r/rust/comments/18di11g/faer_016_release_a_general_purpose_densesparse/)  github 75 upvotes · 10 comments
Best rust crate for sparse matrices?  r/rust • 2y ago [
Best rust crate for sparse matrices?
](https://www.reddit.com/r/rust/comments/1ck8vqb/best_rust_crate_for_sparse_matrices/) 19 upvotes · 3 comments
05 Matrix rust (is this bad? Or normal - Northeast USA)  r/Toyota • 2y ago [
05 Matrix rust (is this bad? Or normal - Northeast USA)
](https://www.reddit.com/r/Toyota/comments/1dt3q8x/05_matrix_rust_is_this_bad_or_normal_northeast_usa/)  2 upvotes · 12 comments
Matrix 2.0 — Matthew Hodgson talks about Rust in Element client, Rust SDK, IETF MLS, MIMI and more  r/rust • 3y ago [
Matrix 2.0 — Matthew Hodgson talks about Rust in Element client, Rust SDK, IETF MLS, MIMI and more
](https://www.reddit.com/r/rust/comments/10w4fo2/matrix_20_matthew_hodgson_talks_about_rust_in/) 89 upvotes · 6 comments
New matrix server written in Rust  r/rust • 3mo ago [
New matrix server written in Rust
](https://www.reddit.com/r/rust/comments/1pd49uf/new_matrix_server_written_in_rust/) 38 upvotes · 18 comments
Rust matrix structure  r/rust • 6y ago [
Rust matrix structure
](https://www.reddit.com/r/rust/comments/icpdvh/rust_matrix_structure/) 4 upvotes · 8 comments
why are there so many linear algebra crates? Which one is "best"?  r/rust • 9y ago [
why are there so many linear algebra crates? Which one is "best"?
](https://www.reddit.com/r/rust/comments/63wts9/why_are_there_so_many_linear_algebra_crates_which/) 52 upvotes · 46 comments
a simple matrix library for rust[my first rust library]  r/rust • 12y ago [
a simple matrix library for rust[my first rust library]
](https://www.reddit.com/r/rust/comments/28dnao/a_simple_matrix_library_for_rustmy_first_rust/)  github 10 upvotes · 11 comments
Bidirectional Computation using Lazy Evaluation  r/ProgrammingLanguages • 9d ago [
Bidirectional Computation using Lazy Evaluation
](https://www.reddit.com/r/ProgrammingLanguages/comments/1r7fq33/bidirectional_computation_using_lazy_evaluation/) 33 upvotes · 6 comments
Linear Algebra in Rust  r/rust • 2y ago [
Linear Algebra in Rust
](https://www.reddit.com/r/rust/comments/1cwf572/linear_algebra_in_rust/) 22 upvotes · 12 comments
The unreasonable effectiveness of modern sort algorithms  r/rust • 6mo ago [
The unreasonable effectiveness of modern sort algorithms
](https://www.reddit.com/r/rust/comments/1ncidv0/the_unreasonable_effectiveness_of_modern_sort/)  github 294 upvotes · 16 comments
Does 'static mean the data lived forever?  r/rust • 4mo ago [
Does 'static mean the data lived forever?
](https://www.reddit.com/r/rust/comments/1om6gv1/does_static_mean_the_data_lived_forever/) 109 upvotes · 110 comments
One of the most annoying programming challenges I've ever faced  r/rust • 10d ago [
One of the most annoying programming challenges I've ever faced
](https://www.reddit.com/r/rust/comments/1r6gz0z/one_of_the_most_annoying_programming_challenges/)  sniffnet 92 upvotes · 19 comments
Improving state machine code generation  r/rust • 6mo ago [
Improving state machine code generation
](https://www.reddit.com/r/rust/comments/1nd9i3k/improving_state_machine_code_generation/)  trifectatech 107 upvotes · 22 comments
The Incredible Growth of Rust - The Growth-Share Matrix of Software Development  r/rust • 7y ago [
The Incredible Growth of Rust - The Growth-Share Matrix of Software Development
](https://www.reddit.com/r/rust/comments/a9jzjv/the_incredible_growth_of_rust_the_growthshare/)  whoisnnamdi 62 upvotes · 23 comments
Recommendation for Linear Algebra Crate  r/rust • 8y ago [
Recommendation for Linear Algebra Crate
](https://www.reddit.com/r/rust/comments/7f2lq7/recommendation_for_linear_algebra_crate/) 12 upvotes · 5 comments
Does Syntax Matter?  r/ProgrammingLanguages • 4d ago [
Does Syntax Matter?
](https://www.reddit.com/r/ProgrammingLanguages/comments/1rbhqvo/does_syntax_matter/) 58 upvotes · 97 comments
Best way to get comfortable with Rust in 3 months? (moving from Python and Java)  r/rust • 1mo ago [
Best way to get comfortable with Rust in 3 months? (moving from Python and Java)
](https://www.reddit.com/r/rust/comments/1qphy6n/best_way_to_get_comfortable_with_rust_in_3_months/) 4 upvotes · 21 comments
[Media] Introducing Matrix Support in Wrkflw - Run Your GitHub Actions Workflows Locally!  r/rust • 1y ago [
[Media] Introducing Matrix Support in Wrkflw - Run Your GitHub Actions Workflows Locally!
](https://www.reddit.com/r/rust/comments/1jywryh/media_introducing_matrix_support_in_wrkflw_run/)  15 upvotes · 3 comments
"AI is going to replace software developers" they say  r/rust • 1y ago [
"AI is going to replace software developers" they say
](https://www.reddit.com/r/rust/comments/1jworgh/ai_is_going_to_replace_software_developers_they/) 429 upvotes · 254 comments
View Post in
日本語
简体中文
Community Info Section
r/rust
Join
The Rust Programming Language
A place for all things related to the Rust programming language—an open-source systems language that emphasizes performance, reliability, and productivity.
Show more
Public
Anyone can view, post, and comment to this community
Top Posts
Reddit reReddit: Top posts of September 17, 2023
Reddit reReddit: Top posts of September 2023
Reddit reReddit: Top posts of 2023
Reddit Rules Privacy Policy User Agreement Your Privacy Choices Accessibility Reddit, Inc. © 2026. All rights reserved.
Expand Navigation
Expand Navigation
Collapse Navigation
Collapse Navigation 
0cAFcWeA6I-Bfvq9jr0ccB2svyLjDT_-0YdcgOdnNB89HjV4GOUve2F9AmwliC8Eqxd6-_Zoxauv26wj8ybFnNf_rR7uvuqN6BVvAfqGBSyhrYIbcdQYzexrP_1kIbs88uBMy8mWjpFTiZiGh5qnQel9whnk8e5WBDl0pEgpQKSY_QsG2Ateld4a-9isp9d7v8tB_NTGCZ3B-rQyEeXTFe5waPA_ym6UFbQFcDOQPJWzHFUyINtH8e9vs52J6hXsqbQsfTlZD4cyger_J2m9eCH0BnfzQNZittxAgFIUuEZAur5CN99pQt45MYcGaSselc0rGw_mCrJYV_aXWThgBYh9znOUn3MgaQwW5smDRmHMoKYIKyZcW1cwIJFgkPXWOUGQIHU5Xit7sMTc-x5A3ZdCMIQqmocVNDU9fiCvZHCZwD3Qk8GdtwyY3tm4ykflPeVk_ANgUOJ2Txc_GIPUDRcAoPUg8G_zR0Ag9b2jcGkrr0SkEDCQo1gj_2VQNYNPjXp7nnToGESriS841CqVGyKDk0sH0wmXcQplLItqKgIqxVLjv2DHhvSueLjgFKHReAV8tp13-o4rQ3-YuB-omRUikmnc0EGlMDIgich2Z59oFW27q6hLAAmgpgclwtjVMORbmjfEsZHZgCfiJPJY31TFUOHpurdyYhnMJuFt4woU76vsLjO04Aa7dK8BB1VRLtUgHfr81cXs_9d-spsiswrzWGFfgz1WEj031SLmDhmxw9o9MwKYJFxHuKU8i9rmPw_HmIuK2w7jI5xYeydgGxZsBLRIahjaNBdJ9E2VOzUW9C2cARd5Wi0y7iE4C6bNO0I4ovzNL8hazqyaxd2QDxRTEShTHab03Fl8eqMh99AWASAmVBw2pH7pfU9MhpuxI9zdjEe3GrxV9YriYgbNPZbuEPToYq7P0uSY_U0DwWwelZWV0Sq26y0SB5014n7LpF2_uCi6Znd1qEzE2RSf1ok_NwGl-6jltn9ABwLVG3LxejXu0GbzHHtHzOpKteQweEYDPDlS0BpZRM5mZx1ZFXzSj1h9_s0gZTiDInYu7TiD8g0VwrI5DQAA92yujzeXTzNzfXijhJXyvlCqQ01CNYNBpkuh1YUOd8G1Jcz1CyBibrTsW6Sb4SgKCCI49q_hx_BR851bFaj3Zru1n1qhiXzKapG1VeQaIfTq2q6ZwyfqnFJByAIby4dOd0ms2mwPBHeEDY4viIJzzidT-cansu3xIKx2UJ16qp0pPaslau4_SXx7CJW-_dzL0nHFmdDxEMlta_3QtS6Mi5B8p_moqlPhmcVjLYGLdZzNA1jTFv-ilcnXM6M5K2booPzm1yHgXmMmaK6eosBg3QJVlV70qqsk6dFq-yE5acIfdfIokMNl_7kyFvfLlujOsHrCxIuvWLAlX5XQIT9OD0UVKbn36Nrmgn5E2bur39Y4b_x__rt3nXAmOmMpsiqVI2Ntsu5v1APCUeTkN4JZ_i0IPiV1RFbxnNQ3ZURvj7pi16r0WR9A7TKyFqUzJPsuBfbpmviS3i1VLXIbFMVyTLcc9BVlLEb064DFa90qcvfZqjlkvu83cC4gMyVq72jaY9wYtGbL3lw44ApZnMOMfHbFPl6UN1RqaU3pUQhayNXP_yGBfv8VIru4H-IeXdcyzIqhQLyyE5Mdrk-HxZzAv1XgyV396_RSe8weAjYX4w7Frl0-PKHTNbn1rXGv803WgtGgzZq5gmL0HdZ6Q15zYcgxA1n8_UZN2hcpDGMk-3RxaPtBl8pmeiBPo5gBBk8xUFStGZFXay5eH7oNwOF4zMo5xPEud0l4uQvP5-e1Kb7aukj_AKJBYzptsSL8vUs3bJHkAe6buSF0VVhV1HBQKd6h495-XiV_WxTYZcuTPdwBks1-I_dGF8paNgMf7JBffKu1zU_Ej-GLoPi6_vYEG36N1xexapbXp5nJQSbDe57-W4EA8wYUvFvQ-orXCZhsWn4hBQBYpZLHDCPrITZlS0_AGNp_toHpQ_Ts2RwMsdTW5YcSPvEG30fWrWQ2rNAAJinYjKYJRNxjNv09Z3MK_jVvKGx-WhnSUZry1Ar4kxTCdtuIUuyKqJMPXtzhRens6cwZkmzyu0caolpMlAkBbnrHDjBqZ0tq9x2cQSCLhNGbLLhB35zOUJSVs5TGaWJswOZtkdis4USqkRf_PtRGesGq74LkdSdJA6VbXnFFMwlRVoYK9yCnonzpQ0wjliprc