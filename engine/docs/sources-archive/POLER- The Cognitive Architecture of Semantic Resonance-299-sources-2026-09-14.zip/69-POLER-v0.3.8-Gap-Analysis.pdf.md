POLER v0.3.8: Engineering Gap Analysis 
From 64-bit Calibration to libcint Rewriting Date: 2026-06-06 | Source: POLER-v0.3.8-fixed-source.md + main.rs (2731 lines) 
1. The Critical Finding: 64-bit "Breakthrough" is Trial Division 
The v0.3.8 document reports that the 64-bit hard semiprime N = 10376293567231426567 = 3221225473 x 3221225479 is solved in 3.0 seconds. However, a careful reading of the source code reveals that this result is produced entirely by trial division, not by the POLER breathing engine. The key code path in factor_number() (line 2427-2434) computes sqrt_n = (n as f64).sqrt() as u64 + 1 and then calls trial_divide(n, sqrt_n). Since both factors are less than sqrt(N), trial division finds them by brute-force iteration up to 3.2 billion. The POLER breathing solver is never invoked for this case because trial division succeeds first. 
This is not a criticism of the pragmatic fix, which is valid and useful. Raising the trial division limit from 224 to sqrt(N) correctly handles all semiprimes where one factor is below 232. The 3-second runtime is acceptable for a one-time computation. However, the engineering implications are significant: the POLER breathing engine itself has never been validated on 64-bit hard semiprimes. It was TIMEOUT in v0.3.7 and remains TIMEOUT in v0.3.8 if trial division is bypassed. The "breakthrough" belongs to classical number theory, not to the continuous topology solver. 
Bit Width Method That Solves POLER Breathing Status Time 
8-bit (143) Trial division Works (overkill) 0 us 
33-bit (4294967297) Trial division Works 1 us 
49-bit Trial division Works (31.6s) 15.8 ms 
64-bit (hard semiprime) Trial division TIMEOUT 
(unvalidated) 3.0 s 
Table 1: Actual solving method by bit width. POLER breathing has never solved a 64-bit hard semiprime.
2. The "Zero-Allocation" Claim: Partially True 
Version 0.3.8 introduced WorkBuffers and forward_pass_into(), which genuinely eliminate heap allocations during the forward pass. However, the gradient computation path still allocates heavily, and several other hot-path operations create new Vec objects on every iteration. Below is a line-by-line audit of every allocation in the hot loop of run_branch(). 
Location Code Allocs/Breat h Severity 
Line 1958 vec![0.0; npq] 1 LOW 
Lines 1961-62 pq.to_vec() x2 x npq 2 x npq CRITICAL 
Line 1201 vec![0.0; npq] resonance 1 MEDIUM 
Line 1206 vec![vec![0.0; npq]; npq] npq+1 CRITICAL 
Line 1255 pq.clone() 1 MEDIUM 
Line 1257 pq_history.push(pq.clone()) 1 MEDIUM 
Lines 777,829,838 analytical gradient vecs 3 HIGH 
(broken) Table 2: Heap allocation audit in run_branch() hot loop. For npq=66 (64-bit), total allocations 
per breath = 2x66+66+1+1+3 = ~200. At 200K breaths = 40M allocations. 
For 64-bit semiprimes where npq=66, the numerical gradient path alone creates 2x66 = 132 heap allocations per gradient call (lines 1961-1962). The resonance matrix creates npq+1 = 67 allocations. Over 200,000 breath iterations, this amounts to approximately 40 million heap allocations. On modern hardware, each allocation costs 20-50 nanoseconds, totaling 0.8-2.0 seconds of pure allocation overhead. For the libcint target of >1000 variables, npq would be 1000+, making the resonance matrix alone create 1,001,001 allocations per breath, which is completely unsustainable. 
3. Analytical Gradient: Broken and Disabled 
The verify_gradient() diagnostic confirms that the analytical gradient matches the numerical gradient sign in only 40% of cases. This is worse than random guessing (50%), meaning the analytical gradient actively points the optimizer in the wrong direction 60% of the time. The solver therefore falls back to the numerical gradient, which requires 2 x npq forward passes per call. For npq=66, this means 132 forward passes per breath, and for npq=1000 (libcint scale), it would mean
2000 forward passes per breath, which is computationally prohibitive. 
The root cause of the gradient bug appears to be a combination of three issues. First, the backward pass does not properly block gradient flow through fixed variable positions. When a variable is fixed (set to a known N-bit value), gradient should not propagate through it, but the current implementation does not enforce this constraint. Second, the alpha parameter in binary regularization switches discontinuously between 0.5, 2.0, and 10.0 based on energy level, creating gradient discontinuities that the analytical pass does not handle. Third, some carry propagation paths in the backward pass may be incomplete, especially at boundaries between full-adder and half-adder regions of the multiplication circuit. 
For libcint rewriting, a working analytical gradient is essential. The ERI constraint system will have thousands of variables, and numerical gradient (2n forward passes) becomes impossible. The fix requires a line-by-line audit of the backward pass against the forward pass operations, plus proper handling of the fixed-variable gradient blocking and alpha discontinuity. Until this is fixed, POLER cannot scale beyond toy problems. 
4. The Architectural Gap: From Multiplication Circuits to ERI Constraints 
The current POLER engine is built entirely around binary multiplication circuits. The topology builder constructs AND gates, XOR gates, full-adders, and half-adders that encode the relationship p x q = N in continuous form. The gate polynomial constraints (AND(a,b) = a*b - c, XOR(a,b) = a+b-2ab-c, FA_SUM, FA_CARRY) are the only constraint types the solver understands. The PhaseGrid, resonance matrix, breathing mechanics, and V_ZERO protocol are all designed around this specific constraint topology. 
The Electron Repulsion Integral (ERI) computation in libcint has a fundamentally different constraint structure. An ERI involves four Gaussian basis functions (a,b,c,d) with angular momentum quantum numbers (l_a, l_b, l_c, l_d). The Obara-Saika recursion reduces a (l_a, l_b, l_c, l_d) integral to (l_a-1, l_b, l_c, l_d) and (l_a, l_b-1, l_c, l_d) integrals through a set of recurrence relations involving boy function values, Gaussian exponents, and center-of-charge coordinates. The McMurchie-Davidson recursion uses Hermite Gaussian expansion coefficients. These are not binary logic gates, they are continuous algebraic relationships with fundamentally different Jacobian structures. 
Dimension Current POLER (v0.3.8) Required for libcint
Constraint type AND, XOR, FA, HA gates (binary logic) 
OS/MD recursions, Gaussian contractions (continuous algebra) 
Variable count npq <= 66 (64-bit factorization) 1000+ (molecular simulation) 
Topology builder 
FactorizationTopology::build(nb p, nbq) - ripple-carry multiplier 
ERITopology::build(L_a, L_b, L_c, L_d, basis_set) - recursion tree 
Jacobian structure 
Sparse, block-diagonal (gate-local) 
Dense, recursive (contraction cascades) 
Fixed variables N-bit output (target number) Gaussian exponents, coordinates, angular momenta 
Gradient method Numerical (broken analytical) Analytical (essential for scale) 
Search space {0,1}npq (binary SAT) Continuous (no binary rounding needed) 
Output Factor values (p, q) Optimal computation graph (AST) 
Table 3: Architectural gap between current POLER and libcint rewriting requirements. 
5. What v0.3.8 Actually Proved (The Real Achievements) 
Despite the gaps identified above, v0.3.8 represents genuine and important progress. The achievements are real, they just need to be correctly attributed to understand what work remains. The following capabilities have been demonstrated: 
Zero-allocation forward pass. The forward_pass_into() function correctly uses pre-allocated WorkBuffers to eliminate heap allocations during the most frequently called operation. This proves the Arena Allocator pattern works in Rust and can be extended to the gradient path and resonance computation. The architecture of WorkBuffers is sound; it just needs to be completed for the remaining hot-path allocations. 
Breathing mechanics infrastructure. The BreathingCycle, BreathEntropy, PhaseGrid, and V_ZERO protocol form a coherent framework for managing stochastic search with adaptive temperature, phase locking, and anomaly detection. This infrastructure is domain-agnostic and can be repurposed for ERI constraints without fundamental redesign. The breathing fingerprint (mu=1079, sigma=20, CV=0.018832) provides a stable calibration baseline. 
Multi-branch parallel search. The PoleRnMetaEngine with Rayon-parallel branches, temperature bands (cold/warm/hot), and global best-energy sharing via AtomicU64 demonstrates a scalable parallel search architecture. The early-stop
mechanism (AtomicBool) prevents wasted computation once a solution is found. This architecture maps well to ERI optimization where multiple contraction orderings must be explored. 
Gradient verification diagnostic. The verify_gradient() function is a critical engineering tool. Without it, the broken analytical gradient would have gone undetected. The 40% sign match provides a quantitative baseline against which fixes can be measured. The target is 95%+ sign match before enabling analytical gradient in production. 
6. Roadmap: From v0.3.8 to libcint Rewriting 
The path from the current v0.3.8 to a tool capable of rewriting libcint requires work in three phases. Phase 1 fixes the existing engine so that it works correctly on its current domain (factorization). Phase 2 generalizes the constraint system so it can represent ERI recursions. Phase 3 builds the libcint-specific topology and code generation pipeline. 
Phase 1: Fix the Engine (v0.3.9) 
Task Description Impact Effort 
Fix analytical gradient 
Audit backward pass line-by-line. Block gradient at fixed vars. Handle alpha discontinuity. 
CRITICAL 2-3 days 
Eliminate gradient allocations 
Extend WorkBuffers for pq_plus/pq_minus. Remove pq.to_vec() from hot loop. 
HIGH 1 day 
Eliminate resonance allocations 
Pre-allocate resonance matrix in WorkBuffers. Use flat npq x npq array. 
HIGH 1 day 
Validate on 64-bit (POLER) 
Bypass trial division for one test. Confirm breathing engine converges within budget. 
HIGH 0.5 day 
Table 4: Phase 1 tasks. Total estimated effort: 4-5 days. 
Phase 2: Generalize the Constraint System (v0.4.0) The current PolynomialConstraint struct is hardwired to gate operations (AND, XOR, FA). Phase 2 replaces it with a generic constraint system where each constraint is defined by an arbitrary function f(x) = 0 and its Jacobian. This is not a minor refactor; it requires redesigning the topology builder to accept ERI-specific constraints such as Obara-Saika horizontal recurrence relations,
vertical recurrence relations, and Gaussian product theorem contractions. The key insight is that the breathing engine (dissipator D, resonance J, V_ZERO) is constraint-agnostic, so the core optimization loop can remain unchanged while the constraint encoding is replaced. 
A minimal ERI constraint set for (ss|ss) type integrals (all angular momenta = 0) would demonstrate the feasibility of this approach. The (ss|ss) integral has a closed-form solution involving only Gaussian exponents and inter-center distances, making it an ideal calibration target. Once (ss|ss) works, the horizontal and vertical recursions for (ps|ss), (pp|ss), and (pp|pp) integrals can be added incrementally. 
Phase 3: libcint Rewriting Pipeline (v0.5.0) Phase 3 builds the actual meta-compiler. The POLER breathing engine optimizes ERI computation graphs, finding the shortest path through the recursive decomposition. The result is not a numerical integral value, but a crystallized computation graph (AST) that represents the optimal sequence of operations. This AST is then emitted as Rust procedural macros (generate_os_eri_unrolled!) that expand at compile time into monolithic, allocation-free computation kernels. The key architectural decision is the hybrid dispatch: s,p,d shells use unrolled Obara-Saika with SIMD, f,g shells use McMurchie-Davidson with dense matrix operations via faer::Mat::mul, and l >= 5 shells use Rys quadrature with precomputed static tables. 
7. Engineering Verdict 
The direct answer to the question "Is v0.3.8 at the level we need?" is: no, it is not. The 64-bit breakthrough is from trial division, not from the POLER breathing engine. The breathing engine has never been validated on 64-bit hard semiprimes, the analytical gradient is broken (40% sign match), the gradient path still allocates heavily, and the constraint system only understands binary multiplication circuits. For the libcint rewriting goal, every one of these gaps must be closed. 
However, the v0.3.8 architecture is sound and extensible. The breathing mechanics (BreathCycle, PhaseGrid, V_ZERO), the parallel search engine (PoleRnMetaEngine, Rayon), and the WorkBuffers pattern are all reusable. The gap is not architectural; it is engineering. The constraint system needs to be generalized, the gradient needs to be fixed, and the allocations need to be eliminated. None of these require a fundamental redesign of the breathing engine, which is the core intellectual contribution of POLER.
Verdict: 64-bit trial division = calibration milestone, not engine validation. POLER breathing engine itself remains unproven on hard problems. For libcint rewriting, minimum requirements are: (1) fixed analytical gradient with 95%+ sign match, (2) truly zero-allocation hot path, (3) generic constraint system supporting ERI recursions, (4) ERI topology builder. Estimated effort: Phase 1 (5 days) + Phase 2 (2-3 weeks) + Phase 3 (4-6 weeks) = 7-10 weeks total. 
What v0.3.8 got right: WorkBuffers architecture (proven pattern for zero-alloc), breathing infrastructure (domain-agnostic), parallel search (Rayon), gradient verification diagnostic (critical for debugging), pragmatic trial division fix (solves 64-bit instantly). These are real engineering achievements that form the foundation for the next phase.