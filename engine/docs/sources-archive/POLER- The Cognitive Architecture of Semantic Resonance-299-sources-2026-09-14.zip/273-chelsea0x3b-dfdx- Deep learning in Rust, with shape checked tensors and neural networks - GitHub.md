> Source: https://github.com/chelsea0x3b/dfdx

GitHub - chelsea0x3b/dfdx: Deep learning in Rust, with shape checked tensors and neural networks
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
chelsea0x3b / dfdx Public
Sponsor
Sponsor chelsea0x3b/dfdx
External links
 patreon.com/ dfdx ko-fi.com/ coreylowman Learn more about funding links in repositories. Report abuse
Notifications You must be signed in to change notification settings
Fork 105
Star 1.9k
Deep learning in Rust, with shape checked tensors and neural networks
License
View license
1.9k stars 105 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 68
Pull requests 22
Actions
Projects 0
Wiki
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Wiki
Security
Insights
chelsea0x3b/dfdx
main
5 Branches 15 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
License
dfdx: shape checked deep learning in rust
 
Ergonomics & safety focused deep learning in Rust.
Still in pre-alpha state. The next few releases are planned to be breaking releases.
Features at a glance:
🔥 GPU accelerated tensor library with shapes up to 6d!
Shapes with both compile and runtime sized dimensions. (e.g. Tensor<(usize, Const<10>)> and Tensor<Rank2<5, 10>> )
A large library of tensor operations (including matmul , conv2d , and much more).
All tensor operations shape and type checked at compile time!!
Ergonomic neural network building blocks (like Linear , Conv2D , and Transformer ).
Standard deep learning optimizers such as Sgd , Adam , AdamW , RMSprop , and more. dfdx is on crates.io! Use by adding this to your Cargo.toml :
See the documentation at docs.rs/dfdx.
[1] https://en.wikipedia.org/wiki/Automatic_differentiation#Reverse_accumulation
Design Goals
Ergonomics the whole way down (both frontend interface & internals).
Check as much at compile time as possible (i.e. don't compile if something is not correct).
Maximize performance.
Minimize unsafe code[1]
Minimize Rc used in internal code[2]
[1] Currently the only unsafe calls are for matrix multiplication.
[2] The only things that use Arc are tensors to store their data. Arc is used instead of Box to reduce allocations when tensors are cloned.
GPU acceleration with CUDA
Enable the cuda feature to start using the Cuda device! Requires the installation of nvidia's cuda toolkit. See feature flags docs for more info.
API Preview
Check examples/ for more details.
👌 Simple Neural Networks API, completely shape checked at compile time.
📈 Ergonomic Optimizer API
💡 Const tensors can be converted to and from normal rust arrays
Fun/notable implementation details
Module
From this flexible trait we get:
Single & batched inputs (just have multiple impls!)
Multiple inputs/outputs (multi-headed modules, or rnns)
Behavior different when tape is present or not ( not the .train()/.eval() behavior present in other libraries!).
Tuples represent feedforward (a.k.a sequential) modules
Since we can implement traits for tuples, which is not possible in other languages AFAIK, they provide a very nice frontend for sequentially executing modules.
How implementing Module for a 2-tuple looks:
Modules implemented for Tuples up to 6 elements, but you can arbitrarily nest them!
No Rc<RefCells<T>> used - Gradient tape is not kept behind a cell!
Other implementations may store a reference to the gradient tape directly on tensors, which requires mutating tensors or using Rc/Refcells all over the place.
We've figured out an elegant way to avoid this, reducing references and dynamic borrow checks to 0!
Since all operations result in exactly 1 child, we can always move the gradient tape to the child of the last operation. Additionally, no model parameters (all tensors) will ever own the gradient tape because they will never be the result of any operation. This means we know exactly which tensor owns the gradient tape, and the tensors that have it will always be intermediate results that don't need to be maintained across gradient computation.
All of this together gives users unprecedented control/precision over what tensors are recorded on the gradient tape!
One advanced use case requires that tensors be re-used multiple times in a computation graph. This can be handled by cloning the tensor, and manually moving the gradient tape around.
Type checked backward
tl;dr: If you forget to include a call to trace() or traced() , the program won't compile!
Since we know exactly what tensors own the gradient tape, we can require the tensor passed into .backward() to own the gradient tape! And further, we can require it be moved into .backward() , so it can destruct the tape and construct the gradients!
All of this can be checked at compile time 🎉
📄 Validated against pytorch
All functions & operations are tested against behavior shown by similar code in pytorch.
License
Dual-licensed to be compatible with the Rust project.
Licensed under the Apache License, Version 2.0 http://www.apache.org/licenses/LICENSE-2.0 or the MIT license http://opensource.org/licenses/MIT, at your option. This file may not be copied, modified, or distributed except according to those terms.
About
Deep learning in Rust, with shape checked tensors and neural networks
Topics
rust machine-learning deep-neural-networks deep-learning neural-network gpu cuda autograd rust-lang gpu-acceleration cuda-kernels tensor gpu-computing backpropagation cudnn cuda-toolkit cuda-support autodiff autodifferentiation
Resources
Readme
License
View license
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
1.9k stars
Watchers
32 watching
Forks
105 forks
Report repository
Releases 8
v0.13.0 - dtypes module & adds AMP<F> dtype Latest on Jul 27, 2023
+ 7 releases
Sponsor this project
 patreon.com/ dfdx
 ko-fi.com/ coreylowman
Packages 0
No packages published
Uh oh!
There was an error while loading. Please reload this page.
Contributors 39
+ 25 contributors
Languages
Rust 92.1%
Cuda 7.6%
Other 0.3%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.