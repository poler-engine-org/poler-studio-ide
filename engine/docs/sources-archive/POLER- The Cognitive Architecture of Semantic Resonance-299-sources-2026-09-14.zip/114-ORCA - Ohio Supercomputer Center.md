> Source: https://www.osc.edu/resources/available_software/software_list/orca

ORCA | Ohio Supercomputer Center
Skip navigation
A Division of the Ohio Department of Higher Education
Accessibility
Default Display
Text Only
Text Only (High Contrast)
Accessibility Statement
Login
Search form
Search Search     
Home
About
About OSC
At A Glance
Governance
News
Careers
Leadership
Visit the Ohio Supercomputer Center
Affiliations
By the Numbers
Services
Cluster Computing
Research Data Storage
Education
Web Software Development
Research Software Engineering
Artificial Intelligence, Data Analytics and Machine Learning
Dependability
Case Studies
Advanced Materials
Aerospace
Agribusiness
Automotive
Aviation
Biological Sciences
Energy/Chemical
Environment
Industrial Engagement
Invention/Discovery
Manufacturing
Research Landscape
Resources
Getting Started
Available Software
Technical Support
Gateways
Facilitation
Data Storage
OSC Campus Champions
Protected Data Service
Security, Accessibility, and Policies
Research
Cite OSC
Manage Projects and Budgets
Research Proposal Partnership
Research Collaborations
Annual Research Reports
Open OnDemand
Research Symposium
Education
Summer Educational Programs
NSF ACCESS Regional Workshop
AI Research Experience Summer Opportunity for Undergraduates
Contact Us
Client Support Request
Sales
Report an Information Security Incident
Media and Branding
Staff Directory
Access OSC
System Gateway
Client Portal
System Status
Usage Metrics
Get an OSC account
Service Costs
You are here
Home/
Client Resources/
Available Software/
Software List/
ORCA
ORCA
ORCA is an ab initio quantum chemistry program package that contains modern electronic structure methods including density functional theory, many-body perturbation, coupled cluster, multireference methods, and semi-empirical quantum chemistry methods. Its main field of application is larger molecules, transition metal complexes, and their spectroscopic properties. ORCA is developed in the research group of Frank Neese. Visit ORCA Forum for additional information.
We have found that several ORCA 5 jobs requiring heavy I/O load on scratch/project filesystems are causing performance issues and affecting the performance of the filesystems. For optimal performance, we recommend to run such ORCA jobs on a local disk ($TMPDIR), as discussed in the ORCA forum:
https://orcaforum.kofo.mpg.de/viewtopic.php?f=8&t=10935&p=45270&hilit=di...
https://orcaforum.kofo.mpg.de/viewtopic.php?f=9&t=10835&p=44967&hilit=di...
We also recommend using ORCA 4.2.1 unless ORCA 5 is necessary for your job. To run an ORCA job using $TMPDIR, please refer to the example in the Usage section below.
To avoid potential memory issues, it is important to tune the %maxcore value based on the number of cores you request. Plese refer to the "Best practices" section in the Usage guidelines below for more details.
Availability and Restrictions
Versions
ORCA is available on the OSC clusters. These are the versions currently available:
Current default version. The notes indicate the MPI module likely to produce the best performance, but see the Known Issue below named "Bind to CORE".
You can use module spider orca to view available modules for a given machine. Feel free to contact OSC Help if you need other versions for your work.
Access
ORCA is available to OSC academic users; users need to sign up ORCA Forum. You will receive a registration confirmation email from the ORCA management. Please contact [OSC Help](mailto:oschelp@osc.edu?subject=Access to ORCA) with the confirmation email for access.
Publisher/Vendor/Repository and License Type
ORCA, Academic (Computer Center)
Usage
Usage
Set-up
ORCA usage is controlled via modules. Load one of the ORCA modulefiles at the command line, in your shell initialization script, or in your batch scripts. To load the a particular software version, use module load orca/{version} . For example, use module load orca/4.2.1 to load ORCA version 4.2.1.
IMPORTANT NOTE: You need to load correct compiler and MPI modules before you use ORCA. In order to find out what modules you need, use module spider orca/{version} .
Batch Usage
When you log into pitzer.osc.edu or pitzer.osc.edu, you are actually logged into a linux box referred to as the login node. To gain access to the mutiple processors in the computing environment, you must submit your job to the batch system for execution. Batch jobs can request mutiple nodes/cores and compute time up to the limits of the OSC systems. Refer to Queues and Reservations and Batch Limit Rules for more info. Batch jobs run on the compute nodes of the system and not on the login node. It is desirable for big problems since more resources can be used.
Interactive Batch Session
For an interactive batch session one can run the following command:
which requests one core ( -n 1 ), for a walltime of 20 minutes ( -t 00:20:00 ). You may adjust the numbers per your need.
Non-interactive Batch Job
A batch script can be created and submitted for a serial or parallel run. You can create the batch script using any text editor you like in a working directory on the system of your choice. Below is the example batch script for a parallel run:
Please note that the <number-of-cores-per-node> cannot exceed the maximum cores per node. You can refer to Cluster Computing for the maximum number for each cluster.
Best practices
Set correct value for %maxcore
In general, it is recommended to utilize 3000, which is 75% of the usable memory per core on each cluster. However, you may need to increase %maxcore due to the methods and the modular system. In this case, you can decrease the number of cores for the same job. For example, if you have the following script to run an 80-core ORCA job on two Pitzer 40-core nodes:
If you need to increase %maxcore to 4000, you can run ORCA with 60 cores (30 cores per node) in the same job script by replacing the ORCA command line with:
Further Reading
User manual is available from the ORCA Forum Job submission information is available from the Batch Submission Guide
Scratch Storage information is availiable from the Storage Documentation
Supercomputer:
Ascend
Cardinal
Pitzer
Service:
Software
Fields of Science:
Chemical Engineering & Chemistry
‹ Nodejs up Ollama ›
Printer-friendly version
Client Resources
Getting Started Toggle submenu visibility
New User Resource Guide
HPC Basics
Getting Connected
Budgets and Accounts Toggle submenu visibility
Applying for Academic Accounts
UNIX Basics Toggle submenu visibility
Linux Command Line Fundamentals
Linux Tutorial
Tar Tutorial
Unix Shortcuts
Classroom Project Resource Guide Toggle submenu visibility
Classroom Guide for Students
Using Jupyter for Classroom
Using Rstudio for classroom
Using nbgrader for Classroom
HOWTO Toggle submenu visibility
Using Software on Pitzer RHEL 7
HOW TO: Look at requested time accuracy using XDMoD
HOWTO: Add and Use DUO MFA
HOWTO: Collect performance data for your program
HOWTO: Create and Manage Python Environments Toggle submenu visibility
HOWTO: Install Tensorflow locally
HOWTO: Install Python packages from source
HOWTO: Use GPU with Tensorflow and PyTorch
HOWTO: Debugging Tips
HOWTO: Establish durable SSH connections
HOWTO: Estimating and Profiling GPU Memory Usage for Generative AI
HOWTO: Identify users on a project account and check status
HOWTO: Install a MATLAB toolbox
HOWTO: Install your own Perl modules
HOWTO: Locally Installing Software
HOWTO: Manage Access Control List (ACLs) Toggle submenu visibility
HOWTO: Use NFSv4 ACL
HOWTO: Use POSIX ACL
HOWTO: PyTorch Distributed Data Parallel (DDP)
HOWTO: PyTorch Fully Sharded Data Parallel (FSDP2)
HOWTO: Reduce Disk Space Usage
HOWTO: Reduce GPU memory usage during ANN training and inference
HOWTO: Run Python in Parallel
HOWTO: Submit Homework to Repository at OSC
HOWTO: Submit multiple jobs using parameters
HOWTO: Tune Performance
HOWTO: Tune VASP Memory Usage
HOWTO: Use 'rclone' to Upload Data
HOWTO: Use 'rclone' to Upload Data from Google Drive
HOWTO: Use Address Sanitizer
HOWTO: Use Cron and OSCusage for Regular Emailed Reports
HOWTO: Use Docker and Singularity Containers at OSC
HOWTO: Use Extensions with JupyterLab
HOWTO: Use GPU in Python
HOWTO: Use Globus (Overview) Toggle submenu visibility
HOWTO: Use AWS S3 in Globus
HOWTO: Use OneDrive in Globus
HOWTO: Deploy your own endpoint on a server
HOWTO: Use Jupyter on OnDemand
HOWTO: Use VNC in a batch job
HOWTO: Use a Conda/Virtual Environment With Jupyter
HOWTO: Use an Externally Hosted License
HOWTO: Use ulimit command to set soft limits
HOWTO: Using MLFlow to track ML training and models
HOWTO: test data transfer speed
Citation
New User Training
OSC Custom Commands Toggle submenu visibility
OSCfinger
OSCgetent
OSCprojects
OSCusage
gpu-seff
osc-seff
OSC User Code of Ethics
Supercomputing FAQ
Supercomputing Terms
Available Software Toggle submenu visibility
Browse Software
Community Software
OnDemand Application List
Scientific Database List Toggle submenu visibility
BLAST Database
Software List Toggle submenu visibility
Abaqus
AFNI
AMBER
ANSYS Toggle submenu visibility
ANSYS Mechanical
CFX
FLUENT
Workbench Platform
AlphaFold 3
AlphaFold
Altair HyperWorks
Apptainer
AutoDock
BCFtools
BLAS
BLAST
BWA
Blender
Boost
Bowtie
Bowtie2
CMake
COMSOL Toggle submenu visibility
Interactive Parallel COMSOL Job
CP2K
CUDA
Cell Ranger
Code Server
ComfyUI
Connectome Workbench
Cufflinks
DS9
DSI Studio
Darshan
Desmond
FFTW
FSL
FastQC
FreeSurfer
GAMESS
GATK
GNU Compilers
GROMACS
GSL
Gaussian
Git
Gurobi
HDF5 Toggle submenu visibility
HDF5-Serial
HISAT2
HPC Toolkit
HTSlib
IQmol
Intel Compilers
Intel MPI (Old)
Intel MPI
Intel Math Kernel Library
Java
Julia
LAMMPS
LAPACK
LS-DYNA Toggle submenu visibility
LS-OPT
LS-PrePost
User-Defined Material for LS-DYNA
Linaro HPC tools Toggle submenu visibility
Linaro Performance Reports
Linaro MAP
Linaro DDT
MATLAB Toggle submenu visibility
SPM
MRIQC
MRIcroGL
MVAPICH
MVAPICH2
Mathematica
Miniconda3
NAMD
NCCL
NVHPC
NWChem
Ncview
NetCDF
Neuropointillist
Nextflow
Nodejs
ORCA
Ollama
OpenACC
OpenAI Python
OpenCV
OpenFOAM
OpenMP
OpenMPI
ParaView
Parallel-netCDF
Perl
Picard
Podman
PyMOL
PyTorch
Python
Q-Chem
QGIS
Quantum ESPRESSO
R and Rstudio
RELION
Rosetta
Ruby
Rust
SAMtools
SRA Toolkit
STAR
STAR-CCM+ Toggle submenu visibility
Run STAR-CCM+ to STAR-CCM+ Coupling
Schrodinger
Scipion
SnpEff
Spark
Stata
Subread
Texlive
Tinker
Trimmomatic
Trinity
TurboVNC
VASP
VCFtools
VMD
VirtualGL
VisIt
WARP3D
WCStools
XFdtd
aocc
bedtools
dcm2nii
fMRIPrep
ffmpeg
oneAPI
parallel-command-processor
vLLM
Statewide Software Licensing Toggle submenu visibility
Statewide Software-Altair
Storage Documentation
Technical Support Toggle submenu visibility
HPC Changelog Toggle submenu visibility
MVAPICH2 version 2.3 modules modified on Owens
Known issues
Search Documentation
Supercomputers Toggle submenu visibility
Ascend Toggle submenu visibility
Ascend Programming Environment
Ascend Software Environment
Batch Limit Rules
Citation
Available software list on Next Gen Ascend
OSU College of Medicine Compute Service
SSH key fingerprints
Technical Specifications
Cardinal Toggle submenu visibility
Technical Specifications
Cardinal Programming Environment
Cardinal Software Environment
Citation
Batch Limit Rules
Cardinal SSH key fingerprints
Migrating jobs from other clusters
Pitzer Toggle submenu visibility
Technical Specifications
Pitzer Programming Environment
Pitzer Software Environment
Batch Limit Rules
Citation
Pitzer SSH key fingerprints
Guidance After Pitzer Upgrade to RHEL9
Guidance on Requesting Resources on Pitzer
GPU Computing
High Bandwidth Memory
Tutorials & Training Toggle submenu visibility
Seminar: What can OSC do for you? Services for Faculty Research and Teaching
Batch Processing at OSC Toggle submenu visibility
Batch System Concepts
Batch Execution Environment
Job Scripts
Job Submission
Monitoring and Managing Your Job
Scheduling Policies and Limits
Slurm Directives Summary
Batch Environment Variable Summary
Batch-Related Command Summary
License software flag usage information
Messages from sbatch
Troubleshooting Batch Problems
batch email notifications
Slurm Migration Toggle submenu visibility
How to Prepare Slurm Job Scripts
How to Submit, Monitor and Manage Jobs
Steps on How to Submit Jobs
Slurm Migration Issues
Knowledge Base Toggle submenu visibility
Account Consolidation Guide
Community Accounts
Compilation Guide
Firewall and Proxy Settings
Job and storage charging
Out-of-Memory (OOM) or Excessive Memory Usage
Thread Usage Best Practices
XDMoD Tool Toggle submenu visibility
Job Viewer
XDMoD - Checking Job Efficiency
Gateways Toggle submenu visibility
Client Portal Toggle submenu visibility
Self-Signup for Accounts
Change or Reset Password and Retrieve Usernames
Adding grant information
Check usage costs for current fiscal year
Invite, add, remove users
Limiting charges with budgets
Manage profile information
Multi-factor authentication
Project review and special properties
Projects, budgets and charge accounts
billing statements
HPC Job Activity tool
Interactive Reporting
OnDemand Toggle submenu visibility
File Transfer and Management
Job Management
Facilitation
Data Storage Toggle submenu visibility
Overview of File Systems
Storage Hardware
2016 Storage Service Upgrades
2020 Storage Service Upgrades
2022 Storage Service Upgrades
Protected Data Service Toggle submenu visibility
Manage the protected data and its access
Securely transferring files to protected data location
Security, Accessibility, and Policies Toggle submenu visibility
Proposed OSC Policies for Public Comments
Service Costs Toggle submenu visibility
FY26 budgets: Action may be required
FY27 budgets: Action may be required
Service Terms
Upcoming Events
Virtual Help Desk
Virtual Help Desk
Jun 3 2026 - 2:00pm to 4:00pm
Virtual Help Desk
Jun 9 2026 - 2:00pm to 4:00pm
Virtual Help Desk
Jun 10 2026 - 2:00pm to 4:00pm
more
Recent News
Columbus, Ohio - May 28: Ohio University researchers turn to Ohio Supercomputer Center as computing demands grow
Columbus, Ohio - May 21: Open OnDemand helps University of Otago expand access to HPC across campus and the Pacific
Columbus, Ohio - May 14: Open OnDemand releases version 4.2.2 in compliance with U.S. accessibility guidelines
more
Translate
Select Language
Abkhaz
Acehnese
Acholi
Afar
Afrikaans
Albanian
Alur
Amharic
Arabic
Armenian
Assamese
Avar
Awadhi
Aymara
Azerbaijani
Balinese
Baluchi
Bambara
Baoulé
Bashkir
Basque
Batak Karo
Batak Simalungun
Batak Toba
Belarusian
Bemba
Bengali
Betawi
Bhojpuri
Bikol
Bosnian
Breton
Bulgarian
Buryat
Cantonese
Catalan
Cebuano
Chamorro
Chechen
Chichewa
Chinese (Simplified)
Chinese (Traditional)
Chuukese
Chuvash
Corsican
Crimean Tatar (Cyrillic)
Crimean Tatar (Latin)
Croatian
Czech
Danish
Dari
Dhivehi
Dinka
Dogri
Dombe
Dutch
Dyula
Dzongkha
Esperanto
Estonian
Ewe
Faroese
Fijian
Filipino
Finnish
Fon
French
French (Canada)
Frisian
Friulian
Fulani
Ga
Galician
Georgian
German
Greek
Guarani
Gujarati
Haitian Creole
Hakha Chin
Hausa
Hawaiian
Hebrew
Hiligaynon
Hindi
Hmong
Hungarian
Hunsrik
Iban
Icelandic
Igbo
Ilocano
Indonesian
Inuktut (Latin)
Inuktut (Syllabics)
Irish
Italian
Jamaican Patois
Japanese
Javanese
Jingpo
Kalaallisut
Kannada
Kanuri
Kapampangan
Kazakh
Khasi
Khmer
Kiga
Kikongo
Kinyarwanda
Kituba
Kokborok
Komi
Konkani
Korean
Krio
Kurdish (Kurmanji)
Kurdish (Sorani)
Kyrgyz
Lao
Latgalian
Latin
Latvian
Ligurian
Limburgish
Lingala
Lithuanian
Lombard
Luganda
Luo
Luxembourgish
Macedonian
Madurese
Maithili
Makassar
Malagasy
Malay
Malay (Jawi)
Malayalam
Maltese
Mam
Manx
Maori
Marathi
Marshallese
Marwadi
Mauritian Creole
Meadow Mari
Meiteilon (Manipuri)
Minang
Mizo
Mongolian
Myanmar (Burmese)
Nahuatl (Eastern Huasteca)
Ndau
Ndebele (South)
Nepalbhasa (Newari)
Nepali
NKo
Norwegian
Nuer
Occitan
Odia (Oriya)
Oromo
Ossetian
Pangasinan
Papiamento
Pashto
Persian
Polish
Portuguese (Brazil)
Portuguese (Portugal)
Punjabi (Gurmukhi)
Punjabi (Shahmukhi)
Quechua
Qʼeqchiʼ
Romani
Romanian
Rundi
Russian
Sami (North)
Samoan
Sango
Sanskrit
Santali (Latin)
Santali (Ol Chiki)
Scots Gaelic
Sepedi
Serbian
Sesotho
Seychellois Creole
Shan
Shona
Sicilian
Silesian
Sindhi
Sinhala
Slovak
Slovenian
Somali
Spanish
Sundanese
Susu
Swahili
Swati
Swedish
Tahitian
Tajik
Tamazight
Tamazight (Tifinagh)
Tamil
Tatar
Telugu
Tetum
Thai
Tibetan
Tigrinya
Tiv
Tok Pisin
Tongan
Tshiluba
Tsonga
Tswana
Tulu
Tumbuka
Turkish
Turkmen
Tuvan
Twi
Udmurt
Ukrainian
Urdu
Uyghur
Uzbek
Venda
Venetian
Vietnamese
Waray
Welsh
Wolof
Xhosa
Yakut
Yiddish
Yoruba
Yucatec Maya
Zapotec
Zulu
Powered by
 Translate
Ohio Supercomputer Center (OSC)
· A member of the Ohio Technology Consortium
1224 Kinnear Road, Columbus, OH, 43212, US
· 614-292-9248
· webmaster@osc.edu
Copyright © 2026 by the Ohio Supercomputer Center. All Rights Reserved.
· Privacy Policy
Request Help from Client Services
If you have a disability and experience difficulty accessing this content, please contact the OH-TECH Digital Accessibility Team at accessibility@oh-tech.org. 
Ohio Department of Higher Education
25 South Front Street
Columbus, Ohio 43215
State Government Links
Mike DeWine, Governor | Ohio.gov
Ohio Checkbook
Education Links
Ohio Department of Higher Education
Ohio Technology Consortium
OARnet | OSC | OhioLINK
OACC | IUC | OTTA | ODE 
Original text
Rate this translation
Your feedback will be used to help improve Google Translate