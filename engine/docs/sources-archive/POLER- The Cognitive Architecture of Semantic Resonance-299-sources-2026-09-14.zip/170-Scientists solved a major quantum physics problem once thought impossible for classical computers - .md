> Source: https://www.earth.com/news/scientists-solve-major-quantum-physics-problem-once-thought-impossible-for-classical-computers/

Scientists solved a major quantum physics problem once thought impossible for classical computers - Earth.com 
 
Subscribe
news 
videos 
images 
earthpedia 
take action
earthsnap 
Subscribe 
05-24-2026
Scientists solved a major quantum physics problem once thought impossible for classical computers
By Eric Ralls
Earth.com staff writer
 [](https://www.linkedin.com/shareArticle?url=https%3A%2F%2Fwww.earth.com%2Fnews%2Fscientists-solve-major-quantum-physics-problem-once-thought-impossible-for-classical-computers%2F&text=Scientists solved a major quantum physics problem once thought impossible for classical computers)   
Follow Earth on Google Follow us Mark as selected source
D-Wave's quantum machine had done something worth paying attention to. It had tracked hundreds of particles locked in a tangled, disorderly magnetic system. It was the kind of simulation that grows exponentially harder the more particles you add
The problem was so complicated, in fact, that a March 2025 paper in Science concluded that no classical computer could replicate it. The authors had compared their research against every available classical method, but nothing came close.
That conclusion landed as a formal claim of quantum supremacy: a problem quantum hardware could solve that ordinary computers simply could not.
Papers like that tend to redirect careers, funding, and the broader narrative of which technology the field should be building toward. A group of physicists in New York read it, raised their eyebrows, and started writing code.
Solving physics problems on laptops
That someone was Joseph Tindall, an associate research scientist at the Center for Computational Quantum Physics at the Flatiron Institute.
He and his colleagues spend their time finding ways to push quantum-physics problems through old-fashioned computers.
The CCQ team specializes in finding new ways to push quantum problems through ordinary hardware. Whenever a result arrives with the label “beyond classical,” they look for methods the authors may have missed. This time, they had new tools ready.
So they picked that paper as their target. The simulation involved hundreds of interacting qubits across two- and three-dimensional lattices, and the D-Wave team had maintained that no classical approach could keep up.
Quantum supremacy claim
That phrase, “beyond classical,” carries weight in this field. When a quantum experiment crosses that line, it suggests a real-world advantage for the finicky machines researchers have been building for over a decade. The 2025 paper made exactly that argument.
Specifically, the D-Wave team measured how a quantum spin glass – a disorderly system of magnetic interactions – evolved over time.
After comparisons with the classical methods available at the time, they concluded the simulation lay out of reach without quantum hardware.
That claim of quantum supremacy is the kind of headline that pulls money, talent, and policy attention toward quantum machines. It is also the kind of headline Tindall and his colleagues tend to read with raised eyebrows.
Why qubits resist
The reason such simulations turn ugly sits inside the math. Qubits, the quantum equivalents of the 0s and 1s inside ordinary computers, can hold a blend of both values at once. Powerful in theory. And extraordinarily costly to simulate.
A few dozen qubits tangled together produces a state too large to store directly. The size of that state, called the wave function, grows exponentially as more qubits enter the picture.
Quantum entanglement compounds the trouble. Two qubits on opposite ends of a lattice can be linked in a way that classical math cannot factor apart, which forces the whole system to be tracked together rather than in pieces.
An older algorithm
To get around that, Tindall reached back to an idea from the 1980s. Belief propagation was built for working with uncertain data – the math behind error correction and machine vision. Forty years old, and newly useful.
The method is approximate rather than exact. That trade-off is what makes it cheap, light enough to run on hardware that ordinary scientists already keep on their desks – including the laptop Tindall used.
Tindall paired that older idea with newer mathematical scaffolding. Belief propagation tracked how entanglement spread between particles as the simulation ran, and a more careful version of the same method pulled out the final answers.
Compression and tensor networks
The other half of the trick involved tensor networks – mathematical structures that store a quantum state inside linked tables of numbers.
Rather than cataloging every configuration, the approach captures only the patterns that actually appear. Not everything. Just those.
Tindall ran the early calculations on a laptop using a software library called ITensor, built by the CCQ team over the past decade. No specialized hardware. No quantum machine. Just code.
What made it possible was capturing the system in three dimensions rather than flattening it into something simpler.
That three-dimensional approach is harder to pull off classically, and it's precisely where the D-Wave result had set its bar.
Quantum vs. classical methods
When the team ran their simulation against the D-Wave results, the numbers lined up. The classical method reproduced the quantum machine's output, and matched theoretical predictions on smaller test problems where exact answers can be checked.
That outcome cuts directly against the 2025 supremacy claim. Same answers, no quantum computer. The classical version did it on hardware anyone could buy at a store.
None of that means quantum computers are dead in the water. Not even close. The result does suggest that earlier comparisons may have left useful classical tricks on the table when judging which problems truly require quantum machines.
What changes now
One direct outcome of this work: the 2025 quantum supremacy claim does not hold. Future supremacy claims will need to beat smarter classical baselines, including tensor-network methods of the kind Tindall and his co-authors used here.
Tindall's group is now pushing toward harder problems involving electrons that hop between lattice sites, the kind of system that describes real quantum materials. Those simulations connect directly to predicting how new superconductors behave at the atomic scale.
That class of problem has stayed stubbornly difficult for decades. But classical tools have advanced faster than anyone predicted, and the line between what a laptop can handle and what only a quantum computer can do is still moving.
The study is published in Science.
—–
Like what you read? Subscribe to our newsletter for engaging articles, exclusive content, and the latest updates.
Check us out on EarthSnap, a free app brought to you by Eric Ralls and Earth.com.
—–
RELATED NEWS
05-30-2026
Scientists identify the brain circuit that makes pain feel worse
05-30-2026
Scientists tracked children who lie and found something surprising
05-30-2026
Divers damage coral reefs far more often than they realize
05-30-2026
Eating too little protein may speed up physical decline as you age
05-30-2026
A hidden fat buildup inside cat kidneys may reveal why they get so sick with age
05-30-2026
Cannabis linked to a surprising change in testosterone levels
05-30-2026
AI reveals how the brain clears harmful waste during sleep
05-30-2026
No superfood needed, a large study links lower colorectal cancer risk to an anti-inflammatory diet pattern
05-30-2026
Scientists finally know how long orangutans breastfeed
05-30-2026
A deep ocean change near Antarctica may follow Atlantic slowdowns, and it could reshape climate patterns
05-30-2026
Being single is better than settling for a bad relationship
05-30-2026
Plants can smell fast-growing neighbors and change their strategy
home
news
news-category/science
News coming your way
The biggest news about our planet delivered to you each day 
Subscribe
Built with Kit 
About Us
Privacy Policy
Terms of Service
Site Map
Staff
EARTH.COM
News
Videos
Images
Earthpedia
Take action
EARTHPEDIA
Articles
Animals Encyclopedia
Endangered Animals
Plants Encyclopedia
Endangered Plants
EARTH NEWS
Breaking News
Environment
Lifestyle
Animals
Plants
Earthsnap
Get the app
Privacy Policy
Terms of service
GET IN TOUCH
Contact Us
© 2026 Earth.com
All rights reserved
✕ Error. Try later. You have blocked Push Notifications. Follow these instructions to enable Push Notifications. Subscribe to receive push notifications on latest updates You are unsubscribed to Push Notifications You are subscribed to Push Notifications  SUBSCRIBE SUBSCRIBE UNSUBSCRIBE ⚡ by Webpushr
✕
Subscribe to our newsletter and be the first to know what the planet is up to.
Sign up  
What is this? 
Report Ad 
What is this? 
Report Ad 
What is this? 
Report Ad
15   