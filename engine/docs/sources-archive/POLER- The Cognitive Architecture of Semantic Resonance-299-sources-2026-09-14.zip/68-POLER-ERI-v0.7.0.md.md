POLER-ERI v0.7.0 – повний код проекту
📁 Структура файлів
Cargo.toml – залежності та налаштування проєкту
main.rs – метакомпілятор, синтез схем, кристалізатор, тести
generated/ – згенеровані Rust-бібліотеки для оболонок (ss, ps, ds, pp, dd)
--------------------------------------------------------------------------------
📄 Cargo.toml
📄 main.rs
📄 generated/poler_eri_dd_dd_generated.rs
📄 generated/poler_eri_ds_ss_generated.rs
📄 generated/poler_eri_pp_pp_generated.rs
📄 generated/poler_eri_pp_ss_generated.rs
📄 generated/poler_eri_ps_ss_generated.rs
📄 generated/poler_eri_ss_ss_generated.rs