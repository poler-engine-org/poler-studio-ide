> Source: https://en.wikipedia.org/wiki/Tensor_product_of_algebras

Tensor product of algebras - Wikipedia
Jump to content [-]
Main menu
Main menu
move to sidebar hide
Navigation
Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Contribute
Help
Learn to edit
Community portal
Recent changes
Upload file
Special pages
Search
Search [-]
Appearance
Donate
Create account
Log in [-]
Personal tools
Donate
Create account
Log in
Contents
move to sidebar hide
(Top)
1 Definition
2 Further properties
3 Applications
4 Examples
5 See also
6 Notes
7 References [-]
Toggle the table of contents
Tensor product of algebras
[-]
3 languages
Français
日本語
Русский
Edit links
Article
Talk [-]
English
Read
Edit
View history [-]
Tools
Tools
move to sidebar hide
Actions
Read
Edit
View history
General
What links here
Related changes
Upload file
Permanent link
Page information
Cite this page
Get shortened URL
Expand all
Edit interlanguage links
Print/export
Download as PDF
Printable version
In other projects
Wikidata item
Appearance
move to sidebar hide
Text
[-] 0 Small [x] 1 Standard [-] 2 Large
This page always uses small font size
Width
[x] 1 Standard [-] 0 Wide
The content is as wide as possible for your browser window.
Color
[-] os Automatic [x] day Light [-] night Dark
This page is always in light mode.
From Wikipedia, the free encyclopedia
Algebraic structure → Ring theory
Ring theory
show
Basic concepts
Rings
•
Subrings
•
Ideal
•
Quotient ring
•
Fractional ideal
•
Total ring of fractions
•
Product of rings
•
Free product of associative algebras
•
Tensor product of algebras
Ring homomorphisms
•
Kernel
•
Inner automorphism
•
Frobenius endomorphism
Algebraic structures
•
Module
•
Associative algebra
•
Graded ring
•
Involutive ring
•
Category of rings
•
Initial ring Z {\displaystyle \mathbb {Z} } 
•
Terminal ring 0 = Z / 1 Z {\displaystyle 0=\mathbb {Z} /1\mathbb {Z} } 
Related structures
•
Field
•
Finite field
•
Non-associative ring
•
Lie ring
•
Jordan ring
•
Semiring
•
Semifield
show
Commutative algebra
Commutative rings
•
Integral domain
•
Integrally closed domain
•
GCD domain
•
Unique factorization domain
•
Principal ideal domain
•
Euclidean domain
•
Field
•
Finite field
•
Polynomial ring
•
Formal power series ring
Algebraic number theory
•
Algebraic number field
•
Integers modulo n
•
Ring of integers
•
p-adic integers Z p {\displaystyle \mathbb {Z} _{p}} 
•
p-adic numbers Q p {\displaystyle \mathbb {Q} _{p}} 
•
Prüfer p-ring Z ( p ∞ ) {\displaystyle \mathbb {Z} (p^{\infty })} 
show
Noncommutative algebra
Noncommutative rings
•
Division ring
•
Semiprimitive ring
•
Simple ring
•
Commutator
Noncommutative algebraic geometry
Free algebra
Clifford algebra
•
Geometric algebra
Operator algebra
v
t
e
Tensor product of algebras over a field; itself another algebra
In mathematics, the tensor product of two algebras over a commutative ring R is also an R-algebra. This gives the tensor product of algebras. When the ring is a field, the most common application of such products is to describe the product of algebra representations.
Definition
[ edit]
Let R be a commutative ring and let A and B be R-algebras. Since A and B may both be regarded as R- modules, their tensor product
A ⊗ R B {\displaystyle A\otimes _{R}B} 
is also an R-module. The tensor product can be given the structure of a ring by defining the product on elements of the form a ⊗ b by [1] [2]
( a 1 ⊗ b 1 ) ( a 2 ⊗ b 2 ) = a 1 a 2 ⊗ b 1 b 2 {\displaystyle (a_{1}\otimes b_{1})(a_{2}\otimes b_{2})=a_{1}a_{2}\otimes b_{1}b_{2}} 
and then extending by linearity to all of A ⊗ R B. This ring is an R-algebra, associative and unital with the identity element given by 1 A ⊗ 1 B, [3] where 1 A and 1 B are the identity elements of A and B. If A and B are commutative, then the tensor product is commutative as well.
The tensor product turns the category of R-algebras into a symmetric monoidal category. [citationneeded]
Further properties
[ edit]
There are natural homomorphisms from A and B to A ⊗ R B given by [4]
a ↦ a ⊗ 1 B {\displaystyle a\mapsto a\otimes 1_{B}} 
b ↦ 1 A ⊗ b {\displaystyle b\mapsto 1_{A}\otimes b} 
These maps make the tensor product the coproduct in the category of commutative R-algebras. The tensor product is not the coproduct in the category of all R-algebras; there the coproduct is given by a more general free product of algebras. Nevertheless, the tensor product of non-commutative algebras can be described by a universal property similar to that of the coproduct:
Hom ( A ⊗ B , X ) ≅ { ( f , g ) ∈ Hom ( A , X ) × Hom ( B , X ) ∣ ∀ a ∈ A , b ∈ B : [ f ( a ) , g ( b ) ] = 0 } , {\displaystyle {\text{Hom}}(A\otimes B,X)\cong \lbrace (f,g)\in {\text{Hom}}(A,X)\times {\text{Hom}}(B,X)\mid \forall a\in A,b\in B:[f(a),g(b)]=0\rbrace ,} 
where [-, -] denotes the commutator. The natural isomorphism is given by identifying a morphism ϕ : A ⊗ B → X {\displaystyle \phi :A\otimes B\to X} 
on the left hand side with the pair of morphisms ( f , g ) {\displaystyle (f,g)} 
on the right hand side where f ( a ) := ϕ ( a ⊗ 1 ) {\displaystyle f(a):=\phi (a\otimes 1)} 
and similarly g ( b ) := ϕ ( 1 ⊗ b ) {\displaystyle g(b):=\phi (1\otimes b)} 
.
Applications
[ edit]
The tensor product of commutative algebras is of frequent use in algebraic geometry. For affine schemes X, Y, Z with morphisms from X and Z to Y, so X = Spec( A), Y = Spec( R), and Z = Spec( B) for some commutative rings A, R, B, the fiber product scheme is the affine scheme corresponding to the tensor product of algebras:
X × Y Z = Spec  ( A ⊗ R B ) . {\displaystyle X\times _{Y}Z=\operatorname {Spec} (A\otimes _{R}B).} 
More generally, the fiber product of schemes is defined by gluing together affine fiber products of this form.
Examples
[ edit]
See also: tensor product of modules § Examples
The tensor product can be used as a means of taking intersections of two subschemes in a scheme: consider the C [ x , y ] {\displaystyle \mathbb {C} [x,y]} -algebras C [ x , y ] / f {\displaystyle \mathbb {C} [x,y]/f} , C [ x , y ] / g {\displaystyle \mathbb {C} [x,y]/g} , then their tensor product is C [ x , y ] / ( f ) ⊗ C [ x , y ] C [ x , y ] / ( g ) ≅ C [ x , y ] / ( f , g ) {\displaystyle \mathbb {C} [x,y]/(f)\otimes _{\mathbb {C} [x,y]}\mathbb {C} [x,y]/(g)\cong \mathbb {C} [x,y]/(f,g)} , which describes the intersection of the algebraic curves f = 0 and g = 0 in the affine plane over C.
More generally, if A {\displaystyle A} is a commutative ring and I , J ⊆ A {\displaystyle I,J\subseteq A} are ideals, then A I ⊗ A A J ≅ A I + J {\displaystyle {\frac {A}{I}}\otimes _{A}{\frac {A}{J}}\cong {\frac {A}{I+J}}} , with a unique isomorphism sending ( a + I ) ⊗ ( b + J ) {\displaystyle (a+I)\otimes (b+J)} to a b + I + J {\displaystyle ab+I+J} .
Tensor products can be used as a means of changing coefficients. For example, Z [ x , y ] / ( x 3 + 5 x 2 + x − 1 ) ⊗ Z Z / 5 ≅ Z / 5 [ x , y ] / ( x 3 + x − 1 ) {\displaystyle \mathbb {Z} [x,y]/(x^{3}+5x^{2}+x-1)\otimes _{\mathbb {Z} }\mathbb {Z} /5\cong \mathbb {Z} /5[x,y]/(x^{3}+x-1)} and Z [ x , y ] / ( f ) ⊗ Z C ≅ C [ x , y ] / ( f ) {\displaystyle \mathbb {Z} [x,y]/(f)\otimes _{\mathbb {Z} }\mathbb {C} \cong \mathbb {C} [x,y]/(f)} .
Tensor products also can be used for taking products of affine schemes over a field. For example, C [ x 1 , x 2 ] / ( f ( x ) ) ⊗ C C [ y 1 , y 2 ] / ( g ( y ) ) {\displaystyle \mathbb {C} [x_{1},x_{2}]/(f(x))\otimes {\mathbb {C} }\mathbb {C} [y{1},y_{2}]/(g(y))} is isomorphic to the algebra C [ x 1 , x 2 , y 1 , y 2 ] / ( f ( x ) , g ( y ) ) {\displaystyle \mathbb {C} [x_{1},x_{2},y_{1},y_{2}]/(f(x),g(y))} which corresponds to an affine surface in A C 4 {\displaystyle \mathbb {A} _{\mathbb {C} }^{4}} if f and g are not zero.
Given R {\displaystyle R} -algebras A {\displaystyle A} and B {\displaystyle B} whose underlying rings are graded-commutative rings, the tensor product A ⊗ R B {\displaystyle A\otimes _{R}B} becomes a graded commutative ring by defining ( a ⊗ b ) ( a ′ ⊗ b ′ ) = ( − 1 ) | b | | a ′ | a a ′ ⊗ b b ′ {\displaystyle (a\otimes b)(a'\otimes b')=(-1)^{|b||a'|}aa'\otimes bb'} for homogeneous a {\displaystyle a} , a ′ {\displaystyle a'} , b {\displaystyle b} , and b ′ {\displaystyle b'} .
The tensor product of two matrix algebras is M m ( A ) ⊗ A M n ( A ) ≅ M m n ( A ) {\displaystyle M_{m}(A)\otimes {A}M{n}(A)\cong M_{mn}(A)} , the isomorphism given by extending the Kronecker product of two matrices via the universal property.
See also
[ edit]
Extension of scalars
Tensor product of modules
Tensor product of fields
Linearly disjoint
Multilinear subspace learning
Notes
[ edit]
^ Kassel (1995), p. 32.
^ Lang 2002, pp. 629–630.
^ Kassel (1995), p. 32.
^ Kassel (1995), p. 32.
References
[ edit]
Kassel, Christian (1995), Quantum groups, Graduate texts in mathematics, vol. 155, Springer, ISBN 978-0-387-94370-1 .
Lang, Serge (2002) [first published in 1993]. Algebra. Graduate Texts in Mathematics. Vol. 21. Springer. ISBN 0-387-95385-X . 
Retrieved from " https://en.wikipedia.org/w/index.php?title=Tensor_product_of_algebras&oldid=1351427379"
Categories:
Algebras
Ring theory
Commutative algebra
Multilinear algebra
Hidden categories:
Articles with short description
Short description matches Wikidata
All articles with unsourced statements
Articles with unsourced statements from October 2015
This page was last edited on 27 April 2026, at 21:44 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policy
About Wikipedia
Disclaimers
Contact Wikipedia
Legal & safety contacts
Code of Conduct
Developers
Statistics
Cookie statement
Mobile view
Search
Search [-]
Toggle the table of contents
Tensor product of algebras
3 languages Add topic 