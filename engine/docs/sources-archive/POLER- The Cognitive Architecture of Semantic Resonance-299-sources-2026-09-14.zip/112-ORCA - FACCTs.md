> Source: https://www.faccts.de/orca/

ORCA - FACCTs
Contact us
Toggle main menu
Products Show submenu
ORCA
WEASEL
Services
About Show submenu
FACCTs
Team
Publications
Projects
Careers
News
Documentation Show submenu
ORCA
WEASEL
OPI
Downloads
Contact
FACCTs Bluesky profile FACCTs LinkedIn profile FACCTs YouTube profile FACCTs Mastodon profile FACCTs Instagram profile FACCTs Threads profile
Toggle accessibility preferences
Toggle Background Toggle Contrast Toggle
Visual Tab 
Orca Features Documentation Get Orca
Orca
ORCA is a powerful and versatile quantum chemistry software package, primarily developed by the group of Prof. Frank Neese. It is free for academic use, while commercial licenses are available through FACCTs. ORCA is also the computational engine inside our workflow tool WEASEL. 
Cutting edge
ORCA provides cutting-edge methods in the field of electronic structure theory, including density functional- as well as correlated wave function-based methods.
With a strong user base of more than 100000 registered users in academia worldwide, ORCA is the fastest-growing quantum chemistry software package to date. 
Fast & accurate
We put great effort in making accurate calculations as fast as possible, and ORCA is known to be among the fastest quantum chemistry codes.
Some developments such as the DLPNO and RIJCOSX schemes can speed up calculations by orders of magnitude and even lead to a linear-scaling increase in timing with respect to system size. 
Complete
ORCA is a multi-purpose quantum chemistry software package. It features a wide variety of methods ranging from semi-empirical methods to density functional theory to correlated single- and multi-reference wave function-based methods. Environmental as well as relativistic effects can be taken into account.
We have the leading software tool in the calculation of molecular properties, and offer a native molecular dynamics module as well as a native QM/MM module for large-scale systems. 
Easy-to-use
ORCA is designed and developed with attention to both users and their teams. Computational chemists and physicists work hand in hand with spectroscopists and bench chemists to develop a software that is suited and beneficial for all.
267 +
Citations per year
300 +
Forum posts per year
6.667 +
Registered academic users
4 +
Industry partners
Features
DLPNO-CCSD(T) Using ORCA's DLPNO-CCSD(T) it is possible to compute binding energies, reaction energies/rates, and other properties with an accurate, robust, and parameter-free quantum chemistry method! The DLPNO scheme reduces the computational cost of the problem, so that the calculations are affordable for systems with hundreds of atoms at a cost similar to DFT – but at much higher accuracy.
NEB-TS NEB-TS is our newest method to find reaction paths and transition states, starting from the structures of the reactant and product only. It is designed to run black box, and works successfully even for multi-bond forming/breaking mechanisms. Combined with our multiscale schemes, it can even be used to study reactions inside proteins!
RIJCOSX The RIJCOSX accelerates HF and hybrid-DFT calculations by huge factors – for some features by almost 100-fold – and it is available for all kinds of methods in ORCA.
DFT We have all kinds of modern DFT functionals implemented: LDA, GGA, meta-GGA and double-hybrids, including recent ones such as r 2 SCAN and ωB97M-V. The acceleration schemes such as DLPNO and RIJCOSX are available for the more accurate density functionals that require MP2 or HF-exchange, rendering accurate DFT calculations on large systems affordable.
QMMM AND ONIOM Our built-in QMMM and ONIOM modules allow for multilevel calculations in systems of any size. The methods are designed for easy setup/usage and are well integrated into all other ORCA modules. This way, all ORCA features can be used, which is particularly interesting for reactivity prediction and design in enzymes.
CRYSTAL-QMMM Our Crystal-QMMM features allow to use ORCA's accurate methods on solids. Spectroscopic properties and band gaps can be computed for semiconductors, insulators as well as molecular crystals.
ACCURATE EXCITED STATES ORCA was designed from its very begining to deal with complicated electronic structures, and excited states are no exception. We have single and multireference methods, including TD-DFT for regular and double-hybrid functionals, EOM- and STEOM-CCSD, as well as CASSCF with NEVPT2 or CASPT2. All these profit significantly from the RIJCOSX and DLPNO schemes.
EXCITED STATE DYNAMICS The ORCA_ESD module was designed to predict more realistic, vibronically-resolved UV/Vis, Fluorescence, Phosphorescence and resonant Raman spectra. Using the same approach it is also possible to compute photophysical rate constants for these processes. Thus, it is possible to estimate quantum yields of Fluorescence, Phosphorescence, and ISC.
MULTIREFERENCE ORCA provides a broad variety of highly accurate multireference methods, such as CASSCF/NEVPT2, MRCI, MRCC and even FCI We make sure they are as easy as possible to use and included all the nice RIJCOSX and DLPNO acceleration schemes to bring down the timings.
ORCA PYTHON INTERFACE The ORCA Python Interface (OPI) is a Python library to create input and parse output of ORCA. It is designed as an open source community effort to make ORCA calculations as accessible as possible. The project is located at GitHub ( Documentation).
Documentation
In addition to the extensive user manual, we provide step-by-step tutorials for common use cases.
ORCA Forum Tutorials Manual
Get started with ORCA
ORCA is and will remain free for academic and personal use. If you qualify, you can download the latest Linux version from our Downloads section. All other versions can be obtained at: orcaforum.kofo.mpg.de
For a commercial license or a free trial, please use our contact form.
CONTACT US 
Products
ORCA
WEASEL
Services
News
About
Documentation
Downloads
Contact
Customers for registered users
Subscribe to our newsletter
Email
Subscribe
By entering your email address, you agree to receive our newsletter. After registration you will receive an email with a confirmation link which you must click to receive the newsletter. You can unsubscribe at any time by using the link directly in the newsletter. We use the service Cleverreach. You can find more detailed information in our privacy policy.
© 2026 FACCTs
Imprint
Privacy policy
Accessibility Statement
FACCTs Bluesky profile FACCTs LinkedIn profile FACCTs YouTube profile FACCTs Mastodon profile FACCTs Instagram profile FACCTs Threads profile
This button closes the dialog. Its functionality is identical to the Accept only essential cookies button. 
Privacy Preference
We need your consent before you can continue on our website.
We use cookies and other technologies on our website. Some of them are essential, while others help us to improve this website and your experience.
There is no obligation to consent to the processing of your data in order to use this offer.
You can revoke or adjust your selection at any time under Settings.
Please note that based on individual settings not all functions of the site may be available.
The following is a list of service groups for which consent can be given. The first service group is essential and cannot be unchecked.
[x] Essential [-] Statistics
Accept all cookies
Accept only essential cookies
Individual Privacy Preferences
Save Consent
Preferences Privacy Policy Imprint