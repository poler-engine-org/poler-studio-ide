> Source: https://www.ameslab.gov/gamess-open-source-quantum-chemistry-software

GAMESS: Open Source Quantum Chemistry Software | Ames Laboratory
Skip to main content
Our Science
Research Divisions
Chemical & Biological Sciences
Materials Sciences & Engineering
Simulation, Modeling & Decision Science
Critical Materials
Research Programs
CATS Center for the Advancement of Topological Semimetals
CMI Critical Materials Innovation Hub
iCOUP Institute for Cooperative Upcycling of Plastics
ML-Accelerated Materials Discovery Center Machine Learning Accelerated Materials Discovery Center
Staff Directory
Research Highlights
Services & Resources
Contact Us
Work With Us
Work With Us
Partnerships and Technology Transfer Through multi-institutional collaborations, industry partnerships, and technology licensing, we transition basic energy science from early-stage research to commercialization.
Materials Preparation Center Purification, preparation, and characterization of metals, alloys, and single crystals for research and industry.
Sensitive Instrument Facility Houses state-of-the-art electron microscopes in a vibration- and static-free environment for the highest possible resolution.
Procurement
Careers & Internships
Contact Us
News
News
Ames Lab News
News Releases
Feature Stories
Ames Lab in the News
Media Contacts
Research Highlights
Follow us on Twitter
Follow us on Facebook
About Us
About Us
About Ames Laboratory
Mission & Values
Leadership
Our Organization
History
Visit Ames Laboratory
Education Programs
Careers & Internships
Staff Directory
Contact Us
Toggle search form visibility 
Search Search
Toggle navigation
Search Search
Our Science Back
Our Science
Chemical & Biological Sciences
Material Sciences & Engineering
Simulation, Modeling & Decision Science
Critical Materials
Center for the Advancement of Topological Semimetals (CATS)
Critical Materials Innovation Hub
Institute for Cooperative Upcycling of Plastics (iCOUP)
Machine Learning Accelerated Materials Discovery Center
About Us Back
About Us
About Ames Laboratory
Mission & Values
Leadership
Our Organization
History
Visit Ames Lab
Work With Us Back
Work With Us
Partnerships & Technology Transfer
Materials Preparation Center
Sensitive Instrument Facility
News Back
News
News
News Releases
Feature Stories
In the News
Media Contacts
Education Programs
Careers & Internships
Staff Directory
Contact Us
GAMESS: Open Source Quantum Chemistry Software
GAMESS, or General Atomic and Molecular Electronic Structure System, is a general purpose electronic structure code for computational chemistry. Its primary focus is on ab initio quantum chemistry calculations. The software can also do density functional theory calculations and other semi-empirical calculations (Austin Model 1, Parameterization Model 3), quantum mechanics/molecular mechanics (QM/MM) calculations, and can handle solvent effects. GAMESS has several fragmentation methods that can scale to as many as 260,000 cores, so users can apply GAMESS to very large molecular species.
GAMESS has 150,000 users in over 100 countries. The software is developed by Ames Laboratory scientist Mark Gordon, who is also the Francis M. Craig Distinguished Professor of Chemistry at Iowa State University, along with many members of his group and colleagues around the world.
GAMESS runs on nearly all computer systems, from large parallel systems to workstations to desktops to laptops, in scalar or parallel fashion. A site license for GAMESS is available at no cost to both academic and industrial users.
For more information, visit the GAMESS Website.
For Researchers
Chemical & Biological Sciences
Materials Sciences & Engineering
Simulation, Modeling & Decision Science
Critical Materials
Services and Resources
Research Highlights
For Industry
Work with Us
Services and Resources
Materials Preparation Center
For the Public
About Us
Visit Ames Lab
Education Programs
News
Careers
Contact Us
For Employees
Privacy and Security
DOE Contract
DOE Vulnerability Disclosure Program
LinkedIn
Youtube
Facebook
Instagram
Ames National Laboratory is operated for the U.S. Department of Energy by Iowa State University.