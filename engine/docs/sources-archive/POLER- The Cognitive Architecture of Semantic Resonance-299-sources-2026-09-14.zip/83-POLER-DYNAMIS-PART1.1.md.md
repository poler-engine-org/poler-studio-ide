================================================================================FILE: CMakeLists.txt
cmake_minimum_required (VERSION 3.15) project (cint C) set(cint_VERSION_MAJOR "6") set(cint_VERSION_MINOR "1") set(cint_VERSION_PATCH "3") set(cint_VERSION_TWEAK "0") set(cint_VERSION "{cint_VERSION_MAJOR}.{cint_VERSION_MINOR}.{cint_VERSION_PATCH}")
set(cint_SOVERSION "{cint_VERSION_MAJOR}")
if ("${CMAKE_BUILD_TYPE}" STREQUAL "") set(CMAKE_BUILD_TYPE RELWITHDEBINFO) message("Build type RELWITHDEBINFO") else() message("Build type ${CMAKE_BUILD_TYPE}") endif() set(CMAKE_VERBOSE_MAKEFILE OFF)
option(BUILD_MARCH_NATIVE "gcc flag -march=native" off) if (BUILD_MARCH_NATIVE) include(CheckCCompilerFlag) CHECK_C_COMPILER_FLAG("-march=native" COMPILER_SUPPORTS_MARCH_NATIVE) if(COMPILER_SUPPORTS_MARCH_NATIVE) if ("{CMAKE_C_COMPILER_ID}" STREQUAL "Intel")
message("Add CFLAGS -march=native -unroll-aggressive")
set(CMAKE_C_FLAGS "{CMAKE_C_FLAGS} -unroll-aggressive -ipo") set(CMAKE_C_FLAGS "{CMAKE_C_FLAGS} -fno-math-errno")
else()
message("Add CFLAGS -march=native -ftree-vectorize")
set(CMAKE_C_FLAGS "{CMAKE_C_FLAGS} -march=native -funroll-loops -ftree-vectorize") set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -fno-math-errno") endif() endif() endif()
#set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -g -O2 -DNDEBUG")
set(CMAKE_C_STANDARD 99)
include(GNUInstallDirs) #set(CMAKE_INCLUDE_CURRENT_DIR ON)
list(APPEND CMAKE_MODULE_PATH "${PROJECT_SOURCE_DIR}/cmake") find_package(QUADMATH) if(QUADMATH_FOUND) set(HAVE_QUADMATH_H 1 CACHE INTERNAL "Have QUADMATH") endif()
include(CheckFunctionExists) set(CMAKE_REQUIRED_INCLUDES math.h) set(CMAKE_REQUIRED_LIBRARIES m) check_function_exists(expl HAVE_EXPL) check_function_exists(sqrtl HAVE_SQRTL) #set(CMAKE_REQUIRED_INCLUDES quadmath.h) #set(CMAKE_REQUIRED_LIBRARIES quadmath) #check_function_exists(fabsq HAVE_QUADMATH_H)
configure_file( "{PROJECT_SOURCE_DIR}/src/cint_config.h.in"
"{PROJECT_BINARY_DIR}/src/cint_config.h")
configure_file( "{PROJECT_SOURCE_DIR}/include/cint.h.in"
"{PROJECT_BINARY_DIR}/include/cint.h")
set(cintSrc src/c2f.c src/cart2sph.c src/cint1e.c src/cint2e.c src/cint_bas.c src/fblas.c src/g1e.c src/g2e.c src/misc.c src/optimizer.c src/fmt.c src/rys_wheeler.c src/eigh.c src/rys_roots.c src/find_roots.c src/cint2c2e.c src/g2c2e.c src/cint3c2e.c src/g3c2e.c src/cint3c1e.c src/g3c1e.c src/breit.c src/cint1e_a.c src/cint3c1e_a.c src/cint1e_grids.c src/g1e_grids.c src/autocode/breit1.c src/autocode/dkb.c src/autocode/gaunt1.c src/autocode/grad1.c src/autocode/grad2.c src/autocode/hess.c src/autocode/int3c1e.c src/autocode/int3c2e.c src/autocode/intor1.c src/autocode/intor2.c src/autocode/intor3.c src/autocode/intor4.c src/autocode/deriv3.c src/autocode/int1e_grids1.c src/autocode/deriv4.c src/autocode/lresc.c)
#option(WITH_RANGE_COULOMB "Range separated Coulomb" on) if(WITH_RANGE_COULOMB)
defined in cint_config.h
add_definitions(-DWITH_RANGE_COULOMB)
message("Enabled WITH_RANGE_COULOMB")
endif(WITH_RANGE_COULOMB)
if(WITH_POLYNOMIAL_FIT) set(cintSrc ${cintSrc} src/polyfits.c src/sr_rys_polyfits.c) add_definitions(-DWITH_POLYNOMIAL_FIT) message("Enabled WITH_POLYNOMIAL_FIT") endif(WITH_POLYNOMIAL_FIT)
if(WITH_COULOMB_ERF) message("WITH_COULOMB_ERF is deprecated since v6.0") endif(WITH_COULOMB_ERF)
if(WITH_F12) set(cintSrc ${cintSrc} src/g2e_f12.c src/stg_roots.c src/cint2e_f12.c) add_definitions(-DWITH_F12) message("Enabled WITH_F12") endif(WITH_F12)
Gaussian type geminal code are incorrect
if(WITH_GTG)
set(cintSrc ${cintSrc} src/g2e_gtg.c src/cint2e_gtg.c src/cint3c2e_gtg.c
src/cint2c2e_gtg.c)
add_definitions(-DWITH_GTG)
message("Enabled WITH_GTG. Note there are bugs in gtg type integrals")
message("WITH_GTG is deprecated since v6.0") endif(WITH_GTG)
if(WITH_4C1E) set(cintSrc ${cintSrc} src/cint4c1e.c src/g4c1e.c) message("Enabled WITH_4C1E. Note there are bugs in 4c1e integral functions") endif(WITH_4C1E)
if(PYPZPX) add_definitions(-DPYPZPX) message("P orbitals convention (py, pz, px)") else() message("P orbitals convention (px, py, pz)") endif(PYPZPX)
if(MIN_EXPCUTOFF) message("Minimal cutoff in exponent for integral screening {MIN_EXPCUTOFF}")
add_definitions(-DMIN_EXPCUTOFF={MIN_EXPCUTOFF}) endif()
if(KEEP_GOING) message("Do not trigger hard exit for numerical issues in Rys quadrature") add_definitions(-DKEEP_GOING) endif()
option(WITH_FORTRAN "Fortran interface" on) if(WITH_FORTRAN) add_definitions(-DWITH_FORTRAN) message("Enable Fortran interface") else() message("Exclude Fortran interface") endif(WITH_FORTRAN)
option(WITH_CINT2_INTERFACE "Old libcint (version 2) interface" on) if(WITH_CINT2_INTERFACE) add_definitions(-DWITH_CINT2_INTERFACE) message("Enable old cint (version 2) interface") else() message("Exclude old cint (version 2) interface") endif(WITH_CINT2_INTERFACE)
option(BUILD_SHARED_LIBS "build shared libraries" 1) option(ENABLE_EXAMPLE "build examples" 0) option(ENABLE_TEST "build tests" 0) option(ENABLE_STATIC "Enforce static library build" 0) if(QUICK_TEST) set(RUN_QUICK_TEST --quick) endif()
if(ENABLE_STATIC) set(BUILD_SHARED_LIBS 0) endif()
set(CintHeaders ${PROJECT_SOURCE_DIR}/include/cint_funcs.h ${PROJECT_BINARY_DIR}/include/cint.h)
add_library(cint ${cintSrc})
target_include_directories(cint PUBLIC <BUILD_INTERFACE:{PROJECT_BINARY_DIR}/include> <INSTALL_INTERFACE:{CMAKE_INSTALL_INCLUDEDIR}> PRIVATE ${PROJECT_BINARY_DIR}/src ${PROJECT_SOURCE_DIR}/src )
set_target_properties(cint PROPERTIES VERSION ${cint_VERSION} SOVERSION ${cint_SOVERSION} LIBRARY_OUTPUT_DIRECTORY ${PROJECT_BINARY_DIR}) if(QUADMATH_FOUND) target_link_libraries(cint quadmath) endif() target_link_libraries(cint "-lm")
install(TARGETS cint COMPONENT "lib") install(FILES ${CintHeaders} DESTINATION ${CMAKE_INSTALL_INCLUDEDIR} COMPONENT "dev")
if(ENABLE_EXAMPLE) enable_language(Fortran) find_package(OpenMP) if(OPENMP_FOUND) set(HAVE_OPENMP 1) else () set(OpenMP_C_FLAGS " ") endif() add_subdirectory(examples) endif()
if(BUILD_SHARED_LIBS AND ENABLE_TEST) find_package(PythonInterp) message(STATUS "Found python  ${PYTHON_EXECUTABLE}") if(PYTHONINTERP_FOUND) enable_testing() add_test(NAME cinttest COMMAND ${PYTHON_EXECUTABLE} ${PROJECT_SOURCE_DIR}/testsuite/test_cint.py ${RUN_QUICK_TEST}) add_test(NAME cint3c2etest COMMAND ${PYTHON_EXECUTABLE} ${PROJECT_SOURCE_DIR}/testsuite/test_3c2e.py ${RUN_QUICK_TEST}) endif() endif()
include(CPackComponent)
set(CPACK_PACKAGE_CHECKSUM "SHA512") set(CPACK_GENERATOR "DEB") set(CPACK_DEBIAN_COMPRESSION_TYPE "xz") set(CPACK_PACKAGE_VENDOR "Qiming @sunqm Sun") set(CPACK_PACKAGE_CONTACT "https://github.com/sunqm/libcint") set(CPACK_PACKAGE_HOMEPAGE_URL "https://github.com/sunqm/libcint") set(CPACK_RESOURCE_FILE_LICENSE "{PROJECT_SOURCE_DIR}/LICENSE")
set(CPACK_RESOURCE_FILE_README "{PROJECT_SOURCE_DIR}/README.rst") set(CPACK_PACKAGE_DESCRIPTION_FILE "${PROJECT_SOURCE_DIR}/doc/libcint.CPack.txt")
set(CPACK_PACKAGE_VERSION_MAJOR "{cint_VERSION_MAJOR}")
set(CPACK_PACKAGE_VERSION_MINOR "{cint_VERSION_MINOR}") set(CPACK_PACKAGE_VERSION_PATCH "{cint_VERSION_PATCH}")
set(CPACK_PACKAGE_VERSION_TWEAK "{cint_VERSION_TWEAK}")
set(CPACK_COMPONENTS_GROUPING "IGNORE")
set(CPACK_MONOLITHIC_INSTALL OFF) set(CPACK_DEB_COMPONENT_INSTALL ON) set(CPACK_RPM_COMPONENT_INSTALL ON) set(CPACK_NSIS_COMPONENT_INSTALL ON)
set("CPACK_DEBIAN_LIB_PACKAGE_NAME" "libcint") set("CPACK_DEBIAN_DEV_PACKAGE_NAME" "${CPACK_DEBIAN_LIB_PACKAGE_NAME}-dev")
set(CPACK_DEBIAN_LIB_PACKAGE_DEPENDS "libopenblas0-pthread") set(CPACK_DEBIAN_DEV_PACKAGE_DEPENDS "{CPACK_DEBIAN_LIB_PACKAGE_NAME},libopenblas-pthread-dev")
if(HAVE_QUADMATH)
set(CPACK_DEBIAN_LIB_PACKAGE_DEPENDS "{CPACK_DEBIAN_LIB_PACKAGE_DEPENDS},libquadmath0") endif()
set(CPACK_COMPONENTS_GROUPING "IGNORE")
include(CPack)
================================================================================FILE: POLER-Quantum-CANONICAL.md
POLER-Quantum — Канонически замкнутая версия
S(p) = Π_Λ(J − D)Π_Λ — оператор динамики, фильтрующий силы через логический проектор Π_Λ, резонанс J и диссипацию D.
Архив: POLER-Quantum-canonical.zip (36 КБ)
--------------------------------------------------------------------------------
Содержание
poler_core.py — Каноническое ядро
poler_qbridge.py — Мост Qiskit ↔ POLER
POLER_losses.py — Функционалы F, ε, L
POLER_logic_test.py — Тест «Логика vs Физика»
POLER_vs_Standard.py — Сравнение в шуме
POLER_sim.py — Mode A: базовый 2-кубитный контур
POLER_modeB.py — Mode B: Rz(γ)
POLER_modeC.py — Mode C: адаптивный γ
POLER_loop.py — Замкнутый цикл оптимизации κ
POLER_quantum_formula.py — VQE-подобная система
POLER_Psi_v3.py — Ψ-поле (классы)
poler_gravity.py — Гравитация на «логической массе»
poler_proof.py — SymPy-доказательство законов Кеплера
poler_universe/ — ООП-модуль «вселенной»
run_evolution.py — Genesis-симуляция
save_results.py — Утилита для GitHub Actions
requirements.txt
results/loss_history.csv
.github/workflows/
POLER_Attention_Core.md
--------------------------------------------------------------------------------
1. poler_core.py
--------------------------------------------------------------------------------
2. poler_qbridge.py
--------------------------------------------------------------------------------
3. POLER_losses.py
--------------------------------------------------------------------------------
4. POLER_logic_test.py
--------------------------------------------------------------------------------
5. POLER_vs_Standard.py
--------------------------------------------------------------------------------
6. POLER_sim.py
--------------------------------------------------------------------------------
7. POLER_modeB.py
--------------------------------------------------------------------------------
8. POLER_modeC.py
--------------------------------------------------------------------------------
9. POLER_loop.py
--------------------------------------------------------------------------------
10. POLER_quantum_formula.py
--------------------------------------------------------------------------------
11. POLER_Psi_v3.py
--------------------------------------------------------------------------------
12. poler_gravity.py
--------------------------------------------------------------------------------
13. poler_proof.py
--------------------------------------------------------------------------------
14. poler_universe/
poler_universe/__init__.py
poler_universe/core.py
poler_universe/logic.py
poler_universe/resonance.py
poler_universe/weavers.py
--------------------------------------------------------------------------------
15. run_evolution.py
--------------------------------------------------------------------------------
16. save_results.py
--------------------------------------------------------------------------------
17. requirements.txt
--------------------------------------------------------------------------------
18. results/loss_history.csv
--------------------------------------------------------------------------------
19. .github/workflows/
.github/workflows/simulate.yml
.github/workflows/simulate_extended.yml
--------------------------------------------------------------------------------
20. POLER_Attention_Core.md
POLER Attention Core (v3.0-Closed)
1. System Overview
POLER[n] — не модуль, а ядро уваги, що працює між сенсорним шаром Ω(o_t) і рішенням p_{t+1}. Воно з'єднує фізику даних (Free Energy) з логікою рішень (Projection Π_Λ).
Pipeline: Ω(o_t) → F(p,o;θ) → Π_Λ → ε → R[n] → S(p) → p_{t+1}
--------------------------------------------------------------------------------
2. Основні компоненти
--------------------------------------------------------------------------------
3. Потоки уваги
Forward pass (Perception):
Resonance pass (Memory):
Canonical form (closed):
where S(p) = Π_Λ(J − D)Π_Λ and L = F − γ Σ w_k ε_k.
================================================================================FILE: POLER_DYNAMIS_Complete.md
POLER[DYNAMIS] — Complete Module Documentation
POLER: Pattern-Oriented Latent Evolutionary Resonance
Dissipative quantum dynamics module for PySCF, replacing rigid Fock diagonalization with gradient flow on the free energy landscape.
--------------------------------------------------------------------------------
Mathematical Foundations
Canonical Equation of Motion (POLER Core)
The fundamental state update equation combines dissipative (descent to minimum), resonance (memory), and logical forces:
Where:
eta(t): Adaptive step size
Pi_Lambda: Causality projector (logical constraint)
D = L*L^T: Dissipation operator (descent into reality attractor)
J = A - A^T: Skew-symmetric resonance operator (energy echo of past states)
gamma: Adaptive resonance coefficient
Free Energy and Entropy
Free Energy: F = kappa * ||g(p) - Omega(o)||_G^2 + lambda * R_L(p)
Entropy Homeostasis: S = -sum(p * log(p)) / log(D)
Adaptive Step: eta(t) = eta_0 * exp(-beta_sigma * Sigma(t))
Adaptive Resonance: gamma(t) = gamma_0 * exp(-alpha_sigma * Sigma(t))
Quantum Projection (For Density Matrices)
In the PySCF quantum chemistry context, where p is the density matrix P:
McWeeny Purification: P_new = 3P^2 - 2P^3 (restores idempotency P^2 = P)
Pi_Lambda Projector: Ensures electron number conservation, hermiticity, core orbital protection
--------------------------------------------------------------------------------
Architecture
The POLER module is built around three key components:
1. PolerEvolution (evolution.py) — Stateful Evolution Engine
Stores history of past density matrices for temporal echo R[n] — the resonance contribution that allows the system to "remember" previous states and escape local minima.
Each sub-step of evolution includes:
DIIS gradient computation (FPS - SPF)
Projection through Pi_Lambda (causality projector)
Dissipative + resonance correction
Adaptive step with backtracking — if energy increases, step is automatically reduced
McWeeny purification for idempotency restoration
Key methods:
evolve(dm, J_strength, D_strength, gamma_eps, steps) — main entry point
_compute_resonance(dm_current, gamma_t) — temporal echo R[n]
_update_sigma(dm_current) — topological curvature tracking
2. Purification & Projection (purification.py)
Two critical mechanisms for maintaining physicality:
Pi_Lambda_projector: Projects gradient to satisfy electron number conservation, hermiticity, and core orbital protection
robust_purify: Idempotency restoration through natural orbital analysis (eigenvalue projection), more robust than McWeeny iterations
3. Wrapper (wrapper.py) — apply_poler()
Seamless PySCF integration without modifying library source code. The "POLER kick" approach: after standard Fock diagonalization, apply dissipative-resonance correction. If correction raises energy beyond threshold, it is discarded.
--------------------------------------------------------------------------------
Test Results
H2/STO-3G: Potential Energy Surface Scan
Scanning interatomic distance from 0.5 to 3.5 Angstrom with POLER parameters: J=0.5, D=0.1, gamma=0.1, steps=10.
Key Results:
POLER matches DIIS to precision ~1e-15 Hartree across all distances (0.5-3.5 A)
Both methods converge correctly at equilibrium geometry and stretched configurations
Energy backtracking mechanism prevents POLER from entering unphysical states
N2/STO-3G: Multi-Electron Validation
POLER reproduces DIIS result: E = -107.4965 Ha
Confirms dissipative dynamics works for systems with more complex electronic structure
Stability
The backtracking mechanism in PolerEvolution guarantees that no POLER step leads to unphysical energy increase. If after updating the density matrix the energy rises beyond threshold (1e-8 Ha for sub-steps, 0.05 Ha for main cycle), the step is rejected and the system continues with standard Fock diagonalization.
--------------------------------------------------------------------------------
Source Code
--------------------------------------------------------------------------------
Interactive Visualization
The file poler_dynamics_viz.html provides real-time observation of:
Phase space trajectory (dissipation + resonance forces)
Energy convergence
Density matrix eigenvalues
Topological curvature Sigma(t)
Parameters adjustable in real-time: D (dissipation), J (resonance), eta (step), rho (memory), dimension.
--------------------------------------------------------------------------------
Experiment Parameters
--------------------------------------------------------------------------------
Extracted and reconstructed from POLER archive documents 54, 55, 56, 60, 106.
================================================================================FILE: POLER_DYNAMIS_Independence_Analysis.pdf  [SKIPPED: PDF document, version 1.4, 10 page(s)]
================================================================================FILE: POLER_DYNAMIS_Independence_Analysis_Report.pdf  [SKIPPED: PDF document, version 1.4, 17 page(s)]
================================================================================FILE: POLER_DYNAMIS_Independence_Report_Final.pdf  [SKIPPED: PDF document, version 1.4, 18 page(s)]
================================================================================FILE: POLER_UNIFIED_ALGORITHM.md
POLER[Ψ] — 14 Канонических Уравнений
Каноническое уравнение движения
14 Механизмов
М1. McWeeny Purification (Π_Λ)
Проекция на многообразие Грассмана. Для RHF: occ_max = 2.
М2. Идемпотентный диссипатор (Δ_idem)
Стягивает DM к idempotent точке DM² = occ_max·DM.
М3. Орбитальный градиент (K)
Мера нарушения условия стационарности. K→0 при сходимости.
М4. Резонанс (J)
Заменяет DIIS. Создаёт конструктивную интерференцию.
М5. Адаптивный η
EMA-сглаженный surprise управляет скоростью потока.
М6. Свободная энергия
Электронная энергия. Монотонно убывает при правильном потоке.
М7. Критерий сходимости
Орбитальный градиент → machine zero.
М8. Фаза 1 (Bootstrap)
Большие η аппроксимируют стандартный SCF-шаг.
М9. Фаза 2 (POLER-flow)
Диссипативный спуск по энергии с McWeeny-проекцией.
М10. Сохранение числа электронов
Рескейлинг DM после каждого шага.
М11. Симметризация
DM всегда эрмитова.
М12. occ_max = 2.0 для RHF
Стандарт для Restricted Hartree-Fock.
М13. d = idem_strength
Сила идемпотентного диссипатора. Типично 0.1–1.0.
М14. γ = resonance_coupling
Сила резонансной связи. Типично 0.01–0.1.
Реализация на Rust
energy_engine.rs — все 14 механизмов
faer::Mat<f64> — линейная алгебра
Двухфазная стратегия в PolerEngine::run()
14 тестов покрывают все уравнения
================================================================================FILE: README.md
POLER-DYNAMIS v5
Канонический движок квантовой химии — заменяет SCF/DIIS на уравнение движения:
Структура проекта
Сборка Rust
Зависимости
faer 0.19 — линейная алгебра (f64)
pyo3 0.22 — Python bindings
rayon 1.10 — параллелизм
diffsol 0.4 — ODE интеграция
Что дальше
Подключить libcint через FFI (заглушки → реальные вызовы)
Валидация: 7 молекул (H₂, He, LiH, H₂O, N₂, CH₄, CO)
GPU-ускорение через burn
================================================================================FILE: basis/6-31G.dat
6-31G  EMSL  Basis Set Exchange Library  9/15/14 7:28 AM
Elements                             References
--------                             ----------
H - He: W.J. Hehre, R. Ditchfield and J.A. Pople, J. Chem. Phys. 56,
Li - Ne: 2257 (1972).  Note: Li and B come from J.D. Dill and J.A.
Pople, J. Chem. Phys. 62, 2921 (1975).
Na - Ar: M.M. Francl, W.J. Petro, W.J. Hehre, J.S. Binkley, M.S. Gordon,
D.J. DeFrees and J.A. Pople, J. Chem. Phys. 77, 3654 (1982)
K  - Zn: V. Rassolov, J.A. Pople, M. Ratner and T.L. Windus, J. Chem. Phys.
109, 1223 (1998)
Note: He and Ne are unpublished basis sets taken from the Gaussian
program
BASIS "ao basis" PRINT #BASIS SET: (4s) -> [2s] H    S 18.7311370              0.03349460
2.8253937              0.23472695
0.6401217              0.81375733
H    S 0.1612778              1.0000000
#BASIS SET: (4s) -> [2s] He    S 38.4216340              0.0237660
5.7780300              0.1546790
1.2417740              0.4696300
He    S 0.2979640              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] Li    S 642.4189200              0.0021426
96.7985150              0.0162089
22.0911210              0.0773156
6.2010703              0.2457860
1.9351177              0.4701890
0.6367358              0.3454708
Li    SP 2.3249184             -0.0350917              0.0089415
0.6324306             -0.1912328              0.1410095
0.0790534              1.0839878              0.9453637
Li    SP 0.0359620              1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] Be    S 1264.5857000              0.0019448
189.9368100              0.0148351
43.1590890              0.0720906
12.0986630              0.2371542
3.8063232              0.4691987
1.2728903              0.3565202
Be    SP 3.1964631             -0.1126487              0.0559802
0.7478133             -0.2295064              0.2615506
0.2199663              1.1869167              0.7939723
Be    SP 0.0823099              1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] B    S 2068.8823000              0.0018663
310.6495700              0.0142515
70.6830330              0.0695516
19.8610800              0.2325729
6.2993048              0.4670787
2.1270270              0.3634314
B    SP 4.7279710             -0.1303938              0.0745976
1.1903377             -0.1307889              0.3078467
0.3594117              1.1309444              0.7434568
B    SP 0.1267512              1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] C    S 3047.5249000              0.0018347
457.3695100              0.0140373
103.9486900              0.0688426
29.2101550              0.2321844
9.2866630              0.4679413
3.1639270              0.3623120
C    SP 7.8682724             -0.1193324              0.0689991
1.8812885             -0.1608542              0.3164240
0.5442493              1.1434564              0.7443083
C    SP 0.1687144              1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] N    S 4173.5110000              0.0018348
627.4579000              0.0139950
142.9021000              0.0685870
40.2343300              0.2322410
12.8202100              0.4690700
4.3904370              0.3604550
N    SP 11.6263580             -0.1149610              0.0675800
2.7162800             -0.1691180              0.3239070
0.7722180              1.1458520              0.7408950
N    SP 0.2120313              1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] O    S 5484.6717000              0.0018311
825.2349500              0.0139501
188.0469600              0.0684451
52.9645000              0.2327143
16.8975700              0.4701930
5.7996353              0.3585209
O    SP 15.5396160             -0.1107775              0.0708743
3.5999336             -0.1480263              0.3397528
1.0137618              1.1307670              0.7271586
O    SP 0.2700058              1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] F    S 7001.7130900              0.0018196169
1051.3660900              0.0139160796
239.2856900              0.0684053245
67.3974453              0.233185760
21.5199573              0.471267439
7.40310130             0.356618546
F    SP 20.8479528             -0.108506975            0.0716287243
4.80830834            -0.146451658            0.3459121030
1.34406986             1.128688580            0.7224699570
F    SP 0.358151393            1.0000000              1.0000000
#BASIS SET: (10s,4p) -> [3s,2p] Ne    S 8425.8515300              0.0018843481
1268.5194000              0.0143368994
289.6214140              0.0701096233
81.8590040              0.2373732660
26.2515079              0.4730071260
9.09472051             0.3484012410
Ne    SP 26.5321310             -0.107118287            0.0719095885
6.10175501            -0.146163821            0.3495133720
1.69627153             1.127773500            0.7199405120
Ne    SP 0.44581870             1.0000000              1.0000000
#BASIS SET: (16s,10p) -> [4s,3p] Na    S 9993.2000000              0.0019377
1499.8900000              0.0148070
341.9510000              0.0727060
94.6797000              0.2526290
29.7345000              0.4932420
10.0063000              0.3131690
Na    SP 150.9630000             -0.0035421              0.0050017
35.5878000             -0.0439590              0.0355110
11.1683000             -0.1097521              0.1428250
3.9020100              0.1873980              0.3386200
1.3817700              0.6466990              0.4515790
0.4663820              0.3060580              0.2732710
Na    SP 0.4979660             -0.2485030             -0.0230230
0.0843530             -0.1317040              0.9503590
0.0666350              1.2335200              0.0598580
Na    SP 0.0259544              1.0000000              1.0000000
#BASIS SET: (16s,10p) -> [4s,3p] Mg    S 11722.8000000              0.0019778
1759.9300000              0.0151140
400.8460000              0.0739110
112.8070000              0.2491910
35.9997000              0.4879280
12.1828000              0.3196620
Mg    SP 189.1800000             -0.0032372              0.0049281
45.2119000             -0.0410080              0.0349890
14.3563000             -0.1126000              0.1407250
5.1388600              0.1486330              0.3336420
1.9065200              0.6164970              0.4449400
0.7058870              0.3648290              0.2692540
Mg    SP 0.9293400             -0.2122900             -0.0224190
0.2690350             -0.1079850              0.1922700
0.1173790              1.1758400              0.8461810
Mg    SP 0.0421061              1.0000000              1.0000000
#BASIS SET: (16s,10p) -> [4s,3p] Al    S 13983.1000000              0.00194267
2098.7500000              0.0148599
477.7050000              0.0728494
134.3600000              0.2468300
42.8709000              0.4872580
14.5189000              0.3234960
Al    SP 239.6680000             -0.00292619             0.00460285
57.4419000             -0.0374080              0.0331990
18.2859000             -0.1144870              0.1362820
6.5991400              0.1156350              0.3304760
2.4904900              0.6125950              0.4491460
0.9445400              0.3937990              0.2657040
Al    SP 1.2779000             -0.2276060             -0.0175130
0.3975900              0.00144583             0.2445330
0.1600950              1.0927900              0.8049340
Al    SP 0.0556577              1.0000000              1.0000000
#BASIS SET: (16s,10p) -> [4s,3p] Si    S 16115.9000000              0.00195948
2425.5800000              0.01492880
553.8670000              0.07284780
156.3400000              0.24613000
50.0683000              0.48591400
17.0178000              0.32500200
Si    SP 292.7180000             -0.00278094             0.00443826
69.8731000             -0.03571460             0.03266790
22.3363000             -0.11498500             0.13472100
8.1503900              0.09356340             0.32867800
3.1345800              0.60301700             0.44964000
1.2254300              0.41895900             0.26137200
Si    SP 1.7273800             -0.24463000            -0.01779510
0.5729220              0.00431572             0.25353900
0.2221920              1.09818000             0.80066900
Si    SP 0.0778369              1.00000000             1.00000000
#BASIS SET: (16s,10p) -> [4s,3p] P    S 19413.3000000              0.0018516
2909.4200000              0.0142062
661.3640000              0.0699995
185.7590000              0.2400790
59.1943000              0.4847620
20.0310000              0.3352000
P    SP 339.4780000             -0.00278217             0.00456462
81.0101000             -0.0360499              0.03369360
25.8780000             -0.1166310              0.13975500
9.4522100              0.0968328              0.33936200
3.6656600              0.6144180              0.45092100
1.4674600              0.4037980              0.23858600
P    SP 2.1562300             -0.2529230             -0.01776530
0.7489970              0.0328517              0.27405800
0.2831450              1.0812500              0.78542100
P    SP 0.0998317              1.0000000              1.00000000
#BASIS SET: (16s,10p) -> [4s,3p] S    S 21917.1000000              0.0018690
3301.4900000              0.0142300
754.1460000              0.0696960
212.7110000              0.2384870
67.9896000              0.4833070
23.0515000              0.3380740
S    SP 423.7350000             -0.0023767              0.0040610
100.7100000             -0.0316930              0.0306810
32.1599000             -0.1133170              0.1304520
11.8079000              0.0560900              0.3272050
4.6311000              0.5922550              0.4528510
1.8702500              0.4550060              0.2560420
S    SP 2.6158400             -0.2503740             -0.0145110
0.9221670              0.0669570              0.3102630
0.3412870              1.0545100              0.7544830
S    SP 0.1171670              1.0000000              1.0000000
#BASIS SET: (16s,10p) -> [4s,3p] Cl    S 25180.1000000              0.0018330
3780.3500000              0.0140340
860.4740000              0.0690970
242.1450000              0.2374520
77.3349000              0.4830340
26.2470000              0.3398560
Cl    SP 491.7650000             -0.0022974              0.0039894
116.9840000             -0.0307140              0.0303180
37.4153000             -0.1125280              0.1298800
13.7834000              0.0450160              0.3279510
5.4521500              0.5893530              0.4535270
2.2258800              0.4652060              0.2521540
Cl    SP 3.1864900             -0.2518300             -0.0142990
1.1442700              0.0615890              0.3235720
0.4203770              1.0601800              0.7435070
Cl    SP 0.1426570              1.0000000              1.0000000
#BASIS SET: (16s,10p) -> [4s,3p] Ar    S 28348.3000000              0.00182526
4257.6200000              0.01396860
969.8570000              0.06870730
273.2630000              0.23620400
87.3695000              0.48221400
29.6867000              0.34204300
Ar    SP 575.8910000             -0.00215972             0.00380665
136.8160000             -0.02907750             0.02923050
43.8098000             -0.11082700             0.12646700
16.2094000              0.02769990             0.32351000
6.4608400              0.57761300             0.45489600
2.6511400              0.48868800             0.25663000
Ar    SP 3.8602800             -0.2555920             -0.01591970
1.4137300              0.0378066              0.32464600
0.5166460              1.0805600              0.74399000
Ar    SP 0.1738880              1.0000000              1.0000000
#BASIS SET: (22s,16p) -> [5s,4p] K    S 31594.4200000              1.828010E-03
4744.3300000              1.399403E-02
1080.4190000              6.887129E-02
304.2338000              2.369760E-01
97.2458600              4.829040E-01
33.0249500              3.404795E-01
K    SP 622.7625000             -2.502976E-03           4.094637E-03
147.8839000             -3.315550E-02           3.145199E-02
47.3273500             -1.226387E-01           1.351558E-01
17.5149500              5.353643E-02           3.390500E-01
6.9227220              6.193860E-01           4.629455E-01
2.7682770              4.345878E-01           2.242638E-01
K    SP 11.8480200              1.277689E-02          -1.221377E-02
4.0792110              2.098767E-01          -6.900537E-03
1.7634810             -3.095274E-03           2.007466E-01
0.7889270             -5.593884E-01           4.281332E-01
0.3503870             -5.134760E-01           3.970156E-01
0.1463440             -6.598035E-02           1.104718E-01
K    SP 0.7168010             -5.237772E-02           0.0316430
0.2337410             -2.798503E-01          -0.0404616
0.0386750              1.141547E+00           1.0120290
K    SP 0.0165210              1.000000E+00           1.00000000
#BASIS SET: (22s,16p) -> [5s,4p] Ca    S 35264.8600000              1.813501E-03
5295.5030000              1.388493E-02
1206.0200000              6.836162E-02
339.6839000              2.356188E-01
108.6264000              4.820639E-01
36.9210300              3.429819E-01
Ca    SP 706.3096000              2.448225E-03           4.020371E-03
167.8187000              3.241504E-02           3.100601E-02
53.8255800              1.226219E-01           1.337279E-01
20.0163800             -4.316965E-02           3.367983E-01
7.9702790             -6.126995E-01           4.631281E-01
3.2120590             -4.487540E-01           2.257532E-01
Ca    SP 14.1951800              1.084500E-02          -1.289621E-02
4.8808280              2.088333E-01          -1.025198E-02
2.1603900              3.150338E-02           1.959781E-01
0.9878990             -5.526518E-01           4.357933E-01
0.4495170             -5.437997E-01           3.996452E-01
0.1873870             -6.669342E-02           9.713636E-02
Ca    SP 1.0322710             -4.439720E-02          -0.4298621
0.3811710             -3.284563E-01           0.006935829
0.0651310              1.163010E+00           0.9705933
Ca    SP 0.0260100              1.000000E+00           1.00000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Sc    S 39088.9800000              1.803263E-03
5869.7920000              1.380769E-02
1336.9100000              6.800396E-02
376.6031000              2.347099E-01
120.4679000              4.815690E-01
40.9803200              3.445652E-01
Sc    SP 786.2852000              2.451863E-03           4.039530E-03
186.8870000              3.259579E-02           3.122570E-02
60.0093500              1.238242E-01           1.349833E-01
22.2588300             -4.359890E-02           3.424793E-01
8.8851490             -6.177181E-01           4.623113E-01
3.6092110             -4.432823E-01           2.177524E-01
Sc    SP 29.8435500             -2.586302E-03          -6.096652E-03
9.5423830              7.188424E-02          -2.628884E-02
4.0567900              2.503260E-01           5.091001E-02
1.7047030             -2.991003E-01           3.798097E-01
0.7062340             -7.446818E-01           5.170883E-01
0.2795360             -1.799776E-01           1.829772E-01
Sc    SP 1.0656090              6.482978E-02          -0.2938440
0.4259330              3.253756E-01           0.09235323
0.0763200             -1.170806E+00           0.9847930
Sc    SP 0.0295940              1.000000E+00           1.00000000
Sc    D 11.1470100              8.747672E-02
2.8210430              3.795635E-01
0.8196200              7.180393E-01
Sc    D 0.2214680              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Ti    S 43152.9500000              1.791872E-03
6479.5710000              1.372392E-02
1475.6750000              6.762830E-02
415.6991000              2.337642E-01
133.0006000              4.810696E-01
45.2722200              3.462280E-01
Ti    SP 874.6826000              2.431008E-03           4.017679E-03
207.9785000              3.233027E-02           3.113966E-02
66.8791800              1.242520E-01           1.349077E-01
24.8734700             -3.903905E-02           3.431672E-01
9.9684410             -6.171789E-01           4.625760E-01
4.0638260             -4.473097E-01           2.154603E-01
Ti    SP 33.6436300             -2.940358E-03          -6.311620E-03
10.8756500              7.163103E-02          -2.697638E-02
4.6282250              2.528915E-01           5.316847E-02
1.9501260             -2.966401E-01           3.845549E-01
0.8094520             -7.432215E-01           5.127662E-01
0.3204740             -1.853520E-01           1.811135E-01
Ti    SP 1.2241480              6.351465E-02          -0.2112070
0.4842630              3.151404E-01           0.07771998
0.0840960             -1.162595E+00           0.9898214
Ti    SP 0.0320360              1.000000E+00           1.00000000
Ti    D 13.6908500              8.589418E-02
3.5131540              3.784671E-01
1.0404340              7.161239E-01
Ti    D 0.2869620              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] V    S 47354.3300000              1.784513E-03
7110.7870000              1.366754E-02
1619.5910000              6.736122E-02
456.3379000              2.330552E-01
146.0606000              4.806316E-01
49.7579100              3.474802E-01
V    SP 968.1484000              2.410599E-03           3.995005E-03
230.2821000              3.207243E-02           3.104061E-02
74.1459100              1.245942E-01           1.347747E-01
27.6410700             -3.482177E-02           3.437279E-01
11.1147500             -6.167374E-01           4.628759E-01
4.5431130             -4.509844E-01           2.135547E-01
V    SP 37.6405000             -3.233199E-03          -6.494056E-03
12.2823800              7.130744E-02          -2.753453E-02
5.2333660              2.543820E-01           5.516284E-02
2.2089500             -2.933887E-01           3.879672E-01
0.9178800             -7.415695E-01           5.090258E-01
0.3634120             -1.909410E-01           1.803840E-01
V    SP 1.3927810              6.139703E-02          -0.1891265
0.5439130              3.061130E-01           0.08005453
0.0914760             -1.154890E+00           0.9877399
V    SP 0.0343120              1.000000E+00           1.00000000
V    D 16.0502500              8.599899E-02
4.1600630              3.802996E-01
1.2432650              7.127659E-01
V    D 0.3442770              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Cr    S 51789.8100000              1.776182E-03
7776.8490000              1.360476E-02
1771.3850000              6.706925E-02
499.1588000              2.323104E-01
159.7982000              4.802410E-01
54.4702100              3.487653E-01
Cr    SP 1064.3280000              2.399669E-03           3.986997E-03
253.2138000              3.194886E-02           3.104662E-02
81.6092400              1.250868E-01           1.350518E-01
30.4819300             -3.221866E-02           3.448865E-01
12.2943900             -6.172284E-01           4.628571E-01
5.0377220             -4.525936E-01           2.110426E-01
Cr    SP 41.5629100             -3.454216E-03          -6.722497E-03
13.6762700              7.218428E-02          -2.806471E-02
5.8443900              2.544820E-01           5.820028E-02
2.4716090             -2.934534E-01           3.916988E-01
1.0283080             -7.385455E-01           5.047823E-01
0.4072500             -1.947157E-01           1.790290E-01
Cr    SP 1.5714640              0.05892219            -0.1930100
0.6055800              0.2976055              0.0960562
0.0985610             -1.1475060              0.9817609
Cr    SP 0.0364590              1.000000E+00           1.0000000
Cr    D 18.4193000              8.650816E-02
4.8126610              3.826699E-01
1.4464470              7.093772E-01
Cr    D 0.4004130              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Mn    S 56347.1400000              1.771580E-03
8460.9430000              1.357081E-02
1927.3250000              6.690605E-02
543.2343000              2.318541E-01
173.9905000              4.799046E-01
59.3600500              3.495737E-01
Mn    SP 1165.4120000              2.388751E-03           3.977318E-03
277.3276000              3.181708E-02           3.103112E-02
89.4727800              1.254670E-01           1.351894E-01
33.4825600             -2.955431E-02           3.457387E-01
13.5403700             -6.175160E-01           4.629205E-01
5.5579720             -4.544458E-01           2.090592E-01
Mn    SP 45.8353200             -3.665856E-03          -6.887578E-03
15.1877700              7.231971E-02          -2.846816E-02
6.5007100              2.544486E-01           6.031832E-02
2.7515830             -2.910380E-01           3.938961E-01
1.1454040             -7.359860E-01           5.013769E-01
0.4536870             -1.997617E-01           1.792264E-01
Mn    SP 1.7579990              0.05628572            -0.5035024
0.6670220              0.2897491              0.2345011
0.1051290             -1.1406530              0.9141257
Mn    SP 0.0384180              1.000000E+00           1.00000000
Mn    D 20.9435500              8.672702E-02
5.5104860              3.841883E-01
1.6650380              7.069071E-01
Mn    D 0.4617330              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Fe    S 61132.6200000              1.766111E-03
9179.3420000              1.353038E-02
2090.8570000              6.673128E-02
589.2479000              2.314823E-01
188.7543000              4.797058E-01
64.4462900              3.501976E-01
Fe    SP 1259.9800000              2.438014E-03           4.028019E-03
299.8761000              3.224048E-02           3.144647E-02
96.8491700              1.265724E-01           1.368317E-01
36.3102000             -3.139902E-02           3.487236E-01
14.7299600             -6.207593E-01           4.617931E-01
6.0660750             -4.502914E-01           2.043058E-01
Fe    SP 50.4348500             -3.873256E-03          -7.017128E-03
16.8392900              7.196598E-02          -2.877660E-02
7.1920860              2.556591E-01           6.181383E-02
3.0534200             -2.882837E-01           3.954946E-01
1.2736430             -7.342822E-01           4.989059E-01
0.5040910             -2.049353E-01           1.791251E-01
Fe    SP 1.9503160              0.05694869            -0.4593796
0.7367210              0.2882915              0.2852139
0.1141770             -1.1381590              0.9076485
Fe    SP 0.0411480              1.000000E+00           1.00000000
Fe    D 23.1499400              8.876935E-02
6.1223680              3.896319E-01
1.8466010              7.014816E-01
Fe    D 0.5043610              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Co    S 66148.9900000              1.759787E-03
9933.0770000              1.348162E-02
2262.8160000              6.649342E-02
637.9154000              2.307939E-01
204.4122000              4.792919E-01
69.8253800              3.514097E-01
Co    SP 1378.8410000              2.376276E-03           3.971488E-03
328.2694000              3.167450E-02           3.108174E-02
106.0946000              1.262888E-01           1.357439E-01
39.8327500             -2.584552E-02           3.476827E-01
16.1862200             -6.183491E-01           4.626340E-01
6.6677880             -4.567008E-01           2.051632E-01
Co    SP 54.5235500             -3.993004E-03          -7.290772E-03
18.2978300              7.409663E-02          -2.926027E-02
7.8673480              2.542000E-01           6.564150E-02
3.3405340             -2.921657E-01           4.000652E-01
1.3937560             -7.318703E-01           4.950236E-01
0.5513260             -2.040784E-01           1.758240E-01
Co    SP 2.1519470              0.05379843            -0.2165496
0.8110630              0.2759971              0.1240488
0.1210170             -1.1296920              0.9724064
Co    SP 0.0430370              1.000000E+00           1.00000000
Co    D 25.5930600              9.004748E-02
6.8009900              3.931703E-01
2.0516470              6.976844E-01
Co    D 0.5556710              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Ni    S 71396.3500000              1.753003E-03
10720.8400000              1.343122E-02
2442.1290000              6.627041E-02
688.4265000              2.302508E-01
220.6153000              4.790186E-01
75.3937300              3.523444E-01
Ni    SP 1492.5320000              2.370714E-03           3.967554E-03
355.4013000              3.160566E-02           3.109479E-02
114.9534000              1.266335E-01           1.359517E-01
43.2204300             -2.417037E-02           3.485136E-01
17.5971000             -6.187775E-01           4.625498E-01
7.2577650             -4.576770E-01           2.035186E-01
Ni    SP 59.3526100             -4.162002E-03          -7.421452E-03
20.0218100              7.425111E-02          -2.953410E-02
8.6145610              2.541360E-01           6.731852E-02
3.6605310             -2.903477E-01           4.016660E-01
1.5281110             -7.302121E-01           4.926623E-01
0.6040570             -2.076057E-01           1.756893E-01
Ni    SP 2.3792760              0.05157888            -0.1887663
0.8858390              0.2707611              0.1015199
0.1285290             -1.1247700              0.9790906
Ni    SP 0.0451950              1.000000E+00           1.00000000
Ni    D 28.1914700              9.098881E-02
7.5235840              3.958208E-01
2.2712280              6.947154E-01
Ni    D 0.6116030              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Cu    S 76794.3800000              1.748161E-03
11530.7000000              1.339602E-02
2626.5750000              6.610885E-02
740.4903000              2.298265E-01
237.3528000              4.787675E-01
81.1581800              3.530739E-01
Cu    SP 1610.8140000              2.364055E-03           3.963307E-03
383.6367000              3.153635E-02           3.110223E-02
124.1733000              1.269452E-01           1.361350E-01
46.7467800             -2.262840E-02           3.492914E-01
19.0656900             -6.192080E-01           4.624780E-01
7.8715670             -4.585393E-01           2.020102E-01
Cu    SP 64.4573200             -4.331075E-03          -7.523725E-03
21.8521200              7.412307E-02          -2.975687E-02
9.4053430              2.542108E-01           6.849654E-02
3.9991680             -2.874843E-01           4.027141E-01
1.6702970             -7.291436E-01           4.908490E-01
0.6596270             -2.113951E-01           1.759268E-01
Cu    SP 2.6000880              0.05027577            -0.1702911
0.9630940              0.2650040              0.09310133
0.1361610             -1.1201550              0.9814336
Cu    SP 0.0473320              1.000000E+00           1.00000000
Cu    D 30.8534100              9.199905E-02
8.2649850              3.985021E-01
2.4953320              6.917897E-01
Cu    D 0.6676580              1.0000000
#BASIS SET: (22s,16p,4d) -> [5s,4p,2d] Zn    S 82400.9400000              1.743329E-03
12372.5500000              1.335966E-02
2818.3510000              6.594365E-02
794.5717000              2.294151E-01
254.7232000              4.785453E-01
87.1388000              3.537753E-01
Zn    SP 1732.5690000              2.361459E-03           3.963125E-03
412.7149000              3.150177E-02           3.113411E-02
133.6780000              1.272774E-01           1.363931E-01
50.3858500             -2.145928E-02           3.501266E-01
20.5835800             -6.197652E-01           4.623179E-01
8.5059400             -4.590180E-01           2.004995E-01
Zn    SP 69.3649200             -4.440098E-03          -7.689262E-03
23.6208200              7.505253E-02          -2.997982E-02
10.1847100              2.533111E-01           7.082411E-02
4.3340820             -2.881897E-01           4.046141E-01
1.8109180             -7.267052E-01           4.882325E-01
0.7148410             -2.133439E-01           1.751970E-01
Zn    SP 2.8238420              0.04898543            -0.1586763
1.0395430              0.2592793              0.08379327
0.1432640             -1.1157110              0.9840547
Zn    SP 0.0492960              1.000000E+00           1.00000000
Zn    D 33.7076400              9.262648E-02
9.0611060              4.002980E-01
2.7383830              6.896608E-01
Zn    D 0.7302940              1.0000000
END
================================================================================FILE: basis/cc-pvdz.dat
cc-pVDZ  EMSL  Basis Set Exchange Library  9/15/14 7:23 AM
Elements                             References
--------                             ----------
H     : T.H. Dunning, Jr. J. Chem. Phys. 90, 1007 (1989).
He    : D.E. Woon and T.H. Dunning, Jr. J. Chem. Phys. 100, 2975 (1994).
Li - Ne: T.H. Dunning, Jr. J. Chem. Phys. 90, 1007 (1989).
Na - Mg: D.E. Woon and T.H. Dunning, Jr.  (to be published)
Al - Ar: D.E. Woon and T.H. Dunning, Jr.  J. Chem. Phys. 98, 1358 (1993).
Sc - Zn: N.B. Balabanov and K.A. Peterson, J. Chem. Phys. 123, 064107 (2005),
N.B. Balabanov and K.A. Peterson, J. Chem. Phys. 125, 074110 (2006)
Ca     : J. Koput and K.A. Peterson, J. Phys. Chem. A, 106, 9595 (2002).
BASIS "ao basis" PRINT #BASIS SET: (4s,1p) -> [2s,1p] H    S 13.0100000              0.0196850
1.9620000              0.1379770
0.4446000              0.4781480
H    S 0.1220000              1.0000000
H    P 0.7270000              1.0000000
#BASIS SET: (4s,1p) -> [2s,1p] He    S 38.3600000              0.0238090
5.7700000              0.1548910
1.2400000              0.4699870
He    S 0.2976000              1.0000000
He    P 1.2750000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] Li    S 1469.0000000              0.0007660             -0.0001200
220.5000000              0.0058920             -0.0009230
50.2600000              0.0296710             -0.0046890
14.2400000              0.1091800             -0.0176820
4.5810000              0.2827890             -0.0489020
1.5800000              0.4531230             -0.0960090
0.5640000              0.2747740             -0.1363800
0.0734500              0.0097510              0.5751020
Li    S 0.0280500              1.0000000
Li    P 1.5340000              0.0227840
0.2749000              0.1391070
0.0736200              0.5003750
Li    P 0.0240300              1.0000000
Li    D 0.1239000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] Be    S 2940.0000000              0.0006800             -0.0001230
441.2000000              0.0052360             -0.0009660
100.5000000              0.0266060             -0.0048310
28.4300000              0.0999930             -0.0193140
9.1690000              0.2697020             -0.0532800
3.1960000              0.4514690             -0.1207230
1.1590000              0.2950740             -0.1334350
0.1811000              0.0125870              0.5307670
Be    S 0.0589000              1.0000000
Be    P 3.6190000              0.0291110
0.7110000              0.1693650
0.1951000              0.5134580
Be    P 0.0601800              1.0000000
Be    D 0.2380000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] B    S 4570.0000000              0.0006960             -0.0001390
685.9000000              0.0053530             -0.0010970
156.5000000              0.0271340             -0.0054440
44.4700000              0.1013800             -0.0219160
14.4800000              0.2720550             -0.0597510
5.1310000              0.4484030             -0.1387320
1.8980000              0.2901230             -0.1314820
0.3329000              0.0143220              0.5395260
B    S 0.1043000              1.0000000
B    P 6.0010000              0.0354810
1.2410000              0.1980720
0.3364000              0.5052300
B    P 0.0953800              1.0000000
B    D 0.3430000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] C    S 6665.0000000              0.0006920             -0.0001460
1000.0000000              0.0053290             -0.0011540
228.0000000              0.0270770             -0.0057250
64.7100000              0.1017180             -0.0233120
21.0600000              0.2747400             -0.0639550
7.4950000              0.4485640             -0.1499810
2.7970000              0.2850740             -0.1272620
0.5215000              0.0152040              0.5445290
C    S 0.1596000              1.0000000
C    P 9.4390000              0.0381090
2.0020000              0.2094800
0.5456000              0.5085570
C    P 0.1517000              1.0000000
C    D 0.5500000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] N    S 9046.0000000              0.0007000             -0.0001530
1357.0000000              0.0053890             -0.0012080
309.3000000              0.0274060             -0.0059920
87.7300000              0.1032070             -0.0245440
28.5600000              0.2787230             -0.0674590
10.2100000              0.4485400             -0.1580780
3.8380000              0.2782380             -0.1218310
0.7466000              0.0154400              0.5490030
N    S 0.2248000              1.0000000
N    P 13.5500000              0.0399190
2.9170000              0.2171690
0.7973000              0.5103190
N    P 0.2185000              1.0000000
N    D 0.8170000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] O    S 11720.0000000              0.0007100             -0.0001600
1759.0000000              0.0054700             -0.0012630
400.8000000              0.0278370             -0.0062670
113.7000000              0.1048000             -0.0257160
37.0300000              0.2830620             -0.0709240
13.2700000              0.4487190             -0.1654110
5.0250000              0.2709520             -0.1169550
1.0130000              0.0154580              0.5573680
O    S 0.3023000              1.0000000
O    P 17.7000000              0.0430180
3.8540000              0.2289130
1.0460000              0.5087280
O    P 0.2753000              1.0000000
O    D 1.1850000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] F    S 14710.0000000              0.0007210             -0.0001650
2207.0000000              0.0055530             -0.0013080
502.8000000              0.0282670             -0.0064950
142.6000000              0.1064440             -0.0266910
46.4700000              0.2868140             -0.0736900
16.7000000              0.4486410             -0.1707760
6.3560000              0.2647610             -0.1123270
1.3160000              0.0153330              0.5628140
F    S 0.3897000              1.0000000
F    P 22.6700000              0.0448780
4.9770000              0.2357180
1.3470000              0.5085210
F    P 0.3471000              1.0000000
F    D 1.6400000              1.0000000
#BASIS SET: (9s,4p,1d) -> [3s,2p,1d] Ne    S 17880.0000000              0.0007380             -0.0001720
2683.0000000              0.0056770             -0.0013570
611.5000000              0.0288830             -0.0067370
173.5000000              0.1085400             -0.0276630
56.6400000              0.2909070             -0.0762080
20.4200000              0.4483240             -0.1752270
7.8100000              0.2580260             -0.1070380
1.6530000              0.0150630              0.5670500
Ne    S 0.4869000              1.0000000
Ne    P 28.3900000              0.0460870
6.2700000              0.2401810
1.6950000              0.5087440
Ne    P 0.4317000              1.0000000
Ne    D 2.2020000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] Na    S 31700.0000000              0.458878D-03          -0.112162D-03           0.170160D-04
4755.0000000              0.355070D-02          -0.868512D-03           0.130693D-03
1082.0000000              0.182618D-01          -0.451330D-02           0.687784D-03
306.4000000              0.716650D-01          -0.181436D-01           0.272359D-02
99.5300000              0.212346D+00          -0.580799D-01           0.895529D-02
35.4200000              0.416203D+00          -0.137653D+00           0.207832D-01
13.3000000              0.373020D+00          -0.193908D+00           0.319380D-01
4.3920000              0.625054D-01           0.858009D-01          -0.191368D-01
1.6760000             -0.624532D-02           0.604419D+00          -0.102595D+00
0.5889000              0.243374D-02           0.441719D+00          -0.198945D+00
0.0564000             -0.442381D-03           0.130547D-01           0.655952D+00
Na    S 0.0230700              1.0000000
Na    P 138.1000000              0.579641D-02          -0.581531D-03
32.2400000              0.415756D-01          -0.407306D-02
9.9850000              0.162873D+00          -0.167937D-01
3.4840000              0.359401D+00          -0.353268D-01
1.2310000              0.449988D+00          -0.521971D-01
0.4177000              0.227507D+00          -0.168359D-01
0.0651300              0.808247D-02           0.434613D+00
Na    P 0.0205300              1.0000000
Na    D 0.0973000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] Mg    S 47390.0000000              0.346023D-03          -0.877839D-04           0.169628D-04
7108.0000000              0.268077D-02          -0.674725D-03           0.129865D-03
1618.0000000              0.138367D-01          -0.355603D-02           0.688831D-03
458.4000000              0.551767D-01          -0.142154D-01           0.273533D-02
149.3000000              0.169660D+00          -0.476748D-01           0.931224D-02
53.5900000              0.364703D+00          -0.114892D+00           0.223265D-01
20.7000000              0.406856D+00          -0.200676D+00           0.411195D-01
8.3840000              0.135089D+00          -0.341224D-01           0.545642D-02
2.5420000              0.490884D-02           0.570454D+00          -0.134012D+00
0.8787000              0.286460D-03           0.542309D+00          -0.256176D+00
0.1077000              0.264590D-04           0.218128D-01           0.605856D+00
Mg    S 0.0399900              1.0000000
Mg    P 179.9000000              0.538161D-02          -0.865948D-03
42.1400000              0.392418D-01          -0.615978D-02
13.1300000              0.157445D+00          -0.261519D-01
4.6280000              0.358535D+00          -0.570647D-01
1.6700000              0.457226D+00          -0.873906D-01
0.5857000              0.215918D+00          -0.122990D-01
0.1311000              0.664948D-02           0.502085D+00
Mg    P 0.0411200              1.0000000
Mg    D 0.1870000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] Al    S 64150.0000000              0.290250D-03          -0.758048D-04           0.175078D-04
9617.0000000              0.225064D-02          -0.581791D-03           0.134208D-03
2189.0000000              0.116459D-01          -0.308113D-02           0.712442D-03
620.5000000              0.467377D-01          -0.123112D-01           0.284330D-02
202.7000000              0.146299D+00          -0.419781D-01           0.976842D-02
73.1500000              0.330283D+00          -0.103371D+00           0.241850D-01
28.5500000              0.415861D+00          -0.196308D+00           0.474993D-01
11.7700000              0.189253D+00          -0.830002D-01           0.203621D-01
3.3000000              0.115889D-01           0.541040D+00          -0.158788D+00
1.1730000             -0.128385D-02           0.578796D+00          -0.311694D+00
0.1752000              0.425883D-03           0.288147D-01           0.620147D+00
Al    S 0.0647300              1.0000000
Al    P 258.8000000              0.406847D-02          -0.748053D-03
60.8900000              0.306815D-01          -0.545796D-02
19.1400000              0.129149D+00          -0.245371D-01
6.8810000              0.320831D+00          -0.582138D-01
2.5740000              0.453815D+00          -0.983756D-01
0.9572000              0.275066D+00          -0.260064D-01
0.2099000              0.190807D-01           0.464020D+00
Al    P 0.0598600              1.0000000
Al    D 0.1890000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] Si    S 78860.0000000              0.270443D-03          -0.723177D-04           0.185113D-04
11820.0000000              0.209717D-02          -0.555116D-03           0.142236D-03
2692.0000000              0.108506D-01          -0.293805D-02           0.752185D-03
763.4000000              0.436754D-01          -0.117687D-01           0.302279D-02
249.6000000              0.137653D+00          -0.402907D-01           0.103677D-01
90.2800000              0.316644D+00          -0.100609D+00           0.262563D-01
35.2900000              0.418581D+00          -0.196528D+00           0.523989D-01
14.5100000              0.210212D+00          -0.102382D+00           0.290959D-01
4.0530000              0.144952D-01           0.527190D+00          -0.178003D+00
1.4820000             -0.203590D-02           0.593251D+00          -0.346874D+00
0.2517000              0.624186D-03           0.332652D-01           0.623020D+00
Si    S 0.0924300              1.0000000
Si    P 315.9000000              0.392656D-02          -0.858302D-03
74.4200000              0.298811D-01          -0.630328D-02
23.4800000              0.127212D+00          -0.288255D-01
8.4880000              0.320943D+00          -0.694560D-01
3.2170000              0.455429D+00          -0.119493D+00
1.2290000              0.268563D+00          -0.199581D-01
0.2964000              0.188336D-01           0.510268D+00
Si    P 0.0876800              1.0000000
Si    D 0.2750000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] P    S 94840.0000000              0.255509D-03          -0.696939D-04           0.191199D-04
14220.0000000              0.198193D-02          -0.535266D-03           0.147223D-03
3236.0000000              0.102760D-01          -0.283709D-02           0.777912D-03
917.1000000              0.414823D-01          -0.113983D-01           0.314546D-02
299.5000000              0.131984D+00          -0.392929D-01           0.108200D-01
108.1000000              0.308662D+00          -0.996364D-01           0.279957D-01
42.1800000              0.420647D+00          -0.197983D+00           0.563978D-01
17.2800000              0.222878D+00          -0.114860D+00           0.358190D-01
4.8580000              0.164035D-01           0.518595D+00          -0.193387D+00
1.8180000             -0.254255D-02           0.601847D+00          -0.372097D+00
0.3372000              0.748050D-03           0.368612D-01           0.624246D+00
P    S 0.1232000              1.0000000
P    P 370.5000000              0.395005D-02          -0.959832D-03
87.3300000              0.302492D-01          -0.711177D-02
27.5900000              0.129554D+00          -0.327122D-01
10.0000000              0.327594D+00          -0.795784D-01
3.8250000              0.456992D+00          -0.135016D+00
1.4940000              0.253086D+00          -0.910585D-02
0.3921000              0.168798D-01           0.537802D+00
P    P 0.1186000              1.0000000
P    D 0.3730000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] S    S 110800.0000000              0.247635D-03          -0.687039D-04           0.199077D-04
16610.0000000              0.192026D-02          -0.527681D-03           0.153483D-03
3781.0000000              0.996192D-02          -0.279671D-02           0.809503D-03
1071.0000000              0.402975D-01          -0.112651D-01           0.328974D-02
349.8000000              0.128604D+00          -0.388834D-01           0.112967D-01
126.3000000              0.303480D+00          -0.995025D-01           0.296385D-01
49.2600000              0.421432D+00          -0.199740D+00           0.599851D-01
20.1600000              0.230781D+00          -0.123360D+00           0.413248D-01
5.7200000              0.178971D-01           0.513194D+00          -0.207474D+00
2.1820000             -0.297516D-02           0.607120D+00          -0.392889D+00
0.4327000              0.849522D-03           0.396753D-01           0.632840D+00
S    S 0.1570000              1.0000000
S    P 399.7000000              0.447541D-02          -0.116251D-02
94.1900000              0.341708D-01          -0.865664D-02
29.7500000              0.144250D+00          -0.390886D-01
10.7700000              0.353928D+00          -0.934625D-01
4.1190000              0.459085D+00          -0.147994D+00
1.6250000              0.206383D+00           0.301904D-01
0.4726000              0.102141D-01           0.561573D+00
S    P 0.1407000              1.0000000
S    D 0.4790000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] Cl    S 127900.0000000              0.241153D-03          -0.678922D-04           0.204986D-04
19170.0000000              0.187095D-02          -0.521836D-03           0.158298D-03
4363.0000000              0.970827D-02          -0.276513D-02           0.833639D-03
1236.0000000              0.393153D-01          -0.111537D-01           0.339880D-02
403.6000000              0.125932D+00          -0.385919D-01           0.116738D-01
145.7000000              0.299341D+00          -0.994848D-01           0.309622D-01
56.8100000              0.421886D+00          -0.201392D+00           0.629533D-01
23.2300000              0.237201D+00          -0.130313D+00           0.460257D-01
6.6440000              0.191531D-01           0.509443D+00          -0.219312D+00
2.5750000             -0.334792D-02           0.610725D+00          -0.408773D+00
0.5371000              0.929883D-03           0.421549D-01           0.638465D+00
Cl    S 0.1938000              1.0000000
Cl    P 417.6000000              0.525982D-02          -0.143570D-02
98.3300000              0.398332D-01          -0.107796D-01
31.0400000              0.164655D+00          -0.470075D-01
11.1900000              0.387322D+00          -0.111030D+00
4.2490000              0.457072D+00          -0.153275D+00
1.6240000              0.151636D+00           0.894609D-01
0.5322000              0.181615D-02           0.579444D+00
Cl    P 0.1620000              1.0000000
Cl    D 0.6000000              1.0000000
#BASIS SET: (12s,8p,1d) -> [4s,3p,1d] Ar    S 145700.0000000              0.236700D-03          -0.674910D-04           0.210457D-04
21840.0000000              0.183523D-02          -0.518522D-03           0.162565D-03
4972.0000000              0.952860D-02          -0.274825D-02           0.855463D-03
1408.0000000              0.386283D-01          -0.111007D-01           0.349745D-02
459.7000000              0.124081D+00          -0.384820D-01           0.120156D-01
165.9000000              0.296471D+00          -0.997599D-01           0.321368D-01
64.6900000              0.422068D+00          -0.203088D+00           0.655279D-01
26.4400000              0.241711D+00          -0.135608D+00           0.499370D-01
7.6280000              0.200509D-01           0.507195D+00          -0.229769D+00
2.9960000             -0.361000D-02           0.612898D+00          -0.421006D+00
0.6504000              0.975607D-03           0.442968D-01           0.642331D+00
Ar    S 0.2337000              1.0000000
Ar    P 453.7000000              0.570555D-02          -0.160655D-02
106.8000000              0.430460D-01          -0.121714D-01
33.7300000              0.176591D+00          -0.520789D-01
12.1300000              0.406863D+00          -0.123737D+00
4.5940000              0.452549D+00          -0.151619D+00
1.6780000              0.122801D+00           0.142425D+00
0.5909000             -0.445996D-02           0.584501D+00
Ar    P 0.1852000              1.0000000
Ar    D 0.7380000              1.0000000
#BASIS SET: (14s,11p,5d) -> [5s,4p,2d] Ca    S 190000.7000000              0.00022145            -0.00006453             0.00002223             0.00000531
28481.4600000              0.00171830            -0.00049662             0.00017170             0.00004111
6482.7010000              0.00892348            -0.00262826             0.00090452             0.00021568
1835.8910000              0.03630183            -0.01066845             0.00370343             0.00088827
598.7243000              0.11762223            -0.03713509             0.01283750             0.00305813
215.8841000              0.28604352            -0.09804284             0.03475459             0.00837608
84.0124200              0.42260708            -0.20342692             0.07303491             0.01741056
34.2248800              0.25774366            -0.15244655             0.06100083             0.01515453
10.0249700              0.02391893             0.48279406            -0.24292928            -0.06207919
4.0559200             -0.00495218             0.62923839            -0.48708500            -0.12611803
1.0202610              0.00171779             0.06164842             0.56502804             0.17360694
0.4268650             -0.00089209            -0.01479971             0.65574386             0.37822943
0.0633470              0.00024510             0.00361089             0.02672894            -0.65964698
Ca    S 0.0263010              1.0000000
Ca    P 1072.0430000              0.00198166            -0.00064891             0.00013595
253.8439000              0.01612944            -0.00527907             0.00109420
81.3162600              0.07657851            -0.02581131             0.00542680
30.2418300              0.23269594            -0.08062892             0.01674718
12.1011000              0.42445210            -0.15846552             0.03389863
5.0225540              0.37326402            -0.12816816             0.02531183
1.9092200              0.07868530             0.25610103            -0.05895713
0.7713040             -0.00599927             0.58724068            -0.15876120
0.3005700              0.00264257             0.30372561            -0.08554523
0.0766490             -0.00085694             0.01416451             0.54464665
Ca    P 0.0277720              1.0000000
Ca    D 10.3182000              0.03284900
2.5924200              0.14819200
0.7617000              0.31092100
0.2083800              0.45219500
Ca    D 0.0537000              1.0000000
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Sc    S 2.715278E+06           8.147221E-06          -4.722109E-06           9.139905E-07          -2.201951E-07          -3.757238E-07
4.065984E+05           6.334788E-05          -3.671829E-05           7.108513E-06          -1.711419E-06          -2.981907E-06
9.253004E+04           3.330384E-04          -1.930883E-04           3.738126E-05          -9.008469E-06          -1.522586E-05
2.620792E+04           1.404055E-03          -8.146870E-04           1.578828E-04          -3.799997E-05          -6.684686E-05
8.549429E+03           5.081725E-03          -2.955526E-03           5.737686E-04          -1.383227E-04          -2.313129E-04
3.085975E+03           1.626926E-02          -9.520035E-03           1.859244E-03          -4.473692E-04          -7.959729E-04
1.203172E+03           4.624577E-02          -2.746858E-02           5.433182E-03          -1.310691E-03          -2.161961E-03
4.984869E+02           1.137223E-01          -6.991528E-02           1.425387E-02          -3.429860E-03          -6.206459E-03
2.167360E+02           2.257636E-01          -1.499251E-01           3.246144E-02          -7.847579E-03          -1.261905E-02
9.787476E+01           3.106700E-01          -2.459153E-01           6.003454E-02          -1.447189E-02          -2.739459E-02
4.520433E+01           2.191906E-01          -2.401293E-01           6.916105E-02          -1.690669E-02          -2.336516E-02
2.021187E+01           7.215879E-02           3.567987E-02          -2.113084E-02           5.396115E-03          -5.734627E-03
9.574751E+00           1.187030E-01           4.915023E-01          -2.666832E-01           6.671062E-02           1.536025E-01
4.540346E+00           1.220532E-01           4.911381E-01          -4.367591E-01           1.178356E-01           1.447100E-01
1.995687E+00           2.136795E-02           9.120633E-02           6.498243E-02          -2.738134E-02           9.359699E-02
9.422150E-01          -5.357246E-04          -5.356723E-03           7.009599E-01          -2.260149E-01          -8.687730E-01
4.178450E-01           2.435774E-04           8.812836E-04           4.515562E-01          -3.073539E-01           2.114597E-02
9.576100E-02          -8.796617E-05          -7.605536E-04           3.011910E-02           2.544054E-01           2.275498E+00
5.135100E-02           7.878246E-05           6.340116E-04          -1.329480E-02           5.981590E-01          -1.190770E+00
Sc    S 2.387800E-02           1.0000000
Sc    P 1.059219E+04           4.500000E-05          -1.500000E-05          -4.000000E-06           4.000000E-06
2.507533E+03           4.010000E-04          -1.310000E-04          -3.200000E-05           3.900000E-05
8.144571E+02           2.302000E-03          -7.570000E-04          -1.850000E-04           2.210000E-04
3.115195E+02           1.003700E-02          -3.318000E-03          -8.080000E-04           9.840000E-04
1.319617E+02           3.495400E-02          -1.170600E-02          -2.870000E-03           3.423000E-03
5.998718E+01           9.790900E-02          -3.360400E-02          -8.207000E-03           9.993000E-03
2.866250E+01           2.106800E-01          -7.487900E-02          -1.847300E-02           2.191600E-02
1.410851E+01           3.300930E-01          -1.225480E-01          -3.010100E-02           3.700800E-02
7.103706E+00           3.310270E-01          -1.302760E-01          -3.294300E-02           3.779400E-02
3.609200E+00           1.579600E-01           1.459600E-02           7.958000E-03          -4.379000E-03
1.776070E+00           2.209900E-02           3.091840E-01           8.799300E-02          -1.101640E-01
8.547600E-01          -1.605000E-03           4.629980E-01           1.523770E-01          -1.610170E-01
4.022390E-01          -1.326000E-03           3.049570E-01           9.717000E-02          -1.824820E-01
1.546650E-01          -2.800000E-04           5.087800E-02          -2.569380E-01           3.886110E-01
6.494500E-02           3.400000E-05          -4.493000E-03          -5.878150E-01           6.911000E-01
Sc    P 2.635900E-02           1.0000000
Sc    D 5.051380E+01           4.266000E-03          -4.389000E-03
1.474050E+01           2.770800E-02          -2.836300E-02
5.195000E+00           1.000010E-01          -1.051370E-01
2.028460E+00           2.315810E-01          -2.348540E-01
8.040860E-01           3.460330E-01          -3.246090E-01
3.076890E-01           3.733740E-01          -6.428900E-02
1.113920E-01           2.642880E-01           6.017490E-01
Sc    D 3.735200E-02           1.0000000
Sc    F 7.126000E-01           3.617450E-01
1.636000E-01           8.218680E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Ti    S 3.014643E+06           8.060782E-06          -4.630486E-06           9.230559E-07          -2.180323E-07          -3.975126E-07
4.514329E+05           6.267518E-05          -3.600451E-05           7.178974E-06          -1.694860E-06          -3.161080E-06
1.027338E+05           3.295006E-04          -1.893420E-04           3.775134E-05          -8.919208E-06          -1.609375E-05
2.909817E+04           1.389203E-03          -7.988781E-04           1.594532E-04          -3.763633E-05          -7.092947E-05
9.492330E+03           5.028469E-03          -2.898698E-03           5.795150E-04          -1.369575E-04          -2.442710E-04
3.426346E+03           1.610419E-02          -9.339701E-03           1.878414E-03          -4.432894E-04          -8.457892E-04
1.335896E+03           4.581232E-02          -2.697464E-02           5.492747E-03          -1.298868E-03          -2.282208E-03
5.535026E+02           1.128613E-01          -6.878913E-02           1.443297E-02          -3.406752E-03          -6.619873E-03
2.406925E+02           2.248193E-01          -1.481037E-01           3.296408E-02          -7.810829E-03          -1.335024E-02
1.087293E+02           3.114571E-01          -2.445253E-01           6.125493E-02          -1.449245E-02          -2.955830E-02
5.026457E+01           2.224995E-01          -2.419916E-01           7.134113E-02          -1.708136E-02          -2.477039E-02
2.258004E+01           7.293128E-02           3.183790E-02          -1.973150E-02           4.897666E-03          -8.414624E-03
1.071432E+01           1.160683E-01           4.932686E-01          -2.741869E-01           6.753108E-02           1.693855E-01
5.093546E+00           1.194774E-01           4.939655E-01          -4.440977E-01           1.173318E-01           1.500787E-01
2.244183E+00           2.097868E-02           9.196313E-02           7.776084E-02          -2.985025E-02           9.787777E-02
1.059570E+00          -5.091715E-04          -5.316992E-03           7.068444E-01          -2.277634E-01          -9.653608E-01
4.688490E-01           2.217859E-04           8.085624E-04           4.413892E-01          -2.928115E-01           1.489721E-01
1.061430E-01          -7.636896E-05          -6.918459E-04           2.799769E-02           2.665300E-01           2.191179E+00
5.526200E-02           7.719539E-05           6.086512E-04          -1.210790E-02           5.912406E-01          -1.243325E+00
Ti    S 2.546500E-02           1.0000000
Ti    P 1.191203E+04           4.400000E-05          -1.500000E-05           4.000000E-06           4.000000E-06
2.819947E+03           3.910000E-04          -1.310000E-04           3.100000E-05           3.900000E-05
9.159479E+02           2.248000E-03          -7.550000E-04           1.820000E-04           2.230000E-04
3.503842E+02           9.823000E-03          -3.319000E-03           7.950000E-04           9.920000E-04
1.484825E+02           3.433800E-02          -1.175000E-02           2.833000E-03           3.476000E-03
6.753944E+01           9.666600E-02          -3.392200E-02           8.154000E-03           1.017200E-02
3.230332E+01           2.094170E-01          -7.616400E-02           1.847200E-02           2.257600E-02
1.592786E+01           3.301890E-01          -1.257020E-01           3.040000E-02           3.823800E-02
8.038035E+00           3.319360E-01          -1.330980E-01           3.304700E-02           3.933700E-02
4.093916E+00           1.584880E-01           1.740600E-02          -8.251000E-03          -6.106000E-03
2.022390E+00           2.231000E-02           3.151650E-01          -8.855400E-02          -1.129620E-01
9.761020E-01          -1.566000E-03           4.618140E-01          -1.496120E-01          -1.681140E-01
4.595950E-01          -1.324000E-03           2.998560E-01          -9.422700E-02          -1.659320E-01
1.771520E-01          -2.710000E-04           5.000000E-02           2.508460E-01           3.914030E-01
7.351700E-02           3.200000E-05          -4.230000E-03           5.866430E-01           6.818400E-01
Ti    P 2.940100E-02           1.0000000
Ti    D 6.401300E+01           3.887000E-03          -3.970000E-03
1.881790E+01           2.639900E-02          -2.687300E-02
6.728700E+00           9.751100E-02          -1.022750E-01
2.664130E+00           2.328480E-01          -2.377280E-01
1.078680E+00           3.531520E-01          -3.121140E-01
4.232090E-01           3.721860E-01          -4.237800E-02
1.559990E-01           2.476720E-01           5.886580E-01
Ti    D 5.188400E-02           1.0000000
Ti    F 1.227400E+00           3.581580E-01
2.788000E-01           8.257940E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] V    S 3.321857E+06           8.039999E-06          -4.503003E-06           9.320648E-07          -2.158944E-07          -4.093416E-07
4.974356E+05           6.251402E-05          -3.501295E-05           7.249306E-06          -1.678519E-06          -3.258956E-06
1.132027E+05           3.286553E-04          -1.841339E-04           3.811967E-05          -8.831213E-06          -1.656390E-05
3.206333E+04           1.385697E-03          -7.769216E-04           1.610238E-04          -3.727769E-05          -7.316689E-05
1.045962E+04           5.016217E-03          -2.819505E-03           5.852210E-04          -1.356099E-04          -2.512784E-04
3.775506E+03           1.606931E-02          -9.087486E-03           1.897502E-03          -4.392351E-04          -8.732657E-04
1.472040E+03           4.574242E-02          -2.627134E-02           5.550909E-03          -1.286948E-03          -2.347654E-03
6.099331E+02           1.128544E-01          -6.712726E-02           1.460584E-02          -3.382149E-03          -6.853150E-03
2.652634E+02           2.254344E-01          -1.451130E-01           3.342974E-02          -7.765646E-03          -1.376420E-02
1.198607E+02           3.140461E-01          -2.412483E-01           6.235722E-02          -1.447985E-02          -3.084679E-02
5.544891E+01           2.267819E-01          -2.416314E-01           7.312435E-02          -1.715502E-02          -2.562208E-02
2.498372E+01           7.334069E-02           3.067362E-02          -1.911472E-02           4.610101E-03          -1.005123E-02
1.188056E+01           1.102474E-01           4.970415E-01          -2.817249E-01           6.827831E-02           1.795330E-01
5.660311E+00           1.131358E-01           4.958875E-01          -4.488151E-01           1.161368E-01           1.522400E-01
2.495703E+00           1.971295E-02           9.181868E-02           9.202696E-02          -3.277049E-02           9.483887E-02
1.177866E+00          -4.719088E-04          -5.392514E-03           7.110117E-01          -2.280000E-01          -1.014876E+00
5.200440E-01           1.861606E-04           7.102380E-04           4.309274E-01          -2.793991E-01           2.308810E-01
1.159650E-01          -6.208598E-05          -6.363128E-04           2.604589E-02           2.771165E-01           2.113321E+00
5.893800E-02           7.295314E-05           5.979932E-04          -1.101049E-02           5.852999E-01          -1.253048E+00
V    S 2.694600E-02           1.0000000
V    P 1.327320E+04           4.300000E-05          -1.500000E-05           4.000000E-06           4.000000E-06
3.142126E+03           3.840000E-04          -1.310000E-04           3.200000E-05           3.900000E-05
1.020588E+03           2.210000E-03          -7.550000E-04           1.830000E-04           2.230000E-04
3.904407E+02           9.678000E-03          -3.325000E-03           8.020000E-04           9.960000E-04
1.655043E+02           3.393600E-02          -1.181100E-02           2.862000E-03           3.498000E-03
7.532006E+01           9.591700E-02          -3.425600E-02           8.287000E-03           1.029600E-02
3.605503E+01           2.088530E-01          -7.736300E-02           1.887000E-02           2.296200E-02
1.780436E+01           3.306600E-01          -1.284560E-01           3.130700E-02           3.920800E-02
9.002929E+00           3.323120E-01          -1.350780E-01           3.366000E-02           3.994300E-02
4.594544E+00           1.581880E-01           2.083800E-02          -9.479000E-03          -7.121000E-03
2.276760E+00           2.225200E-02           3.204990E-01          -9.231300E-02          -1.162250E-01
1.101178E+00          -1.565000E-03           4.602600E-01          -1.489890E-01          -1.694960E-01
5.186380E-01          -1.353000E-03           2.953460E-01          -8.364400E-02          -1.553740E-01
2.005650E-01          -2.650000E-04           4.904600E-02           2.493390E-01           3.950220E-01
8.129100E-02           2.900000E-05          -3.824000E-03           5.805150E-01           6.789080E-01
V    P 3.179500E-02           1.0000000
V    D 7.761150E+01           3.595000E-03          -3.818000E-03
2.291590E+01           2.521000E-02          -2.671700E-02
8.279540E+00           9.478600E-02          -1.036900E-01
3.309930E+00           2.303630E-01          -2.476890E-01
1.358630E+00           3.528940E-01          -3.115230E-01
5.413500E-01           3.704140E-01          -2.282700E-02
2.023560E-01           2.457180E-01           5.697260E-01
V    D 6.756800E-02           1.0000000
V    F 1.748800E+00           3.900680E-01
4.057000E-01           8.008410E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Cr    S 6.177194E+06           4.128667E-06          -2.301772E-06           4.862957E-07          -1.102451E-07           2.179893E-07
9.249295E+05           3.210767E-05          -1.789536E-05           3.776645E-06          -8.530233E-07           1.612940E-06
2.104865E+05           1.688416E-04          -9.416174E-05           1.990664E-05          -4.520358E-06           9.111842E-06
5.962005E+04           7.128520E-04          -3.975074E-04           8.389164E-05          -1.891612E-05           3.500645E-05
1.945076E+04           2.589325E-03          -1.447025E-03           3.065706E-04          -6.974344E-05           1.435315E-04
7.022056E+03           8.377350E-03          -4.694622E-03           9.944107E-04          -2.237867E-04           4.035896E-04
2.738763E+03           2.441725E-02          -1.382387E-02           2.961959E-03          -6.754503E-04           1.425177E-03
1.135814E+03           6.365135E-02          -3.674643E-02           7.969473E-03          -1.789346E-03           3.114009E-03
4.950923E+02           1.427618E-01          -8.647185E-02           1.955017E-02          -4.477858E-03           9.814449E-03
2.247487E+02           2.541275E-01          -1.696735E-01           4.085035E-02          -9.140144E-03           1.474698E-02
1.053836E+02           3.009512E-01          -2.507089E-01           6.929003E-02          -1.610562E-02           3.911512E-02
5.019359E+01           1.766513E-01          -1.961156E-01           6.146984E-02          -1.334870E-02           9.170888E-03
2.224957E+01           6.936709E-02           1.457244E-01          -6.981302E-02           1.426027E-02           1.559878E-02
1.098265E+01           1.179579E-01           5.466706E-01          -3.517597E-01           8.931690E-02          -2.816844E-01
5.383665E+00           8.916187E-02           3.979434E-01          -3.828629E-01           8.885279E-02          -6.895261E-03
2.343685E+00           1.103630E-02           5.277007E-02           2.676401E-01          -6.368776E-02          -1.769781E-01
1.105202E+00          -3.546048E-04          -4.374537E-03           7.175950E-01          -2.783262E-01           1.443061E+00
4.878480E-01           1.057311E-04           3.204035E-04           3.020814E-01          -1.830071E-01          -1.029318E+00
8.959900E-02           1.114640E-05          -5.142077E-05           7.749514E-03           6.790937E-01          -1.307667E+00
Cr    S 3.342300E-02           1.0000000
Cr    P 1.445420E+04           4.400000E-05          -1.500000E-05           4.000000E-06           4.000000E-06
3.421676E+03           3.890000E-04          -1.350000E-04           3.200000E-05           4.000000E-05
1.111387E+03           2.241000E-03          -7.770000E-04           1.850000E-04           2.290000E-04
4.251918E+02           9.821000E-03          -3.427000E-03           8.100000E-04           1.019000E-03
1.802623E+02           3.447100E-02          -1.218900E-02           2.906000E-03           3.602000E-03
8.206117E+01           9.746000E-02          -3.538800E-02           8.391000E-03           1.055000E-02
3.929726E+01           2.119850E-01          -7.991500E-02           1.919300E-02           2.370200E-02
1.941959E+01           3.339900E-01          -1.323350E-01           3.156400E-02           3.998800E-02
9.828899E+00           3.301370E-01          -1.354010E-01           3.341700E-02           4.043700E-02
5.016810E+00           1.522270E-01           3.200800E-02          -1.290700E-02          -1.207400E-02
2.487091E+00           2.042500E-02           3.338490E-01          -9.365900E-02          -1.189390E-01
1.198780E+00          -1.360000E-03           4.617730E-01          -1.499770E-01          -1.781000E-01
5.586950E-01          -1.195000E-03           2.812900E-01          -6.723400E-02          -1.238650E-01
2.089240E-01          -1.970000E-04           4.184300E-02           2.707590E-01           4.297220E-01
8.460800E-02           2.300000E-05          -4.002000E-03           5.758070E-01           6.507860E-01
Cr    P 3.325800E-02           1.0000000
Cr    D 8.857680E+01           3.621000E-03          -4.122000E-03
2.620450E+01           2.576600E-02          -2.930700E-02
9.517470E+00           9.755600E-02          -1.150620E-01
3.822480E+00           2.363120E-01          -2.730680E-01
1.575120E+00           3.582860E-01          -3.144230E-01
6.289280E-01           3.685430E-01           4.209700E-02
2.344240E-01           2.354940E-01           5.914030E-01
Cr    D 7.681500E-02           1.0000000
Cr    F 2.221100E+00           4.235450E-01
5.231000E-01           7.741140E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Mn    S 3.960805E+06           8.242127E-06          -3.936095E-06           9.462709E-07          -2.095391E-07          -4.121231E-07
5.931155E+05           6.408587E-05          -3.060481E-05           7.360584E-06          -1.629439E-06          -3.282099E-06
1.349768E+05           3.369253E-04          -1.609626E-04           3.869935E-05          -8.570592E-06          -1.667433E-05
3.823067E+04           1.420648E-03          -6.792348E-04           1.635110E-04          -3.619272E-05          -7.369999E-05
1.247154E+04           5.143683E-03          -2.466182E-03           5.941775E-04          -1.316146E-04          -2.529495E-04
4.501743E+03           1.648569E-02          -7.957629E-03           1.927737E-03          -4.266810E-04          -8.801425E-04
1.755212E+03           4.698560E-02          -2.307248E-02           5.641731E-03          -1.250270E-03          -2.365482E-03
7.273039E+02           1.162437E-01          -5.932956E-02           1.487848E-02          -3.294665E-03          -6.926354E-03
3.163678E+02           2.335277E-01          -1.299451E-01           3.414783E-02          -7.581860E-03          -1.393851E-02
1.430098E+02           3.292837E-01          -2.212352E-01           6.405794E-02          -1.422864E-02          -3.143840E-02
6.621805E+01           2.440304E-01          -2.292550E-01           7.557659E-02          -1.693796E-02          -2.625749E-02
2.991896E+01           7.219806E-02           3.580733E-02          -1.946070E-02           4.454298E-03          -1.048313E-02
1.430318E+01           7.687806E-02           5.107602E-01          -2.957874E-01           6.867042E-02           1.856472E-01
6.839451E+00           7.852235E-02           5.008307E-01          -4.521170E-01           1.113335E-01           1.524839E-01
3.012374E+00           1.294109E-02           9.011830E-02           1.224531E-01          -3.900820E-02           7.411368E-02
1.418808E+00          -3.784873E-04          -6.909909E-03           7.169756E-01          -2.215755E-01          -1.018097E+00
6.236240E-01          -2.503203E-05          -1.912925E-04           4.092712E-01          -2.544359E-01           2.980372E-01
1.340980E-01          -2.421517E-05          -6.032312E-04           2.221969E-02           2.865866E-01           1.971989E+00
6.554800E-02           3.462071E-05           5.621608E-04          -9.011202E-03           5.755741E-01          -1.179253E+00
Mn    S 2.958400E-02           1.0000000
Mn    P 1.620586E+04           4.200000E-05          -1.500000E-05           3.000000E-06           4.000000E-06
3.836274E+03           3.730000E-04          -1.290000E-04           3.000000E-05           4.000000E-05
1.246048E+03           2.149000E-03          -7.480000E-04           1.720000E-04           2.260000E-04
4.767535E+02           9.445000E-03          -3.308000E-03           7.620000E-04           1.013000E-03
2.021895E+02           3.329700E-02          -1.181100E-02           2.726000E-03           3.575000E-03
9.209487E+01           9.475900E-02          -3.453300E-02           7.976000E-03           1.061200E-02
4.414720E+01           2.081440E-01          -7.878500E-02           1.828700E-02           2.390200E-02
2.185468E+01           3.318050E-01          -1.321830E-01           3.077600E-02           4.127900E-02
1.108596E+01           3.331750E-01          -1.371950E-01           3.237300E-02           4.147500E-02
5.674108E+00           1.576010E-01           2.707500E-02          -9.978000E-03          -9.458000E-03
2.823170E+00           2.144500E-02           3.288910E-01          -9.052900E-02          -1.236950E-01
1.368621E+00          -2.558000E-03           4.572800E-01          -1.380040E-01          -1.743920E-01
6.444310E-01          -2.027000E-03           2.889080E-01          -7.796500E-02          -1.291700E-01
2.483820E-01          -3.600000E-04           4.743300E-02           2.295600E-01           4.003480E-01
9.725500E-02           3.400000E-05          -3.522000E-03           5.761220E-01           6.696460E-01
Mn    P 3.663300E-02           1.0000000
Mn    D 1.006630E+02           3.579000E-03          -3.454000E-03
2.983360E+01           2.582700E-02          -2.492500E-02
1.088940E+01           9.855900E-02          -9.763500E-02
4.393580E+00           2.383270E-01          -2.366920E-01
1.817820E+00           3.587070E-01          -2.923500E-01
7.278270E-01           3.650920E-01          -4.973000E-03
2.712950E-01           2.337380E-01           5.065880E-01
Mn    D 8.830900E-02           1.0000000
Mn    F 2.703200E+00           4.267760E-01
6.438000E-01           7.697990E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Fe    S 4.316265E+06           8.048803E-06          -4.155954E-06           9.532178E-07          -2.063008E-07          -4.009367E-07
6.463424E+05           6.258306E-05          -3.231401E-05           7.414605E-06          -1.604169E-06          -3.189255E-06
1.470897E+05           3.290239E-04          -1.699525E-04           3.898393E-05          -8.438437E-06          -1.623079E-05
4.166152E+04           1.387355E-03          -7.171369E-04           1.647152E-04          -3.563151E-05          -7.157920E-05
1.359077E+04           5.023256E-03          -2.603625E-03           5.985980E-04          -1.295998E-04          -2.463958E-04
4.905750E+03           1.610140E-02          -8.399109E-03           1.942390E-03          -4.201534E-04          -8.544907E-04
1.912746E+03           4.590034E-02          -2.434109E-02           5.687237E-03          -1.231954E-03          -2.307593E-03
7.926043E+02           1.136154E-01          -6.251948E-02           1.501329E-02          -3.248922E-03          -6.728292E-03
3.448065E+02           2.283869E-01          -1.365929E-01           3.452455E-02          -7.493717E-03          -1.366165E-02
1.558999E+02           3.221159E-01          -2.312707E-01           6.495820E-02          -1.410102E-02          -3.062240E-02
7.223091E+01           2.383661E-01          -2.383734E-01           7.716194E-02          -1.691600E-02          -2.631137E-02
3.272506E+01           7.404667E-02           3.123837E-02          -1.873411E-02           4.218996E-03          -9.760183E-03
1.566762E+01           9.214197E-02           5.086818E-01          -3.009185E-01           6.833810E-02           1.801906E-01
7.503483E+00           9.339790E-02           4.987695E-01          -4.554661E-01           1.098201E-01           1.529634E-01
3.312223E+00           1.573965E-02           9.033552E-02           1.286463E-01          -4.009005E-02           5.505413E-02
1.558471E+00          -4.186682E-04          -6.005337E-03           7.183316E-01          -2.174739E-01          -9.551364E-01
6.839140E-01           5.376318E-05           2.312454E-04           4.051743E-01          -2.465135E-01           2.586813E-01
1.467570E-01          -3.816654E-05          -5.643680E-04           2.168227E-02           2.731435E-01           1.834049E+00
7.058300E-02           4.319603E-05           4.992260E-04          -8.343566E-03           5.748321E-01          -9.333240E-01
Fe    S 3.144900E-02           1.0000000
Fe    P 1.774569E+04           4.100000E-05          -1.500000E-05           3.000000E-06           5.000000E-06
4.200721E+03           3.690000E-04          -1.300000E-04           2.900000E-05           4.200000E-05
1.364429E+03           2.129000E-03          -7.510000E-04           1.650000E-04           2.410000E-04
5.220806E+02           9.369000E-03          -3.329000E-03           7.340000E-04           1.085000E-03
2.214595E+02           3.309700E-02          -1.191200E-02           2.626000E-03           3.831000E-03
1.009096E+02           9.443100E-02          -3.493300E-02           7.725000E-03           1.142300E-02
4.840115E+01           2.080770E-01          -7.998900E-02           1.773300E-02           2.579200E-02
2.398536E+01           3.323330E-01          -1.346360E-01           3.005500E-02           4.481800E-02
1.218250E+01           3.329870E-01          -1.385980E-01           3.109400E-02           4.459800E-02
6.242298E+00           1.568430E-01           3.027800E-02          -1.004800E-02          -1.117700E-02
3.110944E+00           2.154900E-02           3.332160E-01          -8.830600E-02          -1.381340E-01
1.509958E+00          -2.095000E-03           4.561530E-01          -1.298240E-01          -1.882850E-01
7.108450E-01          -1.739000E-03           2.850510E-01          -7.693700E-02          -1.073990E-01
2.731900E-01          -3.000000E-04           4.614400E-02           2.126610E-01           4.448630E-01
1.042330E-01           2.900000E-05          -3.249000E-03           5.730610E-01           6.402390E-01
Fe    P 3.829100E-02           1.0000000
Fe    D 1.133440E+02           3.530000E-03          -3.890000E-03
3.364140E+01           2.578400E-02          -2.844200E-02
1.233100E+01           9.911900E-02          -1.124290E-01
4.994780E+00           2.390730E-01          -2.742570E-01
2.072800E+00           3.571990E-01          -3.155460E-01
8.307530E-01           3.621880E-01           5.710900E-02
3.091780E-01           2.364610E-01           5.636040E-01
Fe    D 1.001300E-01           1.0000000
Fe    F 3.224300E+00           4.222490E-01
7.758000E-01           7.714680E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Co    S 4.675675E+06           7.979026E-06          -4.200240E-06           9.592692E-07          -2.028840E-07          -3.863053E-07
7.001615E+05           6.204071E-05          -3.265831E-05           7.461851E-06          -1.577580E-06          -3.068788E-06
1.593373E+05           3.261735E-04          -1.717644E-04           3.923137E-05          -8.298813E-06          -1.564826E-05
4.513046E+04           1.375360E-03          -7.247853E-04           1.657706E-04          -3.504154E-05          -6.883588E-05
1.472238E+04           4.979997E-03          -2.631462E-03           6.024335E-04          -1.274655E-04          -2.377367E-04
5.314222E+03           1.596434E-02          -8.489272E-03           1.955217E-03          -4.132695E-04          -8.213173E-04
2.072018E+03           4.552086E-02          -2.460619E-02           5.726326E-03          -1.212261E-03          -2.229630E-03
8.586188E+02           1.127385E-01          -6.322059E-02           1.512984E-02          -3.199318E-03          -6.467841E-03
3.735497E+02           2.268262E-01          -1.381957E-01           3.483973E-02          -7.390972E-03          -1.325463E-02
1.689229E+02           3.203074E-01          -2.340680E-01           6.570351E-02          -1.393649E-02          -2.946686E-02
7.829639E+01           2.374021E-01          -2.415002E-01           7.831503E-02          -1.678575E-02          -2.599066E-02
3.552123E+01           7.477686E-02           3.035312E-02          -1.877037E-02           4.149856E-03          -8.499807E-03
1.704144E+01           9.581872E-02           5.101341E-01          -3.062663E-01           6.797646E-02           1.727316E-01
8.173000E+00           9.649911E-02           4.974939E-01          -4.566429E-01           1.075807E-01           1.512189E-01
3.610318E+00           1.623362E-02           8.970746E-02           1.378169E-01          -4.166022E-02           3.554509E-02
1.697047E+00          -4.535497E-04          -5.941034E-03           7.193676E-01          -2.128044E-01          -8.829353E-01
7.435320E-01           5.113519E-05           2.175362E-04           3.992579E-01          -2.381360E-01           2.143530E-01
1.583440E-01          -4.174508E-05          -5.480155E-04           2.079933E-02           2.650788E-01           1.711865E+00
7.503600E-02           4.027577E-05           4.525804E-04          -7.820663E-03           5.722774E-01          -7.140037E-01
Co    S 3.309100E-02           1.0000000
Co    P 1.926778E+04           4.100000E-05          -1.500000E-05          -3.000000E-06           5.000000E-06
4.560986E+03           3.690000E-04          -1.310000E-04          -2.900000E-05           4.500000E-05
1.481436E+03           2.128000E-03          -7.580000E-04          -1.670000E-04           2.550000E-04
5.668671E+02           9.372000E-03          -3.363000E-03          -7.420000E-04           1.144000E-03
2.404910E+02           3.315500E-02          -1.205400E-02          -2.662000E-03           4.061000E-03
1.096105E+02           9.475200E-02          -3.542400E-02          -7.841000E-03           1.209500E-02
5.259491E+01           2.090930E-01          -8.128700E-02          -1.805100E-02           2.747600E-02
2.608361E+01           3.337220E-01          -1.369080E-01          -3.058000E-02           4.755700E-02
1.326143E+01           3.322080E-01          -1.390190E-01          -3.131200E-02           4.730200E-02
6.799778E+00           1.546130E-01           3.546800E-02           1.131100E-02          -1.441800E-02
3.393414E+00           2.090200E-02           3.384980E-01           8.999000E-02          -1.500620E-01
1.648766E+00          -2.024000E-03           4.544330E-01           1.307330E-01          -1.990920E-01
7.762820E-01          -1.697000E-03           2.797930E-01           7.180800E-02          -7.978300E-02
2.980030E-01          -2.800000E-04           4.477600E-02          -2.216580E-01           4.590350E-01
1.136180E-01           2.600000E-05          -3.151000E-03          -5.710250E-01           6.174950E-01
Co    P 4.162400E-02           1.0000000
Co    D 1.262640E+02           3.510000E-03          -4.067000E-03
3.752260E+01           2.588400E-02          -3.005300E-02
1.380210E+01           1.000580E-01          -1.196200E-01
5.609270E+00           2.405470E-01          -2.915130E-01
2.333690E+00           3.568430E-01          -3.180480E-01
9.364150E-01           3.595790E-01           9.169800E-02
3.482370E-01           2.366290E-01           5.608230E-01
Co    D 1.123530E-01           1.0000000
Co    F 3.772400E+00           4.239660E-01
9.170000E-01           7.684290E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Ni    S 5.045991E+06           8.208996E-06          -3.657849E-06           9.594149E-07          -2.013753E-07          -3.924245E-07
7.556142E+05           6.382884E-05          -2.844094E-05           7.462614E-06          -1.565832E-06          -3.113909E-06
1.719568E+05           3.355800E-04          -1.495928E-04           3.923843E-05          -8.237182E-06          -1.590447E-05
4.870479E+04           1.415075E-03          -6.313009E-04           1.657868E-04          -3.478105E-05          -6.981394E-05
1.588841E+04           5.124444E-03          -2.293052E-03           6.025905E-04          -1.265265E-04          -2.417848E-04
5.735123E+03           1.643256E-02          -7.405123E-03           1.955662E-03          -4.102589E-04          -8.326195E-04
2.236137E+03           4.689398E-02          -2.152032E-02           5.730391E-03          -1.203834E-03          -2.270294E-03
9.266468E+02           1.163534E-01          -5.560974E-02           1.514756E-02          -3.179062E-03          -6.557427E-03
4.031743E+02           2.350511E-01          -1.230176E-01           3.493499E-02          -7.353828E-03          -1.354288E-02
1.823476E+02           3.350184E-01          -2.130104E-01           6.598072E-02          -1.389022E-02          -2.989768E-02
8.454885E+01           2.534779E-01          -2.265837E-01           7.893083E-02          -1.677875E-02          -2.693106E-02
3.839634E+01           7.300901E-02           3.546796E-02          -1.906249E-02           4.163378E-03          -7.827693E-03
1.845859E+01           6.184244E-02           5.181697E-01          -3.095921E-01           6.814703E-02           1.741667E-01
8.863548E+00           6.302956E-02           5.025630E-01          -4.558610E-01           1.061029E-01           1.595468E-01
3.916227E+00           1.008063E-02           8.955674E-02           1.482931E-01          -4.339980E-02           1.995550E-02
1.838870E+00          -2.244528E-04          -7.031311E-03           7.134039E-01          -2.094950E-01          -8.897000E-01
8.043620E-01          -5.932767E-05          -4.339167E-04           3.976063E-01          -2.310271E-01           2.486892E-01
1.697970E-01          -1.158562E-05          -5.831711E-04           2.295523E-02           2.590532E-01           1.613012E+00
7.930600E-02           8.115109E-06           4.228788E-04          -9.151758E-03           5.691426E-01          -5.990277E-01
Ni    S 3.467700E-02           1.0000000
Ni    P 2.102792E+04           4.100000E-05          -1.500000E-05           3.000000E-06           6.000000E-06
4.977560E+03           3.630000E-04          -1.290000E-04           2.600000E-05           5.300000E-05
1.616740E+03           2.097000E-03          -7.490000E-04           1.520000E-04           3.050000E-04
6.186718E+02           9.250000E-03          -3.328000E-03           6.780000E-04           1.364000E-03
2.625183E+02           3.279600E-02          -1.194700E-02           2.427000E-03           4.876000E-03
1.196907E+02           9.400400E-02          -3.524200E-02           7.201000E-03           1.450300E-02
5.746585E+01           2.082800E-01          -8.120400E-02           1.657800E-02           3.329600E-02
2.852829E+01           3.336540E-01          -1.374930E-01           2.839200E-02           5.748200E-02
1.452148E+01           3.329040E-01          -1.392260E-01           2.859900E-02           5.870200E-02
7.453850E+00           1.553720E-01           3.601600E-02          -1.013200E-02          -1.990400E-02
3.723553E+00           2.085900E-02           3.391280E-01          -8.291200E-02          -1.946950E-01
1.809813E+00          -2.440000E-03           4.504720E-01          -1.159980E-01          -2.396130E-01
8.513360E-01          -1.998000E-03           2.817830E-01          -7.279500E-02          -2.232000E-03
3.248140E-01          -3.380000E-04           4.789800E-02           1.956400E-01           5.214350E-01
1.195220E-01           3.500000E-05          -2.987000E-03           5.670990E-01           5.455400E-01
Ni    P 4.236600E-02           1.0000000
Ni    D 1.402527E+02           3.376000E-03          -3.495000E-03
4.172610E+01           2.514100E-02          -2.601500E-02
1.539810E+01           9.774600E-02          -1.038760E-01
6.277100E+00           2.347090E-01          -2.520700E-01
2.618500E+00           3.469450E-01          -2.945800E-01
1.052600E+00           3.510680E-01           1.152000E-03
3.916000E-01           2.502550E-01           4.385890E-01
Ni    D 1.262000E-01           1.0000000
Ni    F 4.345500E+00           4.174290E-01
1.068000E+00           7.714830E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Cu    S 5.430321E+06           7.801026E-06          -4.404706E-06           9.704682E-07          -1.959354E-07          -3.532229E-07
8.131665E+05           6.065666E-05          -3.424801E-05           7.549245E-06          -1.523472E-06          -2.798812E-06
1.850544E+05           3.188964E-04          -1.801238E-04           3.968892E-05          -8.014808E-06          -1.432517E-05
5.241466E+04           1.344687E-03          -7.600455E-04           1.677200E-04          -3.383992E-05          -6.270946E-05
1.709868E+04           4.869050E-03          -2.759348E-03           6.095101E-04          -1.231191E-04          -2.179490E-04
6.171994E+03           1.561013E-02          -8.900970E-03           1.978846E-03          -3.992085E-04          -7.474316E-04
2.406481E+03           4.452077E-02          -2.579378E-02           5.798049E-03          -1.171900E-03          -2.049271E-03
9.972584E+02           1.103111E-01          -6.623861E-02           1.534158E-02          -3.096141E-03          -5.885203E-03
4.339289E+02           2.220342E-01          -1.445927E-01           3.540484E-02          -7.171993E-03          -1.226885E-02
1.962869E+02           3.133739E-01          -2.440110E-01           6.702098E-02          -1.356621E-02          -2.683147E-02
9.104280E+01           2.315121E-01          -2.504837E-01           8.026945E-02          -1.643989E-02          -2.479261E-02
4.138425E+01           7.640920E-02           2.852577E-02          -1.927231E-02           4.107628E-03          -5.984746E-03
1.993278E+01           1.103818E-01           5.115874E-01          -3.160129E-01           6.693964E-02           1.557124E-01
9.581891E+00           1.094372E-01           4.928061E-01          -4.573162E-01           1.028221E-01           1.436683E-01
4.234516E+00           1.836311E-02           8.788437E-02           1.550841E-01          -4.422945E-02           8.374103E-03
1.985814E+00          -6.043084E-04          -5.820281E-03           7.202872E-01          -2.031191E-01          -7.460711E-01
8.670830E-01           5.092245E-05           2.013508E-04           3.885122E-01          -2.230022E-01           1.244367E-01
1.813390E-01          -5.540730E-05          -5.182553E-04           1.924326E-02           2.517975E-01           1.510110E+00
8.365700E-02           3.969482E-05           3.731503E-04          -7.103807E-03           5.650091E-01          -3.477122E-01
Cu    S 3.626700E-02           1.0000000
Cu    P 2.276057E+04           4.000000E-05          -1.500000E-05           3.000000E-06           5.000000E-06
5.387679E+03           3.610000E-04          -1.310000E-04           2.500000E-05           4.900000E-05
1.749945E+03           2.083000E-03          -7.550000E-04           1.470000E-04           2.780000E-04
6.696653E+02           9.197000E-03          -3.359000E-03           6.560000E-04           1.253000E-03
2.841948E+02           3.266000E-02          -1.208100E-02           2.351000E-03           4.447000E-03
1.296077E+02           9.379500E-02          -3.570300E-02           7.004000E-03           1.337000E-02
6.225415E+01           2.082740E-01          -8.250200E-02           1.613100E-02           3.046900E-02
3.092964E+01           3.339930E-01          -1.398900E-01           2.777000E-02           5.344700E-02
1.575827E+01           3.324930E-01          -1.407290E-01           2.756700E-02           5.263900E-02
8.094211E+00           1.547280E-01           3.876600E-02          -1.011500E-02          -1.688100E-02
4.046921E+00           2.127100E-02           3.426950E-01          -8.100900E-02          -1.794480E-01
1.967869E+00          -1.690000E-03           4.523100E-01          -1.104090E-01          -2.095880E-01
9.252950E-01          -1.516000E-03           2.770540E-01          -7.173200E-02          -3.963300E-02
3.529920E-01          -2.420000E-04           4.388500E-02           1.879300E-01           5.021300E-01
1.273070E-01           2.300000E-05          -2.802000E-03           5.646290E-01           5.811110E-01
Cu    P 4.435600E-02           1.0000000
Cu    D 1.738970E+02           2.700000E-03          -3.363000E-03
5.188690E+01           2.090900E-02          -2.607900E-02
1.934190E+01           8.440800E-02          -1.082310E-01
7.975720E+00           2.139990E-01          -2.822170E-01
3.398230E+00           3.359800E-01          -3.471900E-01
1.409320E+00           3.573010E-01           2.671100E-02
5.488580E-01           2.645780E-01           4.920470E-01
Cu    D 1.901990E-01           1.0000000
Cu    F 5.028600E+00           4.242800E-01
1.259400E+00           7.630250E-01
#BASIS SET: (20s,16p,8d,2f) -> [6s,5p,3d,1f] Zn    S 5.820021E+06           8.549241E-06          -2.640069E-06           9.967103E-07           1.995818E-07          -5.435910E-07
8.715234E+05           6.647410E-05          -2.052720E-05           7.754163E-06           1.552973E-06          -4.336894E-06
1.983350E+05           3.494962E-04          -1.079859E-04           4.076019E-05           8.161259E-06          -2.197572E-05
5.617631E+04           1.473832E-03          -4.558577E-04           1.722811E-04           3.450747E-05          -9.747392E-05
1.832582E+04           5.338330E-03          -1.657758E-03           6.259370E-04           1.253275E-04          -3.331615E-04
6.614955E+03           1.712708E-02          -5.368492E-03           2.032855E-03           4.072990E-04          -1.166192E-03
2.579199E+03           4.894085E-02          -1.571249E-02           5.954646E-03           1.192734E-03          -3.119308E-03
1.068849E+03           1.217934E-01          -4.122558E-02           1.576640E-02           3.163140E-03          -9.239504E-03
4.651045E+02           2.476589E-01          -9.406459E-02           3.637638E-02           7.303942E-03          -1.855471E-02
2.104130E+02           3.582431E-01          -1.719954E-01           6.892343E-02           1.391279E-02          -4.281189E-02
9.761629E+01           2.798174E-01          -1.958523E-01           8.238093E-02           1.670620E-02          -3.571095E-02
4.438020E+01           6.857491E-02           4.532907E-02          -2.011360E-02          -4.035586E-03          -1.638350E-02
2.142308E+01          -1.311092E-03           5.244442E-01          -3.252526E-01          -6.968861E-02           2.644664E-01
1.030891E+01           1.914001E-03           5.006142E-01          -4.602899E-01          -1.030105E-01           2.086588E-01
4.553645E+00          -8.759220E-04           8.945527E-02           1.635546E-01           4.471442E-02          -1.774382E-02
2.132821E+00           3.740096E-04          -2.146262E-03           7.297118E-01           2.150027E-01          -1.353873E+00
9.296970E-01          -1.401399E-04           2.112113E-03           3.769751E-01           2.220163E-01           8.182926E-01
1.921470E-01           4.757132E-05          -4.133980E-04           1.433224E-02          -3.114776E-01           1.695036E+00
8.759500E-02          -3.642711E-05           3.209752E-04          -6.671210E-03          -5.693429E-01          -1.388656E+00
Zn    S 3.770200E-02           1.0000000
Zn    P 2.441198E+04           4.100000E-05          -1.500000E-05           3.000000E-06           5.000000E-06
5.778518E+03           3.610000E-04          -1.350000E-04           2.500000E-05           4.200000E-05
1.876862E+03           2.088000E-03          -7.820000E-04           1.440000E-04           2.380000E-04
7.182361E+02           9.221000E-03          -3.478000E-03           6.450000E-04           1.088000E-03
3.048327E+02           3.277300E-02          -1.252000E-02           2.311000E-03           3.821000E-03
1.390453E+02           9.417900E-02          -3.701600E-02           6.898000E-03           1.164400E-02
6.680417E+01           2.091320E-01          -8.555900E-02           1.588200E-02           2.616700E-02
3.320699E+01           3.345690E-01          -1.447180E-01           2.735000E-02           4.675000E-02
1.692816E+01           3.303590E-01          -1.434420E-01           2.662100E-02           4.330900E-02
8.696229E+00           1.523470E-01           4.359500E-02          -1.085800E-02          -1.342900E-02
4.350510E+00           2.298400E-02           3.488880E-01          -7.985300E-02          -1.538970E-01
2.116523E+00           1.607000E-03           4.538650E-01          -1.061270E-01          -1.674130E-01
9.953870E-01           4.680000E-04           2.685940E-01          -6.888300E-02          -8.499500E-02
3.781120E-01           6.600000E-05           3.886800E-02           1.843850E-01           4.508130E-01
1.345790E-01          -2.000000E-06          -2.492000E-03           5.617880E-01           6.408690E-01
Zn    P 4.628200E-02           1.0000000
Zn    D 2.056177E+02           2.342000E-03           3.279000E-03
6.144981E+01           1.860600E-02           2.617600E-02
2.305689E+01           7.710200E-02           1.113670E-01
9.577739E+00           2.020260E-01           3.045810E-01
4.133734E+00           3.294540E-01           3.862990E-01
1.747518E+00           3.609760E-01          -5.837500E-02
6.995600E-01           2.716570E-01          -5.388760E-01
Zn    D 2.516080E-01           1.0000000
Zn    F 5.734400E+00           4.311320E-01
1.461500E+00           7.546420E-01
#BASIS SET: (14s,11p,6d) -> [5s,4p,2d] Ga    S 485130.0000000              0.0002068             -0.0000643              0.0000245             -0.0000057
72719.0000000              0.0016047             -0.0004954              0.0001895             -0.0000440
16552.0000000              0.0083402             -0.0026208              0.0009964             -0.0002305
4687.8000000              0.0340248             -0.0106839              0.0041082             -0.0009544
1529.1000000              0.1111699             -0.0374123              0.0142938             -0.0033055
551.8100000              0.2753930             -0.1009636              0.0398034             -0.0092888
215.1800000              0.4212628             -0.2145141              0.0855940             -0.0198644
88.1740000              0.2738906             -0.1752297              0.0796305             -0.0190888
27.1540000              0.0283720              0.4831599             -0.2939107              0.0732356
11.5030000             -0.0062931              0.6323677             -0.5263914              0.1341526
3.3018000              0.0020606              0.0684942              0.5864249             -0.1831929
1.3314000             -0.0009269             -0.0118712              0.6726347             -0.3571308
0.1931600              0.0002273              0.0026652              0.0276123              0.6246013
Ga    S 0.0708950              1.0000000
Ga    P 3248.6000000              0.0015260             -0.0005803              0.0000950
769.9700000              0.0127486             -0.0048647              0.0007832
248.2000000              0.0633742             -0.0248394              0.0040855
93.3640000              0.2065775             -0.0841759              0.0135987
38.2510000              0.4092963             -0.1800885              0.0302695
16.4220000              0.3919183             -0.1585555              0.0241790
6.7918000              0.1029441              0.2355376             -0.0423777
2.8336000             -0.0007203              0.5820587             -0.1265661
1.1062000              0.0020950              0.3366619             -0.0499444
0.2225000             -0.0003290              0.0171912              0.4494199
Ga    P 0.0617720              1.0000000
Ga    D 65.3370000              0.0273825
18.4970000              0.1510805
6.3150000              0.3749217
2.1635000              0.4750799
0.6667500              0.2982750
Ga    D 0.1884000              1.0000000
#BASIS SET: (14s,11p,6d) -> [5s,4p,2d] Ge    S 521800.0000000              0.0002045             -0.0000638              0.0000246             -0.0000063
78214.0000000              0.0015868             -0.0004916              0.0001900             -0.0000486
17803.0000000              0.0082480             -0.0026002              0.0009993             -0.0002553
5041.9000000              0.0336649             -0.0106080              0.0041200             -0.0010560
1644.5000000              0.1101249             -0.0371602              0.0143557             -0.0036674
593.4300000              0.2735607             -0.1005790              0.0400375             -0.0103053
231.3600000              0.4210670             -0.2143977              0.0865794             -0.0222200
94.7620000              0.2766791             -0.1782617              0.0815861             -0.0215275
29.2740000              0.0292180              0.4777404             -0.2934770              0.0806752
12.4500000             -0.0065903              0.6355983             -0.5367983              0.1524958
3.6463000              0.0022430              0.0722174              0.5637985             -0.1980528
1.5025000             -0.0010382             -0.0127265              0.6947182             -0.4073954
0.2450300              0.0002695              0.0029608              0.0315730              0.6477288
Ge    S 0.0915940              1.0000000
Ge    P 3568.1000000              0.0014591             -0.0005630              0.0001115
845.7200000              0.0122176             -0.0047354              0.0009212
272.7400000              0.0610490             -0.0242643              0.0048273
102.6800000              0.2008039             -0.0830900              0.0162272
42.1480000              0.4038942             -0.1800247              0.0366354
18.1490000              0.3970027             -0.1663295              0.0307867
7.5934000              0.1105481              0.2193717             -0.0480643
3.1964000              0.0000768              0.5820239             -0.1559804
1.2743000              0.0021263              0.3477720             -0.0632370
0.2825800             -0.0003744              0.0192455              0.5040819
Ge    P 0.0840900              1.0000000
Ge    D 74.7620000              0.0257684
21.3020000              0.1454421
7.3436000              0.3713721
2.5651000              0.4800002
0.8197000              0.2896800
Ge    D 0.2470000              1.0000000
#BASIS SET: (14s,11p,6d) -> [5s,4p,2d] As    S 559583.7900000              0.0002024             -0.0000634              0.0000246             -0.0000068
83879.3300000              0.0015709             -0.0004883              0.0001907             -0.0000525
19092.6680000              0.0081662             -0.0025821              0.0010031             -0.0002756
5407.3925000              0.0333399             -0.0105402              0.0041353             -0.0011389
1763.7559000              0.1091726             -0.0369325              0.0144259             -0.0039646
636.4567200              0.2718853             -0.1002355              0.0402962             -0.0111423
248.0884300              0.4208509             -0.2142948              0.0875670             -0.0241991
101.5785100              0.2792257             -0.1810526              0.0835178             -0.0236339
31.4755130              0.0300301              0.4725410             -0.2932935              0.0866317
13.4372820             -0.0068804              0.6386194             -0.5470520              0.1685839
4.0086900              0.0024240              0.0758107              0.5438738             -0.2091425
1.6849290             -0.0011491             -0.0135278              0.7143591             -0.4500918
0.3000190              0.0003095              0.0031970              0.0353443              0.6603978
As    S 0.1135870              1.0000000
As    P 3886.3564000              0.0014097             -0.0005519              0.0001236
921.2020100              0.0118277             -0.0046550              0.0010240
297.1931900              0.0593280             -0.0239176              0.0053805
111.9750800              0.1965115             -0.0825627              0.0182443
46.0346210              0.3997891             -0.1806791              0.0415979
19.8741940              0.4004653             -0.1724848              0.0362998
8.3860880              0.1164196              0.2086700             -0.0523569
3.5587280              0.0006918              0.5823622             -0.1791667
1.4472820              0.0021633              0.3537465             -0.0740477
0.3477790             -0.0004150              0.0206439              0.5358094
As    P 0.1076990              1.0000000
As    D 84.4242340              0.0245288
24.1815890              0.1411340
8.4017770              0.3687579
2.9805020              0.4840626
0.9790030              0.2824434
As    D 0.3098000              1.0000000
#BASIS SET: (14s,11p,6d) -> [5s,4p,2d] Se    S 598990.0000000              0.0002004             -0.0000629              0.0000247             -0.0000072
89783.0000000              0.0015554             -0.0004850              0.0001913             -0.0000559
20435.0000000              0.0080872             -0.0025644              0.0010068             -0.0002938
5786.9000000              0.0330344             -0.0104761              0.0041514             -0.0012136
1887.3000000              0.1082924             -0.0367223              0.0144991             -0.0042340
680.9700000              0.2703361             -0.0999225              0.0405658             -0.0119035
265.3900000              0.4206236             -0.2141973              0.0885364             -0.0260206
108.6300000              0.2815922             -0.1836593              0.0854212             -0.0256148
33.7600000              0.0308110              0.4675454             -0.2932581              0.0919427
14.4650000             -0.0071617              0.6414740             -0.5570727              0.1838700
4.3890000              0.0026022              0.0792569              0.5261436             -0.2188461
1.8783000             -0.0012583             -0.0142697              0.7320371             -0.4896524
0.3585900              0.0003465              0.0033792              0.0388246              0.6775818
Se    S 0.1364900              1.0000000
Se    P 4135.6000000              0.0014127             -0.0005610              0.0001366
980.3400000              0.0118588             -0.0047340              0.0011308
316.3500000              0.0595153             -0.0243504              0.0059581
119.2500000              0.1972201             -0.0841071              0.0201866
49.0680000              0.4007439             -0.1841384              0.0461939
21.2120000              0.3994740             -0.1735004              0.0394050
8.9462000              0.1153364              0.2167263             -0.0592846
3.8236000              0.0002219              0.5850099             -0.2014663
1.5883000              0.0022838              0.3416816             -0.0687821
0.4096900             -0.0004756              0.0199125              0.5595944
Se    P 0.1245900              1.0000000
Se    D 94.4720000              0.0234982
27.1800000              0.1375183
9.5068000              0.3664824
3.4168000              0.4874717
1.1479000              0.2765769
Se    D 0.3682000              1.0000000
#BASIS SET: (14s,11p,6d) -> [5s,4p,2d] Br    S 640100.0000000              0.0001984             -0.0000625              0.0000248             -0.0000076
95938.0000000              0.0015400             -0.0004816              0.0001919             -0.0000588
21833.0000000              0.0080096             -0.0025466              0.0010100             -0.0003092
6181.9000000              0.0327341             -0.0104112              0.0041659             -0.0012766
2015.7000000              0.1074480             -0.0365179              0.0145683             -0.0044634
727.1000000              0.2688946             -0.0996295              0.0408345             -0.0125575
283.2800000              0.4204411             -0.2141310              0.0894859             -0.0276145
115.9100000              0.2838041             -0.1860911              0.0872786             -0.0273945
36.1240000              0.0315455              0.4628261             -0.2933644              0.0964094
15.5320000             -0.0074268              0.6441141             -0.5667109              0.1976871
4.7857000              0.0027728              0.0825502              0.5105658             -0.2266693
2.0817000             -0.0013635             -0.0149694              0.7477214             -0.5241165
0.4202800              0.0003812              0.0035288              0.0421512              0.6889865
Br    S 0.1606900              1.0000000
Br    P 4340.8000000              0.0014448             -0.0005819              0.0001518
1028.9000000              0.0121288             -0.0049065              0.0012563
332.0200000              0.0608077             -0.0252514              0.0066224
125.1600000              0.2009358             -0.0869445              0.0223816
51.5110000              0.4047419             -0.1893422              0.0509717
22.2810000              0.3957151             -0.1710882              0.0414009
9.3417000              0.1102213              0.2368755             -0.0703970
4.0132000             -0.0009090              0.5898400             -0.2232540
1.7002000              0.0024832              0.3171944             -0.0564179
0.4719400             -0.0005744              0.0179833              0.5808079
Br    P 0.1442100              1.0000000
Br    D 104.8300000              0.0226583
30.2720000              0.1345895
10.6490000              0.3647181
3.8696000              0.4904196
1.3239000              0.2713885
Br    D 0.4098000              1.0000000
#BASIS SET: (14s,11p,6d) -> [5s,4p,2d] Kr    S 681358.8200000              0.0001969             -0.0000622              0.0000249             -0.0000079
102126.4800000              0.0015286             -0.0004794              0.0001928             -0.0000614
23243.7100000              0.0079500             -0.0025341              0.0010149             -0.0003230
6582.0073000              0.0324938             -0.0103636              0.0041857             -0.0013330
2146.4286000              0.1067240             -0.0363516              0.0146459             -0.0046672
774.3378200              0.2675701             -0.0993737              0.0411070             -0.0131352
301.6702000              0.4201851             -0.2140610              0.0903955             -0.0290342
123.4118400              0.2858015             -0.1883192              0.0890623             -0.0290173
38.5675510              0.0322461              0.4583816             -0.2935718              0.1002664
16.6373790             -0.0076828              0.6465664             -0.5759698              0.2103818
5.1987950              0.0029393              0.0856579              0.4968578             -0.2332471
2.2948140             -0.0014662             -0.0156123              0.7616895             -0.5546497
0.4852110              0.0004144              0.0036490              0.0453267              0.6969522
Kr    S 0.1862700              1.0000000
Kr    P 4474.2699000              0.0015195             -0.0006208              0.0001701
1060.5790000              0.0127424             -0.0052212              0.0014064
342.2081200              0.0636465             -0.0268463              0.0073963
128.9984200              0.2085635             -0.0915823              0.0248254
53.0872220              0.4122423             -0.1968164              0.0557155
22.9594250              0.3878103             -0.1634750              0.0412132
9.5073000              0.1003820              0.2738204             -0.0876057
4.0830550             -0.0025078              0.5981592             -0.2440586
1.7504460              0.0027139              0.2750453             -0.0295007
0.5291900             -0.0006977              0.0127706              0.6012295
Kr    P 0.1643690              1.0000000
Kr    D 115.5253200              0.0219557
33.4652460              0.1321620
11.8304590              0.3633484
4.3397710              0.4929582
1.5075240              0.2667560
Kr    D 0.5030000              1.0000000
END
================================================================================FILE: cint.h.in
/*
Copyright (C) 2013-  Qiming Sun osirpt.sun@gmail.com
Parameters and function signature for libcint. */
#define CINT_VERSION            "@cint_VERSION@" #define CINT_SOVERSION          @cint_SOVERSION@
#cmakedefine I8 #ifdef I8 #include <stdint.h> #define FINT int64_t #else #define FINT int #endif
#cmakedefine CACHE_SIZE_I8 #ifdef CACHE_SIZE_I8 #include <stdint.h> #define CACHE_SIZE_T int64_t #else #define CACHE_SIZE_T FINT #endif
// global parameters in env // Overall cutoff for integral prescreening, value needs to be ~ln(threshold) #define PTR_EXPCUTOFF           0 // R_C of (r-R_C) in dipole, GIAO operators #define PTR_COMMON_ORIG         1 // R_O in 1/|r-R_O| #define PTR_RINV_ORIG           4 // ZETA parameter for Gaussian charge distribution (Gaussian nuclear model) #define PTR_RINV_ZETA           7 // omega parameter in range-separated coulomb operator // LR interaction: erf(omegar12)/r12 if omega > 0// SR interaction: erfc(omegar12)/r12 if omega < 0 #define PTR_RANGE_OMEGA         8 // Yukawa potential and Slater-type geminal e^{-zeta r} #define PTR_F12_ZETA            9 // Gaussian type geminal e^{-zeta r^2} #define PTR_GTG_ZETA            10 #define NGRIDS                  11 #define PTR_GRIDS               12 #define PTR_ENV_START           20
// slots of atm #define CHARGE_OF       0 #define PTR_COORD       1 #define NUC_MOD_OF      2 #define PTR_ZETA        3 #define PTR_FRAC_CHARGE 4 #define RESERVE_ATMSLOT 5 #define ATM_SLOTS       6
// slots of bas #define ATOM_OF         0 #define ANG_OF          1 #define NPRIM_OF        2 #define NCTR_OF         3 #define KAPPA_OF        4 #define PTR_EXP         5 #define PTR_COEFF       6 #define RESERVE_BASLOT  7 #define BAS_SLOTS       8
// slots of gout #define POSX            0 #define POSY            1 #define POSZ            2 #define POS1            3 // For 2-electron integral with two spin operators // SIGMA1X * SIGMA2X     0 // SIGMA1Y * SIGMA2X     1 // SIGMA1Z * SIGMA2X     2 // I1_2x2  * SIGMA2X     3 // SIGMA1X * SIGMA2Y     4 // SIGMA1Y * SIGMA2Y     5 // SIGMA1Z * SIGMA2Y     6 // I1_2x2  * SIGMA2Y     7 // SIGMA1X * SIGMA2Z     8 // SIGMA1Y * SIGMA2Z     9 // SIGMA1Z * SIGMA2Z     10 // I1_2x2  * SIGMA2Z     11 // SIGMA1X * I2_2x2      12 // SIGMA1Y * I2_2x2      13 // SIGMA1Z * I2_2x2      14 // I1_2x2  * I2_2x2      15 #define POSXX           0 #define POSYX           1 #define POSZX           2 #define POS1X           3 #define POSXY           4 #define POSYY           5 #define POSZY           6 #define POS1Y           7 #define POSXZ           8 #define POSYZ           9 #define POSZZ           10 #define POS1Z           11 #define POSX1           12 #define POSY1           13 #define POSZ1           14 #define POS11           15
// tensor #define TSRX        0 #define TSRY        1 #define TSRZ        2 #define TSRXX       0 #define TSRXY       1 #define TSRXZ       2 #define TSRYX       3 #define TSRYY       4 #define TSRYZ       5 #define TSRZX       6 #define TSRZY       7 #define TSRZZ       8
// other boundaries #define MXRYSROOTS      32 // > ANG_MAX2+1 for 4c2e#define ANG_MAX         15 // l = 0..15#define LMAX1           16 // > ANG_MAX#define CART_MAX        136 // > (ANG_MAX(ANG_MAX+1)/2) #define SHLS_MAX        1048576 #define NPRIM_MAX       64 #define NCTR_MAX        64
#define POINT_NUC       1 #define GAUSSIAN_NUC    2 #define FRAC_CHARGE_NUC 3
#define bas(SLOT,I)     bas[BAS_SLOTS * (I) + (SLOT)] #define atm(SLOT,I)     atm[ATM_SLOTS * (I) + (SLOT)]
#if !defined HAVE_DEFINED_CINTOPT_H #define HAVE_DEFINED_CINTOPT_H typedef struct { double rij[3]; double eij; double cceij; } PairData; typedef struct { FINT index_xyz_array; // LMAX14 pointers to index_xyz FINT **non0ctr; FINT **sortedidx; FINT nbas; double **log_max_coeff; PairData **pairdata;  // NULL indicates not-initialized, NO_VALUE can be skipped } CINTOpt;
// Add this macro def to make pyscf compatible with both v4 and v5 #define HAVE_DEFINED_CINTENVVARS_H typedef struct { FINT *atm; FINT *bas; double *env; FINT *shls; FINT natm; FINT nbas;
} CINTEnvVars; #endif
FINT CINTlen_cart(const FINT l); FINT CINTlen_spinor(const FINT bas_id, const FINT *bas);
FINT CINTcgtos_cart(const FINT bas_id, const FINT *bas); FINT CINTcgtos_spheric(const FINT bas_id, const FINT *bas); FINT CINTcgtos_spinor(const FINT bas_id, const FINT *bas); FINT CINTcgto_cart(const FINT bas_id, const FINT *bas); FINT CINTcgto_spheric(const FINT bas_id, const FINT *bas); FINT CINTcgto_spinor(const FINT bas_id, const FINT *bas);
FINT CINTtot_pgto_spheric(const FINT *bas, const FINT nbas); FINT CINTtot_pgto_spinor(const FINT *bas, const FINT nbas);
FINT CINTtot_cgto_cart(const FINT *bas, const FINT nbas); FINT CINTtot_cgto_spheric(const FINT *bas, const FINT nbas); FINT CINTtot_cgto_spinor(const FINT *bas, const FINT nbas);
void CINTshells_cart_offset(FINT ao_loc[], const FINT *bas, const FINT nbas); void CINTshells_spheric_offset(FINT ao_loc[], const FINT *bas, const FINT nbas); void CINTshells_spinor_offset(FINT ao_loc[], const FINT *bas, const FINT nbas);
double *CINTc2s_bra_sph(double *sph, FINT nket, double *cart, FINT l); double *CINTc2s_ket_sph(double *sph, FINT nket, double *cart, FINT l); double *CINTc2s_ket_sph1(double *sph, double *cart, FINT lds, FINT ldc, FINT l);
double CINTgto_norm(FINT n, double a);
void CINTinit_2e_optimizer(CINTOpt **opt, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env); void CINTinit_optimizer(CINTOpt **opt, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env); void CINTdel_2e_optimizer(CINTOpt **opt); void CINTdel_optimizer(CINTOpt **opt);
FINT cint2e_cart(double *opijkl, FINT *shls, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env, CINTOpt *opt); void cint2e_cart_optimizer(CINTOpt **opt, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env); FINT cint2e_sph(double *opijkl, FINT *shls, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env, CINTOpt *opt); void cint2e_sph_optimizer(CINTOpt **opt, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env); FINT cint2e(double *opijkl, FINT *shls, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env, CINTOpt *opt); void cint2e_optimizer(CINTOpt **opt, FINT *atm, FINT natm, FINT *bas, FINT nbas, double *env);
#ifndef __cplusplus #include <complex.h>
void CINTc2s_ket_spinor_sf1(double complex *gspa, double complex *gspb, double *gcart, FINT lds, FINT ldc, FINT nctr, FINT l, FINT kappa); void CINTc2s_iket_spinor_sf1(double complex *gspa, double complex *gspb, double *gcart, FINT lds, FINT ldc, FINT nctr, FINT l, FINT kappa); void CINTc2s_ket_spinor_si1(double complex *gspa, double complex *gspb, double *gcart, FINT lds, FINT ldc, FINT nctr, FINT l, FINT kappa); void CINTc2s_iket_spinor_si1(double complex *gspa, double complex *gspb, double *gcart, FINT lds, FINT ldc, FINT nctr, FINT l, FINT kappa); #endif
================================================================================FILE: demo.py
#!/usr/bin/env python3 """demo.py — Демонстрация POLER DYNAMIS на H₂, H₂O и растянутой H₂."""
from pyscf import gto, scf
print("╔══════════════════════════════════════════════════════════════════════╗") print("║  POLER DYNAMIS — Демонстрация                                       ║") print("║  dp/dt = -η Π_Λ [D·p + γ J·p + ∇F]                                 ║") print("║  Π_Λ = McWeeny: DM_pure = (3/2)DM² - (1/2)DM³                      ║") print("╚══════════════════════════════════════════════════════════════════════╝\n")
========== H₂ ==========
print("="*60) print("TEST 1: H₂ (0.74 Å) — Standard vs POLER-A") print("="*60)
mol = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g', verbose=0) mf_std = scf.RHF(mol) e_std = mf_std.kernel() print(f"Standard:  {e_std:.12f} Ha  (conv={mf_std.converged}, cyc={mf_std.cycles})")
mol2 = gto.M(atom='H 0 0 0; H 0 0 0.74', basis='sto-3g', verbose=0) mf_poler = scf.RHF(mol2) mf_poler.use_poler = True mf_poler.poler_mode = 'A' mf_poler.poler_alpha = 0.7 mf_poler.poler_eta_base = 0.5 mf_poler.poler_d_strength = 0.1 e_poler = mf_poler.kernel() print(f"POLER-A:   {e_poler:.12f} Ha  (conv={mf_poler.converged}, cyc={mf_poler.cycles})") print(f"ΔE:        {abs(e_poler - e_std):.2e} Ha")
========== H₂O ==========
print("\n" + "="*60) print("TEST 2: H₂O — Standard vs POLER-A") print("="*60)
mol3 = gto.M(atom='O 0 0 0; H 0 0 0.96; H 0 0.96 0', basis='sto-3g', verbose=0) e_h2o_std = scf.RHF(mol3).kernel() print(f"Standard:  {e_h2o_std:.12f} Ha")
mol4 = gto.M(atom='O 0 0 0; H 0 0 0.96; H 0 0.96 0', basis='sto-3g', verbose=0) mf2 = scf.RHF(mol4) mf2.use_poler = True mf2.poler_mode = 'A' mf2.poler_alpha = 0.7 mf2.poler_eta_base = 0.3 mf2.poler_d_strength = 0.05 e_h2o_poler = mf2.kernel() print(f"POLER-A:   {e_h2o_poler:.12f} Ha  (conv={mf2.converged}, cyc={mf2.cycles})") print(f"ΔE:        {abs(e_h2o_poler - e_h2o_std):.2e} Ha")
========== H₂ Stretched ==========
print("\n" + "="*60) print("TEST 3: H₂ (5.0 Å) — Standard vs POLER-B (Resonant)") print("="*60)
mol5 = gto.M(atom='H 0 0 0; H 0 0 5.0', basis='sto-3g', verbose=0) e_std5 = scf.RHF(mol5).kernel() print(f"Standard:  {e_std5:.12f} Ha")
mol6 = gto.M(atom='H 0 0 0; H 0 0 5.0', basis='sto-3g', verbose=0) mf3 = scf.RHF(mol6) mf3.use_poler = True mf3.poler_mode = 'B' mf3.poler_alpha = 0.7 mf3.poler_eta_base = 0.3 mf3.poler_d_strength = 0.05 mf3.poler_j_strength = 0.3 e_poler5 = mf3.kernel() print(f"POLER-B:   {e_poler5:.12f} Ha  (conv={mf3.converged}, cyc={mf3.cycles})") print(f"ΔE:        {abs(e_poler5 - e_std5):.2e} Ha")
print("\n" + "="*60) print("SUMMARY") print("="*60) print(f"H₂ ΔE:       {abs(e_poler - e_std):.2e} Ha  {'SUCCESS' if abs(e_poler-e_std) < 1e-6 else 'CLOSE'}") print(f"H₂O ΔE:      {abs(e_h2o_poler - e_h2o_std):.2e} Ha  {'SUCCESS' if abs(e_h2o_poler-e_h2o_std) < 1e-3 else 'TUNING NEEDED'}") print(f"H₂(5Å) ΔE:   {abs(e_poler5 - e_std5):.2e} Ha  {'SUCCESS' if abs(e_poler5-e_std5) < 1e-6 else 'CLOSE'}")
================================================================================FILE: gto_utils_normalization_analysis.md
POLER-DYNAMIS v5: gto_utils.rs — Анализ проблемы нормализации
Дата: 2026-06-02
Статус: КРИТИЧЕСКАЯ ОШИБКА (неправильные интегралы для l >= 1)
--------------------------------------------------------------------------------
1. Структура модуля gto_utils.rs (106 строк)
Исходный код gto_utils.rs
--------------------------------------------------------------------------------
2. Зависимые модули
Кто вызывает gto_utils:
Кто реально нормализует env[]:
Ключевой комментарий в subquantum_bridge.rs (строка 363-365):
--------------------------------------------------------------------------------
3. Исходный код libcint C (CINTgto_norm)
Файл: vendor/libcint/src/utilities/misc.c
--------------------------------------------------------------------------------
4. МАТЕМАТИЧЕСКИЙ АНАЛИЗ РАСХОЖДЕНИЯ
4.1 Правильная формула (libcint)
libcint вычисляет нормировочный коэффициент через гауссов интеграл:
где:
Это гауссов интеграл:
Подставляя n = 4l+2 и a = 2*alpha:
В C-коде:
Поэтому:
4.2 Формула Rust (gto_normalization)
4.3 Сравнение формул
Раскроем правильную формулу libcint, используя связь Gamma и двойного факториала.
Для полуцелых аргументов:
И общее свойство:
Теперь для Gamma(2l + 3/2), где m = 2l:
Подставим в N_l^CINT:
А теперь формулу Rust:
4.3.1 Проверка для l=0 (s-орбиталь)
4.3.2 Проверка для l=1 (p-орбиталь)
Отношение:
Для alpha = 1.0: ratio = sqrt(15/4) = sqrt(3.75) ≈ 1.936
НО тест в subquantum_bridge.rs утверждает, что N_1(1.0) ≈ 5.053. Это соответствует и Rust, и C версии! Проверим напрямую:
Вычислим численно:
Gamma(5/2) = 3sqrt(pi)/4 ≈ 31.77245/4 ≈ 1.32934
2 * 2^(5/2) = 2 * 5.65685 = 11.31371
_gaussian_int = 1.32934 / 11.31371 ≈ 0.11752
N_1^CINT = 1/sqrt(0.11752) ≈ 1/0.34282 ≈ 2.9173
ОТНОШЕНИЕ: 5.0529 / 2.9173 ≈ 1.732 ≈ sqrt(3) = sqrt(2*1+1)
4.4 Общая формула расхождения
Разница возникает из того, что Rust-формула использует двойной факториал (2l-1)!! вместо правильного факториала (2l+2)! / (2^(l+1) * (l+1)!), который следует из Gamma(2l+3/2).
Точнее, отношение:
Доказательство:
Правильная формула (через Gamma):
Rust-формула:
Преобразуем правильную:
Используя (2l+2)! = (2l+2)!! * (2l+1)!! = 2^(l+1) * (l+1)! * (2l+1)!!:
Rust-формула через (2l-1)!!:
Отношение:
Вывод: gto_normalization(l, alpha) даёт значение в sqrt(2l+1) раз больше, чем правильное CINTgto_norm(l, alpha).
4.5 Числовая таблица расхождения
Для alpha=1.0. При других alpha отношение остаётся sqrt(2l+1).
--------------------------------------------------------------------------------
5. Корневая причина
Rust-формула использует двойной факториал (2l-1)!! вместо (2l+1)!! в знаменателе.
Отношение (2l+1)!! / (2l-1)!! = (2l+1), поэтому:
Почему для l=0 не видно:
(2*0-1)!! = (-1)!! = 1 (по соглашению), и (2*0+1)!! = 1!! = 1. Обе формулы дают одинаковый знаменатель = 1. Ошибка не проявляется.
Почему для l=1:
(2*1-1)!! = 1!! = 1, но (2*1+1)!! = 3!! = 3. Rust делит на 1 вместо 3 — результат в sqrt(3) ≈ 1.732 раз больше.
--------------------------------------------------------------------------------
6. ТЕКУЩИЙ СТАТУС (Что работает, что сломано)
Работает:
MoleculeBuilder::add_shell() — использует libcint_ffi::gto_norm() (C FFI) для нормализации env[]. Это ПРАВИЛЬНЫЙ путь, интегралы вычисляются корректно.
libcint_ffi::gto_norm() — прямой вызов CINTgto_norm() из libcint. Абсолютно точен.
Все тесты с H2/STO-3G — H2 содержит только s-орбитали (l=0), где ошибка не проявляется.
Сломано:
gto_utils::gto_normalization() — даёт значения в sqrt(2l+1) раз больше для l>=1. Если кто-либо вызовет эту функцию для p/d/f орбиталей, результат будет неверен.
gto_utils::cint_gto_norm() — просто псевдоним для gto_normalization(), тоже неверен.
basis_parser::gto_normalization() — локальная копия с тем же багом (дублирование!).
basis_parser::double_factorial() — ещё одна копия (тройное дублирование!).
Тесты gto_utils — test_gto_normalization_p_orbital утверждает, что N_1(1.0) ≈ 5.053, но ПРАВИЛЬНОЕ значение CINTgto_norm(1, 1.0) ≈ 2.917. Тест проверяет неправильное значение!
Тесты subquantum_bridge test_cint_gto_norm — тоже утверждают N_1(1.0) ≈ 5.053, НО cint_gto_norm() делегирует в gto_utils::cint_gto_norm() = gto_normalization(), которая даёт неправильное значение! Тест "проходит", но проверяет неверный результат.
--------------------------------------------------------------------------------
7. КАРТА ВЫЗОВОВ
--------------------------------------------------------------------------------
8. РЕШЕНИЕ: Исправление gto_utils.rs
Вариант A: Использовать правильную формулу с (2l+1)!!
Вариант B: Использовать гауссов интеграл (как libcint)
Это самый надёжный метод, дающий точное совпадение с CINTgto_norm:
Рекомендация: Вариант B
Вариант B использует ту же математическую процедуру, что и libcint (через lgamma), что гарантирует побитовое совпадение с CINTgto_norm при всех l и alpha. Вариант A может иметь небольшие численные отличия из-за double_factorial для больших l (l>10), где double_factorial теряет точность.
--------------------------------------------------------------------------------
9. Необходимые дополнительные исправления
Удалить дублирующую gto_normalization() из basis_parser.rs — она не нужна, normalize_shell() уже удалена, нормализацию делает add_shell().
Удалить дублирующую double_factorial() из basis_parser.rs — она уже есть в gto_utils.
Обновить тесты — текущие тесты проверяют неправильные значения (5.053 вместо 2.917 для p-орбиталей). Нужно использовать эталонные значения от CINTgto_norm.
Обновить документацию — комментарий в gto_utils.rs утверждает "Совместима с libcint CINTgto_norm()" — это неверно для l>=1.
--------------------------------------------------------------------------------
10. Приложение: Числовая проверка
Проверка CINTgto_norm через _gaussian_int
Проверка через Rust (если исправить на (2l+1)!!):
Проверка отношения sqrt(2l+1):
--------------------------------------------------------------------------------
11. Резюме
================================================================================FILE: hf_original_backup.py
#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
''' Hartree-Fock '''
import sys import tempfile
from functools import reduce import numpy import scipy.linalg import h5py from pyscf import gto from pyscf import lib from pyscf.lib import logger from pyscf.scf import diis from pyscf.scf import _vhf from pyscf.scf import chkfile from pyscf.scf import dispersion from pyscf.scf import smearing from pyscf.data import nist from pyscf import config
WITH_META_LOWDIN = getattr(config, 'scf_analyze_with_meta_lowdin', True) PRE_ORTH_METHOD = getattr(config, 'scf_analyze_pre_orth_method', 'ANO') MO_BASE = getattr(config, 'MO_BASE', 1) TIGHT_GRAD_CONV_TOL = getattr(config, 'scf_hf_kernel_tight_grad_conv_tol', True) MUTE_CHKFILE = getattr(config, 'scf_hf_SCF_mute_chkfile', False)
remove_overlap_zero_eigenvalue = getattr(config, 'scf_hf_remove_overlap_zero_eigenvalue', True) overlap_zero_eigenvalue_threshold = getattr(config, 'scf_hf_overlap_zero_eigenvalue_threshold', 1e-6)
def kernel(mf, conv_tol=1e-10, conv_tol_grad=None, dump_chk=True, dm0=None, callback=None, conv_check=True, **kwargs): '''kernel: the SCF driver.
You see this error message because of the API updates in pyscf v0.11. Keyword argument "init_dm" is replaced by "dm0"''') log = logger.new_logger(mf) cput0 = log.init_timer() if conv_tol_grad is None: conv_tol_grad = numpy.sqrt(conv_tol) log.info('Set gradient conv threshold to %g', conv_tol_grad)
def energy_elec(mf, dm=None, h1e=None, vhf=None): r'''Electronic part of Hartree-Fock energy, for given core hamiltonian and HF potential
def energy_tot(mf, dm=None, h1e=None, vhf=None): r'''Total Hartree-Fock energy, electronic part plus nuclear repulsion See :func:scf.hf.energy_elec for the electron part
def get_hcore(mol): '''Core Hamiltonian
def get_ovlp(mol): '''Overlap matrix ''' return mol.intor_symmetric('int1e_ovlp')
def init_guess_by_minao(mol): '''Generate initial guess density matrix based on ANO basis, then project the density matrix to the basis set defined by mol
coreshl defines the core shells to be removed in the initial guess
Compared to ANO valence basis, to check whether the ECP basis set has
reasonable AO-character contraction.  The ANO valence AO should have
significant overlap to ECP basis if the ECP basis has AO-character.
normalize electron number
s = mol.intor_symmetric('int1e_ovlp')
dm = mol.nelectron / (dms).sum()
def init_guess_by_1e(mol): '''Generate initial guess density matrix from core hamiltonian
def init_guess_by_atom(mol): '''Generate initial guess density matrix from superposition of atomic HF density matrix.  The atomic HF is occupancy averaged RHF
def init_guess_by_huckel(mol): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def init_guess_by_mod_huckel(mol): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def Kgwh(Ei, Ej, updated_rule=False): '''Computes the generalized Wolfsberg-Helmholtz parameter'''
def _init_guess_huckel_orbitals(mol, updated_rule = False): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def init_guess_by_chkfile(mol, chkfile_name, project=None): '''Read the HF results from checkpoint file, then project it to the basis defined by mol
def init_guess_by_sap(mol, sap_basis, **kwargs): '''Generate initial guess density matrix from a superposition of atomic potentials (SAP), doi:10.1021/acs.jctc.8b01089. This is the Gaussian fit implementation, see doi:10.1063/5.0004046.
def get_init_guess(mol, key='minao', **kwargs): '''Generate density matrix for initial guess
eigenvalue of d is 1
def level_shift(s, d, f, factor): r'''Apply level shift :math:\Delta to virtual orbitals
def damping(f, f_prev, factor): return f*(1-factor) + f_prev*factor
def make_sap(mol, sap_basis): '''Superposition of atomic potentials (SAP) potential matrix
full density matrix for RHF
def make_rdm1(mo_coeff, mo_occ, **kwargs): '''One-particle density matrix in AO representation
def make_rdm2(mo_coeff, mo_occ, **kwargs): '''Two-particle density matrix in AO representation
to make the density matrix consistent with the density matrix obtained from post-HF methods,
################################################
for general DM
hermi = 0 : arbitrary
hermi = 1 : hermitian
hermi = 2 : anti-hermitian
################################################ def dot_eri_dm(eri, dm, hermi=0, with_j=True, with_k=True): '''Compute J, K matrices in terms of the given 2-electron integrals and density matrix:
def get_jk(mol, dm, hermi=1, vhfopt=None, with_j=True, with_k=True, omega=None): '''Compute J, K matrices for all input density matrices
def get_veff(mol, dm, dm_last=None, vhf_last=None, hermi=1, vhfopt=None): '''Hartree-Fock potential matrix for the given density matrix
def get_fock(mf, h1e=None, s1e=None, vhf=None, dm=None, cycle=-1, diis=None, diis_start_cycle=None, level_shift_factor=None, damp_factor=None, fock_last=None): '''F = h^{core} + V^{HF}
def get_occ(mf, mo_energy=None, mo_coeff=None): '''Label the occupancies for each orbital
def get_grad(mo_coeff, mo_occ, fock_ao): '''RHF orbital gradients
def analyze(mf, verbose=logger.DEBUG, with_meta_lowdin=WITH_META_LOWDIN, origin=None, **kwargs): '''Analyze the given SCF object:  print orbital energies, occupancies; print orbital coefficients; Mulliken population analysis; Diople moment. ''' from pyscf.lo import orth from pyscf.tools import dump_mat mo_energy = mf.mo_energy mo_occ = mf.mo_occ mo_coeff = mf.mo_coeff log = logger.new_logger(mf, verbose)
def dump_scf_summary(mf, verbose=logger.DEBUG): if not mf.scf_summary: return
def mulliken_pop(mol, dm, s=None, verbose=logger.DEBUG): r'''Mulliken population analysis
def mulliken_meta(mol, dm, verbose=logger.DEBUG, pre_orth_method=PRE_ORTH_METHOD, s=None): '''Mulliken population analysis, based on meta-Lowdin AOs. In the meta-lowdin, the AOs are grouped in three sets: core, valence and Rydberg, the orthogonalization are carried out within each subsets.
mulliken_pop_meta_lowdin_ao = mulliken_meta
def check_linear_dependency(s, log=None): e, v = scipy.linalg.eigh(s) if log is not None: abs_e = abs(e) emax = abs_e.max() emin = abs_e.min() c = emax / emin log.debug('cond(S) = %s', c) if c > 1e10: log.warn('Singularity detected in the overlap matrix. ' 'SCF may be inaccurate and difficult to converge.') if remove_overlap_zero_eigenvalue: mask = e > overlap_zero_eigenvalue_threshold x = v[:,mask] / numpy.sqrt(e[mask]) else: x = v / numpy.sqrt(e) return x
def canonical_orthogonalization(s): return check_linear_dependency(s)
def eig(h, s, overwrite=False): '''Solver for generalized eigenvalue problem
def adjust_phase(c): '''Make the largest component of each eigenvector real and positive ''' idx = numpy.argmax(numpy.abs(c), axis=0) if c.dtype == numpy.float64: c[:,c[idx,numpy.arange(c.shape[1])]<0] *= -1 else: phase = c[idx,numpy.arange(c.shape[1])] phase /= numpy.abs(phase) c *= phase.conj() return c
def canonicalize(mf, mo_coeff, mo_occ, fock=None): '''Canonicalization diagonalizes the Fock matrix within occupied, open, virtual subspaces separatedly (without change occupancy). ''' if fock is None: dm = mf.make_rdm1(mo_coeff, mo_occ) fock = mf.get_fock(dm=dm) coreidx = mo_occ == 2 viridx = mo_occ == 0 openidx = ~(coreidx | viridx) mo = numpy.empty_like(mo_coeff) mo_e = numpy.empty(mo_occ.size) for idx in (coreidx, openidx, viridx): if numpy.count_nonzero(idx) > 0: orb = mo_coeff[:,idx] f1 = reduce(numpy.dot, (orb.conj().T, fock, orb)) e, c = scipy.linalg.eigh(f1) mo[:,idx] = numpy.dot(orb, c) mo_e[idx] = e mo = adjust_phase(mo) return mo_e, mo
def dip_moment(mol, dm, unit='Debye', origin=None, verbose=logger.NOTE, **kwargs): r''' Dipole moment calculation
def quad_moment(mol, dm, unit='DebyeAngstrom', origin=None, verbose=logger.NOTE, **kwargs): r''' Calculates traceless quadrupole moment tensor.
def uniq_var_indices(mo_occ): ''' Indices of the unique variables for the orbital-gradients (or orbital-rotation) matrix. ''' occidxa = mo_occ>0 occidxb = mo_occ==2 viridxa = ~occidxa viridxb = ~occidxb mask = (viridxa[:,None] & occidxa) | (viridxb[:,None] & occidxb) return mask
def pack_uniq_var(x, mo_occ): ''' Extract the unique variables from the full orbital-gradients (or orbital-rotation) matrix ''' idx = uniq_var_indices(mo_occ) return x[idx]
def unpack_uniq_var(dx, mo_occ): ''' Fill the full orbital-gradients (or orbital-rotation) matrix with the unique variables. ''' nmo = len(mo_occ) idx = uniq_var_indices(mo_occ)
def as_scanner(mf): '''Generating a scanner/solver for HF PES.
class SCF_Scanner(lib.SinglePointScanner): def init(self, mf_obj): self.dict.update(mf_obj.dict) self._last_mol_fp = mf_obj.mol.ao_loc
class SCF(lib.StreamObject): '''SCF base class.   non-relativistic RHF.
##################################################
don't modify the following attributes, they are not input options
employing the updated GWH rule from doi:10.1021/ja00480a005.''') mo_energy, mo_coeff = _init_guess_huckel_orbitals(mol, updated_rule=True) mo_occ = self.get_occ(mo_energy, mo_coeff) return self.make_rdm1(mo_coeff, mo_occ)
This is the Gaussian fit version as described in doi:10.1063/5.0004046.''') if isinstance(sap_basis, str): atoms = [coord[0] for coord in mol._atom] sapbas = {} for atom in set(atoms): single_element_bs = load(sap_basis, atom) if isinstance(single_element_bs, dict): sapbas[atom] = numpy.asarray(single_element_bs[atom][0][1:], dtype=float) else: sapbas[atom] = numpy.asarray(single_element_bs[0][1:], dtype=float) logger.note(self, f'Found SAP basis {sap_basis.split("/")[-1]}') elif isinstance(sap_basis, dict): sapbas = {} for key in sap_basis: sapbas[key] = numpy.asarray(sap_basis[key][0][1:], dtype=float) else: logger.error(self, 'sap_basis is of an unexpected datatype.') return init_guess_by_sap(mol, sap_basis=sapbas, **kwargs)
class KohnShamDFT: '''A mock DFT base class
class RHF(SCF): doc = SCF.doc
def _hf1e_scf(mf, args):logger.info(mf, '\n')logger.info(mf, '******* 1 electron system ********') mf.converged = True h1e = mf.get_hcore(mf.mol) s1e = mf.get_ovlp(mf.mol) mf.mo_energy, mf.mo_coeff = mf.eig(h1e, s1e) mf.mo_occ = mf.get_occ(mf.mo_energy, mf.mo_coeff) mf.e_tot = mf.mo_energy[mf.mo_occ>0][0].real + mf.mol.energy_nuc() if mf.chkfile: mf.dump_chk(mf.chkfile) mf._finalize() return mf.e_tot
del (WITH_META_LOWDIN, PRE_ORTH_METHOD)
================================================================================FILE: hf_patched.py
""" Modified PySCF hf.py kernel with POLER integration.
This is a patched version of pyscf/scf/hf.py that replaces standard Fock diagonalization with live density matrix evolution via poler_evol.evolve() when use_poler flag is set.
Key modification points:
Import of pyscf.poler module (lines ~49-51)
POLER initialization in kernel() (lines ~67-68)
Reality branching in SCF loop (lines ~72)
POLER Branch: dm = poler_evol.evolve(dm, J_strength=..., D_strength=..., gamma_eps=..., steps=...)
Then build Fock from evolved dm for energy calculation
fock = mf.get_fock(h1e, s1e, vhf, dm) mo_energy, mo_coeff = mf.eig(fock, s1e) mo_occ = mf.get_occ(mo_energy, mo_coeff)
In POLER we trust the DM from evolution, so we don't
recalculate it via make_rdm1
Classic Branch: fock = mf.get_fock(h1e, s1e, vhf, dm, cycle, mf_diis, fock_last=fock_last) mo_energy, mo_coeff = mf.eig(fock, s1e) mo_occ = mf.get_occ(mo_energy, mo_coeff) dm = mf.make_rdm1(mo_coeff, mo_occ)
To apply this patch:
Copy this file to pyscf/scf/hf.py (backup original first!)
Or use the wrapper.py approach which doesn't require patching """
==========================================================