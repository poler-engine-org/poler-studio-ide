> Source: https://www.worldscientific.com/doi/10.1142/S0129183127500719

Login to your account
Forgot password?Keep me logged in   New User  Institutional Login Change Password
Too Short   Weak   Medium   Strong   Very Strong   Too Long  
 Your password must have 8 characters or more and contain 3 of the following: 
a lower case character, 
an upper case character, 
a special character 
or a digit  
Too Short  
Password Changed Successfully
Your password has been changed
Create a new account
 Returning user Can't sign in? Forgot your password?
Enter your email address below and we will send you the reset instructions
Please check your inbox for the reset password link that is only valid for 24 hours.  CancelIf the address matches an existing account you will receive an email with instructions to reset your password
CloseRequest Username
Can't sign in? Forgot your username?
Enter your email address below and we will send you your username
CloseIf the address matches an existing account you will receive an email with instructions to retrieve your username
SearchThis Journal
Anywhere
Access type: Only show content I have full access to Only show Open Access Access type: Only show content I have full access to Only show Open Access  Advanced Search
0   My Cart  
Sign in  
Institutional Access  
Skip main navigation
System Maintenance – October 10, 2025, 1 PM (PST) 
 During this time, you may experience a brief 10-minute downtime of our website and related services. For any enquiries, contact us at [email protected] for any enquiries.  No Access
Constructing an enhanced variant of Hill cipher based on 2D hyper chaotic map over GF ( 2 n )
Yongyuan Lu  and 
Hongjun Liu
Yongyuan Lu
https://orcid.org/0009-0008-4113-9099
School of Mathematical Sciences, University of Jinan, Jinan, P. R. China
 Search for more papers by this author 
 and Hongjun Liu
https://orcid.org/0000-0003-4991-6696
School of Mathematical Sciences, University of Jinan, Jinan, P. R. China
E-mail Address:  [email protected]
Corresponding author.
 Search for more papers by this author 
https://doi.org/10.1142/S0129183127500719Cited by: 0  (Source: Crossref)  PreviousNext
View articleAbstract
 The inherent linearity of Hill cipher renders it vulnerable to security threats, such as known-plaintext attacks. To solve this problem, an enhanced variant was designed by extending the Hill cipher from the integer ring to the finite field. First, a 2D finite field hyper chaotic map (2D-FFHCM) with desirable dynamical properties was constructed to dynamically generate both the invertible key matrices (via the product of invertible triangular matrices) and a strong S-Box. Subsequently, an enhanced variant of Hill cipher based on the S-Box was constructed, achieving strong confusion and diffusion properties. Finally, the proposed algorithm was evaluated through comprehensive tests, including key space, key sensitivity, information entropy, differential attack analysis and correlation analysis. Experimental results demonstrated the excellent performance of the proposed algorithm, confirming it can effectively resist common cryptographic attacks.
Keywords:2D hyper chaotic map
finite field
Hill cipher
strong S-Box
triangular matrix
 References 
1.   M. Essaid, I. Akharraz and A. Saaidi  , J. Inf. Secur. Appl.47, 173 ( 2019 ). Web of Science, Google Scholar
2.   K. Suwais  , Intell. Autom. Soft Comput.33, 1815 ( 2022 ). Crossref, Web of Science, Google Scholar
3.   X. Zhang  et al. , Int. J. Opt.2019, 3594534 ( 2019 ). Web of Science, Google Scholar
4.   L. S. Hill  , Am. Math. Mon.36, 306 ( 1929 ). Crossref, Google Scholar
5.   K. A. Reddy, B. Vishnuvardhan and A. V. N. Krishna  , Procedia Technol.4, 114 ( 2012 ). Crossref, Web of Science, Google Scholar
6.   S. Saeednia  , Cryptologia24, 353 ( 2000 ). Crossref, Google Scholar
7.   M. Mokhtari and H. Naraghi  , J. Math. Res.4, 67 ( 2012 ). Crossref, Google Scholar
8.   A. Mahmoud and A. Chefranov  , Appl. Math. Inf. Sci.8, 505 ( 2014 ). Crossref, Web of Science, Google Scholar
9.   J. Jin  et al. , IEEE Internet Things J.12, 14297 ( 2025 ). Crossref, Web of Science, Google Scholar
10.   D. C. Mishra  et al. , Optik126, 3812 ( 2015 ). Crossref, Web of Science, ADS, Google Scholar
11.   H. Rrghout  et al. ,  Robust image encryption algorithm using a new variant of hill cipher , Proc. 6th Int. Conf. Networking, Intelligent Systems & Security ( ACM,  2023 ), pp. 1–6. Crossref, Google Scholar
12.   F. Koken and M. Aksoy  , Filomat39, 4821 ( 2025 ). Crossref, Web of Science, Google Scholar
13.   Y. Ning  et al. , Tsinghua Sci. Technol.31, 1595 ( 2026 ). Crossref, Web of Science, Google Scholar
14.   J. Zhu  et al. , IEEE Trans. Emerg. Top. Comput. Intell.9, 176 ( 2024 ). Crossref, Web of Science, Google Scholar
15.   H. Liu  et al. , Appl. Math. Comput.360, 83 ( 2019 ). Crossref, Web of Science, Google Scholar
16.   Y. Zheng  et al. , Nonlinear Dyn.113, 2811 ( 2025 ). Crossref, Web of Science, Google Scholar
17.   M. A. Lone and S. Qureshi  , Optik260, 168880 ( 2022 ). Crossref, Web of Science, Google Scholar
18.   M. A. Lone and S. Qureshi  , Nonlinear Dyn.111, 5919 ( 2023 ). Crossref, Web of Science, Google Scholar
19.   P. N. Lone  et al. , Mathematics10, 3878 ( 2022 ). Crossref, Web of Science, Google Scholar
20.   S. Li, G. Chen and X. Mou  , Int. J. Bifurc. Chaos15, 3119 ( 2005 ). Link, Web of Science, Google Scholar
21.   M. Zhao and H. Liu  , Integration97, 102200 ( 2024 ). Crossref, Web of Science, Google Scholar
22.   H. Liu  , Nonlinear Dyn.113, 12337 ( 2025 ). Crossref, Web of Science, Google Scholar
23.   D. Xu and H. Liu  , Nonlinear Dyn.112, 9563 ( 2024 ). Crossref, Web of Science, Google Scholar
24.   D. Xu and H. Liu  , Int. J. Bifurc. Chaos34, 2450160 ( 2024 ). Link, Web of Science, Google Scholar
25.   I. Hussain  et al. , Nonlinear Dyn.72, 399 ( 2013 ). Crossref, Web of Science, Google Scholar
26.   R. Chinram  et al. , Soft Comput.27, 11111 ( 2023 ). Crossref, Web of Science, Google Scholar
27.   Y. Cao, H. Liu and D. Xu  , Int. J. Bifurc. Chaos33, 2350181 ( 2023 ). Link, Web of Science, Google Scholar
28.   S. Zhou  et al. , IEEE Internet Things J.12, 9082 ( 2024 ). Crossref, Web of Science, Google Scholar
29.   A. Kadeer, Y. Tuersun and H. Liu  , Comput. Electr. Eng.122, 109951 ( 2025 ). Crossref, Web of Science, Google Scholar
30.   M. Wang  et al. , Expert Syst. Appl.261, 125328 ( 2025 ). Crossref, Web of Science, Google Scholar
31.   M. Zhao and H. Liu  , Int. J. Bifurc. Chaos33, 2350070 ( 2023 ). Link, Web of Science, Google Scholar
32.   J. Overbey, W. Traves and J. Wojdylo  , Cryptologia29, 59 ( 2005 ). Crossref, Google Scholar
33.   D. Ding  et al. , Chaos Solitons Fractals185, 115168 ( 2024 ). Crossref, Web of Science, Google Scholar
34.   H. Wen  et al. , Sci. Rep.13, 14721 ( 2023 ). Crossref, Web of Science, ADS, Google Scholar
35.   M. Zhao and H. Liu  , Int. J. Bifurc. Chaos32, 2250081 ( 2022 ). Link, Web of Science, Google Scholar
36.   X. Sun and H. Liu  , Int. J. Bifurc. Chaos35, 2550141 ( 2025 ). Link, Web of Science, Google Scholar
37.   H. Zhang  et al. , Entropy27, 606 ( 2025 ). Crossref, Web of Science, ADS, Google Scholar
38.   S. Zhou, X. Wang and Y. Zhang  , Inf. Sci.621, 782 ( 2023 ). Crossref, Web of Science, Google Scholar
39.   Z. Zhang  et al. , Nonlinear Dyn.111, 10629 ( 2023 ). Crossref, Web of Science, Google Scholar
40.   C. Zou  et al. , Chaos Solitons Fractals189, 115638 ( 2024 ). Crossref, Web of Science, Google Scholar
41.   X. Huang  et al. , Symmetry17, 801 ( 2025 ). Crossref, Web of Science, ADS, Google Scholar
42.   C. Zhang, H. Wang and Y. Zhang  , Expert Syst. Appl.286, 128091 ( 2025 ). Crossref, Web of Science, Google Scholar
43.   C. E. Shannon  , Bell Syst. Tech. J.27, 379 ( 1948 ). Crossref, Web of Science, ADS, Google Scholar
44.   M. Wang  et al. , Chaos Solitons Fractals183, 114959 ( 2024 ). Crossref, Web of Science, Google Scholar
45.   L. K. Grover  ,  A fast quantum mechanical algorithm for database search , Proc. 28th Annu. ACM Symp. Theory of Computing ( ACM,  1996 ), pp. 212–219. Crossref, Google Scholar
View full text|Download PDFFigures
References
Related
Details
 Recommended 
Online ReadyMetrics
History
Received 8 February 2026   Accepted 1 March 2026   Published: 7 April 2026  
Keywords2D hyper chaotic map
finite field
Hill cipher
strong S-Box
triangular matrix
PDF downloadClose Figure ViewerBrowse All FiguresReturn to FigurePrevious FigureNext FigureCaption
Resources  
For Authors
For Booksellers
For Librarians
Copyright & Permissions
Translation Rights
How to Order
Contact Us
Sitemap
About Us & Help  
About Us
News
Author Services
Help
Accessibility
Links  
World Scientific Europe
WS Education (K-12)
Global Publishing 八方文化
World Century
Privacy policy
© 2026 World Scientific Publishing Co Pte Ltd  Powered by Atypon® Literatum  