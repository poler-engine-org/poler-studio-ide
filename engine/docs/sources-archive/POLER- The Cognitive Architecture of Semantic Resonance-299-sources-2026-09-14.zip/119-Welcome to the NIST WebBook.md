> Source: https://webbook.nist.gov/

Welcome to the NIST WebBook
Jump to content
National Institute of Standards and Technology
NIST Chemistry WebBook, SRD 69
Home
Search
Name
Formula
IUPAC identifier
CAS number
More options
NIST Data
SRD Program
Science Data Portal
Material Data Division
About
FAQ
Credits
More documentation
Welcome to the NIST Chemistry WebBook
The NIST Chemistry WebBook provides access to data compiled and distributed by NIST under the Standard Reference Data Program.
The NIST Chemistry WebBook contains:
Thermochemical data for over 7000 organic and small inorganic compounds:
Enthalpy of formation
Enthalpy of combustion
Heat capacity
Entropy
Phase transition enthalpies and temperatures
Vapor pressure
Reaction thermochemistry data for over 8000 reactions.
Enthalpy of reaction
Free energy of reaction
IR spectra for over 16,000 compounds.
Mass spectra for over 33,000 compounds.
UV/Vis spectra for over 1600 compounds.
Gas chromatography data for over 27,000 compounds.
Electronic and vibrational spectra for over 5000 compounds.
Constants of diatomic molecules (spectroscopic data) for over 600 compounds.
Ion energetics data for over 16,000 compounds:
Ionization energy
Appearance energy
Electron affinity
Proton affinity
Gas basicity
Cluster ion binding energies
Thermophysical property data for 74 fluids:
Density, specific volume
Heat capacity at constant pressure (C p)
Heat capacity at constant volume (C v)
Enthalpy
Internal energy
Entropy
Viscosity
Thermal conductivity
Joule-Thomson coefficient
Surface tension (saturation curve only)
Sound speed
You can search for data on specific compounds in the Chemistry WebBook based on name, chemical formula, CAS registry number, molecular weight, chemical structure, or selected ion energetics and spectral properties.
NIST reserves the right to charge for access to this database in the future.
The National Institute of Standards and Technology (NIST) uses its best efforts to deliver a high quality copy of the Database and to verify that the data contained therein have been selected on the basis of sound scientific judgment. However, NIST makes no warranties to that effect, and NIST shall not be liable for any damage that may result from errors or omissions in the Database.
Click here to enter the NIST Chemistry WebBook.
© 2026 by the U.S. Secretary of Commerce on behalf of the United States of America. All rights reserved.
Copyright for NIST Standard Reference Data is governed by the Standard Reference Data Act.
Site Privacy
Accessibility
Privacy Program
Copyrights (Note: This site is covered by copyright.)
Vulnerability Disclosure
No Fear Act Policy
FOIA
Environmental Policy
Scientific Integrity
Information Quality Standards
Commerce.gov
Science.gov
USA.gov
Vote.gov