> Source: https://open.clemson.edu/cgi/viewcontent.cgi?article=1422&context=all_dissertations

Clemson University 
TigerPrints 
All Dissertations Dissertations 
8-2009 
Discrete Dynamics over Finite Fields 
Jang-woo Park Clemson University, jpark@clemson.edu 
Follow this and additional works at: https://tigerprints.clemson.edu/all_dissertations 
Part of the Applied Mathematics Commons 
This Dissertation is brought to you for free and open access by the Dissertations at TigerPrints. It has been accepted for inclusion in All Dissertations by an authorized administrator of TigerPrints. For more information, please contact kokeefe@clemson.edu. 
Recommended Citation Park, Jang-woo, "Discrete Dynamics over Finite Fields" (2009). All Dissertations. 422. https://tigerprints.clemson.edu/all_dissertations/422
Discrete Dynamics over Finite Fields 
A Dissertation 
Presented to 
the Graduate School of 
Clemson University 
In Partial Fulfillment 
of the Requirements for the Degree 
Doctor of Philosophy 
Mathematics 
by 
Jang-Woo Park 
August 2009 
Accepted by: 
Dr. Shuhong Gao, Committee Chair 
Dr. Neil J. Calkin 
Dr. Kevin L. James 
Dr. Hiren Maharaj 
Dr. Gretchen L. Matthews
Abstract 
A dynamical system consists of a set V and a map f : V → V . The pri-
mary goal is to characterize points in V according to their limiting behaviors under 
iteration of the map f . Especially understanding dynamics of nonlinear maps is an 
important but difficult problem, and there are not many methods available. This 
work concentrates on dynamics of certain nonlinear maps over finite fields. First we 
study monomial dynamics over finite fields. We show that determining the number of 
fixed points of a boolean monomial dynamics is #P −complete problem and consider 
various cases in which the dynamics can be explained efficiently. We also extend 
the result to the monomial dynamics over general finite fields. Then we study the 
dynamics of a simple nonlinear map, f(x) = x + x−1, on fields of characteristic two. 
The main idea is to lift the map f to a proper finite covering map whose dynamics is 
easier to understand. We lift the map of f to an isogeny g on an elliptic curve where 
the dynamics of g can be further reduced to that of a linear map on Z−module. As 
an application of finite covering, we construct a new family of permutation maps over 
finite fields from the known permutation maps. 
ii
Dedication 
To my mother and father, 
whose constant and unconditional love has made me who I am. 
iii
Acknowledgments 
The writing of a dissertation can be a lonely and isolating experience, yet it is 
obviously not possible without the support and encouragement of numerous people. 
First of all, I am very grateful to my doctoral advisor, Dr. Shuhong Gao for 
his encouragement, advice, mentoring, and research support throughout my doctoral 
study. I also truly appreciate his patience and tolerance during my numerous mishaps. 
I also thank my committee members, Dr. Neil Calkin, Dr. Kevin James, Dr. Hiren 
Maharaj, and Dr. Gretchen Matthews. I am fortunate to have received their time 
and suggestions for my research over the years. I am especially grateful to Dr. Kevin 
James for his timely corrections and suggestions that helped make this dissertation 
better. 
I would like to thank Dr. Judith Cottingham and Dr. Timothy Teitloff for 
writing me recommendation letters regarding my teaching skills. I also thank Profes-
sor Eric Bach who showed me how wonderful mathematics is and led me where I am 
now. I am also grateful to Professor Hendrik W. Lenstra, Jr. for his valuable insight 
which has been crucial to the main chapter of this work. 
I am thankful to numerous friends who supported and nourished me in many 
different ways. Among them, I am especially thankful to Sundeep Samson, my co-
instructor and coffee buddy who made this long procedure enjoyable and encouraged 
me during a hard time. I also thank Ethan and Andrea Smith for their helps and 
iv
kindness. I also thank my officemates through the years, especially Ray Heindl and 
Mingfu Zhu for countless hours of good conversation. I thank Mr. Woo-Young Ryu, 
Mr. Sang-Ouk Wee, and Professor Jeong-Han Kim who have been great friends 
throughout my graduate studies. I am especially grateful to my two best friends, 
Tae-Hee Lee and Won-Jin Lee who have encouraged me with unfading friendship for 
decades. 
I thank Johann Sebastian Bach for Goldberg Variations which has been both 
musical and mathematical inspiration to me for long time, Glenn Gould and Dong-
Hyek Lim whose interpretations of Goldberg Variations have nourished my soul, and 
Frédèric Chopin whose brilliant work, Polonaise, Op. 53, has widen my perspective 
on life. I also thank my favorite guitarists, Pat Metheny, Paul Gilbert, Guthrie Govan 
and Billy McLaughlin who provided wonderful music with the instrument that I love 
the most. 
Finally, I would like to thank the most important people in my life, my family. 
I am grateful to my sisters, Young-Woo Park, Jung-Woo Park, Eun-Woo Park for the 
support and the encouragement. I would also like to thank my aunts and uncles for 
their prayers. I am deeply indebted to my parents, Chan-Kyo Park and Kum-Soon 
Kim who have trusted and supported me for my whole life with their unconditional 
love. 
v
Table of Contents 
Title Page . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . i 
Abstract . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ii 
Dedication . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . iii 
Acknowledgments . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . iv 
List of Figures . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . vii 
1 Introduction . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 1 
2 Monomial Dynamics over Finite Fields . . . . . . . . . . . . . . . . 9 2.1 Introduction . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9 2.2 Fixed Points over F2 . . . . . . . . . . . . . . . . . . . . . . . . . . . 14 2.3 Cycles of Lengths Greater than One over F2 . . . . . . . . . . . . . . 20 2.4 Monomial Dynamics over General Finite Fields . . . . . . . . . . . . 26 
3 Finite Coverings . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33 3.1 Introduction . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33 3.2 A Dynamical System and its Associated Elliptic Curve . . . . . . . . 36 3.3 Properties of g on E . . . . . . . . . . . . . . . . . . . . . . . . . . . 40 3.4 Group Structure of E(F2n) . . . . . . . . . . . . . . . . . . . . . . . . 42 3.5 Tree Structure of g on E(F2n) . . . . . . . . . . . . . . . . . . . . . . 53 3.6 Cycle Structure of g on E(F2n) . . . . . . . . . . . . . . . . . . . . . 56 3.7 Dynamics of x 7→ x + x−1 on F2n ∪ {∞} . . . . . . . . . . . . . . . . 69 
4 Permutation Maps over Finite Fields . . . . . . . . . . . . . . . . . 77 4.1 Introduction . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 77 4.2 Proof . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 79 
5 Conclusions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 83 
Bibliography . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 85 
vi
List of Figures 
1.1 Orbit of v under a map f . . . . . . . . . . . . . . . . . . . . . . . . . 2 1.2 Dynamics of f on F5 
2 . . . . . . . . . . . . . . . . . . . . . . . . . . . 3 
2.1 Dependency Graph χf of f and its Strongly Connected Components . 10 2.2 Poset of the Dependency Graph χf . . . . . . . . . . . . . . . . . . . 12 2.3 Poset of the Strongly Connected Components of χf . . . . . . . . . . 12 2.4 Poset G . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 16 2.5 G1 and G2 for the Vertex 3 of G . . . . . . . . . . . . . . . . . . . . . 16 2.6 Complete Tertiary Tree of height 3 . . . . . . . . . . . . . . . . . . . 18 2.7 Special Quadripartite Graph . . . . . . . . . . . . . . . . . . . . . . . 19 2.8 Dependency Graphs of f and g . . . . . . . . . . . . . . . . . . . . . 20 2.9 Dependency Graphs of f 2 and g2 . . . . . . . . . . . . . . . . . . . . 21 2.10 Component C . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 22 2.11 Dependency Graph χf of f . . . . . . . . . . . . . . . . . . . . . . . . 29 
3.1 Dynamics of f(x) = x + x−1 on F24 ∪ {∞}. . . . . . . . . . . . . . . . 36 3.2 Dynamics of f(x) = x + x−1 on F25 ∪ {∞}. . . . . . . . . . . . . . . . 37 3.3 Dynamics of f(x) = x + x−1 on F26 ∪ {∞}. . . . . . . . . . . . . . . . 38 3.4 Dynamics of g on E(F210) and that of f(x) = x + x−1 on F25 ∪ {∞}. . 76 
vii
Chapter 1 
Introduction 
Dynamical systems are ubiquitous in science and engineering. They may rep-
resent the motions of stars in the sky in astronomy, the fluctuation of stock markets 
in business, the heart beat in medical science, gene evolution in genetics, or traffic 
in a highway system or in a city. Dynamical systems have long been studied by 
many scholars in science, engineering, and mathematics, and they are active areas of 
research full of unknowns and challenges. 
In simple terms, a dynamical system consists of a set V and a map f : V → V . 
We write 
f i = f 
 f 
 · · · ◦ f ︸ ︷︷ ︸ 
i 
= ith iteration of f, 
and f 0 denotes the identity map on V by convention. For a given point v ∈ V , the 
orbit of v under f is the set of f i(v)’s for all i ≥ 0. A point v ∈ V is called periodic 
or cyclic if there exists m ≥ 1 such that fm(v) = v. In this case, the orbit of v under 
f is a cycle and the smallest such m is called the cycle length of v. A point v ∈ V 
is called preperiodic if there exist 0 ≤ i < j such that f i(v) = f j(v). In this case, 
the orbit of v is depicted as in Figure 1.1. The number i in Figure 1.1 is called tail 
1
length and the number j − i is called the cycle length of v. In applications, it is 
desirable to understand cycle lengths, tail lengths, and their distributions. 
v2 
3v 
v0v = 
v1 
vi−1 v 
i vj= 
vi+1 
vi+2 
vj−2 
vj−1 
Figure 1.1: Orbit of v under a map f . 
In a classical dynamical system, V is a topological and metric space. A point 
v ∈ V is called stable if, whenever u ∈ V is “close” to v, the orbit of u stays “close” to 
that of v. The Fatou set of f consists of all the stable points of V . The Julia set of f 
is the complement of the Fatou set. So points in Julia set tend to move away from each 
other under iteration of f and they behave chaotically. The important subjects in a 
classical dynamical system are the limiting behaviors of two close points and finding 
the Julia set. For more on classical dynamical system, we recommend [Devaney, 2003] 
and [Robinson, 1998]. 
Understanding the discrete dynamics on finite sets requires different tech-
niques. When V is finite, every point is preperiodic. So the “stability” and “chaos” 
in classical dynamical systems are irrelevant in finite dynamical systems. We view 
the discrete dynamics of f on a finite set V as a directed graph. The graph has V as 
a vertex set and, for any pair of v, w ∈ V , there is an edge from v to w if and only if 
f(v) = w. Figure 1.2 shows a dynamical system over a finite field. 
2
Example 1.0.1. Let f : F5 2 → F5 
2 be f(x1, x2, x3, x4, x5) = (x2x3, x1x4, x3, x4, x4). 
The dynamics of f is shown in Figure 1.2. 
00000 00001 
01000 
01001 
11000 
11001 
10001 
10000 
00100 
10101 
10100 
00101 
01100 
01101 11100 
11101 
00011 
0101000010 
01011 
10011 
10010 11010 
11011 
01110 10111 01111 10110 
1111111110 
00110 00111 
Figure 1.2: Dynamics of f on F5 2 
Notice that the dynamics of f consists of disjoint cycles with trees attached 
to them. As can be seen in Figure 1.2, it has five fixed points, one cycle of length 2, 
the maximum tail length is 2, and the maximum in-degree is 8. It is also noticeable 
that there are regularities in the tree structure. We are interested in dynamics over 
finite sets, especially over finite fields. We are interested in the following questions: 
 How many cycles are in the dynamics of f on V ? 
 What are the cycle lengths ? 
 What are the heights of trees ? 
 What are the in-degrees ? 
3
Although we can get answers for all the questions above by enumerating all 
points, we are interested in the underlying mathematical theory. The goal is to analyze 
the dynamics without actually enumerating all state transitions, since enumerating 
has exponential complexity in the number of model variables. In this work, we are 
particularly interested in monomial dynamics and using finite covering to investigate 
the dynamics of nonlinear maps over finite fields. 
The following is a brief survey of some known results on various discrete dy-
namics. For linear finite dynamical systems, Elspas [1959] examined the dynamics 
of linear systems over prime fields and showed that cycle structure can be deter-
mined by the elementary divisor of the matrix, and Hernandez-Toledo [2005] general-
ized Elspas’s results to arbitrary finite fields and also showed that tree structure can 
be determined by the nilpotent part of the map. Based on these results, Jarrah et al. 
[2006] presented an algorithms which describes the phase spaces. Xua and Zoub [2009] 
have presented an efficient algorithm to analyze cycle structure of the dynamics of 
linear systems over finite commutative rings. Studying dynamics of nonlinear maps 
is very challenging task. Only a few cases have been well understood. Zieve [1996] 
investigated the cycle lengths of polynomial maps over various rings. Even dynamics 
of quadratics polynomials over finite fields are still open except f(x) = x2 and f(x) = 
x2 − 2. The square map over prime fields was studied in [Rogers, 1996] and the dy-
namics of f(x) = x2−2 over prime fields was analyzed in [Gilbert et al., 2001], [Park, 
2003], and [Vasiga and Shallit, 2004]. For monomial dynamics, Jarrah et al. [2008] 
provided an analysis of boolean monomial dynamical systems and Colón-Reyes et al. 
[2006] showed the structure of fixed points of monomial dynamics over general finite 
fields can be reduced to boolean monomial dynamics. 
A map is called a permutation map if it is bijective on V . Permutation maps 
have applications in diverse areas such as coding theory, combinatorics, and cryp-
4
tography. If V is finite, then the dynamics of permutation maps consist of only 
cycles. Especially for permutation maps over finite fields, due to the fact that every 
map over a finite field can be expressed by a polynomial, it was natural to focus 
on maps defined by polynomials. Since Hermite [1863] investigated permutation 
polynomials over finite prime fields and Dickson [1897] studied them over general 
finite fields, numerous mathematicians and engineers have shown their interests in 
permutation polynomials. For more background material on permutation polyno-
mials, we refer the readers to Chapter 7 of [Lidl and Niederreiter, 1997] and, for a 
detailed survey and some open problems, to [Lidl and Mullen, 1988, 1993]. Two well-
known classes of permutation polynomials are monomials xk over Fq with k ≥ 1 and 
gcd(k, q − 1) = 1 and Dickson’s polynomials over Fq with degrees relatively prime to 
q2 − 1. Binomial polynomials of certain forms have been studied by several schol-
ars; see [Akbary and Wang, 2006], [Masuda et al., 2006], [Masuda and Zieve, 2007, 
2009], [Turnwald, 1998], and [Wang, 2002]. For permutation polynomials in more gen-
eral forms, see [Akbary and Wang, 2005], [Park and Lee, 1998], and [Wan and Lidl, 
1991]. 
In this work we focus on studying dynamics of special nonlinear maps over 
finite fields and its theoretical application. In Chapter 2, we study monomial dynamics 
over finite fields. A map f is called a monomial map if f = (f1, f2, . . . , fm) where 
each fi is a monomial. Colón-Reyes et al. [2004] studied fixed point structure of f 
over F2 by associating the dynamics of f with its dependency graph χf . They also 
introduced a loop number of a strongly connected component which plays important 
role in their investigation of cycle structure of monomial dynamics in [Jarrah et al., 
2008]. Jarrah et al. [2008] proved that a component with the loop number t in χf 
would decompose into t/d components in χfd for d dividing t. They showed possible 
lengths of cycles and their distributions when χf has only one component. From this, 
5
they presented lower and upper bound for the number of cycles of a given length 
for general boolean monomial dynamics. When χf has more than one component, 
the obstacle in studying the exact cycle structure of f is that structure of cycles of 
length d ≥ 1 depends on not only how components decompose in χfd but also on 
how components are connected in χf . It is even difficult to determine the number of 
fixed points of boolean monomial dynamics. We show that the problem of counting 
fixed points of a monomial dynamics over F2 is #P − complete, for which no efficient 
algorithm is known. This is proved by a 1 − 1 correspondence between fixed points 
of f and antichains of the poset of strongly connected components of χf . We also 
extend the results of boolean monomial dynamics to monomial dynamics over general 
finite fields. To determine fixed points of a monomial map f over Fq, we work on 
zero component and nonzero components separately. We find the zero components 
by examining the dependency graph of f as done in boolean monomial dynamics. We 
show how nonzero components of f can be reduced to a linear map over Zq−1 by using 
logarithmic representation of f . Hence deciding the values of nonzero components of 
fixed points is equivalent to solving linear systems over Zq−1. 
In Chapter 3, we apply finite covering to analyze dynamics of nonlinear maps 
over finite fields. We are particularly interested in the dynamics of f(x) = x+x−1 over 
F2n ∪{∞}. We lift f to an isogeny g = I +σ on the elliptic curve E : y2 +xy = x3 +1 
where I is an identity map and σ is the Frobenius map. For a positive integer n, let 
E(F2n) be the set of F2n-rational points of E and Ep(F2n) a p− subgroup of E(F2n) 
where p is a prime. Since E(F2n) is a finite abelian group, E(F2n) can be decomposed 
as direct sum of Ep(F2n)’s where p is a prime dividing #E(F2n). 
We show that all the tails of g come from the the dynamics g on E2(F2n). It is 
known that E2(F2n) is isomorphic to Z/(2h2) for some h2. We prove that h2 is equal 
to ν2(n) + 2 and every tree attached to a periodic points is a complete binary tree of 
6
height ν2(n) + 1. 
For an odd prime p, g is an automorphism on Ep(F2n). Hence all cycle lengths 
are explained by the dynamics of g on Ep(F2n). Note that Ep(F2n) is isomorphic to 
Z/(pap) × Z/(pbp) where ap and bp depend on the factorization of σn − 1 in Z[σ]. 
We show that the dynamics of g on Ep(F2n) can be reduced to that of a linear map 
M = ( 
0 1 −2 1 
) on a Z−module. We distinguish three cases: 
(a) For p = 7, we show that #E(F2n) is divisible by 7 if and only 6|n and, for that 
n = 6 · 7e ·w with e ≥ 0 and 7 ∤ w, E7(F2n) is isomorphic to Z/(7e)× Z/(7e+1). 
We show that all the cycle lengths of g on E7(F2n) can be obtained from the 
multiplicative order of M modulo 7c where c runs from 1 to e + 1. 
(b) For odd prime p’s with ( 
p 7 
) = −1, we show that Ep(F2n) is isomorphic to 
Z/(pe) × Z/(pe) with e = νp(#E(F2n))/2 and the dynamics of g on Ep(F2n) is 
identical to that of M over Z/(pe)× Z/(pe). 
(c) For odd prime p’s with ( 
p 7 
) = 1, it is difficult to analyze the cycle lengths of g 
on Ep(F2n) because the structure of Ep(F2n) can be arbitrary. But we show that 
when Ep(F2n) is isomorphic to Z/(pe), g on Ep(F2n) can be reduced to a mul-
tiplication map on Z/(pe), and when Ep(F2n) is isomorphic to Z/(pe)× Z/(pe), 
the dynamics of g on Ep(F2n) is identical to that of M on Z/(pe)× Z/(pe). 
Using this information, we show that, in the dynamics of f on F2n ∪{∞}, the length 
of a cycle projected from an even cycle in the dynamics of g on E(F22n) is the half 
of the cycle length and the length of a cycle projected from an odd cycle has the 
same cycle length. We also show that there are three different tail structures in the 
dynamics of f on F2n ∪ {∞}: 
(a) The tree structure attached to∞ is as follows: a complete binary tree of height 
7
ν2(n) is attached to 0 and 0 is attached to ∞. 
(b) Structure of a tree projected from a tree attached to a periodic point P = 
(x, y) ∈ E(F22n) with x ∈ F2n , y /∈ F2n is a tree of height 0. 
(c) Structure of a tree projected from a tree attached to a periodic point P ∈ 
E(F2n) \ {O} is a complete binary tree of height ν2(n) + 1. 
In Chapter 4, we present an interesting application of finite coverings. We 
construct a new family of permutation maps over finite fields with odd characteristic 
from the known family of permutation maps using finite covering. The key idea is 
that we project n−th power map g using a proper projection map π which is different 
from one used to construct Dickson’s polynomials and obtain a new family of maps h 
satisfying π · g = h · π. We show the exact condition for new maps to be permutation 
maps. 
Finally in Chapter 5, we recapitulate the results given in this work and consider 
the possible questions for future research. 
8
Chapter 2 
Monomial Dynamics over Finite 
Fields 
2.1 Introduction 
For this chapter, we focus on the case when V = F n q and the map f : F n 
q → F n q 
is defined by 
f = (f1, f2, . . . , fn) 
where 
fi = ci · xmi1 1 xmi2 
2 · · · xmin 
n , 1 ≤ i ≤ n, 
with ci ∈ Fq and mij ∈ N. Then f is called a monomial map over Fq and the dynamics 
f a monomial dynamics. 
Since our work extends that of Colón-Reyes et al. [2004]; Jarrah et al. [2008], 
we will use their definitions and basic setup in most of cases. We associate f with a 
digraph χf , called the dependency graph of f which has vertex set {1, 2, . . . , n}, 
and there is a directed edge from j to i if and only if ci 6= 0 and xj|fi. Note that j is 
9
adjacent to i if and only if the value of xj affects fi and we allow self-loops in χf . 
Example 2.1.1. Let f be defined over F2 as 
f = (x2, x3x4, x2, x5x12, x6, c, x8x11, x3x9, x10, x6, x9, x12) 
where c in F2. The dependency graph χf of f is as follows: 
C2 
C3 
C1 
={9,10,11} 
={12} 
={2, 3}2 
4 
5 
6 
3 
1 7 
8 
9 
10 
12 
11 
Figure 2.1: Dependency Graph χf of f and its Strongly Connected Components 
When c = 1, the fixed points of f are : 
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1), 
(0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1), 
(1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1), 
(0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0), 
(0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1). 
10
When c = 0, the fixed points of f are : 
(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), 
(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1). 
Let χ be any digraph. For any two vertices i, j ∈ χ, if there is a directed 
path, or dipath for short, from i to j and a dipath from j to i then we say i and 
j are strongly connected. A subset of vertices is called strongly connected if each 
pair of vertices in the subset is strongly connected. Any maximal strongly connected 
subset of vertices of χ is called a strongly connected component of χ, or simply 
a component of χ. Note that a vertex itself is a component if and only if it has a 
self-loop. 
Note that different components of χ have disjoint vertices, and there may 
be vertices in χ that do not lie on any component. For any vertex i not on any 
component, either there is a dipath from i to some component or there is a dipath 
from some component to i, but not both. Similary, for any two components, if there 
are paths for one component to the other, then there is no path going to the opposite 
direction. We say a component C1 is above, or greater than, another component C2 
if there is a dipath from C2 to C1. This makes the set of all the components of χ into 
a partially ordered set, i.e., a poset. 
Example 2.1.1.(revisited). Suppose that we have the dependency graph χf as in 
Figure 2.1.1. Then, for c = 1, the poset is as in Figure 2.1. 
11
C1 
C2 
C3 
C1 
C3 
C2 
1 
4 
5 
6 
8 
7 
Figure 2.2: Poset of the Dependency Graph χf 
Let G be a set. A partial order is a binary relation “ ≤ ” over G which satisfies 
reflexive, antisymmetric, and transitive. With a partial order, G is called a partially 
ordered set. A pair of elements x and y in G are comparable if x ≤ y or y ≤ x. A 
subset A of G is called an antichain if no two elements in A are comparable. Note 
that the empty subset is an antichain and any singleton subset is an antichain as well. 
Example 2.1.2. Suppose that G is as below: 
C1 
C3 
C2 
Figure 2.3: Poset of the Strongly Connected Components of χf 
Then all the possible antichains of G are: 
∅ , {C1} , {C2} , {C3} , and {C1, C2}. 
12
Note that G in Figure 2.1.2 is obtained from the poset of the dependency graph 
χf in Figure 2.1 by considering only components. For a given dependency graph χf 
of f , we define Gf as the poset of strongly connected components in χf and we call 
Gf the component poset of χf . Let A be a subset of a partially ordered set G. A 
is upper closed if for any x ∈ A and y ∈ G, x ≤ y implies that y ∈ A too. Similarly, 
A is lower closed if for any x ∈ A and y ∈ G, x ≥ y implies that y ∈ A too. Let 
k be an arbitrary field. For any point P = (a1, a2, . . . , an) ∈ kn, we define subsets 
S0(P ) and S1(P ) of χf as 
S0(P ) = {1 ≤ i ≤ n : ai = 0}, S1(P ) = {1 ≤ i ≤ n : ai 6= 0}. 
Then fixed points of monomial dynamics have the following unique property. 
Proposition 2.1.1. Let k be an arbitrary field and f : kn → kn be a monomial map. 
Suppose P = (a1, a2, . . . , an) ∈ kn is a fixed point of f . Then S0(P ) is upper closed 
and S1(P ) is lower closed. 
Proof. Since P = f(P ), for each j in the dependency graph χf , we have aj = fj(P ). 
For any vertex i that has an edge to j, if ai = 0 then aj = 0. Also, if aj 6= 0 then 
ai 6= 0 for all vertices i adjacent to j. The proposition follows by chasing the dipaths 
in χf . 
This property gives us a different way to recognize fixed points of monomial 
dynamics and we will investigate the structure of fixed points using this property. 
13
2.2 Fixed Points over F2 
In this section, we study how to find all fixed points of the dynamics of a given 
map f over F2 and delve into the related combinatorial problems. 
Theorem 2.2.1. Let f = (f1, f2, . . . , fn) : F n 2 → F n 
2 and let χf be the dependency 
graph of f . Assume that no fi’s are constant. Then there exists a 1−1 correspondence 
between the set of fixed points of f and the set of antichains of the component poset 
Gf of χf . 
Proof. Suppose P is a fixed point of f . Then, by Proposition 2.1.1, S1(P ) is lower 
closed. So the set of maximal strongly connected components among the strongly 
connected components contained in S1(P ) forms an antichain. Now, suppose A is an 
antichain of the component poset. Then, for all 1 ≤ i ≤ n, set ji = 0 if ji ≥ C for 
some C ∈ A and set ji = 1 otherwise. Let PA = (j1, j2, . . . , jn). Note that if ji = 0, 
then since j = 0 for all j ≥ ji, fi(PA) = 0. Also, if ji = 1, then since j = 1 for all 
j ≤ ji, fi(PA) = 1. This implies that f(PA) = PA, i.e. PA is a fixed point. 
Example 2.1.1.(revisited). Suppose that f is defined in Example 2.1.1. Recall 
that we have already seen the component poset Gf of χf in Figure 2.1.2 and the 
corresponding antichains. From this, we can find all the fixed points of f : 
∅ ←→ (1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1), 
{C1} ←→ (0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1), 
{C2} ←→ (1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1), 
{C3} ←→ (0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0), 
{C1, C2} ←→ (0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1). 
14
So, if we can compute the number of antichain of the component poset, then 
we know the number of fixed points of given boolean monomial dynamics. 
Definition 2.2.1 (Valiant [1979]). #P is the class of functions that can be computed 
by counting Turing machines of polynomial time complexity. 
A problem is #P − complete if and only if it is in #P , and every problem 
in #P can be reduced to it by a polynomial-time counting reduction. There is no 
known algorithms to solve #P −complete problem efficiently. Provan and Ball [1983] 
showed that computing the number of antichains of given poset is a #P − complete 
problem and Knuth and Ruskey [2003] studied some special cases where the counting 
can be done efficiently. In the following, we present a simple algorithm to count the 
number of antichains of a given poset. 
2.2.1 Counting the Number of Antichains of a Poset 
Let G be a poset and τ(G) be the number of antichains of G. Note that any 
subset of a poset is a poset too. Then there are two basic properties of the number 
of antichains. First, if G is a disjoint union of G1 and G2, then 
τ(G) = τ(G1) · τ(G2). 
Suppose v ∈ G. Then 
τ(G) = τ(G1) + τ(G2) 
where G1 and G2 are defined as following: 
 G1 = G \ {u ∈ G : u comparable to v} and 
 G2 = G \ {v}, but keeps the connections. 
15
The following example will clarify the definitions of G1 and G2. 
Example 2.2.1. Suppose that a poset G is as following: 
1 2 
5 6 7 
3 4G = 
Figure 2.4: Poset G 
If we pick the vertex 3, then the corresponding G1 and G2 are as in Figure 2.5: 
G =1 
2 
7 
4 G =2 
1 2 
5 6 7 
4and 
Figure 2.5: G1 and G2 for the Vertex 3 of G 
Note that if G is a tree of height 1 with n leaves, then τ(G) = 1 + 2n. Thus, 
with these properties, we can develop a recursive algorithm for counting the number 
of antichains in any poset. 
- Algorithm 1 
Input : a poset G. 
Output : τ(G) ( = the number of antichains ). 
16
ALG1(G) : 
1. If G is a tree of height 1 with n leaves, then return (1 + 2n). 
2. Pick any maximal(or minimal) element v ∈ G. Define G1 and G2 as follows: 
 G1 := G \ {u ∈ G : u < v}(or G \ {u ∈ G|u > v}, respectively). 
 G2 := G \ {v}. 
3. return (ALG1(G1) + ALG1(G2)). 
End of ALG1(G) Note that using maximal or minimal element in the above algorithm 
does not change the result or the performance of the algorithm. Although counting 
the number of antichains is generally known as a difficult problem, there are certain 
cases in which we can count it efficiently [Knuth and Ruskey, 2003]. Here, we list 
some of those special types of posets. 
1. Suppose that T is a tree. T is called a complete n − ary tree of height h if 
if every node of T except leaves has the same in-degree, n, and every leaf has 
the same depth, h. Let T (n, h) be a complete n − ary tree of height h. Then 
the properties above gives us the linear time algorithm to count the number of 
antichains of the tree T (n, h). Let u ∈ T (n, h) be the root. Then since it is 
n− ary complete tree, there are n T (n, h− 1)’s attached to u. Thus 
τ(T (n, h)) = 1 + (τ(T (n, h− 1)))n. 
Same reasoning works for a inverted complete n − ary tree of height h. Here 
is an example of a complete n − ary tree. For instance, consider T (3, 3), a 
complete tertiary tree of height 3 in Figure 2.6. Using the above recurrence 
17
oo o o o o o o o 
o o o o o o o o o o o o o o o o o o o o o o o o o o o 
o o o 
o 
Figure 2.6: Complete Tertiary Tree of height 3 
relation, we have 
τ(T (3, 3)) = 1 + (τ(T (3, 2)))3 = 1 + ( 1 + (τ(T (3, 1)))3 
)3 
= 1 + ( 
1 + ( 1 + 23 
)3 )3 
= 389017001. 
2. For positive integers m and n, define M(m,n) by a m−partite graph where each 
level has n vertices and each level is completely connected only with adjacent 
levels. M(4, 3) is shown in Figure 2.7. Then, by choosing a vertex in the 
highest(or lowest level), we have 
τ(M(m,n)) = 2n−1+2n−2+. . .+2+1+τ(M(m−1, n)) = 2n−1+τ(M(m−1, n)). 
Thus 
τ(M(m,n)) = (m− 1)(2n − 1) + τ(M(1, n)). 
Note that G(1, n) is just a poset with n singletons. So 
τ(M(m,n)) = (m− 1)(2n − 1) + 2n = m · 2n −m + 1. 
Then using the above formula, we know 
18
4 5 6 
7 8 9 
10 11 12 
1 2 3 
Figure 2.7: Special Quadripartite Graph 
τ(M(4, 3)) = 4 · 23 − (4− 1) = 29. 
19
2.3 Cycles of Lengths Greater than One over F2 
In this section, we want to discuss how to determine cycles of length greater 
than one in boolean monomial dynamics. Note that if f has a cycle of length m, 
then fm has m new fixed points which are not fixed points of f . This implies that 
the dependency graph of fm has more components than that of f . To be precise, we 
need to study when components of χf can be decomposed into smaller components 
of fm. The dependency graph of fm will be denoted by χfm . Note that if a vertex 
is not on any component of χf , then it is not on any component of χfm . Hence all 
components of χfm come from those of χf . 
The following example shows the difficulty of studying cycle structure of the 
dynamics of f when χf has more than one component. 
Example 2.3.1. Suppose we have the following dependency graphs χf and χg. 
C2 
C1 
o o 
o 
o 
oo 
χ 
f fG 
o o 
o 
o 
oo 
C2 
C1 
χ 
g Gg 
Figure 2.8: Dependency Graphs of f and g 
As we see in Figure 2.3.1, the component posets Gf and Gg are identical. This 
implies that, in this example, the set of fixed points are same in both dynamics. Now 
consider the dependency graphs of f 2 and g2. 
20
C11 C12 
C21 C22 
o 
o 
oo 
o o 
o 
o 
oo 
o o C11 C12 
C21 C22 
χ f 2 2fG χ 
g 2 g 2G 
Figure 2.9: Dependency Graphs of f 2 and g2 
Although f and g have the same fixed points, the cycle structure of f and g 
are different since the component posets Gf2 and Gg2 are different. 
Example 2.3.1 shows that to find out the component poset Gfm , we need 
precise information on how vertices are connected to others in χf . In the rest of 
this chapter, we focus on the case when χf has only one component. To investigate 
further, we need the following definition. 
Definition 2.3.1 (Loop Number [Colón-Reyes et al., 2004]). The loop number of a 
vertex v ∈ χf is the minimum of all numbers t ≥ 1 where t = |p| − |q| for all closed 
walks p, q : v → v. If there is no closed walk from v to v then we set the loop number 
to be zero. 
It was also shown in [Colón-Reyes et al., 2004] that all elements in a component 
have the same loop number, which implies that the loop number is a property of the 
component. 
Example 2.3.2. Suppose a component C is as follows: 
21
1 2 
12 
17 
13 14 
16 
6 
715 
4 3 5 
11 10 
8 
9 
Figure 2.10: Component C 
By the definition, the loop number of C is 6. 
Proposition 2.3.1. Suppose a ∈ χf and its loop number is t. Then, for any two 
loops l1 and l2, passing through a, 
|l1| ≡ |l2| (mod t). 
Proof. Without loss of generality, assume that |l1| > |l2|. Since the loop number 
is t, there exists closed walks c1 and c2 such that |c1| − |c2| = t. Suppose that 
|l1| − |l2| = kt + α where 0 ≤ α < t. Then we have two closed walks l1 + kc2 and 
l2 + kc1 from a to a, 
|l1 + kc2| − |l2 + kc1| = |l1|+ k|c2| − |l2| − k|c1| 
= (|l1| − |l2|)− k(|c1| − |c2|) 
= kt + α− kt 
= α. 
By the minimality of the loop number, we have α = 0, hence |l1|−|l2| ≡ 0 (mod t). 
22
Definition 2.3.2. Let a, b ∈ χf . Then directed distance from a to b, denoted by 
d(a, b), is the length of the shortest path from a to b. We define d(a, b) =∞ if there 
is no path from a to b. 
Lemma 2.3.2. Let C be a component of χf with loop number t. We define a relation 
between any two vertices a, b ∈ C by 
a ∼ b if d(a, b) ≡ 0 (mod t). 
Then ∼ is the equivalence relation on C. 
Proof. Let c1 and c2 be closed walks from a to a with |c1| − |c2| = t throughout the 
proof. For any loop p : a → a, suppose that |p| = d(a, a) = kt + α where 0 ≤ α < t. 
Then we have closed walks p + kc2 and kc1 with 
|p + kc2| − |kc1| = |p| − k(|c1| − |c2|) = kt + α− kt = α. 
By the minimality of the loop number, we have α = 0. Hence every loop passing 
through a has length 0 modulo t. In particular, d(a, a) = 0. 
Suppose that a ∼ b. Then, by the definition, d(a, b) ≡ 0 (mod t). We want 
to show that d(b, a) ≡ 0 (mod t). Let p1 : a→ b with |p1| = k1t and p2 : b→ a with 
|p2| = d(b, a). Then p1 + p2 is a loop from a to a. Recall that |p1 + p2| ≡ 0 (mod t), 
which implies |p2| ≡ 0 (mod t). Hence d(b, a) ≡ 0 (mod t). 
Now, suppose a ∼ b and b ∼ c for a, b, c ∈ C, i.e., there exist a path p1 from 
a to b with |p1| = d(a, b) = k1t and a path p2 from b to c with |p2| = d(b, c) = k2t. 
Let p be any path from c to a. Then we have a loop p1 + p2 + p3 from a to a and 
|p1 + p2 + p| = |p1|+ |p2|+ |p| ≡ 0 (mod t). Hence, d(c, a) ≡ 0 (mod t). 
23
Now partition C according to its loop number t. Pick c ∈ C and let Ci be 
Ci = {a ∈ C : d(a, c) ≡ i (mod t)}. 
It is easy to see that for any a1, a2 ∈ C, a1 ∼ a2 if and only if a1, a2 ∈ Ci for some i. 
Thus C can be decomposed as 
C = C0 ∪ C1 ∪ C2 ∪ . . . ∪ Ct−1. 
From the definition of Ci’s, we can see that the first t steps of the walk from c to 
itself decides the decomposition and these subcomponents Ci’s will not change with 
the different choice of c. Moreover, for any a ∈ Ci, there exists b ∈ Ci+1 such that 
d(a, b) = 1. 
Example 2.3.2.(revisited). Recall that the loop number of C is 6. We can decom-
pose C into two classes as following: 
C = C0 ∪ C1 = {1, 3, 5, 7, 11, 14, 16} ∪ {2, 4, 6, 8, 10, 12, 13, 15, 17}. 
Theorem 2.3.3. Each component of the dependency graph χf with loop number t 
decomposes into d components in χfm with loop number t/d where d = gcd(m, t) and 
the loop number of newly generated components is t/d. 
Proof. This comes directly by the properties of the equivalence classes and the above 
decomposition. 
Theorem 2.3.3 says that to find out cycles of length greater than 1, it is enough 
to look at χm f where gcd(m, t) > 1. Thus, to find out cycles of length > 1, we do not 
have to look χfm for all m > 1. It is enough to consider χfm and the poset of χfm for 
24
m such that m ≤ t and gcd(m, t) > 1 where t is the loop number of some component 
in χfm . Theorem 3.8. in [Jarrah et al., 2008] showed the number of points of certain 
period, equivalently the number of cycles of certain length. Here we present simpler 
proof for the number of cycles of a given length dividing the loop number. 
Theorem 2.3.4. Suppose χf has only one component C with the loop number t and 
k is a positive integer which divides t. Let ℓ(k) be the number of cycles whose lengths 
are exactly k. Then 
ℓ(k) = 1 
k · ∑ 
d|k 
µ(d)2 dt k . 
Proof. For any d, k that divide t, let A(d) be the set of periodic points of period of 
d as defined in [Jarrah et al., 2008]. Since the set of cycles of length d is pairwise 
disjoint, A(d) = d · ℓ(d). From [Jarrah et al., 2008, Lemma 3.6.], we know 
∑ 
d|k 
d · ℓ(d) = ⋃ 
d|k 
A(d) = 2k. 
Then Móbius inversion gives us 
k · ℓ(k) = ∑ 
d|t 
µ(d)2 k d . 
Hence 
ℓ(k) = 1 
k · ∑ 
d|k 
µ(d)2 k d . 
25
2.4 Monomial Dynamics over General Finite Fields 
In this section, we study monomial dynamics over general finite fields. Even 
though we can apply many techniques that we discussed in the previous chapters, 
there is limitation to them. Thus, we will study what the difficulties for general finite 
fields are and how we approach this problem. Note that for cycles of lengths greater 
than 1, we can convert the problem to finding fixed points of fm for m > 1, we will 
focus on finding fixed points of f . 
Let q be a power of an odd prime and f = (f1, f2, . . . , fn) : F n q → F n 
q be a 
monomial map. Then, for each i = 1, . . . , n, 
fi = ci · xmi1 1 xmi2 
2 · · ·xmin 
n = γbi · xm1i 
1 xm2i 
2 · · · xmni 
n 
where γ is a primitive element of Fq. Without loss of generality, we assume that 
fi 6= 0 for all 1 ≤ i ≤ n. Since any non-zero element in Fq can be represented as a 
certain power of γ, we can take log on both sides and obtain 
logα fi ≡ bi + n∑ 
j=1 
mij · logγ xj (mod q − 1). 
Let A = ( 
mij 
) 
∈ Nn×n. Now we can express the monomial map f = (f1, f2, . . . , fn) 
as a matrix representation. 
( logγ f1, logγ f2, . . . , logγ fn 
) = (b1, b2, . . . , bn) + 
( logγ x1, logγ x2, . . . , logγ xn 
) · A. 
We also write this as 
logγ f = b + logγ x · A 
26
where b = (b1, b2, . . . , bn), logγ x = (logγ x1, logγ x2, . . . , logγ xn). Observe that 
f ←→ b + logγ x · A, 
f 2 ←→ b(I + A) + logγ x · A2, 
f 3 ←→ b(I + A + A2) + logγ x · A3, 
... 
fk ←→ b(I + A + A2 + . . . + Ak−1) + logγ x · Ak. 
Next we show how this can be used to find the fixed points of f . Note that we can still 
find which coordinates are zero in a fixed point by examining the poset of χf just as 
we did over F2 by using Proposition 2.1.1. After choosing the nonzero components, we 
need to show how to find the actual values. Without loss of generality, we demonstrate 
below how to find fixed points x that are nonzero on all components. We call such 
fixed points nontrivial fixed points. Then a point x is a nontrivial fixed point of f if 
and only if it satisfies 
logγ x ≡ b + logγ x · A (mod q − 1), 
i.e., 
logγ x · (I − A) ≡ b (mod q − 1). (2.1) 
Let M = I−A. Then since Z/(q−1) is a principal ideal domain, we know that there 
27
exists invertible matrices P,Q ∈ Zn×n q−1 such that 
P ·M ·Q ≡ D ≡ 
 
               
d1 
. . . 
dl 
0 
. . . 
0 
 
               
(mod q − 1) 
where di|q − 1 and di|dj for all i ≤ j. The matrix D is called a Smith-Normal Form. 
Thus (2.1) implies that 
logγ x · P−1 ·D ≡ b ·Q (mod q − 1). 
Let y = logγ x · P−1 and b̃ = b ·Q. Then, since P is invertible, x is a fixed point of f 
if and only the corresponding y is the solution to y ·D = b̃ (mod q− 1). The system 
has solution if and only if 
 
 
 
di|b̃j for 1 ≤ i ≤ r, 
0 ≡ b̃j (mod q − 1) for r + 1 ≤ i ≤ n. 
Thus finding nontrivial fixed points is equivalent to solving the linear equation over 
a ring provided discrete log problem is relatively easy on given finite field, i.e., this 
approach works efficiently when |Fq| is small. Here is an example which explains how 
to find non-trivial fixed points with this approach. 
28
Example 2.4.1. Let a monomial dynamical system f : F3 5 → F3 
5 be 
f(x1, x2, x3) = (x2, x 2 1x 
3 2x 
2 3, 3x 
3 1x 
2 2). 
Then the dependency graph χf of f has only one component so that there is only one 
trivial fixed point, (0, 0, 0). 
2 3 
1 
Figure 2.11: Dependency Graph χf of f . 
Now we want to find nontrivial fixed points of f . Note that F× 5 =< 2 >. Thus, 
using the above idea, this monomial system can be represented as the following linear 
equation: 
log2 f = (0, 0, 3) + log2 x 
 
     
0 2 3 
1 3 2 
0 2 0 
 
     
, 
i.e., 
log2 f = b + log2 x · A. 
Fixed points of f satisfy 
log2 x = b + log2 x · A. 
29
Let 
M = I − A = 
 
     
1 2 1 
3 2 2 
0 2 1 
 
     
. 
Then 
P ·M ·Q ≡ D (mod 4) 
where 
P = 
 
     
2 2 1 
1 2 2 
3 3 3 
 
     
, Q = 
 
     
1 3 0 
0 0 1 
3 0 2 
 
     
, and D = 
 
     
1 0 0 
0 1 0 
0 0 2 
 
     
. 
Note that b̃ = b · Q ≡ (1, 0, 2) (mod 4). Since y · D ≡ (y1, y2, 2y3) (mod 4), the 
solutions to y ·D ≡ b̃ (mod 4) are 
y = (1, 0, 1) and (1, 0, 3). 
Then log2 x = (1, 1, 0) and (3, 3, 2), i.e., the nontrivial fixed points are 
x = (2, 2, 1) and (3, 3, 4). 
Note that ring Z/(q−1) has zero-divisors. Thus it is possible that the dynamics 
of a given map does not have nontrivial fixed points. The following two examples will 
show such cases with different reasons. 
Example 2.4.2. Let a monomial dynamical system f : F3 5 → F3 
5 be 
f(x1, x2, x3) = (x2, x 2 1x2x 
2 3, 3x 
3 1x 
2 2). 
30
Note that this map is obtained by small modification of the map in Example 2.4.1 and, 
indeed, the dependency graph of f and its component poset is the same with that given 
in Example 2.4.1. With the same approach, this monomial system can be represented 
as the following linear equation: 
log2 f = (0, 0, 3) + log2 x 
 
     
0 2 3 
1 1 2 
0 2 0 
 
     
, 
i.e., 
log2 f ≡ b + log2 x · A (mod 4). 
Fixed points satisfy 
log2 x ≡ b + log2 x · A (mod 4). 
Let 
M = I − A = 
 
     
1 2 1 
3 0 2 
0 2 1 
 
     
. 
Then 
P ·M ·Q ≡ D (mod 4) 
where 
P = 
 
     
2 2 1 
1 2 2 
3 3 3 
 
     
, Q = 
 
     
1 3 0 
0 0 1 
3 0 2 
 
     
, and D = 
 
     
1 0 0 
0 1 0 
0 0 0 
 
     
. 
Note that b̃ = b ·Q ≡ (1, 0, 2) (mod 4). Since y ·D ≡ (y1, y2, 0) (mod 4), there is no 
31
y ∈ Z3 4 satisfying 
y ·D ≡ (1, 0, 2) (mod 4). 
Hence there is no nontrivial fixed points. 
Here is the example of dynamics which has no non-trivial fixed points due to 
the scalar. 
Example 2.4.3. Let a monomial dynamical system f : F3 5 → F3 
5 be 
f(x1, x2, x3) = (x2, 3x 2 1x 
3 2x 
2 3, 3x 
3 1x 
2 2). 
To obtain this map, we altered the constant coefficient of f2 of the map in Exam-
ple 2.4.1. Thus the linear equation representing the given systems will be identical 
except b. So we have 
log2 f = (0, 3, 3) + log2 x 
 
     
0 2 3 
1 3 2 
0 2 0 
 
     
, 
i.e., 
log2 f = b + log2 x · A. 
From Example 2.4.1, we already know that b̃ = b · Q ≡ (1, 0, 1) (mod 4) and 
y ·D ≡ (y1, y2, 2y3) (mod 4). Since 2 is not invertible in Z4, there is no y ∈ Z3 4 such 
that 
y ·D ≡ (1, 0, 1) (mod 4). 
Hence there is no non-trivial fixed points. 
32
Chapter 3 
Finite Coverings 
3.1 Introduction 
The idea of finite coverings originated from the holomorphic dynamics liter-
ature. In this section, we would like to give a brief explanation of it and present 
examples of dynamical systems over finite fields which can be explained by it. For 
more general information, it is recommended to read “On the Lattè’s Map” by J. Mil-
nor in [Hjorth and Petersen, 2006]. Let f be a rational map of degree two or more 
from the Riemann sphere Ĉ = C ∪ {∞} to itself and Ef be the set of all points with 
finite grand orbit under f . f is called a finite quotient of an affine map if there 
exists a discrete additive subgroup Λ of C, an affine map L : C/Λ → C/Λ, and a 
finite-to-one holomorphic map Θ : C/Λ → Ĉ \ Ef such that the following diagram is 
33
commutative: 
C/Λ L // 
Θ 
 
C/Λ 
Θ 
 
Ĉ \ Ef 
f // Ĉ \ Ef 
The commutativity of the diagram implies that each orbit of a point in C/Λ is pro-
jected by Θ to an orbit of a point in Ĉ \Ef and since L is an affine map, its dynamics 
are “simpler” than that of f . Especially, when every point in Ĉ \ Ef has preimages in 
C/Λ, we say the dynamics of L on C/Λ covers that of f on Ĉ \ Ef . This provides a 
great tool to study dynamics of rational maps. Finite quotients of affine maps can be 
classified as powermaps, Chebyshev maps, and Lattè’s maps according to their Julia 
sets. These three classes can be well extended to over finite fields and the dynamics 
of them on finite fields can be explained easily. For example, let Fq be a finite field 
of q elements where q is a power of prime. It is easy to see that the dynamics of 
n-th power map on F× q is covered by that of the multiplication by n on Z/(q − 1) 
which can be analyzed effortlessly. For Chebyshev maps over finite fields, suppose 
L : Z/(q2 − 1) → Z/(q2 − 1) by L(y) = ny for y ∈ Z/(q2 − 1) and π(y) = αy + α−y 
where α is a generator of F× q2 . Then we have the following commutative diagram: 
y  L 
// 
π 
 
ny 
π 
 
αy + α−y  
f // αny + α−ny 
Notice that the image of π contains Fq and f is the n-th degree Chebyshev polynomial. 
As π is a 2− cover, which is the reason to use the quadratic extension, any odd cycle 
34
of L projects via π to a cycle of f of the same length and any even cycle of L projects 
to a cycle of half length. The cycle lengths of L are the orders of n modulo m where 
m|(q2− 1). Therefore, the cycle lengths of the n-th degree Chebyshev polynomial on 
Fq are determined by the orders of n modulo m with m running through the divisors 
of q2 − 1. 
When we restrict V to a finite field, holomorphicity is not defined. There is a 
possibility that we have maps which are not finite quotients of affine maps but whose 
dynamics can be explained by this idea. We can generalize this idea as follows: Let 
V and W be algebraic varieties and f : V → V and g : W → W be morphisms. Then 
g is called an n-covering of f if there exists a map π : W → V where for any x ∈ V , 
|π−1(x)| = n (counting multiplicity) such that the following diagram is commutative: 
W g 
// 
π 
 
W 
π 
 
V f 
// V 
Thus our main concern is to study the dynamics of f over V by exploring a proper 
covering space W , a covering morphism g, and the projection map π and studying 
the dynamics of g over W . In the following, we present a map which is not a finite 
quotient of an affine map over C, but whose dynamics can be analyzed by finite 
covering. 
35
3.2 A Dynamical System and its Associated Ellip-
tic Curve 
Let f : F2n ∪ {∞} → F2n ∪ {∞} be a map defined as 
f(x) = 
 
 
 
x + x−1 if x ∈ F× 2n , 
∞ if x = 0 or ∞. 
Figure 3.1, Figure 3.2, and Figure 3.3 show the dynamics of f on F2n ∪ {∞} for 
different values of n. 
o 
o 
oo 
o 
o o 
o 
o 
o 
o 
o 
o 
o 
o 
oo 
Figure 3.1: Dynamics of f(x) = x + x−1 on F24 ∪ {∞}. 
As we see in the figures, the dynamics of f show regularities in structures of 
cycles and trees. H.W. Lenstra, Jr. observed that f can be covered by dynamics of 
a certain isogeny on a Koblitz curve [Koblitz, 1991]. More precisely, let E be the 
elliptic curve group over the algebraic closure F2 defined by 
E : y2 + xy = x3 + 1. (3.1) 
36
o o 
o 
o 
o 
o 
o o 
o 
o 
o 
o 
o 
o o 
o 
o 
o 
o o 
o 
o 
o 
o 
o 
o 
o o 
o 
o 
o 
o 
o 
Figure 3.2: Dynamics of f(x) = x + x−1 on F25 ∪ {∞}. 
Then, with the point O at the infinity, E forms an abelian group with respect to 
the addition of points defined as following [Silverman, 1986, Group Law Algorithm 
2.3.]: O is an identity in E. Let P = (x1, y1) and Q = (x2, y2). If P 6= O, then 
−P = (x1, y1 + x1). Suppose Q 6= −P . Then P + Q = (x3, y3) where 
x3 = 
 
 
 
( y1+y2 
x1+x2 )2 + y1+y2 
x1+x2 + x1 + x2 if P 6= Q, 
x2 1 + 1 
x2 1 
if P = Q. 
and 
y3 = 
 
 
 
( y1+y2 
x1+x2 
) 
(x1 + x3) + x3 + y1 if P 6= Q, 
x2 1 + (x1 + y1 
x1 )x3 + x3 if P = Q. 
Let σ : E → E be the Frobenius morphism, that is, for P = (x, y) 6= O, σ(x, y) = 
(x2, y2). Define a map g : E → E by g(P ) = P + σ(P ) where + is the addition of 
points on the curve. Note that, for P = (x, y) 6= O, 
g(x, y) = (I + σ)(x, y) = (x, y) + (x2, y2) = (x′, y′), 
37
o o 
o 
o 
o 
o 
o 
o o 
o o 
o 
o 
o 
o 
o 
o 
o 
o 
o o 
o 
o 
o 
o 
o 
o 
o o 
o o o o 
o 
o o o o 
o 
o 
o 
o 
ooo 
o o 
o o o o 
o 
o o o o 
o 
o 
o 
o 
ooo 
o o 
Figure 3.3: Dynamics of f(x) = x + x−1 on F26 ∪ {∞}. 
where x′ = x + x−1 and 
y′ = 
 
 
 
x2 + 1 + 1 x2 + y + y 
x2 if (x, y) 6= (x2, y2), 
x + 1 + 1 x 
+ y + y x 
if (x, y) = (x2, y2). 
(3.2) 
Thus we have the following commutative diagram: 
E g 
// 
π 
 
E 
π 
 
F2 ∪ {∞} f 
// F2 ∪ {∞} 
where the projection map π is defined as 
π(P ) = 
 
 
 
x if P = (x, y) 6= O, 
∞ if P = O. 
38
Let E(F22n) be the set of F22n-rational points of E. Since for any x ∈ F2n ∪ {∞}, 
π−1(x) ∈ E(F22n), the dynamics of g on E(F22n) covers that of f on F2n ∪ {∞}. 
Moreover, g is an isogeny of E, i.e., a group homomorphism on E. This enables us 
to focus on the dynamics of g on E(F22n) to understand that of f on F2n ∪ {∞}. 
Throughout this chapter, E will denote the elliptic curve as defined in (3.1), 
End(E) denotes the ring of group endomorphism, m − torsion group of E over al-
gebraic closure is denote by E[m], and, for a field k, E(k)[m] denotes E[m] ∩ E(k). 
For a rational prime p, Ep(k) denotes p − subgroup of E(k), i.e., the order of any 
elements in Ep(k) is a power of p. 
39
3.3 Properties of g on E 
Since I and σ are endomorphisms of E, so is g. Thus g(P +Q) = g(P )+g(Q). 
One can check that the minimum polynomial mσ(T ) of σ is 
mσ(T ) = T 2 + T + 2 ∈ Z[T ]. 
So the minimum polynomial g is mg(T ) = T 2 − T + 2 ∈ Z[T ], i.e., 
g2 − g + 2 = 0 (3.3) 
as a map on E. Since (0, 1) is the only point of order 2 and O is the only fixed point 
of g, one can show that ker g = {O, (0, 1)}. Then we have the following recurrence 
relation: for any n ≥ 1, 
 
  
gn 
gn+1 
 
  = 
 
  
0 1 
−2 1 
 
  
 
  
gn−1 
gn 
 
  . 
Let 
M = 
 
  
0 1 
−2 1 
 
  . 
Then, for any n ≥ 0 and P ∈ E, 
 
  
gn(P ) 
gn+1(P ) 
 
  = Mn 
 
  
P 
g(P ) 
 
  . (3.4) 
Thus the dynamics of g depends on the behavior of M and the subgroups < P > and 
< g(P ) > of E. The following propositions show the basic properties of g. 
40
Proposition 3.3.1. For any point P ∈ E with odd order, g(P ) has the same order. 
Proof. Suppose the order of P is m which is odd. Since mP = O, g(mP ) = mg(P ) = 
O, the order ℓ of g(P ) divides m. Also, g(ℓP ) = ℓg(P ) = O, so ℓP is in the kernel of 
g. If ℓP = (0, 1), then 2ℓP = O, i.e., 2ℓ|m, which contradicts that m is odd. Thus 
ℓP = O. Hence, ℓ = m. 
Proposition 3.3.2. Suppose P ∈ E and |P | = m with m even. Then |g(P )| = m 2 . 
Proof. Let m = 2ℓ. Then 
mP = 2(ℓP ) = O. 
Since (0, 1) is the only point of order 2, ℓP = (0, 1). Thus 
ℓg(P ) = g(ℓP ) = g((0, 1)) = O, 
i.e., ℓ divides |g(P )|. Note that |g(P )| < ℓ implies that |P | < 2ℓ. Hence, the order of 
g(P ) = ℓ. 
Proposition 3.3.1 and Proposition 3.3.2 tell us that E[m] is g − invariant for 
any positive integer m. Although it is enough to consider the group structure of 
E(F22n) for our purpose, we investigate the group structure of E(F2n) for any n ≥ 1. 
41
3.4 Group Structure of E(F2n) 
Suppose 
#E(F2n) = ∏ 
p 
php 
where p’s are rational primes and hp ≥ 1. Since E(F2n) is a finite abelian group, 
E(F2n) is decomposed as 
E(F2n) = E2(F2n) + ⊕ 
p 6=2 
Ep(F2n) 
where Ep(F2n) is p − subgroup of E(F2n). As proved in Section 3.3, Ep(F2n) is 
g − invariant. Thus we study the structure of Ep(F2n) for each prime divisor p 
of #E(F2n). By Theorem 3 in [Rück, 1987], 
E2(F2n) ∼= Z/(2h2) 
where h2 = ν2(n) + 2, i.e., E2(F2n) is a cyclic group of order 2h2 . We will explore the 
size of E2(F2n) in depth in Section 3.5. Now we focus on Ep(F2n) for p 6= 2 rational 
prime dividing #E(F2n). Theorem 3 in [Rück, 1987] also says 
Ep(F2n) ∼= Z/(pap)× Z/(php−ap) 
where 0 ≤ ap ≤ hp. 
Recall that σ2 + σ + 2 = 0 as a map on E. So Q(σ) ∼= Q( √ −7). Moreover, 
since Z[σ] is the ring of integers for Q(σ), End(E) = Z[σ]. Z[σ] is, in fact, a PID. 
Lemma 3.4.1 ([Rück, 1987]). Let m be a positive odd integer. Then E[m] ⊆ E(F2n) 
if and only if σn − 1 = m · w ∈ End(E) where w ∈ End(E). 
42
Proof. Suppose E[m] ⊆ E(F2n). Then the kernel of multiplication by m is contained 
in the kernel of σn − 1. Since multiplication by m is separable [Silverman, 1986, 
Corallary 5.4.], the universal mapping property for Abelian varieties [Weil, 1948, 
Proposition 10.] shows that σn − 1 = m · w where w ∈ End(E). 
Suppose σn − 1 = w ·m ∈ End(E). For any point P ∈ E[m], (σn − 1)(P ) = 
w(mP ) = wO = O, which implies that P ∈ E(F2n). Thus E[m] ⊆ E(F2n). 
The factorization of σn − 1 gives us information on the structure of E(F2n). 
In this section, we analyze the structure of E(F2n) by studying the factorization of 
σn − 1 in Z[σ]. For our purpose, we denote νp(·) the valuation corresponding to a 
prime p in Z[σ]. For a rational prime p and for any α + βσ ∈ Z[σ] with α, β ∈ Z, we 
define νp(α + βσ) by 
νp(α + βσ) = min(νp(α), νp(β)) 
where νp(·) is the valuation of Z corresponding to p. 
Lemma 3.4.2. Let p ∈ Z be a rational prime with p 6= 2. Suppose σn − 1 = pt · w ∈ Z[σ] 
where p ∤ w. Then 
Ep(F2n) ∼= Z/(pap)× Z/(pbp) 
with ap = t and bp = t + νp(ww̄) where w̄ is the conjugate of w in Z[σ]. 
Proof. Suppose σn − 1 = pt · w ∈ Z[σ] where p ∤ w. Then Lemma 3.4.1 implies that 
E[pt] ⊆ E(F2n), but E[pt+1] 6⊆ E(F2n). From Corollary 6.4.(b) in Silverman [1986], 
we know that 
E[pt] ∼= Z/(pt)× Z/(pt). 
43
Note that E(F2n) = ker(σn − 1) by definition. So 
#E(F2n) = # ker(σn − 1) (by [Silverman, 1986, III.5.5. and III.4.10.c.]) 
= deg(σn − 1) (by [Silverman, 1986, III.6.1.]) 
= (σn − 1)(σn − 1) 
where σ is the dual isogeny of σ. Thus 
#E(F2n) = (σn − 1)(σn − 1) = (pt · w)(pt · w) = p2t · ww. 
This implies that νp(#E(F2n)) = 2t + νp(ww). Since Ep(F2n) contains E[pt] but not 
E[pt+1], 
Ep(F2n) ∼= Z/(pap)× Z/(pbp) 
where ap = t and bp = t + ν(ww). 
Thus, to determine ap for each p, we need to know the factorization of σn − 1 
in Z[σ]. 
Lemma 3.4.3. Suppose p ⊆ Z[σ] is prime and n0 is the smallest natural number 
such that νp(σ n0 − 1) = e with e ≥ 1. Then νp(σ 
n − 1) ≥ e if and only if n0|n. 
Proof. Write n as n = an0 + r where 0 ≤ r ≤ n0 − 1. Since σn0 ≡ 1 (mod pe), we 
have 
σn = σan0+r = (σn0)a σr ≡ σr (mod p e). 
Thus σn ≡ 1 (mod p) if and only if σr ≡ 1 (mod p). Since n0 is the smallest such 
that σn0 ≡ 1 (mod p), r = 0. Hence, n0|n. 
44
For e = 1, we have the following useful corollary. 
Corollary 3.4.4. Suppose p ⊆ Z[σ] is prime and n0 is the smallest natural number 
such that νp(σ n0 − 1) > 0. Then νp(σ 
n − 1) > 0 if and only if n0|n. 
Note that the proof of Lemma 3.4.3 is still valid if p is replaced by any ideal 
in Z[σ]. Thus we have the following corollary too. 
Corollary 3.4.5. Suppose that p 6= 2 is a rational prime and n0 is the smallest 
natural number such that p|(σn0 − 1). Then p|(σn − 1) if and only if n0|n. 
Lemma 3.4.6. Suppose that p 6= 2 is a rational prime and n is the smallest natural 
number such that νp(σ n − 1) = e where n ≥ 1 and e ≥ 1. Then the smallest n′ > n 
such that νp(σ n′ − 1) > e is pn. Moreover, νp(σ 
pn − 1) = e + 1. 
Proof. Since νp(σ n − 1) = e, 
σn ≡ 1 + c · pe (mod pe+1) 
where p ∤ c. It is easy to see that 
σpn ≡ 1 + c · pe+1 (mod pe+2), 
i.e., νp(σ pn − 1) = e + 1. Suppose n′ is the smallest such that νp(σ 
n′ − 1) > e. From 
Lemma 3.4.3, n′ = kn with 1 ≤ k ≤ n. Note 
σkn ≡ 1 + ck · pe (mod pe+2). 
So, νp(σ kn − 1) > e if and only if p|k, i.e., k = p. Hence, n′ = pn and νp(σ 
pn − 1) = 
e + 1. 
45
Lemma 3.4.7. Let p be an odd prime and n0 is the smallest natural number such that 
p|(σn0 − 1). Suppose that p|(σn − 1) and n = n0p en′ where p ∤ n′. Then νp(σ 
n − 1) = 
e + νp(σ n0 − 1). 
Proof. By applying Lemma 3.4.6, we know that n0p e is the smallest natural number 
such that νp(σ n0pe−1) = e+νp(σ 
n0−1). Since p ∤ n′, from the proof of Lemma 3.4.6, 
νp(σ n − 1) = νp(σ 
n0pe − 1) = e + νp(σ n0 − 1). 
Lemma 3.4.8. Suppose p ⊆ Z[σ] is prime above an odd rational prime p and n is 
the smallest such that νp(σ n − 1) = e with e ≥ 1. Then the smallest natural number 
m such that νp(σ m − 1) > e is pn where l ∈ Z is a prime below p. Moreover, for any 
n with νp(σ n − 1) = e ≥ 1, if p does not ramify, then 
νp(σ pn − 1) = e + 1, 
and if p ramifies and νp(σ n − 1) ≥ 3, then 
νp(σ pn − 1) = e + 2. 
Proof. From Corollary 3.4.4, we know that n|m. Let m = kn where k ≥ 2. Then 
σm − 1 = σkn − 1 = (σn)k − 1 = (σn − 1)(σ(k−1)n + · · ·+ σn + 1). 
Since σn ≡ 1 (mod p), 
B = σ(k−1)n + · · ·+ σn + 1 ≡ k (mod p). (3.5) 
46
Thus νp(B) > 0 if and only if νp(k) > 0, and the smallest such k is p. 
Suppose p does not ramify. Then either (p) = p or (p) = p · p, then νp(p) = 1 
in either case. Suppose that νp(σ n − 1) = 1. Then σn = 1 + c where νp(c) = 1. Since 
p is odd, 
σpn = (1 + c)p 
≡ 1 + c · p (mod p 3). 
Note that if p does not ramify, then νp(p) = 1. So we know that 
c · p ∈ p 2 but c · p /∈ p 
3. 
Thus νp(σ pn − 1) = 2. 
Suppose νp(σ n − 1) = e ≥ 2. In (3.5), for k = p, 
νp(B) = 1. 
Then 
νp(σ n − 1) = νp(σ 
n − 1) + νp(B) = e + 1. 
Now suppose p ramifies, i.e., (p) = p2 in Z[σ] and e ≥ 3. Then since νp(B) = 2, 
νp(σ n − 1) = νp(σ 
n − 1) + νp(B) = e + 2. 
This completes the proof. 
47
By Theorem 3.4.1. in [Milne, 2009], we know that, for a rational prime p 6= 2, 
 
 
 
(p) ramifies in Z[σ] if and only if p = 7, 
(p) splits in Z[σ] if and only if ( 
p 7 
) = 1, 
(p) stays prime in Z[σ] if and only if ( 
p 7 
) = −1. 
In the following, we study the subgroup structure according to each of the above 
cases. 
3.4.1 Structure of E7(F2n) 
Note that (7) ramifies in Z[σ]. In fact, (7) = p2 where p = (σ − 3, 7) is prime 
in Z[σ]. Suppose that σn − 1 = 7x · w where x ≥ 0 and w ∈ Z[σ] and 7 ∤ w. From 
now on, for a rational prime p, Ordp(α) denotes the multiplicative order of α modulo 
p where α can be an integer or integer matrix and, for an ideal I contained a ring R 
and an element α ∈ R, Ordp(α) denotes the multiplicative order of α modulo I. 
Lemma 3.4.9. Let p = (σ − 3, 7). Then the smallest natural number such that 
σn0 ≡ 1 (mod p) is 6. 
Proof. Note σ ≡ 3 (mod p) and Ordp(3) = Ord7(3) = 6. This completes the proof. 
Theorem 3.4.10. Suppose that p = (σ − 3, 7), the prime in Z[σ] above (7). Then 
#E(F2n) is divisible by 7 if and only if 6|n. If n = 6 · 7e ·m where 7 ∤ m, then 
E7(F2n) ∼= Z/(7e)× Z/(7e+1). 
48
Proof. By Corollary 3.4.4 and Lemma 3.4.9, we know that νp(σ n− 1) > 0 if and only 
if 6|n. Since #E(F2n) is divisible by 7 if and only νp(σ n − 1) > 0, 7|#E(F2n) if and 
only 6|n. 
Now suppose 6|n. Then 
σn − 1 = 7t · w 
where t ≥ 0 and w ∈ Z[σ] with 7 ∤ w. Since 6 is the smallest natural number such 
that σn ≡ 1 (mod p), νp(σ 3 + 1) > 0. From the minimum polynomial of σ, we know 
that σ3 + 1 = −σ + 3, which is not divisible by 7. Thus νp(σ 6 − 1) = 1. 
By Lemma 3.4.8, the smallest n such that νp(σ n− 1) > 1 is 6 · 7. Since σ6 ≡ 1 
(mod p) but σ6 6≡ 1 (mod 7), there exist c1 and c2 in Z[σ] where c2 /∈ p such that 
σ6 = 1 + c17 + c2(σ − 3). 
Then 
σ6·7 = (1 + c17 + c2(σ − 3))7 
≡ (1 + c2(σ − 3))7 (mod 72) 
≡ 1 + 7∑ 
i=1 
( 7 
i 
) 
ci 2(σ − 3)i (mod 72) 
≡ 1 (mod p 3). 
Since c2 /∈ p, σ6·7 6≡ 1 (mod 72), i.e., σ6·7 6≡ 1 (mod p4). Thus 
νp(σ 6·7 − 1) = 3. 
49
Lemma 3.4.8 tells us that νp(σ n − 1) always increases by 2. Since νp(σ 
6 − 1) = 1 and 
νp(σ 6·7 − 1) = 3, νp(σ 
n − 1) is odd for all n divisible by 6. So, for such n, 
σn − 1 = w′ p 
2e+1 = w′7e p 
where w′ ∈ Z[σ] with νp(w) = 0. Hence, for n = 6 · 7e · w where 7 ∤ w, 
E7(F2n) ∼= Z/(7e)× Z/(7e+1). 
3.4.2 Structure of Ep(F2n) with ( 
p 
7 
) = −1 
Suppose that ( 
p 7 
) = −1 and σn − 1 = pe · w in Z[σ] where p ∤ w and e ≥ 1. 
Since (p) stays prime in Z[σ], p ∤ w implies that p ∤ w̄. By Lemma 3.4.2, we have 
Ep(F2n) ∼= Z/(pe)× Z/(pe). 
3.4.3 Structure of Ep(F2n) with ( 
p 
7 
) = 1 
Suppose that ( 
p 7 
) = 1. Then p ≡ 1, 2, or 4 (mod 7). Recall that (p) = p · p 
in Z[σ] where p and p are prime in Z[σ] with p 6= p. Then p = (p, σ − λ) and 
p = (p, σ + λ− 1) where λ is a root of X2 −X + 2 over Z/(p). 
Lemma 3.4.11. Suppose n0 is the smallest natural number such that νp(σ n0−1) > 0. 
Then n0 = Ordp(λ), hence n0|(p− 1). 
50
Proof. Suppose n0 = Ordp(λ). Since σ ≡ λ (mod p), n0 = Ordp(σ) as well. Since 
Z[σ]/p ∼= Z/(p) and σ ∈ Z, 
Ordp(σ) = Ordp(λ) = n0. 
Hence, n0|(p− 1). 
Lemma 3.4.12. Let n0 and p be as before. Then νp(σ n0 − 1) = νp(σ 
p−1 − 1). 
Proof. Suppose that νp(σ n0 − 1) = e. Then 
σn0 ≡ 1 (mod p e) but σn0 6≡ 1 (mod p 
e+1), 
i.e., 
σn0 = 1 + α · r where r ∈ p e but r /∈ p 
e+1. 
Let p− 1 = kn0. Then 
σp−1 = (σn0)k ≡ 1 + αk · r (mod p e+1). 
Since 1 ≤ k < p, αk · r /∈ pe+1. Hence, νp(σ p−1 − 1) = e. 
Theorem 3.4.13. Suppose that νp(σ n0 − 1) = e1 and νp(σ 
n0 − 1) = e2 with e1 ≥ e2. 
Then, for n = n0p en′ with p ∤ n′, 
Ep(F2n) ∼= Z/(pe+e1)× Z/(pe+e2). 
51
Proof. By Lemma 3.4.8, νp(σ n−1) = e+e1 and by Lemma 3.4.7, νp(σ 
n−1) = e+e2. 
Suppose σn − 1 = pe+e2 · w where p ∤ w. Then νp(w) = e1 − e2. By Lemma 3.4.2, we 
have 
Ep(F2n) ∼= Z/(pe+e1)× Z/(pe+e2). 
52
3.5 Tree Structure of g on E(F2n) 
Recall that Proposition 3.3.1 and Proposition 3.3.2 imply that the tree struc-
ture of the dynamics of g = σ + I on E(F2n) solely depends on the dynamics of g on 
E2(F2n). In this section, we study the dynamics of g on E2(F2n). From Section 3.4, 
we know that E(F2n) can be decomposed as 
E(F2n) = E2(F2n) + ⊕ 
l 6=2 
Ep(F2n) (3.6) 
where E2(F2n) ∼= Z/(2h2) for some h2 = ν2(#E(F2n)). Since g is p − invariant and 
gh2(P ) = O for any P ∈ E2(F2n) by Proposition 3.3.2, (3.6) is equivalent to 
E(F2n) = ker gh2 + Im gh2 . (3.7) 
Then Proposition 3.3.2 tells us that the dynamics of g on E2(F2n) is a complete binary 
tree with height h2. Thus we like to find out h2. 
Theorem 3.5.1. Suppose that K = F2m where m = 2r · m′ with m′ odd. Then 
h2 = r + 2. 
To prove this theorem, we need the following lemma. 
Lemma 3.5.2. Define a sequence α′ is of elements in F2 as follows: 
α1 = 0, α2 = 1, and αi = αi+1 + α−1 i+1 for all i ≥ 2. 
Then αi ∈ F22i−2 \ F22i−3 for all i ≥ 3. 
To prove this lemma, we need the following theorem. 
53
Theorem 3.5.3. [Menezes et al., 1992, Theorem 3.10.] Let q = 2k and let R(x) = ∑n 
i=0 cix i ∈ Fq[x] be irreducible over Fq of degree n. Then xnR(x+x−1) is irreducible 
over Fq if and only if Trq|2(c1/c0) 6= 0. 
Proof of Lemma. We will prove it by induction. Note that α1 = 0 and α2 = 1. Let 
Ri(x) = x + αi and R∗ i (x) = xRi(x + x−1) = x2 + αix + 1 for i ≥ 2. Since R2(x) = 
x+α2 = x+1 is irreducible over F2 and Tr2|2(1) = 1 6= 0, so is R∗ 2(x) = x2 +x+1 by 
Theorem 3.5.3. But, since R∗ 2(x) is a quadratic polynomial, R∗ 
2(x) is reducible over 
F22 , i.e., α3, a root of R∗ 2(x), is in F22 \ F2. Thus the claim is true for i = 3. Assume 
that the claim is true for 3 ≤ i ≤ n. Then 
Tr22n−2 |2(α 
−1 n ) = Tr22n−3 
|2 
( 
Tr22n−2 |22n−3 (α−1 
n ) ) 
= Tr22n−3 |2 
( 
Tr22n−2 |22n−3 (αn−1 + αn) 
) 
= Tr22n−3 |2 
( 
Tr22n−2 |22n−3 (αn−1) + Tr22n−2 
|22n−3 (αn) ) 
. 
By the induction hypothesis, αn−2 ∈ F22n−2 , i.e., Tr22n−2 |22n−3 (αn−1) = 0 and, by the 
definition of R∗ n(x), Tr22n−2 
|22n−3 (αn) = αn−1. Thus, by the induction hypothesis, 
Tr22n−2 |2(α 
−1 n ) = Tr22n−3 
|2(αn−1) 6= 0. 
Hence, by Theorem 3.5.3, R∗ n(x) is also irreducible over F22n−2 and αn+1, a root of R∗ 
n 
is in F22n−1 \ F22n−2 . This completes the proof. 
Proof of Theorem 3.5.1. Let Pi = (αi, βi) ∈ E(F2) for i ≥ 0 be any sequence of points 
such that 
P0 = O and g(Pi+1) = Pi for i ≥ 0. 
We want to see in which field Pi lies for i ≥ 0. It is easy to see that αi is as described 
54
in Lemma 3.5.2. Since g(Pi+1) = Pi, from (3.2), for all i ≥ 3, 
βi = α2 
i βi−1 + α4 i + α2 
i + 1 
α2 i + 1 
. (3.8) 
Note that, for i ≥ 1, βi’s roots of the polynomial y2 + αiy = α3 i + 1. Then one can 
check that P1 = (0, 1) and P2 = (1, 0) or (1, 1), i.e., P1 and P2 are in F2. Note that for 
i ≥ 3, that the largest subfield of F2m of the form F22i−2 is F22r . Then Lemma 3.5.2 
says αi ∈ F2m for 1 ≤ i ≤ r+2 and, for βi, it is obvious that βi ∈ F2m for 3 ≤ i ≤ r+1. 
Since αr+2, βr+1 ∈ F2m , from (3.8), βr+2 ∈ F2m too. Hence, the largest i such that 
Pi ∈ E(K) is r + 2, which implies h2 = r + 2. 
Consider the tree structure of g on E2(F2n) where n = 2s · n′ with n′ odd. 
Then, by Theorem 3.5.1, 
E2(F2n) ∼= Z/(2s+2). 
Hence, the dynamics of g on E2(F2n) is the complete binary tree of height s + 1 
attached to O which is the only fixed point under g. 
55
3.6 Cycle Structure of g on E(F2n) 
Recall, from Section 3.3, that for P ∈ E(F2n), the cycle length of P under g 
is the smallest natural number t such that 
(M t − I) 
 
  
P 
g(P ) 
 
  = 
 
  
O 
O 
 
  . (3.9) 
Suppose that h is such that Mh − I ≡ 0 (mod |P |). Then t = h satisfies (3.9). 
Depending on the structure of < g > ∩ < g(P ) >, the cycle length of P under g 
may be smaller than h. Thus the cycle length of P under g is determined by the 
behavior of M and the structure of < P > ∩ < g(P ) >. For the rest of the chapter, 
Clg(P ) denotes the cycle length of P under g. Note that Ep(F2n) is g− invariant for 
p|#E(F2n). So, we consider the following three cases: 
(a) P ∈ E7(F2n). 
(b) P ∈ Ep(F2n) with ( 
p 7 
) = −1. 
(c) P ∈ Ep(F2n) with ( 
p 7 
) = 1. 
3.6.1 Cycle Length of P ∈ E7(F2n) 
From Section 3.4.1, we know that E7(F2n) ∼= Z/(7e)×Z/(7e+1) for some e ≥ 0. 
The cycle length of P ∈ E7(F2n) depends on the subgroup structure of E7(F2n) and 
the order of P . To study the cycle lengths, we need to know the properties of M 
modulo 7e. 
Lemma 3.6.1. Ord7e(M) = 7e−1 · 21 for all e ≥ 1. 
56
Proof. We will prove it by induction. Note that Ord7(M) = 21 and 
M21 ≡ 
 
  
1 + 4 · 7 6 · 7 
2 · 7 1 + 3 · 7 
 
  (mod 72). 
Suppose that Ord7e(M) = t with 
M t ≡ 
 
  
1 + a11 · 7e a12 · 7e 
a21 · 7e 1 + a22 · 7e 
 
  (mod 7e+1) 
where a11, a12, a21, and a22 are not simultaneously 0 (mod 7), i.e., Ord7e+1(M) > t. 
Then 
( M t 
)7 ≡ 
 
  
(1 + a11 · 7e)7 a12 · 7e+1 
a21 · 7e+1 (1 + a22 · 7e)7 
 
  (mod 7e+2) 
≡ 
 
  
1 + a11 · 7e+1 a12 · 7e+1 
a21 · 7e+1 1 + a22 · 7e+1 
 
  (mod 7e+2) 
≡ 
 
  
1 0 
0 1 
 
  (mod 7e+1). 
We know that Ord7e+1(M) > t and Ord7e+1(M)|7t. Since 7 is a prime, Ord7e+1(M) = 7t, 
which completes the proof. 
Corollary 3.6.2. Let e ≥ 1. Suppose that Ord7e(M) = n. Then 
Mn ≡ 
 
  
1 + 4 · 7e 6 · 7e 
2 · 7e 1 + 3 · 7e 
 
  (mod 7e+1). 
Proof. It is trivial from the proof of Lemma 3.6.1. 
57
Lemma 3.6.3. Suppose that E7(F2n) ∼= Z/(7e) × Z/(7e+1) with e ≥ 1 and P ∈ E7 
with |P | = 7e′ where 1 ≤ e′ ≤ e. If < P > ∩ < g(P ) > is not trivial, then 
| < P > ∩ < g(P ) > | = 7 
Proof. Suppose < P > ∩ < g(P ) > is nontrivial. If | < P > | = 7, then it is 
trivial that | < P > ∩ < g(P ) > | = 7. For the rest of the proof, we assume that 
| < P > | > 7, i.e., e′ ≥ 2. Since < P > ∩ < g(P ) > is nontrivial and both < P > 
and < g(P ) > are cyclic, there exist nonzero integers u and v such that 
uP = vg(P ) 
where 
< P > ∩ < g(P ) > = < uP > = < vg(P ) > . 
Then, from the minimum polynomial of g, 
ug(P ) = vg2(P ) = vg(P )− 2vP, 
i.e., 
2vP = (v − u)g(P ). 
This implies that there exists k 6= 0 such that 
ku ≡ 2v (mod 7e′), 
kv ≡ v − u (mod 7e′). 
58
Eliminating u from the above equations, we get 
v(k2 − k + 2) ≡ 0 (mod 7e′). (3.10) 
Since k2− k + 2 = (k− 4)2 + 7(k− 2), we see that k2− k + 2 is not divisible by 72 for 
any k. Since e′ ≥ 2 and k2− k + 2 6≡ 0 (mod 72), (3.10) implies that 7e′−1|v. Hence, 
vg(P ) has order at most 7. This implies that 
| < P > ∩ < g(P ) > | = 7. 
Note that for vg(P ) to have order 7, we must have 
k2 − k + 2 ≡ 0 (mod 7), 
i.e., k ≡ 4 (mod 7). If e′ = 1, then | < P > ∩ < g(P ) > | = 7 implies that 
< P >=< g(P ) >. Moreover, 4u = 2v, i.e., g(P ) = 4P . 
Note that in the above proof, for vg(P ) to have order 7, we must have 
k2 − k + 2 ≡ 0 (mod 7), 
i.e., k ≡ 4 (mod 7). Especially if e′ = 1, then | < P > ∩ < g(P ) > | = 7 implies that 
< P >=< g(P ) > and g(P ) = 4P . 
Theorem 3.6.4. Suppose that P ∈ E7(F2n) with |P | = 7. Then 
Clg(P ) = 
 
 
 
21 if | < P > ∩ < g(P ) > | = 1, 
3 if | < P > ∩ < g(P ) > | = 7. 
59
Proof. Suppose that | < P > ∩ < g(P ) > | = 1. Then, Clg(P ) = Ord7(M) = 21. 
Now suppose that | < P > ∩ < g(P ) > | = 7. This implies that < P >=< g(P ) > 
and from the proof of Lemma 3.6.3, we know g(P ) = 4·P . Hence, Clg(P ) = Ord7(4) = 
3. 
Theorem 3.6.5. Suppose that E7(F2n) ∼= Z/(7e) × Z/(7e+1) with e ≥ 2 and P ∈ 
E7(F2n) with |P | = 7e′ where e′ ≥ 2. Then 
Clg(P ) = 
 
 
 
Ord7e′ (M) if | < P > ∩ < g(P ) > | = 1, 
Ord7e′−1(M) if | < P > ∩ < g(P ) > | = 7. 
Proof. Suppose | < P > ∩ < g(P ) > | = 1. Then, from (3.4), 
( M t − I 
) 
 
  
P 
g(P ) 
 
  = 
 
  
O 
O 
 
  
if and only if 
M t ≡ I (mod 7e′). 
Now suppose that | < P > ∩ < g(P ) > | = 7. Then, from the proof of Lemma 3.6.3, 
g(7e′−1P ) = 4 · 7e′−1P. 
Let t be the multiplicative order of M modulo 7e′−1. Then we know that, from the 
proof of Corollary 3.6.2, 
(M t − I) ≡ 
 
  
4 · 7e′−1 6 · 7e′−1 
2 · 7e′−1 3 · 7e′−1 
 
  (mod 7e′). 
60
Thus 
(M t − I) 
 
  
P 
g(P ) 
 
  = 
 
  
4 · 7e′−1P + 6 · 7e′−1g(P ) 
2 · 7e′−1P + 3 · 7e′−1g(P ) 
 
  
= 
 
  
4 · 7e′−1P + 3 · 7e′−1P 
2 · 7e′−1P + 5 · 7e′−1P 
 
  
= 
 
  
O 
O 
 
  . 
Since t is the smallest such that M t ≡ I (mod 7e′−1), Clg(P ) = t. 
Thus Theorem 3.6.4 and Theorem 3.6.5 explain the cycle length of P under g 
for P ∈ E7(F2n). 
From Section 3.4.1, we know that E7(F2n) ∼= Z/(7e)×Z/(7e+1) for some e ≥ 0. 
Thus there exist P1 and P2 in E7(F2n) such that 
E7(F2n) =< P1, P2 > 
with |P1| = 7e and |P2| = 7e+1. For the following cases, we can determine the structure 
of < P > ∩ < g(P ) > explicitly. 
Lemma 3.6.6. Suppose E7(F2n) is as above and P = βP2 with |P | = 7c where 
1 ≤ c ≤ e + 1. Then 
| < P > ∩ < g(P ) > | = 7. 
61
Proof. From the proof of Lemma 3.6.3, it suffices to show that < 7c−1P >=< 
7c−1g(P ) >. Since |P | = 7c, P = β17 e+1−cP2 with 7 ∤ β1. Then 
< 7c−1P >=< 7c−1β17 e+1−cP2 >=< 7eP2 > . 
Suppose that 
g(P1) = a11P1 + a12P2, 
g(P2) = a21P1 + a22P2. 
Since g is an isomorphism on E7(F2n), 7|a12 and 7 ∤ a22. Thus 
< 7c−1g(P ) >=< g(7c−1P ) >=< g(7eP2) >=< a227 eP2 >=< 7eP2 > . 
Hence, < 7c−1P >=< 7c−1g(P ) >, i.e., | < P > ∩ < g(P ) > | = 7. 
Lemma 3.6.7. Suppose E7(F2n) is as above and P = αP1 + βP2 with ν7(α) = ν7(β). 
Then 
| < P > ∩ < g(P ) > | = 7. 
Proof. Suppose |P | = 7c with 1 ≤ c ≤ e. Then 
P = αP1 + βP2 = α17 e+1−cP1 + β17 
e+1−cP2. 
Similar to the proof of Lemma 3.6.6, 
< 7c−1P >=< 7c−1(α17 e+1−cP1 + β17 
e+1−cP2) >=< β17 eP2 >=< 7eP2 > 
62
and 
< 7c−1g(P ) >=< g(β17 eP2) >=< 7eP2 > . 
Hence, < 7c−1P >=< 7c−1g(P ) >, i.e., | < P > ∩ < g(P ) > | = 7. 
For other cases, we have the following conjecture: 
Conjecture 3.6.8. Suppose E7(F2n) is as above and P = αP1 + βP2 with α 6≡ 0 
(mod 7e) and ν7(α) 6= ν7(β). Then 
< P > ∩ < g(P ) >= {O}. 
3.6.2 Cycle Length of P ∈ Ep(F2n) with ( 
p 
7 
) = −1 
In Section 3.4.2, we have seen that Ep(F2n) ∼= Z/(pe) × Z/(pe) for a rational 
odd prime p such that ( 
p 7 
) = −1. Since 
( −7 p 
) 
= ( 
p 7 
) = −1, k2 − k + 2 is irreducible 
over Z/(pe) for any e ≥ 1. So, for any P ∈ Ep(F2n), 
< P > ∩ < g(P ) >= {O}. 
This tells us that the cycle length of P ∈ Ep(F2n) with |P | = pe solely depends on 
Ordpe(M). 
Theorem 3.6.9. Suppose that p is a rational prime with ( 
p 7 
) = −1 and P ∈ Ep(F2n) 
with |P | = pe for some e ≥ 1. Then Clg(P ) = Ordpe(M). 
Proof. Since < P > ∩ < g(P ) >= {O} and |g(P )| = |P | = pe, we have 
(Mn − I) 
 
  
P 
g(P ) 
 
  = 
 
  
O 
O 
 
  
63
if and only if Mn − I ≡ 0 (mod pe). 
Lemma 3.6.10. Suppose ( 
p 7 
) = −1. Then 
Ordp(M) = (p + 1)Ordp(2), 
and for e ≥ 2, 
Ordpe(M) = pe′Ordp(M) 
where e′ = max(0, e− νp(M Ordp(M) − I)). 
Proof. Suppose that λ1 and λ2 are roots of mg(T ). Then, since λi p+1 = 2 for i = 1, 2, 
Mp+1 ≡ 2I (mod p). 
So Ordp(M) = (p + 1)Ordp(2). 
Now suppose Ordp(M) = c and 
M c ≡ I (mod pe′) but M c 6≡ I (mod pe′+1). 
Then Ordpē(M) = Ordp(M) for 1 ≤ ē ≤ e′. Suppose that 
M c = I + pe′A where p ∤ A. 
Then, for any e > e′, 
(M c)pe′−e 
= (I + pe′A)pe−e′ 
≡ I + peA (mod pe+1) 
≡ I (mod pe) 
64
Moreover, since p is a prime and c is the order of M modulo p, c · pe−e′ is the order 
of M modulo pe. 
Note that the cycle length of a point in Ep(F2n) with ( 
p 7 
) = −1 is determined by 
the multiplicative order of M modulo the order of the point. Thus we can determine 
the exact distribution of cycle lengths according to the orders of points in Ep(F2n). 
Theorem 3.6.11. Suppose that Ep(F2n) ∼= Z/(pe) × Z/(pe) and P ∈ Ep(F2n) with 
|P | = pc where 1 ≤ c ≤ e. Then the number of cycles of length Ordpc(M) is 
p2c = p2c−2. 
Proof. It suffices to show that the number of points in Ep(F2n) of order pc is p2c = p2c−2. 
Since Ep(F2n) ∼= Z/(pe)×Z/(pe), the number of points in Ep(F2n) of order pc is equal 
to that of points in Z/(pe)×Z/(pe) of order pc. Suppose that (a, b) ∈ Z/(pe)×Z/(pe). 
Then (a, b) is of order pc if and only if (pc·a, pc·b) = (0, 0), but (pc−1·a, pc−1·b) 6= (0, 0). 
Hence, there are p2c − p2(c−1) points of order pc. 
3.6.3 Cycle Length of P ∈ Ep(F2n) with ( 
p 
7 
) = 1 
3.6.3.1 When Ep(F2n) ∼= Z/(pep) for some ep ≥ 1 
Since Ep(F2n) is cyclic, there exists Q ∈ Ep(F2n) such that Ep(F2n) =< Q >. 
Recall Ep(F2n) is g − invariant. Thus there exists u such that 
g(Q) = uQ. 
Moreover, u satisfies u2−u+2 ≡ 0 (mod pe). This implies that g is just a multiplica-
tive map on Ep(F2n). So the possible cycle lengths are Ordpc(u) where 1 ≤ c ≤ e. 
Hence, for each c with 1 ≤ c ≤ e, there are ϕ(pc) = (p− 1)pc−1 points of cycle length 
Ordpc(u). 
65
3.6.3.2 When Ep(F2n) ∼= Z/(pe)× Z/(pe) for some e ≥ 1 
Note that Ep(F2n) is a Z−module, so that there exists P1 and P2 in Ep(F2n) 
such that Ep =< P1, P2 > where|P1| = |P2| = pep . Suppose that 
g(P1) = a11P1 + a12P2 
g(P2) = a21P1 + a22P2, 
i.e., 
g 
 
  
P1 
Q1 
 
  = A 
 
  
P1 
Q1 
 
  
where A = ( 
a11 a12 a21 a22 
) ∈ (Z/(p2)) 
2×2 . 
Since g is an isomorphism on Ep(F2n), A is invertible modulo pe. For any 
P = aP1 + bP2 ∈ Ep(F2n), 
g(P ) = (a, b)g 
 
  
P1 
P2 
 
  = (a, b)A 
 
  
P1 
P2 
 
  . 
Thus, for all n ≥ 0, 
gn(P ) = (a, b)An 
 
  
P1 
P2 
 
  . 
Lemma 3.6.12. Suppose A 6= λI for any λ ∈ Z/(pep). Then, there exists a vector 
(a, b) ∈ Z/(pep)× Z/(pep) such that V is invertible modulo pep where 
V = 
 
  
(a, b) 
(a, b)A 
 
  , 
i.e., (a, b)A 6= µ(a, b) for any µ in Z/(pep). 
66
Proof. (a, b)A = µ(a, b) for some (a, b) and µ implies that µ is an eigenvalue and 
(a, b) is a corresponding eigenvector. Note that since mg(T ) dose not have repeated 
roots modulo any prime p 6= 7, A 6= λI. We start from Z/(p). Since the eigenvectors 
associated with distinct eigenvalues are linearly independent, the existence of such 
V modulo p is trivial. Then we can lift this to any power of p. This completes the 
proof. 
Corollary 3.6.13. A is similar to M modulo pe for any positive integer e. Moreover, 
there exists Q ∈ Ep(F2n) such that Ep(F2n) =< Q, g(Q) >. 
Proof. Directly from the relation between A and M . 
With such Q, any P ∈ Ep(F2n) can be expressed as a · Q + b · g(Q) for some 
a, b ∈ Z/(pe) and 
g(P ) = (a, b)M 
 
  
Q 
g(Q) 
 
  . 
So the cycle length of P ∈ Ep(F2n) depends on the order of P and the behavior of 
the matrix M modulo pe. Note that M is diagonalizable modulo pe, i.e., 
M ≡ U 
 
  
λ1 0 
0 λ2 
 
  U−1 (mod pep) ≡ U ·D · U−1 (mod pep) 
where U is invertible matrix modulo pe. This implies that the dynamics of g over 
Ep(F2n) is isomorphic to that of D over Z/(pe)× Z/(pe). Thus it suffices to consider 
the dynamics of D over Z/(pe)× Z/(pe). 
Theorem 3.6.14. Suppose that 
D = 
 
  
λ1 0 
0 λ2 
 
  
67
and P = (a, b) ∈ Z/(pe)× Z/(pe). Then 
ClD(P ) = lcm(Ordpe−νp(a)(λ1),Ordpe−νp(b)(λ2)). 
Proof. Note that ClD(P ) = t if and only if t is the smallest such that 
(a, b) ( Dt − I 
) ≡ (0, 0) (mod pe), 
i.e., 
a · (λt 1 − 1) ≡ 0 (mod pe) and b · (λt 
2 − 1) ≡ 0 (mod pe). (3.11) 
Suppose that νp(a) = ea and νp(b) = eb. Then (3.11) is true if and only if 
λt 1 − 1 ≡ 0 (mod pe−ea) and λt 
2 − 1 ≡ 0 (mod pe−eb). 
Thus t should be the multiple of the order of λ1 modulo pe−ea and the order of λ2 
modulo pe−eb . Since t is the smallest such, 
ClD(P ) = lcm(Ordpe−νp(a)(λ1), Ordpe−νp(b)(λ2)). 
3.6.3.3 When Ep(F2n) ∼= Z/(pe1)× Z/(pe2) with e1 < e2 
In this case, for a point P ∈ Ep(F2n), the structure of < P > ∩ < g(P ) > can 
be arbitrary. We cannot obtain the exact Clg(P ) without finding the exact structure 
of < P > ∩ < g(P ) >. But, from (3.9), we know Clg(P ) should divide Ordpep (M). 
Hence, Clg(P ) is bounded by Ordpep (M). 
68
3.7 Dynamics of x 7→ x + x−1 on F2n ∪ {∞} 
So far we have studied the dynamics of g on E(F2n). Using this information, 
we now study the dynamics of f on F2n ∪ {∞} in this section. For each x ∈ F2n , 
there are two points (x, y) ∈ E(F22n). The values of y are in F22n . Let the subset S 
of E(F22n) be 
S = {P = (x, y) ∈ E(F22n) : x ∈ F2n} ∪ {O}. 
Suppose |P | = 2c2p cp1 1 · · · pcpm 
m where pi’s are odd primes for 1 ≤ i ≤ m. Then, P can 
be written as 
P = P2 + Pp1 + Pp2 + . . . + Ppm 
where P2 ∈ E2(F22n) and Ppi ∈ Epi 
(F22n) for 1 ≤ i ≤ m. As we have seen in Sec-
tion 3.6, we can determine Clg(Ppi ) for 1 ≤ i ≤ m. Then the tail length of P is c2 and 
P is attached to a cycle whose cycle length is lcm(Clg(Pp1), Clg(Pp2), . . . , Clg(Ppm )). 
For the lengths of cycles in the dynamics of f on F2n ∪ {∞}, we have the following 
theorem: 
Theorem 3.7.1. Suppose P = (x, y) ∈ S with Clg(P ) = m. Then 
Clf (x) = 
 
 
 
m if m is odd, 
m 2 
if m is even. 
Proof. Note that π(P ) = π(Q) for P,Q ∈ E(F22n) if and only of Q = −P . Thus 
Clf (x) < Clg(P ) if and only if P satisfies gm′ 
(P ) = −P for some 1 ≤ m′ < m. 
Suppose that m is odd and there exists m′ such that gm′ 
(P ) = −P . Then, since g is 
69
an endomorphism over E(F22n), Clg(−P ) = m. It implies that 
g2m′ 
(P ) = gm′ 
(−P ) = −gm′ 
(P ) = P, 
which is contradiction to that m is odd. Thus, if m is odd, then Clg(P ) = Clf (x). 
Suppose that m is even. Note that since for P ∈ E(F22n), g2(P ) = P implies 
that P ∈ E2(F22n), there is no cycle of length 2 in the dynamics of g on E(F22n). 
Thus m ≡ 0 (mod 4). Note 
(gm − I)(P ) = (g2m′ − I)(P ) = (gm′ − I) · (gm′ 
+ I)(P ) = O. 
Since (gm′ − I)(P ) 6= O, (gm′ 
+ I)(P ) = O, i.e., gm′ 
(P ) = −P . Hence, 
Clf (x) = m′ = m 
2 . 
Note that ker g2 \ ker g = {(1, 0), (1, 1)}. Then the points in S have the fol-
lowing properties. 
Lemma 3.7.2. Suppose (x, y) ∈ S\E(F2n) and P = (1, 0)+(x, y). Then π(P ) /∈ F2n, 
but π(g(P )) ∈ F2n. 
Proof. From the addition formula, 
π(P ) = 
( y 
1 + x 
)2 
+ y 
1 + x + 1 + x. 
70
Since P ∈ E, 
π(P ) = x3 + xy + 1 
1 + x2 + 
y 
1 + x + 1 + x 
= x3 + y + 1 
1 + x2 + 1 + x. (3.12) 
Since π(P ) ∈ F2n if an only if (π(P ))2n 
= π(P ), . From (3.12), we can see that this 
is true if and only if 
y2n+1 
+ y2n 
= y2 + y, 
i.e., 
y2n 
= y. 
Since y ∈ F22n \ F2n , this is not possible. Thus π(P ) ∈ F22n \ F2n . Now apply g to P . 
Then 
g(P ) = g((1, 0)) + g((x, y)) 
= (0, 1) + (x + x−1, y′) 
where y′ = x2 + y + 1 + y+1 x2 . So, 
π(g(P )) = (y′ + 1)2 
(x + x−1)2 + 
y′ + 1 
x + x−1 + x + x−1 
= 1 
(x + x−1)2 
( 
y′2 + 1 + (y′ + 1)(x + x−1) + (x + x−1)3 ) 
= 1 
(x + x−1)2 
( (x + x−1)3 + (x + x−1)y′ + (y′ + 1)(x + x−1) + (x + x−1)3 
) 
= 1 
(x + x−1)2 
( x + x−1 
) 
= 1 
x + x−1 . 
71
Hence π(g(P )) ∈ F2n . 
Lemma 3.7.3. Suppose (x, y) ∈ S\E(F2n) and P = (1, 1)+(x, y). Then π(P ) /∈ F2n, 
but π(g(P )) ∈ F2n. 
Proof. The same argument with the previous lemma will work. 
Lemma 3.7.4. For any P ∈ E(F22n) \ E2(F22n), 
π((1, 0) + P ) 6= π((1, 1) + P ). 
Proof. Let P = (x, y). Then 
π((1, 0) + (x, y)) = y2 
1 + x2 + 
y 
1 + x + 1 + x (3.13) 
and 
π((1, 1) + (x, y)) = 1 + y2 
1 + x2 + 
1 + y 
1 + x + 1 + x. (3.14) 
Thus (3.13) = (3.14) if and only if x = 0, i.e., P = (0, 1) ∈ E2(F22n). This contradicts 
that P /∈ E2(F22n), which completes the proof. 
Lemma 3.7.5. Suppose P ∈ S \E(F2n) and P is periodic with the cycle length bigger 
than 1. Then, for any n ≥ 1, gn(P ) ∈ S \ E(F2n). 
Proof. It suffices to show g(P ) has the same property with P . Let P = (x, y) and 
g(P ) = (u, v). Then, u = x + x−1. Since x ∈ F2n , so is u. From Section 3.2, 
v = x2 + y + 1 + y + 1 
x2 . 
72
Since v2n 
= x2 + y2n 
+ 1 + y2n +1 
x2 , v ∈ F2n if and only if 
( y2n 
+ y ) ( 
1 + 1 
x2 
) 
= 0. (3.15) 
Since y ∈ F22n \ F2n , (3.15) is true if and only if x = 1, i.e., g(P ) = (1, 0) ∈ E2(F22n). 
This contradicts that P is periodic, which completes the proof. 
Lemma 3.7.5 implies that periodic points in the same cycle have the same 
described property. Let n = 2s · n′ with 2 ∤ n′. Then, from Section 3.5, E2(F22n) ∼= 
Z/(2s+3) and any tree in the dynamics of g on E(F22n) is identical to the tree attached 
to O which is a complete binary tree of height s + 2. For our purpose, we view a 
single point as a tree of height 0. To study the tree structure of the dynamics of f 
on F2n ∪ {∞}, we consider these cases separately: 
1. Structure of the tree attached to ∞. 
2. Structure of trees projected down from trees attached to periodic points which 
are in E(F2n). 
3. Structure of trees projected down from trees attached to periodic points which 
are in S \ E(F2n). 
Theorem 3.7.6. Suppose that n = 2s · n′ where 2 ∤ n′. Then the tree structure 
attached to ∞ is as follows: a complete binary tree of height s is attached to 0 and 0 
is attached to ∞. 
Proof. By the definition of f , ker f = {∞, 0} and 0 maps to∞ which is the only fixed 
point of f . Then, by Theorem 3.5.1, E2(F22n) ∼= Z/(2s+3). Thus the dynamics of g 
on E(F22n) is a complete binary tree of height s + 2, which is attached to O. From 
the proof of Theorem 3.5.1, we know that for P ∈ E2(F22n), P ∈ S if and only if 
73
P ∈ ker gs+2. Note that (1, 0), (1, 1) ∈ ker g2 \ ker g and g((1, 0)) = g((1, 1)) = (0, 1). 
Thus two complete binary trees of height s are attached to (0, 1). Since π(1, 0) = 
π(1, 1) = 1, those two trees of height s will be projected by π to one binary tree of 
height s which is attached to 0 in the dynamics of f on F2n ∪ {∞}. 
Lemma 3.7.7. Suppose that n is defined as in Theorem 3.7.6. Then structure of a 
tree projected from a tree attached to a periodic point in S \E(F2n) is a tree of height 
0. 
Proof. Suppose that P ∈ S \ E(F2n) and P is periodic. Then, by Lemma 3.7.2 and 
Lemma 3.7.3, 
π((1, 0) + P ), π((1, 0) + P ) /∈ F2n , 
but 
π(g((1, 0) + P )), π(g((1, 0) + P )) ∈ F2n . 
This implies that for any point Q ∈ E(F22n) such that gm(Q) = (1, 0)+P or (1, 1)+P 
for some m ≥ 1, Q /∈ S. Note that g((1, 0) + P ) = g((1, 1) + P ) = (0, 1) + g(P ), 
whose tail length is 1. Hence, the projected tree is of height 0. 
Lemma 3.7.8. Suppose that P ∈ E(F2n) and Q ∈ E2(F22n)\E2(F2n). Then P +Q /∈ 
S, i.e., x-coordinate of P + Q is not in F2n. 
Proof. Let P +Q = (x, y) and g(P )+g(Q) = (u, v). Suppose that P +Q ∈ S, i.e., x ∈ 
F2n . Since Q ∈ E2(F22n) \ E2(F2n), then g(Q) ∈ E2(F2n) ⊆ E(F2n) by Lemma 3.5.2 
and Theorem 3.5.1. Since P is E(F2n), so is g(P ). Thus g(P ) + g(Q) ∈ E(F2n). 
From 3.2, y is in a field containing both x and v, i.e., y ∈ F2n . This implies that 
P + Q ∈ E(F2n), but since Q ∈ E2(F22n) \ E2(F2n), P + Q /∈ E(F2n), which is a 
contradiction. This completes the proof. 
74
Lemma 3.7.9. Suppose that n is defined as in Theorem 3.7.6. Then structure of a 
tree projected from a tree in the dynamics of g on E(F22n) attached to a periodic point 
which is in E(F2n) is a complete binary tree of height s + 1. 
Proof. Suppose P ∈ E(F2n) is a periodic point under g. From the decomposition of 
E(F22n) in 3.7, for any point Q in a tree in the dynamics of g on E(F22n) attached to 
P , Q can be written as 
Q = Q2 + Qc 
where Q2 ∈ E2(F22n) and Qc ∈ E(F2n) is periodic with cycle length bigger than one. 
Then, by Lemma 3.7.8, π(Q)F2n if and only if Q2 ∈ ker gs+2. This implies that the 
height of the projected tree by π to F2n ∪ {∞} is one less than that of the tree in 
E(F22n). Hence, the structure of a tree projected from a tree in the dynamics of g on 
E(F22n) attached to a periodic point which is in E(F2n) is a complete binary tree of 
s + 1. 
Suppose that x is periodic of cycle length bigger than 1 in the dynamics of f 
on F2n ∪ {∞}. Since g is 2 − cover of f , the point above x is also periodic. Since 
O is the only fixed point of g and there is no cycle of length 2 in the dynamics of g 
on F22n , with Lemma 3.7.7 and Lemma 3.7.9, we have the following theorem which 
explains the structures of trees attached to cycles of length bigger than one. 
Theorem 3.7.10. In the dynamics of f on F2n ∪ {∞}, structures of trees attached 
to a cycle of length bigger than 1 are identical and they are complete trees of height 
either 0 or s + 1. 
Suppose that we want to study the dynamics of f on F25 ∪ {∞}. Then we 
study that of g on E(F210) and project it to F25 ∪ {∞}. Figure 3.4 shows how we 
project the dynamics of g on E(F22n) to that of f on E(F2n). Notice that in the 
75
dynamics of g on E(F210), points painted in blue are points whose x−coordinates 
are not in F25 and T represents a binary tree of height 2. Since 5 = 5 · 20, trees in 
the dynamics of g on E(F210) are of height 2. Thus trees in the dynamics of f on 
F25 ∪{∞} are height of either 0 or 1. We also see that two components are projected 
to one component, cycles of length 5 are projected to a cycle of the same length, and 
a cycle of length 10 is projected to a cycle of length 5. These are consistent with our 
results. 
o o o o o 
o o o o o 
TT T 
TT TT T 
T T 
o 
o 
o o 
o 
o 
o 
o 
o 
o 
o 
o 
oo 
o o o o o 
o o o o o 
TT TT T 
TT T T Too oo 
o 
o 
o 
o 
o 
T 
T 
T 
T 
T o 
o 
o 
o 
o 
T 
T 
T 
T 
T 
o 
o 
o 
o o 
o 
o 
o 
o 
o 
o 
o 
o 
oo 
o 
o 
o 
oo 
o 
o 
o 
T= 
Figure 3.4: Dynamics of g on E(F210) and that of f(x) = x + x−1 on F25 ∪ {∞}. 
76
Chapter 4 
Permutation Maps over Finite 
Fields 
4.1 Introduction 
A map over a finite field is called a permutation map if it is bijective. Due to 
the fact that every map over a finite field can be expressed by a polynomial, it was 
natural to focus on maps defined by polynomials. Since Hermite [1863] investigated 
permutation polynomials over finite prime fields and Dickson [1897] studied them 
over general finite fields, numerous mathematicians and engineers have shown their 
interests in permutation polynomials due not only to their mathematical importance 
but also to their applications in diverse areas such as coding theory, combinatorics, 
and cryptography. For more background material on permutation polynomials, we 
refer the readers to Chapter 7 of [Lidl and Niederreiter, 1997] and, for a detailed 
survey and some open problems, to [Lidl and Mullen, 1988, 1993]. 
Two well-known classes of permutation polynomials are monomials xk over Fq 
with k ≥ 1 and gcd(k, q−1) = 1 and Dickson’s polynomials over Fq with degrees rela-
77
tively prime to q2−1. Binomial polynomials of certain forms have been studied by sev-
eral scholars; see [Akbary and Wang, 2006], [Masuda et al., 2006], [Masuda and Zieve, 
2007, 2009], [Turnwald, 1998], and [Wang, 2002]. For permutation polynomials in 
more general forms, see [Akbary and Wang, 2005], [Park and Lee, 1998], and [Wan and Lidl, 
1991]. 
In this chapter, we take a different approach. Applying finite covering, we 
construct a new family of permutation maps from known one. Here we introduce a 
new class of permutation maps over finite fields defined by rational functions that are 
not equivalent to any known classes of permutation polynomials. 
Throughout the chapter Fq denotes a finite field with q elements, q is a power 
of an odd prime p, i denotes √ −1 as an element of Fq2 , and α is a nonzero element 
of Fq. We introduce the following rational map over Fq: for any k ≥ 1, 
ck(x, α) = ak(x, α) 
bk(x, α) 
where 
ak(x, α) = 
⌊ k 2 ⌋ 
∑ 
j=0 
( k 
2j 
) 
(−1)jα2j+1xk−2j, bk(x, α) = 
⌊ k 2 ⌋ 
∑ 
j=0 
( k 
2j + 1 
) 
(−1)jα2j+1xk−2j−1. 
Theorem 4.1.1. The rational map ck(x, α) is a permutation map on Fq if and only 
if  
 
 
gcd(k, q − 1) = 1 for q ≡ 1 (mod 4), 
gcd(k, q + 1) = 1 for q ≡ 3 (mod 4). 
The proof of Theorem 4.1.1 is presented in the next section. 
78
4.2 Proof 
We need some simple properties before presenting the proof. 
Lemma 4.2.1. Suppose α ∈ Fq with α 6= 0. Then For any x ∈ Fq with x 6= αi and 
y = x+αi x−αi 
, we have  
 
 
yq−1 = 1 for q ≡ 1 (mod 4), 
yq+1 = 1 for q ≡ 3 (mod 4). 
Proof. Since α, x ∈ Fq, 
yq = (x + αi)q 
(x− αi)q = 
x + αiq 
x− αiq . 
Note that iq = (−1) q−1 2 i. Thus 
yq = x + αiq 
x− αiq = 
 
 
 
x+αi x−αi 
= y for q ≡ 1 (mod 4), 
x−αi x+αi 
= 1/y for q ≡ 3 (mod 4). 
Hence, the proposition follows. 
We rewrite the expressions for ak(x, α) and bk(x, α) as follows: 
ak(x, α) = 
⌊ k 2 ⌋ 
∑ 
j=0 
( k 
2j 
) 
(−1)jα2j+1xk−2j = α 
2 
( (x + αi)k + (x− αi)k 
) , (4.1) 
and 
bk(x, α) = 
⌊ k 2 ⌋ 
∑ 
j=0 
( k 
2j + 1 
) 
(−1)jα2j+1xk−2j−1 = − i 
2 
( (x + αi)k − (x− αi)k 
) . (4.2) 
79
For x 6= αi, let y = x+αi x−αi 
. Then y 6= 1 and, for any k ≥ 1, we have 
ck(x, α) = 
 
 
 
αi · yk+1 yk−1 
for x 6= αi, 
αi for x = αi. 
Thus we have the following commutative diagram: 
y  // 
π 
 
yk 
π 
 
αi · y+1 y−1 
 
ck(·,α) // αi · yk+1 
yk−1 
Notice that since ck(x, α) is a rational map, ck(x, α) is not defined for x ∈ Fq such 
that bk(x, α) = 0. Thus, for ck(x, α) to be a permutation map, we need the following 
lemmas. 
Lemma 4.2.2. Suppose q ≡ 1 (mod 4). Then bk(x, α) has no roots in Fq if and only 
if gcd(k, q − 1) = 1. 
Proof. In this case, αi ∈ Fq. From (4.2), it is easy to see that ±αi is not the root 
of bk(x, α) for any k ≥ 1. It suffices to consider β ∈ Fq with β 6= ±αi. Notice that 
bk(β, α) 6= 0 if and only if ( 
β+αi β−αi 
)k 
6= 1. 
Suppose gcd(k, q − 1) = 1. Then the only solution to Xk = 1 over Fq is 1. 
Since y = β+αi β−αi 
6= 1 and is in Fq, we see that ( 
β+αi β−αi 
)k 
6= 1. Thus bk(x, α) has no roots 
in Fq. 
Now suppose that gcd(k, q − 1) = d > 1. Then there is an element γ ∈ Fq, 
γ 6= 1, such that γk = 1. Let β = αi · γ+1 γ−1 ∈ Fq. Then γ = β+αi 
β−αi , so 
( β+αi β−αi 
)k 
= γk = 1, 
i.e., bk(β, α) = 0. This completes the proof. 
80
Lemma 4.2.3. Suppose q ≡ 3 (mod 4). Then bk(x, α) has no roots in Fq if and only 
if gcd(k, q + 1) = 1. 
Proof. The proof will be similar to the proof of Lemma 4.2.2. Suppose that gcd(k, q+ 
1) = 1. For any β ∈ Fq, let λβ = β+αi β−αi 
6= 1. Then, since i ∈ Fq2 \ Fq, λβ ∈ Fq2 \ Fq. 
Then, by Proposition 4.2.1, λq+1 β = 1. Since gcd(k, q+1) = 1, we have λk 
β 6= 1. Hence, 
bk(x, α) has no roots in Fq. 
Now suppose that gcd(k, q +1) = d > 1. Then Xq+1− 1 has a root in Fq2 that 
is different from 1, say λ. Then one can check that β = αi · γ+1 γ−1 ∈ Fq and is a root of 
bk(x, α). This completes the proof. 
Lemma 4.2.2 and Lemma 4.2.3 give us the exact condition for the domain of 
ck(x, α) to be entire Fq and notice that this condition is identical to the condition for 
Theorem 4.1.1. Now we prove the main theorem. 
Proof of Theorem 4.1.1. For any x ∈ Fq, let y = x+αi x−αi 
as above. Notice that i ∈ Fq 
only for q ≡ 1 (mod 4), and ck(x, α) = αi if and only if x = αi. We may assume that 
x 6= αi. We have 
ck(x, α) = αi · y k + 1 
yk − 1 . 
Suppose q ≡ 1 (mod 4). Then i ∈ Fq and so y ∈ Fq. Note that the map 
y = x+αi x−αi 
defines a bijection from Fq \ {i} to Fq \ {1}. Also, the map yk defines a 
permutation on the subset Fq \ {1} if and only if gcd(k, q− 1) = 1. Hence, ck(x, α) is 
a permutation on Fq if and only if gcd(k, q − 1) = 1. 
Now suppose q ≡ 3 (mod 4). Let G be the multiplicative subgroup of Fq2 of 
order q + 1. By Lemma 4.2.1, y ∈ G \ {1}. In fact, the map y = x+αi x−αi 
defines a 
bijection from Fq to G \ {1}. Note that the map yk defines a permutation on G \ {1} 
if and only if gcd(k, q + 1) = 1. It follows that ck(x, α) defines a permutation on Fq 
81
if and only if gcd(k, q + 1) = 1. This completes the proof. 
82
Chapter 5 
Conclusions 
Chapter 2 has focused on monomial dynamics over finite fields. We have 
shown that counting the number of fixed points of boolean monomial dynamics is a 
#P − complete problem and investigating cycle structure can be reduced to studying 
fixed point structure. We also have examined monomial dynamics over general finite 
fields and seen that investigating it is equivalent to solving linear systems modulo 
prime power. For the monomial dynamics with more than one component, which 
have not been covered in this thesis, there is still difficulty in studying cycle structure 
of such dynamics. 
In Chapter 3, we have presented a map f(x) = x+x−1 over F2n∪{∞} which is 
not linear nor a finite-quotient of an affine map, but whose dynamics can be explained 
with finite covering. We have analyzed the dynamics of f over F2n ∪ {∞} by lifting 
to that of an isogeny g = I + σ on a Koblitz curve E : y2 + xy = x3 + 1 over F22n 
whose dynamics is much simpler to understand. We have shown that g satisfies a 
linear recurrence relation and the dynamics of g on E(F22n) can be determined by 
the group decomposition of E(F22n) and the behavior of the linear recurrence relation 
over E(F22n). 
83
In Chapter 4, using finite covering, we have constructed a new class ck(x, α) of 
permutation maps over finite fields which has a weaker condition to be permutation 
than Dickson’s polynomials. Notice that ck(x, α) and the Dickson’s polynomial of 
degree k are projected down from the same map over the quadratic extension with 
different projection maps. 
As mentioned in the introduction, discrete dynamics over finite fields is a 
young area of mathematics. In this thesis, we have investigated some of interesting 
problems. But there are many interesting questions yet to be explored. It would be 
interesting to investigate the following questions: 
 What is “simple” dynamics ? How do we measure simplicity of discrete dynam-
ics ? 
 When can a dynamics be covered by a simple dynamics ? 
 How do we study dynamics defined by morphism in higher dimensional algebraic 
varieties ? 
 How does the algebraic structure of the set affect the dynamics ? 
 What other algebraic techniques can be used to study dynamics ? 
We believe that answering these questions will contribute greatly to discrete 
dynamics. Since there are numerous applications of discrete dynamics such as reverse-
engineering problems [Laubenbacher and Stigler, 2004], modeling of gene regulatory 
networks [Albert and Othmer, 2003; Celada and Seiden, 1992], and building secure 
cryptosystems [Habutsu et al., 1991], exploring the above questions will provide in-
teresting and challenging research directions as well. 
84
Bibliography 
Akbary, A. and Wang, Q. (2005). On some permutation polynomials over finite fields. International Journal of Mathematics and Mathematical Sciences, 2005:2631–2640. 
Akbary, A. and Wang, Q. (2006). A generalized lucas sequence and permutation binomials. Proceedings of the American Mathematical Society, 134:15–22. 
Albert, R. and Othmer, H. (2003). The topology of the regulatory interactions predicts the expression patterns of the segment polarity genes in drosophila melanogaster. Journal of Theoretical Biology, 223:1–18. 
Celada, F. and Seiden, P. (1992). A computer model of cellular interactions in the immune system. Immunology today, 13(2). 
Colón-Reyes, O., JarrahR., A., Laubenbacher, R., and Sturmfels, B. (2006). Mono-mial dynamical systems over finite fields. ArXiv Mathematics e-prints. 
Colón-Reyes, O., Laubenbacher, R., and Pareigis, B. (2004). Boolean monomial dynamical systems. Annals of Combinatorics, 8. 
Devaney, R. (2003). An Introduction to Chaotic Dynamical System. Westview Press, second edition. 
Dickson, L. (1896-1897). The analytic representation of substitutions on a power of a prime number of letters with a discussion of the linear group. Annals of Mathematics, 11(1/6). 
Elspas, B. (1959). The theory of autonomous linear sequential networks. IRE Trans-actions on Circuit Theory, CT-6(1). 
Gilbert, C., Kolesar, J., Reiter, C., and Stroey, J. (2001). Function digraphs of quadratic maps modulo p. The Fibonacci Quarterly, 39. 
Habutsu, T., Nishio, Y., Sasase, I., and Mori, S. (1991). A secret key cryptosystem by iterating a chaotic map. Eurocrypt. 
Hermite, C. (1863). Sur les fonctions de sept lettres. Comptes Rendus des Sèances de l’Académie des Sciences, 57. 
85
Hernandez-Toledo, R. (2005). Linear finite dynamical systems. Communications in Algebra, 33. 
Hjorth, P. and Petersen, C. (2006). Dynamics on the Riemann Sphere: A Bodil Branner Festschrift. European Mathematical Society. 
Jarrah, A., Laubenbacher, R., and Veliz-Cuba, A. (2008). The dynamics of conjunc-tive and disjunctive boolean networks. arXiv:0805.0275v1. 
Jarrah, A., Laubenbacher, R., and Vera-Licona, P. (2006). An efficient algorithm for finding the phase space structure of liner finite dynamical systems. 
Knuth, D. and Ruskey, F. (2003). Efficient coroutine generation of constrained gray sequences. Lecture Notes in Computer Science, 2635. 
Koblitz, N. (1991). Cm-curves with good cryptographic properties. In Feigenbaum, J., editor, Advances in Cryptology - Proceedings of CRYPTO 1991, LNCS, volume 576, pages 279–287, London, UK. Springer-Verlag. 
Laubenbacher, R. and Stigler, B. (2004). A computational algebra approach to the reverse-engineering of gene regulatory networks. Journal of Theoretical Biology, 229. 
Lidl, R. and Mullen, G. (1988). When does a polynomial over a finite field permute the elements of the field? American Mathematical Monthly, 95. 
Lidl, R. and Mullen, G. (1993). When does a polynomial over a finite field permute the elements of the field? ii. American Mathematical Monthly, 100. 
Lidl, R. and Niederreiter, H. (1997). Finite Fields. Cambridge University Press, New York. 
Masuda, A., Panario, D., and Wang, Q. (2006). The number of permutation binomials over f̃4p+1 where p and 4p+1 are primes. Electronic Journal of Combinatorics, 13. 
Masuda, A. and Zieve, M. (2007). Nonexistence of permutation binomials of certain shapes. Electronic Journal of Combinatorics, 14. 
Masuda, A. and Zieve, M. (2009). Permutation binomials over finite fields. TRANS-ACTIONS OF THE AMERICAN MATHEMATICAL SOCIETY, 361(8). 
Menezes, A., Blake, I., Gao, S., Mullin, R., Vanstone, S., and Yaghoobiann, T. (1992). Applications of Finite Fields. Kluwer Academic Publishers. 
Milne, J. (2009). Algebraic number theory (v3.01). Available at www.jmilne.org/math/. 
86
Park, J. (2003). Algebraic properties of the digraph generated by the iteration of quadratic mapping x 7→ x2 − 2 (mod p). manuscript. 
Park, Y. and Lee, J. (1998). Permutation polynomials with exponents in an arithmetic progression. Bulletin of the Australian Mathematical Society, 57. 
Provan, J. and Ball, M. (1983). Complexity of counting cuts. Siam Journal of Computing, 12. 
Robinson, C. (1998). Dynamical Systems - Stability, Symbolic Dynamics, and Chaos. CRC. 
Rogers, T. (1996). The graph of the square mapping on the prime fields. Discrete Mathematics, 148. 
Rück, H. (1987). A note on elliptic curve over finite fields. Mathematics of Compu-tation, 179. 
Silverman, J. (1986). The Arithmetic of Elliptic Curves. Springer. 
Turnwald, G. (1998). Permutation polynomials of binomial type. Contributions to General Algebra, 6. 
Valiant, L. (1979). The complexity of computing the permanent. Theoretical Com-puter Science, 8. 
Vasiga, T. and Shallit, J. (2004). On the itereation of certain quadratic maps over gf(p). Discrete Mathematics, 277. 
Wan, D. and Lidl, R. (1991). Permutation polynomials of the form xrf(x(q−1)/d) and their group structure. Monatshefte für Mathematik, 112. 
Wang, L. (2002). On permutation polynomials. Finite Fields and Their Applications, 8. 
Weil, A. (1948). Courbes algébriques et variètès abéliennes. Sur les courbes algébriques et les varietés qui s’en deduisent. Hermann. 
Xua, G. and Zoub, Y. (2009). Linear dynamical systems over finite rings. Journal of Algebra, 321(8). 
Zieve, M. (1996). Cycles of Polynomial Mappings. PhD thesis, University of California at Berkeley. 
87