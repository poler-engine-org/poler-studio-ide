> Source: https://www.mdpi.com/1099-4300/23/5/616

Hidden Attractors in Discrete Dynamical Systems
Loading web-font Gyre-Pagella/Normal/Regular
Next Article in Journal
A Foreground-Aware Framework for Local Face Attribute Transfer
Next Article in Special Issue
Stabilization and Synchronization of a Complex Hidden Attractor Chaotic System by Backstepping Technique
Previous Article in Journal
Functional Interdependence in Coupled Dissipative Structures: Physical Foundations of Biological Coordination
Previous Article in Special Issue
A Caputo–Fabrizio Fractional-Order Model of HIV/AIDS with a Treatment Compartment: Sensitivity Analysis and Optimal Control Strategies
Journals
Active Journals Find a Journal Journal Proposal Proceedings Series
[
Topics
](https://www.mdpi.com/topics)
Information
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
Open Access Policy Institutional Open Access Program Special Issues Guidelines Editorial Process Research and Publication Ethics Article Processing Charges Awards Testimonials
[
Author Services
](https://www.mdpi.com/authors/english)
Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
About
Overview Contact Careers News Press Blog
Sign In / Sign Up
Notice
You can make submissions to other journals here.
clear
Notice
You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.
Continue Cancel
clear
All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to https://www.mdpi.com/openaccess.
Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.
Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.
Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.
Original Submission Date Received: .
You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled. 
clear zoom_out_map search menu 
Journals
Active Journals
Find a Journal
Journal Proposal
Proceedings Series
Topics
Information
For Authors
For Reviewers
For Editors
For Librarians
For Publishers
For Societies
For Conference Organizers
Open Access Policy
Institutional Open Access Program
Special Issues Guidelines
Editorial Process
Research and Publication Ethics
Article Processing Charges
Awards
Testimonials
Author Services
Initiatives
Sciforum
MDPI Books
Preprints.org
Scilit
SciProfiles
Encyclopedia
JAMS
Proceedings Series
About
Overview
Contact
Careers
News
Press
Blog
Sign In / Sign Up Submit
Search for Articles:
Title / Keyword
Author / Affiliation / Email
Journal
All Journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica (AMH)
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine (ARM)
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation (ASI)
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing (BDCC)
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C (Journal of Carbon Research)
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies (Clean Technol.)
Climate
Clinical and Translational Neuroscience (CTN)
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation (CMD)
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction (CMTR)
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology (CIMB)
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation (DHI)
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates (DDC)
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications (ESA)
Eng
Engineering Proceedings
Entropic and Disordered Matter (EDM)
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal (EBJ)
European Journal of Investigation in Health, Psychology and Education (EJIHPE)
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional (Fractal Fract)
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums (FCLAM)
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease (GUCDD)
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences (IJCS)
International Journal of Environmental Medicine (IJEM)
International Journal of Environmental Research and Public Health (IJERPH)
International Journal of Financial Studies (IJFS)
International Journal of Medical Devices (IJMD)
International Journal of Molecular Sciences (IJMS)
International Journal of Neonatal Screening (IJNS)
International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)
International Journal of Plant Biology (IJPB)
International Journal of Topology
International Journal of Translational Medicine (IJTM)
International Journal of Turbomachinery, Propulsion and Power (IJTPP)
International Medical Education (IME)
Inventions
IoT
ISPRS International Journal of Geo-Information (IJGI)
J
Journal of Aesthetic Medicine (J. Aesthetic Med.)
Journal of Ageing and Longevity (JAL)
Journal of CardioRenal Medicine (JCRM)
Journal of Cardiovascular Development and Disease (JCDD)
Journal of Clinical & Translational Ophthalmology (JCTO)
Journal of Clinical Medicine (JCM)
Journal of Composites Science (J. Compos. Sci.)
Journal of Cybersecurity and Privacy (JCP)
Journal of Dementia and Alzheimer's Disease (JDAD)
Journal of Developmental Biology (JDB)
Journal of Experimental and Theoretical Analyses (JETA)
Journal of Eye Movement Research (JEMR)
Journal of Functional Biomaterials (JFB)
Journal of Functional Morphology and Kinesiology (JFMK)
Journal of Fungi (JoF)
Journal of Genome Biotechnology and Genetics (JGBG)
Journal of Gerontology and Geriatrics (JGG)
Journal of Imaging (J. Imaging)
Journal of Innovation
Journal of Intelligence (J. Intell.)
Journal of Interdisciplinary Research Applied to Medicine (JDReAM)
Journal of Low Power Electronics and Applications (JLPEA)
Journal of Manufacturing and Materials Processing (JMMP)
Journal of Marine Science and Engineering (JMSE)
Journal of Market Access & Health Policy (JMAHP)
Journal of Mind and Medical Sciences (JMMS)
Journal of Molecular Pathology (JMP)
Journal of Nanotheranostics (JNT)
Journal of Nuclear Engineering (JNE)
Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)
Journal of Parks
Journal of Personalized Medicine (JPM)
Journal of Pharmaceutical and BioTech Industry (JPBI)
Journal of Phytomedicine
Journal of Respiration (JoR)
Journal of Risk and Financial Management (JRFM)
Journal of Sensor and Actuator Networks (JSAN)
Journal of Superintelligence
Journal of the American Podiatric Medical Association (JAPMA)
Journal of the Oman Medical Association (JOMA)
Journal of Theoretical and Applied Electronic Commerce Research (JTAER)
Journal of Vascular Diseases (JVD)
Journal of Xenobiotics (JoX)
Journal of Zoological and Botanical Gardens (JZBG)
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction (MAKE)
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications (MCA)
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols (MPs)
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction (MTI)
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA (ncRNA)
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care (PHC)
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science (QuBS)
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics (RSEE)
Religions
Remote Sensing
Reports
Reproductive Medicine (Reprod. Med.)
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine (RJPM)
Ruminants
Safety
Sci
Scientia Pharmaceutica (Sci. Pharm.)
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal (SIUJ)
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease (TropicalMed)
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal (WEVJ)
Youth
Zoonotic Diseases
Entropy
Article Type
All Article Types
Article
Review
Communication
Editorial
Abstract
Book Review
Brief Communication
Brief Report
Case Report
Clinicopathological Challenge
Comment
Commentary
Concept Paper
Conference Report
Correction
Creative
Data Descriptor
Discussion
Entry
Essay
Expression of Concern
Extended Abstract
Field Guide
Giants in Urology
Guidelines
Hypothesis
Interesting Images
Letter
New Book Received
Obituary
Opinion
Patent Summary
Perspective
Proceeding Paper
Project Report
Protocol
Registered Report
Reply
Retraction
Short Note
Study Protocol
Systematic Review
Technical Note
Tutorial
Urology around the World
Viewpoint
All Article Types Search
Advanced Search
Section
All Sections
Astrophysics, Cosmology, and Black Holes
Complexity
Entropy and Biology
Entropy Reviews
Information Theory, Probability and Statistics
Multidisciplinary Applications
Non-equilibrium Phenomena
Quantum Information
Signal and Data Analysis
Statistical Physics
Thermodynamics
Time
General
All Sections
Special Issue
All Special Issues
Advances in Applied Thermodynamics III
Advancing Privacy-Preserving Federated Learning: Innovative Frameworks and Protocols
An Informational Theoretical Approach to the Entropy of Liquids and Solutions
Applications of Fisher Information in Sciences
Applications of Information Theory in the Geosciences II
Applications of Nonlinear Diffusion Equations
Approximate, Sample and Multiscale Entropy
Big Data
Blockchain: Security, Challenges, and Opportunities
Causal Graphical Models and Their Applications, 2nd Edition
Challenges and Progresses in the Modelling of Entropy Generation in Fluid Mechanics, Heat Transfer and Porous Media
Complex and Fractional Dynamics
Complex Systems and Fractional Dynamics
Concepts of Entropy and Their Applications
Concepts of Entropy and Their Applications - Papers presented at the Meeting at University of Melbourne, 26 November - 11 December 2007
Condensed-Matter-Principia Based Information & Statistical Measures: From Classical to Quantum
Configurational Entropy
Cybersemiotics—Integration of the informational and semiotic paradigms of cognition and communication
Distance in Information and Statistical Physics Volume 2
Dynamical Equations and Causal Structures from Observations
Emergence in Chemical Systems
Emergence of Information in Evolutionary Processes
Emergent Quantum Mechanics – David Bohm Centennial Perspectives
Entropic and Non-Linear Aspects of Animal Behaviour
Entropic Applications in Economics and Finance
Entropic Aspects Arising from Geometric Descriptions of Physical Phenomena
Entropic Aspects of Nonlinear Partial Differential Equations: Classical and Quantum Mechanical Perspectives
Entropic Control of Soft Materials
Entropic Methods in Surface Science
Entropic Properties of Dynamical Systems
Entropic Uncertainty Relations and Their Applications
Entropies of Polymers
Entropies: Between Information Geometry and Kinetics
Entropy and Complexity of Data
Entropy and EZ-Water
Entropy and Friction Volume 2
Entropy and Information in the Foundation of Quantum Physics
Entropy and Information Inequalities
Entropy and Its Applications across Disciplines
Entropy and Scale-Dependence in Urban Modelling
Entropy and Space-Time Analysis in Environment and Health
Entropy and the Economy
Entropy and Urban Sprawl
Entropy Application in Tribology
Entropy Applications in Environmental and Water Engineering
Entropy Based Data Hiding
Entropy Based Inference and Optimization in Machine Learning
Entropy for Characterization of Uncertainty in Risk and Reliability
Entropy for Sustainable and Resilient Urban Future
Entropy Generation and Heat Transfer
Entropy Generation in Nanofluid Flows
Entropy Generation in Nanofluid Flows II
Entropy Generation in Thermal Systems and Processes
Entropy Generation in Thermal Systems and Processes 2015
Entropy Generation Minimization
Entropy Generation Minimization II
Entropy in Computational Fluid Dynamics
Entropy in Computational Fluid Dynamics II
Entropy in Dynamic Systems
Entropy in Experimental Design, Sensor Placement, Inquiry and Search
Entropy in Genetics and Computational Biology
Entropy in Hydrology
Entropy in Image Analysis
Entropy in Model Reduction
Entropy in Nanofluids
Entropy in Networked Control
Entropy in Shape Memory Alloys
Entropy Measures for Data Analysis: Theory, Algorithms and Applications
Entropy Methods in Guided Self-Organization
Entropy Production in Turbulent Flow
Entropy-Based Applied Cryptography and Enhanced Security for Ubiquitous Computing
Entropy-Based Fault Diagnosis
Entropy, Utility, and Logical Reasoning
Entropy: From Physics to Information Sciences and Geometry
Entropy: The Scientific Tool of the 21st Century
Evaluation of Systems' Irregularity and Complexity: Sample Entropy, Its Derivatives, and Their Applications across Scales and Disciplines
Facets of Entropy - Papers presented at the workshop in Copenhagen (24-26 October 2007)
Fluctuation Relations and Nonequilibrium Thermodynamics in Classical and Quantum Systems
Foundations of Quantum Mechanics
Gibbs Paradox 2018
Gibbs Paradox and Its Resolutions
High Entropy Alloys
High-Entropy Alloys and High-Entropy-Related Materials
High-Entropy Materials
Image Encryption and Privacy Protection Based on Chaotic Systems—Third Edition
Information and Entropy
Information and Self-Organization
Information Decomposition of Target Effects from Multi-Source Interactions
Information Geometry
Information Geometry III
Information Processing in Complex Systems
Information Theoretic Measures and Their Applications
Information Theory and Stochastics for Multiscale Nonlinear Systems
Information Theory for Data Communications and Processing
Information Transfer in Multilayer/Deep Architectures
Information-Processing and Embodied, Embedded, Enactive Cognition Part 1
Information-Processing and Embodied, Embedded, Enactive Cognition Part 2: Morphological Computing and Cognitive Agency
Information, Entropy and Their Geometric Structures
Intermittency and Self-Organisation in Turbulence and Statistical Mechanics
Joseph Fourier 250th Birthday: Modern Fourier Analysis and Fourier Heat Equation in Information Sciences for the XXIst century
Lie Group Machine Learning and Lie Group Structure Preserving Integrators
Long-Distance Quantum Communications
Loop Entropy
Machine Learning and Entropy: Discover Unknown Unknowns in Complex Data Sets
Machine Learning Meets Stochastic Processes: New Trends for Understanding Complex Systems
MaxEnt 2017 - The 37th International Workshop on Bayesian Inference and Maximum Entropy Methods in Science and Engineering
Maximum Entropy
Maximum Entropy and Bayes Theorem
Maximum Entropy and Bayesian Methods
Maximum Entropy and Its Application
Maximum Entropy and Its Application II
Maximum Entropy and Its Application III
Maximum Entropy Applied to Inductive Logic and Reasoning
Maximum Entropy Principle and Semiconductors
Maximum Entropy Production
Maximum versus Minimum Entropy Generation: Theoretical Developments and Applications
Maxwell's Demon 2013
Models of Consciousness
Molecular Dynamics Simulation
Multivariate Entropy Measures and Their Applications
New Advances in High-Entropy Alloys
New Developments in Statistical Information Theory Based on Entropy and Divergence Measures
Noise-Driven Dynamics in Far-from-Equilibrium Systems
Optimized Entropic Pathways
Permutation Entropy & Its Interdisciplinary Applications
Physical Information and the Physical Foundations of Computation
Probability Distributions and Maximum Entropy in Stochastic Chemical Reaction Networks
Quantum Criticality and Emergent Phases in Strongly Correlated and Frustrated Materials
Quantum Foundations: 90 Years of Uncertainty
Quantum Information and Communication: From Foundations to Applications
Quantum Limits to the Second Law of Thermodynamics
Quantum Mechanics: From Foundations to Information Technologies
Quantum Nonlocality
Random Walks and Stochastic Processes in Complex Systems: From Physics to Socio-Economic Phenomena, 2nd Edition
Residual Entropy and Nonequilibrium States
Selected Featured Papers from Entropy Editorial Board Members
Selected Papers from 14th Joint European Thermodynamics Conference
Selected Papers from 1st International Electronic Conference on Entropy and its Applications
Selected Papers from 2nd International Electronic Conference on Entropy and Its Applications
Selected Papers from 37th Annual Conference of Spanish Society of Biomedical Engineering
Selected Papers from 4th International Electronic Conference on Entropy and Its Applications
Selected Papers from IWOBI—Entropy-Based Applied Signal Processing
Selected Papers from MaxEnt 2016
Selected Papers from Symposium on Natural/Unconventional Computing and Its Philosophical Significance
Selected Papers from the International Conference on Innovative Applied Energy (IAPE'20)
Social Networks and Information Diffusion
Solar and Stellar Variability and Statistical Mechanics
Spatial Information Theory
Statistical Significance and the Logic of Hypothesis Testing
Symbolic Entropy Analysis and Its Applications
Symbolic Entropy Analysis and Its Applications II
Symmetry and Entropy
The 20th Anniversary of Entropy - Approximate and Sample Entropy
The 20th Anniversary of Entropy - Recent Advances in Entropy and Information-Theoretic Concepts and Their Applications
The Information Bottleneck Method
The Ubiquity of Entropy
Theoretical Developments and Applications of Entropy and Ordinal Patterns
Thermalization in Isolated Quantum Systems
Thermodynamics and Population Dynamics
Thermodynamics of Information Processing
Thermoeconomics for Energy Efficiency
Towards Ultimate Quantum Theory (UQT)
Transfer Entropy
Transfer Entropy II
Tsallis Entropy
Understanding Molecular Dynamics via Stochastic Processes
Wavelet Entropy: Computation and Applications
Wavelets, Fractals and Information Theory I
Wavelets, Fractals and Information Theory II
Wavelets, Fractals and Information Theory III
What Is Maximum Entropy Production and How Should We Apply It?
All Special Issues
Volume 23
Issue 5
Number
Page
Logical Operator Operator
AND
OR
Search Text
Search Type
All fields
Title
Abstract
Keywords
Authors
Affiliations
Doi
Full Text
References
add_circle_outline
remove_circle_outline Search
Journals
Entropy
Volume 23
Issue 5
10.3390/e23050616
Submit to this Journal Review for this Journal Propose a Special Issue
► ▼ Article Menu
Article Menu
Academic Editor Christos Volos
Recommended Articles
Related Info Links
PubMed/Medline
Google Scholar
More by Authors Links
on DOAJ
Berezowski, M.
Lawnik, M.
on Google Scholar
Berezowski, M.
Lawnik, M.
on PubMed
Berezowski, M.
Lawnik, M.
Article Views 3886
Citations 6
Table of Contents
Abstract
Introduction
Mathematical Foundations
Examples
Hidden Chaotic Attractors with Euler Integration Method
Summary
Author Contributions
Funding
Conflicts of Interest
References 
Altmetric share Share announcement Help format_quote Cite question_answer Discuss in SciProfiles
Need Help?
Support
Find support for a specific problem in the support section of our website.
Get Support
Feedback
Please let us know what you think of our products and services.
Give Feedback
Information
Visit our dedicated information section to learn more about MDPI.
Get Information
clear
JSmol Viewer
clear
first_page
Download PDF
settings
Order Article Reprints
Font Type:
Arial Georgia Verdana
Font Size:
Aa Aa Aa
Line Spacing:
  
Column Width:
  
Background:
Open Access Article
Hidden Attractors in Discrete Dynamical Systems
by
Marek Berezowski 
Marek Berezowski
SciProfiles Scilit Preprints.org Google Scholar 1,*  
and
Marcin Lawnik 
Marcin Lawnik
SciProfiles Scilit Preprints.org Google Scholar 2   1
Faculty of Chemical Engineering and Technology, Cracow University of Technology, ul. Warszawska 24, 30-155 Kraków, Poland 2
Department of Mathematics Applications and Methods for Artificial Intelligence, Silesian University of Technology, Kaszubska 23, 44-100 Gliwice, Poland *
Author to whom correspondence should be addressed.
Entropy 2021, 23(5), 616; https://doi.org/10.3390/e23050616
Submission received: 26 March 2021 / Revised: 13 May 2021 / Accepted: 14 May 2021 / Published: 16 May 2021
(This article belongs to the Special Issue Nonlinear Dynamics and Entropy of Complex Systems with Hidden and Self-Excited Attractors III)
Download keyboard_arrow_down
Download PDF
Download PDF with Cover
Download XML
Download Epub
Browse Figures      
Versions Notes
Article Views
Citations -
Abstract
Research using chaos theory allows for a better understanding of many phenomena modeled by means of dynamical systems. The appearance of chaos in a given process can lead to very negative effects, e.g., in the construction of bridges or in systems based on chemical reactors. This problem is important, especially when in a given dynamic process there are so-called hidden attractors. In the scientific literature, we can find many works that deal with this issue from both the theoretical and practical points of view. The vast majority of these works concern multidimensional continuous systems. Our work shows these attractors in discrete systems. They can occur in Newton's recursion and in numerical integration.
Keywords:
chaos; discrete system; dynamics; fractal; hidden attractor
1. Introduction
In nature, many phenomena are generated by dynamical systems. These are, i.a., fixed points, periodic or non-periodic (quasiperiodic) oscillations, as well as chaotic oscillations. From a scientific and practical point of view, chaotic oscillations are the most interesting. They are found both in engineering (e.g., in chemical reactors [ 1, 2, 3]) and in such fields as cryptography (e.g., [ 4]). Research in the field of chaos covers issues such as hyperchaos and multistability [ 5, 6], Lyapunov exponents [ 7], or systems with lags [ 8]. One of the aspects of research on chaos is the so-called hidden attractors. Much has been said in the scientific literature about so-called hidden attractors, including hidden stable periodic attractors and hidden chaotic attractors. We deal with a hidden attractor when the mathematical model of a given system does not have a constant dynamic equilibrium point (stationary point). Previous literature reports on this subject concern both dynamic continuous systems (e.g., [ 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]), and discrete multidimensional dynamic systems (for example: [ 26, 27, 28, 29, 30]). Research on this issue is crucial because it can protect the system from dangerous, chaotic oscillations. However, due to their nature, it is difficult to find them at the design stage [ 31]. Dynamical systems with hidden attractors may also have a positive impact on the development of some fields, for example, in the encryption of images [ 22, 32, 33] or in the wireless control of mobile robots [ 34].
This work presents examples of periodic orbits without an equilibrium point and hidden chaotic attractors in one-dimensional discrete systems. Using Lyapunov's exponents it was shown that periodic orbits without an equilibrium point are unstable. These orbits are a solution of the multiple compounding of a given discrete transformation, which means that their detection by means of numerical simulation is practically impossible. This problem is significantly simplified when the mathematical model of a given discrete system is an even or at least symmetric function. From the examples presented in this paper, mathematical dependencies were derived that explicitly define the unstable periodic orbits. Hidden chaotic attracting orbits have been determined only numerically. The behavior of partial sums composed of elements of chaotic attractors was also investigated in this work. The fractal nature of these sums was shown, which is presented in the appropriate figure.
The goal of our work is to show that hidden chaotic attractors can occur not only in complex multivariate continuous systems but also in simple single discrete systems that are, for example, described by recursive equations, and that they are quite common in such systems. We also demonstrate repellers in discrete systems without an equilibrium point. The scientific literature mainly deals with hidden attractors in continuous systems. There is, however, a clear deficiency in discrete systems.
In our work, we use tools of nonlinear dynamics, especially chaotic dynamics and fractals. These are primarily the formulas for calculating the Lyapunov exponents, the sensitivity test on the change of initial conditions, and the phase diagram in the form of a discrete fractal map (Figure 5).
This article is structured as follows: The Introduction section provides an overview of the topic and an overview of similar works in the scientific literature; the Mathematical Foundations section describes a method of constructing discrete maps that generate hidden orbits as a result of iteration; in the next part examples of maps constructed with the proposed method are presented; then, in the section devoted to the Euler method, the method of constructing maps on the example of numerical integration is shown. The article ends with conclusions and references.
2. Mathematical Foundations
Suppose a function f ( x ) such that for every real number x:
f ( x ) ≠ 0 .
(1)
To derive a discrete model without a fixed point, we will use the well-known Newton's method for determining the roots of the equation. Thus, the following recursive Newton process:
x k + 1 = x k − f ( x k ) f ′ ( x k )
(2)
is not a convergent process. This means that the transformation ( 2) does not have a dynamic equilibrium point (fixed point). In this case, the stable periodic orbits and the chaotic attracting orbits are hidden ones. F ( m ) ( x ) should be understood as the m-th composition of the recursive transform ( 2) ( m-th cycle). All m-periodic orbits ( m > 1 ) can be determined from the m-th transformation of the relationship ( 2):
x k + m = F ( m ) ( x k ) .
(3)
Assuming: x k + m = x k = x s m , the m-periodic orbit are the roots of the equation ( m > 1 ):
x s m = F ( m ) ( x s m ) .
(4)
In case when the function f ( x ) is even, i.e., f ( x ) = f ( − x ) , the two-period orbit is defined by the points x s 1 = − x s 2 . They can be determined directly from ( 2) as a solution to the equation:
− x s 1 = F ( 1 ) ( x s 1 ) .
(5)
In the case where f ( x ) is a symmetrical function with respect to x * ≠ 0 , the plot of the function should be shifted so that the zero point becomes the point of symmetry and then formula ( 5) should be applied. In all other cases, formula ( 4) should be used to determine other periodic orbits. The other attracting orbits are chaotic orbits.
3. Examples
Example 1.
Let us suppose:
f ( x ) = x 2 n + c 2 = 0 .
(6)
This equation has no solution, and the function f ( x ) is an even function. Therefore, applying Formula ( 5), we get that the two-period orbit of transformation ( 2) are the points:
x s 1 , 2 = ± c 2 4 n − 1 2 n .
(7)
This orbit is unstable, as evidenced by the value of Lyapunov's exponent:
λ = ln [ 2 ( 2 n − 1 ) ] > 0 .
(8)
This transformation also has a hidden chaotic attracting orbit ( Figure 1). 
Figure 1. Unstable periodic orbit x s 1 = − 1 3 , x s 2 = 1 3 and hidden chaotic attractor. n = 1 , c = 1 , x 0 = 0.1 .
Example 2.
Let us suppose:
f ( x ) = exp ( c x 2 n ) = 0 .
(9)
This equation has no solution, and the function f ( x ) is an even function. Therefore, applying Formula ( 5), we get that the two-period orbit of transformation ( 2) are the points:
x s 1 , 2 = ± 1 4 n c 2 n .
(10)
This orbit is unstable, as evidenced by the value of Lyapunov's exponent:
λ = ln [ 1 + 2 ( 2 n − 1 ) ] > 0 .
(11)
This transformation also has a hidden chaotic attracting orbit ( Figure 2). 
Figure 2. Unstable periodic orbit x s 1 = − 1 2 , x s 2 = 1 2 and hidden chaotic attractor. n = 1 , c = 1 , x 0 = 0.1 .
Example 3.
Let us suppose:
f ( x ) = x 2 + x + 1 = 0 .
(12)
This equation has no solution. The function f ( x ) is not an even function, but it is a symmetrical function with respect to the point x * = − 1 2 . The two-period orbit of Transformation ( 2) is defined in this case by the points:
x s 1 = − 1 ; x s 2 = 0 .
(13)
This orbit is unstable, as evidenced by the value of Lyapunov's exponent:
λ = ln 2 > 0 .
(14)
This transformation also has a hidden chaotic attracting orbit ( Figure 3). 
Figure 3. Unstable periodic orbit x s 1 = − 1 , x s 2 = 0 and hidden chaotic attractor. x 0 = 0.1 .
The remaining higher-order orbits ( m > 2 ), occurring in the above examples, can be determined using Formula ( 4).
Example 4
Example 4.
Let us suppose:
f ( x ) = x 2 n + exp ( c x ) = 0 .
(15)
This equation has no solution, and the function f ( x ) is neither even nor symmetric. Transformation ( 2) based on this function has no periodic orbit, but a chaotic attracting orbit ( Figure 4). 
Figure 4. Hidden chaotic attractor. x 0 = 0.1 .
An interesting issue is to check the behavior of average partial sums, defined as:
S k = 1 k ∑ i = 1 k x i ; k = 1 , 2 , ⋯
(16)
Taking into account Example 1, the points with the coordinates S k , S k + 1 are marked in Figure 5. 
Figure 5. Fractal of partial sums for Example 1.
The color of the point depends on the value of k. This graph is a fractal. The drawings made for the remaining examples look similar.
4. Hidden Chaotic Attractors with Euler Integration Method
Suppose we have the following differential equation:
d x d t = g ( x ) ,
(17)
where g ( x ) = 0 has no solution. Let us say the function g ( x ) can be represented as:
g ( x ) = − f ( x ) f ′ ( x ) ,
(18)
which, in conjunction with ( 17), gives:
d x d t = − f ( x ) f ′ ( x ) ,
(19)
where f ( x ) = 0 has no solution.
Simple transformations of dependencies ( 19) lead to the general final form:
f ( x ) = f ( x 0 ) e − t ,
(20)
where x 0 = x ( t = 0 ) . It is clearly visible that for t = 0 , Equation ( 20) has a solution that is x = x 0 . Therefore, there must be a limit t l , above which the equation no longer has a solution. Suppose, for example, that:
f ( x ) = x 2 + 1 ,
(21)
where then:
g ( x ) = − x 2 + 1 2 x .
(22)
It is thus clear that in this case:
t l = ln ( x 0 + 1 ) .
(23)
Integrating Equation ( 17) using the Euler method we obtain the recursion:
x k + 1 = x k − f ( x k ) f ′ ( x k ) Δ t .
(24)
This means that for t < t l the numerical process tends to a specific value of the variable x (for t = t l x = 0 ), while for t > t l the numerical process becomes chaotic and has the feature of hidden chaos, regardless of the value of the integration variable Δ t . This phenomenon is shown in Figure 6 for x 0 = 3 . The limit value, in this case, is t l = 2.3026 . 
Figure 6. Numerical solution obtained from ( 24). After reaching t l = 2.3026 the solution becomes chaotic. x 0 = 3 .
5. Summary
The examples presented in the paper show the existence of unstable periodic orbits without an equilibrium point and hidden chaotic attracting orbits in discrete models. In the scientific literature, these attracting orbits are called “hidden” because the mathematical models from which they were generated do not have dynamic equilibrium points. Therefore, detecting these types of orbits is extremely difficult. For these examples, mathematical formulas were derived to define unstable periodic orbits without an equilibrium point. Newton's method and Euler's method utilized in the work are used to obtain discrete mappings that generate hidden chaotic solutions for appropriately selected functions. The examples presented in the paper show the existence of unstable periodic orbits without an equilibrium point and hidden chaotic orbits in discrete models.
Author Contributions
Conceptualization, M.B. and M.L.; methodology, M.B. and M.L.; formal analysis, M.B.; writing—original draft preparation, M.B. and M.L.; writing—review and editing, M.B and M.L. Both authors have read and agreed to the published version of the manuscript.
Funding
This research received no external funding.
Conflicts of Interest
The authors declare no conflict of interest.
References
Berezowski, M. Determination of catastrophic sets of a tubular chemical reactor by two-parameter continuation method. Int. J. Chem. React. Eng. 2020, 18. [ Google Scholar] [ CrossRef]
Berezowski, M. Application of Lyapunov's Methods for Analyzing the Stability of a Tubular Chemical Reactor with Recycle. Chem. Eng. Technol. 2020, 43, 2523–2529. [ Google Scholar] [ CrossRef]
Berezowski, M. Chaos Predictability in a Chemical Reactor. Int. J. Bifurc. Chaos 2020, 30, 2050221. [ Google Scholar] [ CrossRef]
Lawnik, M.; Kapczyński, A. The application of modified Chebyshev polynomials in asymmetric cryptography. Comput. Sci. 2019, 20. [ Google Scholar] [ CrossRef]
Galias, Z.; Tucker, W. Numerical Study of Coexisting Attractors for The Hénon Map. Int. J. Bifurc. Chaos 2013, 23, 1330025. [ Google Scholar] [ CrossRef]
Garashchuk, I.R.; Sinelshchikov, D.; Kazakov, A.; Kudryashov, N. Hyperchaos and multistability in the model of two interacting microbubble contrast agents. Chaos 2019, 29, 063131. [ Google Scholar] [ CrossRef] [ PubMed]
Lawnik, M. The problem of the inverse Lyapunov exponent and its applications. Nonlinear Anal. Model. Control 2018, 23, 951–960. [ Google Scholar] [ CrossRef]
Matsumoto, A.; Szidarovszky, F.; Nakayama, K. Delay Cournot Duopoly Game with Gradient Adjustment: Berezowski Transition from a Discrete Model to a Continuous Model. Mathematics 2021, 9, 32. [ Google Scholar] [ CrossRef]
Kuznetsov, N.; Leonov, G.; Vagaitsev, V. Analytical-numerical method for attractor localization of generalized Chua's system. IFAC Proc. Vol. 2010, 43, 29–33. [ Google Scholar] [ CrossRef]
Leonov, G.; Kuznetsov, N.; Vagaitsev, V. Localization of hidden Chua's attractors. Phys. Lett. A 2011, 375, 2230–2233. [ Google Scholar] [ CrossRef]
Leonov, G.; Kuznetsov, N.; Vagaitsev, V. Hidden attractor in smooth Chua systems. Phys. D Nonlinear Phenom. 2012, 241, 1482–1486. [ Google Scholar] [ CrossRef]
Leonov, G.A.; Kuznetsov, N.V. Hidden Attractors in Dynamical Systems. From Hidden Oscillations in Hilbert-Kolmogorov Aizerman, and Kalman Problems to Hidden Chaotic Attractor in Chua Circuits. Int. J. Bifurc. Chaos 2013, 23, 1330002. [ Google Scholar] [ CrossRef]
Jafari, S.; Sprott, J. Simple chaotic flows with a line equilibrium. Chaos Solitons Fractals 2013, 57, 79–84. [ Google Scholar] [ CrossRef]
Jafari, S.; Sprott, J.; Hashemi Golpayegani, S.M.R. Elementary quadratic chaotic flows with no equilibria. Phys. Lett. A 2013, 377, 699–702. [ Google Scholar] [ CrossRef]
Leonov, G.A.; Kuznetsov, N.V.; Kiseleva, M.A.; Solovyeva, E.P.; Zaretskiy, A.M. Hidden oscillations in mathematical model of drilling system actuated by induction motor with a wound rotor. Nonlinear Dyn. 2014, 77, 277–288. [ Google Scholar] [ CrossRef]
Leonov, G.; Kuznetsov, N.; Mokaev, T.N. Homoclinic orbits, and self-excited and hidden attractors in a Lorenz-like system describing convective fluid motion. Eur. Phys. J. Spec. Top. 2015, 224, 1421–1458. [ Google Scholar] [ CrossRef]
Jafari, S.; Sprott, J.C.; Nazarimehr, F. Recent new examples of hidden attractors. Eur. Phys. J. Spec. Top. 2015, 224. [ Google Scholar] [ CrossRef]
Dudkowski, D.; Jafari, S.; Kapitaniak, T.; Kuznetsov, N.V.; Leonov, G.A.; Prasad, A. Hidden attractors in dynamical systems. Phys. Rep. 2016, 637, 1–50. [ Google Scholar] [ CrossRef]
Jiang, H.; Liu, Y.; Wei, Z.; Zhang, L. A New Class of Three-Dimensional Maps with Hidden Chaotic Dynamics. Int. J. Bifurc. Chaos 2016, 26, 1650206. [ Google Scholar] [ CrossRef]
Jafari, S.; Pham, V.T.; Golpayegani, S.M.R.H.; Moghtadaei, M.; Kingni, S.T. The Relationship Between Chaotic Maps and Some Chaotic Systems with Hidden Attractors. Int. J. Bifurc. Chaos 2016, 26, 1650211. [ Google Scholar] [ CrossRef]
Kiseleva, M.A.; Kuznetsov, N.V.; Leonov, G.A. Hidden attractors in electromechanical systems with and without equilibria. IFAC-PapersOnLine 2016, 49, 51–55. [ Google Scholar] [ CrossRef]
Çavuşoğlu, U.; Panahi, S.; Akgül, A.; Jafari, S.; Kaçar, S. A New Chaotic System with Hidden Attractor and Its Engineering Applications: Analog Circuit Realization and Image Encryption. Analog Integr. Circuits Signal Process. 2019, 98, 85–99. [ Google Scholar] [ CrossRef]
Yang, L.; Yang, Q.; Chen, G. Hidden attractors, singularly degenerate heteroclinic orbits, multistability and physical realization of a new 6D hyperchaotic system. Commun. Nonlinear Sci. Numer. Simul. 2020, 90, 105362. [ Google Scholar] [ CrossRef]
Azar, A.T.; Serrano, F.E. Stabilization of Port Hamiltonian Chaotic Systems with Hidden Attractors by Adaptive Terminal Sliding Mode Control. Entropy 2020, 22, 122. [ Google Scholar] [ CrossRef] [ PubMed]
Danca, M.F.; Lampart, M. Hidden and self-excited attractors in a heterogeneous Cournot oligopoly model. Chaos Solitons Fractals 2021, 142, 110371. [ Google Scholar] [ CrossRef]
Kamal, N.; Varshney, V.; Shrimali, M.; Prasad, A.; Kuznetsov, N.; Leonov, G. Shadowing in hidden attractors. Nonlinear Dyn. 2018, 91, 2429–2434. [ Google Scholar] [ CrossRef]
Danca, M.F.; Fečkan, M. Hidden chaotic attractors and chaos suppression in an impulsive discrete economical supply and demand dynamical system. Commun. Nonlinear Sci. Numer. Simul. 2019, 74, 1–13. [ Google Scholar] [ CrossRef]
Ouannas, A.; Khennaoui, A.A.; Momani, S.; Grassi, G.; Pham, V.T.; El-Khazali, R.; Vo Hoang, D. A Quadratic Fractional Map without Equilibria: Bifurcation, 0–1 Test, Complexity, Entropy, and Control. Electronics 2020, 9, 748. [ Google Scholar] [ CrossRef]
Ouannas, A.; Khennaoui, A.A.; Momani, S.; Pham, V.-T.; El-Khazali, R. Hidden attractors in a new fractional-order discrete system: Chaos, complexity, entropy and control. Chin. Phys. B 2020, 29, 050504. [ Google Scholar] [ CrossRef]
Ouannas, A.; Khennaoui, A.A.; Momani, S.; Grassi, G.; Pham, V.T. Chaos and control of a three-dimensional fractional order discrete-time system with no equilibrium and its synchronization. AIP Adv. 2020, 10, 045310. [ Google Scholar] [ CrossRef]
Pham, V.T.; Vaidyanathan, S.; Volos, C.; Kapitaniak, T. (Eds.) Nonlinear Dynamical Systems with Self-Excited and Hidden Attractors; Springer: Cham, Switzerland, 2018. [ Google Scholar]
Peng, X.; Zeng, Y. Image encryption application in a system for compounding self-excited and hidden attractors. Chaos Solitons Fractals 2020, 139, 110044. [ Google Scholar] [ CrossRef]
Wang, S.; Wang, C.; Xu, C. An image encryption algorithm based on a hidden attractor chaos system and the Knuth–Durstenfeld algorithm. Opt. Lasers Eng. 2020, 128, 105995. [ Google Scholar] [ CrossRef]
Vaidyanathan, S.; Sambas, A.; Mamat, M.; Sanjaya, M. A new three-dimensional chaotic system with a hidden attractor, circuit design and application in wireless mobile robot. Arch. Control Sci. 2017, 27, 541–554. [ Google Scholar] [ CrossRef]
Figure 1. Unstable periodic orbit x s 1 = − 1 3 , x s 2 = 1 3 and hidden chaotic attractor. n = 1 , c = 1 , x 0 = 0.1 .
Figure 2. Unstable periodic orbit x s 1 = − 1 2 , x s 2 = 1 2 and hidden chaotic attractor. n = 1 , c = 1 , x 0 = 0.1 .
Figure 3. Unstable periodic orbit x s 1 = − 1 , x s 2 = 0 and hidden chaotic attractor. x 0 = 0.1 .
Figure 4. Hidden chaotic attractor. x 0 = 0.1 .
Figure 5. Fractal of partial sums for Example 1.
Figure 6. Numerical solution obtained from ( 24). After reaching t l = 2.3026 the solution becomes chaotic. x 0 = 3 .
Publisher's Note: MDPI stays neutral with regard to jurisdictional claims in published maps and institutional affiliations.
© 2021 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license ( https://creativecommons.org/licenses/by/4.0/).
Share and Cite
      
MDPI and ACS Style
Berezowski, M.; Lawnik, M. Hidden Attractors in Discrete Dynamical Systems. Entropy 2021, 23, 616. https://doi.org/10.3390/e23050616
AMA Style
Berezowski M, Lawnik M. Hidden Attractors in Discrete Dynamical Systems. Entropy. 2021; 23(5):616. https://doi.org/10.3390/e23050616
Chicago/Turabian Style
Berezowski, Marek, and Marcin Lawnik. 2021. "Hidden Attractors in Discrete Dynamical Systems" Entropy 23, no. 5: 616. https://doi.org/10.3390/e23050616
APA Style
Berezowski, M., & Lawnik, M. (2021). Hidden Attractors in Discrete Dynamical Systems. Entropy, 23(5), 616. https://doi.org/10.3390/e23050616
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
Article Metrics
Yes
Citations
Crossref
6
Scopus
6
Web of Science
6
ads
4
Google Scholar
[click to view]
No
Article Access Statistics
Created with Highcharts 4.0.4 Article access statistics Article Views 11. Mar 12. Mar 13. Mar 14. Mar 15. Mar 16. Mar 17. Mar 18. Mar 19. Mar 20. Mar 21. Mar 22. Mar 23. Mar 24. Mar 25. Mar 26. Mar 27. Mar 28. Mar 29. Mar 30. Mar 31. Mar 1. Apr 2. Apr 3. Apr 4. Apr 5. Apr 6. Apr 7. Apr 8. Apr 9. Apr 10. Apr 11. Apr 12. Apr 13. Apr 14. Apr 15. Apr 16. Apr 17. Apr 18. Apr 19. Apr 20. Apr 21. Apr 22. Apr 23. Apr 24. Apr 25. Apr 26. Apr 27. Apr 28. Apr 29. Apr 30. Apr 1. May 2. May 3. May 4. May 5. May 6. May 7. May 8. May 9. May 10. May 11. May 12. May 13. May 14. May 15. May 16. May 17. May 18. May 19. May 20. May 21. May 22. May 23. May 24. May 25. May 26. May 27. May 28. May 29. May 30. May 31. May 1. Jun 2. Jun 3. Jun 4. Jun 5. Jun 6. Jun 7. Jun 8. Jun 0k 1k 2k 3k 4k 5k
For more information on the journal statistics, click here.
Multiple requests from the same IP address are counted as one view.
Zoom | Orient | As Lines | As Sticks | As Cartoon | As Surface | Previous Scene | Next Scene
Cite
Export citation file: BibTeX | EndNote | RIS
MDPI and ACS Style
Berezowski, M.; Lawnik, M. Hidden Attractors in Discrete Dynamical Systems. Entropy 2021, 23, 616. https://doi.org/10.3390/e23050616
AMA Style
Berezowski M, Lawnik M. Hidden Attractors in Discrete Dynamical Systems. Entropy. 2021; 23(5):616. https://doi.org/10.3390/e23050616
Chicago/Turabian Style
Berezowski, Marek, and Marcin Lawnik. 2021. "Hidden Attractors in Discrete Dynamical Systems" Entropy 23, no. 5: 616. https://doi.org/10.3390/e23050616
APA Style
Berezowski, M., & Lawnik, M. (2021). Hidden Attractors in Discrete Dynamical Systems. Entropy, 23(5), 616. https://doi.org/10.3390/e23050616
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
clear
Entropy, EISSN 1099-4300, Published by MDPI
RSS Content Alert
Further Information
Article Processing Charges Pay an Invoice Open Access Policy Contact MDPI Jobs at MDPI
Guidelines
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
MDPI Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
Follow MDPI
LinkedIn Facebook X 
Subscribe to receive issue release notifications and newsletters from MDPI journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies
Climate
Clinical and Translational Neuroscience
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications
Eng
Engineering Proceedings
Entropic and Disordered Matter
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal
European Journal of Investigation in Health, Psychology and Education
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences
International Journal of Environmental Medicine
International Journal of Environmental Research and Public Health
International Journal of Financial Studies
International Journal of Medical Devices
International Journal of Molecular Sciences
International Journal of Neonatal Screening
International Journal of Orofacial Myology and Myofunctional Therapy
International Journal of Plant Biology
International Journal of Topology
International Journal of Translational Medicine
International Journal of Turbomachinery, Propulsion and Power
International Medical Education
Inventions
IoT
ISPRS International Journal of Geo-Information
J
Journal of Aesthetic Medicine
Journal of Ageing and Longevity
Journal of CardioRenal Medicine
Journal of Cardiovascular Development and Disease
Journal of Clinical & Translational Ophthalmology
Journal of Clinical Medicine
Journal of Composites Science
Journal of Cybersecurity and Privacy
Journal of Dementia and Alzheimer's Disease
Journal of Developmental Biology
Journal of Experimental and Theoretical Analyses
Journal of Eye Movement Research
Journal of Functional Biomaterials
Journal of Functional Morphology and Kinesiology
Journal of Fungi
Journal of Genome Biotechnology and Genetics
Journal of Gerontology and Geriatrics
Journal of Imaging
Journal of Innovation
Journal of Intelligence
Journal of Interdisciplinary Research Applied to Medicine
Journal of Low Power Electronics and Applications
Journal of Manufacturing and Materials Processing
Journal of Marine Science and Engineering
Journal of Market Access & Health Policy
Journal of Mind and Medical Sciences
Journal of Molecular Pathology
Journal of Nanotheranostics
Journal of Nuclear Engineering
Journal of Otorhinolaryngology, Hearing and Balance Medicine
Journal of Parks
Journal of Personalized Medicine
Journal of Pharmaceutical and BioTech Industry
Journal of Phytomedicine
Journal of Respiration
Journal of Risk and Financial Management
Journal of Sensor and Actuator Networks
Journal of Superintelligence
Journal of the American Podiatric Medical Association
Journal of the Oman Medical Association
Journal of Theoretical and Applied Electronic Commerce Research
Journal of Vascular Diseases
Journal of Xenobiotics
Journal of Zoological and Botanical Gardens
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics
Religions
Remote Sensing
Reports
Reproductive Medicine
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine
Ruminants
Safety
Sci
Scientia Pharmaceutica
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal
Youth
Zoonotic Diseases
Select options
[-] accountaudit Accounting and Auditing [-] acoustics Acoustics [-] amh Acta Microbiologica Hellenica [-] actuators Actuators [-] adhesives Adhesives [-] admsci Administrative Sciences [-] adolescents Adolescents [-] arm Advances in Respiratory Medicine [-] aerobiology Aerobiology [-] aerospace Aerospace [-] agriculture Agriculture [-] agriengineering AgriEngineering [-] agrochemicals Agrochemicals [-] agronomy Agronomy [-] ai AI [-] aichem AI Chemistry [-] aieng AI for Engineering [-] aieduc AI in Education [-] aimed AI in Medicine [-] aimater AI Materials [-] aisens AI Sensors [-] air Air [-] algorithms Algorithms [-] allergies Allergies [-] alloys Alloys [-] analog Analog [-] analytica Analytica [-] analytics Analytics [-] anatomia Anatomia [-] anesthres Anesthesia Research [-] animals Animals [-] antibiotics Antibiotics [-] antibodies Antibodies [-] antioxidants Antioxidants [-] applbiosci Applied Biosciences [-] applmech Applied Mechanics [-] applmicrobiol Applied Microbiology [-] applnano Applied Nano [-] applsci Applied Sciences [-] asi Applied System Innovation [-] appliedchem AppliedChem [-] appliedmath AppliedMath [-] appliedphys AppliedPhys [-] aquacj Aquaculture Journal [-] architecture Architecture [-] arthropoda Arthropoda [-] arts Arts [-] astronautics Astronautics [-] astronomy Astronomy [-] atmosphere Atmosphere [-] atoms Atoms [-] audiolres Audiology Research [-] automation Automation [-] axioms Axioms [-] bacteria Bacteria [-] batteries Batteries [-] behavsci Behavioral Sciences [-] beverages Beverages [-] BDCC Big Data and Cognitive Computing [-] biochem BioChem [-] bioengineering Bioengineering [-] biologics Biologics [-] biology Biology [-] blsf Biology and Life Sciences Forum [-] biomass Biomass [-] biomechanics Biomechanics [-] biomed BioMed [-] biomedicines Biomedicines [-] biomedinformatics BioMedInformatics [-] biomimetics Biomimetics [-] biomolecules Biomolecules [-] biophysica Biophysica [-] bioresourbioprod Bioresources and Bioproducts [-] biosensors Biosensors [-] biosphere Biosphere [-] biotech BioTech [-] birds Birds [-] blockchains Blockchains [-] brainsci Brain Sciences [-] buildings Buildings [-] businesses Businesses [-] carbon C [-] cancers Cancers [-] cardiogenetics Cardiogenetics [-] cardiovascmed Cardiovascular Medicine [-] catalysts Catalysts [-] cells Cells [-] ceramics Ceramics [-] challenges Challenges [-] ChemEngineering ChemEngineering [-] chemistry Chemistry [-] chemproc Chemistry Proceedings [-] chemosensors Chemosensors [-] children Children [-] chips Chips [-] civileng CivilEng [-] cleantechnol Clean Technologies [-] climate Climate [-] ctn Clinical and Translational Neuroscience [-] clinbioenerg Clinical Bioenergetics [-] clinpract Clinics and Practice [-] clockssleep Clocks & Sleep [-] coasts Coasts [-] coatings Coatings [-] colloids Colloids and Interfaces [-] colorants Colorants [-] commodities Commodities [-] complexities Complexities [-] complications Complications [-] compounds Compounds [-] computation Computation [-] csmf Computer Sciences & Mathematics Forum [-] computers Computers [-] condensedmatter Condensed Matter [-] conservation Conservation [-] constrmater Construction Materials [-] cmd Corrosion and Materials Degradation [-] cosmetics Cosmetics [-] covid COVID [-] cmtr Craniomaxillofacial Trauma & Reconstruction [-] crops Crops [-] cryo Cryo [-] cryptography Cryptography [-] crystals Crystals [-] culture Culture [-] cimb Current Issues in Molecular Biology [-] curroncol Current Oncology [-] dairy Dairy [-] data Data [-] dentistry Dentistry Journal [-] dermato Dermato [-] dermatopathology Dermatopathology [-] designs Designs [-] diabetology Diabetology [-] diagnostics Diagnostics [-] dietetics Dietetics [-] digital Digital [-] dhi Digital Health and Innovation [-] disabilities Disabilities [-] diseases Diseases [-] diversity Diversity [-] dna DNA [-] drones Drones [-] ddc Drugs and Drug Candidates [-] dynamics Dynamics [-] earth Earth [-] ecologies Ecologies [-] econometrics Econometrics [-] economies Economies [-] education Education Sciences [-] electricity Electricity [-] electrochem Electrochem [-] electronicmat Electronic Materials [-] electronics Electronics [-] ecm Emergency Care and Medicine [-] encyclopedia Encyclopedia [-] endocrines Endocrines [-] energies Energies [-] esa Energy Storage and Applications [-] eng Eng [-] engproc Engineering Proceedings [-] edm Entropic and Disordered Matter [-] entropy Entropy [-] eesp Environmental and Earth Sciences Proceedings [-] environremediat Environmental Remediation [-] environments Environments [-] epidemiologia Epidemiologia [-] epigenomes Epigenomes [-] ebj European Burn Journal [-] ejihpe European Journal of Investigation in Health, Psychology and Education [-] famsci Family Sciences [-] fermentation Fermentation [-] fibers Fibers [-] fintech FinTech [-] fire Fire [-] fishes Fishes [-] fluids Fluids [-] foods Foods [-] forecasting Forecasting [-] forensicsci Forensic Sciences [-] forests Forests [-] fossstud Fossil Studies [-] foundations Foundations [-] fractalfract Fractal and Fractional [-] freshwater Freshwater [-] fuels Fuels [-] future Future [-] fclam Future Collections, Libraries, Archives, and Museums [-] futureinternet Future Internet [-] futurepharmacol Future Pharmacology [-] futuretransp Future Transportation [-] galaxies Galaxies [-] games Games [-] gases Gases [-] gastroent Gastroenterology Insights [-] gastrointestdisord Gastrointestinal Disorders [-] gastronomy Gastronomy [-] gels Gels [-] genealogy Genealogy [-] genes Genes [-] geographies Geographies [-] geohazards GeoHazards [-] geomatics Geomatics [-] geometry Geometry [-] geosciences Geosciences [-] geotechnics Geotechnics [-] geriatrics Geriatrics [-] germs Germs [-] glacies Glacies [-] gucdd Gout, Urate, and Crystal Deposition Disease [-] grasses Grasses [-] green Green [-] greenhealth Green Health [-] hardware Hardware [-] healthcare Healthcare [-] hearts Hearts [-] hemato Hemato [-] hematolrep Hematology Reports [-] heritage Heritage [-] histories Histories [-] horticulturae Horticulturae [-] hospitals Hospitals [-] humanities Humanities [-] humans Humans [-] hydrobiology Hydrobiology [-] hydrogen Hydrogen [-] hydrology Hydrology [-] hydropower Hydropower [-] hygiene Hygiene [-] immuno Immuno [-] industries Industries [-] idr Infectious Disease Reports [-] inflammj Inflammation Journal [-] informatics Informatics [-] information Information [-] infrastructures Infrastructures [-] inorganics Inorganics [-] insects Insects [-] instruments Instruments [-] iic Intelligent Infrastructure and Construction [-] ijcs International Journal of Cognitive Sciences [-] ijem International Journal of Environmental Medicine [-] ijerph International Journal of Environmental Research and Public Health [-] ijfs International Journal of Financial Studies [-] ijmd International Journal of Medical Devices [-] ijms International Journal of Molecular Sciences [-] IJNS International Journal of Neonatal Screening [-] ijom International Journal of Orofacial Myology and Myofunctional Therapy [-] ijpb International Journal of Plant Biology [-] ijt International Journal of Topology [-] ijtm International Journal of Translational Medicine [-] ijtpp International Journal of Turbomachinery, Propulsion and Power [-] ime International Medical Education [-] inventions Inventions [-] IoT IoT [-] ijgi ISPRS International Journal of Geo-Information [-] J J [-] jaestheticmed Journal of Aesthetic Medicine [-] jal Journal of Ageing and Longevity [-] jcrm Journal of CardioRenal Medicine [-] jcdd Journal of Cardiovascular Development and Disease [-] jcto Journal of Clinical & Translational Ophthalmology [-] jcm Journal of Clinical Medicine [-] jcs Journal of Composites Science [-] jcp Journal of Cybersecurity and Privacy [-] jdad Journal of Dementia and Alzheimer's Disease [-] jdb Journal of Developmental Biology [-] jeta Journal of Experimental and Theoretical Analyses [-] jemr Journal of Eye Movement Research [-] jfb Journal of Functional Biomaterials [-] jfmk Journal of Functional Morphology and Kinesiology [-] jof Journal of Fungi [-] jgbg Journal of Genome Biotechnology and Genetics [-] jgg Journal of Gerontology and Geriatrics [-] jimaging Journal of Imaging [-] joi Journal of Innovation [-] jintelligence Journal of Intelligence [-] jdream Journal of Interdisciplinary Research Applied to Medicine [-] jlpea Journal of Low Power Electronics and Applications [-] jmmp Journal of Manufacturing and Materials Processing [-] jmse Journal of Marine Science and Engineering [-] jmahp Journal of Market Access & Health Policy [-] jmms Journal of Mind and Medical Sciences [-] jmp Journal of Molecular Pathology [-] jnt Journal of Nanotheranostics [-] jne Journal of Nuclear Engineering [-] ohbm Journal of Otorhinolaryngology, Hearing and Balance Medicine [-] jop Journal of Parks [-] jpm Journal of Personalized Medicine [-] jpbi Journal of Pharmaceutical and BioTech Industry [-] jphytomed Journal of Phytomedicine [-] jor Journal of Respiration [-] jrfm Journal of Risk and Financial Management [-] jsan Journal of Sensor and Actuator Networks [-] superintelligence Journal of Superintelligence [-] japma Journal of the American Podiatric Medical Association [-] joma Journal of the Oman Medical Association [-] jtaer Journal of Theoretical and Applied Electronic Commerce Research [-] jvd Journal of Vascular Diseases [-] jox Journal of Xenobiotics [-] jzbg Journal of Zoological and Botanical Gardens [-] journalmedia Journalism and Media [-] kidneydial Kidney and Dialysis [-] kinasesphosphatases Kinases and Phosphatases [-] knowledge Knowledge [-] labmed LabMed [-] laboratories Laboratories [-] land Land [-] languages Languages [-] laws Laws [-] life Life [-] lights Lights [-] limnolrev Limnological Review [-] lipidology Lipidology [-] liquids Liquids [-] literature Literature [-] livers Livers [-] logics Logics [-] logistics Logistics [-] lae Low-Altitude Economy [-] lubricants Lubricants [-] lymphatics Lymphatics [-] make Machine Learning and Knowledge Extraction [-] machines Machines [-] macromol Macromol [-] magnetism Magnetism [-] magnetochemistry Magnetochemistry [-] marinedrugs Marine Drugs [-] materials Materials [-] materproc Materials Proceedings [-] mca Mathematical and Computational Applications [-] mathematics Mathematics [-] medsci Medical Sciences [-] msf Medical Sciences Forum [-] medicina Medicina [-] medicines Medicines [-] membranes Membranes [-] merits Merits [-] metabolites Metabolites [-] metals Metals [-] meteorology Meteorology [-] methane Methane [-] mps Methods and Protocols [-] metrics Metrics [-] metrology Metrology [-] micro Micro [-] microbiolres Microbiology Research [-] microelectronics Microelectronics [-] micromachines Micromachines [-] microorganisms Microorganisms [-] microplastics Microplastics [-] microwave Microwave [-] minerals Minerals [-] mining Mining [-] modelling Modelling [-] mmphys Modern Mathematical Physics [-] molbank Molbank [-] molecules Molecules [-] multimedia Multimedia [-] mti Multimodal Technologies and Interaction [-] muscles Muscles [-] nanoenergyadv Nanoenergy Advances [-] nanomanufacturing Nanomanufacturing [-] nanomaterials Nanomaterials [-] ndt NDT [-] network Network [-] neuroglia Neuroglia [-] neuroimaging Neuroimaging [-] neurolint Neurology International [-] neurosci NeuroSci [-] nitrogen Nitrogen [-] ncrna Non-Coding RNA [-] nursrep Nursing Reports [-] nutraceuticals Nutraceuticals [-] nutrients Nutrients [-] obesities Obesities [-] occuphealth Occupational Health [-] oceans Oceans [-] onco Onco [-] optics Optics [-] oral Oral [-] organics Organics [-] organoids Organoids [-] osteology Osteology [-] oxygen Oxygen [-] pandemics Pandemics [-] parasitologia Parasitologia [-] particles Particles [-] pathogens Pathogens [-] pathophysiology Pathophysiology [-] peacestud Peace Studies [-] pediatrrep Pediatric Reports [-] pets Pets [-] pharmaceuticals Pharmaceuticals [-] pharmaceutics Pharmaceutics [-] pharmacoepidemiology Pharmacoepidemiology [-] pharmacy Pharmacy [-] philosophies Philosophies [-] photochem Photochem [-] photonics Photonics [-] phycology Phycology [-] physchem Physchem [-] psf Physical Sciences Forum [-] physics Physics [-] physiologia Physiologia [-] plants Plants [-] plasma Plasma [-] platforms Platforms [-] pollutants Pollutants [-] polymers Polymers [-] polysaccharides Polysaccharides [-] populations Populations [-] poultry Poultry [-] powders Powders [-] precisoncol Precision Oncology [-] phc Primary and Hospital Care [-] proceedings Proceedings [-] processes Processes [-] prosthesis Prosthesis [-] proteomes Proteomes [-] psychiatryint Psychiatry International [-] psychoactives Psychoactives [-] psycholint Psychology International [-] publications Publications [-] purification Purification [-] qubs Quantum Beam Science [-] quantumrep Quantum Reports [-] quaternary Quaternary [-] radiation Radiation [-] reactions Reactions [-] realestate Real Estate [-] receptors Receptors [-] recycling Recycling [-] rsee Regional Science and Environmental Economics [-] religions Religions [-] remotesensing Remote Sensing [-] reports Reports [-] reprodmed Reproductive Medicine [-] resources Resources [-] rheumato Rheumato [-] risks Risks [-] robotics Robotics [-] rjpm Romanian Journal of Preventive Medicine [-] ruminants Ruminants [-] safety Safety [-] sci Sci [-] scipharm Scientia Pharmaceutica [-] sclerosis Sclerosis [-] seeds Seeds [-] shi Semiconductors and Heterogeneous Integration [-] sensors Sensors [-] separations Separations [-] sexes Sexes [-] signals Signals [-] sinusitis Sinusitis [-] smartcities Smart Cities [-] socsci Social Sciences [-] siuj Société Internationale d'Urologie Journal [-] societies Societies [-] software Software [-] soilsystems Soil Systems [-] solar Solar [-] solids Solids [-] spectroscj Spectroscopy Journal [-] sports Sports [-] standards Standards [-] stats Stats [-] stratsediment Stratigraphy and Sedimentology [-] stresses Stresses [-] surfaces Surfaces [-] surgeries Surgeries [-] std Surgical Techniques Development [-] sustainability Sustainability [-] suschem Sustainable Chemistry [-] sanpp Swiss Archives of Neurology, Psychiatry and Psychotherapy [-] symmetry Symmetry [-] synbio SynBio [-] systems Systems [-] targets Targets [-] taxonomy Taxonomy [-] technologies Technologies [-] telecom Telecom [-] textiles Textiles [-] thalassrep Thalassemia Reports [-] tae Theoretical and Applied Ergonomics [-] therapeutics Therapeutics [-] thermo Thermo [-] timespace Time and Space [-] tomography Tomography [-] tourismhosp Tourism and Hospitality [-] toxics Toxics [-] toxins Toxins [-] transplantology Transplantology [-] traumacare Trauma Care [-] higheredu Trends in Higher Education [-] tph Trends in Public Health [-] tropicalmed Tropical Medicine and Infectious Disease [-] universe Universe [-] urbansci Urban Science [-] uro Uro [-] vaccines Vaccines [-] vehicles Vehicles [-] venereology Venereology [-] vetsci Veterinary Sciences [-] vibration Vibration [-] virtualworlds Virtual Worlds [-] viruses Viruses [-] vision Vision [-] waste Waste [-] water Water [-] welding Welding [-] wild Wild [-] wind Wind [-] women Women [-] world World [-] wevj World Electric Vehicle Journal [-] youth Youth [-] zoonoticdis Zoonotic Diseases
Subscribe
© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated
Disclaimer
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
Legal Notice Terms and Conditions Privacy Policy Privacy Settings Accessibility
We use cookies on our website to ensure you get the best experience.
Read more about our cookies here.
Accept
Share Link
        https://www.mdpi.com/1111076
Copy
clear
Share
https://www.mdpi.com/1111076
clear
Back to Top Top
All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.
You can change your mind at any time by clicking "Privacy Settings" at the bottom of the pages.  
Accept All
Deny
More Information
Powered by Usercentrics Consent Management