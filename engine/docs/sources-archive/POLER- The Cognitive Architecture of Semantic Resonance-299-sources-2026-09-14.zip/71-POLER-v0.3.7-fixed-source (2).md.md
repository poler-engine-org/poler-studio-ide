POLER-Factorization v0.3.7 — Breathing Engine for Factorization
Test platform for breathing mathematics. Lives inside the processor, stands above it, but breathes the same air. Это должно быть по кругу.
--------------------------------------------------------------------------------
Table of Contents
Cargo.toml
Source Code (main.rs)
Deep Analysis: 64-bit Hard Semiprime TIMEOUT Problem
--------------------------------------------------------------------------------
Cargo.toml
--------------------------------------------------------------------------------
Source Code (main.rs)
--------------------------------------------------------------------------------
Deep Analysis: 64-bit Hard Semiprime TIMEOUT Problem
Problem Statement
Example: N = 4294967297 × 4294967311 = 18446744065119617087 Both p ≈ 2^32, q ≈ 2^32 — a perfectly balanced hard semiprime.
Root Cause Chain — Why 64-bit Hard Semiprimes Timeout
BOTTLENECK 1: Trial Division Hits the 2^24 Ceiling
For 64-bit N with two 32-bit primes, sqrt(N) ≈ 2^32 ≈ 4.3 billion. But trial division is capped at 2^24 = 16.7 million. Both factors are > 2^24, so trial division finds NOTHING.
Why the cap exists: Uncapping trial division to sqrt(N) for 64-bit numbers means iterating up to 2^32 ≈ 4.3 billion divisions. At ~1ns per division, that's ~4.3 seconds — slow but possible. But at 6k±1 stepping, it's ~1.4 billion steps, which is ~1.4 seconds. This IS feasible.
Current code (line 2290):
BOTTLENECK 2: Topology Size Explosion
For 64-bit N with balanced topology:
Topology variables:
Input bits: 66 (33 + 33)
Partial products: 33 × 33 = 1089
Ripple-carry rows: 32 rows × 66 columns = 2112
Carry rows: 32 rows × 66 columns = 2112
Total variables: ~5379
Each forward_pass allocates a Vec of 5379 f64 values and performs 33×33=1089 multiplications + 32×66=2112 full-adder evaluations. Each gradient (numerical) calls forward_pass 2×66 = 132 times. Each gradient (analytical) calls it 1 time + 1 backward pass.
BOTTLENECK 3: Search Space Dimensionality
The continuous optimizer searches in R^66 (66 floating-point variables). Each variable ∈ [0,1], discretized to {0,1}. That's 2^66 ≈ 7.4×10^19 possible binary configurations.
The optimizer relies on the gradient to guide the search, but:
The energy landscape has exponential number of local minima
The gradient vanishes near saddle points (pq[i] ≈ 0.5 → bin_term ≈ 0.25 maximum, but the gradient of bin_term is zero at 0.5)
The breathing entropy adds noise but not structured exploration
BOTTLENECK 4: Breathing Budget Insufficient
With 200 branches, each branch gets 1M breaths total. Each breath does:
RDTSC measurement (~100-5000 cycles)
One gradient computation (analytical: 1 forward + 1 backward pass through 5379 vars)
Adam update (66 vars)
Energy evaluation (1 forward pass)
Per-breath cost (analytical gradient):
Forward: O(nbp × nbq + nbn × nbq) = O(33×33 + 66×32) = O(3201) ops
Backward: same complexity ~ O(3201) ops
Total: ~6400 floating-point ops per breath
1M breaths × 6400 ops = 6.4 billion ops → ~2-3 seconds of pure compute. But with allocation overhead (Vec::new per forward_pass), it's ~10-20× slower. Estimated: 30-60 seconds per branch, and branches run in parallel.
The real problem: 1M breaths is simply not enough iterations for a 66-dimensional non-convex optimization. The optimizer gets stuck in local minima and V_ZERO resets only help if the PhaseGrid has a starting point close to the solution.
BOTTLENECK 5: Branch & Bound Cannot Scale
For 66-bit pq with even moderate uncertainty (say 40 bits uncertain), n_uncertain = 40 > 24, so B&B is NEVER called. The brute_binary_search has a radius of only 100,000 — useless for 32-bit factors.
BOTTLENECK 6: PhaseGrid Coverage Is Too Sparse
200 phase vectors in R^66 — that's 200 starting points in a 66-dimensional hypercube. The probability that any of them is "close enough" to the true solution to converge is astronomically small.
BOTTLENECK 7: forward_pass Allocation Overhead
EVERY call to forward_pass allocates a new Vec of ~43KB. With 1M breaths per branch × 200 branches, that's 200M allocations. This is catastrophic for cache performance and adds massive overhead.
Quantitative Breakdown — Where Time Goes
For a 64-bit hard semiprime with analytical gradient:
This matches the observed TIMEOUT.
Comparison: Why 49-bit Works but 64-bit Doesn't
The search space grows by 2^38 (≈ 274 billion times), but breaths only double. This is the fundamental scaling problem.
Solutions — Ordered by Impact
SOLUTION 1: Quadratic Sieve / ECM Hybrid (HIGHEST IMPACT)
The honest truth: polynomial-system factorization fundamentally cannot compete with number-theoretic algorithms for large semiprimes.
For 64-bit: Lenstra ECM or Quadratic Sieve would factor in <1 second. The breathing mathematics adds value NOT by replacing number theory, but by providing a UNIQUE computation model that can be applied to problems where traditional algorithms don't apply (quantum chemistry, constraint satisfaction, combinatorial optimization).
Recommendation: Add ECM (Elliptic Curve Method) as Step 2.5:
ECM with B1=10000 can find 32-bit factors in ~10ms. This immediately solves the 64-bit TIMEOUT problem for semiprimes.
SOLUTION 2: Eliminate Allocation in Forward Pass (HIGH IMPACT)
Replace Vec::new allocation with stack-allocated arrays or pre-allocated buffers. This alone could give 5-10× speedup:
Also pre-allocate the gradient buffer, pq_history, and phase vectors.
SOLUTION 3: Increase Trial Division Limit (MEDIUM IMPACT)
Raise the cap from 2^24 to 2^32 for 64-bit numbers:
Cost: up to ~1.4 seconds for full sqrt(N) trial division. Benefit: catches factors up to 2^32 instantly — SOLVES the 64-bit problem for semiprimes with at least one factor < 2^32.
This is a pragmatic fix: for hard semiprimes where BOTH factors > 2^32, we still need the breathing solver or ECM.
SOLUTION 4: Blockwise Factorization (MEDIUM IMPACT)
Instead of solving the full 66-variable system at once, decompose into smaller blocks:
Fix upper bits of p and q based on N's magnitude
Solve for lower 16 bits of each factor (32-var system)
Verify candidates, then solve for next 16 bits
Repeat until full factorization
This reduces the search space from 2^66 to 4 × 2^16 = 262,144 combinations in the worst case.
SOLUTION 5: Preconditioned PhaseGrid (MEDIUM IMPACT)
Current PhaseGrid generates random-ish phase vectors. For 64-bit, we should seed PhaseGrid with vectors that respect modular arithmetic:
For k=1: if N is odd, then p[0]=1, q[0]=1 (already done as anchor_lsb). For k=2: we can precompute valid (p[0:2], q[0:2]) combinations. For k=4: only 16 valid combinations out of 256 possible.
This gives a much better starting point and reduces the search space.
SOLUTION 6: Hierarchical B&B with Iterative Deepening (MEDIUM IMPACT)
Current B&B cutoff at 24 uncertain bits is too conservative. Replace with iterative deepening:
SOLUTION 7: Batch Forward Pass with SIMD (LOW-MEDIUM IMPACT)
Use SIMD (AVX2/AVX-512) to evaluate multiple forward passes simultaneously. With AVX2: 4 f64 per register → 4× throughput on forward pass. With AVX-512: 8 f64 per register → 8× throughput.
Priority Ranking for "Raising the Stakes"
For real quantum chemistry calculations, the bottlenecks are the same: large search spaces, many local minima, allocation overhead. The solutions prioritize differently:
ECM hybrid — immediate fix for number-theoretic problems
Eliminate allocation — 5-10× speedup for ALL breathing computations
Blockwise factorization — reduces exponential to polynomial scaling
Preconditioned starts — leverages mathematical structure
SIMD batch evaluation — hardware acceleration
For the quantum chemistry domain (where POLER's breathing math truly differentiates), solutions 2 and 4 are most important, because:
Quantum chemistry doesn't have number-theoretic shortcuts like ECM
The constraint systems are similar but larger
Allocation overhead becomes catastrophic at scale
Blockwise decomposition is the only way to handle 1000+ variable systems
Questions for the Author's Notebook
Is POLER breathing intended to REPLACE classical number theory, or toCOMPLEMENT it? If complement: adding ECM as Step 2.5 solves 64-bit semiprimes instantly while preserving the breathing engine for its true purpose (quantum chemistry).
What is the target variable count for quantum chemistry calculations? If >1000 variables, the allocation overhead (Solution 2) is critical and must be fixed first.
Can the constraint system be decomposed into independent sub-problems? If yes, blockwise factorization (Solution 4) applies directly. If no, the breathing engine needs fundamentally different search strategies for high dimensions.
What is "liblist" exactly? Understanding the library to be rewritten in Rust would clarify what mathematical operations need to be preserved and what can be restructured for the breathing model.
Should the 2^24 trial division cap be raised to 2^32? This is a one-line change that immediately handles 64-bit semiprimes where at least one factor is < 2^32. The cost is ~1 second for worst-case trial division.
Is the analytical gradient correct? The test (line 2519-2562) only requires 40% sign match with numerical gradient — this suggests the analytical gradient may have bugs that hurt convergence for large problems.
--------------------------------------------------------------------------------
POLER v0.3.7 — archived with analysis Breathing fingerprint: μ=1079, σ=20, CV=0.018832 8 CPU threads (rayon) | Trial division limit: min(sqrt(N), 2^24)