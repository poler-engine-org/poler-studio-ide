> Source: https://www.mdpi.com/2227-7390/11/6/1481

Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata
Loading web-font Gyre-Pagella/Main/Regular
Next Article in Journal
Measuring E-Commerce User Experience in the Last-Mile Delivery
Previous Article in Journal
An Improved Deep-Learning-Based Financial Market Forecasting Model in the Digital Economy
Journals
Active Journals Find a Journal Journal Proposal Proceedings Series
[
Topics
](https://www.mdpi.com/topics)
Information
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
Open Access Policy Institutional Open Access Program Special Issues Guidelines Editorial Process Research and Publication Ethics Article Processing Charges Awards Testimonials
[
Author Services
](https://www.mdpi.com/authors/english)
Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
About
Overview Contact Careers News Press Blog
Sign In / Sign Up
Notice
You can make submissions to other journals here.
clear
Notice
You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.
Continue Cancel
clear
All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to https://www.mdpi.com/openaccess.
Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.
Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.
Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.
Original Submission Date Received: .
You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled. 
clear zoom_out_map search menu 
Journals
Active Journals
Find a Journal
Journal Proposal
Proceedings Series
Topics
Information
For Authors
For Reviewers
For Editors
For Librarians
For Publishers
For Societies
For Conference Organizers
Open Access Policy
Institutional Open Access Program
Special Issues Guidelines
Editorial Process
Research and Publication Ethics
Article Processing Charges
Awards
Testimonials
Author Services
Initiatives
Sciforum
MDPI Books
Preprints.org
Scilit
SciProfiles
Encyclopedia
JAMS
Proceedings Series
About
Overview
Contact
Careers
News
Press
Blog
Sign In / Sign Up Submit
Search for Articles:
Title / Keyword
Author / Affiliation / Email
Journal
All Journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica (AMH)
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine (ARM)
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation (ASI)
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing (BDCC)
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C (Journal of Carbon Research)
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies (Clean Technol.)
Climate
Clinical and Translational Neuroscience (CTN)
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation (CMD)
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction (CMTR)
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology (CIMB)
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation (DHI)
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates (DDC)
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications (ESA)
Eng
Engineering Proceedings
Entropic and Disordered Matter (EDM)
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal (EBJ)
European Journal of Investigation in Health, Psychology and Education (EJIHPE)
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional (Fractal Fract)
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums (FCLAM)
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease (GUCDD)
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences (IJCS)
International Journal of Environmental Medicine (IJEM)
International Journal of Environmental Research and Public Health (IJERPH)
International Journal of Financial Studies (IJFS)
International Journal of Medical Devices (IJMD)
International Journal of Molecular Sciences (IJMS)
International Journal of Neonatal Screening (IJNS)
International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)
International Journal of Plant Biology (IJPB)
International Journal of Topology
International Journal of Translational Medicine (IJTM)
International Journal of Turbomachinery, Propulsion and Power (IJTPP)
International Medical Education (IME)
Inventions
IoT
ISPRS International Journal of Geo-Information (IJGI)
J
Journal of Aesthetic Medicine (J. Aesthetic Med.)
Journal of Ageing and Longevity (JAL)
Journal of CardioRenal Medicine (JCRM)
Journal of Cardiovascular Development and Disease (JCDD)
Journal of Clinical & Translational Ophthalmology (JCTO)
Journal of Clinical Medicine (JCM)
Journal of Composites Science (J. Compos. Sci.)
Journal of Cybersecurity and Privacy (JCP)
Journal of Dementia and Alzheimer's Disease (JDAD)
Journal of Developmental Biology (JDB)
Journal of Experimental and Theoretical Analyses (JETA)
Journal of Eye Movement Research (JEMR)
Journal of Functional Biomaterials (JFB)
Journal of Functional Morphology and Kinesiology (JFMK)
Journal of Fungi (JoF)
Journal of Genome Biotechnology and Genetics (JGBG)
Journal of Gerontology and Geriatrics (JGG)
Journal of Imaging (J. Imaging)
Journal of Innovation
Journal of Intelligence (J. Intell.)
Journal of Interdisciplinary Research Applied to Medicine (JDReAM)
Journal of Low Power Electronics and Applications (JLPEA)
Journal of Manufacturing and Materials Processing (JMMP)
Journal of Marine Science and Engineering (JMSE)
Journal of Market Access & Health Policy (JMAHP)
Journal of Mind and Medical Sciences (JMMS)
Journal of Molecular Pathology (JMP)
Journal of Nanotheranostics (JNT)
Journal of Nuclear Engineering (JNE)
Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)
Journal of Parks
Journal of Personalized Medicine (JPM)
Journal of Pharmaceutical and BioTech Industry (JPBI)
Journal of Phytomedicine
Journal of Respiration (JoR)
Journal of Risk and Financial Management (JRFM)
Journal of Sensor and Actuator Networks (JSAN)
Journal of Superintelligence
Journal of the American Podiatric Medical Association (JAPMA)
Journal of the Oman Medical Association (JOMA)
Journal of Theoretical and Applied Electronic Commerce Research (JTAER)
Journal of Vascular Diseases (JVD)
Journal of Xenobiotics (JoX)
Journal of Zoological and Botanical Gardens (JZBG)
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction (MAKE)
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications (MCA)
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols (MPs)
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction (MTI)
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA (ncRNA)
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care (PHC)
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science (QuBS)
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics (RSEE)
Religions
Remote Sensing
Reports
Reproductive Medicine (Reprod. Med.)
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine (RJPM)
Ruminants
Safety
Sci
Scientia Pharmaceutica (Sci. Pharm.)
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal (SIUJ)
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease (TropicalMed)
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal (WEVJ)
Youth
Zoonotic Diseases
Mathematics
Article Type
All Article Types
Article
Review
Communication
Editorial
Abstract
Book Review
Brief Communication
Brief Report
Case Report
Clinicopathological Challenge
Comment
Commentary
Concept Paper
Conference Report
Correction
Creative
Data Descriptor
Discussion
Entry
Essay
Expression of Concern
Extended Abstract
Field Guide
Giants in Urology
Guidelines
Hypothesis
Interesting Images
Letter
New Book Received
Obituary
Opinion
Patent Summary
Perspective
Proceeding Paper
Project Report
Protocol
Registered Report
Reply
Retraction
Short Note
Study Protocol
Systematic Review
Technical Note
Tutorial
Urology around the World
Viewpoint
All Article Types Search
Advanced Search
Section
All Sections
A: Algebra and Logic
B: Geometry and Topology
C: Mathematical Analysis
C1: Difference and Differential Equations
C2: Dynamical Systems
C3: Real Analysis
C4: Complex Analysis
D: Statistics and Operational Research
D1: Probability and Statistics
D2: Operations Research and Fuzzy Decision Making
E: Applied Mathematics
E1: Mathematics and Computer Science
E2: Control Theory and Mechanics
E3: Mathematical Biology
E4: Mathematical Physics
E5: Financial Mathematics
E6: Functional Interpolation
General
All Sections
Special Issue
All Special Issues
Mathematics: 10th Anniversary
Advance in Mathematical Methods for Space Dynamics and Spacecraft Systems Engineering
Advance in Modeling, Cooperative Control, and Decision-Making Method for the Collective Large-Scale Intelligent Systems
Advanced Applications with Mathematical Modeling in Operations and Supply Chain Management
Advanced Mathematical Methods in Intelligent Multimedia: Security and Applications, 2nd Edition
Advanced Mathematical Methods in Theoretical Physics
Advanced Mathematical Methods: Theory and Applications
Advanced Methods of Polynomial Ideal Computation
Advancements in Mathematical Modeling and Numerical Simulation for Civil Engineering Applications
Advances in Algebraic Structures: Representation Theory and Lie Groups
Advances in Behavioral Decision Analytics and Informatics
Advances in Convex Analysis and Inequalities
Advances in Differential and Difference Equations with Applications
Advances in Differential and Difference Equations with Applications 2019
Advances in Elliptic Equations and Their Applications
Advances in Machine Learning Applied to Intelligent Systems and Data Analytics, 2nd Edition
Advances in Mathematical Analysis with Applications
Advances in Mathematical Inequalities and Applications
Advances in Mathematical Methods for Economy and Sustainable Development Goals
Advances in Nonlinear Spectral Theory
Advances in Probability and Statistics: Emerging Trends and Real-World Applications
Advances in Proportional-Integral-Derivative-Based Control of Dynamic Systems: Theory and Applications
Advances in singularities throughout Mathematics: Algebra, Topology, Geometry, Analysis, Number Theory, Combinatorics and Cryptography
Advances in Study of Quantum Groups
Advances on Complex Analysis
Advances on Complex Analysis, 2nd Edition
AI-Augmented Software Engineering
Algebraic and Geometric Topology
Application of Artificial Intelligence and Control Theory
Application of Optimization in Production, Logistics, Inventory, Supply Chain Management and Block Chain
Applications of Algebra, Geometry, and Optimization to Control Theory, 2nd Edition
Applications of Modern Mathematical Methods in Geosciences
Applied Algebraic Methods in Cryptography
Applied Analysis of Ordinary Differential Equations 2018
Applied and Computational Statistics
Applied Cryptography and Information Security with Application
Applied Functional Analysis and Applications
Applied Functional Analysis and Its Applications
Applied Mathematics and Mechanics
Applied Mathematics and Mechanics 2017
Artificial Intelligence in Education
Bayesian Predictive Inference and Related Asymptotics—Festschrift for Eugenio Regazzini's 75th Birthday
Beyond Quantum Physics, and Computation
Bioinformatics and Computational Biology
Biologically Inspired Computing, 2nd Edition
Challenges in STEM Education
Chaos and Randomness of Discrete Dynamical Systems: Their Use in Applied Science
Cognitive, Behavioral and Affective Variables Involved in Mathematics Education: Learning and Competence Development
Combinatorial and Algebraic Structures in Words
Complex and Contact Manifolds II
Computational Methods and Application in Machine Learning
Computational Methods and Application in Machine Learning, 2nd Edition
Computational Methods in Analysis and Applications
Computational Methods in Analysis and Applications,
3rd Edition
Computational Multiscale Methods on Nanotechnology
Computational Spectroscopy
Computer Algebra in Scientific Computing
Control and Optimal Control Theory of Possibly Degenerate Differential Equations
Current Trends on Monomial and Binomial Ideals
Data Driven Decision-Making Under Uncertainty (D3U), 2nd Edition
Data Science Education: Recent Advances and Future Challenges
Data-Driven Artificial Intelligence and Optimization for Real-World Applications
Data-Driven or AI-Driven Optimization Algorithms and Their Applications
Decision Making and Its Applications
Decomposability of Tensors
Designing Tasks within Dynamic and Interactive Mathematics Learning Environments
Development of Multiphase Computational Fluid Dynamics
Difference Equations and Discrete Dynamical Systems: Theory and Applications
Differential Geometry
Differential Geometry of Special Mappings
Differential-Algebraic Equations: Stability, Control and Applications
Digital Transformation of Mathematics Education
Discrete Optimization: Theory, Algorithms, and Applications
Evolutionary Algorithms in Intelligent Systems
Evolutionary Computation
Examples and Counterexamples in Mathematical Sciences
Feature Papers in Functional Analysis and Applications
Fixed Point Theorems and Applications
Fixed Point Theory
Fractional Calculus in Natural and Social Sciences
Fractional Calculus: Theory and Applications
Fractional Differential and Difference Equations
Fractional Integrals and Derivatives: “True” versus “False” II
Fractional Order Systems
Fuzzy Mathematics
General Algebraic Structures 2020
Geometry of Numbers
Geometry, Representation Theory and Number Theory: Recent Applications in Physics
Harmonic Analysis
Highlights of Research in the Didactics of Mathematics: The Insider's Perspective
Homological and Homotopical Algebra and Category Theory
Human-Computer Interaction: New Horizons
Inequalities
Inequalities III
Information Security and Cloud Computing
Information Theory Applied in Scientific Computing
Intelligent Detection and Application
International Perspectives for Technology Applications in Mathematics Education
Iterative Methods for Solving Nonlinear Equations and Systems
Lie Theory and Its Applications
Machine Learning in Manufacturing: Digital Twins, Optimization and Control
Making AI Materially Better: Mathematics for Contemporary AI Needs
Mathematic Control and Artificial Intelligence
Mathematical Analysis and Analytic Number Theory 2019
Mathematical Analysis and Analytic Number Theory 2020
Mathematical Analysis and Boundary Value Problems II
Mathematical and Computational Intelligence Techniques in Decision Making Processes
Mathematical and Computational Methods for Image Processing and Pattern Recognition
Mathematical and Computational Modelling in Empirical and Applied Science
Mathematical Application of Heterogeneous Knowledge for Sustainable Planning Decisions
Mathematical Economics and Its Applications
Mathematical Finance
Mathematical Game Theory
Mathematical Inequalities with Applications
Mathematical Logic and Its Applications 2020
Mathematical Method and Application of Machine Learning
Mathematical Methods and Models in Epidemiology, 2nd Edition
Mathematical Methods and Models in Robust Nonlinear Control
Mathematical Methods and Models in Software Engineering
Mathematical Methods and Models in Software Engineering, 2nd Edition
Mathematical Methods in Network Security
Mathematical Methods on Intelligent Decision Support Systems
Mathematical Modelling and Control Strategies for System Biotechnology
Mathematical Optimization & Evolutionary Computing
Mathematical physics
Mathematical Physics and Quantum Information
Mathematical Prediction Models Applied to Health Management
Mathematical Sociology
Mathematical Strategy Theory
Mathematical Theories and Models in Environmental Science
Mathematics and Applications
Mathematics and Applications, 2nd Edition
Mathematics and Computer Science-Driven Innovations in Web3
Mathematics of Quantum Uncertainty
Mathematics on Automation Control Systems
Mathematics on Partial Differential Equations
Microlocal and Time-Frequency Analysis
Modern Finite Element Methods
Multi-Criteria Decision Making Methods and Their Applications
Multiple Criteria Decision Making
New Advance of Data Driven Optimization and AI—in Honor of Prof.Dr. Kai-Tai Fang
New Advances in Mathematical Analysis and Functional Analysis
New Advances in Stability Research of Nonlinear Systems: From Asymptotic Stability to Predefined-Time Stability
New Directions on Model Predictive Control
New Insights in Algebra, Discrete Mathematics and Number Theory II
New Paradigms and Trends in Quantitative Ecology
New Progress in General Topology and Its Applications
New Trends in Applications of Orthogonal Polynomials and Special Functions
New Trends in Complex Analysis Researches
New Trends in Computational Methods and Stochastic Modelling in Scientific Machine Learning
New Trends in Function Spaces and Partial Differential Equations: Theory and Applications to Physical Processes
Nonlinear Analysis Using Fuzzy Mathematics
Nonlinear Functional Analysis and Its Applications
Numerical Analysis and Computational Science
Numerical Linear Algebra with Applications
Numerical Methods
Numerical Methods for Partial Differential Equations
Numerical Optimization and Applications
Operators of Fractional Calculus and Their Applications
Optimal Control and Management of Infectious Diseases
Optimization for Decision Making
Optimization Methods in Engineering Mathematics
Optimization Theory, Method and Application
Optimization Theory, Variational Methods for Applied Mathematics
Optimization with Engineering Applications: Heuristics, Meta-Heuristics and Hyper-Heuristics
Probability, Statistics & Symmetry, 2nd edition
Progress in Mathematical Ecology
Quantitative Methods for Social Sciences
Quantitative Methods for Social Sciences, 2nd Edition
Recent Advances in Fixed Point Theory and Its Applications
Recent Advances in Fractional Calculus and Its Applications
Recent Advances in Functional Analysis and Matrix Theory
Recent Advances in Game and Decision Theory: Structures, Models, Applications and Software Implementation
Recent Advances in STEM Education
Recent Advances in the Theory, Numerical Analysis, and Applications of Fractional Calculus
Recent Developments in the Theory and Applications of Fractional Calculus
Recent Developments in Theoretical and Applied Mathematics
Recent Developments in Wavelet Transforms and Their Applications
Recent Developments of Function Spaces and Their Applications II
Recent Trends on Orthogonal Polynomials: Approximation Theory and Applications
Reviews in Mathematics and Applications
Selected Papers from the Innovative STEM Education
Selected Papers from the International Symposium on Computer, Consumer and Control (IS3C2020)
Set-Valued Analysis II
Set-Valued Analysis, 3rd Edition
Special Functions and Applications
Special Functions with Applications
Stability Analysis for Hybrid Systems
Stability Problems
State-of-the-Art Mathematical Applications in Asia-Pacific Area
State-of-the-Art Mathematical Applications in Europe
Statistical Methods in Economics
Statistical Simulation and Computation II
Stochastic Processes with Applications
Stochastic Processes: Theory and Applications
Theoretical Methods and Applications of the Large Language Models
Theoretical Modeling and Computational Aspects on Sustainability: Financial and Socio-Economic Implications
Theory and Application of Algebraic Combinatorics, 2nd Edition
Time and Time Dependence in Quantum Mechanics
Topological Modeling
Uncertainty Quantification Techniques in Statistics, Machine Learning and FinTech
Using Artificial Neural Networks to Address Complex Problems
All Special Issues
Volume 11
Issue 6
Number
Page
Logical Operator Operator
AND
OR
Search Text
Search Type
All fields
Title
Abstract
Keywords
Authors
Affiliations
Doi
Full Text
References
add_circle_outline
remove_circle_outline Search
Journals
Mathematics
Volume 11
Issue 6
10.3390/math11061481
Submit to this Journal Review for this Journal Propose a Special Issue
► ▼ Article Menu
Article Menu
Academic Editor Ximeng Liu
Recommended Articles
Related Info Link
Google Scholar
More by Authors Links
on DOAJ
Stănică, G. Cosmin
Anghelescu, P.
on Google Scholar
Stănică, G. Cosmin
Anghelescu, P.
on PubMed
Stănică, G. Cosmin
Anghelescu, P.
Article Views 3832
Citations 23
Table of Contents
Abstract
Introduction
Basic Concepts on Cellular Automata and Cryptography
Materials and Methods of the Proposed Cryptographic Algorithm
Testing and Results
Discussion
Conclusions
Author Contributions
Funding
Data Availability Statement
Acknowledgments
Conflicts of Interest
References 
Altmetric share Share announcement Help format_quote Cite question_answer Discuss in SciProfiles
Need Help?
Support
Find support for a specific problem in the support section of our website.
Get Support
Feedback
Please let us know what you think of our products and services.
Give Feedback
Information
Visit our dedicated information section to learn more about MDPI.
Get Information
clear
JSmol Viewer
clear
first_page
Download PDF
settings
Order Article Reprints
Font Type:
Arial Georgia Verdana
Font Size:
Aa Aa Aa
Line Spacing:
  
Column Width:
  
Background:
Open Access Article
Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata
by
George Cosmin Stănică 
George Cosmin Stănică
SciProfiles Scilit Preprints.org Google Scholar *  
and
Petre Anghelescu 
Petre Anghelescu
SciProfiles Scilit Preprints.org Google Scholar *  
Department of Electronics, Computers and Electrical Engineering, University of Pitesti, 110040 Pitesti, Romania *
Authors to whom correspondence should be addressed.
Mathematics 2023, 11(6), 1481; https://doi.org/10.3390/math11061481
Submission received: 17 February 2023 / Revised: 13 March 2023 / Accepted: 16 March 2023 / Published: 17 March 2023
(This article belongs to the Section E1: Mathematics and Computer Science)
Download keyboard_arrow_down
Download PDF
Download PDF with Cover
Download XML
Download Epub
Browse Figures            
Versions Notes
Article Views
Citations -
Abstract
The theory and application of cellular automata (CA) for a stream cipher-based encryption principle are presented in this study. Certain fundamental transformations are developed based on CA theory regarding decentralized computation for modeling different system's behavior. The changes governing state transitions rely on simple evolution rules, which can easily be translated into functions using logic operators. A class of linear hybrid cellular automata (LHCA) based on rules 90 and 150 is used to implement these functions. Symmetric key systems theory is the foundation of the suggested algorithm. The algorithm functions use the proprieties provided by the LHCA evolution in order to convert plain text into cipher text and vice versa, in each case starting from the same initial state of the system and performing the same number of steps for each operation. Cellular automata's parallel information processing property, in addition to their regular and dynamical structure, makes hardware implementation of such schemes best suited for VLSI implementation. Testing of the proposed algorithm was performed by developing both software and hardware solutions. Hardware implementation of the presented cryptosystem was developed using VHDL hardware description language and a FPGA device (XILINX Spartan3E XC3S500E). Design and software simulations have been carried out using the C# programming language.
Keywords:
dynamical systems; cellular automata; cryptography; cryptosystems; stream ciphers; biologically inspired systems; reconfigurable computing; symmetric encryption
MSC:
68Q80; 37B15; 68P25; 94A60; 68W35
1. Introduction
The digitalization of our society is drastically altering the way computer systems are used. A vast proportion of the population is always connected to the Internet using various services. At the same time, we are always vulnerable to attacks: our sensitive data may be stolen, edited, or deleted. In the last two years, the use of online services such as communication, payments and digital data exchange has increased significantly due to the pandemic. In addition, a considerable number of companies have adopted remote working. The spread of blockchain technology, especially in cryptocurrency, is another major aspect that we should consider due to the sensitive data exchanged in this kind of communication. Cybersecurity becomes more and more crucial now, when information is becoming the driving force of society. Therefore, it seems reasonable to assume that secure communication is becoming increasingly important in our everyday lives.
Today's society's requirement for communications is increasingly high and the need for speed and security is also very high. Implicitly, it is vital that these communications are secured and fast, and these attributes can only be provided by the correct and effective implementation and integration of cryptographic algorithms. Currently, the strength of cryptographic algorithms based on bio-inspired systems (e. g., cellular automata) lies in the ease of software simulation and hardware implementation due to their properties: local connectivity, simple components and regular structure. It is essential, therefore, to develop cryptographic solutions able to cope with the communication requirements of today (and of the near future)—especially concerning wireless communications in cellular networks and in computer networks, where very high-speed data communication is expected (starting at 11 Mbps and rising up to 11 Gbps). Of course, due to the complexity of this field, from a theoretical point of view, there are still many aspects that need to be analyzed, studied and structured.
As the Internet of Things (IoT) continues to grow, the situation is expected to worsen in the coming years. These devices have unique characteristics that pose new security challenges, and traditional security measures are often inadequate. The Mirai botnet, for example, used vulnerable consumer devices such as IP cameras to launch large-scale Distributed Denial of Service (DDoS) attacks.
Moreover, cybersecurity is now a pressing concern for fields beyond computer science that rely on digital devices and services for critical functions. This includes e-health, medicine, robotics, power and water supply plants, smart cities, and other critical infrastructure. The digital transformation of medicine has increased its exposure to cybersecurity risks, as medical devices such as surgical assistants and implants are increasingly connected and vulnerable to attacks.
The goal of this paper is to design and implement a stream cipher algorithm, which is one of the fastest encryption procedures nowadays. The fact that data are encrypted as they stream rather than being stored in the system's memory is the most crucial feature of stream ciphers, which offer the speed of encryption. Stream cipher techniques are widely used in various practical applications, such as the A5 algorithm in GSM communications and the E0 encryption system in Bluetooth specifications. These procedures rely on a secret key, known only to the parties involved, and a public algorithm, typically a sequence generator. By utilizing these elements, stream cipher procedures are able to generate long sequences of seemingly random bits known as keystream sequences, which are in fact pseudorandom sequences used for cryptographic purposes.
The paper is divided into five sections, which are organized as follows. The next section presents an overview of cellular automata concepts and defines the idea of the ways in which a particular class of hybrid CA can be used for stream encryption. Section 3 presents the proposed algorithm of data encryption through the software and hardware implementations developed and also experimental results of both solutions are discussed here. Testing of the proposed algorithm using statistical and graphical analysis, along with the results discussion, is presented in Section 4 and Section 5. Section 6 concludes the study by outlining future research objectives and potential extensions to this work.
2. Basic Concepts on Cellular Automata and Cryptography
2.1. Overview of Cellular Automata Concept
This section presents an overview of cellular automata theory followed by a description of cryptographic techniques based on different variations of CA with references to the literature regarding this concept.
Mathematicians S. Ulam and John von Neumann [ 1] first proposed the cellular automaton (the two initially calling those cellular spaces) as a model in the 1940s in order to build a self-reproducing machine [ 2]. However, research in this field has gained momentum, especially in the last 20 years. This is due to the increasing complexity of hardware systems and software applications. The initiator of the field of cellular automata is Von Neumann (the creator of the sequential computing machine model).
Cellular automata refer to discrete dynamical systems that operate on a regular lattice, relying on straightforward local interactions among their components, thereby eliminating the need for partial differential equations [ 3]. These automata exhibit a series of distinct characteristics, including discreteness in terms of space, time, and values, as well as local interaction, homogeneity, and parallel evolution [ 4]. The wide potential CA have for modeling complicated systems, despite their simplicity, is the primary driver of their usage in so many areas. A CA is defined entirely by specifying the neighborhood and the evolution function of the states as presented in Figure 1 below. 
Figure 1. Structure of cellular automata.
Additionally, considering the length, at least theoretically infinite, of the number of cells that make up the automaton, it is also necessary to specify the size and the boundary conditions for its extremities (for the marginal cells). These elements must be specified regardless of the type of cellular automaton used. There are also accepted cases in which not all cells have the same type of neighborhood or the same evolution rule, a situation in which the evolution rules and neighborhoods must be specified for each cell that is part of the automaton [ 5].
The organizational similarity between cellular automata and natural systems, made up of a large number of simple components with interactions at the local level, allows the modeling of simple natural systems with self-organization. In the case of cellular automata, one way to define self-organization is the property of the system to manifest a global order at the spatial, temporal, or spatio-temporal level. This global order arises only based on a local “order” and the presence of basins of attraction indicates the likelihood of these features appearing. CA is a bio-inspired paradigm with deep involvement in soft computing and hardware for large classes of applications. These methods have been effectively employed in simulating biological and physical systems, and more recently in developing parallel and distributed algorithms, including those used for data encryption [ 6].
2.2. Related Research about the Usage of Cellular Automata in Cryptography
The use of cryptography techniques is essential for any secure communication. Secret and public key systems are the two primary types of encryptions used today. Reference [ 7] provides a thorough description of the present and developing encryption methods used in both types of systems. A promising cryptography technique consists of applying cellular automata as a primitive of an encryption system.
For modeling many applications including data encryption, researchers and scientists from various domains have taken advantage of the CA paradigm of local information, decentralized control and universal computing. Reference [ 8] provides a good summary of all key cryptography techniques. CA have been used in both symmetric-key and public-key cryptography. The first proposal for a stream CA-based encryption algorithm was released by Wolfram [ 9], and subsequently developed by Tommassini et al. [ 10] and more recently by Seredynski et al. [ 11]. Research has also been conducted on the different cryptography applications fields, including image encryption presented in [ 12, 13] and also in one of the increasingly used domains such as blockchain and device networks.
Wolfram was the first to use cellular automata (CA) to encrypt messages, employing a uniform one-dimensional CA and rule 30 to construct pseudorandom number sequences. At each simulation step, the communications are encrypted and decrypted by combining them directly with the state of the CA. Other solutions based on CA used for data encryption are presented in [ 14, 15]. Wolfram has investigated cellular automata using empirical observations and simulations [ 16]. In the case of two-state, three-neighborhood cellular automata (CA), the evolution of the ( i)th cell can be expressed as a function of the current states of the ( i − 1)th, ( i)th, and ( i + 1)th cells, as demonstrated by Equation (1). Each cell concurrently changes its state based on nearby cells at a specific moment.
s i(t + 1) = f(s i−1(t), s i(t), s i+1(t)).
(1)
The equation shown above employs f to denote the combinational logic used in a two-state three-neighborhood cellular automaton. Such a cellular automaton has eight unique neighborhood configurations (as there are 2 3 = 8 possible combinations of the states of the three neighboring cells) and 256 unique mappings to the subsequent state, each of which corresponds to a distinct cellular automaton rule [ 17].
Typically, a cell's surroundings are assumed to consist of a few nearby cells. This results in the issue of cells that are located on the grid's edge. A CA must define an input for the missing neighbor in order to determine what occurs at the outermost cells. When utilizing a cyclic-boundary cellular automaton, the value from the outermost cell on the opposite end of the array is utilized. Conversely, in the case of a null-boundary cellular automaton, these neighboring cells are assigned a constant value of “0” (or ground, in the context of hardware implementation).
Starting from the point of simplifying the design and modeling of complex systems, many CA improvements have been developed. Evolution rules are referred to as linear if they solely use XOR logic, resulting in linear CA. Another helpful version of these systems, where the cells follow a combination of rules, is called a hybrid cellular automaton. The rule set of this type of CA, applied as a linear variant, can be analyzed through matrix algebra [ 18].
Although typical applications for cellular automata reside in modeling, game theory [ 19], pseudorandom signal generation [ 20] and image processing [ 21], the main goal of this research is to develop and implement solutions for data encryption. In this sense, cellular automata are used as a mathematical model of complex natural systems composed of simple components [ 22].
Recent research has focused on the development of encryption techniques using cellular automata, a field of study that has shown great promise in enhancing the security of data transmission. One such study by Li et al. [ 23] compared three different cellular automata-based encryption schemes and determined that all three were effective in achieving high security with fast encryption and decryption times. However, the study also highlighted the need for further research to optimize these schemes for practical use.
Another study presented in [ 24] tested the performance of cellular automata-based encryption methods using a special class of reversible rules. The authors suggested that cellular automata encryption techniques show an enhanced throughput in a high-performance system compared with other algorithms.
In addition, several articles have explored the use of cellular automata-based encryption in combination with other technologies, such as chaos theory and neural networks. For example, study [ 25] proposed a hybrid encryption method that combined cellular automata with neural networks and determined that this approach was highly effective in achieving secure data transmission.
Complex behavior and self-organization phenomena appear in their case through the cooperation of the parts, which follow physical, chemical, and other local laws. It should be noted that cellular automata also have this characteristic: they have simple components that evolve according to local rules, usually simple. However, their global behavior is complex and could present self-organization phenomena.
3. Materials and Methods of the Proposed Cryptographic Algorithm
This part begins with a description of LHCA, the core component of the system, and continues with software where features, development process and acquired results are described. The section ends with the presentation of the entire proposed cryptosystem composed of the software application and the hardware implementation.
3.1. Description of Used LHCA
This study focuses on one-dimensional cellular automata that utilize linear transition rules and have a three-neighborhood structure. Additionally, the cellular automata considered in this work are hybrid, meaning that different cells within the structure follow distinct transition rules. The automata also have a null-boundary structure, which means that cells adjacent to the outermost cells in the structure have null content.
The transition function of cellular automata is often referred to as the “rule” by most authors, and this naming convention follows the system of numbering introduced by Wolfram. The output bits of each 2 N potential input are taken into account when determining the rule's number, which is subsequently translated into decimal form. An instance of a cellular automaton rule can be represented by a function that takes input strings of 111, 110, …, 000 and generates output bits, such as rule 90, which outputs bits 0, 1, 0, 1, 1, 0, 1, 0, respectively, for the corresponding inputs.
The LHCA built using rules 90 and 150 serves as the foundation for the cryptographic method proposed in this work. Only LHCA with states “0, 1” are taken into account. The following is an expression for the equivalent state transition logic of rules:
s i (t + 1) = s i−1(t) ⨁ s i+1(t); rule 90;
(2)
s i (t + 1) = s i−1(t) ⨁ s i(t) ⨁ s i+1(t); rule 150.
(3)
Equations (2) and (3) show that at time t + 1, the content of the i-th cell depends on the content at time t of either two different cells (rule 90) or three different cells (rule 150), with i = 1, …, L, where L is the length of the automaton. Moreover, the state of the automaton at time t is the binary content of the L cells at such an instant. Table 1 displays the subsequent condition of a cell for rules 90 and 150. This condition applies to the middle cell of the trio shown at the top of the table.
Table 1. Evolution rules that determine the LHCA future states. 
Additionally, CA may be defined using a transition matrix (S-matrix). Equation (4) displays the CA general transition matrix, where S i stands for the rule that is taken into consideration for the i-th cell. Stage i follows rule 90 if S i = 0 and rule 150 in all other cases. The unpredictability of the patterns produced can be quantified by the matrix analysis. This matrix is capable of producing pseudorandom sequences.
T CA = [ s 1 1 0 … 0 0 1 s 2 1 … 0 0 0 1 s 3 … 0 0 … … … … … … 0 0 0 … s n − 1 1 0 0 0 … 1 s n ] .
(4)
This hybrid cellular automaton's combination of rules 90 and 150 is a crucial component of its operating concept. When the cellular automaton operates independently, it can achieve a maximal cycle length with no zero state. This cycle can be calculated using the formula 2 n − 1, where n is the number of bytes. Table 2 displays the hybrid design required to produce a CA with the maximum cycle length (3 ≤ n ≤ 14).
Table 2. Combination of evolution rules. 
In the table above, we assumed that the rule was presented in hexadecimal format, with “0” standing for a rule 90 cell and “1” for a rule 150 cell.
The following figure ( Figure 2) provides an example of an 8-stage LHCA based on the building guidelines stated in Table 2. The null-boundary condition helps the cellular automaton increase cycle lengths. Additionally, CA have drawn a lot of interest since each cell is only connected to its neighbors. As a result, a CA is easily expandable by adding more cells to the end of it. 
Figure 2. Example of 8-bit LHCA with 90/150 rules.
The arrangement of the rules causes the composed cellular automata to exhibit chaotic behavior, meaning that even a small change in the initial state of the system can lead to vastly different outcomes, though taken separately it seems that their behavior is simple. Below is an example of the chaotic behavior that can result from this combination of rules in which we consider starting with an initial state of all cells in 0, except for one cell, which is a 1.
As the system evolves according to the rules, patterns emerge that can be very different depending on which cell was chosen to be the initial one. The pattern changes dramatically after just a few generations, even though the initial state only differs by a single cell. This is a result of the complex and unpredictable interactions between the two rules. This demonstrates the sensitivity of the system to its initial conditions, and that even small differences can result in vastly different outcomes.
Furthermore, the choice of the rule 90/150 was based on our previous work presented in [ 17], in which we investigated their behavior as pseudorandom number generator by testing the produced sequences using NIST Statistical Test. The positive results obtained after the test represent a factor that encouraged us in choosing these rules.
The stream cipher (decipher) procedure can be defined as follows:
Set up encryption/decryption key (initial state of LHCA);
Perform XOR operation between character and LHCA state;
Evolve LHCA state;
Repeat steps 2 and 3 for N times (N = number of iterations through LHCA).
After the first stage, the XOR operation will be performed between the new state of the LHCA and the result of the previous operation. The result of the final XOR operation constitutes the processed message (encrypted/decrypted data) depending on the operation performed.
The algorithm is designed to perform identical number of steps for both encryption and decryption, provided that the private key (initial state of the system) is the same. The same operations are performed in both processes, the only difference being the initial data provided to the system (plain text or cipher text). The system works by taking the initial data and performing the XOR operations with the cellular automata states. The only requirements to decrypt data are to use the same initial state of the CA as well as to perform the same number of iterations through the CA as was previously performed on encryption process.
The plain text is encrypted and decrypted at the byte level, so the characters are instantaneously changed to cipher text. The LHCA data encryption and decryption mechanism is shown in Figure 3. 
Figure 3. General encryption/decryption process.
The algorithm operates by encrypting each message character. The ASCII code of the character and the system key (initial state of CA) are XORed together in the first phase. The following stages involve changing the CA state and performing a new XOR operation on the prior result and the CA's new state. A certain number of iterations of this operation are performed, provided that the number is less than the maximum cycle length of the LHCA used, which is 255.
The encryption and decryption procedures are based on the data to be processed and the initial state of the LHCA. For this, a character is first converted into binary using the equivalent ASCII code. Then, XOR operation is performed on the binary value of the character and the LHCA states for a predetermined number of steps. An example of this procedure, with 3 iterations, is presented below:
Encryption Procedure
Character to encrypt: S (ASCII code for S = 53 (16) = 01010011 (2));
States of LHCA: S1 = 10110101 (initial state); S2 = 10100101; S3 = 10011101.
R1 = S ⊕ S1 = 01010011 ⊕ 10110101 = 11100110;
R2 = R1 ⊕ S2 = 11100110 ⊕ 10100101 = 01000011;
R3 = R2 ⊕ S3 = 01000011 ⊕ 10011101 = 11011110 = ▐.
▐ = Ciphertext equivalent of character S.
Decryption Procedure
Character to decrypt: ▐ (ASCII code for ▐ = DE (16) = 11011110 (2));
States of LHCA: S1 = 10110101 (initial state); S2 = 10100101; S3 = 10011101.
R1 = ▐ ⊕ S1 = 11011110 ⊕ 10110101 = 01101011;
R2 = R1 ⊕ S2 = 01101011 ⊕ 10100101 = 11001110;
R3 = R2 ⊕ S3 = 11001110 ⊕ 10011101 = 01010011 = S.
S = Plaintext equivalent of character ▐.
The essential element of these ciphers is the creation of the key stream. The randomization of the stream key completely destroys any statistical features present in the message. In this system, the key is defined by the initial state of the LHCA and the number of iterations applied to the CA. The key of the system, depicted in Figure 3, consists of state Si (initial state) and n (number of iterations). The proposed encryption algorithm was designed for 8-bit encryption, and therefore, an LHCA with 8 cells was used to generate the key.
To evaluate and study this encryption method, applications were developed for both hardware and software. CA-based models are extremely parallelizable since the new state in each time step is defined entirely by the preceding time step's neighboring state [ 26]. As a result, we can use parallel processing methods such as FPGA boards that are used to create encryption at the hardware level.
3.2. Software Implementation
The software application was created to enable the simulation of the chosen CA as well as the execution of the encryption method over various input data. Cellular automata simulation and encryption/decryption are the two sections of the program.
A variety of functions are offered by the CA simulation area presented in Figure 4 below to enable various configurations of the hybrid cellular automaton that is employed. In addition to utilizing the optimal evolution rules, it is also possible to input their various combinations to examine the evolution of the CA. Although the encryption algorithm presented here uses an 8-cell CA, the application provides the possibility of choosing the number of cells to simulate, varying from 4 to 10 CA cells. Both the cycle duration and the emergence of the states may be observed and verified. 
Figure 4. Application LHCA simulation area.
The second section provides controls for the encryption/decryption algorithm. The text message is loaded from a file selected by the user through the application window. Once the message is loaded, the user must specify the key of the system by setting the values of the cells in the first section of the application. When this section is activated, the CA is automatically configured as an 8-cell system. After setting the initial configuration, the operation is shown in two fields as follows:
Original message: shows the initial message (plain text or cipher text can be inserted here);
Processed message: shows the final message (encrypted or decrypted in accordance with the original message).
The encryption/decryption process is performed using the appropriate evolution rule (90 or 150) for each stage of the LHCA. This can be achieved using logic expressions of the two rules presented in Equations (2) and (3). For the implementation of LHCA evolution, a different technique was used. First, we encoded the order of the rules in binary form, '0'—for rule 90 and '1'—for rule 150. This allowed combining Equations (2) and (3) in a single Equation (5) that describes the behavior of the entire LHCA.
s i(t + 1) = s i−1(t) ^ [R o(s i) & s i(t)] ^ s i+1(t)],
(5)
where R o(s i) represents the rule applying to the current cell.
The controls provided in this section of the application allow for both encryption and decryption using the fields mentioned earlier. Once the encryption or decryption operation is completed, the fields can be cleared to process new messages. Figure 5 shows an example of encryption in which the original message (plain text) is converted into cipher text using the algorithm. 
Figure 5. Results of the encryption process.
The plain text provided from a text file can be observed in the original message field. The process of encryption is carried out character by character and produces the ciphertext, which is displayed in the processed message field. Similarly, decryption is performed in the same way, starting from an encrypted message and processing it into plain text as shown in Figure 6 below. 
Figure 6. Results of the decryption process.
If the system's initial state (the private key) is the same, the suggested algorithm's uniqueness enables completing the same operation steps for encryption and decryption. The developed system provides an ideal framework for a reasonably detailed CA investigation of emergent properties.
3.3. Hardware Implementation
The suggested cryptosystem's general architecture is built on an FPGA device design, which handles encryption and decryption and a software desktop application, which represents the graphical tool that offers system's users an interface to manage hardware operation [ 27]. It is possible to synthesize logic architectures using several methods, including hardware description languages [ 28].
The C# programming language was used to fully implement the suggested solution and its functionality in the software applications. The hardware system was implemented as an active HDL application and was tested on a FPGA hardware device (XILINX Spartan3E XC3S500E).
Below is a block schematic of the proposed hardware cryptosystem ( Figure 7). While the main (middle) module executes encryption or decryption depending on the kind of message received from the PC, the receiver and transmitter modules manage communication between PC software applications and the FPGA board. 
Figure 7. Hardware system block scheme.
Data from the FPGA chip must be gathered in order to evaluate the cryptosystem that has been built. The board uses a serial RS232 port to connect to the computer at a 9600 Baud rate. After character-by-character processing of the complete message, the FPGA transfers the encryption/decryption data to the PC for analysis. The current state of the eight switches on the board serves as the algorithm key.
The receiver module handles data reception from the computer in byte format and then it sends it further to the encryption/decryption module, which, together with the key, creates the processed message that is delivered to the transmitter module. The way the latter operates is by serializing the message and sending it back to the PC. Global clock (GCLK) sets the communication rate between PC and FPGA. The message to be processed is sent to FPGA from the software application by manually writing it in the appropriate field or by choosing a text file for longer messages. The application interface used to send messages to the FPGA board is presented in Figure 8 below. 
Figure 8. Interface with FPGA board: ( a) Encryption process; ( b) Decryption process.
The tests performed on the hardware system show a plain text sent to the FPGA system from the application to be encrypted. To check the correctness of the obtained result, the encrypted output data were fed back to the system for processing to test whether the original message could be reconstructed. After these steps, the plain text was obtained, proving the correct functionality of the hardware system.
Table 3 details the FPGA resources consumed and system timing for the experimental results of the hardware implementation. The data presented in the following table are based on an 8-bit system that includes modules for encryption, serial transmission, and reception.
Table 3. Overall system resource and time summary. 
Time values from the above table are presented for the processing of one character in the message. The values are influenced by the key and the character to encrypt/decrypt. To test the functionality of the 8-bit LHCA used for encryption, different simulations were performed: simulation of its states evolution ( Figure 9) and simulation of obtained results—encrypted data ( Figure 10). The results are presented below as output waveforms. 
Figure 9. Output waveform for 8-bit 90/150 LHCA (decimal form). 
Figure 10. An 8-bit 90/150 LHCA output waveform for the encryption process (decimal form).
The entire cryptosystem developed in this work and the used FPGA are presented in Figure 11 below. The implementation in reconfigurable hardware makes the proposed cryptographic algorithm more efficient because of the parallelization obtained with the FPGA board and provides more security over the encryption technique due to the difficulty to obtain data from FPGA chip and hardware resources. 
Figure 11. ( a) Entire cryptosystem; ( b) FPGA board.
The hybrid cellular automata with the best statistical properties were analyzed, implemented, tested and evaluated in software and hardware (FPGA). Due to their properties, cellular automata are suitable for hardware implementation, and by using some instruction parallelization algorithms [ 29], increased speeds can be obtained for securing data transmitted in heterogeneous telecommunication networks.
4. Testing and Results
This section focuses on testing the quality of the proposed encryption algorithm. Statistical tests, along with graphical representations, were performed to assess the randomness of the produced results, ending with a discussion about the cryptosystem and applications developed in this work.
For analyzing cryptographic algorithm results, we used a series of statistical tests provided by the National Institute of Standards and Technology (NIST) to check whether the produced sequence complies with the requirements of a pseudorandom number generator [ 30]. The NIST Test Suite is a collection of 15 statistical tests designed to assess the randomness of binary sequences generated by cryptographic random or pseudorandom number generators, regardless of whether they are hardware- or software-based. These tests are designed to detect various forms of non-randomness that may be present in a sequence.
To evaluate the randomness of a sequence, a range of statistical tests can be employed. These tests are designed to identify non-randomness in the sequence and produce a test statistic value as a function of the data. Based on the test statistic value, a p-value is calculated, which represents the probability that a perfect random number generator would produce a less random sequence than the one tested. A significance level (α) is determined, and if the p-value is greater than or equal to α, the sequence is considered random, while a p-value of less than α indicates non-randomness.
In this work, α has been chosen to be 0.01. An α of 0.01 indicates that it is expected that one sequence in 100 sequences to be rejected. If a p-value is equal to or greater than 0.01, it implies that the sequence can be considered random with a confidence level of 99%. Each test has certain specifications for its usage. The most important of these is the input size recommendation that specifies the length in bits of the tested sequences. We used an encryption result of our proposed algorithm consisting of about 1,000,000 bits that were tested by splitting them into ten bitstreams. That means that 10 streams of 100,000 bits were tested. For each of the 15 tests, the software provides the p-value and the proportion of passing sequences (pass rate). Table 4 presents the results of the performed tests.
Table 4. Statistical testing results using NIST software. 
National Institute of Standards and Technology tests asses the most significant proprieties that may indicate that a sequence is potentially random, namely uniformity, scalability and consistency. The test results indicate that the sequence has the propriety of being possibly random. For better visualization of the obtained algorithm results, graphical representations were produced by analyzing the rate of diffusion of original text throughout the ASCII interval. Results are presented in Figure 12 below. 
Figure 12. Dispersion of encrypted data over ASCII interval ( a) Plaintext; ( b) Ciphertext.
The graph above depicts the distribution of original data (left side) and encrypted data (right side) across ASCII intervals. It is worth noting that the dispersion of the encrypted data is consistent across all intervals, implying that encrypted text is dispersed almost evenly throughout all ASCII intervals, not only alphanumeric.
Another important aspect of the system consists in the number of iterations produced to generate the pseudorandom keystream sequence. The iterations are a crucial part of the cryptosystem meaning that their number affects the efficiency of the algorithm in terms of security provided by the system. No iterations or low number of iterations provides little or no efficiency in security of the system, thus a higher number of iterations are required to provide security. This is because the generated key stream is used to encrypt the plaintext, and if the key stream is not sufficiently unpredictable or large, it can be more susceptible to attacks.
In Table 5, we present an example consisting in a statistical analysis using NIST Tests on the system results produced using a small number of iterations in comparison to a higher number of iterations.
Table 5. Statistical testing of system with different number of iterations (NIST software). 
We can observe that performing a low number of iterations results in failure of the statistical tests, thus indicating that the produced sequence does not offer pseudorandom characteristics resulting in low security provided by the cryptosystem.
Therefore, while we prioritize efficiency in generating the pseudorandom numbers, we also agree that the number of iterations affects the overall efficiency of the cryptosystem in terms of security.
5. Discussion
According to NIST's guidelines, the minimum requirement for passing each statistical test is around 8 for a sample size of 10 binary sequences. Randomness is a characteristic that can be defined and described in terms of probability. Many statistical tests are available to determine the randomness of a sequence by detecting the presence or absence of patterns. If a pattern is detected, it indicates that the sequence is not random. However, since there are numerous tests available to evaluate randomness, no particular finite set of tests is considered to be “complete.” Concerning that and the above results, we can state that our algorithm produces potentially random data.
Various types of stream ciphers are currently in use across different networks, many of which were created as part of the eSTREAM initiative. Among the most popular ones are Grain and Trivium, which feature distinct specifications such as key length. Subsequent to these designs, a group of stream ciphers based on cellular automata (CA) were developed, including CAvium, CAR30, and FResCA, among others. CAvium is a modification of Trivium that relies on a hybrid CA to replace Trivium's shift registers, incorporating a range of rules (30, 60, 90, 120, 150, 180, 210, 240) to enhance the nonlinearity of keystream generation.
CAR30 is another stream cipher based on cellular automata, featuring a three-neighborhood CA rule that draws inspiration from Grain-128. This cipher serves as a pseudorandom number generator in a modified version of the Grain algorithm. FResCA is another CA-based stream cipher, also inspired by Grain, but with a distinct design. While other CA-based stream ciphers rely solely on three-neighborhood CA, FResCA uses a hybrid approach that combines both three- and four-neighborhood CA. A more recent CA stream cipher algorithm, known as CARPenter and described in [ 31], employs a non-linear mixing function and combines a non-linear CA with a maximum length null-boundary linear CA.
All the stream ciphers mentioned above except CAvium had their inspiration from the design of Grain-128, a lightweight stream cipher that had high throughput and fast initialization, which is still developed during the lightweight stream cipher competition initiated by NIST in response to the increasing number of connected IoT devices.
In comparison to these existing ciphers, our algorithm has a relatively low computational complexity due to the simplicity of the rules used, which allows for easy implementation logic in hardware structures without usage of numerous resources. This results in faster encryption and decryption times. A comparison between our proposed scheme of encryption and other similar ones is presented in Table 6.
Table 6. Comparison with related stream ciphers. 
Due to differences in implementation, the values depicted in the table may exhibit minor variations. Nevertheless, the results point out the advantages of our cipher, which notably reduces the number of required rules and the radius of the neighborhood while maintaining the same properties as other ciphers. This represents a key highlight of our approach.
Another advantage a relatively small key size, which makes it easier to transmit and store. An attack on the system assumes not only finding the initial state of the system to decipher the message, but also the number of iterations performed from that state through the LHCA. Therefore, even if the proposed system only uses 8-bit LHCA to perform encryption and decryption, it provides security through the two components—the initial state of the CA and the number of evolution steps—that make up the system secret keys.
6. Conclusions
This paper demonstrated data encryption and decryption solutions using linear models based on cellular automata theory with a combination of rules 90 and 150. It is interesting that these encryption techniques based on discrete, dynamical systems with simple evolution rules which employ keystream sequences generated by pseudorandom generators have a direct cryptographic application in stream ciphers.
Since the hardware implementation of the established CA-based models is simple and particularly suitable for reconfigurable hardware logic (e.g., FPGA), the encryption approach is suitable for cryptographic systems in various practical applications. It is suited for innovations where time execution is essential, such as in communication systems with high transmission rates. Still, it could also be integrated into most of telecommunication networks.
The cryptosystem developed in this work will be enhanced so that the CA may operate with 16 or 32 cells. Due to the intrinsic properties of the CA, a 16-bit or 32-bit CA can still have a simple structure while operating the same way (e. g., all CA cells are updated at the same time, and this is possible in a single clock). Furthermore, we will focus on incorporating this encryption algorithm into numerous applications (e.g., telemedicine) and data communication channels, such as the Internet. Another research extension to this system focuses on improving the speed of encryption by integrating data directly into LHCA.
Author Contributions
The authors contributed equally to this work, from conceptualization of the problem to the software and hardware implementations that were used to analyze and test our proposed solution and to the funding acquisition that supported this research. All authors have read and agreed to the published version of the manuscript.
Funding
This work was supported by a grant of the Ministry of Research, Innovation and Digitization, CNCS/CCCDI–UEFISCDI, project number PN-III-P2-2.1-PED-2021-3669, within PNCDI III, contract number 693PED/28.06.2022.
Data Availability Statement
No new data were created or analyzed in this study. Data sharing is not applicable to this article.
Acknowledgments
We would like to acknowledge the usage of the NIST Statistical Test Suite as a contribution to this work. The software was used to test our proposed algorithm output against the random number generator theory.
Conflicts of Interest
The authors declare no conflict of interest.
References
Von Neumann, J. Theory of Self-Reproducing Automata; University of Illinois: Urbana, IL, USA, 1966. [ Google Scholar]
Sipper, M. Evolution of Parallel Cellular Machines—The Cellular Programming Approach; Springer: Berlin/Heidelberg, Germany, 2004. [ Google Scholar]
Cho, S.J.; Choi, U.S.; Kim, H.D.; Hwang, Y.H.; Kim, J.G. Analysis of 90/150 Two Predecessor Nongroup Cellular Automata. In Proceedings of the Cellular Automata, 8th International Conference on Cellular Automata for Research and Industry (ACRI '08), Yokohama, Japan, 23–26 September 2008; Springer: Berlin/Heidelberg, Germany, 2008. [ Google Scholar] [ CrossRef]
Wolfram, S. Random Sequence Generation by Cellular Automata. Adv. Appl. Math. 1986, 7, 123–169. [ Google Scholar] [ CrossRef]
Kozlov, V.; Tatashev, A.; Yashina, M. Elementary Cellular Automata as Invariant under Conjugation Transformation or Combination of Conjugation and Reflection Transformations, and Applications to Traffic Modeling. Mathematics 2022, 10, 3541. [ Google Scholar] [ CrossRef]
Anghelescu, P. Parallel Optimization of Program Instructions Using Genetic Algorithms. Comput. Mater. Contin. 2021, 67, 3293–3310. [ Google Scholar] [ CrossRef]
Aumasson, J.P. Serious Cryptography; No Starch Press: San Francisco, CA, USA, 2018. [ Google Scholar]
Menezes, A.; van Oorschot, P.; Vanstone, S. Handbook of Applied Cryptography; CRC Press: Boca Raton, MA, USA, 1996. [ Google Scholar]
Wolfram, S. Cryptography with Cellular Automata. In Proceeding of the Advances in Cryptology: Crypto '85, Linz, Austria, 9–11 April 1985. [ Google Scholar] [ CrossRef]
Tomassini, M.; Perrenoud, M. Stream Ciphers with One and Two-Dimensional Cellular Automata. In Proceedings of the Parallel Problem Solving from Nature—PPSN VI, Paris, France, 18–20 September 2000. [ Google Scholar] [ CrossRef]
Seredynski, F.; Bouvry, P.; Zomaya, A.Y. Cellular Programming and Symmetric Key Cryptography Systems. In Proceedings of Genetic and Evolutionary Computation—GECCO 2003, Chicago, IL, USA, 12–16 July 2003. [ Google Scholar] [ CrossRef]
Kumar, A.; Raghava, N.S. An efficient image encryption scheme using elementary cellular automata with novel permutation box. Multimed. Tools Appl. 2021, 80, 21727–21750. [ Google Scholar] [ CrossRef]
Anghelescu, P.; Stirbu, C. Cellular automata based algorithm for image density classification task. In Proceedings of the 2014 6th International Conference on Electronics, Computers and Artificial Intelligence (ECAI), Bucharest, Romania, 23–25 October 2014. [ Google Scholar] [ CrossRef]
Hortensius, P.; McLeod, R.; Card, H. Parallel random number generation for VLSI systems using cellular automata. IEEE Trans. Comput. 1989, 38, 1466–1473. [ Google Scholar] [ CrossRef]
Nandi, S.; Kar, B.; Chaudhuri, P.P. Theory and applications of cellular automata in cryptography. IEEE Trans. Comput. 1994, 43, 1346–1357. [ Google Scholar] [ CrossRef]
Wolfram, S. A New Kind of Science; Wolfram Media: Champaign, IL, USA, 2002. [ Google Scholar]
Anghelescu, P.; Ionita, S.; Sofron, E. Encryption Technique with Programmable Cellular Automata (ETPCA). J. Cell. Autom. 2010, 5, 79–105. [ Google Scholar]
Treml, L.M.; Bartocci, E.; Gizzi, A. Modeling and Analysis of Cardiac Hybrid Cellular Automata via GPU-Accelerated Monte Carlo Simulation. Mathematics 2021, 9, 164. [ Google Scholar] [ CrossRef]
Wang, W.; Zhou, Y.; Liu, J.; Sun, B. On-Street Cruising for Parking Model in Consideration with Gaming Elements and Its Impact Analysis. Mathematics 2022, 10, 3423. [ Google Scholar] [ CrossRef]
Anghelescu, P.; Ionita, S.; Sofron, E. FPGA Implementation of Hybrid Additive Programmable Cellular Automata Encryption Algorithm. In Proceedings of 8th International Conference on Hybrid Intelligent Systems, Barcelona, Spain,, 10–12 September 2008. [ Google Scholar] [ CrossRef]
Angulo, K.V.; Gil, D.G.; Espitia, H.E. Modeling and Numerical Validation for an Algorithm Based on Cellular Automata to Reduce Noise in Digital Images. Computers 2022, 11, 46. [ Google Scholar] [ CrossRef]
Perestrelo, S.A.; Grácio, M.C.; Ribeiro, N.D.A.; Lopes, L.M. A Multi-Scale Network with Percolation Model to Describe the Spreading of Forest Fires. Mathematics 2022, 10, 588. [ Google Scholar] [ CrossRef]
Li, X.-W.; Kim, S.-T.; Wang, Q.-H. Designing Three-Dimensional Cellular Automata Based Video Authentication With an Optical Integral Imaging Generated Memory-Distributed Watermark. IEEE J. Sel. Top. Signal Process. 2017, 11, 1200–1212. [ Google Scholar] [ CrossRef]
Nanda, S.K.; Mohanty, S.; Pattnaik, P.K.; Sain, M. Throughput Optimized Reversible Cellular Automata Based Security Algorithm. Electronics 2022, 11, 3190. [ Google Scholar] [ CrossRef]
Devipriya, M.; Sreenivasan, M.; Brindha, M. Reconfigurable Architecture for Image Encryption Using a Three-Layer Artificial Neural Network, IETE J. Res. 2022, 2022, 1–14. [ Google Scholar] [ CrossRef]
Anghelescu, P.; Sofron, E.; Ionita, S. VLSI Implementation of High-Speed Cellular Automata Encryption Algorithm. In Proceedings of International Semiconductor Conference (CAS), Sinaia, Romania, 15 October–17 September 2007. [ Google Scholar] [ CrossRef]
Anghelescu, P. FPGA implementation of programmable cellular automata encryption algorithm for network communications. Comput. Syst. Sci. Eng. 2016, 31, 361–370. [ Google Scholar]
Harshala, P.; Shyam Sunder, P. Cellular automata for built in test pattern generation and test response analyzer. Int. J. Electr. Electron. Res. 2 2014, 2, 44–50. [ Google Scholar]
Dascălu, M. Cellular Automata Hardware Implementations—An Overview. Sci. Technol. 2016, 19, 360–368. [ Google Scholar]
Rukhin, A.; Soto, J.; Nechvatal, J.; Smid, M.; Barker, E.; Leigh, S.; Levenson, M.; Vangel, M.; Banks, D.; Heckert, N.; et al. A Statistical Test Suite for Random and PseudoRandom Number Generators for Cryptographic Applications. Natl. Inst. Stand.Technol. Spec. Publ. 2005, 2005, 800–822. [ Google Scholar]
John, A.; Lakra, R.; Jose, J. On the design of stream ciphers with Cellular Automata having radius = 2. Cryptol. Eprint Arch. 2020, 2020, 327. [ Google Scholar]
Figure 1. Structure of cellular automata.
Figure 2. Example of 8-bit LHCA with 90/150 rules.
Figure 3. General encryption/decryption process.
Figure 4. Application LHCA simulation area.
Figure 5. Results of the encryption process.
Figure 6. Results of the decryption process.
Figure 7. Hardware system block scheme.
Figure 8. Interface with FPGA board: ( a) Encryption process; ( b) Decryption process.
Figure 9. Output waveform for 8-bit 90/150 LHCA (decimal form).
Figure 10. An 8-bit 90/150 LHCA output waveform for the encryption process (decimal form).
Figure 11. ( a) Entire cryptosystem; ( b) FPGA board.
Figure 12. Dispersion of encrypted data over ASCII interval ( a) Plaintext; ( b) Ciphertext.
Table 1. Evolution rules that determine the LHCA future states.
Table 2. Combination of evolution rules.
Table 3. Overall system resource and time summary.
Table 4. Statistical testing results using NIST software.
Table 5. Statistical testing of system with different number of iterations (NIST software).
| NIST Statistical Test | 3 Iterations || 20 Iterations || | ^^ | p-Value | Pass Rate | p-Value | Pass Rate | | --- | --- | --- | --- | --- | | Frequency (monobits) | 0.000164 | Failure | 0.122325 | 10/10 | | Block frequency | 0.000025 | Failure | 0.911413 | 9/10 | | Runs | 0.000000 | Failure | 0.991468 | 10/10 | | Longest run of one in a block | 0.000469 | Failure | 0.911413 | 10/10 | | Rank | 0.000245 | Failure | 0.350485 | 10/10 | | FFT | 0.000054 | Failure | 0.739918 | 10/10 | | Non-overlapping template | 0.000000 | Failure | 0.035174 | 9/10 | | Overlapping template | 0.000000 | Failure | 0.739918 | 10/10 | | Linear complexity | 0.000047 | Failure | 0.213309 | 9/10 | | Serial 1 | 0.000000 | Failure | 0.534146 | 10/10 | | Serial 2 | 0.000000 | Failure | 0.122325 | 10/10 | | Universal | undefined | undefined | undefined | undefined | | Approximate Entropy | 0.000122 | Failure | 0.122325 | 9/10 | | Cumulative Sum (forward) | 0.000000 | Failure | 0.534146 | 10/10 | | Cumulative Sum (reverse) | 0.000000 | Failure | 0.122325 | 10/10 |
Table 6. Comparison with related stream ciphers.
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
© 2023 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license ( https://creativecommons.org/licenses/by/4.0/).
Share and Cite
      
MDPI and ACS Style
Stănică, G.C.; Anghelescu, P. Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics 2023, 11, 1481. https://doi.org/10.3390/math11061481
AMA Style
Stănică GC, Anghelescu P. Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics. 2023; 11(6):1481. https://doi.org/10.3390/math11061481
Chicago/Turabian Style
Stănică, George Cosmin, and Petre Anghelescu. 2023. "Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata" Mathematics 11, no. 6: 1481. https://doi.org/10.3390/math11061481
APA Style
Stănică, G. C., & Anghelescu, P. (2023). Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics, 11(6), 1481. https://doi.org/10.3390/math11061481
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
Article Metrics
Yes
Citations
Crossref
17
Scopus
23
Web of Science
9
Google Scholar
[click to view]
No
Article Access Statistics
Created with Highcharts 4.0.4 Article access statistics Article Views 11. Mar 12. Mar 13. Mar 14. Mar 15. Mar 16. Mar 17. Mar 18. Mar 19. Mar 20. Mar 21. Mar 22. Mar 23. Mar 24. Mar 25. Mar 26. Mar 27. Mar 28. Mar 29. Mar 30. Mar 31. Mar 1. Apr 2. Apr 3. Apr 4. Apr 5. Apr 6. Apr 7. Apr 8. Apr 9. Apr 10. Apr 11. Apr 12. Apr 13. Apr 14. Apr 15. Apr 16. Apr 17. Apr 18. Apr 19. Apr 20. Apr 21. Apr 22. Apr 23. Apr 24. Apr 25. Apr 26. Apr 27. Apr 28. Apr 29. Apr 30. Apr 1. May 2. May 3. May 4. May 5. May 6. May 7. May 8. May 9. May 10. May 11. May 12. May 13. May 14. May 15. May 16. May 17. May 18. May 19. May 20. May 21. May 22. May 23. May 24. May 25. May 26. May 27. May 28. May 29. May 30. May 31. May 1. Jun 2. Jun 3. Jun 4. Jun 5. Jun 6. Jun 7. Jun 8. Jun 0k 1k 2k 3k 4k 5k
For more information on the journal statistics, click here.
Multiple requests from the same IP address are counted as one view.
Zoom | Orient | As Lines | As Sticks | As Cartoon | As Surface | Previous Scene | Next Scene
Cite
Export citation file: BibTeX | EndNote | RIS
MDPI and ACS Style
Stănică, G.C.; Anghelescu, P. Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics 2023, 11, 1481. https://doi.org/10.3390/math11061481
AMA Style
Stănică GC, Anghelescu P. Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics. 2023; 11(6):1481. https://doi.org/10.3390/math11061481
Chicago/Turabian Style
Stănică, George Cosmin, and Petre Anghelescu. 2023. "Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata" Mathematics 11, no. 6: 1481. https://doi.org/10.3390/math11061481
APA Style
Stănică, G. C., & Anghelescu, P. (2023). Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics, 11(6), 1481. https://doi.org/10.3390/math11061481
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
clear
Mathematics, EISSN 2227-7390, Published by MDPI
RSS Content Alert
Further Information
Article Processing Charges Pay an Invoice Open Access Policy Contact MDPI Jobs at MDPI
Guidelines
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
MDPI Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
Follow MDPI
LinkedIn Facebook X 
Subscribe to receive issue release notifications and newsletters from MDPI journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies
Climate
Clinical and Translational Neuroscience
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications
Eng
Engineering Proceedings
Entropic and Disordered Matter
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal
European Journal of Investigation in Health, Psychology and Education
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences
International Journal of Environmental Medicine
International Journal of Environmental Research and Public Health
International Journal of Financial Studies
International Journal of Medical Devices
International Journal of Molecular Sciences
International Journal of Neonatal Screening
International Journal of Orofacial Myology and Myofunctional Therapy
International Journal of Plant Biology
International Journal of Topology
International Journal of Translational Medicine
International Journal of Turbomachinery, Propulsion and Power
International Medical Education
Inventions
IoT
ISPRS International Journal of Geo-Information
J
Journal of Aesthetic Medicine
Journal of Ageing and Longevity
Journal of CardioRenal Medicine
Journal of Cardiovascular Development and Disease
Journal of Clinical & Translational Ophthalmology
Journal of Clinical Medicine
Journal of Composites Science
Journal of Cybersecurity and Privacy
Journal of Dementia and Alzheimer's Disease
Journal of Developmental Biology
Journal of Experimental and Theoretical Analyses
Journal of Eye Movement Research
Journal of Functional Biomaterials
Journal of Functional Morphology and Kinesiology
Journal of Fungi
Journal of Genome Biotechnology and Genetics
Journal of Gerontology and Geriatrics
Journal of Imaging
Journal of Innovation
Journal of Intelligence
Journal of Interdisciplinary Research Applied to Medicine
Journal of Low Power Electronics and Applications
Journal of Manufacturing and Materials Processing
Journal of Marine Science and Engineering
Journal of Market Access & Health Policy
Journal of Mind and Medical Sciences
Journal of Molecular Pathology
Journal of Nanotheranostics
Journal of Nuclear Engineering
Journal of Otorhinolaryngology, Hearing and Balance Medicine
Journal of Parks
Journal of Personalized Medicine
Journal of Pharmaceutical and BioTech Industry
Journal of Phytomedicine
Journal of Respiration
Journal of Risk and Financial Management
Journal of Sensor and Actuator Networks
Journal of Superintelligence
Journal of the American Podiatric Medical Association
Journal of the Oman Medical Association
Journal of Theoretical and Applied Electronic Commerce Research
Journal of Vascular Diseases
Journal of Xenobiotics
Journal of Zoological and Botanical Gardens
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics
Religions
Remote Sensing
Reports
Reproductive Medicine
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine
Ruminants
Safety
Sci
Scientia Pharmaceutica
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal
Youth
Zoonotic Diseases
Select options
[-] accountaudit Accounting and Auditing [-] acoustics Acoustics [-] amh Acta Microbiologica Hellenica [-] actuators Actuators [-] adhesives Adhesives [-] admsci Administrative Sciences [-] adolescents Adolescents [-] arm Advances in Respiratory Medicine [-] aerobiology Aerobiology [-] aerospace Aerospace [-] agriculture Agriculture [-] agriengineering AgriEngineering [-] agrochemicals Agrochemicals [-] agronomy Agronomy [-] ai AI [-] aichem AI Chemistry [-] aieng AI for Engineering [-] aieduc AI in Education [-] aimed AI in Medicine [-] aimater AI Materials [-] aisens AI Sensors [-] air Air [-] algorithms Algorithms [-] allergies Allergies [-] alloys Alloys [-] analog Analog [-] analytica Analytica [-] analytics Analytics [-] anatomia Anatomia [-] anesthres Anesthesia Research [-] animals Animals [-] antibiotics Antibiotics [-] antibodies Antibodies [-] antioxidants Antioxidants [-] applbiosci Applied Biosciences [-] applmech Applied Mechanics [-] applmicrobiol Applied Microbiology [-] applnano Applied Nano [-] applsci Applied Sciences [-] asi Applied System Innovation [-] appliedchem AppliedChem [-] appliedmath AppliedMath [-] appliedphys AppliedPhys [-] aquacj Aquaculture Journal [-] architecture Architecture [-] arthropoda Arthropoda [-] arts Arts [-] astronautics Astronautics [-] astronomy Astronomy [-] atmosphere Atmosphere [-] atoms Atoms [-] audiolres Audiology Research [-] automation Automation [-] axioms Axioms [-] bacteria Bacteria [-] batteries Batteries [-] behavsci Behavioral Sciences [-] beverages Beverages [-] BDCC Big Data and Cognitive Computing [-] biochem BioChem [-] bioengineering Bioengineering [-] biologics Biologics [-] biology Biology [-] blsf Biology and Life Sciences Forum [-] biomass Biomass [-] biomechanics Biomechanics [-] biomed BioMed [-] biomedicines Biomedicines [-] biomedinformatics BioMedInformatics [-] biomimetics Biomimetics [-] biomolecules Biomolecules [-] biophysica Biophysica [-] bioresourbioprod Bioresources and Bioproducts [-] biosensors Biosensors [-] biosphere Biosphere [-] biotech BioTech [-] birds Birds [-] blockchains Blockchains [-] brainsci Brain Sciences [-] buildings Buildings [-] businesses Businesses [-] carbon C [-] cancers Cancers [-] cardiogenetics Cardiogenetics [-] cardiovascmed Cardiovascular Medicine [-] catalysts Catalysts [-] cells Cells [-] ceramics Ceramics [-] challenges Challenges [-] ChemEngineering ChemEngineering [-] chemistry Chemistry [-] chemproc Chemistry Proceedings [-] chemosensors Chemosensors [-] children Children [-] chips Chips [-] civileng CivilEng [-] cleantechnol Clean Technologies [-] climate Climate [-] ctn Clinical and Translational Neuroscience [-] clinbioenerg Clinical Bioenergetics [-] clinpract Clinics and Practice [-] clockssleep Clocks & Sleep [-] coasts Coasts [-] coatings Coatings [-] colloids Colloids and Interfaces [-] colorants Colorants [-] commodities Commodities [-] complexities Complexities [-] complications Complications [-] compounds Compounds [-] computation Computation [-] csmf Computer Sciences & Mathematics Forum [-] computers Computers [-] condensedmatter Condensed Matter [-] conservation Conservation [-] constrmater Construction Materials [-] cmd Corrosion and Materials Degradation [-] cosmetics Cosmetics [-] covid COVID [-] cmtr Craniomaxillofacial Trauma & Reconstruction [-] crops Crops [-] cryo Cryo [-] cryptography Cryptography [-] crystals Crystals [-] culture Culture [-] cimb Current Issues in Molecular Biology [-] curroncol Current Oncology [-] dairy Dairy [-] data Data [-] dentistry Dentistry Journal [-] dermato Dermato [-] dermatopathology Dermatopathology [-] designs Designs [-] diabetology Diabetology [-] diagnostics Diagnostics [-] dietetics Dietetics [-] digital Digital [-] dhi Digital Health and Innovation [-] disabilities Disabilities [-] diseases Diseases [-] diversity Diversity [-] dna DNA [-] drones Drones [-] ddc Drugs and Drug Candidates [-] dynamics Dynamics [-] earth Earth [-] ecologies Ecologies [-] econometrics Econometrics [-] economies Economies [-] education Education Sciences [-] electricity Electricity [-] electrochem Electrochem [-] electronicmat Electronic Materials [-] electronics Electronics [-] ecm Emergency Care and Medicine [-] encyclopedia Encyclopedia [-] endocrines Endocrines [-] energies Energies [-] esa Energy Storage and Applications [-] eng Eng [-] engproc Engineering Proceedings [-] edm Entropic and Disordered Matter [-] entropy Entropy [-] eesp Environmental and Earth Sciences Proceedings [-] environremediat Environmental Remediation [-] environments Environments [-] epidemiologia Epidemiologia [-] epigenomes Epigenomes [-] ebj European Burn Journal [-] ejihpe European Journal of Investigation in Health, Psychology and Education [-] famsci Family Sciences [-] fermentation Fermentation [-] fibers Fibers [-] fintech FinTech [-] fire Fire [-] fishes Fishes [-] fluids Fluids [-] foods Foods [-] forecasting Forecasting [-] forensicsci Forensic Sciences [-] forests Forests [-] fossstud Fossil Studies [-] foundations Foundations [-] fractalfract Fractal and Fractional [-] freshwater Freshwater [-] fuels Fuels [-] future Future [-] fclam Future Collections, Libraries, Archives, and Museums [-] futureinternet Future Internet [-] futurepharmacol Future Pharmacology [-] futuretransp Future Transportation [-] galaxies Galaxies [-] games Games [-] gases Gases [-] gastroent Gastroenterology Insights [-] gastrointestdisord Gastrointestinal Disorders [-] gastronomy Gastronomy [-] gels Gels [-] genealogy Genealogy [-] genes Genes [-] geographies Geographies [-] geohazards GeoHazards [-] geomatics Geomatics [-] geometry Geometry [-] geosciences Geosciences [-] geotechnics Geotechnics [-] geriatrics Geriatrics [-] germs Germs [-] glacies Glacies [-] gucdd Gout, Urate, and Crystal Deposition Disease [-] grasses Grasses [-] green Green [-] greenhealth Green Health [-] hardware Hardware [-] healthcare Healthcare [-] hearts Hearts [-] hemato Hemato [-] hematolrep Hematology Reports [-] heritage Heritage [-] histories Histories [-] horticulturae Horticulturae [-] hospitals Hospitals [-] humanities Humanities [-] humans Humans [-] hydrobiology Hydrobiology [-] hydrogen Hydrogen [-] hydrology Hydrology [-] hydropower Hydropower [-] hygiene Hygiene [-] immuno Immuno [-] industries Industries [-] idr Infectious Disease Reports [-] inflammj Inflammation Journal [-] informatics Informatics [-] information Information [-] infrastructures Infrastructures [-] inorganics Inorganics [-] insects Insects [-] instruments Instruments [-] iic Intelligent Infrastructure and Construction [-] ijcs International Journal of Cognitive Sciences [-] ijem International Journal of Environmental Medicine [-] ijerph International Journal of Environmental Research and Public Health [-] ijfs International Journal of Financial Studies [-] ijmd International Journal of Medical Devices [-] ijms International Journal of Molecular Sciences [-] IJNS International Journal of Neonatal Screening [-] ijom International Journal of Orofacial Myology and Myofunctional Therapy [-] ijpb International Journal of Plant Biology [-] ijt International Journal of Topology [-] ijtm International Journal of Translational Medicine [-] ijtpp International Journal of Turbomachinery, Propulsion and Power [-] ime International Medical Education [-] inventions Inventions [-] IoT IoT [-] ijgi ISPRS International Journal of Geo-Information [-] J J [-] jaestheticmed Journal of Aesthetic Medicine [-] jal Journal of Ageing and Longevity [-] jcrm Journal of CardioRenal Medicine [-] jcdd Journal of Cardiovascular Development and Disease [-] jcto Journal of Clinical & Translational Ophthalmology [-] jcm Journal of Clinical Medicine [-] jcs Journal of Composites Science [-] jcp Journal of Cybersecurity and Privacy [-] jdad Journal of Dementia and Alzheimer's Disease [-] jdb Journal of Developmental Biology [-] jeta Journal of Experimental and Theoretical Analyses [-] jemr Journal of Eye Movement Research [-] jfb Journal of Functional Biomaterials [-] jfmk Journal of Functional Morphology and Kinesiology [-] jof Journal of Fungi [-] jgbg Journal of Genome Biotechnology and Genetics [-] jgg Journal of Gerontology and Geriatrics [-] jimaging Journal of Imaging [-] joi Journal of Innovation [-] jintelligence Journal of Intelligence [-] jdream Journal of Interdisciplinary Research Applied to Medicine [-] jlpea Journal of Low Power Electronics and Applications [-] jmmp Journal of Manufacturing and Materials Processing [-] jmse Journal of Marine Science and Engineering [-] jmahp Journal of Market Access & Health Policy [-] jmms Journal of Mind and Medical Sciences [-] jmp Journal of Molecular Pathology [-] jnt Journal of Nanotheranostics [-] jne Journal of Nuclear Engineering [-] ohbm Journal of Otorhinolaryngology, Hearing and Balance Medicine [-] jop Journal of Parks [-] jpm Journal of Personalized Medicine [-] jpbi Journal of Pharmaceutical and BioTech Industry [-] jphytomed Journal of Phytomedicine [-] jor Journal of Respiration [-] jrfm Journal of Risk and Financial Management [-] jsan Journal of Sensor and Actuator Networks [-] superintelligence Journal of Superintelligence [-] japma Journal of the American Podiatric Medical Association [-] joma Journal of the Oman Medical Association [-] jtaer Journal of Theoretical and Applied Electronic Commerce Research [-] jvd Journal of Vascular Diseases [-] jox Journal of Xenobiotics [-] jzbg Journal of Zoological and Botanical Gardens [-] journalmedia Journalism and Media [-] kidneydial Kidney and Dialysis [-] kinasesphosphatases Kinases and Phosphatases [-] knowledge Knowledge [-] labmed LabMed [-] laboratories Laboratories [-] land Land [-] languages Languages [-] laws Laws [-] life Life [-] lights Lights [-] limnolrev Limnological Review [-] lipidology Lipidology [-] liquids Liquids [-] literature Literature [-] livers Livers [-] logics Logics [-] logistics Logistics [-] lae Low-Altitude Economy [-] lubricants Lubricants [-] lymphatics Lymphatics [-] make Machine Learning and Knowledge Extraction [-] machines Machines [-] macromol Macromol [-] magnetism Magnetism [-] magnetochemistry Magnetochemistry [-] marinedrugs Marine Drugs [-] materials Materials [-] materproc Materials Proceedings [-] mca Mathematical and Computational Applications [-] mathematics Mathematics [-] medsci Medical Sciences [-] msf Medical Sciences Forum [-] medicina Medicina [-] medicines Medicines [-] membranes Membranes [-] merits Merits [-] metabolites Metabolites [-] metals Metals [-] meteorology Meteorology [-] methane Methane [-] mps Methods and Protocols [-] metrics Metrics [-] metrology Metrology [-] micro Micro [-] microbiolres Microbiology Research [-] microelectronics Microelectronics [-] micromachines Micromachines [-] microorganisms Microorganisms [-] microplastics Microplastics [-] microwave Microwave [-] minerals Minerals [-] mining Mining [-] modelling Modelling [-] mmphys Modern Mathematical Physics [-] molbank Molbank [-] molecules Molecules [-] multimedia Multimedia [-] mti Multimodal Technologies and Interaction [-] muscles Muscles [-] nanoenergyadv Nanoenergy Advances [-] nanomanufacturing Nanomanufacturing [-] nanomaterials Nanomaterials [-] ndt NDT [-] network Network [-] neuroglia Neuroglia [-] neuroimaging Neuroimaging [-] neurolint Neurology International [-] neurosci NeuroSci [-] nitrogen Nitrogen [-] ncrna Non-Coding RNA [-] nursrep Nursing Reports [-] nutraceuticals Nutraceuticals [-] nutrients Nutrients [-] obesities Obesities [-] occuphealth Occupational Health [-] oceans Oceans [-] onco Onco [-] optics Optics [-] oral Oral [-] organics Organics [-] organoids Organoids [-] osteology Osteology [-] oxygen Oxygen [-] pandemics Pandemics [-] parasitologia Parasitologia [-] particles Particles [-] pathogens Pathogens [-] pathophysiology Pathophysiology [-] peacestud Peace Studies [-] pediatrrep Pediatric Reports [-] pets Pets [-] pharmaceuticals Pharmaceuticals [-] pharmaceutics Pharmaceutics [-] pharmacoepidemiology Pharmacoepidemiology [-] pharmacy Pharmacy [-] philosophies Philosophies [-] photochem Photochem [-] photonics Photonics [-] phycology Phycology [-] physchem Physchem [-] psf Physical Sciences Forum [-] physics Physics [-] physiologia Physiologia [-] plants Plants [-] plasma Plasma [-] platforms Platforms [-] pollutants Pollutants [-] polymers Polymers [-] polysaccharides Polysaccharides [-] populations Populations [-] poultry Poultry [-] powders Powders [-] precisoncol Precision Oncology [-] phc Primary and Hospital Care [-] proceedings Proceedings [-] processes Processes [-] prosthesis Prosthesis [-] proteomes Proteomes [-] psychiatryint Psychiatry International [-] psychoactives Psychoactives [-] psycholint Psychology International [-] publications Publications [-] purification Purification [-] qubs Quantum Beam Science [-] quantumrep Quantum Reports [-] quaternary Quaternary [-] radiation Radiation [-] reactions Reactions [-] realestate Real Estate [-] receptors Receptors [-] recycling Recycling [-] rsee Regional Science and Environmental Economics [-] religions Religions [-] remotesensing Remote Sensing [-] reports Reports [-] reprodmed Reproductive Medicine [-] resources Resources [-] rheumato Rheumato [-] risks Risks [-] robotics Robotics [-] rjpm Romanian Journal of Preventive Medicine [-] ruminants Ruminants [-] safety Safety [-] sci Sci [-] scipharm Scientia Pharmaceutica [-] sclerosis Sclerosis [-] seeds Seeds [-] shi Semiconductors and Heterogeneous Integration [-] sensors Sensors [-] separations Separations [-] sexes Sexes [-] signals Signals [-] sinusitis Sinusitis [-] smartcities Smart Cities [-] socsci Social Sciences [-] siuj Société Internationale d'Urologie Journal [-] societies Societies [-] software Software [-] soilsystems Soil Systems [-] solar Solar [-] solids Solids [-] spectroscj Spectroscopy Journal [-] sports Sports [-] standards Standards [-] stats Stats [-] stratsediment Stratigraphy and Sedimentology [-] stresses Stresses [-] surfaces Surfaces [-] surgeries Surgeries [-] std Surgical Techniques Development [-] sustainability Sustainability [-] suschem Sustainable Chemistry [-] sanpp Swiss Archives of Neurology, Psychiatry and Psychotherapy [-] symmetry Symmetry [-] synbio SynBio [-] systems Systems [-] targets Targets [-] taxonomy Taxonomy [-] technologies Technologies [-] telecom Telecom [-] textiles Textiles [-] thalassrep Thalassemia Reports [-] tae Theoretical and Applied Ergonomics [-] therapeutics Therapeutics [-] thermo Thermo [-] timespace Time and Space [-] tomography Tomography [-] tourismhosp Tourism and Hospitality [-] toxics Toxics [-] toxins Toxins [-] transplantology Transplantology [-] traumacare Trauma Care [-] higheredu Trends in Higher Education [-] tph Trends in Public Health [-] tropicalmed Tropical Medicine and Infectious Disease [-] universe Universe [-] urbansci Urban Science [-] uro Uro [-] vaccines Vaccines [-] vehicles Vehicles [-] venereology Venereology [-] vetsci Veterinary Sciences [-] vibration Vibration [-] virtualworlds Virtual Worlds [-] viruses Viruses [-] vision Vision [-] waste Waste [-] water Water [-] welding Welding [-] wild Wild [-] wind Wind [-] women Women [-] world World [-] wevj World Electric Vehicle Journal [-] youth Youth [-] zoonoticdis Zoonotic Diseases
Subscribe
© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated
Disclaimer
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
Legal Notice Terms and Conditions Privacy Policy Privacy Settings Accessibility
We use cookies on our website to ensure you get the best experience.
Read more about our cookies here.
Accept
Share Link
        https://www.mdpi.com/2201388
Copy
clear
Share
https://www.mdpi.com/2201388
clear
Back to Top Top
All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.
You can change your mind at any time by clicking "Privacy Settings" at the bottom of the pages.  
Accept All
Deny
More Information
Powered by Usercentrics Consent Management