> Source: https://www.mdpi.com/2079-9292/14/13/2627

Multi-Layer Cryptosystem Using Reversible Cellular Automata
Next Article in Journal
From Regulation to Reality: A Framework to Bridge the Gap in Digital Health Data Protection
Previous Article in Journal
CaDCR: An Efficient Cascaded Dynamic Collaborative Reasoning Framework for Intelligent Recognition Systems
Journals
Active Journals Find a Journal Journal Proposal Proceedings Series
[
Topics
](https://www.mdpi.com/topics)
Information
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
Open Access Policy Institutional Open Access Program Special Issues Guidelines Editorial Process Research and Publication Ethics Article Processing Charges Awards Testimonials
[
Author Services
](https://www.mdpi.com/authors/english)
Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
About
Overview Contact Careers News Press Blog
Sign In / Sign Up
Notice
You can make submissions to other journals here.
clear
Notice
You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.
Continue Cancel
clear
All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to https://www.mdpi.com/openaccess.
Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.
Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.
Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.
Original Submission Date Received: .
You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled. 
clear zoom_out_map search menu 
Journals
Active Journals
Find a Journal
Journal Proposal
Proceedings Series
Topics
Information
For Authors
For Reviewers
For Editors
For Librarians
For Publishers
For Societies
For Conference Organizers
Open Access Policy
Institutional Open Access Program
Special Issues Guidelines
Editorial Process
Research and Publication Ethics
Article Processing Charges
Awards
Testimonials
Author Services
Initiatives
Sciforum
MDPI Books
Preprints.org
Scilit
SciProfiles
Encyclopedia
JAMS
Proceedings Series
About
Overview
Contact
Careers
News
Press
Blog
Sign In / Sign Up Submit
Search for Articles:
Title / Keyword
Author / Affiliation / Email
Journal
All Journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica (AMH)
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine (ARM)
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation (ASI)
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing (BDCC)
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C (Journal of Carbon Research)
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies (Clean Technol.)
Climate
Clinical and Translational Neuroscience (CTN)
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation (CMD)
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction (CMTR)
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology (CIMB)
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation (DHI)
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates (DDC)
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications (ESA)
Eng
Engineering Proceedings
Entropic and Disordered Matter (EDM)
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal (EBJ)
European Journal of Investigation in Health, Psychology and Education (EJIHPE)
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional (Fractal Fract)
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums (FCLAM)
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease (GUCDD)
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences (IJCS)
International Journal of Environmental Medicine (IJEM)
International Journal of Environmental Research and Public Health (IJERPH)
International Journal of Financial Studies (IJFS)
International Journal of Medical Devices (IJMD)
International Journal of Molecular Sciences (IJMS)
International Journal of Neonatal Screening (IJNS)
International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)
International Journal of Plant Biology (IJPB)
International Journal of Topology
International Journal of Translational Medicine (IJTM)
International Journal of Turbomachinery, Propulsion and Power (IJTPP)
International Medical Education (IME)
Inventions
IoT
ISPRS International Journal of Geo-Information (IJGI)
J
Journal of Aesthetic Medicine (J. Aesthetic Med.)
Journal of Ageing and Longevity (JAL)
Journal of CardioRenal Medicine (JCRM)
Journal of Cardiovascular Development and Disease (JCDD)
Journal of Clinical & Translational Ophthalmology (JCTO)
Journal of Clinical Medicine (JCM)
Journal of Composites Science (J. Compos. Sci.)
Journal of Cybersecurity and Privacy (JCP)
Journal of Dementia and Alzheimer's Disease (JDAD)
Journal of Developmental Biology (JDB)
Journal of Experimental and Theoretical Analyses (JETA)
Journal of Eye Movement Research (JEMR)
Journal of Functional Biomaterials (JFB)
Journal of Functional Morphology and Kinesiology (JFMK)
Journal of Fungi (JoF)
Journal of Genome Biotechnology and Genetics (JGBG)
Journal of Gerontology and Geriatrics (JGG)
Journal of Imaging (J. Imaging)
Journal of Innovation
Journal of Intelligence (J. Intell.)
Journal of Interdisciplinary Research Applied to Medicine (JDReAM)
Journal of Low Power Electronics and Applications (JLPEA)
Journal of Manufacturing and Materials Processing (JMMP)
Journal of Marine Science and Engineering (JMSE)
Journal of Market Access & Health Policy (JMAHP)
Journal of Mind and Medical Sciences (JMMS)
Journal of Molecular Pathology (JMP)
Journal of Nanotheranostics (JNT)
Journal of Nuclear Engineering (JNE)
Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)
Journal of Parks
Journal of Personalized Medicine (JPM)
Journal of Pharmaceutical and BioTech Industry (JPBI)
Journal of Phytomedicine
Journal of Respiration (JoR)
Journal of Risk and Financial Management (JRFM)
Journal of Sensor and Actuator Networks (JSAN)
Journal of Superintelligence
Journal of the American Podiatric Medical Association (JAPMA)
Journal of the Oman Medical Association (JOMA)
Journal of Theoretical and Applied Electronic Commerce Research (JTAER)
Journal of Vascular Diseases (JVD)
Journal of Xenobiotics (JoX)
Journal of Zoological and Botanical Gardens (JZBG)
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction (MAKE)
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications (MCA)
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols (MPs)
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction (MTI)
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA (ncRNA)
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care (PHC)
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science (QuBS)
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics (RSEE)
Religions
Remote Sensing
Reports
Reproductive Medicine (Reprod. Med.)
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine (RJPM)
Ruminants
Safety
Sci
Scientia Pharmaceutica (Sci. Pharm.)
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal (SIUJ)
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease (TropicalMed)
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal (WEVJ)
Youth
Zoonotic Diseases
Electronics
Article Type
All Article Types
Article
Review
Communication
Editorial
Abstract
Book Review
Brief Communication
Brief Report
Case Report
Clinicopathological Challenge
Comment
Commentary
Concept Paper
Conference Report
Correction
Creative
Data Descriptor
Discussion
Entry
Essay
Expression of Concern
Extended Abstract
Field Guide
Giants in Urology
Guidelines
Hypothesis
Interesting Images
Letter
New Book Received
Obituary
Opinion
Patent Summary
Perspective
Proceeding Paper
Project Report
Protocol
Registered Report
Reply
Retraction
Short Note
Study Protocol
Systematic Review
Technical Note
Tutorial
Urology around the World
Viewpoint
All Article Types Search
Advanced Search
Section
All Sections
Artificial Intelligence
Artificial Intelligence Circuits and Systems (AICAS)
Bioelectronics
Circuit and Signal Processing
Computer Science & Engineering
Electrical and Autonomous Vehicles
Electronic Materials, Devices and Applications
Electronic Multimedia
Industrial Electronics
Microelectronics
Microwave and Wireless Communications
Networks
Optoelectronics
Power Electronics
Quantum Electronics
Semiconductor Devices
Systems & Control Engineering
General
All Sections
Special Issue
All Special Issues
Additively Manufactured Flexible RF Structures for Next Generation of Wireless Applications
Advanced Electronic and Photonic Devices from the International Conference on Next-Generation Electronics & Photonics (INGEP 2024)
Advanced in Flexible Electronics and Applications
Advanced Microcontrollers, Intelligent Control, and Edge Computing in Industrial IoT Ecosystems
Advancements in Communication and Sensing Systems through Machine Learning
Advances and Applications in Blockchain Technology
Advances and Development in Image Processing and Pattern Recognition
Advances in Cloud and Distributed System Applications
Advances in Electronics Technology
Advances in Electronics Technology—Selected Papers From the 6th International Conference on Electronics Technology (ICET)
Advances in Electronics, Communication, and Automation
Advances in High-Efficiency AI-Enabled Edge Computing for Distributed Networking Systems
Advances in the Modeling and Simulation of Technical Systems Using Modelica
Advances of Electronics Research from Zhejiang University
Advances on Electronics for Harsh Environments
Application of Computer Vision and Pattern Recognition
Application of Microgrids in Power System
Artificial Intelligence for Virtual, Mixed, and Augmented Reality Content and Interaction
Assistive Technology: Advances, Applications and Challenges
Celebrating the 200th Anniversary of the University of Manchester—Electrical and Electronic Engineering
Celebrating the 85th Anniversary of Beijing Institute of Technology—Electronic Science and Technology
Channeling a Characteristics-Driven New Paradigm for Wireless Communication Security
Converging Platform Technologies: Collaborative Innovations and Future Directions
Digital Intelligence Technology and Applications, 2nd Edition
Electronic Applications and Research in Environmental Protection and Environmental Technology
Emerging Technologies in Intelligent Software Methodologies, Tools, and Techniques (Selected Papers from SoMeT 2023)
Feature Papers
Feature Review Papers in Electronics
Flexible and Wearable Electronics: Design and Applications
Flexible Devices and Optoelectronics Technologies
Flexible Electronics: Sensors, Energy and Health
Fluidic Type Strain/Pressure Sensors for Wearable Electronics and Robotics Applications
Front-End Electronics for Radiation Detectors
Hardware and Software Co-Design in Intelligent Systems
Instrumentation, Noise, Reliability
Intelligent Mobile Robotic Systems: Decision, Planning and Control, 2nd Edition
Intelligent Resource Allocation Methods for Next Generation Wireless Cellular Systems
Interactive, Mobile and Wearable Technologies
Internet of Things (IoT) and Wearable Devices Applications in Healthcare and Disaster Healthcare
Internet of Vehicles (IoV)
IoT Applications for Renewable Energy Management and Control, 2nd Edition
Latest Developments in LED Drivers
LTCC for Space, Imaging, Telecommunication, and Medical Applications
Machine Vision and 3D Sensing in Smart Agriculture
Micro- and Nanotechnology of Wide Bandgap Semiconductors
Microwave/ Millimeter-Wave Devices and MMICs
Multi-Modal Biometrics for Surveillance and Digital Evidence Processing in Smart Cities
Multimodal Data Fusion and Computational Optimization for Intelligent Perception, 2nd Edition
Multimodal Fusion and Its Application
Multimodal Remote Sensing for Wildfires
Nano-materials Based 3D Electronics
Neuromorphic Devices and Brain-Inspired Intelligent Systems: Applications and Prospects
New CMOS Devices and Their Applications
New Insights and Techniques for Neural Networks
New Research in IoT and Applications on Sustainable Smart Farming and Agriculture
Next-Generation Sensing, Computing, and System Engineering for Large-Scale Connected and Automated Vehicle and Transportation: Celebrating the 70th Anniversary of Nanjing University of Aeronautics and Astronautics
Printed and Flexible Electronics
Pulsed Magnetic Fields and Its Applications
Quantum Computation and Its Applications
Recent Advances in Intelligent Systems
Recent Advances in IoT/Blockchain Security and Privacy
Recent Developments and Emerging Trends in Computational Imaging
Recent Developments in Object Tracking and Computer Vision
Second Quantum Revolution: Sensing, Computing, and Transmitting
Selected Paper from Best PhD Thesis Award
Selected Papers from the 2024 International Conference on Science and Engineering of Electronics (ICSEE'2024)
Selected Papers from the Asia Pacific Conference of the Prognostics and Health Management Society 2021
Selected Papers from Young Researchers in Flexible Electronics
Signal Processing and Analysis of Electrical Circuit
Simultaneous Localization and Mapping (SLAM) of Mobile Robots
State-of-the-Art Electronics and Informatics in Australia
State-of-the-Art Electronics in the USA
Stretchable and Wearable Electronics
Techniques and Advances in Human Activity Recognition
The Explainable AI Revolution: From Black Boxes to Transparent Insights
Towards a Sustainable Future: Addressing AI and Big Data, Energy, Climate, and Public Healthcare Challenges
VLSI Architecture Design for Digital Signal Processing
Wearable and Flexible Integrated Sensors
Wearable and Flexible Sensors in Health Monitoring and Diagnosis
Wearable Sensors Applied in Artificial Perception
Wearable Sensors for Human Position, Attitude and Motion Tracking
What Is the Future of Edge AI Accelerators? Emerging Algorithms, System Architectures, Circuit Implementations and Applications
Women in Electronics
Young Investigators in Electronics
All Special Issues
Volume 14
Issue 13
Number
Page
Logical Operator Operator
AND
OR
Search Text
Search Type
All fields
Title
Abstract
Keywords
Authors
Affiliations
Doi
Full Text
References
add_circle_outline
remove_circle_outline Search
Journals
Electronics
Volume 14
Issue 13
10.3390/electronics14132627
Submit to this Journal Review for this Journal Propose a Special Issue
► ▼ Article Menu
Article Menu
Academic Editor Zbigniew Kotulski
Recommended Articles
Related Info Link
Google Scholar
More by Authors Links
on DOAJ
Stănică, G. Cosmin
Anghelescu, P.
on Google Scholar
Stănică, G. Cosmin
Anghelescu, P.
on PubMed
Stănică, G. Cosmin
Anghelescu, P.
Article Views 1199
Table of Contents
Abstract
Introduction
Materials and Methods of the Cryptosystem
Hardware Architecture and Implementation
Results and Discussion
Conclusions
Author Contributions
Funding
Data Availability Statement
Acknowledgments
Conflicts of Interest
Abbreviations
References 
Altmetric share Share announcement Help format_quote Cite question_answer Discuss in SciProfiles
Need Help?
Support
Find support for a specific problem in the support section of our website.
Get Support
Feedback
Please let us know what you think of our products and services.
Give Feedback
Information
Visit our dedicated information section to learn more about MDPI.
Get Information
clear
JSmol Viewer
clear
first_page
Download PDF
settings
Order Article Reprints
Font Type:
Arial Georgia Verdana
Font Size:
Aa Aa Aa
Line Spacing:
  
Column Width:
  
Background:
Open Access Editor's Choice Article
Multi-Layer Cryptosystem Using Reversible Cellular Automata
by
George Cosmin Stănică 
George Cosmin Stănică
SciProfiles Scilit Preprints.org Google Scholar *  
and
Petre Anghelescu 
Petre Anghelescu
SciProfiles Scilit Preprints.org Google Scholar *  
Department of Electronics, Computers and Electrical Engineering, National University of Science and Technology POLITEHNICA Bucharest, Pitesti University Centre, 110040 Pitesti, Romania *
Authors to whom correspondence should be addressed.
Electronics 2025, 14(13), 2627; https://doi.org/10.3390/electronics14132627
Submission received: 30 May 2025 / Revised: 18 June 2025 / Accepted: 28 June 2025 / Published: 29 June 2025
(This article belongs to the Section Computer Science & Engineering)
Download keyboard_arrow_down
Download PDF
Download PDF with Cover
Download XML
Download Epub
Browse Figures            
Versions Notes
Article Views
Citations -
Abstract
The growing need for adaptable and efficient hardware-based encryption methods has led to increased interest in unconventional models such as cellular automata (CA). This study presents the hardware design and the field programmable gate array (FPGA)-based implementation of a multi-layer symmetric block encryption algorithm built on the principles of reversible cellular automata (RCA). The algorithm operates on 128-bit plaintext blocks processed over iterative rounds and integrates five RCA components, each assigned with specific transformation roles to ensure high data diffusion. A 256-bit secret key that governs the rule configuration yields a vast keyspace, significantly enhancing resistance to brute-force attacks. Key elements such as rule-based evolution, neighborhood radius, and hybrid cellular automata for random state generation are also integrated into the hardware logic. All cryptographic components, including initialization, encryption logic, and control, are built exclusively using CA, ensuring design consistency and low complexity. The cryptosystem takes advantage of the localized interactions and naturally parallel CA structure, which align with the architecture of FPGA devices, making them a suitable platform for implementing such encryption schemes. The results demonstrate the feasibility of deploying multi-layer RCA encryption schemes on reconfigurable devices and provide a viable path toward efficient and secure hardware-level encryption systems.
Keywords:
cryptosystem; multi-layer encryption; reversible cellular automata; symmetric cryptography; reconfigurable devices; block encryption; hardware implementation
1. Introduction
In the current digital era, the exponential growth of interconnected devices and the expanding scope of sensitive data transmitted across networks have significantly increased the demand for robust and adaptable encryption systems. Traditional cryptographic methods such as Data Encryption Standard (DES) or Advanced Encryption Standard (AES) have proven effective in many applications, but their centralized and sequential architectures present limitations in environments requiring high parallelism, scalability, or hardware-level optimization [ 1]. This has prompted a growing body of research into alternative encryption models that leverage unconventional computing paradigms, particularly those inspired by naturally distributed systems.
In response to evolving security demands and emerging computational threats [ 2], particularly those posed by quantum computing [ 3], researchers have increasingly turned to alternative encryption methodologies rooted in complex systems and non-linear dynamics. Chaos-based encryption schemes have gained attention due to their sensitivity to initial conditions and pseudorandom behavior, which offer potential advantages in secure communication and image encryption [ 4]; however, their cryptographic strength remains a topic of ongoing research, with certain schemes found to be vulnerable under rigorous cryptanalysis. Similarly, bio-inspired models, including neural networks [ 5] and memristive neuron architectures [ 6], have been used to generate dynamic and adaptive encryption, often with improved resistance to cryptanalysis. Other approaches have drawn from swarm intelligence [ 7] and hyperchaotic maps [ 8] to introduce higher levels of complexity and unpredictability into cryptographic processes.
Within this growing field of unconventional techniques, cellular automata offer a structurally simple yet computationally rich framework. Their local rule-based evolution and scalability align well with hardware implementation, distinguishing them as a practical candidate among alternative cryptographic methods. Several studies have explored the application of one-dimensional cellular automata (CA) in encryption [ 9], including hybrid cellular automata using rule combinations (such as 90/150) for pseudorandom number generation [ 10], and reversible cellular automata (RCA) for bidirectional state evolution [ 11]. Recent advancements in reconfigurable hardware, particularly field-programmable gate array (FPGA), offer a compelling opportunity to implement CA-based cryptosystems efficiently by exploiting their structural compatibility with parallel processing models [ 12].
In recent years, complex dynamic systems, such as those modeled by chaos theory, neural structures, and cellular automata, have emerged as valuable foundations for cryptographic systems due to their inherent unpredictability and sensitivity to initial conditions [ 13, 14, 15]. The shift from software- to hardware-based encryption systems has also become increasingly relevant, especially with the growing demand for real-time data processing in constrained environments. FPGA platforms provide a reconfigurable and parallel processing infrastructure that aligns well with CA-based models, allowing the development of secure, high-speed, and resource-efficient encryption solutions [ 16].
The use of FPGA technology in cryptographic hardware design has gained momentum due to its ability to accelerate performance while preserving flexibility. Several recent studies have demonstrated the effectiveness of implementing cryptographic algorithms, including AES, stream ciphers, and chaos-based schemes on FPGA to achieve improved throughput, reduced latency, and stronger hardware-level security [ 17, 18, 19, 20]. These advancements motivate the exploration of alternative cryptographic paradigms that can be natively mapped onto FPGA architectures, such as the reversible cellular automata-based system proposed in this work.
While previous work has demonstrated the feasibility and theoretical strength of RCA-based encryption through software simulation [ 21], relatively few studies have addressed the practical realization of such systems in hardware. This work presents the design and implementation of a multi-layer RCA encryption algorithm on an FPGA platform. The proposed system integrates five RCA components with distinct neighborhood radii and roles, coordinated through iterative rounds and controlled by a 256-bit key.
The purpose of this study is to demonstrate that the structural and functional properties of cellular automata, when deployed on an FPGA, can provide a viable and efficient framework for secure hardware-level encryption. The implementation confirms that multi-layer RCA logic can be synchronized, evolved, and controlled through modular hardware design, maintaining the reversibility and rule-dependence required for secure encryption and decryption. These results support the broader investigation of bio-inspired and rule-based computing models in cryptographic hardware applications.
Our research introduces key advancements in the field of hardware cryptographic systems. These contributions, which highlight the unique aspects and strengths of our proposed system, are outlined below:
Development of an innovative multi-layer encryption algorithm entirely based on reversible cellular automata, leveraging a cascade of RCA modules to strengthen diffusion and security characteristics of the cipher;
Full integration of cellular automata principles in both encryption logic and random state generation, ensuring structural consistency and alignment with CA-based design methodology validated in prior studies;
Design of a robust key structure consisting of 256-bits, enabling dynamic rule configuration for each RCA and securing critical recovery data, thereby significantly expanding the cryptographic keyspace;
FPGA-based hardware implementation optimized for parallelism and reversibility, utilizing modular RCA units along with the inclusion of a custom PC–FPGA communication interface allowing seamless encryption/decryption operations and secure key/data handling;
Application of NIST statistical tests to assess ciphertext randomness along with visual evaluation techniques and performance analysis confirming high entropy and resistance to pattern-based attacks, further demonstrating the cryptosystem's effectiveness.
The remainder of this paper is organized as follows. Section 2 presents the materials and methods used in the design of the proposed cryptosystem. It begins with a brief overview of key cellular automata principles, followed by the introduction of hybrid cellular automata (HCA) and reversible cellular automata, highlighting their specific roles in the encryption process. This section also details the architecture of the multi-layer encryption algorithm, explaining its operational logic from individual block processing within a single round to the system's overall encryption and decryption flow. Section 3 focuses on the hardware implementation of the cryptosystem, describing the FPGA-based design from a top-level perspective and elaborating on the main architectural modules responsible for RCA evolution, communication, and control. Section 4 presents the experimental results obtained from the hardware system, along with a discussion evaluating the performance, behavior, and reliability of the implemented cryptosystem. Finally, Section 5 concludes the paper by summarizing key findings.
2. Materials and Methods of the Cryptosystem
This section introduces the fundamental principles and structural design underpinning the proposed encryption algorithm. The first subsection outlines the theoretical background of cellular automata, highlighting core concepts such as neighborhood radius, boundary conditions, and rule representation. It then focuses on two specific classes of CA used within the system: hybrid cellular automata (HCA), which are utilized for random number generation based on alternating rule patterns (90/150), and reversible cellular automata, which form the core mechanism for secure data transformation. The second subsection presents the design methodology of the multi-layer encryption algorithm, detailing how multiple RCA components are integrated across the rounds to achieve data confidentiality. This includes graphical representations and explanatory sequences that describe both encryption and decryption workflows.
2.1. Cellular Automata Models
Cellular automata are discrete dynamic systems composed of a regular lattice of identical cells, where each cell holds a state from a finite set (often binary, {0,1}). The evolution of the system occurs in discrete time steps, and at each step, the state of a cell is updated simultaneously across the grid based on a local transition rule. This rule considers the state of the cell and its surrounding neighbors, defined collectively as the neighborhood [ 22]. The number of neighboring cells that influence a given cell is defined by the radius of the automaton. The radius r of a one-dimensional CA determines the span of this neighborhood: a cell located at position i in the array will have a neighborhood defined as
N(c i) = {c i−r, c i−(r−1), …, c i, …, c i+(r−1), c i+r}
(1)
where c i denotes the state of the cell at position i. Consequently, the total number of cells considered for the update of a single cell is 2r + 1. For example, a radius-1 CA uses 3 cells per neighborhood, while radius-2 and radius-3 CAs use 5 and 7 cells, respectively.
Another fundamental concept in CA design is the treatment of boundary conditions, which defines how the CA handles the edge cells that may lack sufficient neighbors [ 23]. Among the most commonly used are fixed boundaries, also known as null boundaries where edge neighbors are assumed constant, typically zero, periodic boundaries, in which the grid is treated as circular, allowing the first and last cells to be neighbors, and reflective boundaries where edge neighbors mirror the value of the adjacent internal cell.
Each rule in a cellular automaton specifies a mapping from every possible neighborhood configuration to a new cell state. For binary CA, the number of possible rules increases exponentially with the neighborhood size—for instance, a radius-1 CA has 2 3 = 8 possible neighborhood configurations and 2 8 = 256 total rules commonly referred to by Wolfram's numbering convention (e.g., Rule 90, Rule 150). These rule definitions can be encoded as binary strings of length 2 2r+1, where each bit corresponds to the output for a specific neighborhood configuration. Increasing the radius of a cellular automaton expands the number of possible rule configurations. Specifically, a radius-2 CA produces 2 32 unique rules, while a radius-3 CA results in 2 128 distinct rule combinations.
A distinct class within the broader family of cellular automata is the hybrid cellular automaton, which extends the conventional uniform CA by allowing different cells to evolve according to different local rules. Unlike uniform CA, where a single evolution rule is applied uniformly across all cells, HCAs assign a specific rule to each cell individually, enabling greater diversity and adaptability in their behavior [ 24]. This heterogeneity makes HCAs particularly suitable for tasks requiring increased randomness or complexity, such as cryptographic applications. Binary HCAs commonly include linear rules such as rule 90 and rule 150, both of which are known for producing complex, pseudo-random patterns. Table 1 illustrates the binary representations of these two rules for a radius-1 CA, where each bit corresponds to the output for a particular neighborhood configuration ordered from highest to lowest value.
Table 1. Binary representation of two evolution rules (90 and 150). 
Linear cellular automata (LCA) operate using rules defined by XOR-based logic applied over a cell's neighborhood. Rules 90 and 150 fall in this category because their evolution is governed by XOR operations applied over specific neighborhoods. Rule 90 calculates the next state of a cell using the XOR of its immediate left and right neighbors, while Rule 150 includes the cell itself in the XOR computation along with its two neighbors. To offer a clearer understanding of how these rules operate and how their evolution functions are constructed, a graphical representation is provided in Figure 1 along with the corresponding Boolean equations used for state transitions, defined as follows:
c i (t + 1) = c i–1(t) ⊕ c i+1(t); Rule 90.
(2)
c i (t + 1) = c i–1(t) ⊕ c i(t) ⊕ c i+1(t); Rule 150.
(3) 
Figure 1. Graphical representation of rules 90 and 150.
The assignment of these rules across the lattice can follow a fixed pattern or a dynamically generated scheme, depending on the intended application. Due to their increased entropy and ability to produce unpredictable sequences, HCAs have been widely explored as building blocks in random number generators. In the context of this work, a hybrid CA combining rules 90 and 150 is utilized for generating initial random states within the cryptographic algorithm, taking advantage of its structural simplicity and inherent randomness. A detailed explanation of how these HCAs are incorporated into the cryptosystem is provided in the following subsection.
Reversible cellular automata represent a subclass of cellular automata in which the evolution process is reversible, meaning that each configuration of the system has a unique predecessor. This bijective nature enables both forward and backward traversal of states, making RCAs particularly suitable for symmetric cryptographic systems where decryption is essentially the reverse of encryption. While some elementary CA rules inherently support reversibility, their number is limited, and many do not offer the complexity or randomness necessary for secure cryptographic applications [ 25].
To overcome the limitations of simple reversible rules, this work employs second-order reversible cellular automata, a more flexible and powerful approach. In this model, the next state of each cell is influenced not only by its neighborhood at the current time step (t), but also by its own state at the previous time step (t − 1), as described by the evolution function:
c i(t + 1) = f [N(c i(t)), c i(t − 1)]
(4)
In this work, the term reversible refers specifically to the ability of the cellular-automata-based cryptographic system to deterministically reproduce previous configurations when both the initial states and the secret key are known. This form of reversibility differs from the broader theoretical concept of reversibility often associated with pseudo-random number generators in cellular automata, which may suffer from degeneration at certain configurations, rendering backward reconstruction infeasible. This ensures that both encryption and decryption processes are symmetric and reliable, without requiring the storage of intermediate states.
A graphical representation of this concept is provided in Figure 2, illustrating the evolution of a single cell within a one-dimensional reversible cellular automaton using a radius-3 neighborhood. 
Figure 2. Reversible cellular automata cell state evolution.
The reversible rule is constructed by defining two complementary evolution rules: one applied when the previous state of the cell is '1', and the other, its bitwise complement, when the previous state is '0'. This mechanism preserves reversibility while increasing the rule space and enabling more intricate evolution behavior for cryptographic operations. From a mathematical standpoint, the second rule is derived from the first, as expressed below, where r denotes the radius of the cell.
CR 2 = 2 m − CR 1 − 1
(5)
m = 2 2*r+1
(6)
Complementary rules enable precise two-way evolution in reversible cellular automata, ensuring that previous states can be accurately reconstructed. This reversibility is founded on the principle of bijectivity, requiring the update function to be both injective, so that no two inputs yield the same output, and surjective, ensuring every output results from some valid input. As a result, each configuration leads to a unique next state, and any state can be reliably traced back to its origin, maintaining the system's reversible behavior.
A single RCA following these principles can be used for encrypting data by initializing it with two configurations: one derived from the plaintext and one randomly generated. The RCA is then evolved over a fixed number of iterations. The final two states produced by this evolution represent the encrypted output. For decryption, the process is reversed: the last two configurations are used as starting points, and the automaton is iterated backward using the same rules and the same number of iterations. In each case, the secret key consists of the reversible rule applied during the encryption and decryption process. Figure 3 illustrates how reversible cellular automata are applied within cryptographic systems, depicting the operational flow of both encryption and decryption processes. This symmetric structure guarantees that the original data can be precisely reconstructed, maintaining both confidentiality and reversibility. 
Figure 3. Encryption and decryption mechanisms based on reversible cellular automata.
The encryption and decryption process using reversible cellular automata is structured around symmetric forward and backward evolution. In the encryption phase, the system starts with two initial configurations: a random state s 0 and the plaintext represented by s 1 state. These are passed through the RCA evolution, which processes them over a fixed number of iterations to produce two final states, s n−1 and s n. The state s n−1 becomes the ciphertext, while s n serves as recovery data, which are subsequently encrypted using an XOR operation with a secret key, in accordance with the Vernam algorithm [ 26], to enhance security. During decryption, this encrypted recovery data are first decrypted using the same XOR key to retrieve s n, which, along with s n−1, is fed back into the RCA evolution in reverse order. Through backward evolution, the algorithm reconstructs the original initial states, effectively recovering the original plaintext.
2.2. Multi-Layer RCA-Based Encryption Design
The proposed encryption algorithm is structured around a multi-layer framework that integrates five reversible cellular automata across three distinct functional layers, forming a cascading encryption process. This layered architecture is designed to enhance diffusion, key sensitivity, and reversibility, making it suitable for secure block encryption. Each layer contributes a specific transformation role within the system, working together to ensure the integrity of the encrypted output and the accurate reconstruction of the original data during decryption. The algorithm consists of the following layers built from RCA components:
Primary Transformation Layer: consists of two parallel RCA modules (denoted as PLCA and PRCA), each processing a separate half of the input data block;
Shift Computation Layer: introduces controlled variability in the data flow by employing additional RCA modules (LSCA and RSCA) to dynamically generate shift values in order to increase dispersion and eliminate symmetry in the data;
Binding Layer: performs the recombination of the processed data using another RCA module (BCA) operating over the entire block length, resulting in a final encrypted output for the current round and an additional state used for the next block encryption.
The flow of data through these layers is repeated over multiple rounds, reinforcing complexity and resistance to cryptanalytic attacks. This iterative design principle aligns with modern symmetric encryption standards such as the Data Encryption Standard or Advanced Encryption Standard, which also rely on multiple transformation rounds to strengthen security through confusion and diffusion. Following this approach, the proposed algorithm performs 16 consecutive rounds of reversible transformations for each 128-bit plaintext block, using the multi-layer RCA structure to progressively obscure the original data. Figure 4 illustrates the internal architecture of a single encryption round within the proposed multi-layer RCA-based algorithm. The diagram highlights the sequential flow of data, showing how intermediate transformations are applied and how each RCA component interacts to produce the encrypted output for the current round. 
Figure 4. Flow diagram of a single encryption round.
To support a secure and reversible transformation process within each encryption round, the algorithm integrates five distinct reversible cellular automata across its multi-layer structure. These RCAs are configured using extended neighborhood radius to expand the complexity and variability of their rule sets. Specifically, the RCAs in the primary transformation layer and the shift computation layer utilize a radius-2 neighborhood, while the RCA responsible for binding operations employs a larger radius-3 neighborhood. The automata differ in size based on their functional role: the two RCAs in the primary layer are each composed of 64 cells; the shift control automata each consist of 16 cells, optimized for generating the shift values and the binding RCA operates over a full 128-cell structure, accommodating the merged results of previous layers. To ensure seamless evolution of cell states and avoid edge anomalies, all RCAs in the system are governed by periodic boundary conditions, which treat the first and last cells as neighbors, maintaining consistency and preserving the circular nature of the automaton evolution. Figure 5 below illustrates the process of successive block encryption, emphasizing the chaining mechanism, where the final state of one block directly influences the initialization of the next, ensuring data diffusion and enhancing security. 
Figure 5. Successive block encryption of plaintext blocks.
As depicted in Figure 4, the encryption of a single 128-bit plaintext block in one round of the proposed RCA-based cryptosystem follows a structured and layered sequence of operations. The process begins with two initial inputs: a 128-bit block of plaintext denoted as s 1 init and a 128-bit random initialized value labeled as s 0 init. These two states are divided into two equal halves, forming four 64-bit segments: s 0 L, s 1 L, s 0 R, and s 1 R. The left halves (s 0 L, s 1 L) are fed into the primary left cellular automaton, while the right halves (s 0 R, s 1 R) are sent into the primary right cellular automaton. Both PLCA and PRCA evolve their respective states using specific RCA rules defined in the encryption key. The evolution produces the outputs s n−1 L and s n L from PLCA and s n−1 R and s n R from PRCA.
Next, the outputs s n L and s n R are subjected to a bitwise circular shift. The amount by which each is shifted, left for s n L and right for s n R, is dynamically determined by the two instances of the shift computation layer that compute the shift values XsL and XsR. The shifted results are labeled s n L* and s n R*, respectively. To provide a clearer understanding of how these values are derived, the process is illustrated in Figure 6 below. 
Figure 6. Shift value generation process.
Following this, the binding cellular automaton, which operates with a wider neighborhood and 128-bit states, is initialized. Its inputs are a combination of earlier outputs, the first one obtained from swapping the position and concatenation of the states s n−1 L and s n−1 R, and the second one obtained from the concatenation of state s n L* with state s n R*.
This layer is responsible for reconstructing and further transforming the output from the primary and shift layers, enhancing diffusion and increasing resistance to statistical attacks. The BCA is evolved for 22 generations using its own rule defined in the encryption key, ultimately producing the final outputs for the current round s 0 final and s 1 final. These values serve two purposes: if the current round is not the last, they become the new initialization values (s 0 init and s 1 init) for the next round, and if it is the final round, s 0 final is designated as the ciphertext block, while s 1 final is stored as recovery data necessary for decryption. This round-based design ensures strong confusion and diffusion throughout the encryption process and forms the foundation of the reversible transformation scheme used in the system.
At the start of the encryption process, each of the two SCAs is initialized a single time using predefined configurations derived from the same random source responsible for the initial state of the first plaintext block in round one (s 0 init). Prior to every encryption round, both SCAs undergo six iterations of evolution. During this process, the central cell in each SCA produces one bit per iteration, collectively forming a 6-bit shift value referred to as XsL (for LSCA) or XsR (for RSCA). This mechanism ensures that the value can range from 0 to 2 6, enabling flexible and dynamic shifting of the 64-bit outputs from the primary RCAs. The generated shift values are used to perform circular bit shifts, left and right, on the respective outputs, ensuring full or partial rotation, depending on the calculated value.
The random 128-bit initial value required to initiate the encryption process is generated using a linear hybrid cellular automaton (LHCA) configured with rules 90 and 150. This setup consists of four independent LHCA instances, each operating as a 32-cell CA. Each LHCA follows a specific rule configuration pattern derived from Hortensius's rule order combinations, which are known to achieve maximal-length cycles and strong pseudo-random behavior [ 27]. In this pattern, each bit position in the 32-bit LHCA is assigned either rule 90 or 150 based on a predefined sequence that ensures optimal linear complexity and avoids short repetitive cycles. This predefined sequence is expressed as a binary string, where a value of '0' indicates the use of rule 90 and a value of '1' indicates the use of rule 150 for the corresponding cell position, respectively, as detailed in Table 2. The generated values not only serve as the initial state for the encryption algorithm but also contribute to the initialization of key RCA components such as the shift control automata (SCA), ensuring secure initialization.
Table 2. Rule combination order for maximum cycle length. 
The seed used to initialize the LHCA-based random number generator is set arbitrarily with a predefined value during the first use. For subsequent encryption operations, the system updates its seed by assigning the last generated state of the LHCA as the new starting point. This approach is viable because the initial random state used for encryption does not need to be stored or remembered for decryption, ensuring both randomness and efficiency without compromising the reversibility of the encryption process. The usage of randomly generated data in the developed cryptosystem is depicted in Figure 7 below. 
Figure 7. Usage of LHCA randomly generated data.
The secret key is a fundamental component of the proposed encryption system, directly influencing the behavior and security of the multi-layer reversible cellular automata architecture. It is composed of 256-bits and is responsible for configuring the evolution rules for each of the five RCA modules used across the multi-layer structure of the cryptosystem. These rules govern the way each RCA updates its cell states during the encryption and decryption processes. To better illustrate the structure of the secret key and how each segment corresponds to the rule configuration of a specific RCA, Figure 8 provides a breakdown of the key layout. The diagram illustrates the exact bit ranges allocated to each of the five RCA modules, highlighting their association with the respective neighborhood radius and functional role within the encryption algorithm. 
Figure 8. Key structure and role breakdown.
The first 32 bits of the key define the rule used by the primary left cellular automaton, followed by the next 32 bits, which correspond to the primary right cellular automaton. Both PLCA and PRCA utilize a radius-2 neighborhood, which results in 2 2r+1 = 2 5 = 32 possible neighborhood configurations, thus requiring a 32-bit rule for full definition. Similarly, the left and right shift cellular automata (LSCA and RSCA) also use radius-2, and each is allocated 32 bits from the key. The final 128 bits are dedicated to the binding cellular automaton, which operates on a larger radius of 3. This extended radius leads to 2 2r+1 = 2 7 = 128 distinct neighborhood patterns, and therefore necessitates a 128-bit rule definition.
These rule segments are not just arbitrary bitstrings but represent reversible evolution rules that determine how a cell's next state is computed based on its current neighborhood and its own previous state. The system adheres to second-order reversible cellular automata principles, where two complementary rules are used to ensure bidirectional evolution. Specifically, the 256-bit key explicitly provides only the rule corresponding to the case when a cell's state in the previous generation (t − 1) is 1. The complementary rule, which applies when the previous state is 0, is derived by bitwise negation of the provided rule. This method guarantees reversibility and simplifies key design, as it reduces the amount of information that must be stored and transmitted while still supporting complete reconstruction of prior states during decryption.
In addition to governing the evolution of the cellular automata throughout the encryption process, the secret key plays a pivotal role in securing the final states of the system once all plaintext blocks have been processed. Specifically, the algorithm protects five critical RCA outputs: the final state of the binding cellular automaton, referred to as the recovery data, and the last two configurations of each of the two shift cellular automata (LSCA and RSCA). These elements are collectively sensitive, as they contain information essential for correctly reversing the encryption and reconstructing the original data. If exposed, they could potentially be exploited by adversaries to infer the internal state transitions of the system.
To prevent such vulnerabilities, these final states are secured through a transformation process resulting in a 192-bit string called Encrypted Recovery Data (ERd). This string is formed by applying a bitwise XOR operation between the sensitive states and specific segments of the 256-bit secret key. The precise derivation of the ERd and its component contributions are detailed below, clearly illustrating how key-dependent transformations enhance security by protecting the most crucial internal states of the system.
ERd [0..127] = s n BCA [0..127] XOR Key [64..191]
(7)
ERd [128..143] = s n−1 LSCA [0..15] XOR Key [192..207]
(8)
ERd [144..159] = s n LSCA [0..15] XOR Key [208..223]
(9)
ERd [160..175] = s n−1 RSCA [0..15] XOR Key [224..239]
(10)
ERd [176..191] = s n RSCA [0..15] XOR Key [240..255]
(11)
This construction ensures that without knowledge of the key, the original states remain inaccessible. The ERd value is appended to the ciphertext as a final output of the encryption phase and is required during decryption to accurately initialize the system for reverse evolution. The XOR operation offers a simple yet powerful cryptographic mechanism, enhancing security by obscuring critical data while maintaining low computational overhead. This efficiency, combined with its protective function, highlights the essential role the secret key plays in reinforcing the overall security framework of the encryption system.
The decryption process is designed to mirror the encryption logic, ensuring accurate and complete reconstruction of the original plaintext. Due to the reversible nature of the cellular automata used, each transformation applied during encryption can be undone by following the backward evolution path, starting from the final system state. Decryption requires three critical inputs: the final ciphertext block, the 192-bit Encrypted Recovery Data, and the original 256-bit secret key.
The decryption begins with extracting the original internal system states needed to initiate the reverse process, which are obtained by decrypting the ERd using an XOR operation with specific segments of the secret key. These recovered states serve as the starting point for backward evolution. The decryption of ciphertext blocks proceeds in reverse order, starting from the last encrypted block and moving backward to the first. This is necessary because the encryption process uses chaining, where each block's initial state depends on the final state of the previous round. For each block, the same number of rounds is executed using the same RCA configurations and key-defined rules as during encryption. However, in each round, the data flow through the three RCA layers in the reverse order compared to encryption, starting from the binding layer to the shifting layer and ending with the primary layer. The outputs from these stages progressively reconstruct the earlier plaintext configurations. After completing all rounds in reverse and processing all ciphertext blocks from last to first, the original plaintext is fully restored.
This design not only ensures data recoverability but also maintains high resistance to cryptanalysis, as each round depends on tightly coupled RCA state transitions, key-dependent behavior, and shift operations. The overall structure thus preserves both confidentiality and reversibility, aligning with the principles of secure symmetric block encryption systems.
3. Hardware Architecture and Implementation
This section presents the hardware-level design and implementation of the proposed multi-layer RCA-based encryption algorithm, realized on a field programmable gate array platform. The FPGA was chosen for its inherent parallel processing capabilities, which align naturally with the structural and operational properties of cellular automata. This compatibility allows the algorithm to take full advantage of parallel evolution, enabling efficient execution and enhanced security. The section begins by describing the top-level hardware architecture, followed by detailed explanations of the core components that make up the cryptosystem. These include the individual reversible cellular automata modules responsible for encryption logic and the control unit that handles data flow and process sequencing. In addition, the system integrates a UART-based communication interface that facilitates interaction with an external environment. A dedicated software application, developed as part of the project, enables users to control encryption and decryption operations by sending and receiving data to and from the FPGA board. Figure 9 presents the block diagram that includes the overall integration of the system components. 
Figure 9. Cryptosystem block diagram.
The first block is the Communication Unit (COMM_UNIT), which manages the data exchange between the software application and the FPGA board. This unit is composed of two modules: a receiving module that handles incoming data from the PC to the FPGA, such as encryption keys and plaintext or ciphertext blocks, and a transmitting module that sends the processed data, either encrypted or decrypted, back to the PC.
The second block is the Encryption Unit (ENC/DEC_UNIT), which performs the core encryption and decryption operations. This unit is subdivided into two key subcomponents: the control unit, responsible for managing the data flow and sequencing of operations across the algorithm's multiple rounds, and the CA units, which house dedicated modules for each of the hybrid and reversible cellular automata layers involved in the encryption structure. As shown in Figure 10, the top-level design provides a clear overview of the internal architecture of the cryptosystem. 
Figure 10. Cryptosystem top-level hardware design.
The hardware implementation of the cryptosystem includes dedicated communication modules that facilitate reliable data transfer between the PC and the FPGA. This is achieved through a serial UART communication interface divided into two main components: the receiver module and the transmitter module. The receiver module is responsible for capturing incoming data from the PC, including the secret key, plaintext blocks for encryption, or ciphertext blocks for decryption. It stores the received bytes and ensures data are correctly forwarded to the processing unit. The transmitter module handles the outbound communication by sending back the processed data to the PC. Once a complete 128-bit block has been processed, the transmitter breaks it into bytes and sends it serially.
In addition to handling raw data reception, the receiver module plays a critical role in defining the operational mode of the cryptosystem, specifically, whether the system should perform encryption or decryption. This functionality is facilitated through the encrypt_mode output signal, which is used by the control unit to determine the appropriate processing flow for the incoming data. The operational mode is configured from the software application interface, shown in Figure 11, where the user can toggle between encryption and decryption using a checkbox control. Based on the selected mode, the application automatically appends an identifier character to the transmitted data: 'P' for plaintext (encryption mode), 'C' for ciphertext (decryption mode), and 'K' to indicate the transmission of the secret key. These characters correspond to well-known ASCII codes, which can be easily recognized by the receiver module in hardware. Once identified, these prefix characters are stripped before the actual data are passed to the encryption/decryption unit, ensuring clean and correctly formatted input. This mechanism simplifies the control logic and provides an efficient and user-friendly way to dynamically configure system behavior without requiring additional signals or complex hardware protocols. 
Figure 11. Software application interface.
In order to manage multiple 128-bit data blocks efficiently, the receiving module stores incoming blocks in a FIFO-like buffer structure. This ensures that blocks are maintained in the correct processing order. The structure is controlled by two key signals: dequeue, which is issued by the control unit to remove a processed block, and empty, which signals when no further blocks remain to be processed. An important observation regarding the decryption process is that since decryption operates in reverse, starting from the last ciphertext block and proceeding backward, the reordering of the ciphertext is efficiently handled at the software level. This approach eliminates the need for complex hardware control logic for data reversal, thereby optimizing resource usage and simplifying the hardware design. The reversing operation is lightweight and introduces negligible overhead in software, ensuring a seamless integration with the hardware-based decryption flow. Another important aspect of the decryption process concerns the encrypted recovery data, required to reconstruct the final system states necessary for reverse operations. In the hardware flow, this 192-bit ERd is identified by the receiving module, which extracts the first 192 bits from the incoming ciphertext stream and routes them appropriately for decryption initialization. This mechanism ensures seamless separation between recovery data and the actual ciphertext blocks, simplifying state recovery.
The HCA_Random_128 module serves as the system's random state generator, responsible for producing the first 128-bit initial configuration required to begin the encryption process. This module is composed of four individual hybrid cellular automata, each operating on 32-bit and evolving according to a hybrid rule set based on rules 90 and 150. The selection of these rules follows a specific binary pattern known to generate maximum-length cycles, ensuring high entropy and unpredictability in the generated states. Each of the four HCAs is initialized with a predefined 32-bit value, serving as the seed for the random number generation process. The final 32-bit output of each HCA serves the role of a new seed for a subsequent encryption process, and it is also concatenated to produce a complete 128-bit value. This combined output forms the initial random state used by the cryptosystem to begin processing the first block of plaintext.
The encryption process in the proposed hardware implementation is coordinated by the control unit based on the HCA random generator and the collection of RCA units. These components are tightly integrated, each fulfilling a specific role that contributes to the overall functioning of the encryption operation. At the core of the system lies the control unit, which orchestrates the entire encryption process. It manages the flow of data, sequencing of operations, and the activation of each CA module. Based on inputs such as encrypt_mode and key_in, the control unit determines the operational mode, identifies the key and plaintext/ciphertext inputs, and generates the appropriate control signals (start_PLCA, start_PRCA, start_LSCA, start_RSCA, start_BCA) to trigger the corresponding RCA modules. Additionally, it handles the readiness signals (PLCA_done, PRCA_done, LSCA_done, RSCA_done, BCA_done, and HCA_done) that indicate the completion of evolution cycles in each RCA block, allowing it to manage transitions between stages and rounds. The control unit also handles the generation and forwarding of intermediate data like rotated outputs and shift values, along with the distribution of key segments to each RCA, ensuring data dependencies between layers are maintained across all rounds of encryption. To better illustrate the process of securing data, Algorithm 1 below presents the logic of the overall operation flow of the hardware implementation, using pseudocode:
Algorithm 1: FPGA-Based Multi-Layer RCA Overall Operation Logic Flow
Initialize UART Communication
Initialize RCA Units with Key Rules
Load Secret Key (256-bit)
Generate Initial Random State (128-bit)
while (Receiver detects new data block)
if Received Data Identifier = 'K'
Store Secret Key from Incoming Stream
else if Received Data Identifier = 'P' OR 'C'
Store Input Block into Buffer
Set encrypt_mode Flag Accordingly
end if
while (Buffer Not Empty)
Dequeue 128-bit Block from FIFO
if encrypt_mode = ENCRYPT
for Round = 1 to 16
Evolve PLCA and PRCA in Parallel
Compute Shift Values using LSCA and RSCA
Apply Circular Shifts to PLCA and PRCA Outputs
Evolve BCA Using Shifted Outputs
end for
Store Final BCA State
Generate Encrypted Recovery Data (ERd)
Append ERd to Final Cipher Block
Transmit Cipher Block via UART
else if encrypt_mode = DECRYPT
Extract ERd and Restore Last States
for Round = 1 to 16
Reverse BCA Evolution
Reverse Shifts and Primary RCAs Evolutions
end for
Transmit Decrypted Plaintext Block
end if
end while
end while
end
The system contains five distinct reversible cellular automata units, each fulfilling a specialized role based on their position in the encryption architecture as described in Section 2.2. Together, these units implement the layered RCA-based encryption process over 16 rounds. Each RCA module is activated by control signals from the control unit, and the results are sequentially routed to the next stages. The system architecture ensures efficient data management, synchronization, and secure reversible transformation of data, assured through the modular design of the implementation.
4. Results and Discussion
This section presents and analyzes the experimental results obtained following the complete design and hardware implementation of the proposed RCA-based encryption system. The discussion focuses on evaluating the cryptographic strength and operational effectiveness of the system through a series of assessments aligned with essential security properties. These include statistical analysis of the encrypted output to evaluate data randomness, graphical inspection of ciphertext dispersion relative to the original plaintext, and evaluation of key sensitivity and diffusion characteristics. In addition, implementation-specific results are discussed, including hardware resource utilization. The resilience of the system to attacks is also addressed, supported by evidence from the algorithm's design characteristics and test outputs. Collectively, these analyses provide a comprehensive view of the cryptosystem's performance and its suitability for secure, hardware-level data protection.
The proposed cryptosystem was developed and tested using a combination of software and hardware components. The software application, responsible for system control and communication, was implemented on a desktop computer equipped with an Intel Core i5-14600K processor and 32 GB of RAM. On the hardware side, the encryption algorithm was developed using Xilinx ISE version 10.1, and it was deployed on a Xilinx Spartan-3E FPGA board, specifically the Digilent Nexys 2 model.
The current research and hardware-level implementation of the cryptosystem using FPGA builds upon a previously conducted study in which the encryption algorithm was developed and validated at the software level [ 21]. In that earlier work, a custom-designed desktop application was created to simulate and test the core principles of the multi-layer RCA-based encryption system. The software platform enabled a comprehensive evaluation of the algorithm's functionality, correctness, and security features through various experimental scenarios. The promising results obtained, including strong key sensitivity, data diffusion, and accurate decryption, served as a solid foundation and motivation for transitioning the design to a hardware environment. This shift aimed to harness the parallel processing strengths of FPGA technology to further enhance performance and demonstrate the feasibility of deploying the cryptosystem in practical applications.
To assess the quality and security of the encrypted data produced by the proposed cryptosystem, a series of statistical evaluations were conducted using the National Institute of Standards and Technology (NIST) Statistical Test Suite. These tests are specifically designed to measure the randomness of binary sequences generated by cryptographic systems, a critical factor in ensuring resistance against various forms of cryptanalysis. Randomness in encrypted data is essential because it prevents the appearance of detectable patterns that could be exploited by attackers to infer information about the plaintext or the encryption key.
The NIST Statistical Test Suite consists of 14 distinct tests, each designed to evaluate a different dimension of randomness within binary sequences generated by encryption systems. These tests apply a range of analytical approaches to detect potential irregularities or patterns that could compromise data confidentiality. Each test within the suite evaluates a different aspect of randomness and outputs a p-value, which indicates the probability that a truly random generator would produce a sequence less random than the one being tested. For the current study, a total of 1,000,000 bits of encrypted data were collected and analyzed as 10 bitstreams of 100,000 bits each, in accordance with the input size requirements specified by the NIST guidelines [ 28]. A significance level of α = 0.01 was used, meaning that sequences are considered statistically random if their p-value is greater than or equal to 0.01, providing a 99% confidence level in the validity of the randomness results. The detailed outcomes of these tests are summarized in Table 3 below.
Table 3. NIST-based randomness validation of encrypted bitstreams. 
In addition to evaluating statistical randomness, the suite also provides insights into the distribution of binary values, specifically the proportion of ones and zeroes, across the analyzed ciphertext sequences. Ensuring a nearly equal distribution of these binary values is a fundamental characteristic of a secure cryptographic system, as it contributes to the elimination of recognizable structures that adversaries might exploit. A balanced output not only reflects the strength of the underlying encryption mechanism but also reinforces its resistance to statistical attacks. Table 4 presents the proportion of ones and zeroes obtained for each of the 10 analyzed bitstreams (BS), offering an additional metric to validate the robustness of the encryption algorithm.
Table 4. Binary value distribution analysis of encrypted sequences. 
According to NIST's guidelines, the minimum requirement for passing each statistical test is around 8 for a sample size of 10 binary sequences when using a significance level α = 0.01. In this study, the encrypted data were divided into 10 sequences of 100,000 bits each and analyzed accordingly. The results align with the expectations of high potential randomness, and all applied tests met or exceeded the required confidence thresholds, thereby validating the cryptographic quality of the generated ciphertext.
In addition to evaluating the randomness of the encrypted output, the NIST statistical test suite was also applied to validate the quality of the HCA-based random number generator used in the proposed cryptosystem. The test results confirmed that the HCA generator produces statistically sound random sequences, meeting the required criteria for cryptographic randomness. This validation supports its use as a reliable source of initial data for encryption processes. Moreover, the choice of HCA as the random number generator reinforces the system's conceptual consistency, as it ensures that all components of the cryptosystem are founded on cellular automata principles.
To further assess the encryption system's effectiveness in concealing meaningful patterns, an analysis of the ciphertext distribution across the ASCII interval was conducted. While the original plaintext is constrained within the alphanumerical range of the ASCII table, the encrypted output generated by the system exhibits a broad dispersion across the entire ASCII interval. This uniform distribution contributes significantly to the unpredictability and confidentiality of the encrypted data, as it removes recognizable structures that could otherwise compromise data security. As illustrated in Figure 12, the ciphertext does not exhibit clustering or repetitions that could be linked to the original message, highlighting the system's capacity to prevent data sensitivity and potential exposure through statistical observation. 
Figure 12. Data dispersion across ASCII values. ( a) Original data; ( b) encrypted data.
To evaluate the feasibility and efficiency of implementing the proposed cryptosystem at the hardware level, resource utilization statistics were collected after synthesizing the design on the selected FPGA platform. These statistics provide insight into the area and logic consumption associated with deploying the complete system, including both communication modules and the internal RCA-based processing units. Table 5 below summarizes the utilization of key FPGA resources.
Table 5. Hardware implementation summary. 
In the FPGA implementation, each reversible cellular automata rule is stored as a binary value corresponding to its respective neighborhood size, and the evolution of each cell is computed in parallel through combinational logic blocks. This design enables one-step full-state updates, aligned with the CA's parallelism model. Each RCA unit, whether 16, 64, or 128 cells wide, is instantiated using modular entities that permit straightforward scalability. The synthesis report shows moderate resource consumption, with logic slice utilization remaining within device capacity even for the complete system. The resource utilization may be further optimized using approaches such as parallelization of program instructions using techniques like genetic algorithms [ 29], which could help streamline instruction execution and logic placement. While the UART-based serial communication was used in this study to validate functionality and enable testing from a PC interface, the architecture can be extended to more robust high-speed protocols such as PCI Express or Ethernet, especially for integration into networked or embedded environments. This highlights the design's adaptability and its suitability for practical secure hardware applications beyond conceptual validation.
A comparative efficiency evaluation was carried out by calculating the throughput of the proposed encryption algorithm, expressed in Mbps, to determine its performance improvements when implemented at the hardware level. This analysis aimed to assess whether the hardware implementation, developed in the current study, outperforms the earlier software-based version described in previous research. Additionally, the algorithm's performance was benchmarked against other encryption algorithms, with the average results presented in Table 6 below. These results are derived from synthesis reports and a series of empirical tests conducted across different input data scenarios. The findings confirm that the transition to hardware significantly enhances performance due to the inherent parallelism and optimized resource utilization of FPGA platforms.
Table 6. Comparative analysis results. 
The proposed cryptographic system demonstrates strong resistance to various forms of cryptanalytic attacks, like brute-force and reverse engineering techniques. The foundation of this resistance lies primarily in the system's large key space and the inherent complexity introduced by its multi-layer RCA structure. With a secret key length of 256-bits, the algorithm offers a key space of 2 256 possible combinations, making exhaustive key search computationally infeasible using current or near-future computing resources.
While the results from the NIST statistical test suite confirm the high degree of randomness in the generated ciphertext, a critical attribute for resisting statistical and differential attacks, it is important to acknowledge that such validation alone does not constitute formal proof of cryptographic strength. Thus, beyond the statistical test results, the robustness of the system is supported by its large key space (2 256), the high number of possible configurations of each RCA module due to their extended radius and size, and the dynamic evolution mechanism that diffuses input data across multiple layers and rounds. These features collectively contribute to the algorithm's resistance against brute-force and pattern-based attacks.
The strength of the proposed encryption algorithm also lies in the enormous configuration space of each reversible cellular automaton used throughout its multi-layer architecture. While the secret key governs the evolution rules, the state space of each RCA is determined by the number of cells composing it: PLCA and PRCA each have a configuration space of 2 64 possible states, LSCA and RSCA each have a configuration space of 2 16 possible states, while the BCA has a total of 2 128 possible states. This plays a vital role in preventing attacks as it ensures a vast number of potential internal states. This analysis shows that each RCA, beyond the complexity introduced by its evolution rule (defined in the key), brings a massive number of internal configurations to the encryption system. The high-dimensional state space ensures that even if an attacker knows the rule, determining the initial or intermediate configuration remains computationally impractical.
Additionally, since encryption evolves across 16 rounds, and each round involves transitions across these large configuration spaces, the complexity grows exponentially. One critical feature of the encryption algorithm is its ability to prevent identical plaintext blocks from producing the same ciphertext. This is accomplished through the chaining mechanism, in which the encryption of each block is influenced by the final states generated from the encryption of the previous block. As a result, even if the same plaintext block appears multiple times, the algorithm produces distinct ciphertexts for each occurrence. This is achieved without the need to store or transmit the initial random state, as the reversibility of RCA ensures that decryption can reconstruct all required intermediate states from the final configurations alone. This chaining effect, combined with the secret key structure and the reversible nature of the RCA rules, further strengthens resistance to attacks, particularly in cases where partial information may be available to adversaries. The approach results in highly nonlinear and diffused transformations of the plaintext, a fact that is validated by the presented statistical and structural test results.
Although the proposed cryptosystem uses reversible cellular automata and XOR-based rule structures commonly found in linear CA, the system cannot be accurately described as simply reversible coding or pseudo-random masking. The architecture leverages a multi-layer configuration of RCA modules, extended radii for richer rule spaces, and iterative evolution rounds governed by a 256-bit secret key, thereby ensuring high entropy and strong data diffusion. These design choices introduce non-linearity and interdependency across rounds, elevating the transformation beyond simple XOR operations. Therefore, despite using CA rules as primitives, the overall mechanism fulfills the structural expectations of an encryption system. This distinguishes the presented approach from basic reversible encoding schemes, reinforcing its applicability in secure data communication contexts.
The proposed cryptographic system is particularly suited for deployment in scenarios that require secure and efficient data exchange within constrained hardware environments. These include embedded systems, Internet of Things (IoT) devices, industrial control systems, and secure hardware-level communication channels. Such applications demand lightweight, parallelizable encryption solutions capable of operating in real time without extensive computational overhead. The use of FPGA-based implementation not only enables parallel processing in alignment with the cellular automata model but also offers adaptability and reconfigurability, making it well-suited for integration into custom secure hardware designs. This combination of efficiency and security supports the cryptosystem's applicability in domains where both performance and protection against data compromise are essential.
5. Conclusions
This paper presents the design and hardware-level implementation of a multi-layer encryption system based on reversible cellular automata, using an FPGA platform to fully leverage the intrinsic parallelism of CA structures. The proposed cryptosystem was carefully structured into three RCA-driven layers, each contributing to the transformation, diffusion, and binding of data across multiple encryption rounds. The system integrates five RCAs of varying lengths and radii, coordinated through a control unit and supported by a lightweight communication interface with a desktop application for user interaction.
The implementation successfully demonstrates the feasibility of deploying a complex RCA-based algorithm on reconfigurable hardware while preserving the theoretical principles of cellular automata models. The use of a 256-bit secret key ensures strong protection against brute-force attacks and supports secure rule-based RCA evolution. Statistical analysis of the encrypted outputs, including tests with the NIST Suite, confirmed the randomness and uniform bit distribution of the cipher data, validating their resistance to cryptanalysis. The hardware-level FPGA-based implementation proved capable of achieving secure encryption and decryption, further underlining the practical potential of RCA-based designs in embedded or high-performance cryptographic applications.
Author Contributions
Conceptualization, G.C.S.; Formal analysis, G.C.S. and P.A.; Investigation, G.C.S. and P.A.; Methodology, G.C.S. and P.A.; Resources, P.A.; Software, G.C.S.; Supervision, P.A.; Validation, G.C.S. and P.A.; Visualization, P.A.; Writing—original draft, G.C.S. All authors have read and agreed to the published version of the manuscript.
Funding
This research received no external funding.
Data Availability Statement
The original contributions presented in this study are included in the article.
Acknowledgments
The evaluation of the system's output randomness was conducted using the NIST Statistical Test Suite, which provided a standardized and comprehensive framework for validating the quality of the cryptosystem.
Conflicts of Interest
The authors declare no conflicts of interest.
Abbreviations
The following abbreviations are used in this manuscript:
References
Scripcariu, L.; Diaconu, F.; Mătăsaru, P.D.; Gafencu, L. AES Vulnerabilities Study. In Proceedings of the 10th International Conference on Electronics, Computers and Artificial Intelligence (ECAI), Iasi, Romania, 28–30 June 2018. [ Google Scholar] [ CrossRef]
Rahmani, M.; Nitaj, A.; Ziane, M. Partial Exposure Attacks on a New RSA Variant. Cryptography 2024, 8, 44. [ Google Scholar] [ CrossRef]
American Scientist. Available online: https://www.americanscientist.org/article/is-quantum-computing-a-cybersecurity-threat (accessed on 7 May 2025).
Alexan, W.; Youssef, M.; Hussein, H.H.; Ahmed, K.K.; Hosny, K.M.; Fathy, A.; Mansour, M.B.M. A new multiple image encryption algorithm using hyperchaotic systems, SVD, and modified RC5. Sci. Rep. 2025, 15, 9775. [ Google Scholar] [ CrossRef]
Cantoro, R.; Deligiannis, N.I.; Reorda, M.S.; Traiola, M.; Valea, E. Evaluating Data Encryption Effects on the Resilience of an Artificial Neural Network. In Proceedings of the 2020 IEEE International Symposium on Defect and Fault Tolerance in VLSI and Nanotechnology Systems (DFT), Frascati, Italy, 19–21 October 2020; pp. 1–4. [ Google Scholar] [ CrossRef]
Deng, Q.; Wang, C.; Sun, Y.; Deng, Z.; Yang, G. Memristive Tabu Learning Neuron Generated Multi-Wing Attractor with FPGA Implementation and Application in Encryption. IEEE Trans. Circuits Syst. I Regul. Pap. 2024, 72, 300–311. [ Google Scholar] [ CrossRef]
Huang, Y.; Zhang, S.; Wang, B. An Improved Genetic Algorithm with Swarm Intelligence for Security-Aware Task Scheduling in Hybrid Clouds. Electronics 2023, 12, 2064. [ Google Scholar] [ CrossRef]
Jiang, M.; Yang, H. Image Encryption Using a New Hybrid Chaotic Map and Spiral Transformation. Entropy 2023, 25, 1516. [ Google Scholar] [ CrossRef] [ PubMed]
Corona-Bermúdez, E.; Chimal-Eguía, J.C.; Téllez-Castillo, G. Cryptographic Services Based on Elementary and Chaotic Cellular Automata. Electronics 2022, 11, 613. [ Google Scholar] [ CrossRef]
Levina, A.; Mukhamedjanov, D.; Bogaevskiy, D.; Lyakhov, P.; Valueva, M.; Kaplun, D. High Performance Parallel Pseudorandom Number Generator on Cellular Automata. Symmetry 2022, 14, 1869. [ Google Scholar] [ CrossRef]
Stănică, G.C.; Anghelescu, P. Reversible cellular automata encryption algorithm implemented on FPGA. In Proceedings of the 2023 International Conference on Applied Electronics (AE), Pilsen, Czech Republic, 6–7 September 2023; pp. 1–4. [ Google Scholar] [ CrossRef]
Stănică, G.C.; Anghelescu, P. Reversible Cellular Automata Based Cryptosystem. Electronics 2024, 13, 2515. [ Google Scholar] [ CrossRef]
Wang, X.Y.; Li, L.; Sun, B. Chaotic Image Encryption Algorithm Based on Block Theory and Reversible Mixed Cellular Automata. Opt. Laser Technol. 2020, 121, 105756. [ Google Scholar]
Zhang, B.; Liu, L. Chaos-Based Image Encryption: Review, Application, and Challenges. Mathematics 2023, 11, 2585. [ Google Scholar] [ CrossRef]
Chen, K.; Wang, X.; Fu, Y.; Li, L. Efficient Quantization and Data Access for Accelerating Homomorphic Encrypted CNNs. Electronics 2025, 14, 464. [ Google Scholar] [ CrossRef]
Abbassi, N.; Gafsi, M.; Amdouni, R.; Hajjaji, M.A.; Mtibaa, A. Hardware implementation of a robust image cryptosystem using reversible cellular-automata rules and 3-D chaotic systems. Integration 2022, 87, 49–66. [ Google Scholar] [ CrossRef]
Nanda, S.K.; Mohanty, S.; Pattnaik, P.K.; Sain, M. Throughput Optimized Reversible Cellular Automata Based Security Algorithm. Electronics 2022, 11, 3190. [ Google Scholar] [ CrossRef]
Siddiqui, A.F.; Sekhar, C. FPGA Acceleration of AES Algorithm for High-Performance Cryptographic Applications. Int. J. Inf. Technol. Comput. Eng. 2024, 4, 1–11. [ Google Scholar] [ CrossRef]
Yang, C.-H.; Lee, J.-D.; Tam, L.-M.; Li, S.-Y.; Cheng, S.-C. FPGA Implementation of Image Encryption by Adopting New Shimizu–Morioka System-Based Chaos Synchronization. Electronics 2025, 14, 740. [ Google Scholar] [ CrossRef]
Guang, Y.; Yu, L.; Dong, W.; Wang, Y.; Zeng, J.; Zhao, J.; Ding, Q. Chaos-Based Lightweight Cryptographic Algorithm Design and FPGA Implementation. Entropy 2022, 24, 1610. [ Google Scholar] [ CrossRef]
Stănică, G.C.; Anghelescu, P. Design of a Multi-Layer Symmetric Encryption System Using Reversible Cellular Automata. Mathematics 2025, 13, 304. [ Google Scholar] [ CrossRef]
Wolfram, S. A New Kind of Science; Wolfram Media: Champaign, IL, USA, 2002. [ Google Scholar]
Anghelescu, P. Evolution of Hybrid Cellular Automata for Density Classification Problem. Symmetry 2024, 16, 599. [ Google Scholar] [ CrossRef]
Stănică, G.C.; Anghelescu, P. Cryptographic Algorithm Based on Hybrid One-Dimensional Cellular Automata. Mathematics 2023, 11, 1481. [ Google Scholar] [ CrossRef]
Wolfram, S. Random Sequence Generation by Cellular Automata. Adv. Appl. Math. 1986, 7, 123–169. [ Google Scholar] [ CrossRef]
Hatkar, S.S.; Pawar, B.K. Symmetric key algorithm using Vernam cipher: VSA. In Proceedings of the International Conference on Inventive Computation Technologies (ICICT), Coimbatore, India, 26–27 August 2016. [ Google Scholar]
Hortensius, P.; McLeod, R.; Card, H. Parallel random number generation for VLSI systems using cellular automata. IEEE Trans. Comput. 1989, 38, 1466–1473. [ Google Scholar] [ CrossRef]
Bassham, L.; Rukhin, A.; Soto, J.; Nechvatal, J.; Smid, M.; Leigh, S.; Levenson, M.; Vangel, M.; Heckert, N.; Banks, D. A Statistical Test Suite for Random and Pseudorandom Number Generators for Cryptographic Applications; National Institute of Standards and Technology: Gaithersburg, MD, USA, 2010; pp. 800–822. [ Google Scholar]
Anghelescu, P. Parallel Optimization of Program Instructions Using Genetic Algorithms. Comput. Mater. Contin. 2021, 67, 3293–3310. [ Google Scholar] [ CrossRef]
Li, H.; Li, T.; Feng, W.; Zhang, J.; Zhang, J.; Gan, L.; Li, C. A novel image encryption scheme based on non-adjacent parallelable permutation and dynamic DNA-level two-way diffusion. J. Inf. Secur. Appl. 2021, 61, 102844. [ Google Scholar] [ CrossRef]
Hua, Z.; Zhu, Z.; Yi, S.; Zhang, Z.; Huang, H. Cross-plane colour image encryption using a two-dimensional logistic tent modular map. Inf. Sci. 2021, 546, 1063–1083. [ Google Scholar] [ CrossRef]
Li, H.; Yu, S.; Feng, W.; Chen, Y.; Zhang, J.; Qin, Z.; Zhu, Z.; Wozniak, M. Exploiting Dynamic Vector-Level Operations and a 2D-Enhanced Logistic Modular Map for Efficient Chaotic Image Encryption. Entropy 2023, 25, 1147. [ Google Scholar] [ CrossRef]
Figure 1. Graphical representation of rules 90 and 150.
Figure 2. Reversible cellular automata cell state evolution.
Figure 3. Encryption and decryption mechanisms based on reversible cellular automata.
Figure 4. Flow diagram of a single encryption round.
Figure 5. Successive block encryption of plaintext blocks.
Figure 6. Shift value generation process.
Figure 7. Usage of LHCA randomly generated data.
Figure 8. Key structure and role breakdown.
Figure 9. Cryptosystem block diagram.
Figure 10. Cryptosystem top-level hardware design.
Figure 11. Software application interface.
Figure 12. Data dispersion across ASCII values. ( a) Original data; ( b) encrypted data.
Table 1. Binary representation of two evolution rules (90 and 150).
Rule in decimal form. Evolution of central cell is considered in each case.
Table 2. Rule combination order for maximum cycle length.
Table 3. NIST-based randomness validation of encrypted bitstreams.
Table 4. Binary value distribution analysis of encrypted sequences.
Table 5. Hardware implementation summary.
Table 6. Comparative analysis results.
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
© 2025 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license ( https://creativecommons.org/licenses/by/4.0/).
Share and Cite
      
MDPI and ACS Style
Stănică, G.C.; Anghelescu, P. Multi-Layer Cryptosystem Using Reversible Cellular Automata. Electronics 2025, 14, 2627. https://doi.org/10.3390/electronics14132627
AMA Style
Stănică GC, Anghelescu P. Multi-Layer Cryptosystem Using Reversible Cellular Automata. Electronics. 2025; 14(13):2627. https://doi.org/10.3390/electronics14132627
Chicago/Turabian Style
Stănică, George Cosmin, and Petre Anghelescu. 2025. "Multi-Layer Cryptosystem Using Reversible Cellular Automata" Electronics 14, no. 13: 2627. https://doi.org/10.3390/electronics14132627
APA Style
Stănică, G. C., & Anghelescu, P. (2025). Multi-Layer Cryptosystem Using Reversible Cellular Automata. Electronics, 14(13), 2627. https://doi.org/10.3390/electronics14132627
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
Article Metrics
Yes
Citations
No citations were found for this article, but you may check on Google Scholar
No
Article Access Statistics
Created with Highcharts 4.0.4 Article access statistics Article Views 11. Mar 12. Mar 13. Mar 14. Mar 15. Mar 16. Mar 17. Mar 18. Mar 19. Mar 20. Mar 21. Mar 22. Mar 23. Mar 24. Mar 25. Mar 26. Mar 27. Mar 28. Mar 29. Mar 30. Mar 31. Mar 1. Apr 2. Apr 3. Apr 4. Apr 5. Apr 6. Apr 7. Apr 8. Apr 9. Apr 10. Apr 11. Apr 12. Apr 13. Apr 14. Apr 15. Apr 16. Apr 17. Apr 18. Apr 19. Apr 20. Apr 21. Apr 22. Apr 23. Apr 24. Apr 25. Apr 26. Apr 27. Apr 28. Apr 29. Apr 30. Apr 1. May 2. May 3. May 4. May 5. May 6. May 7. May 8. May 9. May 10. May 11. May 12. May 13. May 14. May 15. May 16. May 17. May 18. May 19. May 20. May 21. May 22. May 23. May 24. May 25. May 26. May 27. May 28. May 29. May 30. May 31. May 1. Jun 2. Jun 3. Jun 4. Jun 5. Jun 6. Jun 7. Jun 8. Jun 0 250 500 750 1000 1250 1500
For more information on the journal statistics, click here.
Multiple requests from the same IP address are counted as one view.
Zoom | Orient | As Lines | As Sticks | As Cartoon | As Surface | Previous Scene | Next Scene
Cite
Export citation file: BibTeX | EndNote | RIS
MDPI and ACS Style
Stănică, G.C.; Anghelescu, P. Multi-Layer Cryptosystem Using Reversible Cellular Automata. Electronics 2025, 14, 2627. https://doi.org/10.3390/electronics14132627
AMA Style
Stănică GC, Anghelescu P. Multi-Layer Cryptosystem Using Reversible Cellular Automata. Electronics. 2025; 14(13):2627. https://doi.org/10.3390/electronics14132627
Chicago/Turabian Style
Stănică, George Cosmin, and Petre Anghelescu. 2025. "Multi-Layer Cryptosystem Using Reversible Cellular Automata" Electronics 14, no. 13: 2627. https://doi.org/10.3390/electronics14132627
APA Style
Stănică, G. C., & Anghelescu, P. (2025). Multi-Layer Cryptosystem Using Reversible Cellular Automata. Electronics, 14(13), 2627. https://doi.org/10.3390/electronics14132627
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
clear
Electronics, EISSN 2079-9292, Published by MDPI
RSS Content Alert
Further Information
Article Processing Charges Pay an Invoice Open Access Policy Contact MDPI Jobs at MDPI
Guidelines
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
MDPI Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
Follow MDPI
LinkedIn Facebook X 
Subscribe to receive issue release notifications and newsletters from MDPI journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies
Climate
Clinical and Translational Neuroscience
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications
Eng
Engineering Proceedings
Entropic and Disordered Matter
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal
European Journal of Investigation in Health, Psychology and Education
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences
International Journal of Environmental Medicine
International Journal of Environmental Research and Public Health
International Journal of Financial Studies
International Journal of Medical Devices
International Journal of Molecular Sciences
International Journal of Neonatal Screening
International Journal of Orofacial Myology and Myofunctional Therapy
International Journal of Plant Biology
International Journal of Topology
International Journal of Translational Medicine
International Journal of Turbomachinery, Propulsion and Power
International Medical Education
Inventions
IoT
ISPRS International Journal of Geo-Information
J
Journal of Aesthetic Medicine
Journal of Ageing and Longevity
Journal of CardioRenal Medicine
Journal of Cardiovascular Development and Disease
Journal of Clinical & Translational Ophthalmology
Journal of Clinical Medicine
Journal of Composites Science
Journal of Cybersecurity and Privacy
Journal of Dementia and Alzheimer's Disease
Journal of Developmental Biology
Journal of Experimental and Theoretical Analyses
Journal of Eye Movement Research
Journal of Functional Biomaterials
Journal of Functional Morphology and Kinesiology
Journal of Fungi
Journal of Genome Biotechnology and Genetics
Journal of Gerontology and Geriatrics
Journal of Imaging
Journal of Innovation
Journal of Intelligence
Journal of Interdisciplinary Research Applied to Medicine
Journal of Low Power Electronics and Applications
Journal of Manufacturing and Materials Processing
Journal of Marine Science and Engineering
Journal of Market Access & Health Policy
Journal of Mind and Medical Sciences
Journal of Molecular Pathology
Journal of Nanotheranostics
Journal of Nuclear Engineering
Journal of Otorhinolaryngology, Hearing and Balance Medicine
Journal of Parks
Journal of Personalized Medicine
Journal of Pharmaceutical and BioTech Industry
Journal of Phytomedicine
Journal of Respiration
Journal of Risk and Financial Management
Journal of Sensor and Actuator Networks
Journal of Superintelligence
Journal of the American Podiatric Medical Association
Journal of the Oman Medical Association
Journal of Theoretical and Applied Electronic Commerce Research
Journal of Vascular Diseases
Journal of Xenobiotics
Journal of Zoological and Botanical Gardens
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics
Religions
Remote Sensing
Reports
Reproductive Medicine
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine
Ruminants
Safety
Sci
Scientia Pharmaceutica
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal
Youth
Zoonotic Diseases
Select options
[-] accountaudit Accounting and Auditing [-] acoustics Acoustics [-] amh Acta Microbiologica Hellenica [-] actuators Actuators [-] adhesives Adhesives [-] admsci Administrative Sciences [-] adolescents Adolescents [-] arm Advances in Respiratory Medicine [-] aerobiology Aerobiology [-] aerospace Aerospace [-] agriculture Agriculture [-] agriengineering AgriEngineering [-] agrochemicals Agrochemicals [-] agronomy Agronomy [-] ai AI [-] aichem AI Chemistry [-] aieng AI for Engineering [-] aieduc AI in Education [-] aimed AI in Medicine [-] aimater AI Materials [-] aisens AI Sensors [-] air Air [-] algorithms Algorithms [-] allergies Allergies [-] alloys Alloys [-] analog Analog [-] analytica Analytica [-] analytics Analytics [-] anatomia Anatomia [-] anesthres Anesthesia Research [-] animals Animals [-] antibiotics Antibiotics [-] antibodies Antibodies [-] antioxidants Antioxidants [-] applbiosci Applied Biosciences [-] applmech Applied Mechanics [-] applmicrobiol Applied Microbiology [-] applnano Applied Nano [-] applsci Applied Sciences [-] asi Applied System Innovation [-] appliedchem AppliedChem [-] appliedmath AppliedMath [-] appliedphys AppliedPhys [-] aquacj Aquaculture Journal [-] architecture Architecture [-] arthropoda Arthropoda [-] arts Arts [-] astronautics Astronautics [-] astronomy Astronomy [-] atmosphere Atmosphere [-] atoms Atoms [-] audiolres Audiology Research [-] automation Automation [-] axioms Axioms [-] bacteria Bacteria [-] batteries Batteries [-] behavsci Behavioral Sciences [-] beverages Beverages [-] BDCC Big Data and Cognitive Computing [-] biochem BioChem [-] bioengineering Bioengineering [-] biologics Biologics [-] biology Biology [-] blsf Biology and Life Sciences Forum [-] biomass Biomass [-] biomechanics Biomechanics [-] biomed BioMed [-] biomedicines Biomedicines [-] biomedinformatics BioMedInformatics [-] biomimetics Biomimetics [-] biomolecules Biomolecules [-] biophysica Biophysica [-] bioresourbioprod Bioresources and Bioproducts [-] biosensors Biosensors [-] biosphere Biosphere [-] biotech BioTech [-] birds Birds [-] blockchains Blockchains [-] brainsci Brain Sciences [-] buildings Buildings [-] businesses Businesses [-] carbon C [-] cancers Cancers [-] cardiogenetics Cardiogenetics [-] cardiovascmed Cardiovascular Medicine [-] catalysts Catalysts [-] cells Cells [-] ceramics Ceramics [-] challenges Challenges [-] ChemEngineering ChemEngineering [-] chemistry Chemistry [-] chemproc Chemistry Proceedings [-] chemosensors Chemosensors [-] children Children [-] chips Chips [-] civileng CivilEng [-] cleantechnol Clean Technologies [-] climate Climate [-] ctn Clinical and Translational Neuroscience [-] clinbioenerg Clinical Bioenergetics [-] clinpract Clinics and Practice [-] clockssleep Clocks & Sleep [-] coasts Coasts [-] coatings Coatings [-] colloids Colloids and Interfaces [-] colorants Colorants [-] commodities Commodities [-] complexities Complexities [-] complications Complications [-] compounds Compounds [-] computation Computation [-] csmf Computer Sciences & Mathematics Forum [-] computers Computers [-] condensedmatter Condensed Matter [-] conservation Conservation [-] constrmater Construction Materials [-] cmd Corrosion and Materials Degradation [-] cosmetics Cosmetics [-] covid COVID [-] cmtr Craniomaxillofacial Trauma & Reconstruction [-] crops Crops [-] cryo Cryo [-] cryptography Cryptography [-] crystals Crystals [-] culture Culture [-] cimb Current Issues in Molecular Biology [-] curroncol Current Oncology [-] dairy Dairy [-] data Data [-] dentistry Dentistry Journal [-] dermato Dermato [-] dermatopathology Dermatopathology [-] designs Designs [-] diabetology Diabetology [-] diagnostics Diagnostics [-] dietetics Dietetics [-] digital Digital [-] dhi Digital Health and Innovation [-] disabilities Disabilities [-] diseases Diseases [-] diversity Diversity [-] dna DNA [-] drones Drones [-] ddc Drugs and Drug Candidates [-] dynamics Dynamics [-] earth Earth [-] ecologies Ecologies [-] econometrics Econometrics [-] economies Economies [-] education Education Sciences [-] electricity Electricity [-] electrochem Electrochem [-] electronicmat Electronic Materials [-] electronics Electronics [-] ecm Emergency Care and Medicine [-] encyclopedia Encyclopedia [-] endocrines Endocrines [-] energies Energies [-] esa Energy Storage and Applications [-] eng Eng [-] engproc Engineering Proceedings [-] edm Entropic and Disordered Matter [-] entropy Entropy [-] eesp Environmental and Earth Sciences Proceedings [-] environremediat Environmental Remediation [-] environments Environments [-] epidemiologia Epidemiologia [-] epigenomes Epigenomes [-] ebj European Burn Journal [-] ejihpe European Journal of Investigation in Health, Psychology and Education [-] famsci Family Sciences [-] fermentation Fermentation [-] fibers Fibers [-] fintech FinTech [-] fire Fire [-] fishes Fishes [-] fluids Fluids [-] foods Foods [-] forecasting Forecasting [-] forensicsci Forensic Sciences [-] forests Forests [-] fossstud Fossil Studies [-] foundations Foundations [-] fractalfract Fractal and Fractional [-] freshwater Freshwater [-] fuels Fuels [-] future Future [-] fclam Future Collections, Libraries, Archives, and Museums [-] futureinternet Future Internet [-] futurepharmacol Future Pharmacology [-] futuretransp Future Transportation [-] galaxies Galaxies [-] games Games [-] gases Gases [-] gastroent Gastroenterology Insights [-] gastrointestdisord Gastrointestinal Disorders [-] gastronomy Gastronomy [-] gels Gels [-] genealogy Genealogy [-] genes Genes [-] geographies Geographies [-] geohazards GeoHazards [-] geomatics Geomatics [-] geometry Geometry [-] geosciences Geosciences [-] geotechnics Geotechnics [-] geriatrics Geriatrics [-] germs Germs [-] glacies Glacies [-] gucdd Gout, Urate, and Crystal Deposition Disease [-] grasses Grasses [-] green Green [-] greenhealth Green Health [-] hardware Hardware [-] healthcare Healthcare [-] hearts Hearts [-] hemato Hemato [-] hematolrep Hematology Reports [-] heritage Heritage [-] histories Histories [-] horticulturae Horticulturae [-] hospitals Hospitals [-] humanities Humanities [-] humans Humans [-] hydrobiology Hydrobiology [-] hydrogen Hydrogen [-] hydrology Hydrology [-] hydropower Hydropower [-] hygiene Hygiene [-] immuno Immuno [-] industries Industries [-] idr Infectious Disease Reports [-] inflammj Inflammation Journal [-] informatics Informatics [-] information Information [-] infrastructures Infrastructures [-] inorganics Inorganics [-] insects Insects [-] instruments Instruments [-] iic Intelligent Infrastructure and Construction [-] ijcs International Journal of Cognitive Sciences [-] ijem International Journal of Environmental Medicine [-] ijerph International Journal of Environmental Research and Public Health [-] ijfs International Journal of Financial Studies [-] ijmd International Journal of Medical Devices [-] ijms International Journal of Molecular Sciences [-] IJNS International Journal of Neonatal Screening [-] ijom International Journal of Orofacial Myology and Myofunctional Therapy [-] ijpb International Journal of Plant Biology [-] ijt International Journal of Topology [-] ijtm International Journal of Translational Medicine [-] ijtpp International Journal of Turbomachinery, Propulsion and Power [-] ime International Medical Education [-] inventions Inventions [-] IoT IoT [-] ijgi ISPRS International Journal of Geo-Information [-] J J [-] jaestheticmed Journal of Aesthetic Medicine [-] jal Journal of Ageing and Longevity [-] jcrm Journal of CardioRenal Medicine [-] jcdd Journal of Cardiovascular Development and Disease [-] jcto Journal of Clinical & Translational Ophthalmology [-] jcm Journal of Clinical Medicine [-] jcs Journal of Composites Science [-] jcp Journal of Cybersecurity and Privacy [-] jdad Journal of Dementia and Alzheimer's Disease [-] jdb Journal of Developmental Biology [-] jeta Journal of Experimental and Theoretical Analyses [-] jemr Journal of Eye Movement Research [-] jfb Journal of Functional Biomaterials [-] jfmk Journal of Functional Morphology and Kinesiology [-] jof Journal of Fungi [-] jgbg Journal of Genome Biotechnology and Genetics [-] jgg Journal of Gerontology and Geriatrics [-] jimaging Journal of Imaging [-] joi Journal of Innovation [-] jintelligence Journal of Intelligence [-] jdream Journal of Interdisciplinary Research Applied to Medicine [-] jlpea Journal of Low Power Electronics and Applications [-] jmmp Journal of Manufacturing and Materials Processing [-] jmse Journal of Marine Science and Engineering [-] jmahp Journal of Market Access & Health Policy [-] jmms Journal of Mind and Medical Sciences [-] jmp Journal of Molecular Pathology [-] jnt Journal of Nanotheranostics [-] jne Journal of Nuclear Engineering [-] ohbm Journal of Otorhinolaryngology, Hearing and Balance Medicine [-] jop Journal of Parks [-] jpm Journal of Personalized Medicine [-] jpbi Journal of Pharmaceutical and BioTech Industry [-] jphytomed Journal of Phytomedicine [-] jor Journal of Respiration [-] jrfm Journal of Risk and Financial Management [-] jsan Journal of Sensor and Actuator Networks [-] superintelligence Journal of Superintelligence [-] japma Journal of the American Podiatric Medical Association [-] joma Journal of the Oman Medical Association [-] jtaer Journal of Theoretical and Applied Electronic Commerce Research [-] jvd Journal of Vascular Diseases [-] jox Journal of Xenobiotics [-] jzbg Journal of Zoological and Botanical Gardens [-] journalmedia Journalism and Media [-] kidneydial Kidney and Dialysis [-] kinasesphosphatases Kinases and Phosphatases [-] knowledge Knowledge [-] labmed LabMed [-] laboratories Laboratories [-] land Land [-] languages Languages [-] laws Laws [-] life Life [-] lights Lights [-] limnolrev Limnological Review [-] lipidology Lipidology [-] liquids Liquids [-] literature Literature [-] livers Livers [-] logics Logics [-] logistics Logistics [-] lae Low-Altitude Economy [-] lubricants Lubricants [-] lymphatics Lymphatics [-] make Machine Learning and Knowledge Extraction [-] machines Machines [-] macromol Macromol [-] magnetism Magnetism [-] magnetochemistry Magnetochemistry [-] marinedrugs Marine Drugs [-] materials Materials [-] materproc Materials Proceedings [-] mca Mathematical and Computational Applications [-] mathematics Mathematics [-] medsci Medical Sciences [-] msf Medical Sciences Forum [-] medicina Medicina [-] medicines Medicines [-] membranes Membranes [-] merits Merits [-] metabolites Metabolites [-] metals Metals [-] meteorology Meteorology [-] methane Methane [-] mps Methods and Protocols [-] metrics Metrics [-] metrology Metrology [-] micro Micro [-] microbiolres Microbiology Research [-] microelectronics Microelectronics [-] micromachines Micromachines [-] microorganisms Microorganisms [-] microplastics Microplastics [-] microwave Microwave [-] minerals Minerals [-] mining Mining [-] modelling Modelling [-] mmphys Modern Mathematical Physics [-] molbank Molbank [-] molecules Molecules [-] multimedia Multimedia [-] mti Multimodal Technologies and Interaction [-] muscles Muscles [-] nanoenergyadv Nanoenergy Advances [-] nanomanufacturing Nanomanufacturing [-] nanomaterials Nanomaterials [-] ndt NDT [-] network Network [-] neuroglia Neuroglia [-] neuroimaging Neuroimaging [-] neurolint Neurology International [-] neurosci NeuroSci [-] nitrogen Nitrogen [-] ncrna Non-Coding RNA [-] nursrep Nursing Reports [-] nutraceuticals Nutraceuticals [-] nutrients Nutrients [-] obesities Obesities [-] occuphealth Occupational Health [-] oceans Oceans [-] onco Onco [-] optics Optics [-] oral Oral [-] organics Organics [-] organoids Organoids [-] osteology Osteology [-] oxygen Oxygen [-] pandemics Pandemics [-] parasitologia Parasitologia [-] particles Particles [-] pathogens Pathogens [-] pathophysiology Pathophysiology [-] peacestud Peace Studies [-] pediatrrep Pediatric Reports [-] pets Pets [-] pharmaceuticals Pharmaceuticals [-] pharmaceutics Pharmaceutics [-] pharmacoepidemiology Pharmacoepidemiology [-] pharmacy Pharmacy [-] philosophies Philosophies [-] photochem Photochem [-] photonics Photonics [-] phycology Phycology [-] physchem Physchem [-] psf Physical Sciences Forum [-] physics Physics [-] physiologia Physiologia [-] plants Plants [-] plasma Plasma [-] platforms Platforms [-] pollutants Pollutants [-] polymers Polymers [-] polysaccharides Polysaccharides [-] populations Populations [-] poultry Poultry [-] powders Powders [-] precisoncol Precision Oncology [-] phc Primary and Hospital Care [-] proceedings Proceedings [-] processes Processes [-] prosthesis Prosthesis [-] proteomes Proteomes [-] psychiatryint Psychiatry International [-] psychoactives Psychoactives [-] psycholint Psychology International [-] publications Publications [-] purification Purification [-] qubs Quantum Beam Science [-] quantumrep Quantum Reports [-] quaternary Quaternary [-] radiation Radiation [-] reactions Reactions [-] realestate Real Estate [-] receptors Receptors [-] recycling Recycling [-] rsee Regional Science and Environmental Economics [-] religions Religions [-] remotesensing Remote Sensing [-] reports Reports [-] reprodmed Reproductive Medicine [-] resources Resources [-] rheumato Rheumato [-] risks Risks [-] robotics Robotics [-] rjpm Romanian Journal of Preventive Medicine [-] ruminants Ruminants [-] safety Safety [-] sci Sci [-] scipharm Scientia Pharmaceutica [-] sclerosis Sclerosis [-] seeds Seeds [-] shi Semiconductors and Heterogeneous Integration [-] sensors Sensors [-] separations Separations [-] sexes Sexes [-] signals Signals [-] sinusitis Sinusitis [-] smartcities Smart Cities [-] socsci Social Sciences [-] siuj Société Internationale d'Urologie Journal [-] societies Societies [-] software Software [-] soilsystems Soil Systems [-] solar Solar [-] solids Solids [-] spectroscj Spectroscopy Journal [-] sports Sports [-] standards Standards [-] stats Stats [-] stratsediment Stratigraphy and Sedimentology [-] stresses Stresses [-] surfaces Surfaces [-] surgeries Surgeries [-] std Surgical Techniques Development [-] sustainability Sustainability [-] suschem Sustainable Chemistry [-] sanpp Swiss Archives of Neurology, Psychiatry and Psychotherapy [-] symmetry Symmetry [-] synbio SynBio [-] systems Systems [-] targets Targets [-] taxonomy Taxonomy [-] technologies Technologies [-] telecom Telecom [-] textiles Textiles [-] thalassrep Thalassemia Reports [-] tae Theoretical and Applied Ergonomics [-] therapeutics Therapeutics [-] thermo Thermo [-] timespace Time and Space [-] tomography Tomography [-] tourismhosp Tourism and Hospitality [-] toxics Toxics [-] toxins Toxins [-] transplantology Transplantology [-] traumacare Trauma Care [-] higheredu Trends in Higher Education [-] tph Trends in Public Health [-] tropicalmed Tropical Medicine and Infectious Disease [-] universe Universe [-] urbansci Urban Science [-] uro Uro [-] vaccines Vaccines [-] vehicles Vehicles [-] venereology Venereology [-] vetsci Veterinary Sciences [-] vibration Vibration [-] virtualworlds Virtual Worlds [-] viruses Viruses [-] vision Vision [-] waste Waste [-] water Water [-] welding Welding [-] wild Wild [-] wind Wind [-] women Women [-] world World [-] wevj World Electric Vehicle Journal [-] youth Youth [-] zoonoticdis Zoonotic Diseases
Subscribe
© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated
Disclaimer
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
Legal Notice Terms and Conditions Privacy Policy Privacy Settings Accessibility
We use cookies on our website to ensure you get the best experience.
Read more about our cookies here.
Accept
Share Link
        https://www.mdpi.com/3380790
Copy
clear
Share
https://www.mdpi.com/3380790
clear
Back to Top Top
All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.
You can change your mind at any time by clicking "Privacy Settings" at the bottom of the pages.  
Accept All
Deny
More Information
Powered by Usercentrics Consent Management