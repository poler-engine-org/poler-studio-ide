"""poler_dynamis_v4.py — POLER DYNAMIS v4: Supreme Law Architecture
Каноническое уравнение движения: dDM/dt = -η·(Δ_idem + γ·J·DM + K)
АРХИТЕКТУРА v4 — ЗАКОН ЕДИН: Каноническое уравнение — ЗАКОН эволюции системы. Диагонализация Фока — предельный случай закона при η→∞: Когда шаг бесконечен, поток мгновенно «перепрыгивает» к ближайшему стационарному состоянию на многообразии Грассмана. Это и есть Fock→eig→DM — не «подчинение SCF», а частный случай применения того же закона.
Двухфазная стратегия: ФАЗА 1 (η→∞, coarse): Fock diagonalization → DM_idempotent Эквивалент прыжка канонического потока к аттрактору. Применяется пока ||[F,DM]|| > τ_coarse. ФАЗА 2 (η<1, fine):   POLER-flow с Δ_idem + J + K Тонкая доводка — POLER «скатывается» к точному минимуму. Здесь проявляются преимущества POLER: резонанс J протаскивает через локальные минимумы, Δ_idem плавно очищает.
PySCF — ТОЛЬКО сенсор (поставляет S, h1e, eri). DIIS — устранён (резонанс J = темпоральное эхо R[n] заменяет его).
Сведение к Шрёдингеру (вырожденный случай): При D=0, ∇F=0 → dDM/dt = -η·γ·J(DM) ≡ iℏ∂ψ/∂t = Ĥψ
Author: POLER-Quantum DYNAMIS Team Version: 4.1 — Supreme Law, Two-Phase """
from future import annotations
from dataclasses import dataclass, field from enum import Enum from typing import Dict, List, Optional, Tuple
import numpy as np import scipy.linalg
Array = np.ndarray
class PolerMode(Enum): A = "dissipative" B = "resonant" C = "adaptive"
@dataclass class DynamisParams: """Гиперпараметры POLER-DYNAMIS v4.1.""" mode: PolerMode = PolerMode.A eta0: float = 0.5 beta_sigma: float = 1.0 sigma_ema_alpha: float = 0.3 gamma: float = 0.1 j_strength: float = 0.3 d_strength: float = 1.0 eps_F: float = 1e-6 backtrack_factor: float = 0.5 max_backtracks: int = 8 mcweeny_order: int = 2 mcweeny_always: bool = True    # Фаза 2: Π_Λ всегда (DM уже идемпотентна) mcweeny_threshold: float = 0.1 t_total: int = 200 tau: float = 1e-8 tau_coarse: float = 1e-4       # Порог Фазы 1→2 max_iter: int = 300 dt: float = 1.0 resonance_depth: int = 10 occ_max: float = 2.0
@dataclass class DynamisState: """Состояние POLER-эволюции v4.1.""" dm: Array dm_history: List[Array] = field(default_factory=list) fock_history: List[Array] = field(default_factory=list) energy_history: List[float] = field(default_factory=list) surprise_history: List[float] = field(default_factory=list) eta_history: List[float] = field(default_factory=list) step_count: int = 0 sigma_ema: float = 0.0 converged: bool = False phase: int = 1                 # 1 = coarse, 2 = fine comm_history: List[float] = field(default_factory=list) d_norm_history: List[float] = field(default_factory=list) j_norm_history: List[float] = field(default_factory=list) kick_accepted: int = 0 kick_rejected: int = 0
═══════════════════════════════════════════════════════════════════════════════
МЕХАНИЗМЫ
═══════════════════════════════════════════════════════════════════════════════
def mcweeny_purify(dm: Array, order: int = 1, occ_max: float = 2.0) -> Array: c1 = 3.0 / occ_max c2 = 2.0 / (occ_max * occ_max) dm_pure = dm.copy() for _ in range(order): dm_sq = dm_pure @ dm_pure dm_cu = dm_sq @ dm_pure dm_pure = c1 * dm_sq - c2 * dm_cu return dm_pure
def mcweeny_trace_preserving(dm: Array, nelec: float, S: Array, order: int = 1, occ_max: float = 2.0) -> Array: dm_pure = mcweeny_purify(dm, order, occ_max) current_nelec = np.real(np.trace(dm_pure @ S)) if abs(current_nelec) > 1e-12: dm_pure *= nelec / current_nelec return dm_pure
def compute_surprise(fock: Array, dm: Array) -> float: return float(np.linalg.norm(fock @ dm - dm @ fock, 'fro'))
def compute_normalized_surprise(fock: Array, dm: Array, S: Array) -> float: comm = fock @ dm - dm @ fock scale = np.linalg.norm(fock @ dm @ S, 'fro') if scale < 1e-15: return 0.0 return float(np.linalg.norm(comm, 'fro') / scale)
def adaptive_eta(surprise_norm: float, eta0: float, beta_sigma: float, sigma_ema: float, ema_alpha: float) -> Tuple[float, float]: sigma_ema_new = ema_alpha * surprise_norm + (1.0 - ema_alpha) * sigma_ema eta_t = eta0 * np.exp(-beta_sigma * sigma_ema_new) eta_t = max(eta_t, 1e-4) return float(eta_t), float(sigma_ema_new)
def compute_free_energy(dm: Array, fock: Array, h1e: Array, S: Array) -> float: return float(0.5 * (np.real(np.trace(h1e @ dm)) + np.real(np.trace(fock @ dm))))
def _compute_idempotency_dissipator(dm: Array, strength: float, occ_max: float = 2.0) -> Array: """Δ_idem = d_strength · (DM² - occ_max·DM). Обнуляется при DM² = occ_max·DM (идемпотентность).""" return strength * (dm @ dm - occ_max * dm)
def _compute_resonance(dm_history: List[Array], dim: int, strength: float, depth: int = 10) -> Array: if len(dm_history) < 2: return np.zeros((dim, dim)) A = np.zeros((dim, dim)) history = dm_history[-min(len(dm_history), depth):] for k in range(len(history) - 1): delta = history[k + 1] - history[k] A += history[k] @ delta.T A /= max(len(history) - 1, 1) return (A - A.T) * strength
def _get_gamma(params: DynamisParams, step: int) -> float: if params.mode == PolerMode.A: return 0.0 elif params.mode == PolerMode.B: return params.gamma else: T = max(params.t_total, 1) return params.gamma * max(1.0 - step / T, 0.0) ** 2
═══════════════════════════════════════════════════════════════════════════════
ФАЗА 1: FOCK EIG (η→∞ — предельный случай канонического уравнения)
═══════════════════════════════════════════════════════════════════════════════
def _fock_eig_step(fock: Array, S: Array, nelec: float, dim: int, nocc: int) -> Array: """Диагонализация Фока → DM_idempotent.
═══════════════════════════════════════════════════════════════════════════════
ЯДРО v4.1: ДВУХФАЗНАЯ ЭВОЛЮЦИЯ
═══════════════════════════════════════════════════════════════════════════════
def poler_scf_supreme( mol, params: Optional[DynamisParams] = None, verbose: bool = True, ) -> Tuple[float, Array, DynamisState]: """POLER-DYNAMIS v4.1: АБСОЛЮТНОЕ ВЕРХОВЕНСТВО ЗАКОНА.
═══════════════════════════════════════════════════════════════════════════════
СРАВНЕНИЕ
═══════════════════════════════════════════════════════════════════════════════
def poler_vs_standard(mol, params=None, verbose=True) -> Dict: from pyscf import scf if params is None: params = DynamisParams()
═══════════════════════════════════════════════════════════════════════════════
BRIDGE
═══════════════════════════════════════════════════════════════════════════════
def poler_dynamis_evolve(dm, fock, h1e, S, nelec, params=None, state=None): """Одна итерация POLER-flow (Фаза 2).""" if params is None: params = DynamisParams() dim = dm.shape[0] if state is None: state = DynamisState(dm=dm.copy())
═══════════════════════════════════════════════════════════════════════════════
УТИЛИТЫ
═══════════════════════════════════════════════════════════════════════════════
def auto_select_mode(bond_length: float = 0.0) -> PolerMode: if bond_length > 10.0: return PolerMode.C elif bond_length > 3.0: return PolerMode.B else: return PolerMode.A
def verify_idempotency(dm: Array, S: Array, occ_max: float = 2.0) -> float: return float(np.linalg.norm(dm @ dm - occ_max * dm, 'fro'))
def verify_electron_count(dm: Array, S: Array, expected: float) -> float: return float(np.real(np.trace(dm @ S)) - expected)
compute_topological_curvature = compute_normalized_surprise