> Source: https://docs.rs/faer/latest/faer/

faer - Rust
Docs.rs
faer-0.24.0
faer 0.24.0
Permalink
Docs.rs crate page
MIT
Links
Repository
crates.io
Source
Owners
sarah-quinones
Dependencies
bytemuck ^1.24.0 normal
dyn-stack ^0.13.2 normal
equator ^0.6.0 normal
faer-traits ^0.24.0 normal
gemm ^0.19.0 normal
generativity ^1.1.0 normal
libm ^0.2.15 normal
log ^0.4.29 normal optional
nano-gemm ^0.2.2 normal
npyz ^0.8.4 normal optional
num-complex ^0.4.6 normal
num-traits ^0.2.19 normal
pulp ^0.22.2 normal
rand ^0.9.2 normal optional
rand_distr ^0.5.1 normal optional
rayon ^1.11.0 normal optional
reborrow ^0.5.5 normal
spindle ^0.2.6 normal optional
aligned-vec ^0.6.4 dev
amd ^0.2.2 dev
approx ^0.5.1 dev
assert_approx_eq ^1.1.0 dev
curl ^0.4.49 dev
diol ^0.13.1 dev
flate2 ^1.1.5 dev
itertools ^0.14.0 dev
matrix-market-rs ^0.1.3 dev
nalgebra ^0.33 dev
serde ^1.0.228 dev
serde_json ^1.0.145 dev
serde_test ^1.0.177 dev
simba ^0.9.1 dev
tar ^0.4.44 dev
toml ^0.9.8 dev
lapack-sys ^0.15.0 dev
openmp-sys ^1.3.0 dev
blis-src ^0.2.2 dev
lapack-src ^0.13 dev
netlib-src ^0.9.0 dev
intel-mkl-src ^0.8.1 dev
lapack-src ^0.13 dev
lapack-src ^0.13 dev
openblas-src ^0.10.13 dev
suitesparse_sys ^0.1.4 dev
private-gemm-x86 ^0.1.20 normal optional
Versions
99.56% of the crate is documented
Platform
aarch64-apple-darwin
aarch64-unknown-linux-gnu
i686-pc-windows-msvc
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
Skip to main content
Crate faer
Settings
Help
faer 0.24.0
All Items
Sections
basic usage
example
matrix decompositions
L L ⊤ LL^\top L L ⊤ decomposition
L B L ⊤ LBL^\top L B L ⊤ decomposition
L U LU L U decomposition with partial pivoting
L U LU L U decomposition with full pivoting
Q R QR Q R decomposition
Q R QR Q R decomposition with column pivoting
singular value decomposition
eigendecomposition
crate features
Crate Items
Re-exports
Modules
Macros
Structs
Enums
Traits
Functions
Type Aliases
Crates
faer 
Crate faer Copy item path
Source
Search
Settings
Help
Summary
Expand description faer is a general-purpose linear algebra library for rust, with a focus on high performance for algebraic operations on medium/large matrices, as well as matrix decompositions
most of the high-level functionality in this library is provided through associated functions in its vocabulary types: Mat / MatRef / MatMut faer is recommended for applications that handle medium to large dense matrices, and its design is not well suited for applications that operate mostly on low dimensional vectors and matrices such as computer graphics or game development. for such applications, nalgebra and cgmath may be better suited
§ basic usage
Mat is a resizable matrix type with dynamic capacity, which can be created using [ Mat::new ] to produce an empty 0 × 0 0\times 0 0 × 0 matrix, [ Mat::zeros ] to create a rectangular matrix filled with zeros, [ Mat::identity ] to create an identity matrix, or [ Mat::from_fn ] for the more general case
Given a &Mat<T> (resp. &mut Mat<T> ), a MatRef<'_, T> (resp. MatMut<'_, T> ) can be created by calling [ Mat::as_ref ] (resp. [ Mat::as_mut ]), which allow for more flexibility than Mat in that they allow slicing ([ MatRef::get ]) and splitting ([ MatRef::split_at ]) MatRef and MatMut are lightweight view objects. the former can be copied freely while the latter has move and reborrow semantics, as described in its documentation
most of the matrix operations can be used through the corresponding math operators: + for matrix addition, - for subtraction, * for either scalar or matrix multiplication depending on the types of the operands.
§ example
§ matrix decompositions
faer provides a variety of matrix factorizations, each with its own advantages and drawbacks:
§ L L ⊤ LL^\top L L ⊤ decomposition
[ Mat::llt ] decomposes a self-adjoint positive definite matrix A A A such that A = L L H , A = LL^H, A= L L H, where L L L is a lower triangular matrix. this decomposition is highly efficient and has good stability properties
an implementation for sparse matrices is also available
§ L B L ⊤ LBL^\top L B L ⊤ decomposition
[ Mat::lblt ] decomposes a self-adjoint (possibly indefinite) matrix A A A such that P A P ⊤ = L B L H , P A P^\top = LBL^H, P A P ⊤= L B L H, where P P P is a permutation matrix, L L L is a lower triangular matrix, and B B B is a block diagonal matrix, with 1 × 1 1 \times 1 1 × 1 or 2 × 2 2 \times 2 2 × 2 diagonal blocks. this decomposition is efficient and has good stability properties
§ L U LU L U decomposition with partial pivoting
[ Mat::partial_piv_lu ] decomposes a square invertible matrix A A A into a lower triangular matrix L L L, a unit upper triangular matrix U U U, and a permutation matrix P P P, such that P A = L U PA = LU P A= L U it is used by default for computing the determinant, and is generally the recommended method for solving a square linear system or computing the inverse of a matrix (although we generally recommend using a faer::linalg::solvers::Solve instead of computing the inverse explicitly)
an implementation for sparse matrices is also available
§ L U LU L U decomposition with full pivoting
[ Mat::full_piv_lu ] decomposes a generic rectangular matrix A A A into a lower triangular matrix L L L, a unit upper triangular matrix U U U, and permutation matrices P P P and Q Q Q, such that P A Q ⊤ = L U PAQ^\top = LU P A Q ⊤= L U it can be more stable than the LU decomposition with partial pivoting, in exchange for being more computationally expensive
§ Q R QR Q R decomposition
[ Mat::qr ] decomposes a matrix A A A into the product A = Q R , A = QR, A= Q R, where Q Q Q is a unitary matrix, and R R R is an upper trapezoidal matrix. it is often used for solving least squares problems
an implementation for sparse matrices is also available
§ Q R QR Q R decomposition with column pivoting
([ Mat::col_piv_qr ]) decomposes a matrix A A A into the product A P ⊤ = Q R , AP^\top = QR, A P ⊤= Q R, where P P P is a permutation matrix, Q Q Q is a unitary matrix, and R R R is an upper trapezoidal matrix
it is slower than the version with no pivoting, in exchange for being more numerically stable for rank-deficient matrices
§ singular value decomposition
the SVD of a matrix A A A of shape ( m , n ) (m, n) ( m, n) is a decomposition into three components U U U, S S S, and V V V, such that:
U U U has shape ( m , m ) (m, m) ( m, m) and is a unitary matrix,
V V V has shape ( n , n ) (n, n) ( n, n) and is a unitary matrix,
S S S has shape ( m , n ) (m, n) ( m, n) and is zero everywhere except the main diagonal, with nonnegative diagonal values in nonincreasing order,
and finally:
A = U S V H A = U S V^H A= U S V H
the SVD is provided in two forms: either the full matrices U U U and V V V are computed, using [ Mat::svd ], or only their first min  ( m , n ) \min(m, n) min( m, n) columns are computed, using [ Mat::thin_svd ]
if only the singular values (elements of S S S) are desired, they can be obtained in nonincreasing order using [ Mat::singular_values ]
§ eigendecomposition
note: the order of the eigenvalues is currently unspecified and may be changed in a future release
the eigenvalue decomposition of a square matrix A A A of shape ( n , n ) (n, n) ( n, n) is a decomposition into two components U U U, S S S:
U U U has shape ( n , n ) (n, n) ( n, n) and is invertible,
S S S has shape ( n , n ) (n, n) ( n, n) and is a diagonal matrix,
and finally:
A = U S U − 1 A = U S U^{-1} A= U S U− 1
if A A A is self-adjoint, then U U U can be made unitary ( U − 1 = U H U^{-1} = U^H U− 1= U H), and S S S is real valued. additionally, the eigenvalues are sorted in nondecreasing order
Depending on the domain of the input matrix and whether it is self-adjoint, multiple methods are provided to compute the eigendecomposition:
[ Mat::self_adjoint_eigen ] can be used with either real or complex matrices, producing an eigendecomposition of the same type,
[ Mat::eigen ] can be used with real or complex matrices, but always produces complex values.
if only the eigenvalues (elements of S S S) are desired, they can be obtained using [ Mat::self_adjoint_eigenvalues ] (nondecreasing order), [ Mat::eigenvalues ] with the same conditions described above.
§ crate features
std : enabled by default. links with the standard library to enable additional features such as cpu feature detection at runtime
rayon : enabled by default. enables the rayon parallel backend and enables global parallelism by default
npy : enables conversions to/from numpy's matrix file format
perf-warn : produces performance warnings when matrix operations are called with suboptimal data layout
nightly : requires the nightly compiler. enables experimental simd features such as avx512
Re-exports §
pub extern crate [num_complex](https://docs.rs/num-complex/0.4.6/x86_64-unknown-linux-gnu/num_complex/index.html) as complex; pub extern crate [dyn_stack](https://docs.rs/dyn-stack/0.13.2/x86_64-unknown-linux-gnu/dyn_stack/index.html); pub extern crate [rand](https://docs.rs/rand/0.9.2/x86_64-unknown-linux-gnu/rand/index.html); pub extern crate [reborrow](https://docs.rs/reborrow/0.5.5/x86_64-unknown-linux-gnu/reborrow/index.html); pub extern crate [faer_traits](https://docs.rs/faer-traits/0.24.0/x86_64-unknown-linux-gnu/faer_traits/index.html) as traits; pub use col:: [Col](https://docs.rs/faer/latest/faer/col/type.Col.html); pub use col:: [ColMut](https://docs.rs/faer/latest/faer/col/type.ColMut.html); pub use col:: [ColRef](https://docs.rs/faer/latest/faer/col/type.ColRef.html); pub use mat:: [Mat](https://docs.rs/faer/latest/faer/mat/type.Mat.html); pub use mat:: [MatMut](https://docs.rs/faer/latest/faer/mat/type.MatMut.html); pub use mat:: [MatRef](https://docs.rs/faer/latest/faer/mat/type.MatRef.html); pub use row:: [Row](https://docs.rs/faer/latest/faer/row/type.Row.html); pub use row:: [RowMut](https://docs.rs/faer/latest/faer/row/type.RowMut.html); pub use row:: [RowRef](https://docs.rs/faer/latest/faer/row/type.RowRef.html);
Modules §
col
column vector
diag
diagonal matrix
io
de-serialization from common matrix file formats
linalg
linear algebra module
mat
rectangular matrix
matrix_free
matrix-free linear operator traits and algorithms
perm
permutation matrix
prelude
useful imports for general usage of the library
row
row vector
sparse
sparse matrix data structures
stats
statistics and randomness functionality
utils
helper utilities
Macros §
Zip
expands to the type of zipped items.
auto
shorthand for <_ as Auto::<T>>::auto()
col
creates a col::Col containing the arguments
concat
concatenates the matrices in each row horizontally, then concatenates the results vertically
make_guard
see: generativity::make_guard
mat
creates a Mat containing the arguments.
row
creates a row::Row containing the arguments
unzip
used to undo the zipping by the zip! macro.
zip
zips together matrix of the same size, so that coefficient-wise operations can be performed on their elements.
Structs §
ContiguousBwd
contiguous stride equal to -1
ContiguousFwd
contiguous stride equal to +1
Scale
scaling factor for multiplying matrices.
Spec
implements Default based on Config 's Auto implementation for the type T .
Enums §
Accum
determines whether to replace or add to the result of a matmul operatio
Conj
determines whether the input should be implicitly conjugated or not
Par
determines the parallelization configuration
Side
determines which side of a self-adjoint matrix should be accessed
TryReserveError
memory allocation error
Traits §
Auto
like Default , but with an extra type parameter so that algorithm hyperparameters can be tuned per scalar type.
Index
native unsigned integer type
Shape
matrix dimension
ShapeIdx
base trait for Shape
Stride
stride distance between two consecutive elements along a given dimension
Unbind
sealed trait for types that can be created from “unbound” values, as long as their struct preconditions are upheld
Functions §
disable_global_parallelism
causes functions that access global parallelism settings to panic.
get_global_parallelism
gets the global parallelism settings.
set_global_parallelism
sets the global parallelism settings.
Type Aliases §
Idx
type that can be used to index into a range
IdxInc
type that can be used to partition a range
MaybeIdx
either an index or a negative value
c32 Complex<f32>
c64 Complex<f64>
cx128 Complex<f64>
fx128 Complex<f64>