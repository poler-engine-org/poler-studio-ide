> Source: https://bibliotekanauki.pl/articles/716196.pdf

