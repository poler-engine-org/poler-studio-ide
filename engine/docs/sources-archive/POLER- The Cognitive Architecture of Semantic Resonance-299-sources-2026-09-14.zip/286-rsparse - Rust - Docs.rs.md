> Source: https://docs.rs/rsparse

rsparse - Rust
Docs.rs
rsparse-1.2.1
rsparse 1.2.1
Permalink
Docs.rs crate page
MIT
Links
Repository
crates.io
Source
Owners
RLado
Dependencies
Versions
91.36% of the crate is documented
Platform
aarch64-apple-darwin
aarch64-unknown-linux-gnu
i686-pc-windows-msvc
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
Crate rsparse
Settings
Help
rsparse 1.2.1
All Items
Sections
Data structures
Features
Solvers
Examples
Basic matrix operations
Solve a linear system
Sources
Crate Items
Modules
Enums
Functions
Crates
rsparse 
Crate rsparse Copy item path
Source
Search
Settings
Help
Summary
Expand description
rs parse
A Rust library for solving sparse linear systems using direct methods.   
§ Data structures
CSC matrix ( Sprs )
Triplet matrix ( Trpl )
§ Features
Convert from dense [Vec<T>] or Vec<Vec<T>> matrix to CSC sparse matrix Sprs
Convert from sparse to dense Vec<Vec<T>>
Convert from a triplet format matrix Trpl to CSC Sprs
Sparse matrix addition [C=A+B]
Sparse matrix multiplication [C=A*B]
Transpose sparse matrices
Solve sparse linear systems
Where T is a numeric type
§ Solvers
lsolve: Solve a lower triangular system. Solves Lx=b where x and b are dense.
ltsolve: Solve L'x=b where x and b are dense.
usolve: Solve an upper triangular system. Solves Ux=b where x and b are dense
utsolve: Solve U'x=b where x and b are dense
cholsol: A\b solver using Cholesky factorization. Where A is a defined positive Sprs matrix and b is a dense vector
lusol: A\b solver using LU factorization. Where A is a square Sprs matrix and b is a dense vector
qrsol: A\b solver using QR factorization. Where A is a rectangular Sprs matrix and b is a dense vector
§ Examples
§ Basic matrix operations
Output:
§ Solve a linear system
Output:
§ Sources
Davis, T. (2006). Direct Methods for Sparse Linear Systems. Society for Industrial and Applied Mathematics. https://doi.org/10.1137/1.9780898718881
CSparse: A Concise Sparse Matrix Package in C
MIT License Copyright (c) 2023 Ricard Lado
Modules §
data
Data structures for rsparse
Enums §
Error
Functions §
add
C = alpha * A + beta * B
chol
L = chol (A, [Pinv parent cp]), Pinv is optional
cholsol
A\b solver using Cholesky factorization.
gaxpy
Generalized A times X Plus Y
lsolve
Solves a lower triangular system. Solves Lx=b. Where x and b are dense.
ltsolve
Solves L'x=b. Where x and b are dense.
lu
(L,U,Pinv) = lu(A, (Q lnz unz)). lnz and unz can be guess
lusol
A\b solver using LU factorization.
multiply
C = A * B
norm
Computes the 1-norm of a sparse matrix
qr
Sparse QR factorization (V,beta,p,R) = qr (A)
qrsol
A\b solver using QR factorization.
schol
Ordering and symbolic analysis for a Cholesky factorization
scpmat
Scalar plus sparse matrix. C = alpha + A
scxmat
Scalar times sparse matrix. C = alpha * A
sprs_print
Print a sparse matrix
sqr
Symbolic analysis for QR or LU
transpose
C = A'
usolve
Solves an upper triangular system. Solves U*x=b.
utsolve
Solves U'x=b where x and b are dense.