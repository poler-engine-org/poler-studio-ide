> Source: https://en.wikipedia.org/wiki/Wheeler%E2%80%93DeWitt_equation

Wheeler–DeWitt equation - Wikipedia
Jump to content [-]
Main menu
Main menu
move to sidebar hide
Navigation
Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Contribute
Help
Learn to edit
Community portal
Recent changes
Upload file
Special pages
Search
Search [-]
Appearance
Donate
Create account
Log in [-]
Personal tools
Donate
Create account
Log in
Contents
move to sidebar hide
(Top)
1 Motivation and background
2 Mathematical formalism Toggle Mathematical formalism subsection
2.1 Hamiltonian constraint
2.2 Momentum constraint
3 See also
4 References [-]
Toggle the table of contents
Wheeler–DeWitt equation
[-]
14 languages
Català
Deutsch
Español
فارسی
Suomi
Français
עברית
Italiano
日本語
한국어
Português
Svenska
Türkçe
中文
Edit links
Article
Talk [-]
English
Read
Edit
View history [-]
Tools
Tools
move to sidebar hide
Actions
Read
Edit
View history
General
What links here
Related changes
Upload file
Permanent link
Page information
Cite this page
Get shortened URL
Download QR code
Expand all
Edit interlanguage links
Print/export
Download as PDF
Printable version
In other projects
Wikidata item
Appearance
move to sidebar hide
Birthday mode (Baby Globe)
[-] 0 Disabled [x] 1 Enabled Learn more about Birthday mode
Text
[-] 0 Small [x] 1 Standard [-] 2 Large
This page always uses small font size
Width
[x] 1 Standard [-] 0 Wide
The content is as wide as possible for your browser window.
Color (beta)
[-] os Automatic [x] day Light [-] night Dark
This page is always in light mode.
From Wikipedia, the free encyclopedia
Field equation from quantum gravity 
hide This article has multiple issues. Please help improve it or discuss these issues on the talk page. ( Learn how and when to remove these messages) 
This article may be too technical for most readers to understand. Please help improve it to make it understandable to non-experts, without removing the technical details. ( August 2011) ( Learn how and when to remove this message)
This article needs additional citations for verification. Please help improve this article by adding citations to reliable sources. Unsourced material may be challenged and removed.
Find sources: "Wheeler–DeWitt equation" – news
· newspapers
· books
· scholar
· JSTOR ( July 2025) ( Learn how and when to remove this message)
( Learn how and when to remove this message)
Quantum field theory 
Feynman diagram
History
show
Background
Field theory
Electromagnetism
Weak force
Strong force
Quantum mechanics
Special relativity
General relativity
Gauge theory
Yang–Mills theory
show
Symmetries
Symmetry in quantum mechanics
C-symmetry
P-symmetry
T-symmetry
Lorentz symmetry
Poincaré symmetry
Gauge symmetry
Explicit symmetry breaking
Spontaneous symmetry breaking
Noether charge
Topological charge
show
Tools
Anomaly
Background field method
BRST quantization
Correlation function
Crossing
Effective action
Effective field theory
Expectation value
Feynman diagram
Lattice field theory
LSZ reduction formula
Partition function
Path Integral Formulation
Propagator
Quantization
Regularization
Renormalization
Vacuum state
Wick's theorem
Wightman axioms
hide
Equations
Dirac equation
Klein–Gordon equation
Proca equations
Wheeler–DeWitt equation
Bargmann–Wigner equations
Schwinger-Dyson equation
Renormalization group equation
show
Standard Model
Quantum electrodynamics
Electroweak interaction
Quantum chromodynamics
Higgs mechanism
show
Incomplete theories
String theory
Supersymmetry
Technicolor
Theory of everything
Quantum gravity
show
Scientists
Adler
Anderson
Anselm
Bargmann
Becchi
Belavin
Bell
Berezin
Bethe
Bjorken
Bleuer
Bogoliubov
Brodsky
Brout
Buchholz
Cachazo
Callan
Cardy
Coleman
Connes
Dashen
DeWitt
Dirac
Doplicher
Dyson
Englert
Faddeev
Fadin
Fayet
Fermi
Feynman
Fierz
Fock
Frampton
Fritzsch
Fröhlich
Fredenhagen
Furry
Glashow
Gell-Mann
Glimm
Goldstone
Gribov
Gross
Gupta
Guralnik
Haag
Hagen
Han
Heisenberg
Hepp
Higgs
't Hooft
Iliopoulos
Ivanenko
Jackiw
Jaffe
Jona-Lasinio
Jordan
Jost
Källén
Kendall
Kinoshita
Kim
Klebanov
Kontsevich
Kreimer
Kuraev
Landau
Lee
Lee
Lehmann
Leutwyler
Lipatov
Łopuszański
Low
Lüders
Maiani
Majorana
Maldacena
Matsubara
Migdal
Mills
Møller
Naimark
Nambu
Neveu
Nishijima
Oehme
Oppenheimer
Osborn
Osterwalder
Parisi
Pauli
Peccei
Peskin
Plefka
Polchinski
Polyakov
Pomeranchuk
Popov
Proca
Quinn
Rouet
Rubakov
Ruelle
Sakurai
Salam
Schrader
Schwarz
Schwinger
Segal
Seiberg
Semenoff
Shifman
Shirkov
Skyrme
Sommerfield
Stora
Stueckelberg
Sudarshan
Symanzik
Takahashi
Thirring
Tomonaga
Tyutin
Vainshtein
Veltman
Veneziano
Virasoro
Ward
Weinberg
Weisskopf
Wentzel
Wess
Wetterich
Weyl
Wick
Wightman
Wigner
Wilczek
Wilson
Witten
Yang
Yukawa
Zamolodchikov
Zamolodchikov
Zee
Zimmermann
Zinn-Justin
Zuber
Zumino
v
t
e
The Wheeler–DeWitt equation [1] for theoretical physics and applied mathematics, is a field equation attributed to John Archibald Wheeler and Bryce DeWitt. The equation attempts to mathematically combine the ideas of quantum mechanics and general relativity, a step towards a theory of quantum gravity.
In this approach, time plays a role different from what it does in non-relativistic quantum mechanics, leading to the so-called " problem of time". [2] More specifically, the equation describes the quantum version of the Hamiltonian constraint using metric variables. Its commutation relations with the diffeomorphism constraints generate the Bergman–Komar "group" (which is the diffeomorphism group on-shell).
Motivation and background
[ edit]
This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. ( July 2025) ( Learn how and when to remove this message)
In canonical gravity, spacetime is foliated into spacelike submanifolds. The three-metric (i.e., metric on the hypersurface) is γ i j {\displaystyle \gamma _{ij}} 
and given by g μ ν d x μ d x ν = ( − N 2 + β k β k ) d t 2 + 2 β k d x k d t + γ i j d x i d x j . {\displaystyle g_{\mu \nu },\mathrm {d} x^{\mu },\mathrm {d} x^{\nu }=(-N^{2}+\beta _{k}\beta ^{k}),\mathrm {d} t^{2}+2\beta _{k},\mathrm {d} x^{k},\mathrm {d} t+\gamma _{ij},\mathrm {d} x^{i},\mathrm {d} x^{j}.} 
In that equation the Latin indices run over the values 1, 2, 3, and the Greek indices run over the values 1, 2, 3, 4. The three-metric γ i j {\displaystyle \gamma _{ij}} 
is the field, and we denote its conjugate momenta as π i j {\displaystyle \pi ^{ij}} 
. The Hamiltonian is a constraint (characteristic of most relativistic systems) H = 1 2 γ G i j k l π i j π k l − γ ( 3 ) R = 0 , {\displaystyle {\mathcal {H}}={\frac {1}{2{\sqrt {\gamma }}}}G_{ijkl}\pi ^{ij}\pi ^{kl}-{\sqrt {\gamma }},{}^{(3)}!R=0,} 
where γ = det ( γ i j ) {\displaystyle \gamma =\det(\gamma _{ij})} 
, and G i j k l = ( γ i k γ j l + γ i l γ j k − γ i j γ k l ) {\displaystyle G_{ijkl}=(\gamma _{ik}\gamma _{jl}+\gamma _{il}\gamma _{jk}-\gamma _{ij}\gamma _{kl})} 
is the Wheeler–DeWitt metric. In index-free notation, the Wheeler–DeWitt metric on the space of positive definite quadratic forms g in three dimensions is tr  ( ( g − 1 d g ) 2 ) − ( tr  ( g − 1 d g ) ) 2 . {\displaystyle \operatorname {tr} ((g^{-1}dg)^{2})-(\operatorname {tr} (g^{-1}dg))^{2}.} 
Quantization "puts hats" on the momenta and field variables; that is, the functions of numbers in the classical case become operators that modify the state function in the quantum case. Thus we obtain the operator H ^ = 1 2 γ G ^ i j k l π ^ i j π ^ k l − γ ( 3 ) R ^ . {\displaystyle {\hat {\mathcal {H}}}={\frac {1}{2{\sqrt {\gamma }}}}{\hat {G}}_{ijkl}{\hat {\pi }}^{ij}{\hat {\pi }}^{kl}-{\sqrt {\gamma }},{}^{(3)}!{\hat {R}}.} 
Working in "position space", these operators are γ ^ i j ( t , x k ) → γ i j ( t , x k ) , π ^ i j ( t , x k ) → − i δ δ γ i j ( t , x k ) . {\displaystyle {\begin{aligned}{\hat {\gamma }}_{ij}(t,x^{k})&\to \gamma _{ij}(t,x^{k}),\{\hat {\pi }}^{ij}(t,x^{k})&\to -i{\frac {\delta }{\delta \gamma _{ij}(t,x^{k})}}.\end{aligned}}} 
One can apply the operator to a general wave functional of the metric H ^ Ψ [ γ ] = 0 , {\displaystyle {\hat {\mathcal {H}}}\Psi [\gamma ]=0,} 
where Ψ [ γ ] = a + ∫ ψ ( x ) γ ( x ) d x 3 + ∬ ψ ( x , y ) γ ( x ) γ ( y ) d x 3 d y 3 + … , {\displaystyle \Psi [\gamma ]=a+\int \psi (x)\gamma (x),dx^{3}+\iint \psi (x,y)\gamma (x)\gamma (y),dx^{3},dy^{3}+\dots ,} 
which would give a set of constraints amongst the coefficients ψ ( x , y , … ) {\displaystyle \psi (x,y,\dots )} 
. This means that the amplitudes for N {\displaystyle N} 
gravitons at certain positions are related to the amplitudes for a different number of gravitons at different positions. Or, one could use the two-field formalism, treating ω ( g ) {\displaystyle \omega (g)} 
as an independent field, so that the wave function is Ψ [ γ , ω ] {\displaystyle \Psi [\gamma ,\omega ]} 
.
Mathematical formalism
[ edit]
The Wheeler–DeWitt equation [1] is a functional differential equation. It is ill-defined in the general case, but very important in theoretical physics, especially in quantum gravity. It is a functional differential equation on the space of three-dimensional spatial metrics. The Wheeler–DeWitt equation has the form of an operator acting on a wave functional; the functional reduces to a function in cosmology. Contrary to the general case, the Wheeler–DeWitt equation is well defined in minisuperspaces like the configuration space of cosmological theories. An example of such a wave function is the Hartle–Hawking state. Bryce DeWitt first published this equation in 1967 under the name "Einstein–Schrödinger equation"; it was later renamed the "Wheeler–DeWitt equation". [3]
Hamiltonian constraint
[ edit]
Simply speaking, the Wheeler–DeWitt equation says
H ^ ( x ) | ψ ⟩ = 0 , {\displaystyle {\hat {H}}(x)|\psi \rangle =0,} 
where H ^ ( x ) {\displaystyle {\hat {H}}(x)} 
is the Hamiltonian constraint in quantized general relativity, and | ψ ⟩ {\displaystyle |\psi \rangle } 
stands for the wave function of the universe. Unlike ordinary quantum field theory or quantum mechanics, the Hamiltonian is a first-class constraint on physical states. We also have an independent constraint for each point in space.
Although the symbols H ^ {\displaystyle {\hat {H}}} 
and | ψ ⟩ {\displaystyle |\psi \rangle } 
may appear familiar, their interpretation in the Wheeler–DeWitt equation is substantially different from non-relativistic quantum mechanics. | ψ ⟩ {\displaystyle |\psi \rangle } 
is no longer a spatial wave function in the traditional sense of a complex-valued function that is defined on a 3-dimensional space-like surface and normalized to unity. Instead it is a functional of field configurations on all of spacetime. This wave function contains all of the information about the geometry and matter content of the universe. H ^ {\displaystyle {\hat {H}}} 
is still an operator that acts on the Hilbert space of wave functions, but it is not the same Hilbert space as in the nonrelativistic case, and the Hamiltonian no longer determines the evolution of the system, so the Schrödinger equation H ^ | ψ ⟩ = i ℏ ∂ / ∂ t | ψ ⟩ {\displaystyle {\hat {H}}|\psi \rangle =i\hbar \partial /\partial t|\psi \rangle } 
no longer applies. This property is known as timelessness. Various attempts to incorporate time in a fully quantum framework have been made, starting with the "Page and Wootters mechanism" and other subsequent proposals. [4] [5] The reemergence of time was also proposed as arising from quantum correlations between an evolving system and a reference quantum clock system, the concept of system-time entanglement is introduced as a quantifier of the actual distinguishable evolution undergone by the system. [6] [7]
Momentum constraint
[ edit]
We also need to augment the Hamiltonian constraint with momentum constraints
P → ( x ) | ψ ⟩ = 0 {\displaystyle {\vec {\mathcal {P}}}(x)|\psi \rangle =0} 
associated with spatial diffeomorphism invariance.
In minisuperspace approximations, we only have one Hamiltonian constraint (instead of infinitely many of them).
In fact, the principle of general covariance in general relativity implies that global evolution per se does not exist; the time t {\displaystyle t} 
is just a label we assign to one of the coordinate axes. Thus, what we think about as time evolution of any physical system is just a gauge transformation, similar to that of QED induced by U(1) local gauge transformation ψ → e i θ ( r → ) ψ , {\displaystyle \psi \to e^{i\theta ({\vec {r}})}\psi ,} 
where θ ( r → ) {\displaystyle \theta ({\vec {r}})} 
plays the role of local time. The role of a Hamiltonian is simply to restrict the space of the "kinematic" states of the Universe to that of "physical" states—the ones that follow gauge orbits. For this reason we call it a "Hamiltonian constraint". Upon quantization, physical states become wave functions that lie in the kernel of the Hamiltonian operator.
In general, the Hamiltonian [clarificationneeded] vanishes for a theory with general covariance or time-scaling invariance.
See also
[ edit]
ADM formalism
Diffeomorphism constraint
Euclidean quantum gravity
Regge calculus
Canonical quantum gravity
Peres metric
Loop quantum gravity
References
[ edit]
^ Jump up to: a  b DeWitt, Bryce S. (1967-08-25). "Quantum Theory of Gravity. I. The Canonical Theory". Physical Review. 160 (5): 1113– 1148. Bibcode: 1967PhRv..160.1113D. doi: 10.1103/PhysRev.160.1113. ISSN 0031-899X.
^ "Quantum Experiment Shows How Time 'Emerges' from Entanglement". Medium. The Physics arXiv Blog. 23 October 2013.
^ Rovelli, Carlo (2001-01-23). Notes for a brief history of quantum gravity. Presented at the 9th Marcel Grossmann Meeting in Roma, July 2000. arXiv: gr-qc/0006061.
^ Page, Don N.; Wootters, William K. (1983-06-15). "Evolution without evolution: Dynamics described by stationary observables". Physical Review D. 27 (12): 2885– 2892. doi: 10.1103/PhysRevD.27.2885. ISSN 0556-2821.
^ Rovelli, Carlo (1990-10-15). "Quantum mechanics without time: A model". Physical Review D. 42 (8): 2638– 2646. doi: 10.1103/PhysRevD.42.2638. PMID 10013133.
^ Boette, A.; Rossignoli, R.; Gigena, N.; Cerezo, M. (2016-06-27). "System-time entanglement in a discrete-time model". Physical Review A. 93 (6) 062127. arXiv: 1512.07313. doi: 10.1103/PhysRevA.93.062127. ISSN 2469-9926. S2CID 119245348.
^ Boette, A.; Rossignoli, R. (2018-09-12). "History states of systems and operators". Physical Review A. 98 (3) 032108. arXiv: 1806.00956. doi: 10.1103/PhysRevA.98.032108. ISSN 2469-9926. S2CID 56101730.
Hamber, Herbert W.; Williams, Ruth M. (2011-11-18). "Discrete Wheeler-DeWitt equation". Physical Review D. 84 (10) 104033. arXiv: 1109.2530. Bibcode: 2011PhRvD..84j4033H. doi: 10.1103/PhysRevD.84.104033. ISSN 1550-7998. S2CID 4812404.
Hamber, Herbert W.; Toriumi, Reiko; Williams, Ruth M. (2012-10-02). "Wheeler-DeWitt equation in 2 + 1 dimensions". Physical Review D. 86 (8) 084010. arXiv: 1207.3759. Bibcode: 2012PhRvD..86h4010H. doi: 10.1103/PhysRevD.86.084010. ISSN 1550-7998. S2CID 119229306.
show
v
t
e
Quantum gravity
Central concepts
AdS/CFT correspondence
Batalin–Vilkovisky formalism
CA-duality
Causal patch
Faddeev–Popov ghost
Gravitational anomaly
Graviton
Holographic principle
IR/UV mixing
Planck units
Quantum foam
Ryu–Takayanagi conjecture
Trans-Planckian problem
Weinberg–Witten theorem
Toy models
2+1D topological gravity
CGHS model
Jackiw–Teitelboim gravity
Liouville gravity
RST model
Topological quantum field theory
Quantum field theory in curved spacetime
Bunch–Davies vacuum
Hawking radiation
Semiclassical gravity
Unruh effect
Black holes
Black hole complementarity
Black hole information paradox
Black-hole thermodynamics
Bekenstein bound
Bousso's holographic bound
Cosmic censorship hypothesis
ER = EPR
Firewall (physics)
Gravitational singularity
Approaches
Applications
Quantum cosmology
Eternal inflation
FRW/CFT duality
Multiverse
See also:  Template:Quantum mechanics topics 
Retrieved from " https://en.wikipedia.org/w/index.php?title=Wheeler–DeWitt_equation&oldid=1322004454"
Category:
Quantum gravity
Hidden categories:
Articles with short description
Short description is different from Wikidata
Wikipedia articles that are too technical from August 2011
All articles that are too technical
Articles needing additional references from July 2025
All articles needing additional references
Articles with multiple maintenance issues
Wikipedia articles needing clarification from August 2016
This page was last edited on 13 November 2025, at 21:46 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policy
About Wikipedia
Disclaimers
Contact Wikipedia
Legal & safety contacts
Code of Conduct
Developers
Statistics
Cookie statement
Mobile view
Search
Search [-]
Toggle the table of contents
Wheeler–DeWitt equation
14 languages Add topic 