> Source: https://pyscf.org/

Quantum chemistry with Python — PySCF
Skip to main content
Back to top Ctrl + K
The third PySCF Developers Meeting will take place Aug 27-28, 2026, at the University of Chicago!
PySCF
Quickstart
User Guide
Contributor Guide
Virtual Seminars
Benchmarks
About
Search Ctrl + K
Search Ctrl + K
Quickstart
User Guide
Contributor Guide
Virtual Seminars
Benchmarks
About
Quantum chemistry with Python#
Primarily Python
Easy to read and write, for quick development with fewer mistakes.
Fast
Uses NumPy, SciPy, and custom C/C++ code.
Free and open-source
Accessible and community-driven. Distributed on GitHub under the Apache-2.0 license.
Modular
Easily integrated into complex workflows or other software packages.
Comprehensive
Extensive collection of electronic structure methods, for molecules and periodic solids.
Extensible
See the list of Extensions to PySCF.
next Quickstart
© Copyright 2026, The PySCF Developers.
Created using Sphinx 9.1.0.
Built with the PyData Sphinx Theme 0.17.1.