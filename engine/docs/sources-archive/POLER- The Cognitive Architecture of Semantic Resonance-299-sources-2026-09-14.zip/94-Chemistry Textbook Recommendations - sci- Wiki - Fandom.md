> Source: https://4chan-science.fandom.com/wiki/Chemistry_Textbook_Recommendations

Chemistry Textbook Recommendations | /sci/ Wiki | Fandom 
Sign In
Create a Free Account 
/sci/ Wiki
Explore
Main Page
All Pages
Community
Interactive Maps
Recent Blog Posts
Wiki Content
Recently Changed Pages
Chemical Engineering
Mathematics
Physics Textbook Recommendations
Mechanical and Aerospace Engineering
Chemistry Textbook Recommendations
/sci/ Wiki
Universal Material
Statistics
Obtaining textbooks
Bock
Obtaining textbooks
Community
Recent blog posts
Forum
Sign In
Don't have an account?
Create a Free Account
Sign In
Home
Explore
Saved
Progress
History
More
Advertisement
Skip to content
/sci/ Wiki
34
pages
Explore
Main Page
All Pages
Community
Interactive Maps
Recent Blog Posts
Wiki Content
Recently Changed Pages
Chemical Engineering
Mathematics
Physics Textbook Recommendations
Mechanical and Aerospace Engineering
Chemistry Textbook Recommendations
/sci/ Wiki
Universal Material
Statistics
Obtaining textbooks
Bock
Obtaining textbooks
Community
Recent blog posts
Forum
Contents
1 High School - General Chemistry
2 Undergraduate
2.1 General Chemistry
2.2 Analytical Chemistry
2.2.1 Instrumental Analysis
2.3 Organic Chemistry
2.4 Biochemistry
2.5 Physical Chemistry
2.6 Thermal Physics
2.7 Quantum Theory
2.8 Inorganic Chemistry
2.9 Group Theory
2.10 Solid State Chemistry
2.11 Computational Chemistry
3 Graduate
4 Supplements to Organic Chemistry
5 Electrochemistry  
Chemistry Textbook Recommendations
Sign In to Save Save Edit
History
Purge
Talk (0) [-]
Contents
1 High School - General Chemistry
2 Undergraduate
2.1 General Chemistry
2.2 Analytical Chemistry
2.2.1 Instrumental Analysis
2.3 Organic Chemistry
2.4 Biochemistry
2.5 Physical Chemistry
2.6 Thermal Physics
2.7 Quantum Theory
2.8 Inorganic Chemistry
2.9 Group Theory
2.10 Solid State Chemistry
2.11 Computational Chemistry
3 Graduate
4 Supplements to Organic Chemistry
5 Electrochemistry
High School - General Chemistry[  ]
The general chemistry text at most universities is pretty decent. Most use Brown, LeMay, Bursten, which is a great introduction to the chemical sciences. The old editions are fine, I compared a 1997 edition Brown ($4.00 including shipping) to the 2014 edition of Brown ($250), it's 99% identical. It is important to do many of the problems, since chemistry is a quantitative science also. If you have taken AP chemistry or have a good background in calculus and physics, Oxtoby, Gillis, and Nachtrieb would be a good place to start. I recommend reading Brown, LeMay, Bursten and then doing Oxtoby, Gillis, and Nachtrieb if you really want a good treatment of introductory chemistry. Use Khan Academy, YouTube, and UCI open chemistry for help.
Brown, LeMay, Bursten, Murphy, Woodward, Stoltzfus - Chemistry: The Central Science (One of the best intro books on Chemistry for a beginner)
Oxtoby, Gillis, and Nachtrieb - Principles of Modern Chemistry (For serious students interested in math and physics)
Undergraduate[  ]
General Chemistry[  ]
General Chemistry is the same as AP Chemistry. This is where you start if you never took a chemistry class, or only took high school chemistry.
Chang and Overby - Chemistry
Brown, LeMay, Bursten, Murphy, Woodward, Stoltzfus - Chemistry: The Central Science (One of the best intro books on Chemistry for a beginner)
Atkins, Jones, Laverman, Patterson, Young - Chemical Principles: The Quest for Insight
Oxtoby, Gillis, and Nachtrieb - Principles of Modern Chemistry (For serious students interested in math and physics)
Housecroft and Constable - Chemistry (This advanced undergrad book covers all aspects of chemistry fairly well, with worked examples, and is good for review)
Analytical Chemistry[  ]
Harris is the golden standard of analytical chemistry. A basic knowledge of statistics and excel will help. Again, it is important to do the problems at the end of the chapters.
Harris - Quantitative Chemical Analysis
Harvey - Modern Analytical Chemistry
Instrumental Analysis[  ]
Willard et al. - Instrumental Methods of Analysis
Skoog, Holler, and Crouch - Principles of Instrumental Analysis
Organic Chemistry[  ]
The "dreaded" organic chemistry. It's not difficult if you know the concepts and do practice problems. The best book for introductory Organic Chemistry is Klein. Klein along with his "As a Second Language" series will give you enough problems to keep you occupied for days on end. Clayden, Greeves, & Warren is probably the best for those serious about chemistry. Reading it along with Klein would be a good idea. Wade is also a good supplement for an introductory book. Again, as with all chemistry, doing the problems is extremely important.
Klein - Organic Chemistry (with his "As a Second Language" as supplement)
Zubrick - The Organic Chem Lab Survival Manual: A Student's Guide to Techniques (and MIT's Chem Lab Technique Videos on YouTube)
Clayden, Greeves, & Warren - Organic Chemistry (Best in terms comprehensive content, also covers Biochemistry's Metabolism pathways well)
Sykes - A guidebook to mechanism in organic chemistry (A relatively short book that gives a nice introduction to almost all the mechanisms one would encounter during an undergrad course)
Biochemistry[  ]
Biochemistry is not technically required to know, but I included it since ACS requires it for a BS in Chemistry, so study only if you need it. Biochemistry can be taught in two ways, biology-based or chemistry based. Berg will focus on the chemistry side of things. Lehninger is also a great book, along with Mathews. Lehninger's treatment on Enzyme Kinetics is better than Garrett and Grisham. When reading biochemistry, a reading of a molecular biology text would also be very helpful in gaining more understanding. Voet is a demanding text, but if you get through it you will have an absolutely amazing grasp of biochemistry. Voet has a focus also on structural biology, which is a great field. Read Berg or Lehninger and then go on to Voet and you will have more knowledge than 90% of biochemistry majors..
Berg, Tymoczko, and Stryer - Biochemistry [5thEdition]
Nelson and Cox - Lehninger Principles of Biochemistry
Garrett and Grisham - Biochemistry
Voet and Voet - Biochemistry (Very dense with information)
Physical Chemistry[  ]
Along with organic chemistry, physical chemistry is one of the most hated among chemistry majors. McQuarrie and Simon is the best, however, they can be a challenge to read if you are not caught up mathematically. McQuarrie and Simon sneak over 200 pages of mathematics in the book to help you review. I still recommend McQaurrie and Simon to get though. If you do, you will have an amazing grasp of physical chemistry. It is well worth the effort. Atkins is another common textbook. It's quite dense but makes for an excellent reference text.
McQuarrie and Simon - Physical Chemistry: A Molecular Approach (Also available in 2 volumes "Quantum Chemistry" + "Molecular Thermodynamics" with 'nearly' identical combined content)
Levine - Physical Chemistry ("Honors" level)
Atkins' Physical Chemistry (Excellent book for the mathematically inclined - often goes a bit further than a typical undergrad course)
For more detail see Thermodynamics, Chemical Thermodynamics, and:
Thermal Physics[  ]
If you enjoyed thermodynamics in physical chemistry, you can go more in-depth here, but not required.
Schroeder - An Introduction to Thermal Physics
Reif - Fundamentals of Statistical and Thermal Physics
Quantum Theory[  ]
If you enjoyed Quantum Mechanics in physical chemistry, you can go more in-depth here, but not required.
Eisberg and Resnick - Quantum Physics of Atoms, Molecules, Solids, Nuclei, and Particles
Griffiths - Quantum Mechanics
Pauling - Introduction to Quantum Mechanics with Applications to Chemistry (A Dover reprint of the 1935 original. Read for culture and historical perspective. Yes, the Pauling.)
Dirac - Quantum Mechanics (Very rigourous. Another great historical artifact. Yes, the Dirac)
See also Quantum Mechanics
Inorganic Chemistry[  ]
Lee - Concise Inorganic Chemistry
Housecroft and Sharpe - Inorganic Chemistry
Huheey, Keiter, and Keiter - Inorganic Chemistry: Principles of Structure and Reactivity
Miessler - Inorganic Chemistry (Use this book, my personal favorite, and used at MIT / Caltech)
Figgis - Introduction to ligand fields (Good text for inorganic spectroscopy & magnetism)
Group Theory[  ]
Group Theory is extremely important at the graduate level, it will be easier if you have a knowledge of linear algebra, but not required.
Kettle - Symmetry and Structure: Readable Group Theory for Chemists
Carter - Molecular Symmetry and Group Theory
Bishop - Group Theory and Chemistry (Dover Books on Chemistry)
Tinkham - Group Theory and Quantum Mechanics (Dover Books on Chemistry)
Harris and Bertolucci - Symmetry and Spectroscopy: An Introduction to Vibrational and Electronic Spectroscopy (Dover Books on Chemistry)
Solid State Chemistry[  ]
Not Required unless you have an interest in materials.
West - Solid State Chemistry and its Applications
Smart and Moore - Solid State Chemistry: An Introduction
Computational Chemistry[  ]
Not Required unless you are interested in it. A theory-oriented companion text (Szabo, say) is useful..
Cramer - Essentials of Computational Chemistry: Theories and Models
Leach - Molecular Modelling: Principles and Applications
Frenkel and Smit - Understanding Molecular Simulation: From Algorithms to Applications
Allen and Tildesley - Computer Simulation of Liquids
Graduate[  ]
Cotton's Advanced Inorganic Chemistry
Greenwood and Earnshaw's Chemistry of Elements
Tannoudji's Quantum Mechanics Vol 1 and 2
Szabo's Modern Quantum Chemistry
Cook's Handbook of Computational Quantum Chemistry
March's Advanced Organic Chemistry: Reactions, Mechanisms, and Structure
Carey's Advanced Organic Chemistry Parts A and B
Berry, Rice & Ross - Physical Chemistry
Supplements to Organic Chemistry[  ]
Fleming's Molecular Orbitals and Organic Chemical Reactions
Kurti's Strategic Applications of Named Reactions
Grossman's The Art of Writing Reasonable Organic Mechanism
Gawley's Principles of Asymmetric Synthesis
Deslongchamps' Stereoelectronic Effects in Organic Chemistry
Warren's Organic Synthesis: The Disconnection Approach
Nicolaou's Classics in Total Synthesis: Targets, Strategies, Methods
Anslyn's Modern Physical Organic Chemistry
Electrochemistry[  ]
Advanced Batteries: Materials Science Aspects by Huggins
Electrochemical Methods: Fundamentals and Applications by Bard and Faulkner
Electrochemical Systems by Newman and Thomas-Alyea
Community content is available under CC-BY-SA unless otherwise noted.
Comments
Start a conversation
Sign in to share your thoughts and get the conversation going.
SIGN IN
Don't have account? Register now
Advertisement
Advertisement
Advertisement
Advertisement
Explore properties
Fandom
Fanatical
GameSpot
Metacritic
TV Guide
Honest Entertainment
Follow Us
Overview
What is Fandom?
Essentials
About
Careers
Press
Contact
Terms of Use
Privacy Policy
Digital Services Act
Global Sitemap
Local Sitemap
Do Not Sell My Personal Information
Community
Community Central
Support
Help
Advertise
Media Kit
Contact
Fandom Apps
Take your favorite fandoms with you and never miss a beat. 
/sci/ Wiki is a Fandom Lifestyle Community.
View Mobile Site
This website uses cookies to enhance user experience and to analyze performance and traffic on our website. We also share information about your use of our site with our social media, advertising and analytics partners. Privacy Policy
Do Not Sell My Personal Information Accept Cookies 
Do Not Sell My Personal Information
When you visit our website, we store cookies on your browser to collect information. The information collected might relate to you, your preferences or your device, and is mostly used to make the site work as you expect it to and to provide a more personalized web experience. However, you can choose not to allow certain types of cookies, which may impact your experience of the site and the services we are able to offer. Click on the different category headings to find out more and change our default settings according to your preference. You cannot opt-out of our First Party Strictly Necessary Cookies as they are deployed in order to ensure the proper functioning of our website (such as prompting the cookie banner and remembering your settings, to log into your account, to redirect you when you log out, etc.). For more information about the First and Third Party Cookies used please follow this link.
Privacy Policy
Allow All
Manage Consent Preferences
Strictly Necessary Cookies
Always Active
These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.
Functional Cookies
[x]
Functional Cookies
These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.
Performance Cookies
[x]
Performance Cookies
These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.
Targeting Cookies
[x]
Targeting Cookies
These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.
Social Media Cookies
[x]
Social Media Cookies
These cookies are set by a range of social media services that we have added to the site to enable you to share our content with your friends and networks. They are capable of tracking your browser across other sites and building up a profile of your interests. This may impact the content and messages you see on other websites you visit. If you do not allow these cookies you may not be able to use or see these sharing tools.
Cookie List
Clear
[-] checkbox label label
Apply Cancel
Consent Leg.Interest [-]
checkbox label label [-]
checkbox label label [-]
checkbox label label
Confirm My Choices
                