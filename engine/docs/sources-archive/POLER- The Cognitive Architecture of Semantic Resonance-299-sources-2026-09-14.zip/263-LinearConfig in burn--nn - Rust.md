> Source: https://burn.dev/docs/burn/nn/struct.LinearConfig.html

LinearConfig in burn::nn - Rust
LinearConfig
Settings
Help
burn 0.20.0
LinearConfig
Fields
bias
d_input
d_output
initializer
layout
Methods
init
new
with_bias
with_initializer
with_layout
Trait Implementations
Clone
Config
Debug
Deserialize<'de>
Display
Serialize
Auto Trait Implementations
Freeze
RefUnwindSafe
Send
Sync
Unpin
UnwindSafe
Blanket Implementations
Adaptor<()>
Any
Borrow
BorrowMut
CloneToUninit
DeserializeOwned
Downcast
From
Instrument
Into
IntoComptime
IntoEither
Pointable
ToCompactString
ToLine
ToOwned
ToSpan
ToString
ToText
TryFrom
TryInto
Upcast
VZip
WasmNotSend
WasmNotSendSync
WasmNotSync
WithSubscriber
In burn:: nn
Modules
activation
loss
modules
Structs
BatchNorm
BatchNormConfig
BatchNormRecord
BatchNormRecordItem
BiLstm
BiLstmConfig
BiLstmRecord
BiLstmRecordItem
Dropout
DropoutConfig
Embedding
EmbeddingConfig
EmbeddingRecord
EmbeddingRecordItem
GLU
GateController
GateControllerRecord
GateControllerRecordItem
GaussianNoise
GaussianNoiseConfig
Gelu
GroupNorm
GroupNormConfig
GroupNormRecord
GroupNormRecordItem
HardSigmoid
HardSigmoidConfig
InstanceNorm
InstanceNormConfig
InstanceNormRecord
InstanceNormRecordItem
LayerNorm
LayerNormConfig
LayerNormRecord
LayerNormRecordItem
LeakyRelu
LeakyReluConfig
Linear
LinearConfig
LinearRecord
LinearRecordItem
Lstm
LstmConfig
LstmRecord
LstmRecordItem
LstmState
PRelu
PReluConfig
PReluRecord
PReluRecordItem
PositionalEncoding
PositionalEncodingConfig
PositionalEncodingRecord
PositionalEncodingRecordItem
Relu
RmsNorm
RmsNormConfig
RmsNormRecord
RmsNormRecordItem
RotaryEncoding
RotaryEncodingConfig
RotaryEncodingRecord
RotaryEncodingRecordItem
Sigmoid
Softplus
SoftplusConfig
SwiGlu
SwiGluConfig
SwiGluRecord
SwiGluRecordItem
Tanh
Unfold4d
Unfold4dConfig
Enums
Initializer
LinearLayout
PaddingConfig1d
PaddingConfig2d
PaddingConfig3d
Functions
generate_sinusoids 
burn:: nn
Struct LinearConfig Copy item path
Search
Settings
Help
Summary
Expand description
Configuration to create a Linear layer using the init function.
Fields §
§ d_input: [usize](https://doc.rust-lang.org/1.93.0/std/primitive.usize.html)
The size of the input features.
§ d_output: [usize](https://doc.rust-lang.org/1.93.0/std/primitive.usize.html)
The size of the output features.
§ bias: [bool](https://doc.rust-lang.org/1.93.0/std/primitive.bool.html)
If a bias should be applied during the linear transformation.
§ initializer: [Initializer](https://burn.dev/docs/burn/nn/enum.Initializer.html)
The type of function used to initialize neural network parameters
§ layout: [LinearLayout](https://burn.dev/docs/burn/nn/enum.LinearLayout.html)
The layout in which the linear parameters are stored.
Implementations §
§
impl LinearConfig
pub fn new(d_input: usize, d_output: usize) -> LinearConfig
Create a new instance of the config.
§
impl LinearConfig
pub fn with_bias(self, bias: bool) -> LinearConfig
If a bias should be applied during the linear transformation.
pub fn with_initializer(self, initializer: Initializer) -> LinearConfig
The type of function used to initialize neural network parameters
pub fn with_layout(self, layout: LinearLayout) -> LinearConfig
The layout in which the linear parameters are stored.
§
impl LinearConfig
pub fn init(&self, device: &<B as Backend>:: Device) -> Linear where B: Backend,
Initialize a new Linear module.
Trait Implementations §
§
impl Clone for LinearConfig
§
fn clone(&self) -> LinearConfig
Returns a duplicate of the value. Read more
1.0.0
· Source §
fn clone_from(&mut self, source: &Self)
Performs copy-assignment from source . Read more
§
impl Config for LinearConfig
§
fn save(&self, file: P) -> Result<(), Error> where P: AsRef< Path>,
Saves the configuration to a file. Read more
§
fn load(file: P) -> Result<Self, ConfigError> where P: AsRef< Path>,
Loads the configuration from a file. Read more
§
fn load_binary(data: &[ u8]) -> Result<Self, ConfigError>
Loads the configuration from a binary buffer. Read more
§
impl Debug for LinearConfig
§
fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), Error>
Formats the value using the given formatter. Read more
§
impl<'de> Deserialize<'de> for LinearConfig
§
fn deserialize( deserializer: D, ) -> Result< LinearConfig, <D as Deserializer<'de>>:: Error> where D: Deserializer<'de>,
Deserialize this value from the given Serde deserializer. Read more
§
impl Display for LinearConfig
§
fn fmt(&self, f: &mut Formatter<'_>) -> Result<(), Error>
Formats the value using the given formatter. Read more
§
impl Serialize for LinearConfig
§
fn serialize( &self, serializer: S, ) -> Result<<S as Serializer>:: Ok, <S as Serializer>:: Error> where S: Serializer,
Serialize this value into the given Serde serializer. Read more
Auto Trait Implementations §
§
impl Freeze for LinearConfig
§
impl RefUnwindSafe for LinearConfig
§
impl Send for LinearConfig
§
impl Sync for LinearConfig
§
impl Unpin for LinearConfig
§
impl UnwindSafe for LinearConfig
Blanket Implementations §
§
impl Adaptor<()> for T
§
fn adapt(&self)
Adapt the type to be passed to a metric.
Source §
impl Any for T where T: 'static + ? Sized,
Source §
fn type_id(&self) -> TypeId
Gets the TypeId of self . Read more
Source §
impl Borrow for T where T: ? Sized,
Source §
fn borrow(&self) -> &T
Immutably borrows from an owned value. Read more
Source §
impl BorrowMut for T where T: ? Sized,
Source §
fn borrow_mut(&mut self) -> &mut T
Mutably borrows from an owned value. Read more
Source §
impl CloneToUninit for T where T: Clone,
Source §
unsafe fn clone_to_uninit(&self, dest: *mut u8)
🔬 This is a nightly-only experimental API. ( clone_to_uninit )
Performs copy-assignment from self to dest . Read more
§
impl Downcast for T
§
fn downcast(&self) -> &T
Source §
impl From for T
Source §
fn from(t: T) -> T
Returns the argument unchanged.
§
impl Instrument for T
§
fn instrument(self, span: Span) -> Instrumented
Instruments this type with the provided [ Span ], returning an Instrumented wrapper. Read more
§
fn in_current_span(self) -> Instrumented
Instruments this type with the current Span , returning an Instrumented wrapper. Read more
Source §
impl<T, U> Into for T where U: From,
Source §
fn into(self) -> U
Calls U::from(self) .
That is, this conversion is whatever the implementation of [From](https://doc.rust-lang.org/1.93.0/core/convert/trait.From.html)<T> for U chooses to do.
§
impl IntoComptime for T
§
fn comptime(self) -> Self
Source §
impl IntoEither for T
Source §
fn into_either(self, into_left: bool) -> Either<Self, Self>
Converts self into a Left variant of Either<Self, Self> if into_left is true . Converts self into a Right variant of Either<Self, Self> otherwise. Read more
Source §
fn into_either_with(self, into_left: F) -> Either<Self, Self> where F: FnOnce(&Self) -> bool,
Converts self into a Left variant of Either<Self, Self> if into_left(&self) returns true . Converts self into a Right variant of Either<Self, Self> otherwise. Read more
§
impl Pointable for T
§
const ALIGN: usize
The alignment of pointer.
§
type Init = T
The type for initializers.
§
unsafe fn init(init: ::Init) -> usize
Initializes a with the given initializer. Read more
§
unsafe fn deref<'a>(ptr: usize) -> &'a T
Dereferences the given pointer. Read more
§
unsafe fn deref_mut<'a>(ptr: usize) -> &'a mut T
Mutably dereferences the given pointer. Read more
§
unsafe fn drop(ptr: usize)
Drops the object pointed to by the given pointer. Read more
§
impl ToCompactString for T where T: Display,
§
fn try_to_compact_string(&self) -> Result<CompactString, ToCompactStringError>
Fallible version of [ ToCompactString::to_compact_string() ] Read more
§
fn to_compact_string(&self) -> CompactString
Converts the given value to a [ CompactString ]. Read more
§
impl ToLine for T where T: Display,
§
fn to_line(&self) -> Line<'_>
Converts the value to a [ Line ].
Source §
impl ToOwned for T where T: Clone,
Source §
type Owned = T
The resulting type after obtaining ownership.
Source §
fn to_owned(&self) -> T
Creates owned data from borrowed data, usually by cloning. Read more
Source §
fn clone_into(&self, target: &mut T)
Uses borrowed data to replace owned data, usually by cloning. Read more
§
impl ToSpan for T where T: Display,
§
fn to_span(&self) -> Span<'_>
Converts the value to a [ Span ].
Source §
impl ToString for T where T: Display + ? Sized,
Source §
fn to_string(&self) -> String
Converts the given value to a String . Read more
§
impl ToText for T where T: Display,
§
fn to_text(&self) -> Text<'_>
Converts the value to a [ Text ].
Source §
impl<T, U> TryFrom for T where U: Into,
Source §
type Error = Infallible
The type returned in the event of a conversion error.
Source §
fn try_from(value: U) -> Result<T, <T as TryFrom>:: Error>
Performs the conversion.
Source §
impl<T, U> TryInto for T where U: TryFrom,
Source §
type Error = <U as TryFrom>:: Error
The type returned in the event of a conversion error.
Source §
fn try_into(self) -> Result<U, <U as TryFrom>:: Error>
Performs the conversion.
§
impl Upcast for T
§
fn upcast(&self) -> Option< &T>
§
impl<V, T> VZip for T where V: MultiLane,
§
fn vzip(self) -> V
§
impl WithSubscriber for T
§
fn with_subscriber(self, subscriber: S) -> WithDispatch where S: Into,
Attaches the provided Subscriber to this type, returning a [ WithDispatch ] wrapper. Read more
§
fn with_current_subscriber(self) -> WithDispatch
Attaches the current default Subscriber to this type, returning a [ WithDispatch ] wrapper. Read more
Source §
impl DeserializeOwned for T where T: for<'de> Deserialize<'de>,
§
impl WasmNotSend for T where T: Send,
§
impl WasmNotSendSync for T where T: WasmNotSend + WasmNotSync,
§
impl WasmNotSync for T where T: Sync,