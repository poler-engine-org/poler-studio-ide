> Source: https://arxiv.org/html/2403.08245v2

Scattered Mixture-of-Experts Implementation
 Back to arXiv  
 Back to arXiv
This is experimental HTML to improve accessibility. We invite you to report rendering errors. Use Alt+Y to toggle on accessible reporting links and Alt+Shift+Y to toggle off. Learn more about this project and help improve conversions.
Why HTML? Report Issue Back to Abstract Download PDF 
Table of Contents
Abstract
1 Introduction
2 Related Work
Other implementations & Dependencies
Other applications of SMoEs
3 Method
3.1 Sparse Mixture-of-Experts
3.2 ParallelLinear operation
3.2.1 Backward pass
3.2.2 SMoE Multi-layer Perceptron (SMoE MLP)
3.3 Extensibility: Mixture-of-Attention (MoA)
4 Performance
4.1 Unit Benchmarking on the SMoE MLP
4.2 Granularity and Throughput
4.3 Decreasing sparsity
4.4 Mixture-of-Attention
4.5 Mixtral Inference Comparison
5 Conclusion & Limitations
References
HTML conversions sometimes display errors due to content that did not convert correctly from the source. This paper uses the following packages that are not yet supported by the HTML conversion tool. Feedback on these issues are not necessary; they are known and are being worked on.
failed: fontawesome
Authors: achieve the best HTML results from your LaTeX submissions by following these best practices.
License: arXiv.org perpetual non-exclusive license
arXiv:2403.08245v2 [cs.LG] 04 Oct 2024
Scattered Mixture-of-Experts Implementation
Report issue for preceding element
Shawn Tan
tanjings@mila.quebec
&Yikang Shen
yikang.shen@ibm.com
&Rameswar Panda
rpanda@ibm.com
&Aaron Courville
courvila@iro.umontreal.ca
Report issue for preceding element
Abstract
Report issue for preceding element
ScatterMoE is an implementation of Sparse Mixture-of-Experts (SMoE) on GPUs. ScatterMoE builds upon techniques in existing implementations, and overcoming some of the current limitations to improve batched inference, training speed, and memory footprint. This implementation achieves this by avoiding both padding and making excessive copies of the input. We also fuse expert linear transforms and reordering operations with ParallelLinear, a module that can be used to extend the concept of SMoEs. We benchmark our implementation against Megablocks, and show that it enables a higher throughput and lower memory footprint. We also show how ParallelLinear enables extensions of the Mixture-of-Experts concept via a demonstration with a Mixture of Attention implementation.
Report issue for preceding element \faGithubSquare
https://github.com/shawntan/scattermoe
Report issue for preceding element
1 Introduction
Report issue for preceding element
Sparse Mixture of Experts (SMoEs; Shazeer et al. 2017 ) have become increasingly popular for scaling up Transformer-based language models. While applications of SMoEs like the Switch Transformer (Fedus et al., 2022) use SMoEs to scale “outrageously” large models by distributing computation of experts across compute nodes, it has proven useful even in scaling up smaller models where device memory is an issue.
Report issue for preceding element
For SMoEs, sparsity is key in reducing computation costs. However, fully exploiting the sparsity to improve the throughput of MoE modules is challenging. While a lot of deep learning research is implemented in PyTorch (Paszke et al., 2019) , the naive implementation of SMoEs does not take full advantage of the parallelism of GPUs and are slow as a result. Initial implementations on Tensor Processing Units (TPUs) for Switch Transformers require all tensor sizes, or capacity, to be specified at compilation, which ensures that all load for every expert is equal (Fedus et al., 2022) . This creates issues when experts are imbalanced: When the router assigns more tokens than capacity allows to a particular expert, some tokens are dropped. Likewise, when experts are underused, the tensors are padded, which creates unnecessary memory allocation. Later, Megablocks (Gale et al., 2023) and PIT (Zheng et al., 2023) framed the SMoE computation as a sparse matrix multiplication problem, which can be computed efficiently with sparse matrix optimised algorithms. In both these cases, the authors were able to create a more efficient GPU-based implementation of SMoEs.
Report issue for preceding element
Despite these recent advances, there is still room for improvement. First, existing implementations of SMoEs, performs a scatter-to-group initial copy of the input, creating a memory allocation overhead during training because of tensors stored for used in the backward pass. Some implementations pad the routed tensors so they are equal-sized blocks, which further increases the memory overhead. Second, Megablocks and PIT requires a translation of the SMoE problem into a sparse matrix format. While this incurs only a small part of the computation overhead, the sparse matrix format makes the intermediate representation harder to extend upon.
Report issue for preceding element 
Figure 1: Current implementations of SMoE Multi-layer Perceptrons (MLPs) require a copy of the embeddings when grouping (left), while ScatterMoE fuses the grouping and linear transformation step (right), reducing the memory footprint of our method. The various colours represent different experts, while the vertical rectangular boxes represent embeddings with their associated time steps labelled above or below them. Report issue for preceding element
In this paper, we present ScatterMoE, an SMoE implementation that minimises this memory overhead. This is made possible by ParallelLinear, a primitive we introduce that performs grouped matrix operations on scattered vectors. The resulting intermediate representations ( e.g. hidden state of an SMoE MLP) can be exposed as standard PyTorch tensors, allowing for easy extensions of present SMoE methods to other types of expert modules. We demonstrate the utility of this representation by implementing SMoE Attention with ParallelLinear, following the specification in Tan et al. ( 2023) . In the final section, we benchmark ScatterMoE against a naive PyTorch implementation and Megablocks.
Report issue for preceding element
2 Related Work
Report issue for preceding element
Other implementations & Dependencies
Report issue for preceding element
The core parts of ScatterMoE is implemented with Triton 1 1 1\faGithubSquare https://github.com/openai/triton (Tillet et al., 2019) , a tile-based language for GPU programming in Python, making it the most accessible for modification and extension. Our main comparison is against Megablocks 2 2 2\faGithubSquare https://github.com/stanford-futuredata/megablocks, which is implemented using the STK framework 3 3 3\faGithubSquare https://github.com/stanford-futuredata/stk which also uses Triton. Megablocks is also used in the Megatron-LM model (Shoeybi et al., 2019; Narayanan et al., 2021; Korthikanti et al., 2023) , and its widespread use as an efficient method for training SMoEs. Another popular library for implementing SMoEs is CUTLASS 4 4 4\faGithubSquare https://github.com/NVIDIA/cutlass (Kim et al., 2022) , with which Megablocks uses as its grouped option.
Report issue for preceding element
Other applications of SMoEs
Report issue for preceding element
Aside from MLPs, SMoE versions of the attention module have also been proposed (Zhang et al., 2022; Csordás et al., 2023) . These mixture-of-attention (MoA) implementations have been used to scale up Universal Transformers (Dehghani et al., 2018; Tan et al., 2023) , and also for applications to continual learning in a fully modularised Transformer (Shen et al., 2023) . Computing SMoEs efficiently will bring huge benefits to the training and inference of these models.
Report issue for preceding element
3 Method
Report issue for preceding element 
(a) Grouped to grouped Report issue for preceding element 
(b) Scattered to grouped Report issue for preceding element 
(c) Scattered to scattered Report issue for preceding element 
(d) Grouped to scatter Report issue for preceding element
Figure 2: ParallelLinear allows for performing different combinations of SMoE transformations allowing for the input and output to be either grouped or scattered. This basic functionality forms the basis of both forward and backward passes of ScatterMoE. Unlike existing implementations, these operations are performed without additional copying (or padding) of the input and output tensors. Report issue for preceding element
In this paper, we will maintain the notation convention of boldface for matrices, i.e. 𝐗 𝐗 \mathbf{X} bold_X . Unless otherwise stated, the first dimension is batch-time (batch and time dimensions flattened) for ease of understanding. Additionally, 𝐗 i subscript 𝐗 𝑖 \mathbf{X}_{i} bold_X start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT denotes the i 𝑖 i italic_i -th row of 𝐗 𝐗 \mathbf{X} bold_X .
Report issue for preceding element
3.1 Sparse Mixture-of-Experts
Report issue for preceding element
SMoE modules are made up of E 𝐸 E italic_E experts which are typically sub-modules of a similar architecture. Each of the T 𝑇 T italic_T tokens in the input is routed via a routing module, and then based on the router output weights, assigned to k 𝑘 k italic_k experts, where k ≤ E 𝑘 𝐸 k\leq E italic_k ≤ italic_E . However, the naive method of computing an SMoE (iterating over all tokens and evaluating the respective expert output) is far too slow, and does not exploit the full parallelism of GPU computation. In practice, SMoE implementations often perform the following main steps:
Report issue for preceding element
Routing – Based on each token embedding 𝐗 t subscript 𝐗 𝑡 \mathbf{X}{t} bold_X start_POSTSUBSCRIPT italic_t end_POSTSUBSCRIPT , the router assigns the weights for each expert g  ( 𝐗 t ) 𝑔 subscript 𝐗 𝑡 g\left(\mathbf{X}{t}\right) italic_g ( bold_X start_POSTSUBSCRIPT italic_t end_POSTSUBSCRIPT ) , and only the top- k 𝑘 k italic_k experts are selected. Report issue for preceding element
Grouping – This step groups all tokens that are assigned to the same expert together. If k > 1 𝑘 1 k>1 italic_k > 1 , as is often the case, then this also results in a “fan out” of tokens, resulting in k  N 𝑘 𝑁 kN italic_k italic_N embeddings in total. Report issue for preceding element
Expert transform – Now that the tokens are grouped by expert, each expert (a linear transform) can be efficiently computed by batched vector transformations (matrix-matrix multiplications). Report issue for preceding element
Scattering – This step returns each token to be grouped by its original time-step. This still results in a k  N 𝑘 𝑁 kN italic_k italic_N embeddings in total. Report issue for preceding element
Weighted sum – This step combines the k 𝑘 k italic_k outputs per token by its original routing weight, Report issue for preceding element 𝐘 t = ∑ e ∈ topk  ( g  ( 𝐗 t ) ) g e  ( 𝐗 t ) ⋅ f e  ( 𝐗 t ) subscript 𝐘 𝑡 subscript 𝑒 topk 𝑔 subscript 𝐗 𝑡 ⋅ subscript 𝑔 𝑒 subscript 𝐗 𝑡 subscript 𝑓 𝑒 subscript 𝐗 𝑡 \mathbf{Y}{t}=\sum{e\in{\mathrm{topk}}(g\left(\mathbf{X}{t}\right))}g{e}% \left(\mathbf{X}{t}\right)\cdot f{e}\left(\mathbf{X}_{t}\right) bold_Y start_POSTSUBSCRIPT italic_t end_POSTSUBSCRIPT = ∑ start_POSTSUBSCRIPT italic_e ∈ roman_topk ( italic_g ( bold_X start_POSTSUBSCRIPT italic_t end_POSTSUBSCRIPT ) ) end_POSTSUBSCRIPT italic_g start_POSTSUBSCRIPT italic_e end_POSTSUBSCRIPT ( bold_X start_POSTSUBSCRIPT italic_t end_POSTSUBSCRIPT ) ⋅ italic_f start_POSTSUBSCRIPT italic_e end_POSTSUBSCRIPT ( bold_X start_POSTSUBSCRIPT italic_t end_POSTSUBSCRIPT ) resulting in N 𝑁 N italic_N embeddings. Report issue for preceding element
Typically, each expert is a Multi-layer Perceptron (MLP) with one hidden layer of dimension d expert subscript 𝑑 expert d_{\mathrm{expert}} italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT .
Report issue for preceding element
In Megablocks, steps (1) and (4) result in a copy of the original input. They further pad the per-expert blocks of tokens so that they fit into equal count for convenient GPU computation (See Figure 1). This allocates the padded array for the embeddings in High Bandwidth Memory (HBM) and copies the original embeddings in sorted order into it. A Grouped GeMM is then performed on the expert-sorted array.
Report issue for preceding element
ScatterMoE, on the other hand, avoids realising the entire padded array in HBM. Instead of copying all the embeddings into a padded array, we sort the tokens according to the experts, and pad the indices instead. When loading a tile into Static RAM (SRAM), we load according to the padded indices, resulting in a padded tile.
Report issue for preceding element
3.2 ParallelLinear operation
Report issue for preceding element
Our implementation of SMoE relies on ParallelLinear, which allows for different combinations of grouped General Matrix Multiplications (GeMMs). In order to achieve this, we wrote a Triton kernel, scatter2scatter, that enables all combinations of operations shown in Figure 2. This operation fuses grouped GeMMs and scattered read and write operations, which allows us to skip an intermediate group and copy step. ParallelLinear allows options for grouped and scattered for both input and output, resulting in the four possible combinations seein in Figure 2. With combinations of these operations, we can implement both the forward and backward passes of ParallelLinear.
Report issue for preceding element
Algorithm 1 provides the pseudo-code of ParallelLinear. It is a thin wrapper around the scatter2scatter kernel, and the grouping options are provided as arguments to ParallelLinear. This is the main workhorse of our SMoE implementation, and can be used for both implementing an MLP and an attention layer. We implemented the backward pass of ParallelLinear independently of its downstream usage to allow it to be used as a primitive to build other experts upon.
Report issue for preceding element
𝐘 ^ ← ← ^ 𝐘 absent \hat{\mathbf{Y}}\leftarrow over^ start_ARG bold_Y end_ARG ← scatter2scatter ( 𝐗 , 𝐖 , 𝐨 , k , *options ) 𝐗 𝐖 𝐨 𝑘 *options \left(\mathbf{X},\mathbf{W},\mathbf{o},k,\texttt{*options}\right) ( bold_X , bold_W , bold_o , italic_k , *options )
if 𝐩 ≠ ∅ 𝐩 \mathbf{p}\neq\varnothing bold_p ≠ ∅ then
𝐘 ^ ← ← ^ 𝐘 absent \hat{\mathbf{Y}}\leftarrow over^ start_ARG bold_Y end_ARG ← view ( 𝐘 ^ , S , j , − 1 ) ^ 𝐘 𝑆 𝑗 1 \left(\hat{\mathbf{Y}},S,j,-1\right) ( over^ start_ARG bold_Y end_ARG , italic_S , italic_j , - 1 ) // reshape and weighted sum if 𝐩 𝐩 \mathbf{p} bold_p is provided.
𝐘 ← bmm  ( 𝐩 , 𝐘 ^ ) ← 𝐘 bmm 𝐩 ^ 𝐘 \mathbf{Y}\leftarrow\texttt{bmm}\left(\mathbf{p},\hat{\mathbf{Y}}\right) bold_Y ← bmm ( bold_p , over^ start_ARG bold_Y end_ARG )
else
𝐘 ← 𝐘 ^ ← 𝐘 ^ 𝐘 \mathbf{Y}\leftarrow\hat{\mathbf{Y}} bold_Y ← over^ start_ARG bold_Y end_ARG
end if
Algorithm 1 ParallelLinear Forward Report issue for preceding element
3.2.1 Backward pass
Report issue for preceding element
In a typical batched linear transformation 𝐘 = 𝐗𝐖 𝐘 𝐗𝐖 \mathbf{Y}=\mathbf{X}\mathbf{W} bold_Y = bold_XW , we need to compute the gradients ∇ 𝐗 ∇ 𝐗 \nabla\mathbf{X} ∇ bold_X and ∇ 𝐖 ∇ 𝐖 \nabla\mathbf{W} ∇ bold_W .
Report issue for preceding element
∇ 𝐗 ∇ 𝐗 \displaystyle\nabla\mathbf{X} ∇ bold_X
= ∇ 𝐘𝐖 ⊤ , absent ∇ superscript 𝐘𝐖 top \displaystyle=\nabla\mathbf{Y}\mathbf{W}^{\top}, = ∇ bold_YW start_POSTSUPERSCRIPT ⊤ end_POSTSUPERSCRIPT ,
∇ 𝐖 ∇ 𝐖 \displaystyle\nabla\mathbf{W} ∇ bold_W
= 𝐗 ⊤  ∇ 𝐘 , absent superscript 𝐗 top ∇ 𝐘 \displaystyle=\mathbf{X}^{\top}\nabla\mathbf{Y}, = bold_X start_POSTSUPERSCRIPT ⊤ end_POSTSUPERSCRIPT ∇ bold_Y ,
In ParallelLinear, we will need to compute these gradients for each of the E 𝐸 E italic_E experts. While this could be computed in a way where 𝐗 𝐗 \mathbf{X} bold_X and ∇ 𝐘 ∇ 𝐘 \nabla\mathbf{Y} ∇ bold_Y are both scattered, the implementation of this operation is fastest when both 𝐗 𝐗 \mathbf{X} bold_X and ∇ 𝐘 ∇ 𝐘 \nabla\mathbf{Y} ∇ bold_Y are grouped 5 5 5 We tested scatterXTY and found it to be slower than a grouping operation followed by groupXTY .
Report issue for preceding element
if 𝐩 ≠ ∅ 𝐩 \mathbf{p}\neq\varnothing bold_p ≠ ∅ then
∇ 𝐩 ← bmm  ( ∇ 𝐘 , 𝐘 ^ ) ← ∇ 𝐩 bmm ∇ 𝐘 ^ 𝐘 \nabla\mathbf{p}\leftarrow\texttt{bmm}\left(\nabla\mathbf{Y},{\color[rgb]{% 0,0,1}\hat{\mathbf{Y}}}\right) ∇ bold_p ← bmm ( ∇ bold_Y , over^ start_ARG bold_Y end_ARG )
∇ 𝐘 ¯ ← group  ( ∇ 𝐘 , 𝐨 , 𝐩 ) ← ¯ ∇ 𝐘 group ∇ 𝐘 𝐨 𝐩 {\color[rgb]{0,0,1}\bar{\nabla\mathbf{Y}}}\leftarrow\texttt{group}(\nabla% \mathbf{Y},\mathbf{o},\mathbf{p}) over¯ start_ARG ∇ bold_Y end_ARG ← group ( ∇ bold_Y , bold_o , bold_p ) // weight and group
else
∇ 𝐘 ¯ ← 𝐘 ← ¯ ∇ 𝐘 𝐘 \bar{\nabla\mathbf{Y}}\leftarrow\mathbf{Y} over¯ start_ARG ∇ bold_Y end_ARG ← bold_Y
end if
if 𝐗 𝐗 \mathbf{X} bold_X is not grouped then
𝐗 ¯ ← group  ( 𝐗 , 𝐨 , ∅ ) ← ¯ 𝐗 group 𝐗 𝐨 {\color[rgb]{1,.5,0}\bar{\mathbf{X}}}\leftarrow\texttt{group}(\mathbf{X},% \mathbf{o},\varnothing) over¯ start_ARG bold_X end_ARG ← group ( bold_X , bold_o , ∅ )
else
𝐗 ¯ ← 𝐗 ← ¯ 𝐗 𝐗 \bar{\mathbf{X}}\leftarrow\mathbf{X} over¯ start_ARG bold_X end_ARG ← bold_X
end if
∇ 𝐖 ← groupXTY  ( 𝐗 ¯ , ∇ 𝐘 ¯ ) ← ∇ 𝐖 groupXTY ¯ 𝐗 ¯ ∇ 𝐘 \nabla\mathbf{W}\leftarrow\texttt{groupXTY}\left(\bar{\mathbf{X}},\bar{\nabla% \mathbf{Y}}\right) ∇ bold_W ← groupXTY ( over¯ start_ARG bold_X end_ARG , over¯ start_ARG ∇ bold_Y end_ARG )
∇ 𝐗 ¯ ← scatter2scatter  ( ∇ 𝐘 ¯ , 𝐖 ⊤ , 𝐨 , 1 ) ← ¯ ∇ 𝐗 scatter2scatter ¯ ∇ 𝐘 superscript 𝐖 top 𝐨 1 {\color[rgb]{1,.5,0}\bar{\nabla\mathbf{X}}}\leftarrow\texttt{scatter2scatter}% \left(\bar{\nabla\mathbf{Y}},\mathbf{W}^{\top},\mathbf{o},1\right) over¯ start_ARG ∇ bold_X end_ARG ← scatter2scatter ( over¯ start_ARG ∇ bold_Y end_ARG , bold_W start_POSTSUPERSCRIPT ⊤ end_POSTSUPERSCRIPT , bold_o , 1 ) // grouped to scatter or group depending on original input
Algorithm 2 ParallelLinear Backward Report issue for preceding element
Algorithm 2 groups the embeddings when they are not grouped in order to compute ∇ 𝐖 ∇ 𝐖 \nabla\mathbf{W} ∇ bold_W . groupXTY is the kernel that implements this grouped matrix multiplication. While this grouping incurs additional memory allocations for potentially very large matrices, these array allocations could be reused. Once the gradients ∇ 𝐩 ∇ 𝐩 \nabla\mathbf{p} ∇ bold_p has been computed, the array for 𝐘 ^ ^ 𝐘 \hat{\mathbf{Y}} over^ start_ARG bold_Y end_ARG can be used as the output for ∇ 𝐘 ¯ ¯ ∇ 𝐘 \bar{\nabla\mathbf{Y}} over¯ start_ARG ∇ bold_Y end_ARG . 𝐗 ¯ ¯ 𝐗 \bar{\mathbf{X}} over¯ start_ARG bold_X end_ARG can be reused for ∇ 𝐗 ¯ ¯ ∇ 𝐗 \bar{\nabla\mathbf{X}} over¯ start_ARG ∇ bold_X end_ARG as they are of the same dimensions. We can then further minimise the use of memory during the backward pass by re-using the arrays used for the grouping operations. We colour the reused arrays in blue and orange respectively in Algorithm 2.
Report issue for preceding element
3.2.2 SMoE Multi-layer Perceptron (SMoE MLP)
Report issue for preceding element
In the context of an SMoE MLP, we can reduce the memory footprint even further. The MLP requires two linear transformations, and could be naively implemented with two ParallelLinear operations set to perform scatter-to-scatter transformations. However, we can configure these two linear transforms to be scattered-to-grouped then grouped-to-scattered respectively. This will allow each ParallelLinear transform in the SMoE MLP to require only one group operation during the backward pass.
Report issue for preceding element
Input:
𝐗 𝐗 \mathbf{X} bold_X
T × d model 𝑇 subscript 𝑑 model T\times d_{\mathrm{model}} italic_T × italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT
input matrix
𝐨 𝐨 \mathbf{o} bold_o
T 𝑇 T italic_T
vector of grouped ordering
𝐖 1 subscript 𝐖 1 \mathbf{W}_{1} bold_W start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT
E × d model × d expert 𝐸 subscript 𝑑 model subscript 𝑑 expert E\times d_{\mathrm{model}}\times d_{\mathrm{expert}} italic_E × italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT × italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT
transformation tensor
𝐖 2 subscript 𝐖 2 \mathbf{W}_{2} bold_W start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT
E × d expert × d model 𝐸 subscript 𝑑 expert subscript 𝑑 model E\times d_{\mathrm{expert}}\times d_{\mathrm{model}} italic_E × italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT × italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT
transformation tensor
Output:
𝐘 𝐘 \mathbf{Y} bold_Y
T × d model 𝑇 subscript 𝑑 model T\times d_{\mathrm{model}} italic_T × italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT
output matrix
𝐇 ← ParallelLinear  ( 𝐗 , 𝐖 1 , 𝐨 , ∅ , grouped_in=False , grouped_out=True ) ← 𝐇 ParallelLinear 𝐗 subscript 𝐖 1 𝐨 grouped_in=False grouped_out=True \mathbf{H}\leftarrow\texttt{ParallelLinear}\left(\mathbf{X},\mathbf{W}_{1},% \mathbf{o},\varnothing,\texttt{grouped_in=False},\texttt{grouped_out=True}\right) bold_H ← ParallelLinear ( bold_X , bold_W start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , bold_o , ∅ , grouped_in=False , grouped_out=True )
𝐇 ← σ  ( 𝐇 ^ ) ← 𝐇 𝜎 ^ 𝐇 \mathbf{H}\leftarrow\sigma\left(\hat{\mathbf{H}}\right) bold_H ← italic_σ ( over^ start_ARG bold_H end_ARG ) // where σ 𝜎 \sigma italic_σ is any point-wise non-linearity
𝐘 ← ParallelLinear  ( 𝐇 , 𝐖 2 , 𝐨 , 𝐩 , grouped_in=True , grouped_out=False ) ← 𝐘 ParallelLinear 𝐇 subscript 𝐖 2 𝐨 𝐩 grouped_in=True grouped_out=False \mathbf{Y}\leftarrow\texttt{ParallelLinear}\left(\mathbf{H},\mathbf{W}_{2},% \mathbf{o},\mathbf{p},\texttt{grouped_in=True},\texttt{grouped_out=False}\right) bold_Y ← ParallelLinear ( bold_H , bold_W start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , bold_o , bold_p , grouped_in=True , grouped_out=False )
Algorithm 3 SMoE Multi-layer Perceptron Report issue for preceding element
3.3 Extensibility: Mixture-of-Attention (MoA)
Report issue for preceding element
There have been several proposals for applying SMoEs to the attention layer (Zhang et al., 2022; Csordás et al., 2023; Tan et al., 2023) . Regardless of formulation, before the attention layer is applied, the embeddings should be in chronological order (scattered) to facilitate the application of positional embeddings and to compute the result of the attention weights and value embeddings. With existing SMoE implementations, there would be an additional pair of group-scatter operations, incurring additional memory costs.
Report issue for preceding element
ScatterMoE provides an advantage. Since we can retain the scattered ordering through a ParallelLinear transform, we can implement MoAs without allocating the extra arrays for grouping and scattering. Figure 3 shows the operations used for SMoE Attention. In this report, we specifically implement and benchmark the Mixture of Multi-head Attention variant found in Tan et al. ( 2023) .
Report issue for preceding element 
Figure 3: ParallelLinear allows for scattered to scattered transformations which retains the chronological order. Report issue for preceding element
This version resembles Grouped-query Attention (GQA; Ainslie et al. 2023 ), where each key head has multiple possible query heads, while in the SMoE setting, there would be h expert subscript ℎ expert h_{\mathrm{expert}} italic_h start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT key heads, with k ⋅ h expert ⋅ 𝑘 subscript ℎ expert k\cdot h_{\mathrm{expert}} italic_k ⋅ italic_h start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT query heads selected from a possible E ⋅ h expert ⋅ 𝐸 subscript ℎ expert E\cdot h_{\mathrm{expert}} italic_E ⋅ italic_h start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT heads, where h expert subscript ℎ expert h_{\mathrm{expert}} italic_h start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT is the number of heads per expert.
Report issue for preceding element
Following the standard attention implementation conventions, we set d out = d expert ⋅ d head subscript 𝑑 out ⋅ subscript 𝑑 expert subscript 𝑑 head d_{\mathrm{out}}=d_{\mathrm{expert}}\cdot d_{\mathrm{head}} italic_d start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT = italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT ⋅ italic_d start_POSTSUBSCRIPT roman_head end_POSTSUBSCRIPT , where d head subscript 𝑑 head d_{\mathrm{head}} italic_d start_POSTSUBSCRIPT roman_head end_POSTSUBSCRIPT is the number of dimensions for each head. We then reshape accordingly when we perform the attention operation so that the separate heads interact independently.
Report issue for preceding element
In Algorithm 4, we also consider the time dimension, so we express the inputs and intermediate arrays as 3-dimensional tensors with the dimensions for batch, time, and embedding dimensions ( B × T × d 𝐵 𝑇 𝑑 B\times T\times d italic_B × italic_T × italic_d ). In practice, we assume that the input is contiguous and is batch-time ordered, allowing us to flatten the tensor and proceed as we did in the case of the MLP. Note that for the SMoE attention, a key distinction is that we require ParallelLinear to give an ungrouped output after the first transformation, and it takes an ungrouped input for the output transform, which means both ParallelLinear transformation use a scattered to scattered configuration (Figure 2(c)).
Report issue for preceding element
𝐕 ← 𝐗 ⊤  𝐖 V ← 𝐕 superscript 𝐗 top subscript 𝐖 𝑉 \mathbf{V}\leftarrow\mathbf{X}^{\top}\mathbf{W}_{V} bold_V ← bold_X start_POSTSUPERSCRIPT ⊤ end_POSTSUPERSCRIPT bold_W start_POSTSUBSCRIPT italic_V end_POSTSUBSCRIPT
𝐊 ← 𝐗 ⊤  𝐖 K ← 𝐊 superscript 𝐗 top subscript 𝐖 𝐾 \mathbf{K}\leftarrow\mathbf{X}^{\top}\mathbf{W}_{K} bold_K ← bold_X start_POSTSUPERSCRIPT ⊤ end_POSTSUPERSCRIPT bold_W start_POSTSUBSCRIPT italic_K end_POSTSUBSCRIPT
𝐐 ← ParallelLinear  ( 𝐗 , 𝐖 Q , 𝐨 , ∅ , grouped_in=False , grouped_out=False ) ← 𝐐 ParallelLinear 𝐗 subscript 𝐖 𝑄 𝐨 grouped_in=False grouped_out=False \mathbf{Q}\leftarrow\texttt{ParallelLinear}\left(\mathbf{X},\mathbf{W}_{Q},% \mathbf{o},\varnothing,\texttt{grouped_in=False},\texttt{grouped_out=False}\right) bold_Q ← ParallelLinear ( bold_X , bold_W start_POSTSUBSCRIPT italic_Q end_POSTSUBSCRIPT , bold_o , ∅ , grouped_in=False , grouped_out=False )
𝐎 ^ ← Attention  ( 𝐐 , 𝐊 , 𝐕 ) ← ^ 𝐎 Attention 𝐐 𝐊 𝐕 \hat{\mathbf{O}}\leftarrow\texttt{Attention}\left(\mathbf{Q},\mathbf{K},% \mathbf{V}\right) over^ start_ARG bold_O end_ARG ← Attention ( bold_Q , bold_K , bold_V )
𝐎 ← ParallelLinear  ( 𝐎 ^ , 𝐖 O , 𝐨 , 𝐩 , grouped_in=False , grouped_out=False ) ← 𝐎 ParallelLinear ^ 𝐎 subscript 𝐖 𝑂 𝐨 𝐩 grouped_in=False grouped_out=False \mathbf{O}\leftarrow\texttt{ParallelLinear}\left(\hat{\mathbf{O}},\mathbf{W}_{% O},\mathbf{o},\mathbf{p},\texttt{grouped_in=False},\texttt{grouped_out=False% }\right) bold_O ← ParallelLinear ( over^ start_ARG bold_O end_ARG , bold_W start_POSTSUBSCRIPT italic_O end_POSTSUBSCRIPT , bold_o , bold_p , grouped_in=False , grouped_out=False )
Algorithm 4 SMoE Multi-head Attention Report issue for preceding element
4 Performance
Report issue for preceding element
In this section, we cover the performance of our implementation for both training and inference. As an overall integrated test, we benchmark our method within Mixtral (Jiang et al., 2024) , using a ∼ similar-to \sim ∼ 1.5B parameter configuration,
Report issue for preceding element
d model subscript 𝑑 model \displaystyle d_{\mathrm{model}} italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT
= 1024 , absent 1024 \displaystyle=1024, = 1024 ,
d expert subscript 𝑑 expert \displaystyle d_{\mathrm{expert}} italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT
= 3584 , absent 3584 \displaystyle=3584, = 3584 ,
k 𝑘 \displaystyle k italic_k
= 2 , absent 2 \displaystyle=2, = 2 ,
E 𝐸 \displaystyle E italic_E
= 8 , absent 8 \displaystyle=8, = 8 ,
L 𝐿 \displaystyle L italic_L
= 16 , absent 16 \displaystyle=16, = 16 ,
We compare against the naive implementation from HuggingFace ( Naive HF impl.), then swapping out the SMoE layer with Megablocks sparse ( MB (Sparse)) and grouped memory efficient ( MB (Mem. eff.)), and finally ScatterMoE ( Ours). Our goal is to measure the overall throughput in a training setting.
Report issue for preceding element
We ran the training for 100 training updates, with an effective batch size of 256 and 2048 tokens per instance, across 8 A100 GPUs on the same compute node. For both the naive and ScatterMoE, this resulted in an actual batch size of 128 and 2 accumulation steps, while the Megablocks benchmarks required a batch size if 64 and 4 accumulation steps. We ran the training for a 100 steps and computed the overall throughput. Our method outperforms both the Sparse Megablocks implementation by 38.1% in this setting. This indicates the importance of the smaller memory footprint, but at larger dimensions with equivalent batch sizes, the gains are not as significant.
Report issue for preceding element 
(a) 1.5B model training throughput Report issue for preceding element 
(b) SMoE MLP unit throughput Report issue for preceding element 
(c) SMoE MLP unit memory use Report issue for preceding element
Figure 4: Report issue for preceding element
The rest of this section covers the other benchmarking experiments we performed in more detail, testing for the effects of decreasing sparsity, and increasing granularity of experts, and benchmarking of our Mixture of Attention implementation.
Report issue for preceding element
4.1 Unit Benchmarking on the SMoE MLP
Report issue for preceding element
Unless otherwise stated, we use the following model hyperparameters,
Report issue for preceding element
d model subscript 𝑑 model \displaystyle d_{\mathrm{model}} italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT
= 4096 , absent 4096 \displaystyle=4096, = 4096 ,
d ff subscript 𝑑 ff \displaystyle d_{\mathrm{ff}} italic_d start_POSTSUBSCRIPT roman_ff end_POSTSUBSCRIPT
= 2  d model , absent 2 subscript 𝑑 model \displaystyle=2d_{\mathrm{model}}, = 2 italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT ,
d expert subscript 𝑑 expert \displaystyle d_{\mathrm{expert}} italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT
= d ff / k , absent subscript 𝑑 ff 𝑘 \displaystyle=d_{\mathrm{ff}}/k, = italic_d start_POSTSUBSCRIPT roman_ff end_POSTSUBSCRIPT / italic_k ,
E 𝐸 \displaystyle E italic_E
= 8  k absent 8 𝑘 \displaystyle=8k = 8 italic_k
For example, the active hidden units for an MLP is 2 ⋅ 4096 = 8192 ⋅ 2 4096 8192 2\cdot 4096=8192 2 ⋅ 4096 = 8192 . If k = 4 𝑘 4 k=4 italic_k = 4 , then E = 4 ⋅ 8 = 32 𝐸 ⋅ 4 8 32 E=4\cdot 8=32 italic_E = 4 ⋅ 8 = 32 , with each expert being 8192 / k = 2048 8192 𝑘 2048 8192/k=2048 8192 / italic_k = 2048 dimensions. Each datapoint on the plot is the median and 5-th and 95-th percentiles of 100 runs of the module. In this unit test, we use a more efficient PyTorch implementation from the implementation of Tan et al. ( 2023) 6 6 6\faGithubSquare https://github.com/shawntan/SUT/tree/main/sut_layer/parallel_linear/parallel_experts
Report issue for preceding element
Figure 4(a) summarises the overall performance for an SMoE MLP where E = 32 , k = 4 formulae-sequence 𝐸 32 𝑘 4 E=32,k=4 italic_E = 32 , italic_k = 4 , and T = 30 ⋅ 2048 𝑇 ⋅ 30 2048 T=30\cdot 2048 italic_T = 30 ⋅ 2048 . All benchmark times are measured on an Nvidia A100 GPU. Generally, we find that ScatterMoE has slightly higher throughput during training, for the same input sizes. Our method shows a larger margin of improvement for inference.
Report issue for preceding element
On memory consumption, our implementation for the SMoE MLP uses 66.2% of the memory Megablocks uses during training, while using only 53.6% of the memory of Megablocks if we consider only inference.
Report issue for preceding element
4.2 Granularity and Throughput
Report issue for preceding element
Krajewski et al. ( 2024) defines the concept of granularity. Given a SMoE MLP with the equivalent active parameters as an MLP with intermediate dimension layer of dimension d ff subscript 𝑑 ff d_{\textrm{ff}} italic_d start_POSTSUBSCRIPT ff end_POSTSUBSCRIPT , and with each expert of dimension d expert subscript 𝑑 expert d_{\textrm{expert}} italic_d start_POSTSUBSCRIPT expert end_POSTSUBSCRIPT , then granularity is defined as,
Report issue for preceding element
G = d ff d expert 𝐺 subscript 𝑑 ff subscript 𝑑 expert G=\frac{d_{\textrm{ff}}}{d_{\textrm{expert}}} italic_G = divide start_ARG italic_d start_POSTSUBSCRIPT ff end_POSTSUBSCRIPT end_ARG start_ARG italic_d start_POSTSUBSCRIPT expert end_POSTSUBSCRIPT end_ARG
Here, we measure the effect of throughput as we vary G 𝐺 G italic_G while fixing d ff subscript 𝑑 ff d_{\mathrm{ff}} italic_d start_POSTSUBSCRIPT roman_ff end_POSTSUBSCRIPT . Accordingly, with higher values of G 𝐺 G italic_G , we need to increase values of k 𝑘 k italic_k and E 𝐸 E italic_E — more granularity requires more experts to achieve the same active parameters.
Report issue for preceding element
We test values of k ∈ { 1 , 2 , 4 , 8 , 16 } 𝑘 1 2 4 8 16 k\in{1,2,4,8,16} italic_k ∈ { 1 , 2 , 4 , 8 , 16 } , and E = 8  k 𝐸 8 𝑘 E=8k italic_E = 8 italic_k for divisibility of dimension sizes. Figure 5 shows how throughput of both methods vary relative to a model with equivalent active parameters. Since we maintain constant active and total parameters for these runs, these results are also constant for all G 𝐺 G italic_G .
Report issue for preceding element 
(a) Training throughput Report issue for preceding element 
(b) Inference throughput Report issue for preceding element
Figure 5: Increasing k 𝑘 k italic_k and E 𝐸 E italic_E while fixing the number of active parameters and total parameters. We find that our implementation scales better with higher k 𝑘 k italic_k . Inference granularity scaling performance. The difference in relative throughput is higher if we consider only the forward pass. Report issue for preceding element
We find that ScatterMoE scales with G 𝐺 G italic_G with better throughput. This may be related to the increase in zero-padding required for higher number of E 𝐸 E italic_E in the case of Megablocks — as the number of experts grows and the embeddings assigned to each expert decreases, there will be more padding introduced. If we consider only the forward pass, the relative gap between our method and Megablocks is also much higher than in the case of training. This makes our method favourable for batched inference, especially with high granularity settings. The results of Krajewski et al. ( 2024) suggests higher G 𝐺 G italic_G for SMoE models, and our implementation seems suited for this application.
Report issue for preceding element
4.3 Decreasing sparsity
Report issue for preceding element
We can view the SMoE as an interpolation between a model with the size of just the active parameters k ⋅ d expert ⋅ 𝑘 subscript 𝑑 expert k\cdot d_{\mathrm{expert}} italic_k ⋅ italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT and a large fully dense model with E ⋅ d expert ⋅ 𝐸 subscript 𝑑 expert E\cdot d_{\mathrm{expert}} italic_E ⋅ italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT . However, SMoE comes with additional overhead ( e.g. routing, sorting), and we want to measure how much reducing sparsity will affect throughput, in comparison to a fully dense model.
Report issue for preceding element
In this experiment, we tested on increasing values of k ≤ 30 𝑘 30 k\leq 30 italic_k ≤ 30 . Further increasing k 𝑘 k italic_k reaches the limit of device memory for Megablocks. We maintain E = 64 𝐸 64 E=64 italic_E = 64 for all runs, and compare the performance of both Megablocks and ScatterMoE to a dense model with a d ff = E ⋅ d expert subscript 𝑑 ff ⋅ 𝐸 subscript 𝑑 expert d_{\mathrm{ff}}=E\cdot d_{\mathrm{expert}} italic_d start_POSTSUBSCRIPT roman_ff end_POSTSUBSCRIPT = italic_E ⋅ italic_d start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT .
Report issue for preceding element 
Figure 6: Relative throughput curves as we decrease sparsity (increasing k 𝑘 k italic_k ) Report issue for preceding element
Generally, we find that while our implementation performs with slightly better throughput overall, both Megablocks and our implementations are still more efficient than a large dense MLP with equivalent parameters. However, note that in this case, the throughput for k = 30 , E = 64 formulae-sequence 𝑘 30 𝐸 64 k=30,E=64 italic_k = 30 , italic_E = 64 is already reaching the throughput for an equivalent dense model with the same parameters. Further increasing k 𝑘 k italic_k exceeds the memory of the device we ran the benchmarks on for Megablocks.
Report issue for preceding element
4.4 Mixture-of-Attention
Report issue for preceding element 
(a) MoA throughput Report issue for preceding element 
(b) Training throughput Report issue for preceding element 
(c) Inference throughput Report issue for preceding element
Report issue for preceding element Figure 8: The curves for increasing granularity for the MoMHA implementation. In this case, the Active params baseline varies in throughput because of the shared key and value vectors across the experts. Report issue for preceding element
As previously mentioned, we implement the Mixture of Multi-head Attention (MoMHA) variant of Attention SMoEs as described in Tan et al. ( 2023) . This implementation allows for multiple attention heads per expert, and shares the key and value embeddings across the attention experts. This formulation is similar to Grouped-query Attention (GQA; Ainslie et al. 2023 ), where each head of the key has several query heads, each of these forming a group. MoMHA experts are the equivalent of groups in GQA, where each group is of size k 𝑘 k italic_k .
Report issue for preceding element
For the following benchmarks, we adhere to the following parameters:
Report issue for preceding element
d model subscript 𝑑 model \displaystyle d_{\mathrm{model}} italic_d start_POSTSUBSCRIPT roman_model end_POSTSUBSCRIPT
= 4096 , absent 4096 \displaystyle=4096, = 4096 ,
d head subscript 𝑑 head \displaystyle d_{\mathrm{head}} italic_d start_POSTSUBSCRIPT roman_head end_POSTSUBSCRIPT
= 128 , absent 128 \displaystyle=128, = 128 ,
T 𝑇 \displaystyle T italic_T
= 16 ⋅ 2048 , absent ⋅ 16 2048 \displaystyle=16\cdot 2048, = 16 ⋅ 2048 ,
h ℎ \displaystyle h italic_h
= 32 , absent 32 \displaystyle=32, = 32 ,
h expert subscript ℎ expert \displaystyle h_{\mathrm{expert}} italic_h start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT
= h / k , absent ℎ 𝑘 \displaystyle=h/k, = italic_h / italic_k ,
E 𝐸 \displaystyle E italic_E
= 8  k absent 8 𝑘 \displaystyle=8k = 8 italic_k
where d head subscript 𝑑 head d_{\mathrm{head}} italic_d start_POSTSUBSCRIPT roman_head end_POSTSUBSCRIPT is the dimension of each attention head and h ℎ h italic_h is the number of active attention heads.
Report issue for preceding element
We implemented an equivalent baseline in Megablocks using the 'dense' configuration in the library. This version still suffers from the issue with having to perform redundant grouping and scattering steps.
Report issue for preceding element
For k = 8 𝑘 8 k=8 italic_k = 8 , we find that our implementation outperforms Megablocks, by 24.0% of througput for inference. We also note from Figure 8, that as we increase granularity (fewer heads per expert / smaller h expert subscript ℎ expert h_{\mathrm{expert}} italic_h start_POSTSUBSCRIPT roman_expert end_POSTSUBSCRIPT ), the gap between our implementation and Megablocks grows as well. Again, our method is favourable for use in high granularity settings for Mixture-of-Attention
Report issue for preceding element
4.5 Mixtral Inference Comparison
Report issue for preceding element
Table 1: Language Model Evaluation Harness results comparisons: Hugging Face v. ScatterMoE implementations. Differences in results between both implementations are negligible. Report issue for preceding element
Finally, we converted Mixtral 8x7B 7 7 7 https://huggingface.co/mistralai/Mixtral-8x7B-v0.1 to use ScatterMoE, and ran the LM Evaluation Harness (Gao et al., 2023) on several benchmarks (See Table 1). As ScatterMoE is an alternative implementation of Sparse MoEs, we do not expect any differences in the final evaluation results. The absolute error between the Hugging Face naive implementation and ScatterMoE is sufficiently small, which demonstrates this.
Report issue for preceding element
We have included the script to convert the model parameters from Hugging Face's format to a format compatible for ScatterMoE 8 8 8 https://github.com/shawntan/scattermoe/blob/main/examples/convert.py
Report issue for preceding element
5 Conclusion & Limitations
Report issue for preceding element
ScatterMoE is an implementation of SMoEs in Triton that reduces the memory footprint and offers slightly higher throughput on the GPU compared to existing solutions. We have also engineered ScatterMoE to use the ParallelLinear primitive, which we envision to be a module that can be extended upon to build other SMoE-style modules that require grouped or scattered linear transformations. At present, ScatterMoE does not implement a specialised kernel for speeding up decoding, and further work is required for parallelisation in a multi-node setting. These additional features will be added in future iterations, and we believe further testing by us and the open source community will iron out any remaining bugs and performance issues left unoptimised. Finally, we have also provided an implementation of an MLP and Attention layer based on ScatterMoE, that we hope will benefit any future implementations of Mixture-of-Expert based models, and serve as worked examples for extending the concept of SMoEs to other variants of linear transformation based experts.
Report issue for preceding element
Acknowledgments
Report issue for preceding element
We would like to Bowen Pan for testing and feedback of ScatterMoE, and Songlin Yang's valuable advice during the development of the ScatterMoE kernels. Finally, we would like to thank Mayank Mishra for his help enabling torch.compile 9 9 9\faGithubSquare https://github.com/mayank31398/kernel-hyperdrive/ and integrating ScatterMoE into Dolomite Engine (Mishra, 2024) 10 10 10\faGithubSquare https://github.com/IBM/dolomite-engine.
Report issue for preceding element
References
Report issue for preceding element
Ainslie et al. (2023) ↑ Joshua Ainslie, James Lee-Thorp, Michiel de Jong, Yury Zemlyanskiy, Federico Lebrón, and Sumit Sanghai. Gqa: Training generalized multi-query transformer models from multi-head checkpoints. arXiv preprint arXiv:2305.13245, 2023.
Csordás et al. (2023) ↑ Róbert Csordás, Piotr Piekos, and Kazuki Irie. Switchhead: Accelerating transformers with mixture-of-experts attention. arXiv preprint arXiv:2312.07987, 2023.
Dehghani et al. (2018) ↑ Mostafa Dehghani, Stephan Gouws, Oriol Vinyals, Jakob Uszkoreit, and Łukasz Kaiser. Universal transformers. arXiv preprint arXiv:1807.03819, 2018.
Fedus et al. (2022) ↑ William Fedus, Barret Zoph, and Noam Shazeer. Switch transformers: Scaling to trillion parameter models with simple and efficient sparsity. The Journal of Machine Learning Research, 23(1):5232–5270, 2022.
Gale et al. (2023) ↑ Trevor Gale, Deepak Narayanan, Cliff Young, and Matei Zaharia. MegaBlocks: Efficient Sparse Training with Mixture-of-Experts. Proceedings of Machine Learning and Systems, 5, 2023.
Gao et al. (2023) ↑ Leo Gao, Jonathan Tow, Baber Abbasi, Stella Biderman, Sid Black, Anthony DiPofi, Charles Foster, Laurence Golding, Jeffrey Hsu, Alain Le Noac'h, Haonan Li, Kyle McDonell, Niklas Muennighoff, Chris Ociepa, Jason Phang, Laria Reynolds, Hailey Schoelkopf, Aviya Skowron, Lintang Sutawika, Eric Tang, Anish Thite, Ben Wang, Kevin Wang, and Andy Zou. A framework for few-shot language model evaluation, 12 2023. URL https://zenodo.org/records/10256836.
Jiang et al. (2024) ↑ Albert Q Jiang, Alexandre Sablayrolles, Antoine Roux, Arthur Mensch, Blanche Savary, Chris Bamford, Devendra Singh Chaplot, Diego de las Casas, Emma Bou Hanna, Florian Bressand, et al. Mixtral of experts. arXiv preprint arXiv:2401.04088, 2024.
Kim et al. (2022) ↑ Young Jin Kim, Rawn Henry, Raffy Fahim, and Hany Hassan Awadalla. Who says elephants can't run: Bringing large scale moe models into cloud scale production. arXiv preprint arXiv:2211.10017, 2022.
Korthikanti et al. (2023) ↑ Vijay Anand Korthikanti, Jared Casper, Sangkug Lym, Lawrence McAfee, Michael Andersch, Mohammad Shoeybi, and Bryan Catanzaro. Reducing activation recomputation in large transformer models. Proceedings of Machine Learning and Systems, 5, 2023.
Krajewski et al. (2024) ↑ Jakub Krajewski, Jan Ludziejewski, Kamil Adamczewski, Maciej Pióro, Michał Krutul, Szymon Antoniak, Kamil Ciebiera, Krystian Król, Tomasz Odrzygóźdź, Piotr Sankowski, et al. Scaling laws for fine-grained mixture of experts. arXiv preprint arXiv:2402.07871, 2024.
Mishra (2024) ↑ Mayank Mishra. Dolomite Engine: A Hyper-Optimized Library for Pretraining and Finetuning, June 2024. URL https://github.com/ibm/dolomite-engine.
Narayanan et al. (2021) ↑ Deepak Narayanan, Mohammad Shoeybi, Jared Casper, Patrick LeGresley, Mostofa Patwary, Vijay Korthikanti, Dmitri Vainbrand, Prethvi Kashinkunti, Julie Bernauer, Bryan Catanzaro, et al. Efficient large-scale language model training on gpu clusters using megatron-lm. In Proceedings of the International Conference for High Performance Computing, Networking, Storage and Analysis, pp. 1–15, 2021.
Paszke et al. (2019) ↑ Adam Paszke, Sam Gross, Francisco Massa, Adam Lerer, James Bradbury, Gregory Chanan, Trevor Killeen, Zeming Lin, Natalia Gimelshein, Luca Antiga, et al. Pytorch: An imperative style, high-performance deep learning library. Advances in neural information processing systems, 32, 2019.
Shazeer et al. (2017) ↑ Noam Shazeer, Azalia Mirhoseini, Krzysztof Maziarz, Andy Davis, Quoc Le, Geoffrey Hinton, and Jeff Dean. Outrageously large neural networks: The sparsely-gated mixture-of-experts layer. arXiv preprint arXiv:1701.06538, 2017.
Shen et al. (2023) ↑ Yikang Shen, Zheyu Zhang, Tianyou Cao, Shawn Tan, Zhenfang Chen, and Chuang Gan. Moduleformer: Learning modular large language models from uncurated data. arXiv preprint arXiv:2306.04640, 2023.
Shoeybi et al. (2019) ↑ Mohammad Shoeybi, Mostofa Patwary, Raul Puri, Patrick LeGresley, Jared Casper, and Bryan Catanzaro. Megatron-lm: Training multi-billion parameter language models using model parallelism. arXiv preprint arXiv:1909.08053, 2019.
Tan et al. (2023) ↑ Shawn Tan, Yikang Shen, Zhenfang Chen, Aaron Courville, and Chuang Gan. Sparse universal transformer. arXiv preprint arXiv:2310.07096, 2023.
Tillet et al. (2019) ↑ Philippe Tillet, Hsiang-Tsung Kung, and David Cox. Triton: an intermediate language and compiler for tiled neural network computations. In Proceedings of the 3rd ACM SIGPLAN International Workshop on Machine Learning and Programming Languages, pp. 10–19, 2019.
Zhang et al. (2022) ↑ Xiaofeng Zhang, Yikang Shen, Zeyu Huang, Jie Zhou, Wenge Rong, and Zhang Xiong. Mixture of attention heads: Selecting attention heads per token. arXiv preprint arXiv:2210.05144, 2022.
Zheng et al. (2023) ↑ Ningxin Zheng, Huiqiang Jiang, Quanlu Zhang, Zhenhua Han, Lingxiao Ma, Yuqing Yang, Fan Yang, Chengruidong Zhang, Lili Qiu, Mao Yang, et al. Pit: Optimization of dynamic sparse deep learning models via permutation invariant transformation. In Proceedings of the 29th Symposium on Operating Systems Principles, pp. 331–347, 2023.
Report Issue
Report Github Issue
Title: Content selection saved. Describe the issue below: Description:
Submit without Github Submit in Github
Report Issue for Selection
Generated by L A T E xml
Instructions for reporting errors
We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the methods listed below:
Click the "Report Issue" button.
Open a report feedback form via keyboard, use " Ctrl + ?".
Make a text selection and click the "Report Issue for Selection" button near your cursor.
You can use Alt+Y to toggle on and Alt+Shift+Y to toggle off accessible reporting links at each section.
Our team has already identified the following issues. We appreciate your time reviewing and reporting rendering errors we may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability should not be a barrier to accessing research. Thank you for your continued support in championing open access for all.
Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a list of packages that need conversion, and welcome developer contributions.