> Source: https://www.reddit.com/r/quantum/comments/1n637nc/best_quantum_chem_books_for_a_quantum_computing/

Best Quantum Chem books for a Quantum Computing baddie : r/quantum
Skip to main content Best Quantum Chem books for a Quantum Computing baddie : r/quantum
Open menu
Open navigation 
Go to Reddit Home
Ask
Sign Up
Sign up for Reddit
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Sign up Skip to Right Sidebar
Back
Go to quantum
r/quantum
•
9mo ago
Putrid-Speaker4866
Locked post
Stickied post
Archived post
Report
r/QuantumChemistry
• 9 mo. ago
Best Quantum Chem books for a Quantum Computing baddie
I have a background in chemistry (undergrad ) and "classical" computer science. I've been involved in quantum computing research (just the algorithms side, no hardware - god save me) for a bit over a year.
Now, I'm starting a new research project that's more in the Quantum Chem side, but semi in the context of quantum computing. So, I'm looking for a nice textbook that's not just focused on first quantization.
Any recommendations?
4 upvotes
· 2 comments
Upvote 3 Downvote 1 Go to comments Share
Sort by: Best
Open comment sort options
Best
Top
New
Controversial
Old
Q&A
Search Comments Expand comment search
Cancel
Comments Section
shockwave6969
•
9mo ago
McQuarrie is a classic quantum chemistry text. I worked through about the first 400 pages or so as my first introduction to the quantum world a few years ago. I remember quite liking it. Very digestible as an introductory text.
If you're already very adept at QM, you could probably skip ahead quite a bit, but I can't speak to the second half of the text personally.
Upvote 1 Downvote Reply Award Share
Report
Award
Share
People also ask about section
People also ask about
Best books on quantum computing
Current state of quantum computing
Key experiments that shaped quantum mechanics
How quantum superposition affects technology
How to calculate quantum probabilities
More posts you may like
Related posts
cross-government quantum programs to include both annealing and gate-model quantum Computing r/QBTSstock • 2mo ago [
cross-government quantum programs to include both annealing and gate-model quantum Computing
](https://www.reddit.com/r/QBTSstock/comments/1slmjqd/crossgovernment_quantum_programs_to_include_both/)  42 upvotes · 6 comments
Why isn't quantum computing seen as a serious risk to how traditional finance works today? r/bitcoin_com • 24d ago [
Why isn't quantum computing seen as a serious risk to how traditional finance works today?
](https://www.reddit.com/r/bitcoin_com/comments/1t86ab3/why_isnt_quantum_computing_seen_as_a_serious_risk/)  102 upvotes · 27 comments
A level phy past papers r/TeenPakistani • 10mo ago [
A level phy past papers
](https://www.reddit.com/r/TeenPakistani/comments/1m7wggk/a_level_phy_past_papers/) 2 upvotes · 1 comment
Quantum computing feels like where AI was 10 years ago r/Techyshala • 14d ago [
Quantum computing feels like where AI was 10 years ago
](https://www.reddit.com/r/Techyshala/comments/1tif3hg/quantum_computing_feels_like_where_ai_was_10/) 21 upvotes · 28 comments
Physics book for neet 2026 r/MEDICOreTARDS • 1y ago [
Physics book for neet 2026
](https://www.reddit.com/r/MEDICOreTARDS/comments/1ltomk2/physics_book_for_neet_2026/) 2 upvotes · 19 comments
A University Of Pittsburgh Physicist Just Proved That Several Major Quantum Computing Breakthroughs Were Misinterpreted, And It Took Two Years And A Fight With Scientific Journals To Get Anyone To Listen 🤖⚡ r/InterstellarKinetics • 2mo ago [
A University Of Pittsburgh Physicist Just Proved That Several Major Quantum Computing Breakthroughs Were Misinterpreted, And It Took Two Years And A Fight With Scientific Journals To Get Anyone To Listen 🤖⚡
](https://www.reddit.com/r/InterstellarKinetics/comments/1s713fx/a_university_of_pittsburgh_physicist_just_proved/)  sciencedaily 1.3K upvotes · 26 comments
Scientists solved a major quantum physics problem once thought impossible for classical computers r/QBTSstock • 9d ago [
Scientists solved a major quantum physics problem once thought impossible for classical computers
](https://www.reddit.com/r/QBTSstock/comments/1tmz3hv/scientists_solved_a_major_quantum_physics_problem/)  earth 34 upvotes · 9 comments
A Beginners Guide to Quantum Computational Chemistry and its visualization r/comp_chem • 1y ago [
A Beginners Guide to Quantum Computational Chemistry and its visualization
](https://www.reddit.com/r/comp_chem/comments/1lotsqw/a_beginners_guide_to_quantum_computational/) 30 upvotes · 10 comments
The first lesson every undergraduate gets when learning about quantum physics r/chemistrymemes • 7mo ago [
The first lesson every undergraduate gets when learning about quantum physics
](https://www.reddit.com/r/chemistrymemes/comments/1ocnwfi/the_first_lesson_every_undergraduate_gets_when/) 144 upvotes · 7 comments
Chance me for Quantum Engineering r/gradadmissions • 1y ago [
Chance me for Quantum Engineering
](https://www.reddit.com/r/gradadmissions/comments/1lgdo89/chance_me_for_quantum_engineering/) 1 comment
Top three Quantum Computing books you've ever read? r/QuantumComputing • 2y ago [
Top three Quantum Computing books you've ever read?
](https://www.reddit.com/r/QuantumComputing/comments/1apd32t/top_three_quantum_computing_books_youve_ever_read/) 47 upvotes · 22 comments
Rational quantum mechanics: Testing quantum theory with quantum computers r/computerscience • 13d ago [
Rational quantum mechanics: Testing quantum theory with quantum computers
](https://www.reddit.com/r/computerscience/comments/1tjc402/rational_quantum_mechanics_testing_quantum_theory/) 7 upvotes · 7 comments
Quantum Chemistry book recommendation r/chemistry • 17y ago [
Quantum Chemistry book recommendation
](https://www.reddit.com/r/chemistry/comments/b0pfc/quantum_chemistry_book_recommendation/) 9 upvotes · 9 comments
Mastering the Fundamentals of Scattering Theory in Quantum Mechanics: The Step Potential r/learnphysics • 27d ago [
Mastering the Fundamentals of Scattering Theory in Quantum Mechanics: The Step Potential
](https://www.reddit.com/r/learnphysics/comments/1t5bog9/mastering_the_fundamentals_of_scattering_theory/)  5 88 upvotes · 6 comments
In 2026, Quantum Computers Will Reach a New Level r/Futurology • 5mo ago [
In 2026, Quantum Computers Will Reach a New Level
](https://www.reddit.com/r/Futurology/comments/1puk652/in_2026_quantum_computers_will_reach_a_new_level/)  ieee 142 upvotes · 53 comments
Recommendation for Quantum Computing textbook r/QuantumComputing • 3y ago [
Recommendation for Quantum Computing textbook
](https://www.reddit.com/r/QuantumComputing/comments/172v9h7/recommendation_for_quantum_computing_textbook/) 7 upvotes · 9 comments
Introduction Books for Quantum Computing r/QuantumComputing • 3y ago [
Introduction Books for Quantum Computing
](https://www.reddit.com/r/QuantumComputing/comments/152lzsl/introduction_books_for_quantum_computing/) 17 upvotes · 8 comments
Books for quantum chemistry r/chemistry • 5y ago [
Books for quantum chemistry
](https://www.reddit.com/r/chemistry/comments/mq6yl9/books_for_quantum_chemistry/) 1 upvote · 3 comments
What is Quantum Chemistry? r/chemistry • 5y ago [
What is Quantum Chemistry?
](https://www.reddit.com/r/chemistry/comments/pt26qx/what_is_quantum_chemistry/) 190 upvotes · 68 comments
Quantum Computing Built An Impossible Molecule — With Big Implications r/technology • 2mo ago [
Quantum Computing Built An Impossible Molecule — With Big Implications
](https://www.reddit.com/r/technology/comments/1s9f26g/quantum_computing_built_an_impossible_molecule/)  forbes 303 upvotes · 115 comments
Took me a decade to make quantum computing intuitive r/Simulate • 25d ago [
Took me a decade to make quantum computing intuitive
](https://www.reddit.com/r/Simulate/comments/1t76xfz/took_me_a_decade_to_make_quantum_computing/)  9 28 upvotes · 6 comments
Best Quantum Chemistry textbook for a student with little background in math/physics r/chemistry • 7y ago [
Best Quantum Chemistry textbook for a student with little background in math/physics
](https://www.reddit.com/r/chemistry/comments/b2n921/best_quantum_chemistry_textbook_for_a_student/) 1 upvote · 7 comments
New Book: Intro to Quantum Computing for Computer Engineers r/quantum • 8mo ago [
New Book: Intro to Quantum Computing for Computer Engineers
](https://www.reddit.com/r/quantum/comments/1o7r4ap/new_book_intro_to_quantum_computing_for_computer/) 42 upvotes · 9 comments
In 2026, Quantum Computers Will Reach a New Level r/QuantumComputing • 5mo ago [
In 2026, Quantum Computers Will Reach a New Level
](https://www.reddit.com/r/QuantumComputing/comments/1ptugkm/in_2026_quantum_computers_will_reach_a_new_level/)  ieee 36 upvotes · 9 comments
TIL about Post-Quantum Cryptography, a set of new mathematical standards designed to protect data from Quantum Computers, which will eventually be powerful enough to crack the encryption currently used for everything from bank transfers to private messaging. r/todayilearned • 2mo ago [
TIL about Post-Quantum Cryptography, a set of new mathematical standards designed to protect data from Quantum Computers, which will eventually be powerful enough to crack the encryption currently used for everything from bank transfers to private messaging.
](https://www.reddit.com/r/todayilearned/comments/1rzdwt6/til_about_postquantum_cryptography_a_set_of_new/) 408 upvotes · 44 comments
View Post in
Русский
Português (Brasil)
Français
See more See fewer
Español (Latinoamérica)
Italiano
Community Info Section
r/quantum
Join
Quantum Mechanics - Physics Community
Scientific discourse about quantum mechanics and related fields. Not for discussions about interpretations or speculative theories.
Show more
Public
Anyone can view, post, and comment to this community
Top Posts
Reddit reReddit: Top posts of September 1, 2025
Reddit reReddit: Top posts of September 2025
Reddit reReddit: Top posts of 2025
Home
Popular
News
Explore
Best of Reddit
Best of Reddit in Portuguese
Best of Reddit in German
Reddit Rules
Privacy Policy
User Agreement
Your Privacy Choices
Accessibility
Reddit, Inc. © 2026. All rights reserved. 
Search real takes on every topic
Continue with Apple
 Sign in with Apple
Continue with Phone Number
Continue with Email
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy. 
0cAFcWeA6tJw02jhsCPH_Sa8GrqRJoGmeZmd6tYzYVyL8DMaxMRz6ruLN7kL77Mh9hy6xL8S8IxIRuIvjyecvSrZz-TN-JLYpv7sDp_VsJsKMPlECHC0wbXbGmR0Mz_9kKZf_QQUynxjRdkb8dRtiAqCTntoxedZo0GP_w3PW7odnSNYNFjYCTsP6pfOZJ3Zxdp6lViGNK3XZn0obby1wwC-AlVqXhVVabWdbEHk4LFSiw0aePDtJyVQAZnJfT_sYDx0LUzqC7E7pk_9bycG2MaZQDU0YpYsWWemisxSUhWDCKr5cZkcWwkpE7FLN59qtNbkzSP4AvKYSD0iAJKOkRyC6MyRVhUIxj5Wg856BlsaEjbMv3zYk21dkao7LVS-ahz9Zu-Lsy3CKTTp_FdE0lciGZSdcM7tyOXfhgR-Do63CydQuBUZ8XF71VWkeLgUgkIN_48_qQ35Vht7K08DGFagkDWLM9eO2jcMk0FvMqhP7-YK777rzkWiISaiN9LDQKaRdOc3P6hrHN_gtxJVOBX-u1hOh9CotCOnkzGnlaN96opapE5qA7mKEStjus1_7zeyN1M24fELZfQSoRlQHxyyjRPPDzqEzJgAhpL5VWqZIA9rgokuvIkwH7tihhz75q_OTiiMJ5TftOazmRb-x45v5fpELq48I-lBR78KZZflcxsMS6IeXzLskwxcjwFclJ6rtq2KgvDTik4fWOcYNsuVYqLpbNEK0kYDQWk-uhkKWkxsGpnvrK5npgbzk8lNoJRL0nOI7ZdFrnbzrhNBIiwedXdigkWCMulNXvP7Wq7A-th_3YGCztdvguqj22R0Z4crJbR7e5XXXsk3tCrAL5fKtOXIPBxgycj63nNxhbjPGBtrT1YBK_NSTpSMRxygyjiQhyvROofEc68u-D4KfMPCIIbDsxoDM7hCcNWUJB6IvtLx1oz_P0RScbYd1qlcZLMOyFvV4gxVIEz6Y99r_BgH0JXVBU6eltIYwpqEePRLfjuY56K9mOXXl7JcryQgUSdF0ccsSuXdi8cK1nVQqxAd9jJM02oSGp2YkEv-cAoHGy32wGqhIOZOy5WnASUYrIzfr8JAUSNQze70_RWFgipUBPUe1QzYJkwg3DCIkpSEjTNuj788l2ehRb-SapIAK6ZXeVBWRC21JYWlXQhAQ5FOw8kvkIgOSQSoNORmLsQgZvlsP6QoWVzqb95sYPIalpNAlFaBadZz51Z1WP3vhmJmuVOHcSYRyS_3skkmvuQdssXdzjSlS-aEajWQvEw4PNpwcYD2QlHoR8nsOuyeCs7EXxqEwsBoKqbeNbljEnk9gKI3FBAUlLOpqtFEbvLfcYC9FeT7KrNA2ZYTArwbxPCnrmXztjeizsa7whCtpouVPEEob4XRbVDFnHPx200seNsuFHWbSnp0B1DM_KBRrimoPd5BZE_Dke9LI9H5J2sk6OMv4-CMQEtsUx5uEz2TCKMk1rPogS_ei62-rfS9tWI3KlxwRKw2xkOtU6cDrtTEukwOLChH2dt_y8ImeZPSTHfZEqkDg4ytUWkFRVEVlR9xeT5lUrI9dOQdx0_VPNxnbI1KD7I3KiojgVy9bA5-WI4rR58reM3gbIpk33ZO-j6wtjBoZrEkOX1HV5HFnKB8b3qLj8bRfM8ZkHbK02l7OjVZ0ORNQgFCZqaTojG2c4s5bjgiVlE_lnj_RcbwoUxRFzNXB58DMyiuTEQrt-cUlLjDDyg7MECUZaGXpZkB9xWEVLiwDA5RuttOY4OXl5lmyubCTO86gXRS6tlpS2n9wCmy3IWB862PZ27S9jzc4mhS7YCb6_VPOZyB9x2GomR38W9xXG60BH9-L3kyVxdLWV5L0L5Y7bq-lYiL5Ni-xMUgXCeLJX-LVkTHiB5dY8jNuWcGjmjfzP7WTBzGC0bMlcSvKZsy8YMjvx8QZmtH0xUpm4g3cFBC02hVsivE3ImL6Ur-FlSgcVj1IW97U8YhjxGxiaSdtiXtSprYaSQWEUTdBGirqwp9kMIoDRZq0AuDXixLdInVD4Px78_LURsjl9THMCb9WcvW0PMP7Xg8fwV6dgHW_hsR5Da2xDtO4dO7XQeAyzNjQN4Ip-SVbT2QhxFahkOvulR3RnEU47qDrIkJKuVLD-LVr9OAYG9_cFKWhDkCklT9Y