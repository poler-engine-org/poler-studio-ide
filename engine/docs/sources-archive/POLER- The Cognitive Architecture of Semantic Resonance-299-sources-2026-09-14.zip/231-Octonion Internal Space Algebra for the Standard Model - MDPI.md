> Source: https://www.mdpi.com/2218-1997/9/5/222

Octonion Internal Space Algebra for the Standard Model
Loading web-font Gyre-Pagella/DoubleStruck/Regular
Next Article in Journal
Killing Horizons and Surface Gravities for a Well-Behaved Three-Function Generalization of the Kerr Spacetime
Previous Article in Journal
CMB Power Spectrum in the Emergent Universe with K-Essence
Journals
Active Journals Find a Journal Journal Proposal Proceedings Series
[
Topics
](https://www.mdpi.com/topics)
Information
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
Open Access Policy Institutional Open Access Program Special Issues Guidelines Editorial Process Research and Publication Ethics Article Processing Charges Awards Testimonials
[
Author Services
](https://www.mdpi.com/authors/english)
Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
About
Overview Contact Careers News Press Blog
Sign In / Sign Up
Notice
You can make submissions to other journals here.
clear
Notice
You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.
Continue Cancel
clear
All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to https://www.mdpi.com/openaccess.
Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.
Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.
Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.
Original Submission Date Received: .
You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled. 
clear zoom_out_map search menu 
Journals
Active Journals
Find a Journal
Journal Proposal
Proceedings Series
Topics
Information
For Authors
For Reviewers
For Editors
For Librarians
For Publishers
For Societies
For Conference Organizers
Open Access Policy
Institutional Open Access Program
Special Issues Guidelines
Editorial Process
Research and Publication Ethics
Article Processing Charges
Awards
Testimonials
Author Services
Initiatives
Sciforum
MDPI Books
Preprints.org
Scilit
SciProfiles
Encyclopedia
JAMS
Proceedings Series
About
Overview
Contact
Careers
News
Press
Blog
Sign In / Sign Up Submit
error_outline You can access the new MDPI.com website here. Explore and share your feedback with us. close
Search for Articles:
Title / Keyword
Author / Affiliation / Email
Journal
All Journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica (AMH)
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine (ARM)
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation (ASI)
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing (BDCC)
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C (Journal of Carbon Research)
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies (Clean Technol.)
Climate
Clinical and Translational Neuroscience (CTN)
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation (CMD)
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction (CMTR)
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology (CIMB)
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates (DDC)
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications (ESA)
Eng
Engineering Proceedings
Entropic and Disordered Matter (EDM)
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal (EBJ)
European Journal of Investigation in Health, Psychology and Education (EJIHPE)
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional (Fractal Fract)
Fuels
Future
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease (GUCDD)
Grasses
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences (IJCS)
International Journal of Environmental Medicine (IJEM)
International Journal of Environmental Research and Public Health (IJERPH)
International Journal of Financial Studies (IJFS)
International Journal of Molecular Sciences (IJMS)
International Journal of Neonatal Screening (IJNS)
International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)
International Journal of Plant Biology (IJPB)
International Journal of Topology
International Journal of Translational Medicine (IJTM)
International Journal of Turbomachinery, Propulsion and Power (IJTPP)
International Medical Education (IME)
Inventions
IoT
ISPRS International Journal of Geo-Information (IJGI)
J
Journal of Aesthetic Medicine (J. Aesthetic Med.)
Journal of Ageing and Longevity (JAL)
Journal of CardioRenal Medicine (JCRM)
Journal of Cardiovascular Development and Disease (JCDD)
Journal of Clinical & Translational Ophthalmology (JCTO)
Journal of Clinical Medicine (JCM)
Journal of Composites Science (J. Compos. Sci.)
Journal of Cybersecurity and Privacy (JCP)
Journal of Dementia and Alzheimer's Disease (JDAD)
Journal of Developmental Biology (JDB)
Journal of Experimental and Theoretical Analyses (JETA)
Journal of Eye Movement Research (JEMR)
Journal of Functional Biomaterials (JFB)
Journal of Functional Morphology and Kinesiology (JFMK)
Journal of Fungi (JoF)
Journal of Gerontology and Geriatrics (JGG)
Journal of Imaging (J. Imaging)
Journal of Innovation
Journal of Intelligence (J. Intell.)
Journal of Interdisciplinary Research Applied to Medicine (JDReAM)
Journal of Low Power Electronics and Applications (JLPEA)
Journal of Manufacturing and Materials Processing (JMMP)
Journal of Marine Science and Engineering (JMSE)
Journal of Market Access & Health Policy (JMAHP)
Journal of Mind and Medical Sciences (JMMS)
Journal of Molecular Pathology (JMP)
Journal of Nanotheranostics (JNT)
Journal of Nuclear Engineering (JNE)
Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)
Journal of Parks
Journal of Personalized Medicine (JPM)
Journal of Pharmaceutical and BioTech Industry (JPBI)
Journal of Phytomedicine
Journal of Respiration (JoR)
Journal of Risk and Financial Management (JRFM)
Journal of Sensor and Actuator Networks (JSAN)
Journal of the American Podiatric Medical Association (JAPMA)
Journal of the Oman Medical Association (JOMA)
Journal of Theoretical and Applied Electronic Commerce Research (JTAER)
Journal of Vascular Diseases (JVD)
Journal of Xenobiotics (JoX)
Journal of Zoological and Botanical Gardens (JZBG)
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction (MAKE)
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications (MCA)
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols (MPs)
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction (MTI)
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA (ncRNA)
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science (QuBS)
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics (RSEE)
Religions
Remote Sensing
Reports
Reproductive Medicine (Reprod. Med.)
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine (RJPM)
Ruminants
Safety
Sci
Scientia Pharmaceutica (Sci. Pharm.)
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal (SIUJ)
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease (TropicalMed)
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Wild
Wind
Women
World
World Electric Vehicle Journal (WEVJ)
Youth
Zoonotic Diseases
Universe
Article Type
All Article Types
Article
Review
Communication
Editorial
Abstract
Book Review
Brief Communication
Brief Report
Case Report
Clinicopathological Challenge
Comment
Commentary
Concept Paper
Conference Report
Correction
Creative
Data Descriptor
Discussion
Entry
Essay
Expression of Concern
Extended Abstract
Field Guide
Giants in Urology
Guidelines
Hypothesis
Interesting Images
Letter
New Book Received
Obituary
Opinion
Patent Summary
Perspective
Proceeding Paper
Project Report
Protocol
Registered Report
Reply
Retraction
Short Note
Study Protocol
Systematic Review
Technical Note
Tutorial
Urology around the World
Viewpoint
All Article Types Search
Advanced Search
Section
All Sections
Astroinformatics and Astrostatistics
Astronomy & Astrophysics
Compact Objects
Cosmology
Field Theory
Foundations of Quantum Mechanics and Quantum Gravity
Galaxies and Clusters
Gravitation
High Energy Nuclear and Particle Physics
Mathematical Physics
Planetary Sciences
Solar and Stellar Physics
Space Science
Universe Letters
General
All Sections
Special Issue
All Special Issues
100 Years of Chronogeometrodynamics: the Status of the Einstein's Theory of Gravitation in Its Centennial Year
10th Anniversary of
Universe:
Galaxies and Their Black Holes
Accretion Disks, Jets, Gamma-Ray Bursts and Related Gravitational Waves
Advances in Astrophysics and Cosmology – in Memory of Prof. Tan Lu
Advances in Understanding Astrophysical and Atomic Phenomena
Beyond Riemannian Geometry in Classical and Quantum Gravity
BGL2017: 10th Bolyai-Gauss-Lobachevsky Conference on Non-Euclidean Geometry and Its Applications
BGL2025: The 13th Bolyai–Gauss–Lobachevsky Conference on Non-Euclidean Geometry and Its Applications
Black Hole Physics and Astrophysics
Black Hole Thermodynamics
Compact Stars in the QCD Phase Diagram
Compact Stars in the QCD Phase Diagram and in the Multi-Messenger Era of Astronomy
CP Violation in the Universe
Current Trends in Neutrino Oscillation Physics: A Phenomenological and Experimental Perspective
Estate Quantistica Conference - Recent Developments in Gravity, Cosmology, and Mathematical Physics
Experimental and Observational Constraints on Wormhole Models
F(R) Gravity
Frontiers in Astroparticle Physics and Particle Cosmology
Gravitational Lensing and Astrometry
Gravitational Lensing and Optical Geometry: A Centennial Perspective
Gravity, Black Holes and Cosmology XXI
H0 Tension: New Physics or Systematics?
Heavy-Ion Physics
Higher Spin Gauge Theories
Inflation, Black Holes and Gravitational Waves
Inflationary Universe Models: Predictions and Observations
Interplay of QCD, Cosmology and Astroparticle Physics
Italian Research Facilities for Fundamental Physics
LCDM Cosmology: Pros and Cons
Loop Quantum Cosmology and Quantum Black Holes
Loop Quantum Gravity and Non-Perturbative Approaches to Quantum Cosmology
Modified Gravity Cosmology: From Inflation to Dark Energy
Modified Theories of Gravity and Cosmological Applications
Neutron Star Astrophysics
New Insights into Astronomy and Earth Observations: From Observations to the Theory
New Insights into High-Energy Astrophysics, Galaxies, and Cosmology—Celebrating the 10th Anniversary of the Re-establishment of the Department of Astronomy at Xiamen University (2012–2022)
New Trends in High-Energy Physics
Observing Gravitational Lenses: Present and Future
On the Detection and Evolution of Solar Coronal Holes
Organic Matter in the Solar System: Pathways from Interstellar Matter to Insurgence of Life
Origin of the Universe
Origin, Evolution, Distribution, and Future of Life in the Universe
Particle Physics and Cosmology: A Themed Issue in Honor of Professor Dimitri Nanopoulos
Probing New Physics with Black Holes
Progress in Cosmology in the Centenary of the 1917 Einstein Paper
Progress in Group Field Theory and Related Quantum Gravity Formalisms
Pulsars Astrophysics
Quantum Dynamics and Applications
Quantum Field Theory, Gravity and the Dark Universe
Quantum Fields – From Fundamental Concepts to Phenomenological Questions
Quantum Spacetime and Quantum Relativity
Quark-Gluon Plasma in the Early Universe and in Ultra-Relativistic Heavy-Ion Collisions
Recent Advances and Current Trends in Gravitational Waves
Recent Progress in Relativistic Astrophysics
Remo Ruffini Festschrift
Researches on N = 4 SYM Theory
Rotation Effects in Relativity
Selected Papers from José Plínio Baptista School on Cosmology “The dark sector of the universe”
Selected Papers from Teleparallel Universes in Salamanca
Selected Papers from the 17th Russian Gravitational Conference —International Conference on Gravitation, Cosmology and Astrophysics (RUSGRAV-17)
Selected Papers from the 1st International Electronic Conference on Universe (ECU 2021)
Selected Papers from the 2nd International Electronic Conference on Universe (ECU 2023)
Selected Papers from the 3rd International Online Conference on Universe (IOCU 2026)
Selected Papers from the 71st International Astronautical Congress 2020 (Space and Astrophysics Section)
Selected Papers from the 7th International Conference on New Frontiers in Physics (ICNFP 2018)
Seyfert Galaxies Astrophysics
Solar Wind Turbulence: New Advances from the Parker Solar Probe and Solar Orbiter Space Missions
Space-Borne Gravitational Wave Antennas
Spontaneous Breaking of Conformal Symmetry
String Theory and Particle Physics: A Themed Issue in Honor of Professor Ignatios Antoniadis on the Occasion of His 70th Birthday
Studying the Universe from Spain
Super Geometry for Super Strings
Supersymmetric Cosmology and String Landscape
Supersymmetric Quantum Theory
The Advance of Astronomy and Astrophysics in The Netherlands
The Cosmological Constant Puzzle
The Languages of Physics—A Themed Issue in Honor of Professor Richard Kerner on the Occasion of His 80th Birthday
The Multiverse
The Zimányi School and Analytic Hydrodynamics in High Energy Physics
Theories of Gravity: Alternatives to the Cosmological and Particle Standard Models
Ultralight Bosonic Dark Matter: Theoretical Developments and Experimental Searches
Universe: 5th Anniversary
Universe: Feature Papers 2018 - Gravitational Physics
Universe: Feature Papers 2019 - Gravitational Physics
Varying Constants and Fundamental Cosmology
Women Physicists in Astrophysics, Cosmology and Particle Physics
Wormholes in Space-Time: Theory and Facts
All Special Issues
Volume 9
Issue 5
Number
Page
Logical Operator Operator
AND
OR
Search Text
Search Type
All fields
Title
Abstract
Keywords
Authors
Affiliations
Doi
Full Text
References
add_circle_outline
remove_circle_outline Search
Journals
Universe
Volume 9
Issue 5
10.3390/universe9050222
Submit to this Journal Review for this Journal Propose a Special Issue
► ▼ Article Menu
Article Menu
Academic Editor Lorenzo Iorio
Recommended Articles
Related Info Link
Google Scholar
More by Author Links
on DOAJ
Todorov, I.
on Google Scholar
Todorov, I.
on PubMed
Todorov, I.
Article Views 2867
Citations 8
Table of Contents
Abstract
Introduction
Triality Realization of Spin ( 8 ) : C ℓ − 6
The Internal Space Subalgebra of C ℓ 10
Particle Subspace and the Higgs Field
Outlook
Funding
Data Availability Statement
Acknowledgments
Conflicts of Interest
Appendix A
Notes
References
Altmetric share Share announcement Help format_quote Cite question_answer Discuss in SciProfiles
Need Help?
Support
Find support for a specific problem in the support section of our website.
Get Support
Feedback
Please let us know what you think of our products and services.
Give Feedback
Information
Visit our dedicated information section to learn more about MDPI.
Get Information
clear
JSmol Viewer
clear
first_page
Download PDF
settings
Order Article Reprints
Font Type:
Arial Georgia Verdana
Font Size:
Aa Aa Aa
Line Spacing:
  
Column Width:
  
Background:
Open Access Article
Octonion Internal Space Algebra for the Standard Model †
by
Ivan Todorov 
Ivan Todorov
SciProfiles Scilit Preprints.org Google Scholar ‡ 
Institut des Hautes Études Scientifiques, 35 Route de Chartres, 91440 Bures-sur-Yvette, France †
Extended version of a lecture presented at the Workshop Octonions and the Standard Model, Perimeter Institute, Waterloo, ON, Canada, 8 February–17 May 2021, and at the 14th International Workshop Lie Theory and Its Applications to Physics (LT 14), Sofia, Bulgaria, 20–26 June 2021. ‡
Permanent address: Institute for Nuclear Research and Nuclear Energy, Bulgarian Academy of Sciences, Tsarigradsko Chaussee 72, 1784 Sofia, Bulgaria.
Universe 2023, 9(5), 222; https://doi.org/10.3390/universe9050222
Submission received: 17 February 2023 / Revised: 7 April 2023 / Accepted: 20 April 2023 / Published: 6 May 2023
(This article belongs to the Section Mathematical Physics)
Download keyboard_arrow_down
Download PDF
Download PDF with Cover
Download XML
Download Epub
Versions Notes
Article Views
Citations -
Abstract
This paper surveys recent progress in our search for an appropriate internal space algebra for the standard model (SM) of particle physics. After a brief review of the existing approaches, we start with the Clifford algebras involving operators of left multiplication by octonions. A central role is played by a distinguished complex structure that implements the splitting of the octonions O = C ⊕ C 3 , which reflect the lepton-quark symmetry. Such a complex structure on the 32-dimensional space S of C ℓ 10 Majorana spinors is generated by the C ℓ 6 ( ⊂ C ℓ 10 ) volume form, ω 6 = γ 1 ⋯ γ 6 , and is left invariant by the Pati–Salam subgroup of S p i n ( 10 ) , G PS = S p i n ( 4 ) × S p i n ( 6 ) / Z 2 . While the S p i n ( 10 ) invariant volume form ω 10 = γ 1 … γ 10 of C ℓ 10 is known to split S on a complex basis into left and right chiral (semi)spinors, P = 1 2 ( 1 − i ω 6 ) is interpreted as the projector on the 16-dimensional particle subspace (which annihilates the antiparticles).The standard model gauge group appears as the subgroup of G PS that preserves the sterile neutrino (which is identified with the Fock vacuum). The Z 2 -graded internal space algebra A is then included in the projected tensor product A ⊂ P C ℓ 10 P = C ℓ 4 ⊗ C ℓ 6 0 . The Higgs field appears as the scalar term of a superconnection, an element of the odd part C ℓ 4 1 of the first factor. The fact that the projection of C ℓ 10 only involves the even part C ℓ 6 0 of the second factor guarantees that the color symmetry remains unbroken. As an application, we express the ratio m H m W of the Higgs to the W boson masses in terms of the cosine of the theoretical Weinberg angle.
Keywords:
Clifford algebra; composition algebra; triality; Jordan algebra; complex structure; superselection rules; Higgs mass; superconnection; fermion doubling
1. Introduction
The elaboration of the standard model (SM) of particle physics was completed in the early 1970s. To quote John Baez [ 1], “years trying to go beyond the Standard Model hasn't yet led to any clear success”. The present survey belongs to an equally long—albeit less fashionable—effort to clarify the algebraic (or geometric) roots of the SM or, more specifically, to find a natural framework featuring its internal space properties. After discussing some old explorations, we provide an updated exposition of recent developments (particularly, of [ 2]) while clarifying the meaning and role of complex structures, and we concentrate on one structure associated with a Clifford algebra (in our case, C ℓ 6 ) pseudoscalar.
Most ideas on the natural framework of the SM originate in the 1970s, the first decade of its existence (There are two exceptions: the Jordan algebras were introduced and classified in the 1930s [ 3, 4]; and the non-commutative geometry approach was born in the late 1980s [ 5, 6, 7] and is still vigorously developed by Connes and collaborators and followers [ 8, 9, 10, 11, 12]).
First, early in 1973, the ultimate division algebra, the octonions 1, were introduced by Gürsey 2 and his student Günaydin [ 14, 15] for the description of quarks and their S U ( 3 ) color symmetry. The idea was taken up and extended to incorporate all four division algebras by G. Dixon (see [ 16, 17] and the earlier work cited there) and was further developed by Furey [ 18, 19, 20, 21, 22, 23, 24]. Dubois-Violette (D-V) [ 25, 26] emphasizes the lepton-quark correspondence and unimodularity of the color group S U ( 3 ) c as a physical motivation for introducing the octonions; they come equipped with a complex structure preserved by subgroup S U ( 3 ) of the automorphism group G 2 of O :
O = C ⊕ C 3 .
(1)
1.1. (Split) Octonions as Composition Algebras
One can in fact provide a basis-free definition of the octonions, starting with the splitting ( 1). To this end, one uses the skew symmetric vector product and standard inner product on C 3 to define a non-commutative and non-associative distributive product x y on O and a real-valued, non-degenerate symmetric bilinear form 〈 x , y 〉 = 〈 y , x 〉 , such that the quadratic norm N ( x ) = 〈 x , x 〉 is multiplicative:
N ( x y ) = N ( x ) N ( y ) for N ( x ) = 〈 x , x 〉
(2)
(cf. [ 25, 27, 28]). Furthermore, by defining the real part of x ∈ O by Re x = 〈 x , 1 〉 and the octonionic conjugation by x → x * = 2 〈 x , 1 〉 − x , we have
x x * = N ( x ) 1 I ⇔ x 2 − 2 〈 x , 1 〉 x + N ( x ) 1 I = 0 .
(3)
A unital algebra with a non-degenerate quadratic norm obeying ( 2) is called a composition algebra.
Another basis-free definition of the octonions O and their split version O ˜ can be provided in terms of quaternions using the Cayley–Dickson construction. We represent the quaternion as scalars plus vectors
H = R ⊕ R 3 , x = u + U , y = v + V , u , v ∈ R , U , V ∈ R 3 ,
x y = u v − 〈 U , V 〉 + u V + U v + U × V
(4)
with the vector product U × V ∈ R 3 satisfying
U × V = − V × U , ( U × V ) × W = 〈 U , W 〉 V − 〈 V , W 〉 U .
(5)
The product ( 4) is clearly non-commutative, but one verifies that it is associative. The Cayley–Dickson construction defines the octonions O and split octonions O ˜ in terms of a pair of quaternions and a new “imaginary unit” ℓ is defined as:
x = u + U + ℓ ( v + V ) , ℓ ( v + V ) = ( v − V ) ℓ ,
ℓ 2 = − 1 ⇒ x ∈ O 1 ⇒ x ∈ O ˜ .
(6)
We shall encounter the split octonions as generators of C ℓ ( 4 , 2 ) in Section 3.1 below.
1.2. Jordan Algebras; Guts; Clifford Algebras
Studying quantum field theory, it appears natural to replace classical observables (real-valued functions) by an algebra of functions on space-time with values in a finite dimensional Euclidean Jordan algebra 3. As a particularly attractive choice that incorporates the idea of lepton-quark symmetry, D-V proposes [ 25] the exceptional Jordan or Albert algebra of 3 × 3 Hermitian octonionic matrices,
J 3 8 = H 3 ( O ) ,
(7)
which is the only irreducible one that does not admit an associative envelope [ 32]. Further progress was achieved in [ 27, 28, 30, 33, 34, 35] by considering the Clifford algebra envelope of its non-exceptional subalgebra J 2 8 , which fits one generation of fundamental fermions. In these papers, as well as in the present one, we are effectively working with associative algebras that should be viewed as an internal space counterpart of Haag's field algebra (see [ 36]).
A second development, grand unified theory (GUT), anticipated again in 1973 by Pati and Salam [ 37], became mainstream for a time 4. Fundamental chiral fermions fit the complex spinor representation of S p i n ( 10 ) , which was introduced as a GUT group by Fritzsch and Minkowski and by Georgi. A preferred symmetry breaking yields the maximal rank semisimple Pati–Salam subgroup
G PS = S p i n ( 4 ) × S p i n ( 6 ) Z 2 ⊂ S p i n ( 10 ) ,
S p i n ( 4 ) = S U ( 2 ) L × S U ( 2 ) R , S p i n ( 6 ) = S U ( 4 ) .
(8)
We note that G PS is the only GUT group that does not predict a gauge triggered proton decay; it is also encountered in the non-commutative geometry approach to the SM [ 8, 10]. In general, GUTs provide a nice home for the fundamental fermions, as displayed by the two 16-dimensional complex conjugate “Weyl spinors” of S p i n ( 10 ) . Their other representations, however, such as the 45-dimensional adjoint representation of S p i n ( 10 ) , are much too big and involve hypothetical particles such as lepto-quarks which cause difficulties.
The Clifford algebra 5 C ℓ 10 , on the other hand, like the Clifford algebra of any even-dimensional Euclidean vector space, has a unique irreducible representation (IR); in the case of 6 C ℓ 10 ≅ R [ 2 5 ] , it is the 32-component real (Majorana) spinor. Viewed as a representation of S p i n ( 10 ) , it splits upon complexification into two 16-dimensional (complex) IRs that can be naturally associated to the left and right chiral fundamental (anti)fermions of one generation:
32 = 16 L + 16 R .
(9)
Clifford algebras were also applied to the SM in the 1970s—see [ 40] and the references therein. An essential difference in our approach is the use of octonions with a preferred complex structure in C ℓ 8 + ν , ν = 0 , 1 , 2 to restrict the corresponding gauge group (another new point, the use of the Z 2 grading of C ℓ 10 to define the Higgs field, will be discussed in Section 1.3 below).
The Pati–Salam subgroup of S p i n ( 10 ) is singled out as the stabilizer of the C ℓ 6 ( ⊂ C ℓ 8 ⊂ C ℓ 10 ) pseudoscalar
ω 6 = γ 1 … γ 6 for γ α = σ 0 ⊗ ϵ ⊗ L α , γ 8 = σ 0 ⊗ σ 1 ⊗ 1 I 8 ( ∈ C ℓ 10 ) ,
σ 0 = 1 I 2 , ϵ = i σ 2 , L α = L e α , [ L α , L β ] + = − 2 δ α β 1 I 8 , α , β = 1 , ⋯ , 7 .
(10)
Here, L x is the operator of left multiplication in the eight-dimensional real vector space of the octonions, L x y = x y for x , y ∈ O . The action of the operators L α ∈ R [ 8 ] on the octonion units will be made explicit in Section 2.2 (Equation ( 22)). The group G PS ( 8) in fact preserves each factor in the graded tensor product representation of C ℓ 10 :
C ℓ 10 = C ℓ 4 ⊗ ^ C ℓ 6
(11)
Introduced earlier by Furey [ 20, 21] and exploited in [ 2], the complex structure J ∈ S O ( 10 ) generated by ω 6 will be displayed, and the physical interpretation of the mutually orthogonal projection operators
P = 1 2 ( 1 − i ω 6 ) , P ′ = 1 2 ( 1 + i ω 6 )
(12)
will be revealed in Section 2.3.
1.3. Main Message and Organization of the Paper
The present survey focuses on ongoing attempts to answer two questions:
(1) Why is the arbitrarily looking gauge group of the SM
G SM = S ( U ( 2 ) × U ( 3 ) ) = S U ( 2 ) × S U ( 3 ) × U ( 1 ) Z 6 ,
(13)
and what dictates its highly reducible representation for fundamental fermions?
(2) How do we put together the Higgs field with the gauge bosons? Can we explain their mass ratios?
Most physicists accept GUT as an answer to the first question. One has the intriguing result of Baez and Huerta [ 38], where G SM appears as the intersection of two popular GUT subgroups of S p i n ( 10 ) :
G SM = S U ( 5 ) ∩ G PS ⊂ S p i n ( 10 ) .
A top-down approach starting with S p i n ( 10 ) , however, should involve the maximal rank subgroup U ( 5 ) instead of S U ( 5 ) , in line with the philosophy of Borel-de Siebenthal [ 41], yielding an extra U ( 1 ) factor in the intersection.
The minority that are trying to go further includes, besides the fans of octonions and the already cited enthusiasts of almost commutative real spectral triples, Holger Nielsen, whose more than two decades of musing over the problem are reviewed in [ 42]. Our approach exploits the complex structure and particle projector P ( 12) associated with the Clifford pseudoscalar ω 6 ( 10); it permeates the entire paper ( Section 2.3, Section 3.2, Section 3.3, Section 3.4 and Section 5.1…).
The second problem has been universally recognized (see, e.g., the popular account [ 43]). We follow the superconnection approach anticipated by Ne'eman and Fairlie—for a concise review and references, see Section 4.1. We exploit the restricted particle projector P r , which annihilates the sterile neutrino ( Section 3.3) to deform the Fermi oscillators in the lepton sector into the odd generators of the simple Lie superalgebra postulated in [ 44, 45]. The resulting difference between the flavor spaces of leptons and colored quarks allows one to compute the mass ratio m H / m W in agreement with the experiment ( Section 4.2).
The paper aims to be self-contained and combines our contribution in a single narrative with a review of the background material. Section 2.1 provides a summary of the known triality realization of S p i n ( 8 ) . Section 2.2 and Appendix A spell out the relation between left and right multiplication using imaginary octonion units, which is applied in Section 3.4 to display the stabilizer of R 7 . We would like to single out two messages from Section 2.3: (1) the indirect connection between the C ℓ 6 pseudoscalar and the complex structure J ∈ S O ( 8 ) ( 33) and ( 35); (2) the observation that the Lie subalgebra of s o ( 8 ) that commutes with ω 6 and the electric charge operator Q ( 45) is the rank four subalgebra s u ( 3 ) c ⊕ u ( 1 ) Q ⊕ u ( 1 ) B − L . Section 3.1 contains, along with a glance on the equivalence class of Clifford algebras involving C ℓ ( 3 , 1 ) , C ℓ − 6 ( = C ℓ ( 0 , 6 ) ) , C ℓ 10 , the observation that the conformal Clifford algebra C ℓ ( 4 , 2 ) of this class is generated by the split octonions and gives rise to their isometry group S O ( 4 , 4 ) . Section 3.2 contains one of the main messages of the paper: the SM gauge group ( 13) is the subgroup of G PS ( 8) that leaves the sterile neutrino invariant (Proposition 1). Section 3.3 discusses superselection rules and the superselection of the weak hypercharge. Section 3.4 reviews and comments on recent work [ 24, 46] on the complex structure associated with the right action of octonion units as well as the derivation of the gauge group for the SM [ 35] and its left-right symmetric extension [ 47].
The Dirac operator γ μ ( ∂ μ + A μ ) anticommutes with the chirality γ 5 and hence intertwines the left and right fermions; so does the Higgs field, which substitutes a mass term in the fermionic Lagrangian. This inspired Connes and coworkers [ 5, 6, 9] to identify the Higgs field with the internal space part of the Dirac operator. This idea finds a natural implementation in the Clifford algebra approach for the SM superconnection (reviewed in Section 4.1). The concise exposition in Section 4 emphasizes our assumptions and some delicate points, referring the reader for calculational details to the preceding publication [ 2].
We recapitulate our convoluted route to C ℓ 10 in Section 5.1. In Section 5.2, we compare our solution of the fermion doubling problem with the approach of [ 23]. A summary of the main results of the paper is given in Section 5.3, which also cites existing (inconclusive) attempts to understand why are there exactly three generations of fundamental fermions.
2. Triality Realization of Spin ( 8 ) : C ℓ − 6
2.1. The Action of Octonions on Themselves
The group S p i n ( 8 ) , the double cover of the orthogonal group S O ( 8 ) = S O ( O ) , can be defined (see [ 48, 49]) as the set of triples ( g 1 , g 2 , g 3 ) ∈ S O ( 8 ) × S O ( 8 ) × S O ( 8 ) such that
g 2 ( x y ) = g 1 ( x ) g 3 ( y ) for any x , y ∈ O .
(14)
If u is a unit octonion, u * u = 1 ; then, the left and right multiplications by u are examples of isometries of O
| L u x | 2 = 〈 u x , u x 〉 = 〈 x , x 〉 , | R u x | 2 = 〈 x u , x u 〉 = 〈 x , x 〉 for 〈 u , u 〉 = 1 .
(15)
Using the Moufang identity, 7
u ( x y ) u = ( u x ) ( y u ) for any x , y , u ∈ O ,
(16)
One verifies that the triple g 1 = L u , g 2 = L u R u , g 3 = R u satisfies ( 14) and hence belongs to S p i n ( 8 ) . It turns out that triples of this type generate S p i n ( 8 ) (see [ 48] or Yokota's book [ 49] for a proof).
The mappings x → L x and x → R x are, of course, not algebra homomorphisms, as L x and R y each generate an associative algebra, while the algebra of octonions is non-associative. They do, however, preserve the quadratic relation x y * + y x * = 2 〈 x , y 〉 1 :
L x L y * + L y L x * = 2 〈 x , y 〉 1 I = R x R y * + R y R x * ( L x * = L x * ) .
(17)
Equation ( 17) applied to the span of the first six imaginary octonion units e j , j = 1 , ⋯ , 6 and setting L e j = : L j , R e j = : R j becomes the defining relation of the Clifford algebra C ℓ − 6 :
L j L k + L k L j = − 2 δ j k = R j R k + R k R j , j , k = 1 , ⋯ , 6 .
(18)
2.2. C ℓ − 6 as a Generating Algebra of O and s o ( O )
The octonions appear in any of the nested Clifford algebras C ℓ 8 ⊂ C ℓ 9 ⊂ C ℓ 10 . In fact, the minimal realization of O is provided by C ℓ − 6 , generated by the left multiplication L α by six of the seven imaginary octonion units e α . In general, L x L y ≠ L x y (and similarly for R), but remarkably, as noted in [ 20], the relation e 1 ( e 2 ( e 3 ( e 4 ( e 5 ( e 6 e a ) ) ) ) ) ) = e 7 e a is satisfied for all a = 1 , ⋯ , 8 ( e 8 = 1 ) so that
L 1 L 2 ⋯ L 6 = L e 7 = : L 7 , R 1 R 2 ⋯ R 6 = R e 7 = : R 7 .
(19)
While L x R x = R x L x (for x ∈ O ), the non-associativity of the algebra of octonions is reflected in the fact that for x ≠ y , L x and R y in general, do not commute. The Lie algebra s o ( 8 ) is spanned by the elements of the negative square of C ℓ − 6 . If we denote the exterior algebra on the span of L 1 , ⋯ , L 6 by
Λ * ≡ Λ * C ℓ − 6 = Λ 0 + Λ 1 + ⋯ + Λ 6 ( Λ 1 = Span 1 ≤ j ≤ 6 L j , Λ 6 = { R L 7 } )
then s o ( 8 ) = Λ 1 + Λ 2 + Λ 5 + Λ 6 (accordingly, the 28-dimensional adjoint representation of s o ( 8 ) splits into four irreducible representations of s o ( 6 ) : 28 = 6 + 15 + 6 * + 1 . In particular, Λ 5 = S p a n { L α 7 , α = 1 , … , 6 } for L α β defined below). A basis of the Lie algebra, given by
L α 8 = 1 2 L α , L α β = − 1 4 [ L α , L β ] , α , β = 1 , ⋯ , 7
(20)
obeys the standard commutation relations (CRs) for s o ( n ) (herein n = 8 ):
[ L a b , L c d ] = δ b c L a d − δ b d L a c + δ a d L b c − δ a c L b d ,
L a b = 1 4 ( L a L b * − L b L a * ) , a , b , c , d = 1 , 2 , ⋯ , 8 ( L α * = − L α , L 8 * = L 8 )
(21)
(and similarly for R a b ). Each element of s o ( 8 ) of square − 1 defines a complex structure (see Section 2.3). Following [ 24], we shall single out the Clifford pseudoscalars L 7 and R 7 ( 19) (called volume forms in the highly informative lectures [ 51] and Coxeter elements in [ 52]). We shall use the (mod 7) multiplication rules of [ 13] for the imaginary octonion units
L i e j ( = e i e j ) = − δ i j + f i j k e k , f i j k = 1
for ( i , j , k ) = ( 1 , 2 , 4 ) ( 2 , 3 , 5 ) ( 3 , 4 , 6 ) ( 4 , 5 , 7 ) ( 5 , 6 , 1 ) ( 6 , 7 , 2 ) ( 7 , 1 , 3 )
(22)
and f i j k is fully antisymmetric within each of the above seven triples. The Clifford pseudoscalar is naturally associated with the Cartan subalgebra of s o ( 6 ) , spanned by
( L 13 , L 26 , L 45 ) as L 7 ( e 1 , e 2 , e 4 ) = ( e 3 , e 6 , e 5 ) .
(23)
We can write
L 7 = 2 3 L 13 L 26 L 45 ( as 2 L 13 = L 1 L 3 * = − L 1 L 3 etc . ) .
(24)
The infinitesimal counterpart of ( 14) reads
T α ( x , y ) = ( L α x ) y + x ( R α y ) for α , x , y ∈ O , α * = − α ,
i . e . , T α = L α + R α .
(25)
There is an involutive outer automorphism π of the Lie algebra s o ( 8 ) such that
π ( L α ) = T α , π ( R α ) = − R α , π ( T α ) = L α ( π 2 = i d ) .
(26)
As proven in Appendix A,
π ( L a b ) = E a b , where E a b e c = δ b c e a − δ a c e b ( a , b , c = 1 , 2 , ⋯ , 8 , e 8 = 1 ) .
(27)
( L a b ) , ( E a b ) , and ( R a b ) provide three bases of s o ( 8 ) , each obeying the CRs ( 21). They are expressed by each other in terms of the involution π :
L a b = π ( E a b ) , E α 8 = L α 8 + R α 8 , α = 1 , ⋯ , 7 .
(28)
We find, particularly (see Appendix A):
L 7 = 2 L 78 = E 78 − E 13 − E 26 − E 45 = 2 E 78 − R 7 ; 2 L 13 = E 13 − E 26 − E 45 − E 78 ,
2 L 26 = E 26 − E 13 − E 45 − E 78 , 2 L 45 = E 45 − E 13 − E 26 − E 78 .
(29)
While L 78 = 4 L 13 L 26 L 45 ( 24) commutes with the entire Lie algebra s p i n ( 6 ) = s u ( 4 ) and the u ( 1 ) generator (whose physical meaning is revealed by ( 45)).
C 1 = L 13 + L 26 + L 45 centralizes u ( 3 ) = u ( 1 ) ⊕ s u ( 3 ) ⊂ s u ( 4 )
(30)
where the second summand is the unbroken color Lie algebra s u ( 3 ) = s u ( 3 ) c .
2.3. Complex Structure and Symmetry Breaking in C ℓ n
The algebra C ℓ 8 is generated by two-by-two Hermitian matrices whose elements involve the operators L a of the left multiplication by octonion units:
γ a = 0 L a L a * 0 , L a = L e a , L a * = L e a * , a = 1 , … , 8 .
(31)
Here, e 8 = 1 ( = e 8 * ) , L 8 = 1 I 8 is the unit operator in R 8 ; L α * = − L α for α = 1 , … , 7 so that the C ℓ 10 generators γ α ( 10) are obtained from the above (for α = 1 , … , 7 ) through tensoring with the 2 × 2 unit matrix σ 0 .
A compact way to identify the particle states in a Clifford algebra C ℓ 2 n is to introduce a complex structure which, as we shall demonstrate, gives rise to a fermionic Fock space in C ℓ 2 n .
( J X , J Y ) = ( X , Y ) , ( J X , Y ) = − ( X , J Y ) , ∀ X , Y ∈ E 2 n .
(32)
For a non-zero vector X and a complex structure J, the vector Y = J X is orthogonal to X (and has the same norm):
Y = J X ⇒ ( X , Y ) = 0 ( ( X , X ) = ( Y , Y ) > 0 ) .
It follows that for each complex structure J in E 2 n , there exists an orthonormal basis of the form ( γ 1 , … , γ n , J γ 1 , … , J γ n ) in C ℓ 2 n . Then, a j = 1 2 ( γ j − i J γ j ) and a j * = 1 2 ( γ j + i J γ j ) , j = 1 , … , n each span the image in C ℓ 2 n ( = C ℓ 2 n ( C ) ) of a maximal isotropic subspace of the complexification of E 2 n . Together, they yield a realization of the canonical anticommutation relations (CAR). Fermionic oscillators have been used in the present context in [ 21, 53]. The complex structure in s o ( 2 n ) involves a distinguished maximal (rank n) Lie subalgebra (a notion studied in [ 41]), u ( n ) ⊂ s o ( 2 n ) , which is generated by the products b j b k * . It also selects two distinguished u ( n ) singlet states in C ℓ 2 n , the vacuum, which is annihilated by all b j and the antipode, which is annihilated by the b j * . Both singlets are annihilated by the simple part s u ( n ) of u ( n ) .
Complex structures have been studied in relation to spinors by Élie Cartan (since 1908), Veblen (1933), and Chevalley (1954). For a carefully written survey with historical highlights—see [ 54]. For a concise modern exposition that connects them to the states in a fermionic Fock space, see Dubois-Violette [ 55]. We have also been influenced by their use (in S O ( 9 ) ) by Krasnov [ 46] and by relating them to Clifford pseudoscalars in [ 24].
The pseudoscalar ω 6 of C ℓ 6 belongs to C ℓ 8 but only defines a complex structure through its action on the octonion units. More precisely, taking the basic relations ( 22) and the identity ϵ 2 = − σ 0 into account, we can write
ω 6 = − σ 0 ⊗ L 7 , where − L 7 e a = ∑ b J a b e b , J α β = − f 7 α β , α , β = 1 , … , 6 ,
J a b = − J b a , J 13 = J 26 = J 45 = − J 78 = − 1 .
(33)
Warning: due to the non-associativity of O , − L 7 e 3 = e 1 does not imply − L 7 L 3 = L 1 , etc.
We shall see that each of the subgroups S p i n ( n ) ω 6 of the spin groups of C ℓ n for n = 8 , 9 , 10 that leaves ω 6 invariant is relevant for the particle physics:
S p i n ( 8 ) ω 6 = U ( 4 ) , S p i n ( 9 ) ω 6 = S U ( 4 ) × S U ( 2 ) , S p i n ( 10 ) ω 6 = G PS
(34)
The U ( 1 ) factor in the U ( 4 ) of S p i n ( 8 ) ω 6 and the S U ( 2 ) in S p i n ( 9 ) ω 6 are generated by all three components of the “total weak isospin” I = I L + I R , as will be made explicit in Section 3.2.
We shall define a complex structure J corresponding to ω 6 by extrapolating ( 33) to a transformation of the gamma matrices of C ℓ 8 :
J : γ a → ∑ b J a b γ b = ω J γ a ω J * , ω J = 1 4 ( 1 + γ 13 ) ( 1 + γ 26 ) ( 1 + γ 45 ) ( 1 − γ 78 ) .
(35)
We can extend the basis ( 31) of C ℓ 8 to C ℓ 10 , setting (cf. ( 10)):
γ α = σ 0 ⊗ ϵ ⊗ L α for α = 1 , … , 7 ,
γ 8 = σ 0 ⊗ σ 1 ⊗ 1 I 8 , γ 9 = σ 2 ⊗ σ 3 ⊗ 1 I 8 , γ 10 = σ 1 ⊗ σ 3 ⊗ 1 I 8 .
(36)
In particular, C ℓ 9 = R 16 ⊕ R 16 is generated by the 32 × 32 matrices γ 1 , … , γ 9 , which commute with ω 9 = γ 1 γ 2 … γ 9 = σ 2 ⊗ 1 I 16 . The Lie subalgebra of s o ( n ) of the derivations of C ℓ n , n = 8 , 9 , 10 that commute with ω 6 ( 10) is s o ( 6 ) ⊕ s o ( n − 6 ) . For n = 10 , it is the Lie algebra g P S of the Pati–Salam group ( 8) that respects the tensor product representation ( 11) of C ℓ 10 .
We now proceed to give meaning to the projection operator
P = 1 − i ω 6 2 ( P 2 = P ) , t r P = t r ( 1 − P ) = 2 ℓ − 1 for n = 2 ℓ ( = 6 , 8 , 10 ) .
(37)
To begin with, we introduce the isotropic elements
2 b 1 = ( 1 − i J ) γ 1 = γ 1 + i γ 3 , 2 b 2 = ( 1 − i J ) γ 2 = γ 2 + i γ 6 , 2 b 3 = ( 1 − i J ) γ 4 = γ 4 + i γ 5 .
(38)
These correspond to the projected octonion units 1 2 ( 1 + i L 7 ) e ℓ , ℓ = 1 , 2 , 4 . Together with their conjugates b j * ( b 1 * = 1 2 ( γ 1 − i γ 3 ) , etc.), they realize the CAR
[ b j , b k ] + = 0 , [ b j , b k * ] + = δ j k , j , k = 1 , 2 , 3 .
(39)
The annihilation operators b j span the (maximal) three-dimensional isotropic subspace H ( 1 , 0 ) of the six-dimensional complex vector space C E 6 , while b j * span its orthogonal complement H ( 0 , 1 ) ; we have:
J ( 1 ∓ i J ) γ ℓ = ± i ( 1 ∓ i J ) γ ℓ for ℓ = 1 , 2 , 4 .
(40)
The commuting Hermitian elements i γ ℓ 3 ℓ ( m o d 7 ) , ℓ = 1 , 2 , 4 , which span a Cartan subalgebra of the comlexified s o ( 6 ) , can be expressed as commutators of b j * and b j , j = 1 , 2 , 3 or as differences of the associated projection operators p j ′ − p j :
i γ ℓ 3 ℓ = [ b ℓ * , b ℓ ] = p ℓ ′ − p ℓ , ℓ = 1 , 2 , i γ 45 = [ b 3 * , b 3 ] = p 3 ′ − p 3 ,
p j = b j b j * , p j ′ = b j * b j = 1 − p j , p j p j ′ = 0 , j = 1 , 2 , 3 .
(41)
In terms of these operators, the C ℓ 6 pseudoscalar and the projector P assume the form:
i ω 6 = ( p 1 ′ − p 1 ) ( p 2 ′ − p 2 ) ( p 3 ′ − p 3 ) = P ′ − P , P ′ = 1 − P ,
P = ℓ + q , ℓ = p 1 p 2 p 3 , q = q 1 + q 2 + q 3 , q j = p j p k ′ p ℓ ′ .
(42)
The triple ( j , k , ℓ ) being a permutation of ( 1 , 2 , 3 ) .
We shall identify the generators (of the comlexification s ℓ ( 3 , C ) ) of s u ( 3 ) with the traceless part of the matrix ( b j b k * ) , whose elements belong to H ( 1 , 1 ) . Then, the splitting ( 42) of P into the s u ( 3 ) singlet ℓ and the triplet q implements the lepton-quark splitting anticipated by its image ( 1) on the octonions. We shall thus interpret the one-dimensional projectors ℓ and q j as describing the lepton and the colored quark states in C ℓ 6 . The states ℓ and q j are mutually orthogonal idempotents, with ℓ playing the role of the Fock vacuum in C ℓ 6 :
ℓ 2 = ℓ , ℓ q j = 0 , q j q k = δ j k q j , b j ℓ = 0 = ℓ b k * .
(43)
Remark 1.
We shall argue in Section 3.3 that the identification of P as a particle subspace projector (adopted in [ 34]) would only be justified if we have a clear distinction between particles and antiparticles. This can be claimed for the 30 fundamental (anti)fermions of the C ℓ 10 multiplet 32 ( 9), which have different quantum numbers with respect to the gauge Lie algebra g SM of the SM. It fails in the two-dimensional subspace of sterile neutrinos annihilated by g SM ; ν R and ν ¯ L are allowed to form a coherent superposition—a Majorana spinor. In Section 3.3 and Section 4, we shall adopt the restricted projector ℓ r on the (three- rather than four-dimensional) lepton subspace excluding the sterile neutrino.
In order to extend the Fock space picture to C ℓ 8 , we shall set
i γ 7 = a * − a , γ 8 = a + a * ⇒ i γ 78 = [ a * , a ]
(44)
where the pair ( a * , a ) describes another Fermi oscillator ( [ a , a * ] + = 1 ) anticommuting with b j , b k * . We shall fix the physical interpretation of [ a * , a ] by postulating that the electric charge operator is given by
Q : = 1 3 ∑ j = 1 3 b j * b j − a * a = 1 2 ( B − L − [ a * , a ] ) ,
where B − L = 2 i 3 ( L 13 + L 26 + L 45 ) = 1 3 ∑ j [ b j * , b j ] ,
(45)
and stands for the difference between the baryon and the lepton numbers. B − L takes the eigenvalues ± 1 3 for (anti)quarks and ∓ 1 for (anti)leptons. Demanding that the gauge Lie algebra within s o ( 8 ) commutes with both ω 6 and Q, we shall further reduce it from s o ( 6 ) ⊕ s o ( 2 ) to the rank four Lie subalgebra
g 4 = s u ( 3 ) c ⊕ u ( 1 ) Q ⊕ u ( 1 ) B − L = { X ∈ u ( 4 ) , [ X , Q ] = 0 } .
(46)
The knowledge of the charges Q , B − L along with the color Lie algebra allows us to identify the primitive idempotents of C ℓ 8 , given by ℓ , q j and multiplied by a a * or a * a , with the fundamental fermions:
ℓ a a * = ν , ℓ a * a = e , q j a a * = u j , q j a * a = d j .
(47)
The “isotopic doublets” ( ν , e ) and ( u j , d j ) stand for neutrino/electron and up/down colored quarks. We see, in particular, that the Fock vacuum in C ℓ 8 that is associated with the complex structure ( 33) is identified with the neutrino (as it has no charge and a ν = 0 = b j ν ). Note that the subalgebra of g 4 that annihilates ν is the known unbroken gauge Lie algebra u ( 3 ) of the SM:
u ( 3 ) SM = s u ( 3 ) c ⊕ u ( 1 ) Q = { X ∈ g 4 ; X ν = 0 } .
(48)
This picture ignores chirality, which will find its place in C ℓ 10 ( Section 3.2).
3. The Internal Space Subalgebra of C ℓ 10
3.1. Equivalence Class of Lorentz-like Clifford Algebras
Nature appears to select real Clifford algebras C ℓ ( s , t ) of the equivalence class of C ℓ ( 3 , 1 ) (with a Lorentz signature in four dimensions) in Élie Cartan's classification (which involves 8 the signs, ω 2 ( s , t ) and ( − 1 ) s − t ):
C ℓ ( s , t ) = R [ 2 n ] , for s − t = 2 ( mod 8 ) , s + t = 2 n .
(49)
They act on 2 n dimensional Majorana spinors that irreducibly transform under the real 2 n dimensional representation of the spin group S p i n ( s , t ) . If γ 1 , ⋯ , γ 2 n is the image in C ℓ ( s , t ) of an orthonormal basis of the underlying vector space R s , t , then the Clifford pseudoscalar defines a complex structure
ω s , t = γ 1 ⋯ γ 2 n , 2 n = s + t , ω s , t 2 = − 1 ,
(50)
which commutes with the action of S p i n ( s , t ) . Upon complexification, the resulting Dirac spinor splits into two inequivalent 2 n − 1 dimensional complex Weyl (or chiral) spinor representations, which are irreducible over C under S p i n ( s , t ) . The corresponding projectors Π L and Π R on the left and right spinors are given in terms of the chirality χ , which involves the imaginary unit i:
Π L = 1 2 ( 1 − χ ) , Π R = 1 2 ( 1 + χ ) , χ = i ω s , t ,
χ 2 = 1 I ⇔ Π L 2 = Π L , Π R 2 = Π R , Π L Π R = 0 , Π L + Π R = 1 I .
(51)
Another interesting example of the same equivalence class (also with indefinite metric) is the conformal Clifford algebra C ℓ ( 4 , 2 ) (with isometry group O ( 4 , 2 ) ). We shall demonstrate that just as C ℓ − 6 was viewed (in Section 2.2) as the Clifford algebra of the octonions, C ℓ ( 4 , 2 ) plays the role of the Clifford algebra of the split octonions (also appearing in bitwistor theory [ 56]):
x = v + V + l ( w + W ) , v , w ∈ R , V = i V 1 + j V 2 + k V 3 , W = i W 1 + j W 2 + k W 3
i 2 = j 2 = k 2 = i j k = − 1 , l 2 = 1 , V l = − l V .
(52)
Indeed, defining the mapping (cf. ( 6)),
i → γ − 1 , j → γ 0 , l → γ 1 , j l → γ 2 , ℓ k → γ 3 , ℓ i → γ 4
[ γ μ , γ ν ] + = 2 η μ ν 1 I , η 11 = η 22 = η 33 = η 44 = 1 = − η − 1 , − 1 = − η 00
(53)
we find that the missing split-octonion (originally, quaternion) imaginary unit k ( = i j = − j i ) can be identified with the C ℓ ( 4 , 2 ) pseudoscalar:
ω 4 , 2 = γ − 1 γ 0 γ 1 γ 2 γ 3 γ 4 ↔ k , ω 4 , 2 2 = − 1 , [ w 4 , 2 , γ ν ] + = 0 .
(54)
The conjugate to the split octonion x ( 52) and its norm are
x * = v − V − ℓ ( w + W ) , N ( x ) = x x * = v 2 + V 2 − w 2 − W 2 ,
so that the isometry group of O ˜ is O ( 4 , 4 ) (in particular, the maximal compact subalgebra s o ( 4 ) ⊕ s o ( 4 ) ⊂ s o ( 4 , 4 ) is spanned by γ j k , j , k = 1 , … , 4 and by ω 4 , 2 , γ α , α = − 1 , 0 , and their commutators. The remaining 16 non-compact generators of s o ( 4 , 4 ) involve the square-one matrices γ j , γ α γ j , γ j ω 4 , 2 ).
As we are interested in the geometry of the internal space of the SM acted upon by a compact gauge group, we shall work with (positive or negative) definite Clifford algebras C ℓ 2 ℓ , ℓ = 1 ( mod 4 ) . The algebra C ℓ − 6 considered in Section 2 belongs to this family (with ℓ = − 3 ). For ℓ = 1 , we obtain the Clifford algebra of the two-dimensional conformal field theory; the one-dimensional Weyl spinors correspond to analytic and antianalytic functions. Here, we shall argue that for the next allowed value, ℓ = 5 , the algebra C ℓ 10 = C ℓ 4 ⊗ ^ C ℓ 6 ( 11) fits the internal space of the SM beautifully if we associate the two factors to the color and flavor degrees of freedom, respectively. We shall strongly restrict the physical interpretation of the generators γ a b = 1 2 [ γ a , γ b ] , a , b = 1 , ⋯ , 10 of the derivations of C ℓ 10 by demanding that the splitting ( 11) of C ℓ 10 into C ℓ 4 and C ℓ 6 is preserved. This amounts to selecting a first step of symmetry breakings of the GUT group S p i n ( 10 ) , which leads to the semi-simple Pati–Salam group ( S p i n ( 4 ) × S p i n ( 6 ) ) / Z 2 ( 8). Each summand of g P S , s o ( 4 ) and s o ( 6 ) , expressed in terms of Fermi creation and annihilation operators, has a distinguished Lie subalgebra, u ( 2 ) and u ( 3 ) , that belongs to H 1 , 1 . We identify the leptons and quarks with u ( 3 ) singlets and triplets. This identification implements the lepton-quark symmetry alluded to by ( 1).
3.2. g S M as Annihilator of Sterile Neutrino
We proceed to extend the complex structure J ( 33) and ( 35) to C ℓ 10 , expressing, in particular, the electroweak gauge group generators in terms of the fermionic oscillators corresponding to the C ℓ 4 factor in ( 11). To this end, we complement the definition ( 38) of b j by
2 a 1 = ( 1 − i J ) γ 10 = γ 10 − i γ 9 , 2 a 2 = γ 8 − i γ 7 ⇒ i γ 78 = [ a 2 * , a 2 ] , i γ 910 = [ a 1 * , a 1 ]
(55)
(where γ a are given by ( 36)). In particular, ( a 2 , a 2 * ) coincide with the unique flavor fermionic oscillator ( a , a * ) ( 44) of C ℓ 8 . They allow us to define two pairs of complementary projectors.
π α = a α a α * , π α ′ = a α * a α = 1 − π α , α = 1 , 2 , π α π α ′ = 0 , π α + π α ′ = 1 .
(56)
The three pairs of color ( p j , p j ′ , j = 1 , 2 , 3 ) and two pairs of flavor ( π α , π α ′ , α = 1 , 2 ) projectors give rise to a ( 2 5 = 32 -dimensional) maximal abelian subalgebra of C ℓ 10 of the commuting observables. The flavor gauge Lie algebra gnerators, the left and right chiral isospin components, are expressed in terms of a α ( * ) :
I + L = a 1 * a 2 , I − L = a 2 * a 1 , [ I + L , I − L ] = 2 I 3 L = π 1 ′ π 2 − π 1 π 2 ′ = π 1 ′ − π 2 ′ ;
I + R = a 1 a 2 , I − R = a 2 * a 1 * , [ I + R , I − R ] = 2 I 3 R = π 1 π 2 − π 1 ′ π 2 ′ = π 2 − π 1 ′ .
(57)
The chirality operator χ = Π R − Π L is expressed in terms of the C ℓ 10 pseudoscalar (as implied by ( 51) for s = 10 , t = 0 ):
χ = i ω 10 = i ω 6 γ 78 γ 910 = ( P ′ − P ) [ a 1 * , a 1 ] [ a 2 , a 2 * ] = ( P ′ − P ) ( P 1 − P 1 ′ ) ,
P 1 = ( 2 I 3 L ) 2 = π 1 ′ π 2 + π 1 π 2 ′ , P 1 ′ = ( 2 I 3 R ) 2 = π 1 π 2 + π 1 ′ π 2 ′ = 1 − P 1 ,
(58)
so that Π L = P P 1 + P ′ P 1 ′ , Π R = P P 1 ′ + P ′ P 1 . Within the particle subspace P , the operator P 1 projects on the left chiral and P 1 ′ on the right chiral fermions.
The sum I 3 = I 3 L + I 3 R coincides with the total isospin projection that generates the commutant u ( 1 ) of s u ( 4 ) in u ( 4 ) —see the discussion after Equation ( 34) in Section 2.3. Conversely, I 3 L , I 3 R appear as chiral projections of I 3 :
2 I 3 = 2 I 3 L + 2 I 3 R = [ a 2 , a 2 * ] = π 2 − π 2 ′ = 2 Q − ( B − L ) ,
( 2 I 3 ) 2 = 1 , I 3 L = P 1 I 3 P 1 , I 3 R = P 1 ′ I 3 P 1 ′ ( I 3 L I 3 R = 0 ) .
(59)
The identification of the vacuum vector a 1 a 2 b 1 b 2 b 3 (annihilated by all a α , b j ) becomes consequential if we demand that this ket-vector is a singlet with respect to the gauge group of the SM. The fact that the left and right isospin cannot vanish simultaneously (because ( 2 ( I 3 L + I 3 R ) ) 2 = 1 ) implies that the Lie algebra g SM of the SM should be chiral:
g SM ⊂ u ( 2 ) ⊕ u ( 3 ) , where u ( 2 ) = s u ( 2 ) L ⊕ u ( 1 ) I 3 R , u ( 3 ) = s u ( 3 ) c ⊕ u ( 1 ) B − L .
(60)
It is therefore rewarding that we can identify the Fock space vacuum in C ℓ 10 (given by ν of ( 47) for C ℓ 8 ) with the (right handed, hypothetical) sterile neutrino (in fact, ν R and its antipode ν ¯ L do not interact with the gauge bosons):
ν R = π 1 π 2 ℓ , a α ν R = 0 ( = ν R a α * ) , b j ν R = 0 ⇔ ν ¯ L = π 1 ′ π 2 ′ ℓ ′ , a α * ν ¯ L = 0 etc .
(61)
The role of the electric charge Q ( 45) that breaks the u ( 4 ) symmetry of ω 6 in s o ( 8 ) to u ( 3 ) ⊕ u ( 1 ) Q is played by the weak hypercharge Y in s o ( 10 ) :
1 2 Y = 1 3 ∑ j = 1 3 b j * b j − 1 2 ∑ α = 1 2 a α * a α = 1 2 ∑ α = 1 2 a α a α * − 1 3 ∑ j = 1 3 b j b j * .
(62)
They both annihilate the respective vacuum state as well as its antipode. This is made obvious by the two forms of Y in Equation ( 62) as sums of the normal and antinormal products. By definition, Y belongs to the center of the broken symmetry subalgebra of g P S . As pointed out in [ 2] and as will be discussed below in Section 3.3, it gives rise to a superselection rule in the SM.
The significance of choosing the sterile neutrino as a Fock vacuum is summarized by the following:
Proposition 1.
The Lie subgroup of G P S ( 8) that leaves the Fock vacuum ν R ( 61) invariant is the SM gauge group ( 13).
Proof.
We shall first complete the argument that the maximal Lie subalgebra of g P S annihilating the sterile neutrino is g SM . We have already noted that the Lie subalgebra of g P S for which the vacuum transforms as a singlet is u ( 2 ) ⊕ u ( 3 ) ( 60). This follows from the observation that generators involving a 1 * a 2 * and b j * b k * transform ν R into a right-handed electron e R and an up quark u R , respectively. It remains to analyze the two-dimensional center u ( 1 ) B − L + u ( 1 ) I 3 R of this extended algebra. ν R and ν ¯ L are eigenvectors of both generators with eigenvalues of opposite sign; only multiples of Y annihilate the sterile neutrino:
( 2 I 3 R − 1 ) ν R = 0 = ( B − L + 1 ) ν R , Y = B − L + 2 I 3 R ⇒ Y ν R = 0 = Y ν ¯ L .
(63)
This establishes the characterization of the Lie algebra g SM as the annihilator of the sterile neutrino. It will be straightforward to extend the result to the SM gauge group ( 13) after displaying the quantum numbers of the fundamental fermions in the following subsection. □
3.3. Superselection Rules: Restricted Particle Subspace
The weak hypercharge ( 62) and ( 63) generates the u ( 1 ) center of the gauge Lie algebra of the SM and hence commutes with all gauge transformations. It is not only conserved in the observed micro processes but even in hypothetical ones, such as a possible proton decay (with a conserved B − L ), or in the presence of a Majorana neutrino (a coherent superposition of ν R and ν ¯ L ) that would break B − L by two units. The weak hypercharge was proposed in [ 2] as a superselection rule, assuming that Y commutes with all observables. The Jordan algebra of the 32-dimensional space of internal observables of one generation splits into 11 superselection sectors corresponding to the 11 different eigenvalues of Y (see Appendix to [ 2]).
Superselection rules (SSR) were introduced by Wick, Wightman, and Wigner [ 57, 58] in 1952. The superselection of the electric charge has been thoroughly discussed in [ 58] and the review [ 59]; for more references and a historical survey addressed to philosophers, see [ 60]. The charge Q ( 45) is superselected by the exact symmetry of the SM (otherwise, I ± L do not commute with it). SSRs are also related to measurement theory [ 52]. SSR and superselection sectors are an essential part of the Doplicher–Haag–Roberts reconstruction of quantum fields from the algebra of observables—see [ 36].
For all we know, the exact symmetry of the SM is given by the rank four unbroken Lie algebra (obtained from g 4 ( 46) by the substitution B − L → Y ):
a 4 = s u ( 3 ) c ⊕ u ( 1 ) Y ⊕ u ( 1 ) Q , Q = 1 2 Y + I 3 L = 1 3 ∑ j = 1 3 p j ′ − π 2 ′ .
(64)
The states of the fundamental (anti)fermions are given by the primitive idempotents of C ℓ 10 , represented by the 2 5 = 32 different products of the five pairs of basic projectors π α ( ′ ) , p j ( ′ ) ( 56) ( 41). The 16 particles can be labeled by the eigenvalues of the pair of superselected charges ( Q , Y ) :
( ν R ) = ℓ π 1 π 2 = ( 0 , 0 ) = | ν R 〉 〈 ν R | , ( ν L ) = ℓ π 1 ′ π 2 = ( 0 , − 1 ) = | ν L 〉 〈 ν L | , ( e L ) = ℓ π 1 π 2 ′ = ( − 1 , − 1 ) = | e L 〉 〈 e L | , ( e R ) = ℓ π 1 ′ π 2 ′ = ( − 1 , − 2 ) = | e R 〉 〈 e R | ; ℓ = ( ν L ) + ( e L ) + ( ν R ) + ( e R ) = p 1 p 2 p 3 , ℓ 2 = ℓ , tr ℓ = 4 .
(65)
( u L j ) = q j π 1 ′ π 2 = ( 2 3 , 1 3 ) = | u L j 〉 〈 u L j | , ( d L j ) = q j π 1 π 2 ′ = ( − 1 3 , 1 3 ) = | d L j 〉 〈 d L j | , ( u R j ) = q j π 1 π 2 = ( 2 3 , 4 3 ) = | u R j 〉 〈 u R j | , ( d R j ) = q j π 1 ′ π 2 ′ = ( − 1 3 , − 2 3 ) = | d R j 〉 〈 d R j | ; q j = ( u L j ) + ( d L j ) + ( u R j ) + ( d R j ) = p j p k ′ p ℓ ′ , q i q j = δ i j q j , tr q j = 4
(66)
( j , k , ℓ ) ∈ Perm ( 1 , 2 , 3 ) , q = q 1 + q 2 + q 3 = q 2 , tr q = 12 (as the color is unobservable, we do not bother to assign to it eigenvalues of the diagonal operators i γ 13 , i γ 26 , i γ 45 that would replace the index j). Note that chirality in the particle subspace P χ = χ P is determined by the hypercharge:
P χ = P ( Π R − Π L ) = P ( − 1 ) 3 Y .
(67)
The charges ( Q , Y ) for the corresponding antiparticles have the opposite sign. The spectrum of Y and of 2 I 3 L = 2 Q − Y , together with the analysis of [ 38], allow us to complete the group theoretic version of Proposition 1.
Remark 2.
The factorization of the primitive idempotents ( 65) and ( 66) into bra and kets involves choices. We demand, following [ 2], that they are Hermitian conjugate elements of C ℓ 10 , homogeneous in a α ( * ) and b j ( * ) such that the kets corresponding to a left(right) chiral particle contains an odd (or even) number of factors. Choosing then | ν R 〉 = a 1 a 2 ℓ , | ν L 〉 = a 1 * | ν R 〉 , we find:
〈 ν R | = ℓ a 2 * a 1 * ⇒ ( ν R ) = π 1 π 2 ℓ , | ν L 〉 = π 1 ′ a 2 ℓ , | e L 〉 = I − L | ν L 〉 = − a 1 π 2 ′ ℓ , | e R 〉 = − a 1 * | e L 〉 = π 1 ′ π 2 ′ ℓ = I − R | ν R 〉 ; | d L j 〉 = π 1 a 2 * q j , | u L j 〉 = I + L | d L j 〉 = a 1 * π 2 q j , | d R j 〉 = a 1 * | d L j 〉 = a 1 * a 2 * q j , u R j = a 1 | u L j 〉 = π 1 π 2 q j ,
(68)
q j = p j p k ′ p ℓ ′ , j , k , ℓ ∈ Perm ( 1 , 2 , 3 ) , i.e. q 1 = p 1 p 2 ′ p 3 ′ = p 1 p 3 ′ p 2 ′ , etc. We note that all above kets as well as all primitive idempotents ( 65) ( 66) obey a system of five equations (specific for each particle), a α | ν R 〉 = 0 = b j | ν R 〉 , a 1 * | ν L 〉 = a 2 | ν L 〉 = 0 = b j | ν L 〉 , α = 1 , 2 , j = 1 , 2 , 3 , etc., so that they are minimal right ideals in agreement with the philosophy of Furey [ 20].
The fact that ν R , ν ¯ L are not distinguished by the superselected charges has a physical implication; one can consider their coherent superposition as in the now popular theory of a (hypothetical) Majorana neutrino. This suggests the introduction of a restricted 15-dimensional particle subspace with projector
P r = P − ( ν R ) = q + ℓ r , ℓ r = ℓ ( 1 − π 1 π 2 ) .
(69)
Theories whose field algebra is a tensor product of a Dirac spinor bundle on a spacetime manifold with a finite dimensional internal space usually encounter the problem of fermion doubling [ 61] (still discussed over 20 years later, [ 62]). It was proposed in [ 34] as a remedy to consider the algebra P C ℓ 10 P , where P is the projector ( 42) on the 16 dimensional particle subspace (including the hypothetical right-handed sterile neutrino). It is important—and will be essential in the treatment of the Higgs field ( Section 4)—that the operators a α ( * ) and b j ( * ) behave quite differently under particle projection. While a α ( * ) commute with P so that
P a α ( * ) P = a α ( * ) P = P a α ( * ) , [ P a α * , P a β ] + = P δ α β ,
(70)
the 2-sided particle projection of b j ( * ) vanishes:
P b j P = 0 = P b j * P .
(71)
Accordingly, while the generators ( 57) of the (electroweak) flavor “left-right symmetry” s u ( 2 ) L ⊕ s u ( 2 ) R just get multiplied by P , the particle subspace projections of the s u ( 3 ) c generators take a modified form:
P b j b k * P = b j b k * p ℓ ′ = : B j k for ( j , k , ℓ ) ∈ P e r m ( 1 , 2 , 3 ) , B j j − B k k : = q j − q k ;
T a = 1 2 B j k λ a k j , λ a ∈ H 3 ( C ) , tr λ a = 0 , tr λ a λ b = 2 δ a b , a , b = 1 , ⋯ , 8 ,
(72)
but still obey the same CR. It makes sense to separately consider the gauge Lie algebra in the lepton and quark sectors (or the factors C ℓ 4 and C ℓ 6 in C ℓ 10 ), noting that P ( B − L ) = − 1 for leptons and P ( B − L ) = 1 3 for quarks. It is particularly appropriate to treat the lepton sector by itself when using the restricted particle space as it is there that the flavor oscillators a α ( * ) are also modified:
ℓ r a 1 ( * ) ℓ r = a 1 ( * ) π 2 ′ = : A 1 ( * ) , ℓ r a 2 ( * ) ℓ r = a 2 ( * ) π 1 ′ = : A 2 ( * ) .
(73)
The operators A α ( * ) provide a realization of the four odd generators of the smallest simple Lie superalgebra, s ℓ ( 2 | 1 ) , whose even part is s u ( 2 ) L ⊕ u ( 1 ) Y (for a detailed identification with the standard definition of s ℓ ( 2 | 1 ) , see Section 3 of [ 2]). The non-vanishing anticommutators of A α ( * ) are:
[ A 1 , A 1 * ] + = π 2 ′ = − Q , [ A 2 , A 2 * ] + = π 1 ′ = Q − Y ,
[ A 1 * , A 2 ] + = a 2 a 1 * = − I + , [ A 1 , A 2 * ] + = − I − ; [ I + , I − ] = 2 I 3 = 2 Q − Y
(74)
(where we are omitting the superscript L on I a ). We shall apply the odd generators A α ( * ) in defining the Higgs part of a superconnection in Section 4. The minimal associative envelope A ℓ of s ℓ ( 2 | 1 ) ⊂ C ℓ 4 is nine-dimensional; it contains on top of A α ( * ) and their anticommutators ( 74) the projector A 1 * A 1 = A 2 * A 2 = π 1 ′ π 2 ′ ∈ C ℓ 4 . The resulting internal space algebra that ignores the sterile neutrinos is the direct sum
A = A ℓ ⊗ ℓ ⊕ C ℓ 4 ⊗ A q , A q = q C ℓ 6 0 q .
(75)
Here, A q is effectively the nine-dimensional associative envelope of u ( 3 ) ⊂ C ℓ 6 0 .
3.4. Complex Structure Associated with R 7 : A Comment
Inspired by [ 24, 46, 63], we shall display and discuss the symmetry subalgebras of C ℓ n , n = 8 , 9 , 10 of the complex structure generated by the Clifford pseudoscalar ω 6 R corresponding to the right action of the octonions:
ω 6 R = γ 1 R ⋯ γ 6 R for γ α R = ϵ ⊗ R α α = 1 , ⋯ , 7 .
(76)
Written in terms of the color projectors p j and p j ′ , the Hermitian pseudoscalar i ω 6 R assumes the form:
i ω 6 R = 1 2 ( P ′ − P − 3 ( B − L ) ) = ℓ + q ′ − ℓ ′ − q ,
ℓ ′ = p 1 ′ p 2 ′ p 3 ′ , q ′ = ∑ j = 1 3 q j ′ , q 1 ′ = p 1 ′ p 2 p 3 , q 2 ′ = p 1 p 2 ′ p 3 , q 3 ′ = p 1 p 2 p 3 ′
(77)
where we have used
L = ℓ − ℓ ′ , 3 B = q − q ′ .
(78)
While the term P ′ − P ( 42) commutes with the entire derivation algebra s p i n ( 6 ) = s u ( 4 ) of C ℓ 6 , the centralizer of B − L in s u ( 4 ) is u ( 3 ) —see Proposition A2 in Appendix A. It follows that the commutant of ω 6 R in s o ( 8 ) is u ( 3 ) ⊕ u ( 1 ) , while its centralizer in s o ( 9 ) is the gauge Lie algebra g SM = s u ( 3 ) ⊕ s u ( 2 ) ⊕ u ( 1 ) of the SM; finally, in s o ( 10 ) , ω 6 R is invariant under the left-right symmetric extension of g SM [ 24, 63],
g LR = s u ( 3 ) c ⊕ s u ( 2 ) L ⊕ s u ( 2 ) R ⊕ u ( 1 ) B − L .
(79)
Furthermore, as proven in [ 46], the subgroup of S p i n ( 9 ) that leaves ω 6 R invariant is precisely the gauge group 9 G SM = S ( U ( 2 ) × U ( 3 ) ) ( 13) of the SM (with the appropriate Z 6 factored out). One is then tempted to assume that C ℓ 9 , the associative envelope of the Jordan algebra J 2 8 = H 2 ( O ) , may play the role of the internal algebra of the SM, corresponding to one generation of fundamental fermions, with S p i n ( 9 ) as a GUT group [ 27, 28, 33]. We shall demonstrate that although G SM appears as a subgroup of S p i n ( 9 ) , its representation, obtained by restricting the (unique) spinor IR 16 of S p i n ( 9 ) to S ( U ( 2 ) × U ( 3 ) ) only involves S U ( 2 ) doublets, so it has no room for ( e R ) , ( u R ) , ( d R ) ( 65) ( 66). We shall see how this comes about when restricting the realization ( 57) of I L and I R to S p i n ( 9 ) ⊂ C ℓ 9 . It is clear from ( 57) that only the sum a 1 + a 1 * = γ 9 (not a 1 and a 1 * separately) belongs to C ℓ 9 . So, the s u ( 2 ) subalgebra of s p i n ( 9 ) corresponds to the diagonal embedding s u ( 2 ) ↪ s u ( 2 ) L ⊕ s u ( 2 ) R :
I + = I + L + I + R = ( a 1 * + a 1 ) a 2 = γ 9 a 2 , I − = I − L + I − R = a 2 * γ 9
2 I 3 = 2 I 3 L + 2 I 3 R = [ a 2 , a 2 * ] = π 2 − π 2 ′ .
(80)
In other words, the spinorial IR 16 of S p i n ( 9 ) is an eigensubspace of the projector P 1 = ( 2 I 3 L ) 2 . It consists of four S U ( 2 ) L particle doublets and their right chiral antiparticles. More generally, the only simple orthogonal groups with a pair of inequivalent complex that conjugate fundamental IRs are S p i n ( 4 n + 2 ) (see, e.g., [ 64], Proposition 5.2, p. 571). They include S p i n ( 10 ) but not S p i n ( 9 ) .
A direct description of the IR 16 L of S p i n ( 10 ) acting on C H ⊗ C O is given in [ 23] (Here, C H and C O are a short hand for the complexified quaternions and octonions: C H : = C ⊗ R H ). The right action of C H on elements of C H ⊗ C O , which commutes with the left-acting s p i n ( 10 ) , is interpreted in [ 23] as the Lorentz ( S L ( 2 , C ) ) transformation of the (unconstrained) two-component Weyl spinors.
The left-right symmetric extension g LR ( 78) of g SM has a long history, starting with [ 65] and vividly (with an admitted bias) told in [ 66]; it has been recently invigorated in [ 67, 68]. The group G LR was derived by Boyle [ 47] starting with the group E 6 of determinant preserving linear automorphisms of the complexified Albert algebra C J 3 8 and following the procedure of [ 35].
4. Particle Subspace and the Higgs Field
4.1. The Higgs as a Scalar Part of a Superconnection
The space of differential forms Λ * = Λ 0 + Λ 1 + Λ 2 + … can be viewed as a Z 2 graded setting Λ e v = Λ 0 + Λ 2 + … , Λ o d = Λ 1 + Λ 3 + … . Let M = M 0 + M 1 be a Z 2 graded matrix algebra. A superconnection in the sense of Quillen [ 69, 70] is an element of Λ e v ⊗ M 1 + Λ o d ⊗ M 0 , the odd part of the tensor product Λ * ⊗ M ; a critical review of the convoluted history of this notion and its physical implications is given in Section 4 of [ 71] (one should also mention the neat exposition of [ 72] in the context of the Weinberg–Salam model with two Higgs doublets).
Let D be the Yang–Mills connection one-form of the SM,
D = d x μ ( ∂ μ + A μ ( x ) ) ,
i A μ = W μ + I + L + W μ − I − L + W μ 3 I 3 L + N 2 Y B μ + G μ a T a ,
(81)
where Y , I L , and T a are given by ( 62), ( 57), and ( 72), respectively; G μ a is the gluon field, and W μ and B μ provide an orthonormal basis of electroweak gauge bosons; the normalization constant N will be fixed in Equation ( 93) below. Then, one defines a superconnection D in [ 34] involving the chirality χ ( 60) by
D = χ D + Φ , Φ = ∑ α ( ϕ α a α * − ϕ ¯ α a α ) ∈ P C ℓ 10 1 P = P C ℓ 4 1
(82)
(we omit, for the time being, the projector P in A μ and Φ ). The last equation follows from ( 71); the projection on the particle subspace kills the odd part of C ℓ 6 , thus ensuring that the quarks' color symmetry remains unbroken. The factor χ (first introduced in this context in [ 71]) ensures the anticommutativity of Φ and χ D without changing the Yang–Mills curvature D 2 = ( χ D ) 2 .
The projector P ( 42) on the 16-dimensional particle subspace that includes the hypothetical right chiral neutrino (and is implicit in ( 82)) was adopted in [ 34]. By contrast, particles are only distinguished from antiparticles in [ 2] if they have different quantum numbers in the Lie algebra of the SM
g SM = s u ( 3 ) c ⊕ s u ( 2 ) L ⊕ u ( 1 ) Y .
(83)
Thus, in [ 2], P is replaced by the 15-dimensional projector P r = q + ℓ r ( 69). We have seen that the projected odd operators A α ( * ) = ℓ r a α ( * ) ℓ r give rise to a realization of the four odd elements of the eight-dimensional simple Lie superalgebra s ℓ ( 2 | 1 ) whose even part is the four-dimensional Lie algebra u ( 2 ) of the Weinberg–Salam model of the electroweak interactions. It is precisely the Lie superalgebra that was proposed in 1979 independently by Ne'eman and by Fairlie [ 44, 45] (and denoted by them s u ( 2 | 1 ) ) in their attempt to unify s u ( 2 ) L with u ( 1 ) Y (and explain the spectrum of the weak hypercharge). Let us stress that the representation space of s ℓ ( 2 | 1 ) consists of the observed left and right chiral leptons (rather than of bosons and fermions like in the popular speculative theories in which the superpartners are hypothetical). Note that the trace of Y on negative chirality leptons ( ν L , e L ) is equal to its eigenvalue on the unique positive chirality state ( e R ) (equal to − 2 ) so that only the supertrace of Y vanishes on the lepton (as well as on the quark) space. This observation is useful in the treatment of anomaly cancellation (cf. [ 73]).
We shall sketch the main steps in the application of the superconnection ( 82) to the bosonic sector of the SM, emphasizing specific additional hypotheses used on the way (for detailed calculations, see [ 2]).
The canonical curvature form
D 2 = D 2 + χ [ D , Φ ] + Φ 2 , [ D , Φ ] = d x μ ( ∂ μ Φ + [ A μ , Φ ] )
(84)
satisfies the Bianchi identity
D D 2 = D 2 D ( ⇒ χ ( d Φ 2 + [ A , ϕ 2 ] + [ Φ , D Φ ] + ) = 0 ) ,
(85)
equivalent to the (super) Jacobi identity of our Lie superalgebra. It is important that the Bianchi identity, which is needed for the consistency of the theory, still holds if we add to D 2 a constant matrix term with a similar structure. Without such a term, the Higgs potential would be a multiple of Tr Φ 4 and would only have a trivial minimum at Φ = 0 , yielding no symmetry breaking. The projected form of Φ ( 82) and hence the admissible constant matrix addition to Φ 2 depends on whether we use the projector P (as in [ 34]) or P r (as in [ 2]). In the first case we just replace a α ( * ) with a α ( * ) P . In the second, however, the odd generators for leptons and quarks differ, and we set:
Φ = ℓ ( ϕ 1 A 1 * − ϕ ¯ 1 A 1 + ϕ 2 A 2 * − ϕ ¯ 2 A 2 ) + ρ q ∑ α = 1 2 ( ϕ α a α * − ϕ ¯ α a α ) ,
(86)
where ρ (like N in ( 81)) is a normalization constant that will be fixed later. Recalling that ℓ and q are mutually orthogonal ( ℓ q = 0 = q ℓ , ℓ + q = P ) , we find
Φ 2 = ℓ ( ϕ 1 ϕ ¯ 2 I + L + ϕ ¯ 1 ϕ 2 I − L − ϕ 1 ϕ ¯ 1 π 2 ′ − ϕ 2 ϕ ¯ 2 π 1 ′ )
− ρ 2 q ( ϕ 1 ϕ ¯ 1 + ϕ 2 ϕ ¯ 2 ) ( ϕ α = ϕ α ( x ) ) .
(87)
This suggests defining the SM field strength (the extended curvature form) as
F = i ( D 2 + m ^ 2 ) , m ^ 2 = m 2 ( ℓ ( 1 − π 1 π 2 ) + ρ 2 q )
(88)
(while m ^ 2 = m 2 P for the 16-dimensional particle subspace of [ 34]).
4.2. Higgs Potential and Mass Formulae
This yields the bosonic Lagrangian (setting T r X = 1 4 t r X —see [ 2])
L ( x ) = Tr { 1 2 F μ ν F μ ν − ( ∂ μ Φ + [ A μ , Φ ] ) ( ∂ μ Φ + [ A μ , Φ ] ) } − V ( Φ )
(89)
where the Higgs potential V ( Φ ) is given by (noting that T r ℓ r = 3 4 ):
V ( Φ ) = Tr ( m ^ 2 + Φ 2 ) 2 − 1 4 m 4 = 1 2 ( 1 + 6 ρ 4 ) ( ϕ ϕ ¯ − m 2 ) 2 .
(90)
Minimizing V ( Φ ) gives the expectation value of the square of ϕ = ( ϕ 1 , ϕ 2 ) :
〈 ϕ ϕ ¯ 〉 = ϕ 1 m ϕ 1 m ¯ + ϕ 2 m ϕ 2 m ¯ = m 2 , for Φ m = ∑ α = 1 2 ϕ a m a α * ( ℓ π 3 − α ′ + ρ q ) + c
· c
(91)
(the superscript m indicates that ϕ α takes a constant in x values depending on the mass parameter m). The mass spectrum of the gauge bosons is determined by the term − Tr [ A μ , Φ ] [ A μ , Φ ] of the Lagrangian ( 89), with A μ and Φ given by ( 81) and ( 86) for ϕ α = ϕ α m . The gluon field G μ does not contribute to the mass term as C ℓ 6 0 commutes with C ℓ 4 1 . The resulting quadratic form is generally not degenerate, so it does not yield a massless photon. It does so, however, if we assume that Φ m is electrically neutral (i.e., commutes with Q ( 64)):
[ Φ m , Q ] = 0 ⇒ ϕ 2 m = 0 ( = ϕ 2 m ¯ ) .
(92)
The normalization constant N (= tg θ w ) is fixed by assuming that 2 I 3 L and N Y are equally normalized:
N 2 = Tr ( 2 I 3 L ) 2 Tr Y 2 = 3 5 = ( tg θ w ) 2 ⇔ sin 2 θ w = 3 8 .
(93)
As Y ( ν R ) = 0 = I 3 L ( ν R ) , this result for the “Weinberg angle at unification scale” is independent of whether we use P or P r . If one takes the trace over the leptonic subspace, the result would have been ( tg θ w ) 2 = 1 3 ( ⇒ sin θ w = 1 2 , [ 44]), which is closer to the measured low-energy value.
Demanding, similarly, that the leptonic contribution to Φ 2 is the same as that for a colored quark (which gives ρ = 1 for the projector P ), we find
ρ 2 = Tr ( ℓ ( 1 − π 1 π 2 ) Φ 2 ) Tr q j Φ 2 = T r ( π 1 ′ π 2 ′ ϕ ϕ ¯ + π 1 ′ π 2 ϕ 2 ϕ ¯ 2 + π 1 π 2 ′ ϕ 1 ϕ ¯ 1 ) 4 ϕ ϕ ¯ = 1 2 .
(94)
The ratio m H 2 m W 2 , on the other hand, is found to be
m H 2 m W 2 = 4 1 + 6 ρ 4 1 + 6 ρ 2 = 4 for ρ 2 = 1 5 2 for ρ 2 = 1 2 .
(95)
The result of [ 2], which is much closer to the observed value, can also be written in the form m H 2 = 4 cos 2 θ W m W 2 , where θ W is the theoretical Weinberg angle ( 93).
5. Outlook
5.1. Coming to C ℓ 10
The search for an appropriate choice of a finite dimensional algebra suited to represent the internal space F of the SM is still ongoing. The road to the choice of C ℓ 10 , our first step to the restricted algebra A ( 75), has been convoluted.
In view of the lepton-quark correspondence that is embodied in the splitting ( 1) of the normed division algebra O of the octonions, the choice of Dubois-Violette [ 25] of the exceptional Jordan algebra F = H 3 ( O ) ( 7) appeared to be particularly attractive. We realized [ 27, 28, 35] that the simpler to work with subalgebra
J 2 8 = H 2 ( O ) ⊂ H 3 ( O ) = J 3 8
(96)
corresponds to the observables of one generation of fundamental fermions. The associative envelope of J 2 8 is C ℓ 9 = R [ 16 ] ⊕ R [ 16 ] with the associated symmetry group S p i n ( 9 ) . It was proven in [ 35] that the SM gauge group G SM ( 13) is the intersection of S p i n ( 9 ) with the subgroup of the automorphism group F 4 of J 3 8 that preserves the splitting ( 1); that is, the group S U ( 3 ) × S U ( 3 ) Z 3 ⊂ F 4 .
We were thus inclined to identify S p i n ( 9 ) as the most economic GUT group. As demonstrated in Section 3.4, however, the restriction of the spinor IR 16 of S p i n ( 9 ) to its subgroup G SM gives room to only half of the fundamental fermions, the S U ( 2 ) L doublets; the right chiral singlets, e R , u R , d R , are left out. It was then recognized that the (octonionic) Clifford algebra C ℓ 10 does the job. The particle interpretation of C ℓ 10 is dictated by the choice of a (maximal) set of five commuting operators in the Pati–Salam Lie subalgebra of s o ( 10 ) that leaves our complex structure invariant. This led us to presenting all chiral leptons and quarks of one generation as mutually orthogonal idempotents ( 65) and ( 66).
Furey [ 21] arrived (back in 2018) at the tensor product C ℓ 4 ⊗ ^ C ℓ 6 ( 11) following the R ⊗ C ⊗ H ⊗ O road. In fact, Clifford algebras have arisen as an outgrowth of Grassmann algebras and quaternions 10. The 32 products e a ε ν (= ε ν e a ) , a = 1 , ⋯ , 8 ( e 8 = 1 I ), ν = 0 , 1 , 2 , 3 of octonion and quaternion units may serve as components of a S p i n ( 10 ) Dirac (bi)spinor, acted upon by C ℓ 10 (with generators ( 36) involving the operators L α )—cf. [ 23].
5.2. Two Ways to Avoid Fermion Doubling
There are two inequivalent possibilities to avoid fermion doubling within C ℓ 10 . One, which was adopted in [ 2, 34] and in Section 3.3 of the present survey, consists in projecting on the particle subspace, which incorporates four S U ( 2 ) L doublets and eight S U ( 2 ) L (right chiral) singlets, with projector ( 42)
P = ℓ + q = 1 − i ω 6 2 , ℓ = p 1 p 2 p 3 , q = q 1 + q 2 + q 3
(97)
(see ( 70)–( 72)). Here, ω 6 is the C ℓ 6 pseudoscalar, the distinguished complex structure used in [ 24] as a first step in the “cascade of symmetry breakings”. The particle projector ( 97) is only invariant under the Pati–Salam subgroup ( 8) of S p i n ( 10 ) . The more popular alternative, which was adopted in [ 23], projects on the left chiral fermions (four particle doublets and eight antiparticle singlets) with projector Π L , which is defined in terms of the C ℓ 10 chirality χ = i ω 10 :
Π L = 1 − χ 2 = P P 1 + P ′ P 1 ′ ( P + P ′ = 1 = P 1 + P 1 ′ ) ,
(98)
invariant under the entire S p i n ( 10 ) ; here, P 1 projects on S U ( 2 ) L doublets (cf. ( 58)). The components of the resulting 16 L are viewed in [ 23] as Weyl spinors; the right action of (complexified) quaternions (that commutes with the left s p i n ( 10 ) action) is interpreted as an s ℓ ( 2 , C ) (Lorentz) transformation.
The difference of the two approaches, which can be labeled by the projectors P and Π L (on the left and right particles and on the left particles and antiparticles, respectively), has implications in the treatment of the generalized connection (including the Higgs) and anomalies. Thus, for the Π L (anti)leptons ( ν L , e L ) , e ¯ L , ν ¯ L we have vanishing trace of the hypercharge, tr Π L Y = 0 . For P leptons, ( ν L , e L ) , ν R , e R , the traces of the left and right chiral hypercharge are equal: tr ( P Π L Y ) = − 2 = tr ( P Π R Y ) , so that, as noted in Section 4.1, only the supertrace vanishes in this case. The associated Lie superalgebra fits Quillen's notion of superconnection ideally. A real “physical difference” only appears under the assumption that the electroweak hypercharge is superselected and P is replaced by the restricted projector P r on the 15-dimensional particle subspace (with the sterile neutrino ν R and with the vanishing hypercharge excluded). Then, the leptonic (electroweak) part of the SM is governed by the Lie superalgebra s ℓ ( 2 | 1 ) , whose four odd generators are given by third-degree monomials in a α ( * ) , the C ℓ 4 Fermi oscillators. The replacement of ℓ by ℓ r breaks the quark-lepton symmetry; while each colored quark q j appears in four flavors, the colorless leptons number just three. This yields a relative normalization factor between the quark and leptonic projection of the Higgs field and allows us to derive (in [ 2]) the relation
m H 2 = 5 2 m W 2 = 4 cos 2 θ th m W 2 ,
(99)
where θ th is the theoretical Weinberg angle, such that tg 2 θ W = 3 5 . The relation ( 99) is satisfied within 1 % accuracy by the observed Higgs and W ± masses.
5.3. Summary and Discussion; a Challenge
After the pioneering work of Feza Gürsey and the collaborators in the 1970s, Geoffrey Dixon devoted over 30 years to division algebras, which is followed by Cohl Furey since the 2010s. The Clifford algebra approach to unification, coupled with fermionic creation and annihilation operators, has also been pursued since the late 1970s by the Italian group around Roberto Caslbuoni. The notion of superconnection was anticipated and applied to the Weinberg–Salam model during the first decade of the creation of the SM as well. Thus, the basic ingredients of our endeavor have been with us for some 50 years. The pretended new features of the present survey concern certain details. Here belong:
The interpretation of the Clifford pseudoscalar ω 6 as i ( P − P ′ ) , where P and P ′ are the particle and antiparticle projection operators, respectively.
The realization that the projected Clifford algebra
P C ℓ 10 P = C ℓ 4 ⊗ C ℓ 6 0 ,
(100)
only involves the even part C ℓ 6 0 of C ℓ 6 ; coupled with the assignment of the Higgs field to the odd part, C ℓ 4 1 of the first factor explains the symmetry breaking of the (electroweak) flavor symmetry while preserving the color gauge group.
Exhibiting the role of the sterile neutrino (of the first generation of fundamental fermions) as the vacuum state of the theory. The gauge group of the SM is identified as the maximal subgroup of the Pati–Salam group G P S ( 8) that leaves ν R invariant.
Singling out the reduced 15-dimensional particle subspace yields a relation between the Higgs and the W boson masses and the theoretical Weinberg angle satisfied within 1% accuracy.
What is missing for completing the “Algebraic Design of Physics”—to quote from the title of the 1994 book by Geoffrey Dixon—is a true understanding of the three generations of fundamental fermions. None of the attempts in this direction [ 18, 25, 30, 47, 74] has brought a clear success. The exceptional Jordan algebra J 3 8 = H 3 ( O ) ( 7) with its built-in triality was first proposed to this end in [ 25] (continued in [ 33]); in its straightforward interpretaton, however, it corresponds to the triple coupling of left and right chiral spinors with a vector in internal space rather than to three generations of fermions. As recalled in (Section 5.2 of) [ 30], any finite dimensional unital module over H 3 ( O ) has the (disappointingly unimaginative) form of a tensor product of H 3 ( O ) with a finite dimensional real vector space E. It was further suggested there that the dimension of E should be divisible by three, but the idea was not pursued any further. Boyle [ 47] proposed considering the complexified exceptional Jordan algebra, whose group of determinant preserving linear automorpghisms is the compact form of E 6 . This led to a promising left-right symmetric extension of the gauge group of the SM, but the discussion has not yet shed new light on the three generation problem. Yet another development based on the study of indecomposable representations of Lie superalgebras can be traced back from [ 75], but only the mathematical machinery has been discussed so far.
Funding
This research received no external funding.
Data Availability Statement
No new data were created or analyzed in this study. Data sharing is not applicable to this article.
Acknowledgments
Discussions with John Baez, Latham Boyle, Michel Dubois-Violette, Cohl Furey, and Kirill Krasnov are gratefully acknowledged. It is a pleasure to thank Cécile Gourgues for her expert typing. The author thanks the IHES for their hospitality and support during the course of this work. The present exposition differs from the one in IHES/P/22/01; it owes much to the critical remarks on the earlier version made by Cohl Furey and especially by Kirill Krasnov. The author thanks the anonymous referees for their careful reading of the manuscript and constructive critical remarks that helped to improve the presentation in the final version of the paper. I thank Dimitar Nedanovski who helped me cope with the Publishers' requirements.
Conflicts of Interest
The author declares no conflict of interest.
Appendix A
Appendix A.1. Notation for Clifford Algebras
C ℓ ( s , t ) stands for the Clifford algebra generated by γ α satisfying
[ γ α , γ β ] + = 2 η α β , η α α = 1 for α = 1 , … , s , η α α = − 1 for α = s + 1 , … , s + t
( η α β = 0 for α ≠ β ). Its automorphism group is the (non-compact for s t ≠ 0 ) orthogonal group O ( s , t ) = O ( t , s ) . As internal symmetries correspond to compact gauge groups, we are mainly working with (positive or negative) definite forms and use the abbreviated notation C ℓ s = C ℓ ( s , 0 ) and C ℓ − t = C ℓ ( 0 , t ) for the associated Clifford algebras. The even subalgebra C ℓ 0 ( s , t ) is defined as the (closed under multiplication) span of products of an even number of γ matrices; The odd subspace C ℓ 1 ( s , t ) is defined as the (real) span of products of odd numbers of γ s (which is not closed under multiplication).
Appendix A.2. Interrelations between the L, E, and R Bases of so(8)
The imaginary octonion units e 1 , ⋯ , e 7 obey the anticommutation relations of C ℓ − 7
[ e α , e β ] + : = e α e β + e β e α = − 2 δ α β , α , β = 1 , ⋯ , 7
(A1)
and give rise to the seven generators L α = L e α of the Lie algebra s o ( 8 ) :
L α 8 : = 1 2 L α = : − L 8 α , L α β : = [ L α 8 , L 8 β ] ∈ s o ( 7 ) ⊂ s o ( 8 ) .
(A2)
For α ≠ β , there is a unique γ such that
L α e β = f α β γ e γ = ± e γ , f α β γ = − f β α γ = f γ α β .
(A3)
The structure constants f α β γ ( 22) (which only take the values 0 , ± 1 ) obey for different triples ( α , β , γ ) the relations
f α β γ = f α + 1 β + 1 γ + 2 = f 2 α , 2 β , 2 γ ( mod 7 ) .
(A4)
The list ( 22) follows from f 124 = 1 and the first Equation (A4), taking into account relations such as f 679 ≡ f 672 ( mod 7 ) , etc. Note that f α β γ ≠ 0 f α β γ are the structure constants of a (quaternionic) s u ( 2 ) Lie algebra; they are not the structure constants of s o ( 7 ) ⊂ s o ( 8 ) .
Define the involutive outer automorphism π of the Lie algebra s o ( 8 ) by its action ( 26) on the left and right multiplication L α and R α of octonions by imaginary octonions α = − α * :
π ( L α ) = L α + R α = : T α , π ( R α ) = − R α ⇒ π ( T α ) = L α .
(A5)
In the basis (A1) and (A3) of imaginary octonion units e α ( α = 1 , ⋯ , 7 ), by setting e 8 = 1 I and L α 8 = 1 2 L α (A2), R α 8 = 1 2 R α = − R 8 α , we define E a b by the second relation ( 27)
E a b e c : = δ b c e a − δ a c e b , a , b , c = 1 , ⋯ , 8 ( e 8 = 1 ) .
(A6)
Proposition A1.
Under the above assumptions/definitions, we have
π ( L a b ) = E a b ( f o r L α β : = [ L α 8 , L 8 β ] , L α 8 = 1 2 L α = − L 8 α ) .
(A7)
Proof.
From the first equation (A5) and from (A1), (A2), and (A6), it follows that
E α 8 = L α 8 + R α 8 = π ( L α 8 ) .
(A8)
The proposition then follows from the relations
L α β = [ L α 8 , L 8 β ] , E α β = [ E α 8 , E 8 β ]
(A9)
and from the assumption that π is a Lie algebra homomorphism. □
Corollary A1.
From (A7) and the involutive character of π, it follows that, conversely,
π ( E a b ) = L a b .
(A10)
To each α = 1 , ⋯ , 7 , there are three pairs β γ such that L β γ and E β γ commute with L α and among themselves and allow for the expression L α = 2 L α 8 in terms of E α 8 and the corresponding E β γ :
L 1 = 2 L 18 = E 18 − E 24 − E 37 − E 56 , L 2 = 2 L 28 = E 28 + E 14 − E 35 − E 67 , L 3 = 2 L 38 = E 38 + E 17 + E 25 − E 46 , L 4 = 2 L 48 = E 48 − E 12 + E 36 − E 57 , L 5 = 2 L 58 = E 58 + E 16 − E 23 − E 47 , L 6 = 2 L 68 = E 68 − E 15 + E 27 − E 34 , L 7 = 2 L 78 = E 78 − E 13 − E 26 − E 45 , o r L α = E α 8 − ∑ β < γ f α β γ E β γ .
(A11)
Recalling that E a b = π ( L a b ) (A8) and the fact that π is involutive, so that π ( E a b ) = L a b (A10), we deduce, in particular,
2 E 78 = L 78 − L 13 − L 26 − L 45 ,
R 7 = 2 E 78 − 2 L 78 = − L 78 − L 13 − L 26 − L 45 ,
(A12)
thus reproducing ( 29).
We now proceed to displaying the commutant of i ω 6 and i ω 6 R in s o ( 7 + j ) , j = 1 , 2 , 3 .
Proposition A2.
While the Lie algebra s p i n ( 6 ) = s u ( 4 ) commutes with L 7 , the commutant of R 7 (A12) in s u ( 4 ) ⊂ s ℓ ( 4 , C ) is u ( 3 ) ( ⊂ s ℓ ( 4 , C ) ) , given by
u ( 3 ) = ∑ j , k = 1 3 C j k [ b j * , b k ] ; C j k ∈ C , C k j = − C j k ¯
(A13)
in the fermionic oscillator relalization of C ℓ 6 ( C ) (the bar over C j k standing for complex conjugation).
Proof.
The fact that L 7 = 2 L 78 commutes with the generators L α β ( α , β = 1 , ⋯ , 6 ) of s o ( 6 ) and follows from ( 21). To find the commutant of R 7 (A12), it is convenient to use the fermionic realization of the complexification s ℓ ( 4 , C ) of s u ( 4 ) , which is spanned by the nine commutators [ b j * , b k ] in (A13) and the six products
b j b k = − b k b j , b j * b k * = − b k * b j * , j , k = 1 , 2 , 3 , j ≠ k .
(A14)
The sum L 13 + L 26 + L 45 in (A12) is a multiple of B − L ( 58), the Hermitian generator of the center of g ℓ ( 3 , C ) ,
B − L = i 3 ( γ 13 + γ 26 + γ 45 ) = 1 3 ∑ j = 1 3 [ b j * , b j ] .
(A15)
The relations
[ B − L , b j * b k * ] = 2 3 b j * b k * , [ B − L , b j b k ] = − 2 3 b j b k ,
B − L , [ b j * , b k ] = 0 , j , k = 1 , 2 , 3 , j ≠ k ,
(A16)
show that the commutant of B − L (and hence of R 7 ) in s u ( 4 ) is u ( 3 ) . □
Corollary A2.
The commutant of ω 6 R in s o ( 8 ) is u ( 3 ) ⊕ u ( 1 ) ; the commutant of ω 6 R in s p i n ( 9 ) is the gauge Lie algebra of the SM:
G SM = { a ∈ s p i n ( 9 ) ; [ a , ω 6 R ] = 0 } = u ( 3 ) ⊕ s u ( 2 ) .
(A17)
Notes
1
For a pleasant-to-read review of octonions, their history, and applications, see [ 13].
2
I had the good fortune to know him personally. See Witten's eloquent characterization of his personality and work in the Wikipedia entry on Feza Gürsey (1921–1991).
3
These algebras are defined and classified in [ 3, 4]; for a concise review, see [ 29], Section 3.2 of [ 25], and Section 2 of [ 30]; concerning Pascual Jordan (1902–1980), see [ 31].
4
For an enlightening review of the algebra of GUTs and some 40 references, see [ 38].
5
Aptly called geometric algebra by its inventor—see [ 39].
6
For any associative ring K , particularly for the division rings K = R , C , H , we denote the algebra of m × m matrices with entries in K by K [ m ] .
7
See [ 50] for a reader-friendly review of Moufang loops and for a glimpse of the personality of Ruth Moufang (1905–1971).
8
The 10-fold classification of Z 2 graded Clifford algebras also involves signs coming from squaring two antiunitary charge conjugation operators—see [ 51] Chapter 13, pp. 87–125.
9
The group G SM was earlier obtained in [ 35], starting with the Albert algebra J 3 8 ( 7).
10
The Dublin Professor of Astronomy William Rowan Hamilton (1805–1865) and the Stettin Gymnasium teacher Hermann Günter Grassmann (1809–1877) published their papers on quaternions and on “extensive algebras”, respectively, in the same year of 1844. William Kingdom Clifford (1845–1879) combined the two in a “geometric algebra” in 1878, a year before his death, aged 33, referring to both of them.
References
Baez, J.C. Can we understand the Standard Model? talk at the Workshop. In Octonions and the Standard Model; Perimeter Institute: Waterloo, ON, Canada, 2021. [ Google Scholar]
Todorov, I. Superselection of the weak hypercharge and the algebra of the Standard Model. JHEP 2021, 4, 164. [ Google Scholar] [ CrossRef]
Jordan, P. Über Verallgemeinerungsmöglichkeiten des Formalismus der Quantenmechanik. Nachr. Akad. Wiss. Göttingen Math. Phys. 1933, 41, 209217. [ Google Scholar]
Jordan, P.; von Neumann, J.; Wigner, E. On an algebraic generalization of the quantum mechanical formalism. Ann. Math. 1934, 36, 29–64. [ Google Scholar] [ CrossRef]
Connes, A. Essay on physics and noncommutative geometry. In The Interface of Mathematics and Particle Physics; Clarendon Press: Oxford, UK, 1988; Volume 24, pp. 9–48. [ Google Scholar]
Connes, A.; Lott, J. Particle models and noncommutative geometry. Nucl. Phys. Proc. Suppl. 1990, 18, 29–47. [ Google Scholar] [ CrossRef]
Dubois-Violette, M.; Kerner, R.; Madore, J. Non-commutative differential geometry and new models of gauge theory. J. Math. Phys. 1990, 31, 323–329. [ Google Scholar]
Boyle, L.; Farnsworth, S. The standard model, the Pati-Salam model, and “Jordan geometry”. New J. Phys. 2020, 22, 073023. [ Google Scholar] [ CrossRef]
Chamseddine, A.H.; Connes, A. Noncommutative geometry as a framework for unification of all fundamental interactions including gravity. Fortschr. Phys. 2010, 58, 553–600. [ Google Scholar] [ CrossRef]
Chamseddine, A.H.; Connes, A.; van Suijlekom, W.D. Grand unification in the spectral Pati-Salam model. JHEP 2015, 1511, 011. [ Google Scholar] [ CrossRef]
Chamseddine, A.H.; Iliopoulos, J.; van Suijlekom, W.D. Spectral action in matrix form. Eur. Phys. J. 2020, 80, 1045. [ Google Scholar] [ CrossRef]
van Nuland, J.D.H.; van Suijlekom, W.D. One loop corrections to the spectral action. arXiv 2021, arXiv:2107.08485. [ Google Scholar] [ CrossRef]
Baez, J.C. The octonions. Bull. Am. Math. Soc. 2002, 39, 145–205, Erratum in ibid 2005, 42, 213. [ Google Scholar] [ CrossRef]
Günaydin, M.; Gürsey, F. Quark structure and octonions. J. Math. Phys. 1973, 14, 1651–1667. [ Google Scholar] [ CrossRef]
Gürsey, F. Color quarks and octonions, The Johns Hopkins Workshop on Current Problems in High Energy Theory, 1974 Octonionic structures in particle physics. In Group Theoretical Methods in Physics; LNP 94; Springer: Berlin/Heidelberg, Germany, 1979; pp. 508–521. [ Google Scholar]
Dixon, G.M. Division algebras; spinors; idempotents; the algebraic structure of reality. arXiv 2010, arXiv:1012.1304. [ Google Scholar]
Dixon, G.M. Seeable matter; unseeable antimatter, Comment. Math. Univ. Carolin. 2014, 55, 381–386. [ Google Scholar]
Furey, C. Generations: Three prints, in colour. JHEP 2014, 10, 46. [ Google Scholar] [ CrossRef]
Furey, C. Charge quantization from a number operator. Phys. Lett. 2015, 742, 195–199. [ Google Scholar] [ CrossRef]
Furey, C. Standard model physics from an algebra? arXiv 2016, arXiv:1611.09182. [ Google Scholar]
Furey, C. SU(3) c × SU(2) L × U(1) Y(× U(1) X) as a symmetry of the division algebra ladder operators. Eur. Phys. J. 2018, 78, 375. [ Google Scholar] [ CrossRef]
Furey, C. Three generations, two unbroken gauge symmetries, and one eight-dimensional algebra. Phys. Lett. 2018, 85, 84–89. [ Google Scholar] [ CrossRef]
Furey, N.; Hughes, M.J. One generation of standard model Weyl spinors as a single copy of ℝ⊗ℂ⊗ℍ⊗ O . Phys. Lett. 2022, 827, 136259. [ Google Scholar] [ CrossRef]
Furey, N.; Hughes, M.J. Division algebraic symmetry breaking. Phys. Lett. 2022, 831, 137186. [ Google Scholar] [ CrossRef]
Dubois-Violette, M. Exceptional quantum geometry and particle physics. Nucl. Phys. 2016, 912, 426–444. [ Google Scholar] [ CrossRef]
Dubois-Violette, M. Finite quantum geometry, octonions and the theory of fundamental particles, extended notes on talk at the Workshop. In Proceedings of the Octonions and the Standard Model, Paris, France, 8 February 2021. [ Google Scholar]
Todorov, I.; Drenska, S. Composition algebras, exceptional Jordan algebra and related groups. JGSP 2017, 46, 59–93. [ Google Scholar] [ CrossRef]
Todorov, I.; Drenska, S. Octonions, exceptional Jordan algebra, and the role of the group F 4 in particle physics. Adv. in Appl. Clifford Alg. 2018, 28, 82. [ Google Scholar] [ CrossRef]
Meng, G. Euclidean Jordan algebras, hidden actions, and J-Kepler problems. J. Math. Phys. 2011, 52, 112104. [ Google Scholar] [ CrossRef]
Todorov, I. Exceptional quantum algebra for the standard model of particle physics. In Lie Theory and Its Applications in Physics; Dobrev, V.K., Ed.; Chapter 3; Springer: Singapore, 2020. [ Google Scholar]
Dahn, R.W. The Forgotten Founder of Quantum Mechanics: The Science and Politics of Physicist Pascual Jordan 1902–1980. Ph.D. Thesis, University of Chicago, Chicago, IL, USA, 2019. [ Google Scholar]
Albert, A.A. On a certain algebra of quantum mechanics. Ann. Math. 1934, 35, 65–73. [ Google Scholar] [ CrossRef]
Dubois-Violette, M.; Todorov, I. Exceptional quantum geometry and particle physics II. Nucl. Phys. 2019, 938, 751–761. [ Google Scholar] [ CrossRef]
Dubois-Violette, M.; Todorov, I. Superconnection in the spinfactor approach to particle physics. Nucl. Phys. 2020, 957, 115065. [ Google Scholar] [ CrossRef]
Todorov, I.; Dubois-Violette, M. Deducing the symmetry of the standard model from the automorphism and structure groups of the exceptional Jordan algebra. Int. J. Mod. Phys. 2018, 33, 1850118. [ Google Scholar] [ CrossRef]
Haag, R. Local Quantum Physics, Fields, Particles, Algebras; Springer: Berlin/Heidelberg, Germany, 1993. [ Google Scholar]
Pati, J. Abdus Salam, Unified Lepton-Hadron Symmetry and a Gauge Theory of the Basic Interactions. Phys. Rev. 1973, 8, 1240–1251. [ Google Scholar]
Baez, J.C.; Huerta, J. The algebra of grand unified theory. Bull. Am. Math. Soc. 2010, 47, 483–552. [ Google Scholar] [ CrossRef]
Doran, C.; Lasenby, A. Geometric Algebra for Physicists; Cambridge University Press: Cambridge, UK, 2003. [ Google Scholar]
Casalbuoni, R.; Gato, R. Unified theory of quarks and leptons based on Clifford algebras. Phys. Lett. 1979, 90, 81–86. [ Google Scholar] [ CrossRef]
Borel, A.; de Siebenthal, J. Les sous-groupe fermés de rang maximum des groupes de Lie clos. Comment. Math. Helv. 1949, 23, 200–221. [ Google Scholar] [ CrossRef]
Nielsen, H.B.; Bennett, D. Seaking a game in which the standard model group shall win. arXiv 2013, arXiv:1306.2668. [ Google Scholar]
Maladacena, J. The symmetry and simplicity of the laws of physics and the Higgs boson. Eur. J. Phys. 2015, 37, 015802. [ Google Scholar] [ CrossRef]
Fairlie, D. Higgs field and the determination of the Weinberg angle. Phys. Lett. 1979, 82, 97–100. [ Google Scholar] [ CrossRef]
Neeman, Y. Internal subgroup prediction of the Goldstone-Higgs particle mass. Phys. Lett. 1979, 81, 309–310. [ Google Scholar]
Krasnov, K. SO(9) characterization of the standard model gauge group. J. Math. Phys. 2021, 62, 021703. [ Google Scholar] [ CrossRef]
Boyle, L. The standard model, the exceptional Jordan algebra and triality. arXiv 2020, arXiv:2006.16265. [ Google Scholar]
Bryant, R.L. Notes on spinors in low dimensions. arXiv 2020, arXiv:2011.05568. [ Google Scholar]
Yokota, I. Exceptional Lie groups. arXiv 2009, arXiv:0902.0431. [ Google Scholar]
Stener, M. Moufang Loops General Theory and Visualization of Non-Associative Moufang Loops of Order 16. Ph.D. Thesis, Uppsala University, Uppsala, Sweden, 2016. [ Google Scholar]
Moore, G.W. Quantum symmetries and compatible Hamiltonians. Notes Phys. 2013, 695, 267. [ Google Scholar]
Tanimura, S. Superselection rules from measurement theory. arXiv 2011, arXiv:1112.5701. [ Google Scholar]
Barducci, A.; Buccella, F.; Casalbuoni, R.; Lusanna, L.; Sorace, E. Quantized Grassmann variables and unified theories. Phys. Lett. B 1977, 67, 344–346. [ Google Scholar] [ CrossRef]
Budinich, P.; Trautman, A. The Spinorial Chessboard; Trieste Notes in Physics; Springer: Berlin/Heidelberg, Germany, 1988; 128p. [ Google Scholar]
Dubois-Violette, M. Complex structures and the Elie Cartan approach to the theory of spinors. In Spinors, Twistors, Clifford Algebras and Quantum Deformations; Kluwer Academic Publishers: Dordrecht, The Netherlands, 1993; pp. 17–23. [ Google Scholar]
Penrose, R. Basic twistor theory, bi-twistors and split octonions, talk at the online lecture series. In Proceedings of the Octonions, Standard Model and Unification, (OSMU23), Online, 24 February–15 December 2023. [ Google Scholar]
Wick, G.C.; Wightman, A.S.; Wigner, E.P. The intrinsic parity of elementary particles. Phys. Rev. 1952, 88, 101–105. [ Google Scholar] [ CrossRef]
Wick, G.C.; Wightman, A.S.; Wigner, E.P. Superselection rule for charge. Phys. Rev. 1970, 12, 3267–3269. [ Google Scholar] [ CrossRef]
Giulini, D. Superselection rules. arXiv 2007, arXiv:0710.1516v2. [ Google Scholar]
Earman, J. Superselection rules for philosophers. Erkenntnis 2008, 69, 377–414. [ Google Scholar] [ CrossRef]
Gracia-Bondia, J.M.; Iochum, B.; Schucker, T. The Standard Model in noncommutative geometry and fermion doubling. Phys. Lett. 1998, 416, 123. [ Google Scholar] [ CrossRef]
Bochniak, A.; Sitarz, A.; Zalecki, P. Spectral action of the electroweak θ-terms for the Standard Model without fermion doubling. JHEP 2021, 12, 142. [ Google Scholar] [ CrossRef]
Krasnov, K. Spin(11, 3), particles, and octonions. J. Math. Phys. 2022, 63, 031701. [ Google Scholar] [ CrossRef]
Strursberg, R.C.; De Traubenberg, M.R. Group Theory in Physics, A Practitioner's Guide; World Scientific: Singapore, 2019. [ Google Scholar]
Mahapatra, R.N.; Pati, J.C. “Natural” left-right symmetry. Phys. Rev. 1975, 11, 2558–2561. [ Google Scholar] [ CrossRef]
Senjanović, G. Is left-right symmetry the key? Mod. Phys. Lett. 2017, 32, 173004. [ Google Scholar] [ CrossRef]
Dunsky, D.; Hall, L.J.; Harigaya, K. Sterile neutrino dark matter and leptogenesis in left-right Higgs parity. JHEP 2021, 1, 125. [ Google Scholar] [ CrossRef]
Hall, L.J.; Harigaya, K. Implications of Higgs discovery to the strong CP problem and unification. JHEP 2018, 10, 130. [ Google Scholar] [ CrossRef]
Matthai, V.; Quillen, D. Superconnections, Thom classes, and covariant differential forms. Topology 1986, 25, 85–110. [ Google Scholar] [ CrossRef]
Quillen, D. Superconnections and the Chern character. Topology 1985, 24, 85–95. [ Google Scholar] [ CrossRef]
Thierry-Mieg, J. Chirality, the missing key to the definition of the connection and curvature of a Lie-Kac superalgebra. JHEP 2021, 1, 111. [ Google Scholar] [ CrossRef]
Roepstorff, G. Superconnections and the Higgs field. J. Math. Phys. 1999, 40, 2698–2715. [ Google Scholar] [ CrossRef]
Thierry-Mieg, J. Scalar anomaly cancellation reveals the hidden algebraic structure of the quantum chiral SU(2|1) model of leptons and quarks. JHEP 2020, 10, 167. [ Google Scholar] [ CrossRef] [ PubMed]
Manogue, C.A.; Dray, T.; Wilson, R.A. Octions: An E 8 description of the Standard Model. J. Math. Phys. 2022, 63, 081703. [ Google Scholar] [ CrossRef]
Thierry-Mieg, J.; Jarvis, P.; Germini, J.; Gorelik, M. Construction of matryoshka nested indecomposable N-replications of Kac modules of quasi-reductive Lie superalgebras, including the sl( m/ n), sop(2/ n) series. arXiv 2022, arXiv:2207.06538v3. [ Google Scholar]
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
© 2023 by the author. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license ( https://creativecommons.org/licenses/by/4.0/).
Share and Cite
      
MDPI and ACS Style
Todorov, I. Octonion Internal Space Algebra for the Standard Model. Universe 2023, 9, 222. https://doi.org/10.3390/universe9050222
AMA Style
Todorov I. Octonion Internal Space Algebra for the Standard Model. Universe. 2023; 9(5):222. https://doi.org/10.3390/universe9050222
Chicago/Turabian Style
Todorov, Ivan. 2023. "Octonion Internal Space Algebra for the Standard Model" Universe 9, no. 5: 222. https://doi.org/10.3390/universe9050222
APA Style
Todorov, I. (2023). Octonion Internal Space Algebra for the Standard Model. Universe, 9(5), 222. https://doi.org/10.3390/universe9050222
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
Article Metrics
Yes
Citations
Web of Science
6
Crossref
7
ads
8
Scopus
7
Google Scholar
[click to view]
No
Article Access Statistics
Created with Highcharts 4.0.4 Article access statistics Article Views 29. Nov 30. Nov 1. Dec 2. Dec 3. Dec 4. Dec 5. Dec 6. Dec 7. Dec 8. Dec 9. Dec 10. Dec 11. Dec 12. Dec 13. Dec 14. Dec 15. Dec 16. Dec 17. Dec 18. Dec 19. Dec 20. Dec 21. Dec 22. Dec 23. Dec 24. Dec 25. Dec 26. Dec 27. Dec 28. Dec 29. Dec 30. Dec 31. Dec 1. Jan 2. Jan 3. Jan 4. Jan 5. Jan 6. Jan 7. Jan 8. Jan 9. Jan 10. Jan 11. Jan 12. Jan 13. Jan 14. Jan 15. Jan 16. Jan 17. Jan 18. Jan 19. Jan 20. Jan 21. Jan 22. Jan 23. Jan 24. Jan 25. Jan 26. Jan 27. Jan 28. Jan 29. Jan 30. Jan 31. Jan 1. Feb 2. Feb 3. Feb 4. Feb 5. Feb 6. Feb 7. Feb 8. Feb 9. Feb 10. Feb 11. Feb 12. Feb 13. Feb 14. Feb 15. Feb 16. Feb 17. Feb 18. Feb 19. Feb 20. Feb 21. Feb 22. Feb 23. Feb 24. Feb 25. Feb 26. Feb 0k 1k 2k 3k 4k
For more information on the journal statistics, click here.
Multiple requests from the same IP address are counted as one view.
Zoom | Orient | As Lines | As Sticks | As Cartoon | As Surface | Previous Scene | Next Scene
Cite
Export citation file: BibTeX | EndNote | RIS
MDPI and ACS Style
Todorov, I. Octonion Internal Space Algebra for the Standard Model. Universe 2023, 9, 222. https://doi.org/10.3390/universe9050222
AMA Style
Todorov I. Octonion Internal Space Algebra for the Standard Model. Universe. 2023; 9(5):222. https://doi.org/10.3390/universe9050222
Chicago/Turabian Style
Todorov, Ivan. 2023. "Octonion Internal Space Algebra for the Standard Model" Universe 9, no. 5: 222. https://doi.org/10.3390/universe9050222
APA Style
Todorov, I. (2023). Octonion Internal Space Algebra for the Standard Model. Universe, 9(5), 222. https://doi.org/10.3390/universe9050222
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
clear
Universe, EISSN 2218-1997, Published by MDPI
RSS Content Alert
Further Information
Article Processing Charges Pay an Invoice Open Access Policy Contact MDPI Jobs at MDPI
Guidelines
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
MDPI Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
Follow MDPI
LinkedIn Facebook X 
Subscribe to receive issue release notifications and newsletters from MDPI journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies
Climate
Clinical and Translational Neuroscience
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications
Eng
Engineering Proceedings
Entropic and Disordered Matter
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal
European Journal of Investigation in Health, Psychology and Education
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional
Fuels
Future
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease
Grasses
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences
International Journal of Environmental Medicine
International Journal of Environmental Research and Public Health
International Journal of Financial Studies
International Journal of Molecular Sciences
International Journal of Neonatal Screening
International Journal of Orofacial Myology and Myofunctional Therapy
International Journal of Plant Biology
International Journal of Topology
International Journal of Translational Medicine
International Journal of Turbomachinery, Propulsion and Power
International Medical Education
Inventions
IoT
ISPRS International Journal of Geo-Information
J
Journal of Aesthetic Medicine
Journal of Ageing and Longevity
Journal of CardioRenal Medicine
Journal of Cardiovascular Development and Disease
Journal of Clinical & Translational Ophthalmology
Journal of Clinical Medicine
Journal of Composites Science
Journal of Cybersecurity and Privacy
Journal of Dementia and Alzheimer's Disease
Journal of Developmental Biology
Journal of Experimental and Theoretical Analyses
Journal of Eye Movement Research
Journal of Functional Biomaterials
Journal of Functional Morphology and Kinesiology
Journal of Fungi
Journal of Gerontology and Geriatrics
Journal of Imaging
Journal of Innovation
Journal of Intelligence
Journal of Interdisciplinary Research Applied to Medicine
Journal of Low Power Electronics and Applications
Journal of Manufacturing and Materials Processing
Journal of Marine Science and Engineering
Journal of Market Access & Health Policy
Journal of Mind and Medical Sciences
Journal of Molecular Pathology
Journal of Nanotheranostics
Journal of Nuclear Engineering
Journal of Otorhinolaryngology, Hearing and Balance Medicine
Journal of Parks
Journal of Personalized Medicine
Journal of Pharmaceutical and BioTech Industry
Journal of Phytomedicine
Journal of Respiration
Journal of Risk and Financial Management
Journal of Sensor and Actuator Networks
Journal of the American Podiatric Medical Association
Journal of the Oman Medical Association
Journal of Theoretical and Applied Electronic Commerce Research
Journal of Vascular Diseases
Journal of Xenobiotics
Journal of Zoological and Botanical Gardens
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics
Religions
Remote Sensing
Reports
Reproductive Medicine
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine
Ruminants
Safety
Sci
Scientia Pharmaceutica
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Wild
Wind
Women
World
World Electric Vehicle Journal
Youth
Zoonotic Diseases
Select options
[-] accountaudit Accounting and Auditing [-] acoustics Acoustics [-] amh Acta Microbiologica Hellenica [-] actuators Actuators [-] adhesives Adhesives [-] admsci Administrative Sciences [-] adolescents Adolescents [-] arm Advances in Respiratory Medicine [-] aerobiology Aerobiology [-] aerospace Aerospace [-] agriculture Agriculture [-] agriengineering AgriEngineering [-] agrochemicals Agrochemicals [-] agronomy Agronomy [-] ai AI [-] aichem AI Chemistry [-] aieng AI for Engineering [-] aieduc AI in Education [-] aimed AI in Medicine [-] aimater AI Materials [-] aisens AI Sensors [-] air Air [-] algorithms Algorithms [-] allergies Allergies [-] alloys Alloys [-] analog Analog [-] analytica Analytica [-] analytics Analytics [-] anatomia Anatomia [-] anesthres Anesthesia Research [-] animals Animals [-] antibiotics Antibiotics [-] antibodies Antibodies [-] antioxidants Antioxidants [-] applbiosci Applied Biosciences [-] applmech Applied Mechanics [-] applmicrobiol Applied Microbiology [-] applnano Applied Nano [-] applsci Applied Sciences [-] asi Applied System Innovation [-] appliedchem AppliedChem [-] appliedmath AppliedMath [-] appliedphys AppliedPhys [-] aquacj Aquaculture Journal [-] architecture Architecture [-] arthropoda Arthropoda [-] arts Arts [-] astronautics Astronautics [-] astronomy Astronomy [-] atmosphere Atmosphere [-] atoms Atoms [-] audiolres Audiology Research [-] automation Automation [-] axioms Axioms [-] bacteria Bacteria [-] batteries Batteries [-] behavsci Behavioral Sciences [-] beverages Beverages [-] BDCC Big Data and Cognitive Computing [-] biochem BioChem [-] bioengineering Bioengineering [-] biologics Biologics [-] biology Biology [-] blsf Biology and Life Sciences Forum [-] biomass Biomass [-] biomechanics Biomechanics [-] biomed BioMed [-] biomedicines Biomedicines [-] biomedinformatics BioMedInformatics [-] biomimetics Biomimetics [-] biomolecules Biomolecules [-] biophysica Biophysica [-] bioresourbioprod Bioresources and Bioproducts [-] biosensors Biosensors [-] biosphere Biosphere [-] biotech BioTech [-] birds Birds [-] blockchains Blockchains [-] brainsci Brain Sciences [-] buildings Buildings [-] businesses Businesses [-] carbon C [-] cancers Cancers [-] cardiogenetics Cardiogenetics [-] cardiovascmed Cardiovascular Medicine [-] catalysts Catalysts [-] cells Cells [-] ceramics Ceramics [-] challenges Challenges [-] ChemEngineering ChemEngineering [-] chemistry Chemistry [-] chemproc Chemistry Proceedings [-] chemosensors Chemosensors [-] children Children [-] chips Chips [-] civileng CivilEng [-] cleantechnol Clean Technologies [-] climate Climate [-] ctn Clinical and Translational Neuroscience [-] clinbioenerg Clinical Bioenergetics [-] clinpract Clinics and Practice [-] clockssleep Clocks & Sleep [-] coasts Coasts [-] coatings Coatings [-] colloids Colloids and Interfaces [-] colorants Colorants [-] commodities Commodities [-] complexities Complexities [-] complications Complications [-] compounds Compounds [-] computation Computation [-] csmf Computer Sciences & Mathematics Forum [-] computers Computers [-] condensedmatter Condensed Matter [-] conservation Conservation [-] constrmater Construction Materials [-] cmd Corrosion and Materials Degradation [-] cosmetics Cosmetics [-] covid COVID [-] cmtr Craniomaxillofacial Trauma & Reconstruction [-] crops Crops [-] cryo Cryo [-] cryptography Cryptography [-] crystals Crystals [-] culture Culture [-] cimb Current Issues in Molecular Biology [-] curroncol Current Oncology [-] dairy Dairy [-] data Data [-] dentistry Dentistry Journal [-] dermato Dermato [-] dermatopathology Dermatopathology [-] designs Designs [-] diabetology Diabetology [-] diagnostics Diagnostics [-] dietetics Dietetics [-] digital Digital [-] disabilities Disabilities [-] diseases Diseases [-] diversity Diversity [-] dna DNA [-] drones Drones [-] ddc Drugs and Drug Candidates [-] dynamics Dynamics [-] earth Earth [-] ecologies Ecologies [-] econometrics Econometrics [-] economies Economies [-] education Education Sciences [-] electricity Electricity [-] electrochem Electrochem [-] electronicmat Electronic Materials [-] electronics Electronics [-] ecm Emergency Care and Medicine [-] encyclopedia Encyclopedia [-] endocrines Endocrines [-] energies Energies [-] esa Energy Storage and Applications [-] eng Eng [-] engproc Engineering Proceedings [-] edm Entropic and Disordered Matter [-] entropy Entropy [-] eesp Environmental and Earth Sciences Proceedings [-] environremediat Environmental Remediation [-] environments Environments [-] epidemiologia Epidemiologia [-] epigenomes Epigenomes [-] ebj European Burn Journal [-] ejihpe European Journal of Investigation in Health, Psychology and Education [-] famsci Family Sciences [-] fermentation Fermentation [-] fibers Fibers [-] fintech FinTech [-] fire Fire [-] fishes Fishes [-] fluids Fluids [-] foods Foods [-] forecasting Forecasting [-] forensicsci Forensic Sciences [-] forests Forests [-] fossstud Fossil Studies [-] foundations Foundations [-] fractalfract Fractal and Fractional [-] fuels Fuels [-] future Future [-] futureinternet Future Internet [-] futurepharmacol Future Pharmacology [-] futuretransp Future Transportation [-] galaxies Galaxies [-] games Games [-] gases Gases [-] gastroent Gastroenterology Insights [-] gastrointestdisord Gastrointestinal Disorders [-] gastronomy Gastronomy [-] gels Gels [-] genealogy Genealogy [-] genes Genes [-] geographies Geographies [-] geohazards GeoHazards [-] geomatics Geomatics [-] geometry Geometry [-] geosciences Geosciences [-] geotechnics Geotechnics [-] geriatrics Geriatrics [-] germs Germs [-] glacies Glacies [-] gucdd Gout, Urate, and Crystal Deposition Disease [-] grasses Grasses [-] greenhealth Green Health [-] hardware Hardware [-] healthcare Healthcare [-] hearts Hearts [-] hemato Hemato [-] hematolrep Hematology Reports [-] heritage Heritage [-] histories Histories [-] horticulturae Horticulturae [-] hospitals Hospitals [-] humanities Humanities [-] humans Humans [-] hydrobiology Hydrobiology [-] hydrogen Hydrogen [-] hydrology Hydrology [-] hydropower Hydropower [-] hygiene Hygiene [-] immuno Immuno [-] industries Industries [-] idr Infectious Disease Reports [-] informatics Informatics [-] information Information [-] infrastructures Infrastructures [-] inorganics Inorganics [-] insects Insects [-] instruments Instruments [-] iic Intelligent Infrastructure and Construction [-] ijcs International Journal of Cognitive Sciences [-] ijem International Journal of Environmental Medicine [-] ijerph International Journal of Environmental Research and Public Health [-] ijfs International Journal of Financial Studies [-] ijms International Journal of Molecular Sciences [-] IJNS International Journal of Neonatal Screening [-] ijom International Journal of Orofacial Myology and Myofunctional Therapy [-] ijpb International Journal of Plant Biology [-] ijt International Journal of Topology [-] ijtm International Journal of Translational Medicine [-] ijtpp International Journal of Turbomachinery, Propulsion and Power [-] ime International Medical Education [-] inventions Inventions [-] IoT IoT [-] ijgi ISPRS International Journal of Geo-Information [-] J J [-] jaestheticmed Journal of Aesthetic Medicine [-] jal Journal of Ageing and Longevity [-] jcrm Journal of CardioRenal Medicine [-] jcdd Journal of Cardiovascular Development and Disease [-] jcto Journal of Clinical & Translational Ophthalmology [-] jcm Journal of Clinical Medicine [-] jcs Journal of Composites Science [-] jcp Journal of Cybersecurity and Privacy [-] jdad Journal of Dementia and Alzheimer's Disease [-] jdb Journal of Developmental Biology [-] jeta Journal of Experimental and Theoretical Analyses [-] jemr Journal of Eye Movement Research [-] jfb Journal of Functional Biomaterials [-] jfmk Journal of Functional Morphology and Kinesiology [-] jof Journal of Fungi [-] jgg Journal of Gerontology and Geriatrics [-] jimaging Journal of Imaging [-] joi Journal of Innovation [-] jintelligence Journal of Intelligence [-] jdream Journal of Interdisciplinary Research Applied to Medicine [-] jlpea Journal of Low Power Electronics and Applications [-] jmmp Journal of Manufacturing and Materials Processing [-] jmse Journal of Marine Science and Engineering [-] jmahp Journal of Market Access & Health Policy [-] jmms Journal of Mind and Medical Sciences [-] jmp Journal of Molecular Pathology [-] jnt Journal of Nanotheranostics [-] jne Journal of Nuclear Engineering [-] ohbm Journal of Otorhinolaryngology, Hearing and Balance Medicine [-] jop Journal of Parks [-] jpm Journal of Personalized Medicine [-] jpbi Journal of Pharmaceutical and BioTech Industry [-] jphytomed Journal of Phytomedicine [-] jor Journal of Respiration [-] jrfm Journal of Risk and Financial Management [-] jsan Journal of Sensor and Actuator Networks [-] japma Journal of the American Podiatric Medical Association [-] joma Journal of the Oman Medical Association [-] jtaer Journal of Theoretical and Applied Electronic Commerce Research [-] jvd Journal of Vascular Diseases [-] jox Journal of Xenobiotics [-] jzbg Journal of Zoological and Botanical Gardens [-] journalmedia Journalism and Media [-] kidneydial Kidney and Dialysis [-] kinasesphosphatases Kinases and Phosphatases [-] knowledge Knowledge [-] labmed LabMed [-] laboratories Laboratories [-] land Land [-] languages Languages [-] laws Laws [-] life Life [-] lights Lights [-] limnolrev Limnological Review [-] lipidology Lipidology [-] liquids Liquids [-] literature Literature [-] livers Livers [-] logics Logics [-] logistics Logistics [-] lae Low-Altitude Economy [-] lubricants Lubricants [-] lymphatics Lymphatics [-] make Machine Learning and Knowledge Extraction [-] machines Machines [-] macromol Macromol [-] magnetism Magnetism [-] magnetochemistry Magnetochemistry [-] marinedrugs Marine Drugs [-] materials Materials [-] materproc Materials Proceedings [-] mca Mathematical and Computational Applications [-] mathematics Mathematics [-] medsci Medical Sciences [-] msf Medical Sciences Forum [-] medicina Medicina [-] medicines Medicines [-] membranes Membranes [-] merits Merits [-] metabolites Metabolites [-] metals Metals [-] meteorology Meteorology [-] methane Methane [-] mps Methods and Protocols [-] metrics Metrics [-] metrology Metrology [-] micro Micro [-] microbiolres Microbiology Research [-] microelectronics Microelectronics [-] micromachines Micromachines [-] microorganisms Microorganisms [-] microplastics Microplastics [-] microwave Microwave [-] minerals Minerals [-] mining Mining [-] modelling Modelling [-] mmphys Modern Mathematical Physics [-] molbank Molbank [-] molecules Molecules [-] multimedia Multimedia [-] mti Multimodal Technologies and Interaction [-] muscles Muscles [-] nanoenergyadv Nanoenergy Advances [-] nanomanufacturing Nanomanufacturing [-] nanomaterials Nanomaterials [-] ndt NDT [-] network Network [-] neuroglia Neuroglia [-] neuroimaging Neuroimaging [-] neurolint Neurology International [-] neurosci NeuroSci [-] nitrogen Nitrogen [-] ncrna Non-Coding RNA [-] nursrep Nursing Reports [-] nutraceuticals Nutraceuticals [-] nutrients Nutrients [-] obesities Obesities [-] occuphealth Occupational Health [-] oceans Oceans [-] onco Onco [-] optics Optics [-] oral Oral [-] organics Organics [-] organoids Organoids [-] osteology Osteology [-] oxygen Oxygen [-] pandemics Pandemics [-] parasitologia Parasitologia [-] particles Particles [-] pathogens Pathogens [-] pathophysiology Pathophysiology [-] peacestud Peace Studies [-] pediatrrep Pediatric Reports [-] pets Pets [-] pharmaceuticals Pharmaceuticals [-] pharmaceutics Pharmaceutics [-] pharmacoepidemiology Pharmacoepidemiology [-] pharmacy Pharmacy [-] philosophies Philosophies [-] photochem Photochem [-] photonics Photonics [-] phycology Phycology [-] physchem Physchem [-] psf Physical Sciences Forum [-] physics Physics [-] physiologia Physiologia [-] plants Plants [-] plasma Plasma [-] platforms Platforms [-] pollutants Pollutants [-] polymers Polymers [-] polysaccharides Polysaccharides [-] populations Populations [-] poultry Poultry [-] powders Powders [-] precisoncol Precision Oncology [-] proceedings Proceedings [-] processes Processes [-] prosthesis Prosthesis [-] proteomes Proteomes [-] psychiatryint Psychiatry International [-] psychoactives Psychoactives [-] psycholint Psychology International [-] publications Publications [-] purification Purification [-] qubs Quantum Beam Science [-] quantumrep Quantum Reports [-] quaternary Quaternary [-] radiation Radiation [-] reactions Reactions [-] realestate Real Estate [-] receptors Receptors [-] recycling Recycling [-] rsee Regional Science and Environmental Economics [-] religions Religions [-] remotesensing Remote Sensing [-] reports Reports [-] reprodmed Reproductive Medicine [-] resources Resources [-] rheumato Rheumato [-] risks Risks [-] robotics Robotics [-] rjpm Romanian Journal of Preventive Medicine [-] ruminants Ruminants [-] safety Safety [-] sci Sci [-] scipharm Scientia Pharmaceutica [-] sclerosis Sclerosis [-] seeds Seeds [-] shi Semiconductors and Heterogeneous Integration [-] sensors Sensors [-] separations Separations [-] sexes Sexes [-] signals Signals [-] sinusitis Sinusitis [-] smartcities Smart Cities [-] socsci Social Sciences [-] siuj Société Internationale d'Urologie Journal [-] societies Societies [-] software Software [-] soilsystems Soil Systems [-] solar Solar [-] solids Solids [-] spectroscj Spectroscopy Journal [-] sports Sports [-] standards Standards [-] stats Stats [-] stratsediment Stratigraphy and Sedimentology [-] stresses Stresses [-] surfaces Surfaces [-] surgeries Surgeries [-] std Surgical Techniques Development [-] sustainability Sustainability [-] suschem Sustainable Chemistry [-] symmetry Symmetry [-] synbio SynBio [-] systems Systems [-] targets Targets [-] taxonomy Taxonomy [-] technologies Technologies [-] telecom Telecom [-] textiles Textiles [-] thalassrep Thalassemia Reports [-] tae Theoretical and Applied Ergonomics [-] therapeutics Therapeutics [-] thermo Thermo [-] timespace Time and Space [-] tomography Tomography [-] tourismhosp Tourism and Hospitality [-] toxics Toxics [-] toxins Toxins [-] transplantology Transplantology [-] traumacare Trauma Care [-] higheredu Trends in Higher Education [-] tph Trends in Public Health [-] tropicalmed Tropical Medicine and Infectious Disease [-] universe Universe [-] urbansci Urban Science [-] uro Uro [-] vaccines Vaccines [-] vehicles Vehicles [-] venereology Venereology [-] vetsci Veterinary Sciences [-] vibration Vibration [-] virtualworlds Virtual Worlds [-] viruses Viruses [-] vision Vision [-] waste Waste [-] water Water [-] wild Wild [-] wind Wind [-] women Women [-] world World [-] wevj World Electric Vehicle Journal [-] youth Youth [-] zoonoticdis Zoonotic Diseases
Subscribe
© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated
Disclaimer
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
Terms and Conditions Privacy Policy
We use cookies on our website to ensure you get the best experience.
Read more about our cookies here.
Accept
Share Link
        https://www.mdpi.com/2281384
Copy
clear
Share
https://www.mdpi.com/2281384
clear
Back to Top Top
All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.  
More Information
Accept All
Deny
Powered by Usercentrics Consent Management