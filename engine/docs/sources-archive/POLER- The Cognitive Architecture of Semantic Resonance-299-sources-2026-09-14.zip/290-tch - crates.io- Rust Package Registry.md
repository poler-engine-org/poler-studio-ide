> Source: https://crates.io/crates/tch/0.0.4

tch - crates.io: Rust Package Registry
For full functionality of this site it is necessary to enable JavaScript.
[
crates.io
](https://crates.io/)
The Rust community's crate registry
Submit
Change color scheme
light
dark
system
Browse All Crates | Log in with GitHub
Change color scheme
light
dark
system
Menu
Browse All Crates
Log in with GitHub
tch v0.0.4
Rust wrappers for the PyTorch C++ api (libtorch).
# deep-learning
# machine-learning
# pytorch
Readme
47 Versions
Dependencies
Dependents
Security
tch-rs
Rust bindings for PyTorch. The goal of the tch crate is to provide some thin wrappers around the C++ PyTorch api (a.k.a. libtorch). It aims at staying as close as possible to the original C++ api. More idiomatic rust bindings could then be developed on top of this. The documentation can be found on docs.rs.
 
The code generation part for the C api on top of libtorch comes from ocaml-torch.
Getting Started
This crate requires the C++ version of PyTorch (libtorch) to be available on your system. You can either install it manually and let the build script now about it via the LIBTORCH environment variable. If not set, the build script will try downloading and extracting a pre-built binary version of libtorch.
Libtorch Manual Install
Get libtorch from the PyTorch website download section and extract the content of the zip file.
Add the following to your .bashrc or equivalent.
You should now be able to run some examples, e.g. cargo run --example basics .
Examples
The following code defines a simple model with one hidden layer.
This model can be trained on the MNIST dataset by running the following command.
More details on the training loop can be found in the detailed tutorial.
Further examples include:
A simplified version of char-rnn illustrating character level language modeling using Recurrent Neural Networks.
Some ResNet examples on CIFAR-10.
Metadata
almost 7 years ago
2018 edition
Apache-2.0
12K SLoC
48 KiB
pkg:cargo/tch@0.0.4 
Install
Run the following Cargo command in your project directory:
cargo add tch@=0.0.4
Or add the following line to your Cargo.toml:
tch = "=0.0.4"
Documentation
docs.rs/tch/0.0.4
Browse source
docs.rs/crate/tch/0.0.4/source
Repository
github.com/LaurentMazare/tch-rs
Owners
 Laurent Mazare
Categories
Science
Report crate
Stats Overview for 0.0.4 (see all)
1,530 Downloads all time
47 Versions published
Downloads over the last 90 days
Display as
Stacked
Stacked
Unstacked
Rust
rust-lang.org
Rust Foundation
The crates.io team
Get Help
The Cargo Book
Support
System Status
Report a bug
Policies
Usage Policy
Security
Privacy Policy
Code of Conduct
Data Access
Social
rust-lang/crates.io
#t-crates-io
@cratesiostatus