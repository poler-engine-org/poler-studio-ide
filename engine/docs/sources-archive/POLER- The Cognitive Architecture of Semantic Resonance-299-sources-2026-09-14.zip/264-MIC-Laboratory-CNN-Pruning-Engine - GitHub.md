> Source: https://github.com/MIC-Laboratory/CNN-Pruning-Engine

GitHub - MIC-Laboratory/CNN-Pruning-Engine
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
MIC-Laboratory / CNN-Pruning-Engine Public
Notifications You must be signed in to change notification settings
Fork 0
Star 2
2 stars 0 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 0
Pull requests 0
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
MIC-Laboratory/CNN-Pruning-Engine
main
4 Branches 0 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
Pruning Engine
Introduction
This project is a pruning engine for neural network models. It provides a set of tools and methods for pruning the weights and filters of neural networks. Pruning is a technique used to reduce the size of neural networks by removing unnecessary parameters, improving model efficiency, and reducing computational resources required for model inference.
Experiment Result
 
Figure 1: Experiment Result
Pretrain Weight for reproduce the experiment
Cifar100
Cifar10
Installation
To install the project, follow these steps:
Clone the repository:
Install the dependencies:
Usage
To use the pruning engine, follow these steps:
Import the pruning engine module:
Create an instance of the pruning engine:
Load your neural network model:
Based on the structure of the Neural Network, choose the layer that needs to be pruned. E.g. VGG16[1]
VGG16 Configuration in Python Code
Let say if I want the first conv2d layer prune 10% of the filter, the following batchnorm layer also prune 10% and the following conv2d layer prune 10% of the kernel by using L1norm criterion
Retrain the model, reference to the training repo: https://github.com/MIC-Laboratory/Pytorch-Cifar
Save the pruned model:
Pruning Methods
The pruning engine supports multiple pruning methods, including:
L1 norm pruning: Removes least important weights based on their L1 norm.
K-means clustering pruning: Clusters weights and removes weak clusters based on their importance.
Taylor pruning: Measures weight importance using the Taylor expansion and removes less important weights.
Project Structure
Pruning Engine Architecture
Figure 2: Pruning Engine UML diagram
Add your custom pruning criterion,
Create a Python file within the "pruning_criterion" folder, containing your pruning algorithm. This file should include a function that accepts the layer weight as a parameter and return ranks the filters based on their importance using your specific algorithm.
In the pruning engine file, follow the structure of other pruning methods. In the init function of the Pruning Engine, initialize your distinct pruning algorithm, similar to the way other methods are initialized.
Test Case Architecture
Figure 3: Testcase UML diagram
Adding a custom network.
To incorporate your own network for the pruning experiment,
Place your model file in the "Models" folder, and then initialize the new network in "testcase_base.py".
Create a new Python file in the "Example" folder for pruning your model, along with the corresponding config file. This file should include the following fully implemented functions: pruning, hook_function, and get_layer_store. These functions are essential for implementing the K-means and Taylor-related pruning methods. You can refer to the examples of other networks to implement them.
Here is a brief description of each function:
Reference
[1] Simonyan, K. and Zisserman, A., 2014. Very deep convolutional networks for large-scale image recognition. arXiv preprint arXiv:1409.1556.
Contributing
Contributions to this project are welcome. If you find any bugs or have suggestions for new features, please open an issue on the GitHub repository.
License
This project is licensed under the MIT License. See the LICENSE file for more information.
About
No description, website, or topics provided.
Resources
Readme
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
2 stars
Watchers
1 watching
Forks
0 forks
Report repository
Releases
No releases published
Packages 0
No packages published
Uh oh!
There was an error while loading. Please reload this page.
Contributors 2
 zhenyulincs Zhenyu Lin
 MIC-Laboratory MIC-Lab
Languages
Python 99.1%
Jupyter Notebook 0.9%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.