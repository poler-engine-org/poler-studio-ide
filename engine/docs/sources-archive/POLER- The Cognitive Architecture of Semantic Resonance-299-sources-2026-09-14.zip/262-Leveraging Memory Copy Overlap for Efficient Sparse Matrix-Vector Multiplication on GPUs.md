> Source: https://www.mdpi.com/2079-9292/12/17/3687

Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs
Loading web-font Gyre-Pagella/Normal/Regular
Next Article in Journal
A Symmetric Key and Elliptic Curve Cryptography-Based Protocol for Message Encryption in Unmanned Aerial Vehicles
Previous Article in Journal
Contactless Multi-User Virtual Hair Design Synthesis
Journals
Active Journals Find a Journal Journal Proposal Proceedings Series
[
Topics
](https://www.mdpi.com/topics)
Information
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
Open Access Policy Institutional Open Access Program Special Issues Guidelines Editorial Process Research and Publication Ethics Article Processing Charges Awards Testimonials
[
Author Services
](https://www.mdpi.com/authors/english)
Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
About
Overview Contact Careers News Press Blog
Sign In / Sign Up
Notice
You can make submissions to other journals here.
clear
Notice
You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.
Continue Cancel
clear
All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to https://www.mdpi.com/openaccess.
Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.
Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.
Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.
Original Submission Date Received: .
You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled. 
clear zoom_out_map search menu 
Journals
Active Journals
Find a Journal
Journal Proposal
Proceedings Series
Topics
Information
For Authors
For Reviewers
For Editors
For Librarians
For Publishers
For Societies
For Conference Organizers
Open Access Policy
Institutional Open Access Program
Special Issues Guidelines
Editorial Process
Research and Publication Ethics
Article Processing Charges
Awards
Testimonials
Author Services
Initiatives
Sciforum
MDPI Books
Preprints.org
Scilit
SciProfiles
Encyclopedia
JAMS
Proceedings Series
About
Overview
Contact
Careers
News
Press
Blog
Sign In / Sign Up Submit
error_outline You can access the new MDPI.com website here. Explore and share your feedback with us. close
Search for Articles:
Title / Keyword
Author / Affiliation / Email
Journal
All Journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica (AMH)
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine (ARM)
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation (ASI)
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing (BDCC)
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C (Journal of Carbon Research)
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies (Clean Technol.)
Climate
Clinical and Translational Neuroscience (CTN)
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation (CMD)
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction (CMTR)
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology (CIMB)
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates (DDC)
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications (ESA)
Eng
Engineering Proceedings
Entropic and Disordered Matter (EDM)
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal (EBJ)
European Journal of Investigation in Health, Psychology and Education (EJIHPE)
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional (Fractal Fract)
Fuels
Future
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease (GUCDD)
Grasses
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences (IJCS)
International Journal of Environmental Medicine (IJEM)
International Journal of Environmental Research and Public Health (IJERPH)
International Journal of Financial Studies (IJFS)
International Journal of Molecular Sciences (IJMS)
International Journal of Neonatal Screening (IJNS)
International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)
International Journal of Plant Biology (IJPB)
International Journal of Topology
International Journal of Translational Medicine (IJTM)
International Journal of Turbomachinery, Propulsion and Power (IJTPP)
International Medical Education (IME)
Inventions
IoT
ISPRS International Journal of Geo-Information (IJGI)
J
Journal of Aesthetic Medicine (J. Aesthetic Med.)
Journal of Ageing and Longevity (JAL)
Journal of CardioRenal Medicine (JCRM)
Journal of Cardiovascular Development and Disease (JCDD)
Journal of Clinical & Translational Ophthalmology (JCTO)
Journal of Clinical Medicine (JCM)
Journal of Composites Science (J. Compos. Sci.)
Journal of Cybersecurity and Privacy (JCP)
Journal of Dementia and Alzheimer's Disease (JDAD)
Journal of Developmental Biology (JDB)
Journal of Experimental and Theoretical Analyses (JETA)
Journal of Eye Movement Research (JEMR)
Journal of Functional Biomaterials (JFB)
Journal of Functional Morphology and Kinesiology (JFMK)
Journal of Fungi (JoF)
Journal of Gerontology and Geriatrics (JGG)
Journal of Imaging (J. Imaging)
Journal of Innovation
Journal of Intelligence (J. Intell.)
Journal of Interdisciplinary Research Applied to Medicine (JDReAM)
Journal of Low Power Electronics and Applications (JLPEA)
Journal of Manufacturing and Materials Processing (JMMP)
Journal of Marine Science and Engineering (JMSE)
Journal of Market Access & Health Policy (JMAHP)
Journal of Mind and Medical Sciences (JMMS)
Journal of Molecular Pathology (JMP)
Journal of Nanotheranostics (JNT)
Journal of Nuclear Engineering (JNE)
Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)
Journal of Parks
Journal of Personalized Medicine (JPM)
Journal of Pharmaceutical and BioTech Industry (JPBI)
Journal of Phytomedicine
Journal of Respiration (JoR)
Journal of Risk and Financial Management (JRFM)
Journal of Sensor and Actuator Networks (JSAN)
Journal of the American Podiatric Medical Association (JAPMA)
Journal of the Oman Medical Association (JOMA)
Journal of Theoretical and Applied Electronic Commerce Research (JTAER)
Journal of Vascular Diseases (JVD)
Journal of Xenobiotics (JoX)
Journal of Zoological and Botanical Gardens (JZBG)
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction (MAKE)
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications (MCA)
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols (MPs)
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction (MTI)
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA (ncRNA)
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science (QuBS)
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics (RSEE)
Religions
Remote Sensing
Reports
Reproductive Medicine (Reprod. Med.)
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine (RJPM)
Ruminants
Safety
Sci
Scientia Pharmaceutica (Sci. Pharm.)
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal (SIUJ)
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease (TropicalMed)
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Wild
Wind
Women
World
World Electric Vehicle Journal (WEVJ)
Youth
Zoonotic Diseases
Electronics
Article Type
All Article Types
Article
Review
Communication
Editorial
Abstract
Book Review
Brief Communication
Brief Report
Case Report
Clinicopathological Challenge
Comment
Commentary
Concept Paper
Conference Report
Correction
Creative
Data Descriptor
Discussion
Entry
Essay
Expression of Concern
Extended Abstract
Field Guide
Giants in Urology
Guidelines
Hypothesis
Interesting Images
Letter
New Book Received
Obituary
Opinion
Patent Summary
Perspective
Proceeding Paper
Project Report
Protocol
Registered Report
Reply
Retraction
Short Note
Study Protocol
Systematic Review
Technical Note
Tutorial
Urology around the World
Viewpoint
All Article Types Search
Advanced Search
Section
All Sections
Artificial Intelligence
Artificial Intelligence Circuits and Systems (AICAS)
Bioelectronics
Circuit and Signal Processing
Computer Science & Engineering
Electrical and Autonomous Vehicles
Electronic Materials, Devices and Applications
Electronic Multimedia
Industrial Electronics
Microelectronics
Microwave and Wireless Communications
Networks
Optoelectronics
Power Electronics
Quantum Electronics
Semiconductor Devices
Systems & Control Engineering
General
All Sections
Special Issue
All Special Issues
Additively Manufactured Flexible RF Structures for Next Generation of Wireless Applications
Advanced Electronic and Photonic Devices from the International Conference on Next-Generation Electronics & Photonics (INGEP 2024)
Advanced in Flexible Electronics and Applications
Advancements in Communication and Sensing Systems through Machine Learning
Advances and Applications in Blockchain Technology
Advances and Development in Image Processing and Pattern Recognition
Advances in Cloud and Distributed System Applications
Advances in Electronics Technology
Advances in Electronics Technology—Selected Papers From the 6th International Conference on Electronics Technology (ICET)
Advances in Electronics, Communication, and Automation
Advances in High-Efficiency AI-Enabled Edge Computing for Distributed Networking Systems
Advances in the Modeling and Simulation of Technical Systems Using Modelica
Advances of Electronics Research from Zhejiang University
Advances on Electronics for Harsh Environments
Application of Computer Vision and Pattern Recognition
Artificial Intelligence for Virtual, Mixed, and Augmented Reality Content and Interaction
Assistive Technology: Advances, Applications and Challenges
Celebrating the 200th Anniversary of the University of Manchester—Electrical and Electronic Engineering
Celebrating the 85th Anniversary of Beijing Institute of Technology—Electronic Science and Technology
Channeling a Characteristics-Driven New Paradigm for Wireless Communication Security
Converging Platform Technologies: Collaborative Innovations and Future Directions
Digital Intelligence Technology and Applications, 2nd Edition
Electronic Applications and Research in Environmental Protection and Environmental Technology
Emerging Technologies in Intelligent Software Methodologies, Tools, and Techniques (Selected Papers from SoMeT 2023)
Feature Papers
Feature Review Papers in Electronics
Flexible and Wearable Electronics: Design and Applications
Flexible Devices and Optoelectronics Technologies
Flexible Electronics: Sensors, Energy and Health
Fluidic Type Strain/Pressure Sensors for Wearable Electronics and Robotics Applications
Front-End Electronics for Radiation Detectors
Hardware and Software Co-Design in Intelligent Systems
Instrumentation, Noise, Reliability
Intelligent Mobile Robotic Systems: Decision, Planning and Control, 2nd Edition
Intelligent Resource Allocation Methods for Next Generation Wireless Cellular Systems
Interactive, Mobile and Wearable Technologies
Internet of Things (IoT) and Wearable Devices Applications in Healthcare and Disaster Healthcare
Internet of Vehicles (IoV)
IoT Applications for Renewable Energy Management and Control, 2nd Edition
Latest Developments in LED Drivers
LTCC for Space, Imaging, Telecommunication, and Medical Applications
Machine Vision and 3D Sensing in Smart Agriculture
Micro- and Nanotechnology of Wide Bandgap Semiconductors
Microwave/ Millimeter-Wave Devices and MMICs
Multi-Modal Biometrics for Surveillance and Digital Evidence Processing in Smart Cities
Multimodal Data Fusion and Computational Optimization for Intelligent Perception, 2nd Edition
Multimodal Fusion and Its Application
Multimodal Remote Sensing for Wildfires
Nano-materials Based 3D Electronics
Neuromorphic Devices and Brain-Inspired Intelligent Systems: Applications and Prospects
New CMOS Devices and Their Applications
New Insights and Techniques for Neural Networks
New Research in IoT and Applications on Sustainable Smart Farming and Agriculture
Next-Generation Sensing, Computing, and System Engineering for Large-Scale Connected and Automated Vehicle and Transportation: Celebrating the 70th Anniversary of Nanjing University of Aeronautics and Astronautics
Printed and Flexible Electronics
Pulsed Magnetic Fields and Its Applications
Quantum Computation and Its Applications
Recent Advances in Intelligent Systems
Recent Advances in IoT/Blockchain Security and Privacy
Recent Developments in Object Tracking and Computer Vision
Second Quantum Revolution: Sensing, Computing, and Transmitting
Selected Papers from the 2024 International Conference on Science and Engineering of Electronics (ICSEE'2024)
Selected Papers from the Asia Pacific Conference of the Prognostics and Health Management Society 2021
Selected Papers from Young Researchers in Flexible Electronics
Signal Processing and Analysis of Electrical Circuit
Simultaneous Localization and Mapping (SLAM) of Mobile Robots
State-of-the-Art Electronics and Informatics in Australia
State-of-the-Art Electronics in the USA
Stretchable and Wearable Electronics
Techniques and Advances in Human Activity Recognition
The Explainable AI Revolution: From Black Boxes to Transparent Insights
Towards a Sustainable Future: Addressing AI and Big Data, Energy, Climate, and Public Healthcare Challenges
VLSI Architecture Design for Digital Signal Processing
Wearable and Flexible Integrated Sensors
Wearable and Flexible Sensors in Health Monitoring and Diagnosis
Wearable Sensors Applied in Artificial Perception
Wearable Sensors for Human Position, Attitude and Motion Tracking
What Is the Future of Edge AI Accelerators? Emerging Algorithms, System Architectures, Circuit Implementations and Applications
Women in Electronics
Young Investigators in Electronics
All Special Issues
Volume 12
Issue 17
Number
Page
Logical Operator Operator
AND
OR
Search Text
Search Type
All fields
Title
Abstract
Keywords
Authors
Affiliations
Doi
Full Text
References
add_circle_outline
remove_circle_outline Search
Journals
Electronics
Volume 12
Issue 17
10.3390/electronics12173687
Submit to this Journal Review for this Journal Propose a Special Issue
► ▼ Article Menu
Article Menu
Academic Editor Shinichi Yamagiwa
Recommended Articles
Related Info Link
Google Scholar
More by Authors Links
on DOAJ
Zeng, G.
Zou, Y.
on Google Scholar
Zeng, G.
Zou, Y.
on PubMed
Zeng, G.
Zou, Y.
Article Views 2882
Citations 1
Table of Contents
Abstract
Introduction
Related Work
Background
Proposed Methods
Performance Evaluation
Conclusions
Author Contributions
Funding
Institutional Review Board Statement
Informed Consent Statement
Data Availability Statement
Conflicts of Interest
References
Altmetric share Share announcement Help format_quote Cite question_answer Discuss in SciProfiles
Need Help?
Support
Find support for a specific problem in the support section of our website.
Get Support
Feedback
Please let us know what you think of our products and services.
Give Feedback
Information
Visit our dedicated information section to learn more about MDPI.
Get Information
clear
JSmol Viewer
clear
first_page
Download PDF
settings
Order Article Reprints
Font Type:
Arial Georgia Verdana
Font Size:
Aa Aa Aa
Line Spacing:
  
Column Width:
  
Background:
Open Access Article
Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs
by
Guangsen Zeng 
Guangsen Zeng
SciProfiles Scilit Preprints.org Google Scholar  
and
Yi Zou 
Yi Zou
SciProfiles Scilit Preprints.org Google Scholar *  
School of Microelectronics, South China University of Technology, Guangzhou 510641, China *
Author to whom correspondence should be addressed.
Electronics 2023, 12(17), 3687; https://doi.org/10.3390/electronics12173687
Submission received: 2 August 2023 / Revised: 24 August 2023 / Accepted: 30 August 2023 / Published: 31 August 2023
(This article belongs to the Section Computer Science & Engineering)
Download keyboard_arrow_down
Download PDF
Download PDF with Cover
Download XML
Download Epub
Browse Figures         
Versions Notes
Article Views
Citations -
Abstract
Sparse matrix-vector multiplication (SpMV) is central to many scientific, engineering, and other applications, including machine learning. Compressed Sparse Row (CSR) is a widely used sparse matrix storage format. SpMV using the CSR format on GPU computing platforms is widely studied, where the access behavior of GPU is often the performance bottleneck. The Ampere GPU architecture recently from NVIDIA provides a new asynchronous memory copy instruction, memcpy_async, for more efficient data movement in shared memory. Leveraging the capability of this new memcpy_async instruction, we first propose the CSR-Partial-Overlap to carefully overlap the data copy from global memory to shared memory and computation, allowing us to take full advantage of the data transfer time. In addition, we design the dynamic batch partition and the dynamic threads distribution to achieve effective load balancing, avoid the overhead of fixing up partial sums, and improve thread utilization. Furthermore, we propose the CSR-Full-Overlap based on the CSR-Partial-Overlap, which takes the overlap of data transfer from host to device and SpMV kernel execution into account as well. The CSR-Full-Overlap unifies the two major overlaps in SpMV and hides the computation as much as possible in the two important access behaviors of the GPU. This allows CSR-Full-Overlap to achieve the best performance gains from both overlaps. As far as we know, this paper is the first in-depth study of how memcpy_async can be potentially applied to help accelerate SpMV computation in GPU platforms. We compare CSR-Full-Overlap to the current state-of-the-art cuSPARSE, where our experimental results show an average 2.03x performance gain and up to 2.67x performance gain.
Keywords:
sparse matrix-vector multiplication (SpMV); CSR; NVIDIA Ampere GPUs; shared memory; overlap; memcpy_async; dynamic batch partition; dynamic threads distribution
1. Introduction
Sparse matrix-vector multiplication (SpMV) is a commonly used operation in computer science and numerical computation with a wide range of applications in many fields [ 1, 2], such as large-scale linear systems [ 3], graph analytics [ 4, 5], machine learning [ 6], and so on. SpMV is often the performance bottleneck of these applications, so it is important to study how to improve the performance of SpMV. Sparse matrices generally only have a small number of nonzero elements, which are distributed in different positions of the matrix. This irregular distribution results in uncoalesced memory access behavior, which leads to huge memory access overhead [ 7]. In order to reduce such memory overhead to improve the memory access efficiency, a variety of sparse matrix storage formats have been proposed, such as Coordinate (COO) [ 7], Compressed Sparse Row (CSR) [ 7], ELLPACK (ELL) [ 7], Hybrid ELL COO (HYB) [ 7], CSR5 [ 8], etc. Among these various storage formats, CSR is the most widely used and the de facto default format. Other storage formats are inevitably involved in the problem of format conversion from CSR, causing considerable performance overhead [ 9]. Therefore, it is essential to focus on improving the performance of the SpMV algorithm based on the CSR storage format.
Graphics processing units (GPUs) provide efficient parallel computing capability through multiple stream processors and high memory bandwidth. GPU computing platforms are very attractive in the field of high performance computing [ 10]. In this paper, we focus particularly on SpMV performance accelerations on NVIDIA GPU-based computing platforms. Without loss of generality, we use the term GPUs throughout the paper to refer to NVIDIA GPUs, which are most commonly used in SpMV calculations. However, the unstructured nature of sparse matrices introduces new challenges, such as difficulty in maintaining the thread load balance and coalesced memory accesses [ 7]. Such problems inevitably all contribute to constraining the GPU to achieve the desired performance acceleration for SpMV.
In this paper, following convention, we use the term device throughout the paper to refer to NVIDIA GPUs and host to refer to CPUs [ 11], where global and shared memory are used in the context of GPUs. Based on our observations, there exist two major overlaps in the SpMV data movement, namely the global-to-shared data copy overlap and host-to-device data copy overlap. The global-to-shared overlap refers to the overlap of data copy from global memory to shared memory and computation. The device-to-host overlap refers to the overlap of data transfer from host to device and SpMV kernel execution. For convenience of discussion, we use GSOL and HDOL for short in this paper to refer to these two overlaps.
In this paper, we propose a new method to unify these two overlaps to achieve the best performance improvement for SpMV. The main contributions of this paper are summarized as follows:
We introduce the CSR-Partial-Overlap, a novel CSR-based SpMV acceleration algorithm on CUDA-enabled GPUs. This serves as the first in-depth study of how the new memcpy_async in NVIDIA Ampere GPU architecture can be applied to performance acceleration in SpMV;
We design the dynamic batch partition and the dynamic threads distribution algorithms to further improve the performance of the CSR-Partial-Overlap;
We propose the CSR-Full-Overlap based on CSR-Partial-Overlap to unify two major overlaps in SpMV data movement. CSR-Full-Overlap hides the SpMV computation as much as possible in two major types of data transfers, gaining performance acceleration from both overlaps;
We present a detailed comparative analysis of the proposed CSR-Partial-Overlap and CSR-Full-Overlap with a variety of well-known SpMV implementations. We demonstrate that CSR-Partial-Overlap outperforms all other approaches by about 1.4× on average, where CSR-Full-Overlap is superior to the widely used NVIDIA cuSPARSE, with a speedup of an average of 2.03× and up to 2.67×.
The rest of the paper is organized as follows. Section 2 provides a literature review of related work in this context. Section 3 offers a brief background review on SpMV, sparse matrix storage structures, NVIDIA Ampere GPU architecture, and CUDA. In Section 4, we describe the design philosophy of the proposed CSR-Partial-Overlap and CSR-Full-Overlap methods in detail. Next, we introduce the experimental setup in Section 5, as well as analysis and discussions on evaluation results. We conclude this paper in Section 6 with our thoughts on future research directions.
2. Related Work
GPU-based SpMV acceleration has been studied extensively [ 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]. Different optimization techniques have been proposed, focusing on introducing new storage format [ 7, 8], threads distribution [ 9, 16], shared memory leverage [ 12], automatic format selection [ 13, 20], performance analysis and autotuning [ 14, 18, 19, 21], and load balancing [ 15, 17].
Bell and Garland propose CSR-Scalar and CSR-Vector [ 7]. In CSR-Scalar, each thread processes one row of a sparse matrix. If each row of the sparse matrix has a low number of average nonzero elements, such as 1∼2, CSR-Scalar offers better performance. However, when the number of average nonzero elements per row is large, the performance is lower due to uncoalesced memory accesses. On the other hand, unlike CSR-Scalar, in CSR-Vector each warp processes one row of the matrix. This coalesced memory access improves memory access efficiency greatly. However, when short rows are encountered, the redundant threads in the warp remain idle, leading to low computational resource utilization.
In an effort to solve the shortcomings of CSR-Scalar and CSR-Vector, Liu and Schmidt propose LightSpMV [ 9], splitting warps into vectors, where each vector owns v e c t o r _ s i z e threads and processes one row of the matrix. LightSpMV first calculates the number of row-averaged nonzero elements of the sparse matrix to determine the appropriate v e c t o r _ s i z e before performing the SpMV. This approach alleviates the problems of low thread utilization and uncoalesced memory access. However, if the variance of the row lengths of the matrix is very large, using a fixed v e c c t o r _ s i z e is not effective in solving the above problem.
As regards to the memory accesses in GPUs, the access latency to global memory is the largest. For this reason, each streaming multiprocessor in a GPU is equipped with shared memory, accessible to CUDA cores within the streaming multiprocessor with a lower access latency than that of the global memory. Based on this hardware feature of GPUs, Greathouse and Daga propose the CSR-Stream [ 12], which first batch-copies nonzero elements from global memory to shared memory, then accumulates the nonzero elements of each row and writes the result back to global memory. It accesses nonzero elements in a coalesced manner, greatly improving the memory access efficiency. The CSR-Stream proves that copying data to shared memory at first and then distributing threads to compute the sum of each row is a better solution, largely thanks to shared memory having low access latency and friendly to uncoalesced memory access. However, copying data from GPU global memory to shared memory takes up thread resources. Meanwhile, as compared with other methods, it has two more accesses to shared memory, leading to poor performance on sparse matrices with an average row length greater than 32 without fully utilizing the advantages of shared memory for SpMV.
NVIDIA has recently proposed the Ampere GPU architecture [ 22], which implements a new asynchronous copy instruction, memcpy_async. It allows data loading asynchronously from global memory to shared memory. In other words, no additional thread resources are required for copying data from global memory to shared memory, thus freeing up the thread to completely focus on computational operations during such data movement. We believe that the new capability provided by memcpy_async in the Ampere architecture can be applied for accelerating SpMV operation. Particularly in this paper, we explore the opportunity of overlapping the processes of “copying nonzero elements from global memory to shared memory” and “vector processes of each matrix row” using memcpy_async to take full advantage of shared memory for SpMV to achieve overall improved performance.
In addition, before performing a SpMV operation, nonzero elements are copied from host to device. Actually, in our own experiments, we note that this process is very time-consuming, as much as more than 10 times that of the SpMV operation itself. The NVIDIA GPU attempts to solve this via the CUDA library with the concept of streams [ 11], where a stream is a sequence of commands that execute in order. Different streams, on the other hand, may execute their commands out of order with respect to one another or concurrently. Streams using the cudaMemcpyAsync function are capable of overlapping the “copy nonzero elements from host to device” and “SpMV kernel execution”, thus improving performance by hiding the latency of data movement for SpMV.
3. Background
3.1. Sparse Matrix-Vector Multiplication
In this paper, we investigate the general SpMV equation y → = α A x → + β y → [ 23], where A is a sparse m × n matrix. A has N n z nonzero elements. x → is a dense vector of size n and y → is a dense vector of size m. α and β are scalars. Let A i j denote the element of A at position ( i , j ) , x i and y i denote the i-th element of vector x → and y → . Note that the result of SpMV is finally written back into the vector y → , thus the vector y → on the right-hand side of the equation denotes the old value, and the vector y → on the left-hand side denotes the new value. SpMV can be expressed as
y i = β
· y i + α
· ∑ A i j ≠ 0 A i j
· x j
(1)
From Equation ( 1), we know that there are a total of 2 × ( N n z + m ) floating point operations (FLOPs) for a single execution of SpMV.
3.2. Compressed Sparse Row
In this paper, we focus on the SpMV optimization using the widely used sparse matrix storage format, namely the Compressed Sparse Row (CSR). Using the same m × n matrix A with N n z nonzero elements, Figure 1 below illustrates that CSR achieves efficient memory usage by storing nonzero values in three arrays r o w _ o f f s e t s , c o l u m n _ i n d i c e s and v a l u e s . 
Figure 1. CSR representation of an example sparse matrix A.
Note that the CSR format uses 0-based indices, i.e., the index for the first row or column starts from 0. The arrays v a l u e s and c o l u m n _ i n d i c e s are of length N n z , and contain the nonzero values and the column indices of those values, respectively. The array r o w _ o f f s e t s is of length m + 1 and encodes the index in v a l u e s and c o l u m n _ i n d i c e s where the given row starts. This is equivalent to r o w _ o f f s e t s [ j ] encoding the total number of nonzeros above row j. r o w _ o f f s e t s [ m ] is equal to N n z . Figure 1 is an example. Algorithm 1 shows the pseudo-code of CSR-based SpMV using CPU. Algorithm 1: Sequential SpMV based on CSR format 
3.3. Ampere GPU Architecture
NVIDIA GPUs contain multiple streaming multiprocessors (SMs), where each SM contains all necessary computation resources including CUDA cores, scheduler, dispatch units, shared memory, register files, L1 cache, etc. Shared memory is accessed by the corresponding CUDA cores in the SM they belong to with support for uncoalesced accesses [ 10, 11]. This avoids considerable access latency as compared to global memory when memory accesses are uncoalesced. Therefore, it is natural to design the SpMV computation such that we partition the data into batches to batch-copy these data from the global memory to the shared memory for the SM to perform compute on the data [ 12].
Recently, NVIDIA has released a new GPU architecture, namely the Ampere. The Ampere comes with a new powerful asynchronously shared memory copy capability, which is implemented in CUDA as the memcpy_async instruction [ 22]. As its name suggests, it offers efficient asynchronous data copy from global memory to shared memory. This means that copying data using memcpy_async no longer occupies thread resources, freeing up the thread during data movement for computation. Thus, we can leverage this mechanism to achieve efficient SGOL to improve the performance. In addition, the Ampere implements a neat hardware acceleration capability to bypass for L1 cache in memcpy_async, copying data directly from global memory to shared. Figure 2 shows the difference between memcpy_async and without memcpy_async when copying data. 
Figure 2. Illustration of the process with and without memcpy_async for data copying from global memory to shared memory.
Figure 2 offers an illustrative example of two ways for data copying from global memory to shared memory, where the array s h a r e d is stored in shared memory and the array g l o b a l is stored in global memory. When using memcpy_async, data avoids taking a long journey through the memory hierarchy, freeing the thread block as well as related registers from the task of moving data to focus on compute-centric tasks.
3.4. CUDA Streams
Operations within streams in CUDA are executed sequentially, while operations in different streams can be interleaved and, if possible, can be executed concurrently. The cudaMemcpyAsync function is used to copy data from the host memory to the device global memory asynchronously, designed to only be called by the host side. The memcpy_async function, on the other hand, can only be called by the device side, copying data asynchronously between global memory and shared memory in the device. Streams use the cudaMemcpyAsync function to achieve the overlap of data transfer from host to device and SpMV kernel execution. Algorithm 2 provides a simple code example showing how cudaMemcpyAsync is used, while Figure 3 provides an illustrative view of how the data movement and kernel execution are overlapped. Algorithm 2: Example of overlapping data transfer with kernel execution  
Figure 3. Example view of overlapping the data transfer and kernel execution for two streams.
4. Proposed Methods
The goal of this work is to describe a high-performance SpMV using CSR storage format on GPU, hiding the computation as much as possible in the two important access behaviors of the GPU. We first design the CSR-Partial-Overlap, with a two-staged pipeline design using memcpy_async, targeted directly at GSOL-type overlapping. We further design the dynamic batch partition algorithm for the CSR-Partial-Overlap to remove the overhead of fixing up partial sums and allow low cost and effective load balancing. In addition, we design the dynamic threads distribution algorithm for the computation task in the two-staged pipeline, to improve thread utilization. Finally, based on the CSR-Partial-Overlap, we propose the CSR-Full-Overlap, which is not only designed for HDOL-type overlapping but also further unifies the two major overlap types for best overall performance improvement.
4.1. CSR-Partial-Overlap
To solve the shortcoming of existing SpMV CSR algorithms discussed in Section 2, we propose the CSR-Partial-Overlap algorithm with both faster data copying and concurrency in computing and data copying. We aim to achieve these benefits by carefully and smartly applying memcpy_async to SpMV in CSR-Partial-Overlap.
Since the size of shared memory is fixed, the data is partitioned into batches before performing SpMV. We design a two-staged pipeline for CSR-Partial-Overlap to overlap data copying and computation. In addition, we dynamically distribute threads for batches to obtain better performance in data computing.
4.1.1. Partition Nonzero Elements into Batches
An intuitive strategy for batch partition is to have a fixed number of nonzero elements per batch, as shown in Figure 4. However, this approach leads to nonzero elements belonging to the same row being partitioned into two different batches. For example, in Figure 4, row4 is partitioned into batch1 and batch2, where batch1 and batch2 may be assigned to different GPU blocks for computation. The batch would have to save the partial sums of the split rows to the global memory during the computation and wait for all batch computations to finish before starting another kernel to accumulate the partial sums and write them back. Consequently, this approach results in additional global memory accesses and additional kernel overhead for partial sums accumulation. Moreover, writing the computation result of row back to y → is also a non-trivial overhead since batches are likely to differ in number of rows, implying that loads from different batches are not sufficiently well-balanced. 
Figure 4. A static batch partition results in the same number of nonzero elements in all batches.
To mitigate the above problem, we design a dynamic batch partition algorithm (executed on the host side), where batches have different numbers of nonzero elements, limited only by m a x _ b a t c h _ s i z e . The steps to partition the batches are as follows:
1.
Pick out the extra-long rows whose row length is greater than m a x _ b a t c h _ s i z e and record them in the l o n g _ r o w _ i n f o s array, as shown in line 3 in Algorithm 3;
2.
Fill each row into current the batch sequentially. Stop when the number of nonzero elements in the current batch is larger than m a x _ b a t c h _ s i z e or when it encounters an extra-long row. Record the start and end rows of the current batch in the b a t c h _ i n f o s array, as shown in line 7 to 19 in Algorithm 3;
3.
Continue to fill the remaining rows into the next batch until all rows have been partitioned into the corresponding batch. Algorithm 3: Dynamic nonzero elements batch partition algorithm 
Figure 5 shows an example of the working principle of the above dynamic batch partition algorithm, with the corresponding pseudo-code presented in where Algorithm 3. 
Figure 5. Illustration of dynamical batch partition, where each resulting batch can differ in their number of nonzero elements.
As we can see, such a dynamic batch partition method ensures that the same row is not partitioned into different batches, avoiding the overhead from accumulating partial row sums. In our observation, when m a x _ b a t c h _ s i z e is large enough, e.g., m a x _ b a t c h _ s i z e is larger than 1024, after eliminating extra-long rows larger than m a x _ b a t c h _ s i z e , interestingly, batches do not differ much in their numbers of nonzero elements. In addition, the complexity of the batch partition is only related to m, not to N n z . This implies that the overhead for performing the batch partition does not increase significantly when the sparse matrix size increases. Moreover, since the result of batch partition is only related to the number of nonzero elements in each row of the given matrix, there is no need to re-partition the batches whenever the values of its nonzero elements are changed. In addition, the latency overhead of using the CPU to partition the batches can be hidden in the data transfer process between the host and the device. This partitioning method makes each batch have a similar load, and the batches are evenly distributed among GPU blocks to execute. Instead of striving for extreme load balancing, like merge-based, we achieved effective load balancing with a low-cost partitioning method.
4.1.2. Two-Staged Pipeline Processing
As CSR-Partial-Overlap is a CUDA kernel, We assume that the kernel is configured with B GPU blocks and T threads per block. In practice, we usually set B to an integer multiple of the number of SMs on the GPU and correspondingly set T to the number of CUDA cores for each SM. To balance the load, each block processes b l o c k _ b a t c h _ n u m batches, where b l o c k _ b a t c h _ n u m = t o t a l n u m b e r o f b a t c h e s B .
For convenience of discussion, Figure 6 illustrates an example two-staged pipeline design used in CSR-Partial-Overlap. In this example, each block processes three batches. All batches are added to a queue and go through the pipeline in order. Stage 1 of the pipeline is to copy the v a l u e s array and c o l u m n _ i n d i c e s array from the global memory to shared memory using memcpy_async, as shown in line 12 to 17 in Algorithm 4. Stage 2 of the pipeline is the computation task, i.e., computing the sum of the nonzero elements of each row in the batch and writing the result back to the y → vector, as shown in line 19 to 23 in Algorithm 4. We use the term computation to refer to this computation task. We configure shared memory of size S for each block, where S = 2 × m a x _ b a t c h _ s i z e × ( sizeof ( T _ V A L ) + sizeof ( T _ C O L ) ) . This shared memory space is partitioned into two equal-sized sub shared memory spaces, as denoted by S 0 and S 1 in Figure 6. S 0 and S 1 form a shared memory resources pool for pipeline to use. 
Figure 6. Illustration of two-staged pipeline. All batches are added to a queue and go through the pipeline in order.
Note that in the beginning, both S 0 and S 1 are free. In the above example, we load the data of b a t c h 0 into S 0 . After S 0 completes the data loading, the block performs computation for b a t c h 0 , while S 1 loads the data of b a t c h 1 . The b a t c h 0 stays in S 0 while the computation is being performed, which is released when the computation is complete. Whenever S 0 is released, it can immediately be used to load data of b a t c h 2 . The pipeline repeats this behavior until all batches have been computed. Using the same example earlier, we overlap the loading of b a t c h 1 and the computation of b a t c h 0 , and the loading of b a t c h 2 and the computation of b a t c h 1 . Algorithm 4 shows the pseudo-code for this process. Algorithm 4: Copying data from global memory to shared memory overlapping with computation 
4.1.3. Dynamic Thread Distribution for Batches
In this part, we introduce the dynamic threads distribution when batches computing mentioned above. The SM in the NVIDIA GPU executes threads in groups of 32 parallel threads called warps [ 11]. In Section 2, we mentioned that the distribution of one warp per matrix row does not work well for all matrices, since the average row lengths of these matrices are varied. Therefore, we split warps into smaller vectors, each having v e c t o r _ s i z e threads, where v e c t o r _ s i z e ∈ { 1 , 2 , 4 , 8 , 16 , 32 } . Each vector computes one row of the matrix at a time, multiplies and accumulates the nonzero elements of that row, and writes the sum back to the vector y → , as shown in line 8 to 19 in Algorithm 5. After the vector completes the computation of a row, it will distribute the next matrix row until all rows within the batch have been computed, as shown in line 21 in Algorithm 5. Algorithm 5 presents the detail of this logic in pseudo-code. Note that the average row length of each batch is variable, to minimize thread idling, we dynamically select v e c t o r _ s i z e based on the average row length of the batch, as shown in Algorithm 6. This method improves thread utilization, which improves the overall performance of the CSR-Partial-Overlap. Algorithm 5: Vector process nonzero elements in the batch 
It is not too difficult to see that the proposed CSR-Partial-Overlap focuses only on the GSOL type of overlapping. It fully utilizes the time of data transfer between the global and the shared memory for computation. To the best of our knowledge, this is the first time this aspect has been considered in accelerating SpMV computations. In addition, as described in Section 4.1.1, CSR-Partial-Overlap benefits from a dynamic batch partition scheme that fixes the m a x _ b a t c h _ s i z e but not the number of nonzero elements within the batch, where each batch dynamically selects the v e c t o r _ s i z e based on the average row length. Compared to existing merge-based SpMV alternatives, CSR-Partial-Overlap achieves a low cost and effective load balancing and great performance for matrices with low N n z / m , and is much faster than CSR-Stream in the case of a large N n z / m . Algorithm 6: Select vector_size to compute according to mean 
4.2. CSR-Full-Overlap
Next, based on CSR-Partial-Overlap, we describe how to unify the HDOL type of overlapping, maximizing the benefits for accelerating SpMV performance as much as we can. Note that before using GPUs for SpMV, the data needs to be copied from the host to the device. This process causes considerable latency overhead, as much as more than 10 times that of SpMV computation itself. Therefore, we propose CSR-Full-Overlap to utilize the asynchronous copying feature of CUDA Streams to hide the SpMV kernel execution in the data transfer to improve the performance greatly.
The core of the proposed CSR-Full-Overlap relies on the fact that it unifies two types of overlapping in GPUs as introduced in Section 1. By hiding the SpMV computation in both types of data transfer, we are able to achieve substantial performance acceleration for SpMV.
The data transfer overhead between the host and the device is not only the transfer time overhead, but also the startup time overhead. Therefore, the amount of data transferred at a time has to be large enough to be cost-effective. Note that the transfer mentioned in this part refers to the transfer between the host and the device. Based on this, we partition the batches into big batches. During the experiments, we realize that when the amount of data is different for each transfer, it will lead to an additional time overhead. This overhead may seem to be relatively a small portion as compared to the total data transfer time, but nonetheless contributes to the execution time of the SpMV kernel and thus cannot be ignored.
Therefore, unlike the partition method in Section 4.1.1, where each big batch transfers the same b i g _ b a t c h _ s i z e nonzero elements (except for the last big batch), Figure 7 shows an example of the big batch partition, where nine batches are partitioned into two big batches and b i g _ b a t c h _ s i z e = 1000 . Note that a batch can be partitioned into two parts to transfer data, but it can only be processed by one kernel, in which case we assign the batch to the latter big batch kernel to process, as shown in line 9 and 15 in Algorithm 7. In this example, b a t c h 4 is processed by the b i g b a t c h 1 's kernel. The range of transfer data of b i g b a t c h 0 is [ 0 , 1000 ) , and the range of transfer data of b i g b a t c h 1 is [ 1000 , 2000 ) . The batches processed by the kernel of b i g b a t c h 0 are [ b a t c h 0 , b a t c h 3 ] , and the batches processed by the kernel of b i g b a t c h 1 are [ b a t c h 4 , b a t c h 8 ] . We use b i g _ b a t c h _ i n f o s array to store the partition information mentioned above. The pseudo-code is shown in Algorithm 7. Algorithm 7: Partition batches into big batches  
Figure 7. Illustration of big batch partition, where the b i g _ b a t c h _ s i z e is fixed.
After partitioning batches into big batches, we overlap the data transfer and kernel execution using CUDA's streams feature. Each big batch is distributed to a stream, and the c o l u m n _ i n d i c e s array and v a l u e s array within the big batch are first copied to the device using cudaMemcpyAsync. After that, the csr_partial_overlapping kernel in Algorithm 4 is called to perform the SpMV operation. The pseudo-code is shown in Algorithm 8. Since commands are executed concurrently between different streams, the SpMV kernel execution of a stream overlaps with the data transfer of the next stream.
At this point, we have completed the unification of the two overlaps in SpMV, and CSR-Full-Overlap can gain performance improvement by two overlaps at the same time. It is worth mentioning that if the b i g _ b a t c h _ s i z e is set to N n z , which means that a single big batch contains all the batches, in this case CSR-Full-Overlap will be equivalent to CSR-Partial-Overlap.
4.3. Processing of Extra-Long Rows
For rows with a number of nonzero elements larger than m a x _ b a t c h _ s i z e , we process them after all streams have finished transferring data. Due to the large load of extra-long rows, we distribute a row to a block for processing. Multiple warps within the block process a row together, using shared memory as a temporary space to save the partial sums of each warp, as shown in line 9 to line 22 in Algorithm 9. Finally, the first warp within the block accumulates these partial sums and writes the result back to the y → vector, as shown in line 24 to 32 in Algorithm 9. The pseudo-code for this process is shown in Algorithm 9. Having so many nonzero elements within a matrix is a rare case in practice, and launching an extra kernel to process these rows causes additional overhead. We can reduce the probability of this happening by increasing m a x _ b a t c h _ s i z e . Algorithm 8: Nonzero elements transfer from host to device overlapping with SpMV kernel execution  Algorithm 9: Each long row is allocated to a block to process 
5. Performance Evaluation
5.1. Experimental Setup
We use the SuiteSparse Matrix Collection, a publicly available and widely used set of sparse matrix benchmarks collected from a wide range of applications [ 2]. To evaluate the performance of the proposed method, we select a set of matrices with representative matrix sparsity characteristics from the SuiteSparse dataset. Details of this set are shown in Table 1. The N n z of these matrices ranges from 73 K to 14.8 M. The average row length ranges from 2.6 to 158.5. These matrices represent sparse features that are most common in a wide variety of applications.
Table 1. Information of sparse matrices used. 
All tests are conducted on a workstation with two AMD EPYC 7713 64-Core CPUs and 377 GB RAM, running the Ubuntu 20.04 Linux operating system. The workstation has been further equipped with an Ampere-based A40 GPU, which comprises 84 SMs with a total of 10,752 CUDA cores. It also comes with a total of 48 GB global memory. Each SM has 48 KB shared memory. All of the CUDA-based programs used for evaluation in this paper are compiled using the CUDA 11.7 toolkit with standard practice switches “-arch sm_86 -O3”, corresponding to the target GPU architecture and level 3 optimization.
5.2. Optimal Dynamic v e c t o r _ s i z e Selection
In Section 2, we mentioned that the larger the average row length of the matrix was, the larger the v e c t o r _ s i z e for obtaining optimal performance would be. In other words, it is advantageous to process matrices with shorter average row lengths when v e c t o r _ s i z e = 1 and, on the contrary, it is advantageous to process matrices with longer average row lengths when v e c t o r _ s i z e = 32 . Therefore, we segment the average row length into intervals, and each interval has a corresponding v e c t o r _ s i z e that makes the performance optimal on that interval. The boundary point between intervals we call the optimal switching point. In this experiment, we generate a series of random matrices with average row lengths ranging from 1 to 256. The range of average row lengths is large enough to cover all the optimal switching points. We then evaluate the performance of the CSR-Partial-Overlap on these random matrices. In each round of experiments, unlike Algorithm 4, we set v e c t o r _ s i z e to a fixed number in turn, where v e c t o r _ s i z e ∈ { 1 , 2 , 4 , 8 , 16 , 32 } . In this way, we can measure the optimal v e c t o r _ s i z e corresponding to each interval. The result is shown in Table 2.
Table 2. The optimal v e c t o r _ s i z e for each average row length interval. 
5.3. Evaluation of CSR-Partial-Overlap
For practical evaluation, we use the standard metric of billion floating-point operations per second (GFLOPs), which is computed as 2 ( N n z + m ) t kernel × 10 9 for Equation ( 1), where t kernel is the execution time of the CUDA kernel measured in seconds, excluding the host to device data transfer time.
cuSPARSE is a publicly available library from NVIDIA with GPU-accelerated basic linear algebra subroutines for handling sparse matrices [ 23]. cuSPARSE has excellent performance among the existing SpMV algorithms based on the CSR storage format and is thus used in this paper as a baseline for our comparative study.
We compare the proposed CSR-Partial-Overlap with three well-known SpMV algorithms based on CSR storage formats in the literature, namely cuSPARSE [ 23], LightSpMV [ 9], and merge-based [ 17]. Figure 8 illustrates the performance of various implementations in single precision on the collection of matrices listed in Table 1. Note that there is no single algorithm which is best for all the matrices. However in most cases, CSR-Partial-Overlap either outperforms all other algorithms or performs equally well. CSR-Partial-Overlap's performance is far ahead of other algorithms for matrices with average row lengths less than 16. For example, CSR-Partial-Overlap's performance on aug2d matrices is 2.2 times that of cuSPARSE. CSR-Partial-Overlap attains an average throughput of 100.1 GFLOPs compared to 71.6 for cuSPARSE [ 23], 71.7 for LightSpMV [ 9], and 71.1 for merge-based [ 17] GFLOPs. On all matrices CSR-Partial-Overlap obtains the best average performance of 1.4× that of cuSPARSE. 
Figure 8. Performance evaluation of CSR-Partial-Overlap.
5.4. Impact from b i g _ b a t c h _ s i z e
One interesting observation from our experiment is the impact from b i g _ b a t c h _ s i z e on the proposed CSR-Full-Overlap algorithms. Recall, as we have discussed in Section 4.2, that there is a host to device nonzero elements transfer time overhead of up to 10 times of SpMV computation itself. In CSR-Full-Overlap, the data transfer of each big batch overlaps with the SpMV kernel execution of the next big batch. Therefore, the SpMV kernel execution of the last big batch is not overlapped, i.e., its time overhead is not hidden in data transfer. Intuitively, the smaller the execution time of the last big batch kernel, the shorter the total time is, thus a smaller b i g _ b a t c h _ s i z e is always preferred. However, on the contrary, we find that this is not the case since the smaller the b i g _ b a t c h _ s i z e , the larger the s t r e a m _ n u m leading to additional overhead due to the increase in streams switching overhead and startup data transfer is. In our estimation, these overheads are equivalent to 0.2 ∼ 7 % of the total transfer time and thus should not be ignored. Therefore, in this paper, we choose s t r e a m _ n u m = 2 , i.e., correspondingly b i g _ b a t c h _ s i z e = N n z 2 , to avoid above potential overheads.
5.5. Evaluation of CSR-Full-Overlap
To evaluate the performance of the proposed CSR-Full-Overlap, we compare it with cuSPARSE. For a more objective and realistic view, we design the speedup metric using the following formula:
Speedup = t cuSPARSE − t CSR - Full - Overlap t CSR - Partial - Overlap + 1 ,
(2)
The t c u S P A R S E in Equation ( 2) is the total time for cuSPARSE to perform data transfer and SpMV, where the data transfer time is the time spent to transfer the c o l u m n _ i n d i c e s array and v a l u e s array from the host to the device. Similarly, the t CSR - Full - Overlap is the total time for CSR-Full-Overlap to perform data transfer and SpMV. The t CSR - Partial - Overlap is the time taken by this matrix to perform SpMV with CSR-Partial-Overlap, which excludes the time spent on data transfer between host and device. Using Speedup as a metric can effectively show the performance improvement effect brought by CSR-Full-Overlap. For example, if Speedup is 2, it means that the time for one SpMV operation using cuSPARSE is enough for CSR-Full-Overlap to perform 2 SpMV operations.
Figure 9 illustrates the Speedup of CSR-Full-Overlap versus cuSPARSE in single precision in the matrix set of Table 1. CSR-Full-Overlap, which unifies the two overlaps in SpMV, outperforms cuSPARSE in every case, with a maximum Speedup of 2.67 and an average Speedup of 2.03. This speedup is quite considerable, as Equation ( 2) indicates when cuSPARSE has completed 1 SpMV operation, CSR-Full-Overlap has already completed 2.03 SpMV operations. This proves that CSR-Full-Overlap does its best to hide the computation in two major types of data transfers to achieve the acceleration from the two overlaps in SpMV. 
Figure 9. Performance evaluation of CSR-Full-Overlap.
6. Conclusions
As a basic essential scientific computing operation which is widely used in various fields, improving SpMV performance on its dominant CSR format on popular GPU platforms is of great significance and interest to both academia and industry communities.
In this paper, we present observations and in-depth study of effective application of memcpy_async from recent NVIDIA Ampere GPUs to achieve substantial performance gain for SpMV. Firstly, we propose the CSR-Partial-Overlap for GSOL-type overlapping. After that, to remove the overhead of fixing up partial sums and allow low cost and effective load balancing, we design the dynamic batch partition algorithm for the CSR-Partial-Overlap. To further improve the performance of the CSR-Partial-Overlap, we design the dynamic threads distribution algorithm to improve thread utilization. Finally, based on the CSR-Partial-Overlap, we propose the CSR-Full-Overlap, which unifies the two major overlap types and hides the computation as much as possible in the two important access behaviors of the GPU.
We also notice that there are several aspects for future improvement. Particularly, we plan to focus on exploration in the following:
Note that the load of batch is not completely determined by the number of nonzero elements, but is also related to factors including the number of rows, the dispersion of column coordinates, etc. This suggests that it is promising to explore ways for building a low-cost and efficient batch load prediction model, potentially using machine learning methods, such that a more accurate and better load balancing is achieved;
In this paper, we only consider single matrix single vector multiplication operation. In practice, the same sparse matrix may reside in the GPU for single matrix multiple vectors multiplication operation, i.e., multiple SpMV operations. Particularly in the observation of the host to device data transfer being 10 times more than that of SpMV computation itself, we plan to explore multiple SpMV operations to bring even greater potential in performance improvement;
Our approach works under two prerequisites: 1. the GPU supports the GSOL, i.e., the threads can be freed to perform other computational tasks when copying data between shared memory and global memory; and 2. the GPU supports the HDOL, i.e., the GPU can execute other kernels when transferring data between the host memory and the device memory. Therefore, our approach can be applied to any GPUs which support the above two prerequisites. Thus, to improve the generalizability of our approach, applying our approach to GPUs provided by other manufacturers (especially AMD) is one of our future research directions.
It is our belief that this paper not only serves as the first of its kind, but also more importantly, it helps pave the way for more fruitful explorations in this dimension.
Author Contributions
Conceptualization, G.Z.; methodology, G.Z. and Y.Z.; software, G.Z.; validation, G.Z. and Y.Z.; formal analysis, G.Z. and Y.Z.; investigation, G.Z. and Y.Z.; resources, Y.Z.; data curation, G.Z.; writing—original draft preparation, G.Z.; writing—review and editing, G.Z. and Y.Z.; visualization, G.Z.; supervision, Y.Z.; project administration, G.Z.; funding acquisition, Y.Z. All authors have read and agreed to the published version of the manuscript.
Funding
This research is supported partly by the SCUT Research Startup Fund No. K3200890, as well as partly by the Guangzhou Huangpu District International Research Collaboration Fund No. 2022GH13. Any opinions, findings, and conclusions or recommendations expressed in this publication are those of the authors and do not necessarily reflect the views of the sponsoring agencies.
Institutional Review Board Statement
Not applicable.
Informed Consent Statement
Not applicable.
Data Availability Statement
The data that support the findings of this study are available on request from the corresponding author.
Conflicts of Interest
The authors declare no conflict of interest.
References
Asanovic, K.; Bodik, R.; Catanzaro, B.C.; Gebis, J.J.; Husbands, P.; Keutzer, K.; Patterson, D.A.; Plishker, W.L.; Shalf, J.; Williams, S.W.; et al. The Landscape of Parallel Computing Research: A View from Berkeley; Technical Report UCB/EECS-2006-183; EECS Department, University of California: Berkeley, CA, USA, 2006. [ Google Scholar]
Davis, T.A.; Hu, Y. The University of Florida Sparse Matrix Collection. ACM Trans. Math. Softw. 2011, 38, 1–25. [ Google Scholar] [ CrossRef]
Ahamed, A.K.C.; Magoulès, F. Efficient implementation of Jacobi iterative method for large sparse linear systems on graphic processing units. J. Supercomput. 2016, 73, 3411–3432. [ Google Scholar] [ CrossRef]
Gilbert, J.R.; Reinhardt, S.; Shah, V.B. High-performance graph algorithms from parallel sparse matrices. In Proceedings of the Name of the 8th International Workshop (PARA 2006), Umea, Sweden, 18–21 June 2006. [ Google Scholar]
Yang, X.; Parthasarathy, S.; Sadayappan, P. Fast sparse matrix-vector multiplication on GPUs: Implications for graph mining. arXiv 2011, arXiv:1103.2405. [ Google Scholar]
Demirci, G.V.; Ferhatosmanoglu, H. Partitioning Sparse Deep Neural Networks for Scalable Training and Inference. In Proceedings of the ACM International Conference on Supercomputing, Virtual, 14–17 June 2021; Association for Computing Machinery: New York, NY, USA, 2021; pp. 254–265. [ Google Scholar]
Bell, N.; Garland, M. Implementing sparse matrix-vector multiplication on throughput-oriented processors. In Proceedings of the Conference on High Performance Computing Networking, Storage and Analysis, Portland, OR, USA, 14–20 November 2009; pp. 1–11. [ Google Scholar]
Liu, W.; Vinter, B. CSR5: An Efficient Storage Format for Cross-Platform Sparse Matrix-Vector Multiplication. In Proceedings of the 29th ACM on International Conference on Supercomputing, Newport Beach, CA, USA, 8–11 June 2015. [ Google Scholar]
Liu, Y.; Schmidt, B. LightSpMV: Faster CSR-based sparse matrix-vector multiplication on CUDA-enabled GPUs. In Proceedings of the 2015 IEEE 26th International Conference on Application-Specific Systems, Architectures and Processors (ASAP), Toronto, ON, Canada, 27–29 July 2015; pp. 82–89. [ Google Scholar]
Filippone, S.; Cardellini, V.; Barbieri, D.; Fanfarillo, A. Sparse Matrix-Vector Multiplication on GPGPUs. ACM Trans. Math. Softw. 2017, 43, 1–49. [ Google Scholar] [ CrossRef]
CUDA C++ Programming Guide. Available online: https://docs.nvidia.com/cuda/cuda-c-programming-guide/index.html#the-benefits-of-using-gpus (accessed on 15 July 2023).
Greathouse, J.L.; Daga, M. Efficient sparse matrix-vector multiplication on GPUs using the CSR storage format. In Proceedings of the SC14: International Conference for High Performance Computing, Networking, Storage and Analysis, New Orleans, LA, USA, 16–21 November 2014; pp. 769–780. [ Google Scholar]
Nisa, I.; Siegel, C.; Rajam, A.S.; Vishnu, A.; Sadayappan, P. Effective Machine Learning Based Format Selection and Performance Modeling for SpMV on GPUs. In Proceedings of the 2018 IEEE International Parallel and Distributed Processing Symposium Workshops (IPDPSW), Vancouver, BC, Canada, 21–25 May 2018; pp. 1056–1065. [ Google Scholar]
Choi, J.W.; Singh, A.; Vuduc, R.W. Model-driven Autotuning of Sparse Matrix-vector Multiply on GPUs. SIGPLAN Not. 2010, 45, 115–126. [ Google Scholar] [ CrossRef]
Flegar, G.; Anzt, H. Overcoming Load Imbalance for Irregular Sparse Matrices. In Proceedings of the Seventh Workshop on Irregular Applications: Architectures and Algorithms, Denver, CO, USA, 12–17 November 2017; ACM: New York, NY, USA, 2017; pp. 1–8. [ Google Scholar]
Ashari, A.; Sedaghati, N.; Eisenlohr, J.; Parthasarathy, S.; Sadayappan, P. Fast Sparse Matrix-vector Multiplication on GPUs for Graph Applications. In Proceedings of the International Conference for High Performance Computing, Networking, Storage and Analysis, New Orleans, LA, USA, 16–21 November 2014; IEEE Press: Piscataway, NJ, USA, 2014; pp. 781–792. [ Google Scholar]
Merrill, D.; Garland, M. Merge-Based Parallel Sparse Matrix-Vector Multiplication. In Proceedings of the SC16: International Conference for High Performance Computing, Networking, Storage and Analysis, Salt Lake City, UT, USA, 13–18 November 2016. [ Google Scholar]
Tsai, Y.M.; Cojean, T.; Anzt, H. Evaluating the Performance of NVIDIA's A100 Ampere GPU for Sparse Linear Algebra Computations. arXiv 2020, arXiv:2008.08478. [ Google Scholar]
Anzt, H.; Tsai, Y.M.; Abdelfattah, A.; Cojean, T.; Dongarra, J. Evaluating the Performance of NVIDIA's A100 Ampere GPU for Sparse and Batched Computations. In Proceedings of the 2020 IEEE/ACM Performance Modeling, Benchmarking and Simulation of High Performance Computer Systems (PMBS), Atlanta, GA, USA, 12 November 2020; pp. 26–38. [ Google Scholar]
Niu, Y.; Lu, Z.; Dong, M.; Jin, Z.; Liu, W.; Tan, G. TileSpMV: A Tiled Algorithm for Sparse Matrix-Vector Multiplication on GPUs. In Proceedings of the 2021 IEEE International Parallel and Distributed Processing Symposium (IPDPS), Portland, OR, USA, 28 June 2021; pp. 68–78. [ Google Scholar]
Ahmed, M.; Usman, S.; Shah, N.A.; Ashraf, M.U.; Alghamdi, A.M.; Bahadded, A.A.; Almarhabi, K.A. AAQAL: A Machine Learning-Based Tool for Performance Optimization of Parallel SPMV Computations Using Block CSR. Appl. Sci. 2022, 12, 7073. [ Google Scholar] [ CrossRef]
Tuning CUDA Applications for NVIDIA Ampere GPU Architecture. Available online: https://docs.nvidia.com/cuda/ampere-tuning-guide/index.html#asynchronous-data-copy-from-global-memory-to-shared-memory (accessed on 15 July 2023).
cuSPARSE Library. Available online: https://docs.nvidia.com/cuda/cusparse/index.html (accessed on 15 July 2023).
Figure 1. CSR representation of an example sparse matrix A.
Figure 2. Illustration of the process with and without memcpy_async for data copying from global memory to shared memory.
Figure 3. Example view of overlapping the data transfer and kernel execution for two streams.
Figure 4. A static batch partition results in the same number of nonzero elements in all batches.
Figure 5. Illustration of dynamical batch partition, where each resulting batch can differ in their number of nonzero elements.
Figure 6. Illustration of two-staged pipeline. All batches are added to a queue and go through the pipeline in order.
Figure 7. Illustration of big batch partition, where the b i g _ b a t c h _ s i z e is fixed.
Figure 8. Performance evaluation of CSR-Partial-Overlap.
Figure 9. Performance evaluation of CSR-Full-Overlap.
Table 1. Information of sparse matrices used.
Table 2. The optimal v e c t o r _ s i z e for each average row length interval.
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
© 2023 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license ( https://creativecommons.org/licenses/by/4.0/).
Share and Cite
      
MDPI and ACS Style
Zeng, G.; Zou, Y. Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs. Electronics 2023, 12, 3687. https://doi.org/10.3390/electronics12173687
AMA Style
Zeng G, Zou Y. Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs. Electronics. 2023; 12(17):3687. https://doi.org/10.3390/electronics12173687
Chicago/Turabian Style
Zeng, Guangsen, and Yi Zou. 2023. "Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs" Electronics 12, no. 17: 3687. https://doi.org/10.3390/electronics12173687
APA Style
Zeng, G., & Zou, Y. (2023). Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs. Electronics, 12(17), 3687. https://doi.org/10.3390/electronics12173687
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
Article Metrics
Yes
Citations
Crossref
1
Scopus
1
Web of Science
1
Google Scholar
[click to view]
No
Article Access Statistics
Created with Highcharts 4.0.4 Article access statistics Article Views 29. Nov 30. Nov 1. Dec 2. Dec 3. Dec 4. Dec 5. Dec 6. Dec 7. Dec 8. Dec 9. Dec 10. Dec 11. Dec 12. Dec 13. Dec 14. Dec 15. Dec 16. Dec 17. Dec 18. Dec 19. Dec 20. Dec 21. Dec 22. Dec 23. Dec 24. Dec 25. Dec 26. Dec 27. Dec 28. Dec 29. Dec 30. Dec 31. Dec 1. Jan 2. Jan 3. Jan 4. Jan 5. Jan 6. Jan 7. Jan 8. Jan 9. Jan 10. Jan 11. Jan 12. Jan 13. Jan 14. Jan 15. Jan 16. Jan 17. Jan 18. Jan 19. Jan 20. Jan 21. Jan 22. Jan 23. Jan 24. Jan 25. Jan 26. Jan 27. Jan 28. Jan 29. Jan 30. Jan 31. Jan 1. Feb 2. Feb 3. Feb 4. Feb 5. Feb 6. Feb 7. Feb 8. Feb 9. Feb 10. Feb 11. Feb 12. Feb 13. Feb 14. Feb 15. Feb 16. Feb 17. Feb 18. Feb 19. Feb 20. Feb 21. Feb 22. Feb 23. Feb 24. Feb 25. Feb 26. Feb 0k 1k 2k 3k 4k
For more information on the journal statistics, click here.
Multiple requests from the same IP address are counted as one view.
Zoom | Orient | As Lines | As Sticks | As Cartoon | As Surface | Previous Scene | Next Scene
Cite
Export citation file: BibTeX | EndNote | RIS
MDPI and ACS Style
Zeng, G.; Zou, Y. Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs. Electronics 2023, 12, 3687. https://doi.org/10.3390/electronics12173687
AMA Style
Zeng G, Zou Y. Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs. Electronics. 2023; 12(17):3687. https://doi.org/10.3390/electronics12173687
Chicago/Turabian Style
Zeng, Guangsen, and Yi Zou. 2023. "Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs" Electronics 12, no. 17: 3687. https://doi.org/10.3390/electronics12173687
APA Style
Zeng, G., & Zou, Y. (2023). Leveraging Memory Copy Overlap for Efficient Sparse Matrix-Vector Multiplication on GPUs. Electronics, 12(17), 3687. https://doi.org/10.3390/electronics12173687
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
clear
Electronics, EISSN 2079-9292, Published by MDPI
RSS Content Alert
Further Information
Article Processing Charges Pay an Invoice Open Access Policy Contact MDPI Jobs at MDPI
Guidelines
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
MDPI Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
Follow MDPI
LinkedIn Facebook X 
Subscribe to receive issue release notifications and newsletters from MDPI journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies
Climate
Clinical and Translational Neuroscience
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications
Eng
Engineering Proceedings
Entropic and Disordered Matter
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal
European Journal of Investigation in Health, Psychology and Education
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional
Fuels
Future
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease
Grasses
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences
International Journal of Environmental Medicine
International Journal of Environmental Research and Public Health
International Journal of Financial Studies
International Journal of Molecular Sciences
International Journal of Neonatal Screening
International Journal of Orofacial Myology and Myofunctional Therapy
International Journal of Plant Biology
International Journal of Topology
International Journal of Translational Medicine
International Journal of Turbomachinery, Propulsion and Power
International Medical Education
Inventions
IoT
ISPRS International Journal of Geo-Information
J
Journal of Aesthetic Medicine
Journal of Ageing and Longevity
Journal of CardioRenal Medicine
Journal of Cardiovascular Development and Disease
Journal of Clinical & Translational Ophthalmology
Journal of Clinical Medicine
Journal of Composites Science
Journal of Cybersecurity and Privacy
Journal of Dementia and Alzheimer's Disease
Journal of Developmental Biology
Journal of Experimental and Theoretical Analyses
Journal of Eye Movement Research
Journal of Functional Biomaterials
Journal of Functional Morphology and Kinesiology
Journal of Fungi
Journal of Gerontology and Geriatrics
Journal of Imaging
Journal of Innovation
Journal of Intelligence
Journal of Interdisciplinary Research Applied to Medicine
Journal of Low Power Electronics and Applications
Journal of Manufacturing and Materials Processing
Journal of Marine Science and Engineering
Journal of Market Access & Health Policy
Journal of Mind and Medical Sciences
Journal of Molecular Pathology
Journal of Nanotheranostics
Journal of Nuclear Engineering
Journal of Otorhinolaryngology, Hearing and Balance Medicine
Journal of Parks
Journal of Personalized Medicine
Journal of Pharmaceutical and BioTech Industry
Journal of Phytomedicine
Journal of Respiration
Journal of Risk and Financial Management
Journal of Sensor and Actuator Networks
Journal of the American Podiatric Medical Association
Journal of the Oman Medical Association
Journal of Theoretical and Applied Electronic Commerce Research
Journal of Vascular Diseases
Journal of Xenobiotics
Journal of Zoological and Botanical Gardens
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics
Religions
Remote Sensing
Reports
Reproductive Medicine
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine
Ruminants
Safety
Sci
Scientia Pharmaceutica
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Wild
Wind
Women
World
World Electric Vehicle Journal
Youth
Zoonotic Diseases
Select options
[-] accountaudit Accounting and Auditing [-] acoustics Acoustics [-] amh Acta Microbiologica Hellenica [-] actuators Actuators [-] adhesives Adhesives [-] admsci Administrative Sciences [-] adolescents Adolescents [-] arm Advances in Respiratory Medicine [-] aerobiology Aerobiology [-] aerospace Aerospace [-] agriculture Agriculture [-] agriengineering AgriEngineering [-] agrochemicals Agrochemicals [-] agronomy Agronomy [-] ai AI [-] aichem AI Chemistry [-] aieng AI for Engineering [-] aieduc AI in Education [-] aimed AI in Medicine [-] aimater AI Materials [-] aisens AI Sensors [-] air Air [-] algorithms Algorithms [-] allergies Allergies [-] alloys Alloys [-] analog Analog [-] analytica Analytica [-] analytics Analytics [-] anatomia Anatomia [-] anesthres Anesthesia Research [-] animals Animals [-] antibiotics Antibiotics [-] antibodies Antibodies [-] antioxidants Antioxidants [-] applbiosci Applied Biosciences [-] applmech Applied Mechanics [-] applmicrobiol Applied Microbiology [-] applnano Applied Nano [-] applsci Applied Sciences [-] asi Applied System Innovation [-] appliedchem AppliedChem [-] appliedmath AppliedMath [-] appliedphys AppliedPhys [-] aquacj Aquaculture Journal [-] architecture Architecture [-] arthropoda Arthropoda [-] arts Arts [-] astronautics Astronautics [-] astronomy Astronomy [-] atmosphere Atmosphere [-] atoms Atoms [-] audiolres Audiology Research [-] automation Automation [-] axioms Axioms [-] bacteria Bacteria [-] batteries Batteries [-] behavsci Behavioral Sciences [-] beverages Beverages [-] BDCC Big Data and Cognitive Computing [-] biochem BioChem [-] bioengineering Bioengineering [-] biologics Biologics [-] biology Biology [-] blsf Biology and Life Sciences Forum [-] biomass Biomass [-] biomechanics Biomechanics [-] biomed BioMed [-] biomedicines Biomedicines [-] biomedinformatics BioMedInformatics [-] biomimetics Biomimetics [-] biomolecules Biomolecules [-] biophysica Biophysica [-] bioresourbioprod Bioresources and Bioproducts [-] biosensors Biosensors [-] biosphere Biosphere [-] biotech BioTech [-] birds Birds [-] blockchains Blockchains [-] brainsci Brain Sciences [-] buildings Buildings [-] businesses Businesses [-] carbon C [-] cancers Cancers [-] cardiogenetics Cardiogenetics [-] cardiovascmed Cardiovascular Medicine [-] catalysts Catalysts [-] cells Cells [-] ceramics Ceramics [-] challenges Challenges [-] ChemEngineering ChemEngineering [-] chemistry Chemistry [-] chemproc Chemistry Proceedings [-] chemosensors Chemosensors [-] children Children [-] chips Chips [-] civileng CivilEng [-] cleantechnol Clean Technologies [-] climate Climate [-] ctn Clinical and Translational Neuroscience [-] clinbioenerg Clinical Bioenergetics [-] clinpract Clinics and Practice [-] clockssleep Clocks & Sleep [-] coasts Coasts [-] coatings Coatings [-] colloids Colloids and Interfaces [-] colorants Colorants [-] commodities Commodities [-] complexities Complexities [-] complications Complications [-] compounds Compounds [-] computation Computation [-] csmf Computer Sciences & Mathematics Forum [-] computers Computers [-] condensedmatter Condensed Matter [-] conservation Conservation [-] constrmater Construction Materials [-] cmd Corrosion and Materials Degradation [-] cosmetics Cosmetics [-] covid COVID [-] cmtr Craniomaxillofacial Trauma & Reconstruction [-] crops Crops [-] cryo Cryo [-] cryptography Cryptography [-] crystals Crystals [-] culture Culture [-] cimb Current Issues in Molecular Biology [-] curroncol Current Oncology [-] dairy Dairy [-] data Data [-] dentistry Dentistry Journal [-] dermato Dermato [-] dermatopathology Dermatopathology [-] designs Designs [-] diabetology Diabetology [-] diagnostics Diagnostics [-] dietetics Dietetics [-] digital Digital [-] disabilities Disabilities [-] diseases Diseases [-] diversity Diversity [-] dna DNA [-] drones Drones [-] ddc Drugs and Drug Candidates [-] dynamics Dynamics [-] earth Earth [-] ecologies Ecologies [-] econometrics Econometrics [-] economies Economies [-] education Education Sciences [-] electricity Electricity [-] electrochem Electrochem [-] electronicmat Electronic Materials [-] electronics Electronics [-] ecm Emergency Care and Medicine [-] encyclopedia Encyclopedia [-] endocrines Endocrines [-] energies Energies [-] esa Energy Storage and Applications [-] eng Eng [-] engproc Engineering Proceedings [-] edm Entropic and Disordered Matter [-] entropy Entropy [-] eesp Environmental and Earth Sciences Proceedings [-] environremediat Environmental Remediation [-] environments Environments [-] epidemiologia Epidemiologia [-] epigenomes Epigenomes [-] ebj European Burn Journal [-] ejihpe European Journal of Investigation in Health, Psychology and Education [-] famsci Family Sciences [-] fermentation Fermentation [-] fibers Fibers [-] fintech FinTech [-] fire Fire [-] fishes Fishes [-] fluids Fluids [-] foods Foods [-] forecasting Forecasting [-] forensicsci Forensic Sciences [-] forests Forests [-] fossstud Fossil Studies [-] foundations Foundations [-] fractalfract Fractal and Fractional [-] fuels Fuels [-] future Future [-] futureinternet Future Internet [-] futurepharmacol Future Pharmacology [-] futuretransp Future Transportation [-] galaxies Galaxies [-] games Games [-] gases Gases [-] gastroent Gastroenterology Insights [-] gastrointestdisord Gastrointestinal Disorders [-] gastronomy Gastronomy [-] gels Gels [-] genealogy Genealogy [-] genes Genes [-] geographies Geographies [-] geohazards GeoHazards [-] geomatics Geomatics [-] geometry Geometry [-] geosciences Geosciences [-] geotechnics Geotechnics [-] geriatrics Geriatrics [-] germs Germs [-] glacies Glacies [-] gucdd Gout, Urate, and Crystal Deposition Disease [-] grasses Grasses [-] greenhealth Green Health [-] hardware Hardware [-] healthcare Healthcare [-] hearts Hearts [-] hemato Hemato [-] hematolrep Hematology Reports [-] heritage Heritage [-] histories Histories [-] horticulturae Horticulturae [-] hospitals Hospitals [-] humanities Humanities [-] humans Humans [-] hydrobiology Hydrobiology [-] hydrogen Hydrogen [-] hydrology Hydrology [-] hydropower Hydropower [-] hygiene Hygiene [-] immuno Immuno [-] industries Industries [-] idr Infectious Disease Reports [-] informatics Informatics [-] information Information [-] infrastructures Infrastructures [-] inorganics Inorganics [-] insects Insects [-] instruments Instruments [-] iic Intelligent Infrastructure and Construction [-] ijcs International Journal of Cognitive Sciences [-] ijem International Journal of Environmental Medicine [-] ijerph International Journal of Environmental Research and Public Health [-] ijfs International Journal of Financial Studies [-] ijms International Journal of Molecular Sciences [-] IJNS International Journal of Neonatal Screening [-] ijom International Journal of Orofacial Myology and Myofunctional Therapy [-] ijpb International Journal of Plant Biology [-] ijt International Journal of Topology [-] ijtm International Journal of Translational Medicine [-] ijtpp International Journal of Turbomachinery, Propulsion and Power [-] ime International Medical Education [-] inventions Inventions [-] IoT IoT [-] ijgi ISPRS International Journal of Geo-Information [-] J J [-] jaestheticmed Journal of Aesthetic Medicine [-] jal Journal of Ageing and Longevity [-] jcrm Journal of CardioRenal Medicine [-] jcdd Journal of Cardiovascular Development and Disease [-] jcto Journal of Clinical & Translational Ophthalmology [-] jcm Journal of Clinical Medicine [-] jcs Journal of Composites Science [-] jcp Journal of Cybersecurity and Privacy [-] jdad Journal of Dementia and Alzheimer's Disease [-] jdb Journal of Developmental Biology [-] jeta Journal of Experimental and Theoretical Analyses [-] jemr Journal of Eye Movement Research [-] jfb Journal of Functional Biomaterials [-] jfmk Journal of Functional Morphology and Kinesiology [-] jof Journal of Fungi [-] jgg Journal of Gerontology and Geriatrics [-] jimaging Journal of Imaging [-] joi Journal of Innovation [-] jintelligence Journal of Intelligence [-] jdream Journal of Interdisciplinary Research Applied to Medicine [-] jlpea Journal of Low Power Electronics and Applications [-] jmmp Journal of Manufacturing and Materials Processing [-] jmse Journal of Marine Science and Engineering [-] jmahp Journal of Market Access & Health Policy [-] jmms Journal of Mind and Medical Sciences [-] jmp Journal of Molecular Pathology [-] jnt Journal of Nanotheranostics [-] jne Journal of Nuclear Engineering [-] ohbm Journal of Otorhinolaryngology, Hearing and Balance Medicine [-] jop Journal of Parks [-] jpm Journal of Personalized Medicine [-] jpbi Journal of Pharmaceutical and BioTech Industry [-] jphytomed Journal of Phytomedicine [-] jor Journal of Respiration [-] jrfm Journal of Risk and Financial Management [-] jsan Journal of Sensor and Actuator Networks [-] japma Journal of the American Podiatric Medical Association [-] joma Journal of the Oman Medical Association [-] jtaer Journal of Theoretical and Applied Electronic Commerce Research [-] jvd Journal of Vascular Diseases [-] jox Journal of Xenobiotics [-] jzbg Journal of Zoological and Botanical Gardens [-] journalmedia Journalism and Media [-] kidneydial Kidney and Dialysis [-] kinasesphosphatases Kinases and Phosphatases [-] knowledge Knowledge [-] labmed LabMed [-] laboratories Laboratories [-] land Land [-] languages Languages [-] laws Laws [-] life Life [-] lights Lights [-] limnolrev Limnological Review [-] lipidology Lipidology [-] liquids Liquids [-] literature Literature [-] livers Livers [-] logics Logics [-] logistics Logistics [-] lae Low-Altitude Economy [-] lubricants Lubricants [-] lymphatics Lymphatics [-] make Machine Learning and Knowledge Extraction [-] machines Machines [-] macromol Macromol [-] magnetism Magnetism [-] magnetochemistry Magnetochemistry [-] marinedrugs Marine Drugs [-] materials Materials [-] materproc Materials Proceedings [-] mca Mathematical and Computational Applications [-] mathematics Mathematics [-] medsci Medical Sciences [-] msf Medical Sciences Forum [-] medicina Medicina [-] medicines Medicines [-] membranes Membranes [-] merits Merits [-] metabolites Metabolites [-] metals Metals [-] meteorology Meteorology [-] methane Methane [-] mps Methods and Protocols [-] metrics Metrics [-] metrology Metrology [-] micro Micro [-] microbiolres Microbiology Research [-] microelectronics Microelectronics [-] micromachines Micromachines [-] microorganisms Microorganisms [-] microplastics Microplastics [-] microwave Microwave [-] minerals Minerals [-] mining Mining [-] modelling Modelling [-] mmphys Modern Mathematical Physics [-] molbank Molbank [-] molecules Molecules [-] multimedia Multimedia [-] mti Multimodal Technologies and Interaction [-] muscles Muscles [-] nanoenergyadv Nanoenergy Advances [-] nanomanufacturing Nanomanufacturing [-] nanomaterials Nanomaterials [-] ndt NDT [-] network Network [-] neuroglia Neuroglia [-] neuroimaging Neuroimaging [-] neurolint Neurology International [-] neurosci NeuroSci [-] nitrogen Nitrogen [-] ncrna Non-Coding RNA [-] nursrep Nursing Reports [-] nutraceuticals Nutraceuticals [-] nutrients Nutrients [-] obesities Obesities [-] occuphealth Occupational Health [-] oceans Oceans [-] onco Onco [-] optics Optics [-] oral Oral [-] organics Organics [-] organoids Organoids [-] osteology Osteology [-] oxygen Oxygen [-] pandemics Pandemics [-] parasitologia Parasitologia [-] particles Particles [-] pathogens Pathogens [-] pathophysiology Pathophysiology [-] peacestud Peace Studies [-] pediatrrep Pediatric Reports [-] pets Pets [-] pharmaceuticals Pharmaceuticals [-] pharmaceutics Pharmaceutics [-] pharmacoepidemiology Pharmacoepidemiology [-] pharmacy Pharmacy [-] philosophies Philosophies [-] photochem Photochem [-] photonics Photonics [-] phycology Phycology [-] physchem Physchem [-] psf Physical Sciences Forum [-] physics Physics [-] physiologia Physiologia [-] plants Plants [-] plasma Plasma [-] platforms Platforms [-] pollutants Pollutants [-] polymers Polymers [-] polysaccharides Polysaccharides [-] populations Populations [-] poultry Poultry [-] powders Powders [-] precisoncol Precision Oncology [-] proceedings Proceedings [-] processes Processes [-] prosthesis Prosthesis [-] proteomes Proteomes [-] psychiatryint Psychiatry International [-] psychoactives Psychoactives [-] psycholint Psychology International [-] publications Publications [-] purification Purification [-] qubs Quantum Beam Science [-] quantumrep Quantum Reports [-] quaternary Quaternary [-] radiation Radiation [-] reactions Reactions [-] realestate Real Estate [-] receptors Receptors [-] recycling Recycling [-] rsee Regional Science and Environmental Economics [-] religions Religions [-] remotesensing Remote Sensing [-] reports Reports [-] reprodmed Reproductive Medicine [-] resources Resources [-] rheumato Rheumato [-] risks Risks [-] robotics Robotics [-] rjpm Romanian Journal of Preventive Medicine [-] ruminants Ruminants [-] safety Safety [-] sci Sci [-] scipharm Scientia Pharmaceutica [-] sclerosis Sclerosis [-] seeds Seeds [-] shi Semiconductors and Heterogeneous Integration [-] sensors Sensors [-] separations Separations [-] sexes Sexes [-] signals Signals [-] sinusitis Sinusitis [-] smartcities Smart Cities [-] socsci Social Sciences [-] siuj Société Internationale d'Urologie Journal [-] societies Societies [-] software Software [-] soilsystems Soil Systems [-] solar Solar [-] solids Solids [-] spectroscj Spectroscopy Journal [-] sports Sports [-] standards Standards [-] stats Stats [-] stratsediment Stratigraphy and Sedimentology [-] stresses Stresses [-] surfaces Surfaces [-] surgeries Surgeries [-] std Surgical Techniques Development [-] sustainability Sustainability [-] suschem Sustainable Chemistry [-] symmetry Symmetry [-] synbio SynBio [-] systems Systems [-] targets Targets [-] taxonomy Taxonomy [-] technologies Technologies [-] telecom Telecom [-] textiles Textiles [-] thalassrep Thalassemia Reports [-] tae Theoretical and Applied Ergonomics [-] therapeutics Therapeutics [-] thermo Thermo [-] timespace Time and Space [-] tomography Tomography [-] tourismhosp Tourism and Hospitality [-] toxics Toxics [-] toxins Toxins [-] transplantology Transplantology [-] traumacare Trauma Care [-] higheredu Trends in Higher Education [-] tph Trends in Public Health [-] tropicalmed Tropical Medicine and Infectious Disease [-] universe Universe [-] urbansci Urban Science [-] uro Uro [-] vaccines Vaccines [-] vehicles Vehicles [-] venereology Venereology [-] vetsci Veterinary Sciences [-] vibration Vibration [-] virtualworlds Virtual Worlds [-] viruses Viruses [-] vision Vision [-] waste Waste [-] water Water [-] wild Wild [-] wind Wind [-] women Women [-] world World [-] wevj World Electric Vehicle Journal [-] youth Youth [-] zoonoticdis Zoonotic Diseases
Subscribe
© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated
Disclaimer
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
Terms and Conditions Privacy Policy
We use cookies on our website to ensure you get the best experience.
Read more about our cookies here.
Accept
Share Link
        https://www.mdpi.com/2460668
Copy
clear
Share
https://www.mdpi.com/2460668
clear
Back to Top Top
All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.  
More Information
Accept All
Deny
Powered by Usercentrics Consent Management