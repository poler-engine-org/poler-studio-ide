> Source: https://crates.io/crates/sprs

sprs - crates.io: Rust Package Registry
For full functionality of this site it is necessary to enable JavaScript.
[
crates.io
](https://crates.io/)
The Rust community's crate registry
Submit
Change color scheme
light
dark
system
Browse All Crates | Log in with GitHub
Change color scheme
light
dark
system
Menu
Browse All Crates
Log in with GitHub
sprs v0.11.4
A sparse matrix library
# algebra
# linear
# matrix
# sparse
Readme
39 Versions
Dependencies
Dependents
Security
sprs, sparse matrices for Rust
 
sprs implements some sparse matrix data structures and linear algebra algorithms in pure Rust.
The API is a work in progress, and feedback on its rough edges is highly appreciated :)
Features
Structures
CSR/CSC matrix
triplet matrix
Sparse vector
Operations
sparse matrix / sparse vector product
sparse matrix / sparse matrix product
sparse matrix / sparse matrix addition, subtraction
sparse vector / sparse vector addition, subtraction, dot product
sparse/dense matrix operations
Algorithms
Outer iterator on compressed sparse matrices
sparse vector iteration
sparse vectors joint non zero iterations
simple sparse Cholesky decomposition (requires opting into an LGPL license)
sparse triangular solves with dense right-hand side
Examples
Matrix construction
Matrix vector multiplication
Matrix matrix multiplication, addition
For a more complete example, be sure to check out the heat diffusion example.
Documentation
Documentation is available at docs.rs.
Changelog
See the changelog.
Minimum Supported Rust Version
The minimum supported Rust version currently is 1.64. Prior to a 1.0 version, bumping the MSRV will not be considered a breaking change, but breakage will be avoided on a best effort basis.
License
Licensed under either of
Apache License, Version 2.0, ( LICENSE-APACHE or https://www.apache.org/licenses/LICENSE-2.0)
MIT license ( LICENSE-MIT or https://opensource.org/licenses/MIT)
at your option.
Contribution
Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in the work by you, as defined in the Apache-2.0 license, shall be dual licensed as above, without any additional terms or conditions.
Please see the contribution guidelines for additional information about contributing.
Metadata
4 months ago
v1.85.0
MIT OR Apache-2.0
12K SLoC
112 KiB
pkg:cargo/sprs@0.11.4 
Install
Run the following Cargo command in your project directory:
cargo add sprs
Or add the following line to your Cargo.toml:
sprs = "0.11.4"
Documentation
docs.rs/sprs/0.11.4
Browse source
docs.rs/crate/sprs/0.11.4/source
Repository
github.com/sparsemat/sprs
Owners
 Vincent Barrielle
 Magnus Ulimoen
Report crate
Stats Overview
4,236,920 Downloads all time
39 Versions published
Downloads over the last 90 days
Display as
Stacked
Stacked
Unstacked
Rust
rust-lang.org
Rust Foundation
The crates.io team
Get Help
The Cargo Book
Support
System Status
Report a bug
Policies
Usage Policy
Security
Privacy Policy
Code of Conduct
Data Access
Social
rust-lang/crates.io
#t-crates-io
@cratesiostatus