> Source: https://www.reddit.com/r/comp_chem/comments/1t2e0vs/orca_vs_nwchem_vs_psi4_vs_pyscf_vs_others/

ORCA vs NWChem vs Psi4 vs PySCF vs others? : r/comp_chem
Skip to main content ORCA vs NWChem vs Psi4 vs PySCF vs others? : r/comp_chem
Open menu
Open navigation 
Go to Reddit Home
r/comp_chem
Sign Up
Sign up for Reddit
Log In
Log in to Reddit
Expand user menu
Open settings menu
Skip to Navigation Skip to Right Sidebar
Back
Go to comp_chem
r/comp_chem
•
1mo ago
Historical-Mix6784
Locked post
Stickied post
Archived post
Report
ORCA vs NWChem vs Psi4 vs PySCF vs others?
As far as I can tell, there are four broadly available, well-documented, decently optimized, and free quantum chemistry codes out there (ORCA, NWChem, Psi4, and PySCF). This is not including immense number of plane wave/PBC codes, I'm talking quantum chemistry (DFT + correlated methods) in vacuum.
Why so many? What are some of the advantages and disadvantages of each of these packages?
Upvote 10 Downvote 6 Go to comments Share
Sort by: Best
Open comment sort options
Best
Top
New
Controversial
Old
Q&A
Search Comments Expand comment search
Cancel
Comments Section
euphoniu
•
1mo ago
• Edited 1mo ago
I will give a simple answer (aka the reason I like to use different packages) - functionality. I personally use pyscf, orca, and a few others you hadn't listed. These softwares get inspired by specific research groups to solve a specific set of issues or in a specific niche that they feel is missing in other software. For your typical organic chemistry 101 calculations (e.g. what most experimentalists like to use q-chem softwares for), it honestly does not matter at all what software you use. Here are what I like about certain softwares:
PySCF is highly modular, so anytime I need to link with workflows in Python or other Python-based molecular analysis packages, or even multireference engines, it is nice.
ORCA has great tools to map results to experiment. When I want to model results to spectroscopy, especially magnetic or core-properties, it is great, and has nice implementation of RI that really accelerates calculations in large electron systems.
Upvote 16 Downvote Reply Award Share
Report
Award
Share
DFT-andmore86
•
1mo ago
One important aspect is the fact that the codes are also used for method development. There are not only users of the codes, but also many groups in theoretical chemistry for whom working on the code itself defines their field of scientific research.
Thus there needs to be a sufficient range of options here, depending on the resources available and whether or not one can access the source code at all (here the term 'free code' is somewhat misleading, as it also depends on whether the code is closed source - and, if not, whether there are opportunities to become part of a developer community).
And it is perhaps these people who will ultimately be the most important in the long term. After all, someone will have to take care of those software packages in the future too – much of what I have used in the last three decades does not exist any more (i.e. is not updated since many years and cannot be used out of the box any more - and unfortunately just having an open source code does not help if there is no one to maintain it).
A second aspect that I personally think is of some importance too is the fact that having different codes written by different people can help to find and fix bugs or deep-dive into interesting scientific challenges. Last year I had an input which gave three very different results using three different quantum chemistry packages.
Quantum chemistry is no easy task; it involves a whole host of assumptions that do not always hold true, and the algorithms are highly complex. Otherwise, SCF would often not converge at all and even simple default DFT calculations would take much longer than they do now. Time to say a huge Thanks! to all the people who had some brilliant ideas in the past.
Upvote 14 Downvote Reply Award Share
Report
Award
Share 
Aranka_Szeretlek
•
1mo ago
For "basic" calculations that you would take in a course, there is no real difference between the codes. Orca has a great manual, so I would recommend that for learning. Psi4 has nice tutorials, though, and it works well in Jupyter notebooks, so that might also work for demonstrations.
Use whichever you find easier to use.
Upvote 6 Downvote Reply Award Share
Report
Award
Share 
PBE0_enjoyer
•
1mo ago
Q: Why so many? A: Each package is trying to solve a problem either chemistry- or coding-wise. Generally, the more open the code development, the faster new methods get implemented but usually the harder it is to get more optimized code (faster calculations) as you usually need full time employed programmers for consistent code optimization of implemented methods. Code development is also spearheaded by one or a few research groups, who prefer to build what they're familiar with and what their government will fund. Of the four mentioned: NWChem aims to be scalable with good sustainability as it's developed with DOE funding and developed mainly at PNNL. Open source development for new methods. ORCA funding and development comes from Europe and aims at fast, robust code from its non-open source development approach. PySCF aims for modularity and readability. Calculation speed is a lesser concern than the speed at which one can implement and test new methods. Psi4 aims for a Python front end and C++ backend, not dissimilar to PySCF, but in my opinion, marketed more as production code as opposed to PySCF's extremely developer friendly code. Note: PySCF can be very fast, see GPU implementations and DMRG code. Note2: Software sustainability matters and code developed by one academic group usually becomes obsolete when that PI stops. So company or government backed codes are likely to be more sustainable.
Upvote 6 Downvote Reply Award Share
Report
Award
Share
scarfacebunny
•
1mo ago
GAMESS is all of those things too. https://www.msg.chem.iastate.edu/gamess/
Upvote 4 Downvote Reply Award Share
Report
Award
Share
honey_titan
•
27d ago
I think there are so many of them, because they all do things a bit differently. but the methods are very close to each other. Some are modular, some need you to know a lot, some can be run by anybody. I would recommend orca if you are new to this. it has lot of support and is pretty modern and easy to use. Others have their advantages too.
Upvote 1 Downvote Reply Award Share
Report
Award
Share
New to Reddit?
Create your account and connect with a world of communities.
Continue with Email
Continue with Phone Number
By continuing, you agree to our User Agreement and acknowledge that you understand the Privacy Policy.
People also ask about section
People also ask about
Most effective methods for molecular modeling
Popular programming languages for chemists
Trends in quantum chemistry calculations
Essential tools for computational chemists
Career paths in computational chemistry
First time doing ochras r/ochras • 6mo ago [
First time doing ochras
](https://www.reddit.com/r/ochras/comments/1pl7fuo/first_time_doing_ochras/)  4 52 upvotes · 42 comments
A or C? r/NCLEX_RN • 3mo ago [
A or C?
](https://www.reddit.com/r/NCLEX_RN/comments/1ruhyus/a_or_c/)  55 upvotes · 59 comments
FCPS-1 Opth r/FCPS_Pk • 6mo ago [
FCPS-1 Opth
](https://www.reddit.com/r/FCPS_Pk/comments/1p4n40h/fcps1_opth/) 7 upvotes · 7 comments
HPC has entered the chat! r/ClothandPaper • 6mo ago [
HPC has entered the chat!
](https://www.reddit.com/r/ClothandPaper/comments/1pp5krd/hpc_has_entered_the_chat/)  67 upvotes · 33 comments
If you think CS quality control is bad, I present PSA r/Currencytradingcards • 4mo ago [
If you think CS quality control is bad, I present PSA
](https://www.reddit.com/r/Currencytradingcards/comments/1qys3vr/if_you_think_cs_quality_control_is_bad_i_present/)  45 upvotes · 40 comments
CPACE Results Were Unexpectedly Low - Anyone Else? r/Principals • 1y ago [
CPACE Results Were Unexpectedly Low - Anyone Else?
](https://www.reddit.com/r/Principals/comments/1ll9mfe/cpace_results_were_unexpectedly_low_anyone_else/) 7 upvotes · 25 comments
O1A approved r/O1VisasEB1Greencards • 1mo ago [
O1A approved
](https://www.reddit.com/r/O1VisasEB1Greencards/comments/1st67gm/o1a_approved/) 19 upvotes · 19 comments
PFA. Looking to get an SPC9 in the near future. r/bruggerthomet • 7mo ago [
PFA. Looking to get an SPC9 in the near future.
](https://www.reddit.com/r/bruggerthomet/comments/1p0v5v4/pfa_looking_to_get_an_spc9_in_the_near_future/)  76 upvotes · 42 comments
Opinion on DPWAS program choices r/uplb • 5d ago [
Opinion on DPWAS program choices
](https://www.reddit.com/r/uplb/comments/1tqmdp0/opinion_on_dpwas_program_choices/)  6 upvotes · 6 comments
what is the difference between pur and pur plus pitcher filters? r/WaterFilters • 10mo ago [
what is the difference between pur and pur plus pitcher filters?
](https://www.reddit.com/r/WaterFilters/comments/1m97no4/what_is_the_difference_between_pur_and_pur_plus/) 4 upvotes · 3 comments
Pure aerospace or ece or mechanical r/Aerospace_India • 1mo ago [
Pure aerospace or ece or mechanical
](https://www.reddit.com/r/Aerospace_India/comments/1svkfra/pure_aerospace_or_ece_or_mechanical/) 9 upvotes · 32 comments
To those with the WVP II, why are you all of a sudden removing them? r/ThermalGrizzly • 15d ago [
To those with the WVP II, why are you all of a sudden removing them?
](https://www.reddit.com/r/ThermalGrizzly/comments/1tgxe8d/to_those_with_the_wvp_ii_why_are_you_all_of_a/) 6 upvotes · 46 comments
CV or DPS??? r/bokaro • 5mo ago [
CV or DPS???
](https://www.reddit.com/r/bokaro/comments/1qa6drc/cv_or_dps/) 5 upvotes · 41 comments
IOQM PW Batch r/ioqm • 3mo ago [
IOQM PW Batch
](https://www.reddit.com/r/ioqm/comments/1rua521/ioqm_pw_batch/) 3 upvotes · 20 comments
OM-3 Advice r/OMSystem • 6d ago [
OM-3 Advice
](https://www.reddit.com/r/OMSystem/comments/1tp5v5r/om3_advice/) 15 upvotes · 33 comments
Where is PC2 and PC3?! r/ProjectCARS_2 • 2mo ago [
Where is PC2 and PC3?!
](https://www.reddit.com/r/ProjectCARS_2/comments/1sd9o5o/where_is_pc2_and_pc3/)  41 upvotes · 12 comments
PPA-CF r/ender3 • 4mo ago [
PPA-CF
](https://www.reddit.com/r/ender3/comments/1qpvs32/ppacf/)  3 54 upvotes · 23 comments
First PCC that's actually a AR platform. Waiting on my rugged sub9 to get out of jail r/ar15pistol • 7d ago [
First PCC that's actually a AR platform. Waiting on my rugged sub9 to get out of jail
](https://www.reddit.com/r/ar15pistol/comments/1totv8s/first_pcc_thats_actually_a_ar_platform_waiting_on/)  2 39 upvotes · 14 comments
PAC012 Upgrades r/YamahaPacifica • 3mo ago [
PAC012 Upgrades
](https://www.reddit.com/r/YamahaPacifica/comments/1rc3bjt/pac012_upgrades/)  4 50 upvotes · 23 comments
PPA-CF is really strong r/3Dprinting • 1y ago [
PPA-CF is really strong
](https://www.reddit.com/r/3Dprinting/comments/1lapiin/ppacf_is_really_strong/)  182 upvotes · 64 comments
Is this actually PFS? r/FinasterideSyndrome • 1mo ago [
Is this actually PFS?
](https://www.reddit.com/r/FinasterideSyndrome/comments/1t0swd6/is_this_actually_pfs/) 8 upvotes · 22 comments
PFS cure r/FinasterideSyndrome • 1mo ago [
PFS cure
](https://www.reddit.com/r/FinasterideSyndrome/comments/1t0jyrk/pfs_cure/) 6 upvotes · 18 comments
No CNC. No shortcuts. Just pure craftsmanship. r/HickoryGolf • 11d ago [
No CNC. No shortcuts. Just pure craftsmanship.
](https://www.reddit.com/r/HickoryGolf/comments/1tksu6l/no_cnc_no_shortcuts_just_pure_craftsmanship/)  1:54 31 upvotes · 10 comments
Pacifica Standard Plus - 2 Years Later - Have you noticed any workmanship issues? r/YamahaPacifica • 12d ago [
Pacifica Standard Plus - 2 Years Later - Have you noticed any workmanship issues?
](https://www.reddit.com/r/YamahaPacifica/comments/1tkcxby/pacifica_standard_plus_2_years_later_have_you/) 3 upvotes · 7 comments
View Post in
Português (Brasil)
Français
Community Info Section
r/comp_chem
Join
Computational Chemistry
Public
Anyone can view, post, and comment to this community
Reddit Rules
Privacy Policy
User Agreement
Your Privacy Choices
Accessibility
Reddit, Inc. © 2026. All rights reserved.
Expand Navigation
Expand Navigation
Collapse Navigation
Collapse Navigation 
0cAFcWeA7YLEDCiMQwY_8iZTmMX4Wy8IKJ47jp0_lRyKzaMAxau1lNDh5A3JK3MpKegMbS5tq1lQuGpD2b4avR-ATMmAh_3Vuzx7d3E0eix3VD3JQR0AKlj48M1f3KG6MmgZ2XbsSzqOfPbuBuhFVQ4wyclOkgVA71CGY1AvzmRfPLDf7C-xCnH6fJjCyV7wsX2M8_H2ZZeAXgiZBnrBZUTKF-AXQIpReCt2CkziEaYUDEpx_qe7o9JpWEtZUkYIOUQeC_w2A3ctAjq6zDmN-vbmcG9pMju369H5-3LJ0A-UhmL0G3R42DsaRiBR0Ed3TpMlCUVFBKDIYdbNVHNeYW4QFvBl9TlTkcRCriH2PwqFwrHlMOo7Wp3QKfA68Ig58k7DfrtNIOsbk00ceBMQPZo6HQE-FLTmxibwmv9RdHjAX24--n4HP9LFG6c-GP5K6CXghx6HLtEbPnYZ8ePbYcFnNF4-6y7m3Jj9__GMwj9H0Aai0_OCWVNBJij9kd6NdG4fL5mOXy6mS3GhMWxOF4W0kcUSGKFLJCDkTzZgyrq4vNBr5eojxhWr015SXvOx7A5Q19SNigT7v4P0OC2UTwRc5fvskZFkYZHSN9Lq82d3LF9jiJRIQjS3O-JOZWfPhbRWNHEOQ-XAklbiqFl63lSpFbB9W1dwQZa_xQSbwyBOP2_SYlfZQJ909h2ilWs-kocurph8BQsFp0X509ivdj9OxmepJh5Jv0Um2-AAwDqz3sjGTesIQGDbhlxtRHNNvot0a__vN6pjwGcVyfMoi8PADtvj75NScX5bQZDzgxLj2uMI9ZIV5M1BbH4c69xvg4EOm1HOYZKmBrJ7yG2S5bjSvmZyb_u1-9gUIpO1U_8JOmmyjwkHwGUlZXHTNK_IjHVZgUVZPeBdQgrdrybISm4Xl4QRdaHbyKAt6v_T1X81U8d53sAd7OcHCzakGH2LuKXZGum-EhAtGdcCiUZaqOtci1ChYasWuabS3VQJpgwlRsqn6nPSzwXVUAqYvApwkAYRMv6huy0FNknR55mLvvacZrpoxXAy_HeaGPzQhzl_tRt5zh_9qW4gLkFxe-saZg-lgRBSqsaZOOR4GSC9rQLi3F9IdGc65-4gzeMHA30xYIDKqZL_E2eqtc-tfKXaDWTJvs_YCQ3sS9umNn30Z7Q2kejIG49vxMnBMRgy0o0tQ3_uBlsvBrjQYJMqJxjX9ptlSvAQNOHq87lrxCPFk1fH5B-3LMehhiFeCMLufvfN0rSwryfTRW_rTo_XYM0EuJ_Wh8zxNPZUdhnk4uWqIUl7X6INXhywAom_fCwuGXwtcSjoWOZNF3ljnYQZNYeIPOlFwyJf21KqDtFgtj8QQnuI1LuBaOJiaWQXlRxBEuhTRgn0IWIbHuMexU_PT6zdXy5faz111lUST6QpYKYZn2_DboISQxc5Fq-Cq90bviXeIk1ZKsxU8629DSQhmZpW-FOfgRiLxz80ey1fI43JG5KiKMjR8lgQKUuWzu-G6xWp4z5VusHIJ6BRjDce1hlGS02EEVBFNAZNEROrFc5NWwAN9j6Gj_-FIP4AvT5rBtsIXbWxt3z_PkGc6Sb0A1XMs0-iMuiFG4zGid2qZ6RvVH7vU1RbuUnwv6JGpR2CSx-thL_ge1FWb1OFDGp1O_rT8wfygLrknzas3wqIQHWpWe0cWEIuV6rMKVT2bWK4t2ILS9xYjv8ntJjfiLYMrzp6_leFtxsejeNb378Ki4mOq9EopDuyLAPr-X1CcIPpV9OKPL-FyxsW36WsnpPi6NxXrBRDx-XrPS4UCgVgGHOs5-PLn2ODn4Rn2Mwrszd9f2RAovfMPIb-XVCIdcYsIgSVNB5aVbzWYgl4NHnbOhImrfiVTFMf0HttSAPr0eUPZO9v2H_AYMesuQ4Fct-vJs2fBv-i61_e2Yq8gdNr94HpTwO221YP8IUXMqtbk9CwgpHxfIBmJD90EDQZgWggXrG7JmvsDbBGwewO-hmdY8guphnzyIW4TMfPhbzw06iP9E61i_sgjO-rDL2RROFyCnYocIIx2m1ThzsrWP1oGjrSRPHKIJGs4QrWIMidpf7rXIyIOWPovaKHcRLtNBjG3jNWljDoHhrKawItCP