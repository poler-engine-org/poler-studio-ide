POLER-UNIFIED: Полный отчёт о багах и исходный код
Дата: 2026-06-09
Версия: poler-unified (POLER-ERI v3.2.0 + POLER-DYNAMIS v5)
Цель: Документ для ревью кода, проверки математики и поиска решений
--------------------------------------------------------------------------------
Содержание
Обзор проекта и сводка багов
Исправленные баги (с кодом фиксов)
Неисправленные баги (детальный анализ)
Исходный код: poler-eri
Исходный код: poler-dynamis
Справочник математических формул
Архитектура и путь к GPU
--------------------------------------------------------------------------------
1. Обзор проекта и сводка багов
Что такое POLER-UNIFIED
POLER-UNIFIED — это чистый Rust фреймворк квантовой химии, реализующий метод Хартри-Фока (RHF/SCF). Состоит из двух крейтов:
poler-eri: Вычисление всех интегралов (overlap, kinetic, nuclear, ERI) через схему McMurchie-Davidson / Rys quadrature + VRR/HRR
poler-dynamis: SCF-движок с двухфазным алгоритмом сходимости (DIIS bootstrap + POLER-flow)
Архитектура конвейера:
Статус тестов
Ключевое наблюдение: Молекулы только с s-орбиталями (He, H₂) работают правильно. Молекулы с p-орбиталями (H₂O, LiH) дают совершенно неверные результаты.
Сводка багов
Исправленные баги ✅
K=0 баг: Матрица обмена K была нулевой из-за неправильного использования 8-fold симметрии с sym_factor. Исправлено: полный N⁴ цикл + пост-симметризация 0.5*(M+Mᵀ).
FFI lgamma баг: extern "C" { fn lgamma(x: f64) -> f64; } вызывал segfault на некоторых платформах. Исправлено: libm::lgamma(x).
Pipeline FFI баг: SubquantumBridge использовал libcint через FFI. Исправлено: прямое использование poler_eri::IntegralBackend.
Неисправленные баги ❌
Nuclear attraction: фактор-2 для p-орбиталей: Функция nuclear_shell(1,1,...) через McMurchie-Davidson даёт ~половину правильного значения для p-орбиталей, тогда как nuclear_ss для s-орбиталей верна.
ERI: неверные значения для смешанных угловых моментов: ERI-интегралы для p-орбитальных оболочек неверны, что приводит к E=-32.5 вместо -75.0 для H₂O.
--------------------------------------------------------------------------------
2. Исправленные баги
2.1 K=0 баг (FIXED) — eri_engine.rs
Проблема: При использовании 8-fold симметрии с sym_factor, матрица обмена K была нулевой или неверной. Причина: sym_factor умножает значение ERI, но рассеивает только по ограниченному числу позиций, что не эквивалентно посещению всех 8 симметричных позиций. Кроме того, K требует перестановки индексов (ν↔λ), которая не входит в 8-fold симметрии (μν|λσ).
Решение: Полный N⁴ цикл по ВСЕМ shell-квартетам без sym_factor, с пост-симметризацией J и K через 0.5*(M + Mᵀ).
Формула Фока: F = H_core + J - 0.5·K (RHF)
2.2 FFI lgamma баг (FIXED) — gto_utils.rs
Проблема: Использование extern "C" { fn lgamma(x: f64) -> f64; } вызывало segfault или неверные результаты на платформах без C libcint.
Решение: Замена на чистый Rust через libm::lgamma(x):
Это обеспечивает:
Численную стабильность при высоких l (l ≥ 6)
Кросс-платформенную совместимость
Отсутствие переполнения integer (в отличие от double_factorial)
2.3 Pipeline FFI баг (FIXED) — pipeline.rs
Проблема: Конвейер использовал SubquantumBridge для связи с libcint через FFI.
Решение: Прямой импорт poler_eri::IntegralBackend:
--------------------------------------------------------------------------------
3. Неисправленные баги (детальный анализ)
3.1 ⚠️ Nuclear Attraction: фактор-2 для p-орбиталей
Симптом: nuclear_shell(1, 1, ...) через McMurchie-Davidson (MD) даёт примерно половину правильного значения для p-орбиталей. Функция nuclear_ss для s-орбиталей верна.
Где: poler-eri/src/one_electron.rs, функции:
hermite_coefficients_1d() — коэффициенты Эрмита E^{i,j}_t
build_auxiliary_integrals() — вспомогательные интегралы R_{t,u,v}
nuclear_shell() — финальная сборка V_{a,b}
Математика MD-схемы:
Коэффициенты Эрмита E^{i,j}_t (1D рекуренция):
Вспомогательные интегралы R_{t,u,v}^{n}:
Финальная сборка:
Подозреваемые проблемы:
⚠️ Проблема A: В функции build_auxiliary_integrals() базовые значения вычисляются как:
Формула R_{0,0,0}^{n} = -Z_C · 2π/p · F_n(T) · exp(-μ·R_AB²) — это ПРАВИЛЬНАЯ формула для ОДНОМЕРНОГО интеграла, но для 3D интеграла нужен множитель (π/p)^(3/2) вместо 1/p. Проверьте, не дублируется ли нормализация.
⚠️ Проблема B: Рекуренция build_auxiliary_integrals() обрабатывает Boys order от lmax вниз до 0. НО: начальное заполнение r_next[0][0][0] = base_values[lmax] использует только F_{lmax}, тогда как должны быть заполнены ВСЕ R_{0,0,0}^{n} для n = 0..lmax. Текущий код заполняет R_{0,0,0}^{n} = base_values[n] на каждой итерации, что верно — но проверьте, не теряется ли R[0][0][0] при переходе между слоями.
⚠️ Проблема C: В nuclear_shell() используется exp_factor = libm::exp(-gd.mu * rab2) с mu = alpha_a * alpha_b / p. Это одномерный множитель смещения. Для 3D интеграла нужен множитель (π/p)^(3/2) · exp(-μ·R_AB²), где R_AB² — полное 3D расстояние, а не покоординатное. Текущий код вычисляет exp(-μ·rab2) где rab2 = полное 3D |A-B|², что правильно. Но проверьте: не пропущен ли множитель (π/p)^(3/2)?
Диагностический тест: Сравнить nuclear_shell(0,0,...) с nuclear_ss(...) — они должны совпадать (и совпадают!). Затем сравнить nuclear_shell(1,1,...) с известными значениями для p-орбиталей.
3.2 ⚠️ ERI: неверные значения для p-орбиталей
Симптом: H₂O даёт E=-32.5 вместо -75.0, LiH даёт E=-60.89 вместо -7.87. Ошибка ~8x для LiH и ~2.3x для H₂O.
Где: Цепочка вычислений:
poler-eri/src/shell_driver.rs — ShellQuartetDriver::compute()
poler-eri/src/circuit.rs — построение R1CS-схемы VRR/HRR
poler-eri/src/generated/eri_XXXX.rs — кристаллизованные ядра
Математика Rys quadrature:
Для shell-квартета (la, lb | lc, ld):
Prefactors (7 штук для каждого Rys root и направления):
Подозреваемые проблемы:
⚠️ Проблема A: Prefactor c00 = PA[dim] + t·PQ[dim] — проверьте, что это правильная форма VRR. В стандартной схеме Obara-Saika VRR:
Для Rys-схемы это трансформируется в множители c00 и c0p, но формула может отличаться в зависимости от конкретной реализации.
⚠️ Проблема B: Порядок Rys quadrature. Для shell-квартета (la,lb|lc,ld) нужен nrys = (la+lb+lc+ld)/2 + 1 корней. Проверьте, что circuit.rys_order вычисляется правильно.
⚠️ Проблема C: HRR-Ket рекуренция в extract_value() для ManualHrrKet:
Проверьте знак: стандартная HRR-рекуренция:
где CD_i = C_i - D_i. В коде используется neg_cd = D[dim] - C[dim], то есть -CD. Проверьте, что это согласуется с формулой извлечения.
⚠️ Проблема D: Перестановка bra/ket партнёров. Когда la < lb, код меняет местами A↔B. После этого результат нужно транспонировать обратно. Проверьте, что перестановка в shell_quartet_contracted() делает это правильно.
Диагностический подход: Написать diag_eri.rs, который:
Вычисляет (ss|ss) и сравнивает с аналитическим значением — должно совпадать ✅
Вычисляет (ps|ss) и сравнивает с эталоном
Вычисляет (pp|ss) и сравнивает с эталоном
Вычисляет (pp|pp) и сравнивает с эталоном
Сравнивает с PySCF/libcint значениями
--------------------------------------------------------------------------------
4. Исходный код: poler-eri\n\n### poler-eri/src/types.rs\n\n```rust
// FILE: /home/z/my-project/poler-unified/poler-eri/src/types.rs //! Core types for the POLER-ERI meta-compiler and runtime. //! //! This module defines the fundamental data structures used throughout the //! project: points in 3D space, Gaussian shells, atomic data, basis sets, //! and the all-important [QuartetData] which holds precomputed geometric //! quantities for a shell quartet.
/// A Gaussian primitive shell on a specific atom. /// /// A shell is defined by its angular momentum l, the atom it belongs to, /// and sets of exponents (alphas) and contraction coefficients. After /// normalization, norm_coeffs contains the properly normalized coefficients /// that account for the GTO self-overlap. /// /// # Cartesian vs Spherical /// /// - Cartesian components: (l+1)(l+2)/2 (e.g., l=2 → 6: xx, xy, xz, yy, yz, zz) /// - Spherical harmonics: 2l+1 (e.g., l=2 → 5: d₀, d₊₁, d₋₁, d₊₂, d₋₂) #[derive(Debug, Clone)] pub struct Shell { /// Angular momentum quantum number (0=s, 1=p, 2=d, 3=f, ...) pub l: usize, /// Index of the atom this shell belongs to in the molecule's atom list pub atom_idx: usize, /// Gaussian exponents (alpha values) for each primitive pub alphas: Vec<f64>, /// Raw contraction coefficients from the basis set file pub coeffs: Vec<f64>, /// Normalized contraction coefficients (coeffs * N_alpha / sqrt(S_self)) pub norm_coeffs: Vec<f64>, }
impl Shell { /// Create a new shell with unnormalized coefficients. /// /// Call  after /// creation to populate norm_coeffs. pub fn new(l: usize, atom_idx: usize, alphas: Vec<f64>, coeffs: Vec<f64>) -> Self { let n = alphas.len(); Shell { l, atom_idx, alphas: alphas.clone(), coeffs: coeffs.clone(), norm_coeffs: vec![0.0; n], } }
}
/// A point in 3D Euclidean space. /// /// Used to represent atomic coordinates and product centers (P, Q) in the /// McMurchie-Davidson / Obara-Saika scheme. #[derive(Debug, Clone, Copy)] pub struct Point(pub [f64; 3]);
impl Point { /// Origin point (0, 0, 0). pub fn zero() -> Self { Point([0.0, 0.0, 0.0]) }
}
impl std::ops::Sub for Point { type Output = Point; fn sub(self, rhs: Point) -> Point { Point([self.0[0]-rhs.0[0], self.0[1]-rhs.0[1], self.0[2]-rhs.0[2]]) } }
/// Cartesian component specification: (nx, ny, nz) where nx+ny+nz = l. /// /// For example, a d-shell (l=2) has components: /// (2,0,0), (1,1,0), (1,0,1), (0,2,0), (0,1,1), (0,0,2) pub type CartComp = (usize, usize, usize);
/// Precomputed data for a shell quartet (a|b|c|d). /// /// This struct holds ALL geometric quantities needed to evaluate ERI recurrence /// relations for a given set of four centers with Gaussian exponents. The /// constructor computes everything up front so the VRR/HRR pipeline can run /// without any further geometric calculations. /// /// # Key Quantities /// /// - p = alpha_a + alpha_b — combined exponent for bra pair /// - q = alpha_c + alpha_d — combined exponent for ket pair /// - rho = p*q/(p+q) — reduced exponent for Boys function argument /// - kab = exp(-alpha_a * alpha_b * R_AB² / p) — bra overlap factor /// - kcd = exp(-alpha_c * alpha_d * R_CD² / q) — ket overlap factor #[derive(Debug, Clone)] pub struct QuartetData { /// Center A coordinates pub ra: Point, /// Center B coordinates pub rb: Point, /// Center C coordinates pub rc: Point, /// Center D coordinates pub rd: Point, /// Gaussian exponent on center A pub alpha_a: f64, /// Gaussian exponent on center B pub alpha_b: f64, /// Gaussian exponent on center C pub alpha_c: f64, /// Gaussian exponent on center D pub alpha_d: f64, /// Squared distance |A - B|² pub rab2: f64, /// Squared distance |C - D|² pub rcd2: f64, /// Combined bra exponent: alpha_a + alpha_b pub p: f64, /// Combined ket exponent: alpha_c + alpha_d pub q: f64, /// Reduced exponent: p * q / (p + q) — appears in Boys function argument pub rho: f64, /// Bra overlap factor: exp(-alpha_a * alpha_b * R_AB² / p) pub kab: f64, /// Ket overlap factor: exp(-alpha_c * alpha_d * R_CD² / q) pub kcd: f64, /// Overall prefactor: 2π²/(p*q) * sqrt(π/(p+q)) pub prefactor: f64, }
impl QuartetData { /// Compute all geometric quantities for a shell quartet. /// /// This is the constructor you call before running the VRR/HRR pipeline. /// All the heavy math (exponentials, square roots) happens here so the /// recurrence relation evaluation is just additions and multiplications. pub fn new(ra: Point, rb: Point, rc: Point, rd: Point, alpha_a: f64, alpha_b: f64, alpha_c: f64, alpha_d: f64) -> Self { use libm::exp; let p = alpha_a + alpha_b; let q = alpha_c + alpha_d; let rab2 = ra.dist2(&rb); let rcd2 = rc.dist2(&rd); let rho = p * q / (p + q); let kab = exp(-alpha_a * alpha_b * rab2 / p); let kcd = exp(-alpha_c * alpha_d * rcd2 / q); let prefactor = 2.0 * std::f64::consts::PI.powi(2) / (p * q) * libm::sqrt(std::f64::consts::PI / (p + q)); QuartetData { ra, rb, rc, rd, alpha_a, alpha_b, alpha_c, alpha_d, rab2, rcd2, p, q, rho, kab, kcd, prefactor } }
}
/// A single atom with nuclear charge and 3D coordinates. #[derive(Debug, Clone)] pub struct Atom { /// Nuclear charge (1=H, 3=Li, 6=C, 8=O, etc.) pub charge: f64, /// Position in 3D space (in Bohr) pub coords: Point, }
/// A complete basis set: atoms + contracted Gaussian shells. #[derive(Debug, Clone)] pub struct BasisSet { /// List of atoms in the molecule pub atoms: Vec<Atom>, /// List of contracted Gaussian shells (one per shell in the basis set) pub shells: Vec<Shell>, }
\n---\n\n### poler-eri/src/normalization.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-eri/src/normalization.rs //! GTO (Gaussian Type Orbital) normalization for contracted basis shells. //! //! # What this module does //! //! This module computes the normalized contraction coefficients for Gaussian //! basis function shells. Raw basis set files provide unnormalized exponents //! (`alphas`) and coefficients (`coeffs`), but integral evaluation requires //! properly normalized coefficients (`norm_coeffs`) that account for the //! self-overlap of each primitive Gaussian. //! //! # Why this module exists //! //! Gaussian integrals (overlap, kinetic, nuclear attraction, ERI) are derived //! assuming normalized basis functions. If we skip normalization, the integrals //! would be off by factors that depend on the exponents and angular momentum, //! making results meaningless. //! //! The normalization procedure transforms raw coefficients into coefficients //! that, when combined with the primitive Gaussian, produce functions with //! unit self-overlap. This is done per-primitive at the shell level; per-component //! Cartesian normalization (for nx, ny, nz individually) is handled separately //! in the [`cart2sph`](crate::cart2sph) module. //! //! # How it works //! //! The normalization constant for a primitive Gaussian with exponent α and //! angular momentum l is: //! //! text //! N(α, l) = (2α/π)^(3/4) · (4α)^(l/2) / √((2l-1)!!) //! //! //! For the s-shell (l=0), this simplifies to the well-known result: //! //!text //! N(α, 0) = (2α/π)^(3/4) //! //! //! For each primitive i in a shell, the normalized coefficient is: //! //!text //! norm_coeffs[i] = coeffs[i] · N(α_i, l) //! ``` //! //! The double factorial (2l-1)!! = (2l-1)·(2l-3)·...·3·1 is computed by //! the [`fact2`] helper function.
use crate::types::Shell;
/// Compute the double factorial n!! = n · (n-2) · (n-4) · ... · 2 or 1. /// /// # What it does /// /// Returns the double factorial of n. For even n, the product terminates at 2; /// for odd n, it terminates at 1. By convention, 0!! = 1. /// /// # Why it exists /// /// Double factorials appear in the GTO normalization constant and in the /// analytical expressions for overlap integrals of higher-angular-momentum /// shells. They are a building block for the combinatorial factors that arise /// when integrating powers of coordinates against Gaussian functions. /// /// # How it works /// /// Simple iterative product: start at n and decrement by 2 until reaching /// 0 or 1. Returns 1 for the base case n = 0. /// /// # Examples /// /// /// use poler_eri::normalization::fact2; /// /// assert_eq!(fact2(0), 1);   // 0!! = 1 (by convention) /// assert_eq!(fact2(1), 1);   // 1!! = 1 /// assert_eq!(fact2(2), 2);   // 2!! = 2 /// assert_eq!(fact2(3), 3);   // 3!! = 3·1 = 3 /// assert_eq!(fact2(4), 8);   // 4!! = 4·2 = 8 /// assert_eq!(fact2(5), 15);  // 5!! = 5·3·1 = 15 /// assert_eq!(fact2(6), 48);  // 6!! = 6·4·2 = 48 /// assert_eq!(fact2(7), 105); // 7!! = 7·5·3·1 = 105 /// pub fn fact2(n: usize) -> usize { if n < 2 { return 1; } let mut result = 1usize; let mut k = n; while k > 0 { result *= k; if k <= 2 { break; } k -= 2; } result }
/// Compute the GTO normalization constant N(α, l) for a primitive Gaussian. /// /// # What it does /// /// Returns the normalization constant that, when multiplied by a raw /// contraction coefficient, produces a properly normalized primitive /// Gaussian function with unit self-overlap. /// /// # Why it exists /// /// The raw coefficients in basis set files (e.g., STO-3G, cc-pVDZ) are not /// normalized. They must be multiplied by the normalization constant before /// use in integral evaluation. This function isolates the math so that /// [normalize_shell] can simply loop over primitives. /// /// # How it works /// /// The formula is: /// /// text /// N(α, l) = (2α/π)^(3/4) · (4α)^(l/2) / √((2l-1)!!) ///  /// /// - The first factor (2α/π)^(3/4) is the s-shell normalization, ensuring ///   that the Gaussian envelope has unit self-overlap. /// - The second factor (4α)^(l/2) accounts for the increased overlap from ///   the polynomial prefactor x^l. /// - The third factor 1/√((2l-1)!!) compensates for the combinatorial ///   growth of the overlap integral with angular momentum. /// /// For l=0, the angular factors collapse to 1, giving: /// /// text /// N(α, 0) = (2α/π)^(3/4) ///  /// /// # Arguments /// /// * alpha — Gaussian exponent (must be positive) /// * l — Angular momentum quantum number (0 for s, 1 for p, etc.) /// /// # Examples /// /// ignore /// use poler_eri::normalization::gto_norm; /// /// // s-shell normalization /// let alpha = 1.0; /// let n_s = gto_norm(alpha, 0); /// // N(1.0, 0) = (2/π)^(3/4) ≈ 1.1284 /// assert!((n_s - 1.1284).abs() < 0.001); ///  fn gto_norm(alpha: f64, l: usize) -> f64 { use std::f64::consts::PI;
}
/// Normalize a shell's contraction coefficients in-place. /// /// # What it does /// /// Computes norm_coeffs[i] = coeffs[i] * N(α_i, l) for each primitive i /// in the shell, where N(α, l) is the GTO normalization constant computed /// by [gto_norm]. The result is stored in shell.norm_coeffs. /// /// # Why it exists /// /// Integral evaluation routines (overlap, kinetic, nuclear, ERI) require /// normalized coefficients. This function must be called once after creating /// a [Shell] from raw basis set data, before any integrals are computed. /// The Shell::new constructor initializes norm_coeffs to zeros; this /// function fills in the correct values. /// /// # How it works /// /// 1. For each primitive i in the shell: ///    a. Retrieve the exponent alpha = alphas[i] and raw coefficient c = coeffs[i]. ///    b. Compute the normalization constant N = gto_norm(alpha, l). ///    c. Set norm_coeffs[i] = c * N. /// /// The angular momentum l is shared across all primitives in the shell, /// but each primitive has its own exponent, so the normalization constant /// differs per primitive. /// /// # Arguments /// /// * shell — A mutable reference to a [Shell]. After this call, ///   shell.norm_coeffs will contain the normalized coefficients. /// /// # Example /// /// /// use poler_eri::types::Shell; /// use poler_eri::normalization::normalize_shell; /// /// // Create an unnormalized s-shell with one primitive /// let mut shell = Shell::new(0, 0, vec![3.4252509100], vec![0.1543289673]); /// normalize_shell(&mut shell); /// /// // norm_coeffs[0] should now be coeffs[0] * N(3.425, 0) /// assert!(shell.norm_coeffs[0] != 0.0); /// assert!(shell.norm_coeffs[0] > 0.0); /// pub fn normalize_shell(shell: &mut Shell) { let l = shell.l; for i in 0..shell.n_prim() { let alpha = shell.alphas[i]; let coeff = shell.coeffs[i]; shell.norm_coeffs[i] = coeff * gto_norm(alpha, l); } }
#[cfg(test)] mod tests { use super::*; use crate::types::Shell;
}
\n---\n\n### poler-eri/src/kinetic.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-eri/src/kinetic.rs //! Kinetic energy integral evaluation for Gaussian basis functions. //! //! # What this module does //! //! This module computes kinetic energy integrals between Gaussian-type orbitals //! (GTOs). Currently, it provides the base case for two s-type (l=0) primitive //! Gaussians, which is the fundamental building block for all kinetic energy //! integrals via recurrence relations. //! //! # Why this module exists //! //! The kinetic energy integral T_μν = ⟨χ_μ| −½∇² |χ_ν⟩ is a core component of //! the one-electron Hamiltonian Ĥ = T̂ + V̂_nuc. It appears in: //! //! - **Fock matrix construction**: The Fock matrix F = H_core + G, where H_core //!   includes the kinetic energy contribution. //! - **Energy evaluation**: The total electronic energy E = tr(P·(H_core + F))/2 //!   requires kinetic energy integrals. //! - **Molecular orbital analysis**: Kinetic energy contributions to orbital //!   energies reveal bonding character. //! //! The ss kinetic integral is also the base case for building higher angular //! momentum kinetic integrals through recurrence relations (Obara-Saika), just //! as the ss overlap is the base case for overlap integrals. //! //! # How it works //! //! The kinetic energy integral between two s-type primitive Gaussians is derived //! from the overlap integral using the identity: //! //! text //! T_ss = α_a · α_b / (α_a + α_b) · (3 − 2·α_a·α_b·R_AB² / (α_a + α_b)) · S_ss //! //! //! This formula comes from applying the Laplacian operator to the Gaussian //! product. For an s-type Gaussian φ = exp(−α|r−A|²), the Laplacian gives: //! //!text //! ∇² exp(−α r²) = (4α²r² − 6α) exp(−α r²) //! ``` //! //! After forming the Gaussian product and integrating, the result factorizes //! into the overlap S_ss multiplied by a polynomial in the combined exponent //! and inter-center distance.
use crate::overlap::overlap_ss;
/// Compute the kinetic energy integral between two s-type primitive Gaussians. /// /// # What it does /// /// Evaluates ⟨s_A| −½∇² |s_B⟩ where both s-type functions are unnormalized /// primitive Gaussians. Note: this function returns the full kinetic integral /// value including the −½ factor from the kinetic energy operator. /// /// # Why this is the base case /// /// All kinetic energy integrals for higher angular momenta can be computed from /// the s-type overlap integral and this ss kinetic result using the Obara-Saika /// recurrence: /// /// text /// T_{i+1,j} = (P_i − A_i) · T_{i,j} + (i/(2p)) · T_{i−1,j} + (j/(2p)) · T_{i,j−1} ///             + (1/(2p)) · (i · S_{i−1,j} + j · S_{i,j−1}) ///  /// /// where S denotes overlap integrals and T denotes kinetic integrals. /// /// # How it works /// /// The closed-form formula is: /// /// text /// T_ss = α_a · α_b / (α_a + α_b) · (3 − 2·α_a·α_b·R_AB² / (α_a + α_b)) · S_ss ///  /// /// where S_ss is the overlap integral computed by [overlap_ss]. /// /// Derivation sketch: /// 1. Apply −½∇² to the Gaussian on center B. /// 2. The Laplacian of exp(−α_b|r−B|²) yields (4α_b²|r−B|² − 6α_b)·exp(−α_b|r−B|²). /// 3. Multiply by the Gaussian on center A and integrate. /// 4. Use the Gaussian product theorem to shift coordinates to the product center P. /// 5. The radial integral and displacement factors combine to give the formula above. /// /// # Arguments /// /// * alpha_a — Gaussian exponent on center A (must be positive) /// * alpha_b — Gaussian exponent on center B (must be positive) /// * rab2 — Squared distance |A − B|² between the two centers (must be non-negative) /// /// # Returns /// /// The kinetic energy integral ⟨s_A| −½∇² |s_B⟩. Can be negative when the overlap /// of kinetic contributions is destructive (e.g., at large separations). /// /// # Examples /// /// /// use poler_eri::kinetic::kinetic_ss; /// /// // Same-center kinetic integral /// let t_same = kinetic_ss(1.0, 1.0, 0.0); /// // Should be positive (constructive overlap of kinetic energy) /// assert!(t_same > 0.0); /// /// // Kinetic integral decreases as centers separate /// let t_far = kinetic_ss(1.0, 1.0, 10.0); /// assert!(t_far.abs() < t_same.abs()); /// pub fn kinetic_ss(alpha_a: f64, alpha_b: f64, rab2: f64) -> f64 { let p = alpha_a + alpha_b; let mu = alpha_a * alpha_b / p;  // Reduced exponent
}
#[cfg(test)] mod tests { use super::*;
}
\n---\n\n### poler-eri/src/boys.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-eri/src/boys.rs //! Boys function F_m(T) evaluation. //! //! The Boys function is the core special function in Gaussian integral theory: //! //! text //! F_m(T) = ∫₀¹ u^(2m) * exp(-T * u²) du //! ``` //! //! It appears as the radial part of every two-electron integral. The angular //! momentum m determines the power of `u`, and `T = rho * R_PQ²` is the //! argument that depends on the reduced exponent and inter-center distance. //! //! # Implementation //! //! We use a numerical approximation based on the upward recurrence: //! - F_0(T) = sqrt(π/T) * erf(sqrt(T)) / 2  for T > 0 //! - F_0(0) = 1.0 //! - F_{m+1}(T) = [(2m+1) * F_m(T) - exp(-T)] / (2T) //! //! For small T (< 1e-12), we use the Taylor expansion to avoid division by zero.
/// Evaluate the Boys function F_m(T) for a single (m, T) pair. /// /// # Arguments /// /// * m — angular momentum order (0, 1, 2, ...) /// * t — argument T = rho * R_PQ², must be non-negative /// /// # Returns /// /// The value F_m(T). Always non-negative for valid inputs. /// /// # Examples /// /// /// use poler_eri::boys_f; /// /// // F_0(0) = 1.0 (by definition) /// assert!((boys_f(0, 0.0) - 1.0).abs() < 1e-10); /// /// // F_0(1) ≈ 0.7468 (known value) /// assert!((boys_f(0, 1.0) - 0.7468).abs() < 0.001); /// pub fn boys_f(m: usize, t: f64) -> f64 { if t < 1e-12 { // Taylor expansion for T → 0: // F_m(0) = 1/(2m+1) return 1.0 / (2.0 * m as f64 + 1.0); }
}
/// Evaluate Boys function for all m = 0..=m_max at once. /// /// More efficient than calling boys_f repeatedly because F_0(T) is only /// computed once and the upward recurrence is used for subsequent values. /// /// # Returns /// /// A vector of length m_max + 1 where result[m] = F_m(T). pub fn boys_f_vec(m_max: usize, t: f64) -> Vec<f64> { let mut result = Vec::with_capacity(m_max + 1); if t < 1e-12 { for m in 0..=m_max { result.push(1.0 / (2.0 * m as f64 + 1.0)); } return result; }
}
#[cfg(test)] mod tests { use super::*;
}
\n---\n\n### poler-eri/src/vrr.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-eri/src/vrr.rs //! VRR Engine — Obara-Saika Vertical Recurrence Relations. //! //! # What this module does //! //! This module implements the vertical recurrence relations (VRR) for computing //! two-electron repulsion integrals (ERIs) over Gaussian-type orbitals. The VRR //! increases angular momentum on a single center while keeping all other centers //! fixed, generating the (ss|ss)^m auxiliary integrals that serve as seeds for //! the full recurrence chain. //! //! # Why this module exists //! //! The Obara-Saika scheme for computing ERIs works in two stages: //! //! 1. **VRR (Vertical Recurrence Relations)**: Builds integrals with higher //!    angular momentum from lower ones, increasing `l` on one center at a time. //!    The fundamental recurrence is: //! //!    text //!    (a+1_i b | cd) = (PA_i)(ab | cd) + (1/2p)[a_i((a−1_i b | cd) + b_i((a b−1_i | cd)] //!                    + (1/2(p+q))[c_i((ab | c−1_i d) + d_i((ab | cd−1_i)] //!    ``` //! //! 2. HRR (Horizontal Recurrence Relations): Transfers angular momentum //!    between centers on the same side of the integral. See [crate::hrr]. //! //! The seed for all VRR recursions is the (ss|ss) integral, which is computed //! analytically using the Boys function. //! //! # Implementation notes //! //! The VRR and HRR functions in this module are stubs. The real computation //! in the POLER-ERI pipeline goes through the circuit/crystallizer pipeline: //! //! - `CircuitBuilder` encodes the recurrence relations as //!   an R1CS-like circuit of arithmetic gates. //! - `VrrCrystallizer` compiles the circuit into flat, //!   zero-alloc, SIMD-ready Rust source code. //! - `BatchCompiler` auto-generates code for all shell //!   quartets up to MAX_AM. //! //! The stubs exist so that the runtime API is complete and can be used for //! testing/debugging small cases without the meta-compiler. For production //! calculations, the crystallized code is used instead.
use crate::boys::boys_f; use crate::types::QuartetData;
/// Compute all auxiliary integrals (ss|ss)^m for m = 0..m_max. /// /// # What it does /// /// Evaluates the sequence of auxiliary (ss|ss) integrals for increasing angular /// momentum order m. These are needed as seeds for the VRR recurrence relations. /// The m-th auxiliary integral is: /// /// text /// (ss|ss)^m = prefactor · k_ab · k_cd · F_m(ρ · R_PQ²) ///  /// /// where: /// - prefactor = 2π² / (p·q) · √(π / (p+q)) /// - k_ab = exp(−α_a · α_b · R_AB² / p) /// - k_cd = exp(−α_c · α_d · R_CD² / q) /// - F_m(T) is the Boys function of order m /// - ρ = p·q / (p+q) is the reduced exponent /// - R_PQ² is the squared distance between the bra and ket product centers /// /// # Why it returns all values at once /// /// The Boys function satisfies an upward recurrence: /// /// text /// F_{m+1}(T) = [(2m+1) · F_m(T) − exp(−T)] / (2T) ///  /// /// Computing all values in one call is significantly more efficient than calling /// eri_ss_ss repeatedly because F_0(T) and exp(−T) are only computed once. /// The VRR needs all auxiliary integrals up to m_max = la + lb + lc + ld. /// /// # Arguments /// /// * qd — Precomputed geometric data for the shell quartet /// * m_max — Maximum angular momentum order (inclusive). For a shell quartet ///   (la lb|lc ld), use m_max = la + lb + lc + ld. /// /// # Returns /// /// A vector of length m_max containing the values (ss|ss)^0, (ss|ss)^1, ..., /// (ss|ss)^{m_max-1}. /// /// # Examples /// /// ignore /// use poler_eri::{QuartetData, Point}; /// use poler_eri::vrr::eri_ss_ss_m; /// /// // All four centers at the origin with unit exponents /// let qd = QuartetData::new( ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     1.0, 1.0, 1.0, 1.0, /// ); /// let vals = eri_ss_ss_m(&qd, 3); /// assert_eq!(vals.len(), 3); /// // (ss|ss)^0 should be the largest (highest-order Boys function decays fastest) /// assert!(vals[0] > vals[1]); /// assert!(vals[1] > vals[2]); ///  #[allow(dead_code)] fn eri_ss_ss_m(qd: &QuartetData, m_max: usize) -> Vec<f64> { // Compute the Boys function argument: T = rho * R_PQ² let p = qd.center_ab(); let q = qd.center_cd(); let rpq2 = p.dist2(&q); let t = qd.rho * rpq2;
}
/// Compute the (ss|ss) electron repulsion integral for a primitive shell quartet. /// /// # What it does /// /// Evaluates the two-electron repulsion integral (s_A s_B | s_C s_D) for four /// s-type primitive Gaussians. This is the fundamental seed integral from which /// all higher angular momentum ERIs are built via VRR and HRR recurrence relations. /// /// # Why this is the most important function /// /// Every ERI, regardless of angular momentum, ultimately reduces to a weighted /// sum of (ss|ss) integrals through the recurrence chain: /// /// text /// (pp|ss) ← VRR from (ss|ss) /// (pp|pp) ← HRR from (pp|ss) /// (dd|pp) ← VRR from (pp|pp) /// etc. ///  /// /// The (ss|ss) integral is the "atomic unit" of ERI computation. Its correctness /// is therefore critical — an error here propagates to every integral in the /// calculation. /// /// # How it works /// /// The closed-form expression is: /// /// text /// (ss|ss) = prefactor · k_ab · k_cd · F_0(ρ · R_PQ²) ///  /// /// where: /// - prefactor = 2π² / (p·q) · √(π / (p+q)) — overall normalization /// - k_ab = exp(−α_a · α_b · R_AB² / p) — bra displacement factor /// - k_cd = exp(−α_c · α_d · R_CD² / q) — ket displacement factor /// - F_0(T) = √(π/T) · erf(√T) / 2 — Boys function of order 0 /// - ρ = p·q / (p+q) — reduced exponent /// - R_PQ² — squared distance between product centers P and Q /// /// # Arguments /// /// * qd — Precomputed geometric data for the shell quartet, as constructed ///   by . /// /// # Returns /// /// The value of the (ss|ss) integral. Positive for valid inputs. /// /// # Examples /// /// /// use poler_eri::{QuartetData, Point}; /// use poler_eri::vrr::eri_ss_ss; /// /// // (ss|ss) with all centers at origin — maximum value /// let qd = QuartetData::new( ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     1.0, 1.0, 1.0, 1.0, /// ); /// let val = eri_ss_ss(&qd); /// assert!(val > 0.0, "(ss|ss) should be positive"); /// pub fn eri_ss_ss(qd: &QuartetData) -> f64 { // Compute R_PQ² (distance between bra and ket product centers) let p = qd.center_ab(); let q = qd.center_cd(); let rpq2 = p.dist2(&q);
}
/// VRR on center A — vertical recurrence increasing angular momentum on center A. /// /// # What it does /// /// Implements the Obara-Saika VRR that increases the angular momentum on center A /// by one unit in Cartesian direction dim (0=x, 1=y, 2=z): /// /// text /// (a+1_i b | cd) = PA_i · (ab | cd) ///                + (a_i / 2p) · (a−1_i b | cd) ///                + (b_i / 2p) · (a b−1_i | cd) ///                + (1 / 2(p+q)) · c_i · (ab | c−1_i d) ///                + (1 / 2(p+q)) · d_i · (ab | cd−1_i) ///  /// /// # Implementation note /// /// This function is a stub that returns [eri_ss_ss] when all angular momenta /// are zero, and 0.0 otherwise. The real computation goes through the /// circuit/crystallizer pipeline, which generates optimized Rust code for each /// specific (la, lb, lc, ld) quartet at compile time. The stub exists to provide /// a correct fallback for the (ss|ss) base case and a placeholder for higher /// angular momenta. /// /// # Arguments /// /// * qd — Precomputed geometric data for the shell quartet /// * la — Angular momentum on center A /// * lb — Angular momentum on center B /// * lc — Angular momentum on center C /// * ld — Angular momentum on center D /// * dim — Cartesian direction (0=x, 1=y, 2=z) /// /// # Returns /// /// The ERI value. For the (ss|ss) case, returns the analytical result. /// For higher angular momenta, returns 0.0 (use the crystallized code instead). fn vrr_a(qd: &QuartetData, la: usize, lb: usize, lc: usize, ld: usize, dim: usize) -> f64 { // Base case: all angular momenta zero → return the analytical (ss|ss) if la == 0 && lb == 0 && lc == 0 && ld == 0 { return eri_ss_ss(qd); }
}
/// VRR on center C — vertical recurrence increasing angular momentum on center C /// with cross-terms from centers A and B. /// /// # What it does /// /// Implements the Obara-Saika VRR that increases the angular momentum on center C /// by one unit in Cartesian direction dim. This recurrence includes cross-terms /// from the bra side (centers A and B) because the bra and ket product centers /// are coupled through the Boys function: /// /// text /// (ab | c+1_i d) = QC_i · (ab | cd) ///                + (c_i / 2q) · (ab | c−1_i d) ///                + (d_i / 2q) · (ab | cd−1_i) ///                + (1 / 2(p+q)) · a_i · (a−1_i b | cd) ///                + (1 / 2(p+q)) · b_i · (a b−1_i | cd) ///  /// /// # Implementation note /// /// This function is a stub that returns [eri_ss_ss] when all angular momenta /// are zero, and 0.0 otherwise. The real computation goes through the /// circuit/crystallizer pipeline. See [vrr_a] for details on the pipeline. /// /// # Arguments /// /// * qd — Precomputed geometric data for the shell quartet /// * la — Angular momentum on center A /// * lb — Angular momentum on center B /// * lc — Angular momentum on center C /// * ld — Angular momentum on center D /// * dim — Cartesian direction (0=x, 1=y, 2=z) /// /// # Returns /// /// The ERI value. For the (ss|ss) case, returns the analytical result. /// For higher angular momenta, returns 0.0 (use the crystallized code instead). fn vrr_c(qd: &QuartetData, la: usize, lb: usize, lc: usize, ld: usize, dim: usize) -> f64 { // Base case: all angular momenta zero → return the analytical (ss|ss) if la == 0 && lb == 0 && lc == 0 && ld == 0 { return eri_ss_ss(qd); }
}
/// Dispatch to the appropriate VRR recurrence for an ERI shell quartet. /// /// # What it does /// /// Determines which VRR recurrence to apply based on the angular momenta of the /// four centers and dispatches accordingly. The strategy is: /// /// 1. If all angular momenta are zero: return the analytical (ss|ss) result. /// 2. If center A has the highest angular momentum: use [vrr_a] to reduce it. /// 3. Otherwise: use [vrr_c] to reduce the ket-side angular momentum. /// /// # Implementation note /// /// This function is a stub. In the POLER-ERI pipeline, the actual computation /// for arbitrary angular momenta goes through the circuit/crystallizer pipeline: /// /// 1. [CircuitBuilder::new(la, lb, lc, ld).build_circuit()] constructs the ///    recurrence relation circuit. /// 2. [VrrCrystallizer::crystallize(&circuit, name)] compiles it to Rust code. /// 3. [BatchCompiler] generates all quartet functions at once. /// /// The stub provides a correct result for the (ss|ss) base case and serves as /// a placeholder for the full recurrence chain. /// /// # Arguments /// /// * qd — Precomputed geometric data for the shell quartet /// * la — Angular momentum on center A /// * lb — Angular momentum on center B /// * lc — Angular momentum on center C /// * ld — Angular momentum on center D /// /// # Returns /// /// The ERI value. For the (ss|ss) case, returns the analytical result from /// [eri_ss_ss]. For higher angular momenta, returns 0.0. /// /// # Examples /// /// /// use poler_eri::{QuartetData, Point}; /// use poler_eri::vrr::eri_base; /// /// // (ss|ss) base case /// let qd = QuartetData::new( ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     1.0, 1.0, 1.0, 1.0, /// ); /// let val = eri_base(&qd, 0, 0, 0, 0); /// assert!(val > 0.0, "(ss|ss) should be positive"); /// pub fn eri_base(qd: &QuartetData, la: usize, lb: usize, lc: usize, ld: usize) -> f64 { // Base case: (ss|ss) — compute analytically if la == 0 && lb == 0 && lc == 0 && ld == 0 { return eri_ss_ss(qd); }
}
#[cfg(test)] mod tests { use super::*; use crate::types::Point;
}
\n---\n\n### poler-eri/src/eri.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-eri/src/eri.rs //! ERI shell-level wrapper for computing batches of two-electron integrals. //! //! # What this module does //! //! This module provides a shell-level interface for computing all two-electron //! repulsion integrals (ERIs) for a given shell quartet. While the VRR and HRR //! modules operate on individual primitive integrals, this module handles the //! full Cartesian component enumeration and returns the complete integral batch. //! //! # Why this module exists //! //! A shell quartet (a b | c d) with angular momenta (la, lb, lc, ld) contains //! //! text //! ncart(la) × ncart(lb) × ncart(lc) × ncart(ld) //! ``` //! //! individual integrals, one for each combination of Cartesian components on the //! four centers. For example, a (pp|pp) quartet has 3×3×3×3 = 81 integrals. //! //! The [eri_shell] function computes all of these at once, returning them in a //! flat array with a well-defined ordering convention. //! //! # Implementation notes //! //! Currently, this function fills the entire output array with the [`eri_base`] //! value. This is because the real computation for arbitrary angular momenta goes //! through the circuit/crystallizer pipeline, which generates optimized Rust //! code for each specific (la, lb, lc, ld) quartet. The shell-level wrapper is //! designed so that once the crystallized code is available, it can be plugged in //! without changing the API. //! //! For the (ss|ss) case, the returned value is exact. For higher angular momenta, //! the values are placeholder values that should be replaced by the crystallized //! ERI function in production use.
use crate::cart::ncart; use crate::types::QuartetData; use crate::vrr::eri_base;
/// Compute all ERIs for a shell quartet (a b | c d). /// /// # What it does /// /// Returns a flat array containing all /// ncart(la) × ncart(lb) × ncart(lc) × ncart(ld) Cartesian ERI values for the /// specified shell quartet. The ordering follows the convention: /// /// text /// result[i_a * stride_a + i_b * stride_b + i_c * stride_c + i_d] ///  /// /// where: /// - i_a ranges over the ncart(la) Cartesian components of shell a /// - i_b ranges over the ncart(lb) Cartesian components of shell b /// - i_c ranges over the ncart(lc) Cartesian components of shell c /// - i_d ranges over the ncart(ld) Cartesian components of shell d /// - stride_a = ncart(lb) * ncart(lc) * ncart(ld) /// - stride_b = ncart(lc) * ncart(ld) /// - stride_c = ncart(ld) /// - stride_d = 1 /// /// This is row-major ordering with the bra indices varying slowest and the ket /// indices varying fastest, matching the convention used in libcint and Libint. /// /// # Why it returns a flat array /// /// A flat Vec<f64> avoids the overhead of nested Vec<Vec<...>> and is /// compatible with BLAS/LAPACK routines that expect contiguous memory. The /// stride information can be computed from the angular momenta at the call site. /// /// # How it works (current implementation) /// /// For the (ss|ss) case (all angular momenta zero), the single integral value /// is computed exactly using [eri_base], which delegates to [eri_ss_ss]. /// /// For higher angular momenta, the current implementation fills the entire /// output array with the eri_base value. This is a placeholder — in /// production, the crystallized ERI function should be used instead. The /// crystallized code computes each Cartesian component correctly using the /// VRR/HRR recurrence chain compiled by the circuit/crystallizer pipeline. /// /// # Arguments /// /// * qd — Precomputed geometric data for the shell quartet /// * la — Angular momentum on center A (0=s, 1=p, 2=d, ...) /// * lb — Angular momentum on center B /// * lc — Angular momentum on center C /// * ld — Angular momentum on center D /// /// # Returns /// /// A flat array of length ncart(la) * ncart(lb) * ncart(lc) * ncart(ld) /// containing the ERI values in row-major order. /// /// # Examples /// /// /// use poler_eri::{QuartetData, Point}; /// use poler_eri::eri::eri_shell; /// /// // (ss|ss) quartet: single integral /// let qd = QuartetData::new( ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     1.0, 1.0, 1.0, 1.0, /// ); /// let eris = eri_shell(&qd, 0, 0, 0, 0); /// assert_eq!(eris.len(), 1); /// assert!(eris[0] > 0.0); /// /// // (pp|ss) quartet: 3*3*1*1 = 9 integrals /// let eris_pp = eri_shell(&qd, 1, 1, 0, 0); /// assert_eq!(eris_pp.len(), 9); /// pub fn eri_shell(qd: &QuartetData, la: usize, lb: usize, lc: usize, ld: usize) -> Vec<f64> { let na = ncart(la); let nb = ncart(lb); let nc = ncart(lc); let nd = ncart(ld); let total = na * nb * nc * nd;
}
#[cfg(test)] mod tests { use super::*; use crate::types::Point;
}
\n---\n\n### poler-eri/src/shell_driver.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-eri/src/shell_driver.rs //! Shell-level driver for computing ALL Cartesian component ERIs for a shell quartet. //! //! # Overview //! //! This module implements the `ShellQuartetDriver`, which bridges the gap between //! the generated ERI kernels (which compute `I(na, nb | nc, nd)` for one direction //! and one Rys root) and the full shell-level API that libcint provides. //! //! # The Rys Quadrature Algorithm //! //! For a shell quartet `(la, lb | lc, ld)`, the ERI for Cartesian component //! `(na_x, na_y, na_z)` on A, `(nb_x, nb_y, nb_z)` on B, etc. is: //! //! text //! (a b | c d) = prefactor * K_ab * K_cd * //!     Σ_k  w_k * I_x(na_x, nb_x | nc_x, nd_x, t_k) //!                * I_y(na_y, nb_y | nc_y, nd_y, t_k) //!                * I_z(na_z, nb_z | nc_z, nd_z, t_k) //! ``` //! //! where the sum is over Rys quadrature roots t_k with weights `w_k`. //! //! # Implementation Strategy //! //! The driver evaluates the R1CS circuit (from [`Circuit`]) for each Cartesian //! direction (x, y, z) and each Rys root. The circuit computes ALL intermediate //! VRR/HRR results simultaneously, so a single evaluation per (direction, root) //! pair gives us the integrals for every Cartesian component combination. //! //! For Cartesian components where the circuit's `find_operand` returns `None` //! (specifically, non-(la, lb) bra pairs with nd > 0 on the ket side), the //! driver applies the HRR-Ket recurrence manually using the `hrr_bra_map` //! entries as starting points. //! //! # Kernel Dispatch //! //! When a crystallized (generated) kernel is available for the shell quartet //! (all quartets from (ss|ss) through (ff|ff)), the driver dispatches to the //! pre-compiled kernel function for maximum performance. For higher angular //! momenta (la > 3), the generic [`evaluate_circuit`] function is used as a //! fallback. The crystallized kernels produce identical results to the generic //! circuit evaluation but avoid the overhead of interpreting the circuit data //! structure at runtime.
use crate::cart::{cart_comps, ncart}; use crate::circuit::{evaluate_circuit, Circuit, CircuitBuilder}; use crate::eri_dispatch::{dispatch_eri_kernel, EriKernelFn}; use crate::eri_rys::rys_roots_weights; use crate::types::{CartComp, Point, QuartetData};
// ───────────────────────────────────────────────────────────────────────────── // ExtractionPlan: How to extract a 1D integral component from circuit operands // ─────────────────────────────────────────────────────────────────────────────
/// Strategy for extracting I(na, nb | nc, nd) for one Cartesian direction /// from the circuit's operand array after evaluation. /// /// Most integral components are computed directly by the circuit and can be /// read from a known operand index. However, when (na, nb) != (la, lb) and /// nd > 0, the circuit does not record the HRR-Ket intermediates for that /// bra pair. In this case, we must apply the HRR-Ket recurrence manually /// using the bra-side intermediates from [Circuit::hrr_bra_map]. #[derive(Debug, Clone)] pub enum ExtractionPlan { /// The circuit computes this integral directly. /// Read the value from operands[idx] after circuit evaluation. Direct { /// Operand index in the circuit's operand array. idx: usize, },
}
// ───────────────────────────────────────────────────────────────────────────── // ShellQuartetDriver: Precomputed data for a shell quartet // ─────────────────────────────────────────────────────────────────────────────
/// Precomputed driver for evaluating ALL Cartesian component ERIs for a /// shell quartet (la, lb | lc, ld). /// /// The driver holds the R1CS circuit and precomputed extraction plans for /// every Cartesian component combination. Construction is O(1) relative to /// the number of Cartesian components (it just builds lookup tables). The /// expensive computation happens in [ShellQuartetDriver::compute]. /// /// # Construction /// /// rust /// use poler_eri::shell_driver::ShellQuartetDriver; /// /// let driver = ShellQuartetDriver::new(1, 1, 1, 1); // (pp|pp) /// assert_eq!(driver.total_integrals(), 81); // 3^4 = 81 ///  /// /// # Usage /// /// rust /// use poler_eri::{QuartetData, Point}; /// use poler_eri::shell_driver::ShellQuartetDriver; /// /// let driver = ShellQuartetDriver::new(0, 0, 0, 0); // (ss|ss) /// let qd = QuartetData::new( ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     1.0, 1.0, 1.0, 1.0, /// ); /// let eris = driver.compute(&qd); /// assert_eq!(eris.len(), 1); ///  #[derive(Debug, Clone)] pub struct ShellQuartetDriver { /// Angular momentum on center A. pub la: usize, /// Angular momentum on center B. pub lb: usize, /// Angular momentum on center C. pub lc: usize, /// Angular momentum on center D. pub ld: usize, /// Number of Cartesian components for each shell. na: usize, nb: usize, nc: usize, nd: usize, /// Total number of ERI values: na * nb * nc * nd. total: usize, /// Cartesian component enumerations for each shell. comps_a: Vec<CartComp>, comps_b: Vec<CartComp>, comps_c: Vec<CartComp>, comps_d: Vec<CartComp>, /// The R1CS circuit for this shell quartet. circuit: Circuit, /// Extraction plans for each Cartesian component combination and direction. /// Indexed as plans[flat_idx][dim] where dim = 0 (x), 1 (y), 2 (z). plans: Vec<[ExtractionPlan; 3]>, /// Crystallized kernel for this shell quartet, if available. /// Contains (n_operands, kernel_fn) from [dispatch_eri_kernel]. /// When Some, compute() uses the crystallized kernel instead of /// [evaluate_circuit] for each (direction, root) evaluation. crystallized: Option<(usize, EriKernelFn)>, }
impl ShellQuartetDriver { /// Construct a new driver for the shell quartet (la, lb | lc, ld). /// /// This builds the R1CS circuit and precomputes all extraction plans. /// The construction cost is proportional to the number of Cartesian /// component combinations (which is at most ncart(la) * ncart(lb) * /// ncart(lc) * ncart(ld)). /// /// # Panics /// /// Panics if la < lb or lc < ld (permutational symmetry violation), /// as required by [CircuitBuilder::new]. pub fn new(la: usize, lb: usize, lc: usize, ld: usize) -> Self { let na = ncart(la); let nb = ncart(lb); let nc = ncart(lc); let nd = ncart(ld); let total = na * nb * nc * nd;
}
// ───────────────────────────────────────────────────────────────────────────── // Build extraction plan // ─────────────────────────────────────────────────────────────────────────────
/// Build an extraction plan for I(na, nb | nc, nd) from the circuit. /// /// First tries [Circuit::find_operand]. If that returns None (which happens /// when (na, nb) != (la, lb) and nd > 0), falls back to a manual HRR-Ket /// plan using the hrr_bra_map entries. fn build_extraction_plan(circuit: &Circuit, na: usize, nb: usize, nc: usize, nd: usize) -> ExtractionPlan { // Try direct lookup first if let Some(idx) = circuit.find_operand(na, nb, nc, nd) { return ExtractionPlan::Direct { idx }; }
}
// ───────────────────────────────────────────────────────────────────────────── // Extract value from operands using an extraction plan // ─────────────────────────────────────────────────────────────────────────────
/// Extract the value of I(na, nb | nc, nd) from the operand array using /// the precomputed extraction plan. /// /// For [ExtractionPlan::Direct], simply reads operands[idx]. /// /// For [ExtractionPlan::ManualHrrKet], applies the HRR-Ket recurrence /// manually: /// /// text /// Row l=0:  I(na, nb | k, 0)  for k = 0..(nc+nd)   (from hrr_bra_map) /// Row l=1:  I(na, nb | k, 1)  for k = 0..(nc+nd-1) ///   ... /// Row l=nd: I(na, nb | nc, nd)                      (the target) ///  /// /// The HRR-Ket formula is: /// I(na, nb | k, l) = I(na, nb | k+1, l-1) + (-CD) * I(na, nb | k, l-1) fn extract_value(plan: &ExtractionPlan, operands: &[f64], prefactors: &[f64; 7]) -> f64 { match plan { ExtractionPlan::Direct { idx } => { if *idx < operands.len() { operands[*idx] } else { 0.0 } }
}
// ───────────────────────────────────────────────────────────────────────────── // Prefactor computation // ─────────────────────────────────────────────────────────────────────────────
/// Compute the 7 prefactors for one Rys root and one Cartesian direction. /// /// The prefactor layout (matching the circuit's convention): /// /// | Index | Name  | Formula                          | Root-dependent | /// |-------|-------|----------------------------------|----------------| /// | 0     | c00   | PA[dim] + t * PQ[dim]          | Yes            | /// | 1     | c0p   | QC[dim] + t * PQ[dim]          | Yes            | /// | 2     | b10   | 1 / (2p)                       | No             | /// | 3     | b01   | 1 / (2q)                       | No             | /// | 4     | b00   | t / (2(p+q))                   | Yes            | /// | 5     | -AB   | -(A[dim] - B[dim]) = B[dim] - A[dim] | No      | /// | 6     | -CD   | -(C[dim] - D[dim]) = D[dim] - C[dim] | No      | /// /// # Arguments /// /// * qd — Precomputed geometric data for the primitive quartet. /// * t  — Rys root value (the quadrature abscissa squared). /// * dim — Cartesian direction: 0 = x, 1 = y, 2 = z. /// /// # Returns /// /// A fixed-size array of 7 prefactor values. pub fn compute_prefactors(qd: &QuartetData, t: f64, dim: usize) -> [f64; 7] { let p = qd.p; let q = qd.q;
}
// ───────────────────────────────────────────────────────────────────────────── // Rys root computation // ─────────────────────────────────────────────────────────────────────────────
/// Compute Rys quadrature roots and weights for the given T value. /// /// This is a convenience wrapper around [rys_roots_weights] from the /// eri_rys module. The Rys parameter is T = rho * |P - Q|², where /// rho = p*q/(p+q) is the reduced exponent and |P - Q|² is the /// squared distance between the bra and ket product centers. /// /// # Arguments /// /// * t — The Rys parameter T = rho * R_PQ², must be non-negative. /// * nroots — Number of quadrature points (= Rys order). /// /// # Returns /// /// A tuple (roots, weights) of length nroots each. /// /// # Examples /// /// /// use poler_eri::shell_driver::compute_rys_roots; /// /// let (roots, weights) = compute_rys_roots(1.0, 1); /// assert_eq!(roots.len(), 1); /// assert!(roots[0] >= 0.0 && roots[0] <= 1.0); /// assert!(weights[0] > 0.0); /// pub fn compute_rys_roots(t: f64, nroots: usize) -> (Vec<f64>, Vec<f64>) { rys_roots_weights(t, nroots) }
// ───────────────────────────────────────────────────────────────────────────── // Main entry point // ─────────────────────────────────────────────────────────────────────────────
/// Compute ALL Cartesian component ERIs for a shell quartet (single primitive). /// /// This is the main entry point for the shell driver. It computes all /// ncart(la) * ncart(lb) * ncart(lc) * ncart(ld) ERI values for the /// specified primitive quartet. /// /// # Algorithm /// /// 1. Build the ShellQuartetDriver for the given angular momenta. /// 2. Compute Rys roots and weights for T = rho * |P - Q|². /// 3. For each Rys root, evaluate the circuit for directions x, y, z. /// 4. Extract I(na, nb | nc, nd) for each Cartesian component and accumulate ///    w_k * I_x * I_y * I_z. /// 5. Multiply by prefactor * K_ab * K_cd. /// /// # Ordering /// /// The result array uses row-major ordering with bra indices varying slowest: /// /// text /// result[ia * stride_a + ib * stride_b + ic * stride_c + id] ///  /// /// where: /// - stride_a = ncart(lb) * ncart(lc) * ncart(ld) /// - stride_b = ncart(lc) * ncart(ld) /// - stride_c = ncart(ld) /// - stride_d = 1 /// /// # Arguments /// /// * qd — Precomputed geometric data for the primitive quartet. /// * la — Angular momentum on center A (0=s, 1=p, 2=d, ...). /// * lb — Angular momentum on center B. /// * lc — Angular momentum on center C. /// * ld — Angular momentum on center D. /// /// # Returns /// /// A flat array of ERI values in row-major order. /// /// # Examples /// /// /// use poler_eri::{QuartetData, Point}; /// use poler_eri::shell_driver::eri_shell_full; /// /// // (ss|ss) quartet: single integral /// let qd = QuartetData::new( ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     Point([0.0, 0.0, 0.0]), Point([0.0, 0.0, 0.0]), ///     1.0, 1.0, 1.0, 1.0, /// ); /// let eris = eri_shell_full(&qd, 0, 0, 0, 0); /// assert_eq!(eris.len(), 1); /// assert!(eris[0] > 0.0); /// pub fn eri_shell_full(qd: &QuartetData, la: usize, lb: usize, lc: usize, ld: usize) -> Vec<f64> { let driver = ShellQuartetDriver::new(la, lb, lc, ld); driver.compute(qd) }
// ───────────────────────────────────────────────────────────────────────────── // Tests // ─────────────────────────────────────────────────────────────────────────────
#[cfg(test)] mod tests { use super::*;
}
\n---\n\n### poler-eri/src/eri_rys.rs
⚠️ Этот файл очень большой (>1000 строк) — содержит прямую порту rys_root1/2/3/4 из libcint. Файл включён в архив poler-unified-source.tar.gz.
Ключевая функция:
Вычисляет корни и веса Rys-квадратуры для nroots = 1..9. Прямой порт полиномиальных аппроксимаций из libcint.
--------------------------------------------------------------------------------
5. Исходный код: poler-dynamis\n\n### poler-dynamis/src/gto_utils.rs\n\n```rust
// FILE: /home/z/my-project/poler-unified/poler-dynamis/src/gto_utils.rs //! gto_utils.rs — Модуль нормализации Гауссовых примитивов //! //! Устраняет дублирование между cint_gto_norm() и gto_normalization() //! в basis_parser.rs. //! //! # Математическая основа //! //! Нормализационный коэффициент для радиальной части GTO g = r^l * exp(-alpha * r^2): //! //! text //! N_l(alpha) = 1 / sqrt( integral_0^inf [r^(2l) * exp(-2*alpha*r^2)]^2 * r^2 dr ) //!            = 1 / sqrt( gaussian_int(2l+2, 2*alpha) ) //!  //! //! где gaussian_int — гауссов интеграл: //! //! text //! integral_0^inf r^n * exp(-a*r^2) dr = Gamma((n+1)/2) / (2 * a^((n+1)/2)) //!  //! //! Использование libm::lgamma (логарифма гамма-функции) обеспечивает: //! - Численную стабильность при высоких l (l >= 6, i/k-орбитали) //! - Отсутствие переполнения integer (в отличие от double_factorial) //! - Кросс-платформенную совместимость без extern "C" FFI
/// Безопасная обёртка над lgamma через libm. /// /// libm::lgamma(x) возвращает log(|Gamma(x)|), что обеспечивает /// численную стабильность при высоких угловых моментах. #[inline] fn lgamma_rs(x: f64) -> f64 { libm::lgamma(x) }
/// Вычисление гауссова интеграла: /// /// text /// integral_0^inf r^n * exp(-a * r^2) dr = Gamma((n+1)/2) / (2 * a^((n+1)/2)) ///  /// /// Использует lgamma для высокой численной стабильности. #[inline] fn gaussian_int(n: i64, alpha: f64) -> f64 { let n1 = (n as f64 + 1.0) * 0.5; lgamma_rs(n1).exp() / (2.0 * alpha.powf(n1)) }
/// Нормализация GTO радиальной части. /// /// text /// N_l(alpha) = 1 / sqrt( gaussian_int(2l+2, 2*alpha) ) ///  /// /// # Arguments /// /// * l — Угловой момент (0=s, 1=p, 2=d, 3=f, ...) /// * alpha — Экспонента Гауссова примитива /// /// # Returns /// /// Нормализационный коэффициент N_l(alpha) pub fn gto_normalization(l: u8, alpha: f64) -> f64 { if alpha <= 0.0 { return 0.0; } 1.0 / gaussian_int(2 * l as i64 + 2, 2.0 * alpha).sqrt() }
/// Псевдоним для совместимости. /// /// Идемпотентен: cint_gto_norm(l, alpha) == gto_normalization(l, alpha). pub fn cint_gto_norm(l: u8, alpha: f64) -> f64 { gto_normalization(l, alpha) }
#[cfg(test)] mod tests { use super::*;
}
\n---\n\n### poler-dynamis/src/energy_engine.rs\n\nrust // FILE: /home/z/my-project/poler-unified/poler-dynamis/src/energy_engine.rs //! energy_engine.rs — The HEART of the POLER quantum chemistry engine //! //! Implements the canonical equation of motion: //! //! text //! DM_{t+1} = Π_Λ( DM_t − η(t) · [Δ_idem + γ(t)·J·DM + K] ) //! ``` //! //! where: //!   - η(t)  = η₀·exp(−β·Σ_true) is the adaptive learning rate (thermostat) //!   - Π_Λ   = McWeeny retraction (3DM² − 2DM³)/occ_max applied AFTER Euler step //!   - Δ_idem = d·(DM² − occ_max·DM) is the idempotency dissipator //!   - J      = j·(A − A^T) where A = Σ_k P_k · ΔP_k^T (temporal echo R[n]) //!   - γ(t)  = γ₀·exp(−α_σ·Σ)·(1 − t/T_max)² (Feynman annealing) //!   - K      = F·DM·S − S·DM·F is the orbital gradient //!   - Σ_true = ||ΔK||_F / ||ΔDM||_F (secant Hessian approximation) //! //! Uses faer::Mat<f64> exclusively. Eigendecomposition via faer's hermitian EVD //! (fast O(n²·log n) tridiagonal QR, replacing the slow O(n³) cyclic Jacobi).
use faer::{scale, Col, Mat, Parallelism}; use faer::linalg::evd::{compute_hermitian_evd, compute_hermitian_evd_req, ComputeVectors, HermitianEvdParams}; use faer::dyn_stack::PodStack;
// ═══════════════════════════════════════════════════════════════════════════════ // Evolution State — Ring Buffer for Temporal Echo R[n] // ═══════════════════════════════════════════════════════════════════════════════
/// Evolution state tracking DM and K history for resonance computation. /// /// Stores a ring buffer of recent density matrices and orbital gradient matrices, /// enabling the temporal echo operator R[n] (resonance J) to compute the /// cross-correlation integral A = Σ P_t · ΔP_t^T. pub struct EvolutionState { /// Ring buffer of recent DM matrices (most recent last). dm_history: Vec<Mat<f64>>, /// Ring buffer of recent K (orbital gradient) matrices. k_history: Vec<Mat<f64>>, /// Maximum depth of history to retain. max_depth: usize, }
impl EvolutionState { /// Create a new evolution state with the given maximum history depth. pub fn new(max_depth: usize) -> Self { Self { dm_history: Vec::with_capacity(max_depth + 1), k_history: Vec::with_capacity(max_depth + 1), max_depth, } }
}
// ═══════════════════════════════════════════════════════════════════════════════ // DIIS (Direct Inversion in Iterative Subspace) — kept for bootstrap only // ═══════════════════════════════════════════════════════════════════════════════
/// DIIS state for SCF bootstrap acceleration (Phase 1 only). /// /// DIIS is used ONLY during the initial bootstrap phase to rapidly bring /// the DM into the correct orbital subspace. Once the POLER-flow takes over /// (Phase 2), the temporal echo operator J replaces DIIS entirely. pub struct DiisState { fock_history: Vec<Mat<f64>>, error_history: Vec<Mat<f64>>, max_size: usize, min_overlap: f64, }
impl DiisState { pub fn new(max_size: usize) -> Self { Self { fock_history: Vec::with_capacity(max_size + 1), error_history: Vec::with_capacity(max_size + 1), max_size, min_overlap: 1e-12, } }
}
// ═══════════════════════════════════════════════════════════════════════════════ // Configuration & Result Structures // ═══════════════════════════════════════════════════════════════════════════════
/// POLER engine configuration parameters. #[derive(Debug, Clone)] pub struct PolerConfig { // ── Adaptive step η(t) = η₀ · exp(−β_σ · Σ_true) ── /// Initial learning rate. pub eta0: f64, /// Damping factor β_σ for adaptive η: controls how strongly /// topological curvature slows the system. pub beta_sigma: f64,
}
impl Default for PolerConfig { fn default() -> Self { Self { eta0: 0.3, beta_sigma: 3.0,         // Curvature damping for η idem_strength: 0.2,      // Dissipator strength resonance_gamma0: 0.05,  // Initial resonance coupling resonance_j: 0.01,       // Resonance matrix scale alpha_sigma: 2.0,        // Curvature damping for γ resonance_depth: 8,      // History depth for temporal echo mcweeny_order: 1,        // Mild retraction per step occ_max: 2.0, nelec: 2.0, max_iter: 500, conv_tol: 1e-8, phase1_steps: 30,        // DIIS bootstrap only diis_max_vectors: 6, level_shift: 0.0,          // No shift by default; use 0.3 for Li chains } } }
/// POLER convergence result. #[derive(Debug, Clone)] pub struct PolerResult { /// Final density matrix. pub dm: Mat<f64>, /// Final Fock matrix. pub fock: Mat<f64>, /// Electronic energy E = 0.5·(Tr[H·DM] + Tr[F·DM]). pub energy: f64, /// Total iterations performed. pub iterations: usize, /// Whether the engine converged within conv_tol. pub converged: bool, /// Frobenius norm of the final orbital gradient K. pub gradient_norm: f64, /// History of orbital gradient norms ||K||_F per iteration. pub gradient_history: Vec<f64>, /// History of learning rate η per iteration. pub eta_history: Vec<f64>, /// History of topological curvature Σ per iteration. pub curvature_history: Vec<f64>, /// History of resonance coupling γ per iteration. pub gamma_history: Vec<f64>, /// History of electronic energy per iteration. pub energy_history: Vec<f64>, /// Phase label per iteration: "P1" = DIIS, "P2" = POLER-flow. pub phase_history: Vec<String>, }
// ═══════════════════════════════════════════════════════════════════════════════ // Utility Functions // ═══════════════════════════════════════════════════════════════════════════════
/// Compute the Frobenius norm of a matrix: ||M||_F = sqrt(Σ_ij M_ij²). pub fn frobenius_norm(m: &Mat<f64>) -> f64 { let mut sum = 0.0f64; for i in 0..m.nrows() { for j in 0..m.ncols() { let v = m[(i, j)]; sum += v * v; } } sum.sqrt() }
/// Compute the trace of the matrix product A·B: Tr[A·B] = Σ_i (AB)_ii. pub fn trace_product(a: &Mat<f64>, b: &Mat<f64>) -> f64 { let n = a.nrows(); let mut tr = 0.0f64; for i in 0..n { for k in 0..n { tr += a[(i, k)] * b[(k, i)]; } } tr }
/// Symmetrize a matrix: M_sym = 0.5·(M + M^T). pub fn symmetrize(dm: &Mat<f64>) -> Mat<f64> { let n = dm.nrows(); let mut result = Mat::zeros(n, n); for i in 0..n { for j in 0..n { result[(i, j)] = 0.5 * (dm[(i, j)] + dm[(j, i)]); } } result }
/// Matrix subtraction: A − B. fn mat_sub(a: &Mat<f64>, b: &Mat<f64>) -> Mat<f64> { let (r, c) = (a.nrows(), a.ncols()); let mut result = Mat::zeros(r, c); for i in 0..r { for j in 0..c { result[(i, j)] = a[(i, j)] - b[(i, j)]; } } result }
/// Matrix transpose. fn transpose(m: &Mat<f64>) -> Mat<f64> { let (r, c) = (m.nrows(), m.ncols()); let mut t = Mat::zeros(c, r); for i in 0..r { for j in 0..c { t[(j, i)] = m[(i, j)]; } } t }
// ═══════════════════════════════════════════════════════════════════════════════ // Jacobi Eigendecomposition for Symmetric Matrices // ═══════════════════════════════════════════════════════════════════════════════
/// Cyclic Jacobi eigendecomposition for a real symmetric matrix. /// /// Returns (eigenvalues, eigenvectors) where eigenvectors are stored as /// columns of the output matrix. Eigenvalues are sorted in ascending order. /// /// DEPRECATED: Kept as a fallback reference. Use sym_eigen instead for /// ~10-100× speedup on large matrices via faer's tridiagonal QR algorithm. #[allow(dead_code)] fn jacobi_eigen(mat: &Mat<f64>, max_sweeps: usize, tol: f64) -> (Vec<f64>, Mat<f64>) { let n = mat.nrows(); assert_eq!(n, mat.ncols(), "jacobi_eigen requires a square matrix");
}
// ═══════════════════════════════════════════════════════════════════════════════ // Fast Symmetric Eigendecomposition via faer's Hermitian EVD // ═══════════════════════════════════════════════════════════════════════════════
/// Fast symmetric eigendecomposition using faer's hermitian EVD. /// /// Uses the tridiagonal reduction + QR algorithm pathway, which is O(n²·log n) /// compared to the O(n³) cyclic Jacobi. Returns (eigenvalues_sorted_ascending, /// eigenvectors_as_columns). /// /// Note: faer's hermitian EVD accesses only the LOWER triangular part of the /// input matrix. For numerical robustness, we symmetrize the input before /// decomposition to avoid issues with asymmetric floating-point residuals. /// /// This replaces jacobi_eigen for all production use. The Jacobi method is /// retained as #[allow(dead_code)] for reference/testing only. pub fn sym_eigen(mat: &Mat<f64>) -> (Vec<f64>, Mat<f64>) { let n = mat.nrows(); assert_eq!(n, mat.ncols(), "sym_eigen requires a square matrix");
}
// ═══════════════════════════════════════════════════════════════════════════════ // Core Quantum Chemistry Functions // ═══════════════════════════════════════════════════════════════════════════════
/// McWeeny purification: DM_pure = (3/occ_max)·DM² − (2/occ_max²)·DM³ /// /// This is the retraction operator Π_Λ that enforces idempotency DM² = occ_max·DM. /// Applied order times for stronger purification. pub fn mcweeny_purify(dm: &Mat<f64>, occ_max: f64, order: usize) -> Mat<f64> { let c1 = 3.0 / occ_max; let c2 = 2.0 / (occ_max * occ_max);
}
/// Compute the idempotency dissipator Δ_idem = d·(DM² − occ_max·DM). /// /// This term drives the density matrix toward idempotency through a /// dissipative force. It annihilates (becomes zero) when DM is exactly idempotent. pub fn compute_idem_dissipator(dm: &Mat<f64>, d: f64, occ_max: f64) -> Mat<f64> { let dm_sq = dm * dm; let mut result = Mat::zeros(dm.nrows(), dm.ncols()); for i in 0..dm.nrows() { for j in 0..dm.ncols() { result[(i, j)] = d * (dm_sq[(i, j)] - occ_max * dm[(i, j)]); } } result }
/// Compute the orbital gradient K = F·DM·S − S·DM·F. /// /// This is the generalized commutator that vanishes at convergence: /// K = 0 ⟺ [F, DM]_S = 0 ⟺ DM is stationary. pub fn compute_orbital_gradient(fock: &Mat<f64>, dm: &Mat<f64>, s: &Mat<f64>) -> Mat<f64> { let fds = fock * dm * s; let sdf = s * dm * fock; &fds - &sdf }
// ═══════════════════════════════════════════════════════════════════════════════ // Equation 5: Resonance Operator J — Temporal Echo R[n] // ═══════════════════════════════════════════════════════════════════════════════
/// Compute the resonance matrix J = j·(A − A^T) from DM history. /// /// The matrix A is the cross-correlation integral of past states and their /// velocity (change) vectors: /// ///   A = (1/N) Σ_k P_k · ΔP_k^T /// /// where ΔP_k = P_{k+1} − P_k is the velocity (analog of momentum in /// classical mechanics). The skew-symmetric part J = j·(A − A^T) generates /// phase angular momentum on the Grassmann manifold, enabling the system /// to tunnel through local minima via temporal interference of past states. /// /// For RHF with symmetric DM, the old implementation A = DM·DM^T gave /// A − A^T ≡ 0. This corrected version uses the velocity history instead. pub fn compute_resonance( dm_history: &[Mat<f64>], j_strength: f64, depth: usize, ) -> Mat<f64> { if dm_history.len() < 2 || j_strength.abs() < 1e-15 { let n = if dm_history.is_empty() { 1 } else { dm_history[0].nrows() }; return Mat::zeros(n, n); }
}
// ═══════════════════════════════════════════════════════════════════════════════ // Equation 6: True Topological Curvature Σ (Secant Hessian) // ═══════════════════════════════════════════════════════════════════════════════
/// Compute the true topological curvature Σ = ||ΔK||_F / ||ΔDM||_F. /// /// This is a secant approximation to the orbital Hessian ∂²E/∂DM². /// Unlike the old "surprise" (||[F,DM]||_F, which is a gradient not a curvature), /// this quantity correctly measures the dynamic resistance of the energy landscape: /// /// - When the HOMO-LUMO gap is near zero (metallic systems like Li₅₀), ///   even tiny DM changes cause huge gradient swings → Σ → ∞ → η → 0 ///   (system automatically slows down in degenerate zones) /// - When the system is in a smooth basin, Σ is modest → η stays large /// /// Returns 0.0 if ΔDM is negligibly small (absolute rest). pub fn compute_topological_curvature( k_current: &Mat<f64>, k_prev: &Mat<f64>, dm_current: &Mat<f64>, dm_prev: &Mat<f64>, ) -> f64 { let delta_k = mat_sub(k_current, k_prev); let delta_dm = mat_sub(dm_current, dm_prev);
}
// ═══════════════════════════════════════════════════════════════════════════════ // Equation 6: Adaptive Resonance γ(t) — Feynman Annealing // ═══════════════════════════════════════════════════════════════════════════════
/// Compute the adaptive resonance coupling γ(t). /// /// Two mechanisms combined: /// 1. Thermodynamic damping: γ_thermo = γ₀ · exp(−α_σ · Σ) ///    When curvature is high (frustration), the resonance is damped ///    to prevent the system from being ejected from narrow attractor throats. /// /// 2. Feynman annealing: γ_anneal = (1 − t/T_max)² ///    Quadratic schedule that gradually freezes oscillations, ///    allowing final crystallization (phase Ψ, H_Ψ = 0). /// /// Combined: γ(t) = γ₀ · exp(−α_σ · Σ) · (1 − t/T_max)² pub fn compute_gamma_t( gamma0: f64, alpha_sigma: f64, sigma_true: f64, current_step: usize, max_steps: usize, ) -> f64 { // 1. Thermodynamic damping through curvature let gamma_thermo = gamma0 * (-alpha_sigma * sigma_true).exp();
}
/// Adaptive learning rate: η(t) = η₀ · exp(−β · Σ_true). /// /// Returns the new η, clamped to [1e-6, 2.0] for numerical safety. pub fn adaptive_eta(sigma_true: f64, eta0: f64, beta: f64) -> f64 { (eta0 * (-beta * sigma_true).exp()).clamp(1e-6, 2.0) }
/// Compute the POLER free energy: E = 0.5·(Tr[H_core·DM] + Tr[F·DM]). pub fn compute_free_energy(h_core: &Mat<f64>, fock: &Mat<f64>, dm: &Mat<f64>) -> f64 { 0.5 * (trace_product(h_core, dm) + trace_product(fock, dm)) }
/// Ensure the density matrix has the correct electron count. /// /// Scales DM so that Tr[DM·S] = nelec. pub fn ensure_electron_count(dm: &Mat<f64>, s: &Mat<f64>, nelec: f64) -> Mat<f64> { let ds = dm * s; let mut current_nelec = 0.0f64; for i in 0..ds.nrows() { current_nelec += ds[(i, i)]; } if current_nelec.abs() < 1e-14 { return dm.clone(); } let scale_factor = nelec / current_nelec; let mut result = dm.clone(); for i in 0..result.nrows() { for j in 0..result.ncols() { result[(i, j)] *= scale_factor; } } result }
// ═══════════════════════════════════════════════════════════════════════════════ // Overlap Inverse Square Root & DM Construction // ═══════════════════════════════════════════════════════════════════════════════
/// Compute S^{-1/2} = U · diag(s^{-1/2}) · U^T from the overlap matrix S. fn compute_sinv_half(s: &Mat<f64>) -> Mat<f64> { let n = s.nrows(); let (s_evals, s_evecs) = sym_eigen(s);
}
/// Build the density matrix from a Fock matrix via Roothaan-Hall diagonalization. /// /// If level_shift > 0, adds a shift to virtual orbital eigenvalues before /// building the DM. This creates an artificial gap that stabilizes metallic /// systems (e.g., Li chains) by preventing orbital scrambling between nearly /// degenerate occupied and virtual states. /// /// The level shift is equivalent to adding shift * (I - P_occ) to the Fock /// matrix in the orthogonal basis, where P_occ is the occupied subspace projector. /// This stabilizes WHICH orbitals are occupied without changing the final energy. fn build_dm_from_fock( fock: &Mat<f64>, sinv_half: &Mat<f64>, nelec: f64, occ_max: f64, level_shift: f64, ) -> Mat<f64> { let n = fock.nrows(); let nocc = (nelec / occ_max) as usize;
}
// ═══════════════════════════════════════════════════════════════════════════════ // POLER Engine // ═══════════════════════════════════════════════════════════════════════════════
/// The main POLER quantum chemistry engine. /// /// Implements the canonical equation of motion: /// /// text /// DM_{t+1} = Π_Λ( DM_t − η(t) · [Δ_idem + γ(t)·J·DM + K] ) ///  /// /// Phase 1 (bootstrap): DIIS-accelerated SCF to rapidly bring DM /// into the correct orbital subspace. /// /// Phase 2 (POLER-flow): The full canonical equation with: ///   - Adaptive step η(t) = η₀·exp(−β·Σ_true) ///   - True topological curvature Σ = ||ΔK||/||ΔDM|| ///   - Temporal echo J from DM history ring buffer ///   - Feynman-annealed resonance γ(t) = γ₀·exp(−α·Σ)·(1−t/T)² ///   - McWeeny retraction Π_Λ after each Euler step pub struct PolerEngine { pub config: PolerConfig, }
impl PolerEngine { pub fn new(config: PolerConfig) -> Self { Self { config } }
}
// ═══════════════════════════════════════════════════════════════════════════════ // Tests // ═══════════════════════════════════════════════════════════════════════════════
#[cfg(test)] mod tests { use super::*;
}
S_ss(α, β, R_AB²) = (π / (α + β))^(3/2) · exp(−α·β·R_AB² / (α + β))
S_{0,0} = √(π/p) · exp(−μ·Δ²)    (1D base) S_{i+1,j} = PA · S_{i,j} + (1/2p) · (i · S_{i-1,j} + j · S_{i,j-1}) S_{i,j+1} = PB · S_{i,j} + (1/2p) · (i · S_{i-1,j} + j · S_{i,j-1})
T_ss = μ · (3 − 2·μ·R_AB²) · S_ss
T_{0,0} = μ · (1 − 2·μ·Δ²) · S_{0,0}    (1D base) T_{i+1,j} = PA · T_{i,j} + (1/2p) · (i·T_{i-1,j} + j·T_{i,j-1}) + (1/2p) · (i·S_{i-1,j} + j·S_{i,j-1})
V_ss = −Z_C · 2π/p · F_0(p·R_PC²) · exp(−μ·R_AB²)
E^{0,0}_0 = 1 E^{i+1,j}t = PA·E^{i,j}{t-1} + (t+1)/(2p)·E^{i,j}{t+1} E^{i,j+1}t = PB·E^{i,j}{t-1} + (t+1)/(2p)·E^{i,j}{t+1}
R_{0,0,0}^{n} = −Z_C · 2π/p · F_n(T) · exp(−μ·R_AB²) R_{t+1,u,v}^{n} = t · R_{t-1,u,v}^{n+1} + X_PC · R_{t,u,v}^{n+1} R_{t,u+1,v}^{n} = u · R_{t,u-1,v}^{n+1} + Y_PC · R_{t,u,v}^{n+1} R_{t,u,v+1}^{n} = v · R_{t,u,v-1}^{n+1} + Z_PC · R_{t,u,v}^{n+1}
V_{a,b} = Σ_{t,u,v} E^{a_x,b_x}_t · E^{a_y,b_y}_u · E^{a_z,b_z}v · R{t,u,v}^{0}
R_{0,0,0}^{n} = (−2π/p) · (−Z_C) · F_n(T) · exp(−μ·R_AB²)
(ss|ss) = 2π²/(p·q) · √(π/(p+q)) · K_ab · K_cd · F_0(ρ·R_PQ²)
(a+1_i b | cd) = PA_i·(ab|cd) + (a_i/2p)·(a-1_i b|cd) + (b_i/2p)·(a b-1_i|cd) + (1/2(p+q))·c_i·(ab|c-1_i d) + (1/2(p+q))·d_i·(ab|cd-1_i)
(a+1_i b | cd) = (a b+1_i | cd) + AB_i · (ab | cd)     (bra-side) (ab | c+1_i d) = (ab | c d+1_i) + CD_i · (ab | cd)     (ket-side)
F = H_core + J − 0.5·K
J[μ,ν] = Σ_{λ,σ} D[λ,σ] · (μν|λσ)     (Кулон) K[μ,λ] = Σ_{ν,σ} D[ν,σ] · (μν|λσ)     (Обмен, перестановка ν↔λ)
E_elec = 0.5 · Tr[(H_core + F) · D] E_total = E_elec + E_nuc
F_m(T) = ∫₀¹ u^(2m) · exp(−T·u²) du
F_0(T) = √(π/T) · erf(√T) / 2      для T > 0 F_0(0) = 1.0 F_{m+1}(T) = [(2m+1)·F_m(T) − exp(−T)] / (2T)
poler-eri/                      # Крейт интегралов ├── src/ │   ├── types.rs                # Shell, QuartetData, BasisSet │   ├── cart.rs                 # cart_comps, ncart │   ├── normalization.rs        # GTO-нормализация │   ├── overlap.rs              # overlap_ss (s-type base) │   ├── kinetic.rs              # kinetic_ss (s-type base) │   ├── nuclear.rs              # nuclear_ss (s-type base) │   ├── one_electron.rs         # OS+MD для l=0..3 ⚠️ BUG в nuclear_shell │   ├── boys.rs                 # Boys function │   ├── vrr.rs                  # VRR stubs │   ├── hrr.rs                  # HRR stubs │   ├── eri.rs                  # ERI shell wrapper │   ├── eri_engine.rs           # Молекулярный ERI движок (J/K матрицы) │   ├── eri_rys.rs              # Rys quadrature (порт libcint) │   ├── shell_driver.rs         # ShellQuartetDriver │   ├── circuit.rs              # R1CS circuit builder │   ├── eri_dispatch.rs         # Dispatch к кристаллизованным ядрам │   ├── integral_backend.rs     # IntegralBackend trait + PolerBackend │   ├── engine.rs               # IntegralEngine (one-electron) │   └── generated/              # ~100 автогенерированных ERI ядер ├── basis/                      # 6-31G.dat, cc-pvdz.dat └── examples/                   # Диагностические примеры
poler-dynamis/                  # Крейт SCF-движка ├── src/ │   ├── gto_utils.rs            # lgamma фикс ✅ │   ├── pipeline.rs             # FFI фикс ✅ │   ├── energy_engine.rs        # POLER Engine (DIIS + POLER-flow) │   ├── basis_parser.rs         # STO-3G парсер │   └── elements.rs             # Периодическая таблица └── basis/                      # 6-31G.dat, cc-pvdz.dat
--------------------------------------------------------------------------------
Приложение Б: Дополнительные исходные файлы
poler-eri/src/eri_rys.rs
poler-eri/src/circuit.rs
poler-eri/src/engine.rs
poler-eri/src/eri_dispatch.rs
poler-eri/src/screening.rs
poler-eri/src/density.rs
poler-eri/src/contraction.rs
poler-eri/src/diagonalize.rs
poler-eri/src/dipole.rs
poler-eri/src/lib.rs
poler-eri/src/molecule.rs
poler-eri/src/basis.rs
poler-eri/src/cart2sph.rs
poler-dynamis/src/basis_parser.rs
poler-dynamis/src/elements.rs
poler-dynamis/src/lib.rs
poler-dynamis/src/main.rs
poler-eri/Cargo.toml
poler-dynamis/Cargo.toml
Примеры сгенерированных ERI ядер (poler-eri/src/generated/)
Полный набор из ~100 файлов включён в архив poler-unified-source.tar.gz
poler-eri/src/generated/mod.rs
poler-eri/src/generated/eri_ssdd.rs
poler-eri/src/generated/eri_ssdp.rs
poler-eri/src/generated/eri_ssds.rs
poler-eri/src/generated/eri_ssfd.rs
Диагностические примеры (poler-eri/examples/)
poler-eri/examples/debug_nuc.rs
poler-eri/examples/debug_sign.rs
poler-eri/examples/diag_cross_prim.rs
poler-eri/examples/diag_eri.rs
poler-eri/examples/diag_nuc_compare.rs
poler-eri/examples/diag_nuc_pp.rs
poler-eri/examples/diag_nuclear_simple.rs
poler-eri/examples/diag_overshell.rs
poler-eri/examples/diag_p_orbital.rs
poler-eri/examples/diag_prim_nuc.rs
poler-eri/examples/diag_pyscf.rs
poler-eri/examples/test_nuclear.rs
FPGA Reference (POLER_FPGA_Code_v3.md)
1/10 test.matrix multiplication correctness... OK 2/10 test.Hadamard product element-wise... OK 3/10 test.deformed tensor product: ε=0 reduces to matrix multiply... OK 4/10 test.deformed tensor product: ε>0 adds Hadamard deformation... OK 5/10 test.dissipator D = L·L^T is symmetric positive semi-definite... OK 6/10 test.resonance J = A - A^T is skew-symmetric... OK 7/10 test.logical projector Π_Λ is idempotent: Π² = Π... OK 8/10 test.quantum normalization preserves direction... OK 9/10 test.POLER cycle converges to attractor... OK 10/10 test.matrix inversion correctness... OK
PASS: I (x)_0 (2I) = 2I PASS: I (x)_0.3125 I = 1.3125I PASS: diag (x)_0 diag PASS: I (x)_0 (3I) = 3I PASS: I (x)_2 I = 3I PASS: 0 (x)_1 I = 0 ALL TESTS PASSED
PASS: POLER cycle completed (Newton-Schulz + CORDIC working) PASS: POLER (mix=0) ran 512 iterations PASS: CORDIC verified via POLER with mix>0 PASS: Full POLER ran 512 iterations ALL TESTS PASSED
main.zig
build.zig
Verilog Code (Q32.32, FPGA hardware, iverilog-verified)
newton_schulz_inv.v (NEW — Critical: Exact Projector)
cordic_inv_sqrt.v (NEW — High Priority: CORDIC Normalization)
--------------------------------------------------------------------------------
Приложение В: Сгенерированные ERI ядра (полный набор)
poler-eri/src/generated/eri_dddd.rs
poler-eri/src/generated/eri_dddp.rs
poler-eri/src/generated/eri_ddds.rs
poler-eri/src/generated/eri_ddfd.rs
poler-eri/src/generated/eri_ddff.rs
poler-eri/src/generated/eri_ddfp.rs
poler-eri/src/generated/eri_ddfs.rs
poler-eri/src/generated/eri_ddpp.rs
poler-eri/src/generated/eri_ddps.rs
poler-eri/src/generated/eri_ddss.rs
poler-eri/src/generated/eri_dpdd.rs
poler-eri/src/generated/eri_dpdp.rs
poler-eri/src/generated/eri_dpds.rs
poler-eri/src/generated/eri_dpfd.rs
poler-eri/src/generated/eri_dpff.rs
poler-eri/src/generated/eri_dpfp.rs
poler-eri/src/generated/eri_dpfs.rs
poler-eri/src/generated/eri_dppp.rs
poler-eri/src/generated/eri_dpps.rs
poler-eri/src/generated/eri_dpss.rs
poler-eri/src/generated/eri_dsdd.rs
poler-eri/src/generated/eri_dsdp.rs
poler-eri/src/generated/eri_dsds.rs
poler-eri/src/generated/eri_dsfd.rs
poler-eri/src/generated/eri_dsff.rs
poler-eri/src/generated/eri_dsfp.rs
poler-eri/src/generated/eri_dsfs.rs
poler-eri/src/generated/eri_dspp.rs
poler-eri/src/generated/eri_dsps.rs
poler-eri/src/generated/eri_dsss.rs
poler-eri/src/generated/eri_fddd.rs
poler-eri/src/generated/eri_fddp.rs
poler-eri/src/generated/eri_fdds.rs
poler-eri/src/generated/eri_fdfd.rs
poler-eri/src/generated/eri_fdff.rs
poler-eri/src/generated/eri_fdfp.rs
poler-eri/src/generated/eri_fdfs.rs
poler-eri/src/generated/eri_fdpp.rs
poler-eri/src/generated/eri_fdps.rs
poler-eri/src/generated/eri_fdss.rs
poler-eri/src/generated/eri_ffdd.rs
poler-eri/src/generated/eri_ffdp.rs
poler-eri/src/generated/eri_ffds.rs
poler-eri/src/generated/eri_fffd.rs
poler-eri/src/generated/eri_ffff.rs
poler-eri/src/generated/eri_fffp.rs
poler-eri/src/generated/eri_fffs.rs
poler-eri/src/generated/eri_ffpp.rs
poler-eri/src/generated/eri_ffps.rs
poler-eri/src/generated/eri_ffss.rs
poler-eri/src/generated/eri_fpdd.rs
poler-eri/src/generated/eri_fpdp.rs
poler-eri/src/generated/eri_fpds.rs
poler-eri/src/generated/eri_fpfd.rs
poler-eri/src/generated/eri_fpff.rs
poler-eri/src/generated/eri_fpfp.rs
poler-eri/src/generated/eri_fpfs.rs
poler-eri/src/generated/eri_fppp.rs
poler-eri/src/generated/eri_fpps.rs
poler-eri/src/generated/eri_fpss.rs
poler-eri/src/generated/eri_fsdd.rs
poler-eri/src/generated/eri_fsdp.rs
poler-eri/src/generated/eri_fsds.rs
poler-eri/src/generated/eri_fsfd.rs
poler-eri/src/generated/eri_fsff.rs
poler-eri/src/generated/eri_fsfp.rs
poler-eri/src/generated/eri_fsfs.rs
poler-eri/src/generated/eri_fspp.rs
poler-eri/src/generated/eri_fsps.rs
poler-eri/src/generated/eri_fsss.rs
poler-eri/src/generated/eri_ppdd.rs
poler-eri/src/generated/eri_ppdp.rs
poler-eri/src/generated/eri_ppds.rs
poler-eri/src/generated/eri_ppfd.rs
poler-eri/src/generated/eri_ppff.rs
poler-eri/src/generated/eri_ppfp.rs
poler-eri/src/generated/eri_ppfs.rs
poler-eri/src/generated/eri_pppp.rs
poler-eri/src/generated/eri_ppps.rs
poler-eri/src/generated/eri_ppss.rs
poler-eri/src/generated/eri_psdd.rs
poler-eri/src/generated/eri_psdp.rs
poler-eri/src/generated/eri_psds.rs
poler-eri/src/generated/eri_psfd.rs
poler-eri/src/generated/eri_psff.rs
poler-eri/src/generated/eri_psfp.rs
poler-eri/src/generated/eri_psfs.rs
poler-eri/src/generated/eri_pspp.rs
poler-eri/src/generated/eri_psps.rs
poler-eri/src/generated/eri_psss.rs
poler-eri/src/generated/eri_ssdd.rs
poler-eri/src/generated/eri_ssdp.rs
poler-eri/src/generated/eri_ssds.rs
poler-eri/src/generated/eri_ssfd.rs
poler-eri/src/generated/eri_ssff.rs
poler-eri/src/generated/eri_ssfp.rs
poler-eri/src/generated/eri_ssfs.rs
poler-eri/src/generated/eri_sspp.rs
poler-eri/src/generated/eri_ssps.rs
poler-eri/src/generated/eri_ssss.rs
poler-eri/src/generated/mod.rs
poler-eri/src/generated/mod_old.rs
--------------------------------------------------------------------------------
Приложение Г: libcint Reference (C source)
Ключевые файлы из libcint-reference для сравнения с нашей реализацией Rys quadrature
/home/z/my-project/poler-archive/libcint-reference/include/cint_funcs.h
/home/z/my-project/poler-archive/libcint-reference/src/autocode/deriv3.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/deriv4.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/dkb.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/gaunt1.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/grad1.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/int1e_grids1.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/int3c1e.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/intor2.c
/home/z/my-project/poler-archive/libcint-reference/src/autocode/lresc.c
/home/z/my-project/poler-archive/libcint-reference/src/breit.c
/home/z/my-project/poler-archive/libcint-reference/src/c2f.c
/home/z/my-project/poler-archive/libcint-reference/src/c2f.h
/home/z/my-project/poler-archive/libcint-reference/src/cart2sph.h
/home/z/my-project/poler-archive/libcint-reference/src/cint1e.c
/home/z/my-project/poler-archive/libcint-reference/src/cint1e.h
/home/z/my-project/poler-archive/libcint-reference/src/cint1e_a.c
/home/z/my-project/poler-archive/libcint-reference/src/cint1e_grids.c
/home/z/my-project/poler-archive/libcint-reference/src/cint2c2e.c
/home/z/my-project/poler-archive/libcint-reference/src/cint2e.h
--------------------------------------------------------------------------------
Приложение Д: Worklog