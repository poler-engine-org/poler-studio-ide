> Source: https://en.wikipedia.org/wiki/List_of_quantum_chemistry_and_solid-state_physics_software

List of quantum chemistry and solid-state physics software - Wikipedia
Jump to content [-]
Main menu
Main menu
move to sidebar hide
Navigation
Main page
Contents
Current events
Random article
About Wikipedia
Contact us
Contribute
Help
Learn to edit
Community portal
Recent changes
Upload file
Special pages
Search
Search [-]
Appearance
Donate
Create account
Log in [-]
Personal tools
Donate
Create account
Log in
 Edit with pride and win! Participate in Wiki Loves Pride 2026
Contents
move to sidebar hide
(Top)
1 Overview Toggle Overview subsection
1.1 Numerical details
1.2 Quantum chemistry and solid-state physics characteristics
1.3 Post processing packages in quantum chemistry and solid-state physics
2 See also
3 Footnotes
4 References
5 Further reading [-]
Toggle the table of contents
List of quantum chemistry and solid-state physics software
[-]
8 languages
فارسی
Italiano
日本語
한국어
Монгол
Português
Türkçe
中文
Edit links
Article
Talk [-]
English
Read
Edit
View history [-]
Tools
Tools
move to sidebar hide
Actions
Read
Edit
View history
General
What links here
Related changes
Upload file
Permanent link
Page information
Cite this page
Get shortened URL
Expand all
Edit interlanguage links
Print/export
Download as PDF
Printable version
In other projects
Wikidata item
Appearance
move to sidebar hide
Text
[-] 0 Small [x] 1 Standard [-] 2 Large
This page always uses small font size
Width
[x] 1 Standard [-] 0 Wide
The content is as wide as possible for your browser window.
Color
[-] os Automatic [x] day Light [-] night Dark
This page is always in light mode.
From Wikipedia, the free encyclopedia
Quantum chemistry computer programs are used in computational chemistry to implement the methods of quantum chemistry. Most include the Hartree–Fock (HF) and some post-Hartree–Fock methods. They may also include density functional theory (DFT), molecular mechanics or semi-empirical quantum chemistry methods. The programs include both open source and commercial software. Most of them are large, often containing several separate programs, and have been developed over many years.
Overview
[ edit]
The following tables illustrates some of the main capabilities of notable packages:
Numerical details
[ edit]
Quantum chemistry and solid-state physics characteristics
[ edit]
Post processing packages in quantum chemistry and solid-state physics
[ edit]
See also
[ edit]
Chemistry portal
List of software for Monte Carlo molecular modeling
List of computational physics software
Comparison of software for molecular mechanics modeling
Molecular design software
Molecule editor
Molecular modeling on GPUs
List of software for nanostructures modeling
Semi-empirical quantum chemistry method
Computational chemical methods in solid-state physics, with periodic boundary conditions
Valence bond programs
Car–Parrinello molecular dynamics
Community code database from MolSSI
Footnotes
[ edit] †
"Academic": academic (no cost) license possible upon request; "Commercial": commercially distributed. ‡
Support for periodic systems (3d-crystals, 2d-slabs, 1d-rods and isolated molecules): 3d-periodic codes always allow simulating systems with lower dimensionality within a supercell. Specified here is the ability for simulating within lower periodicity. 2
QuanPol is a full spectrum (HF, MCSCF, GVB, MP2, DFT, TDDFT, CHARMM, AMBER, OPLSAA) QM/MM package integrated in GAMESS-US. [9] 10
Through CRYSCOR Archived 2019-12-26 at the Wayback Machine program.
References
[ edit]
^ Jump up to: a  b Lotrich, V.; Flocke, N.; Ponton, M.; Yau, A. D.; Perera, A.; Deumens, E.; Bartlett, R. J. (5 May 2008). "Parallel implementation of electronic structure energy, gradient, and Hessian calculations". The Journal of Chemical Physics. 128 (19). doi: 10.1063/1.2920482. ISSN 0021-9606.
^ "DFTK.jl: The density-functional toolkit".
^ Wortmann, Daniel; Michalicek, Gregor; Baadji, Nadjib; Betzinger, Markus; Bihlmayer, Gustav; Bröder, Jens; Burnus, Tobias; Enkovaara, Jussi; Freimuth, Frank; Friedrich, Christoph; Gerhorst, Christian-Roman; Granberg Cauchi, Sabastian; Grytsiuk, Uliana; Hanke, Andrea; Hanke, Jan-Philipp; Heide, Marcus; Heinze, Stefan; Hilgers, Robin; Janssen, Henning; Klüppelberg, Daniel Aaaron; Kovacik, Roman; Kurz, Philipp; Lezaic, Marjana; Madsen, Georg K. H.; Mokrousov, Yuriy; Neukirchen, Alexander; Redies, Matthias; Rost, Stefan; Schlipf, Martin; Schindlmayr, Arno; Winkelmann, Miriam; Blügel, Stefan (3 May 2023), "FLEUR", Zenodo, Bibcode: 2023zndo...7576163W, doi: 10.5281/zenodo.7576163
^ "Order MOLCAS".
^ "MOPAC has been re-released under the open-source LGPL license".
^ Gozem, Samer; Krylov, Anna I. (2021-05-31). "The ezSpectra suite: An easy‐to‐use toolkit for spectroscopy modeling". WIREs Computational Molecular Science. 12 (2). doi: 10.1002/wcms.1546. ISSN 1759-0876. S2CID 232154733.
^ Alessio, Maristella; Krylov, Anna I. (2021-06-30). "Equation-of-Motion Coupled-Cluster Protocol for Calculating Magnetic Properties: Theory and Applications to Single-Molecule Magnets". Journal of Chemical Theory and Computation. 17 (7): 4225– 4241. doi: 10.1021/acs.jctc.1c00430. ISSN 1549-9618. PMID 34191507. S2CID 235698464.
^ "TheoDORE". theodore-qc.sourceforge.io. Retrieved 2021-08-15.
^ Change History of GAMESS
Further reading
[ edit]
Young, David (2001). Computational Chemistry: A Practical Guide for Applying Techniques to Real World Problems. New York: John Wiley & Sons. pp. 322– 359. ISBN 978-0-471-33368-5 .
"NVIDIA GPU Applications". NVIDIA. Retrieved 9 July 2014.
"atomistic.software - atomistic simulation engines and their citation trends". GitHub. Retrieved 23 November 2021.
hide
v
t
e
Computational chemistry software
Cheminformatics
Chemical kinetics
Molecular modelling,
visualization
List of molecular graphics systems
Molecular docking
List of protein-ligand docking software
Molecular dynamics
Quantum chemistry
List of quantum chemistry and solid-state physics software
Skeletal structure
drawing
Others
Aqion
EXC code
GenX
GSim
Mercury
CrystalExplorer
ICM (ICM-Browser)
Materials Studio
Molden
OpenChrom
SASHIMI 
Retrieved from " https://en.wikipedia.org/w/index.php?title=List_of_quantum_chemistry_and_solid-state_physics_software&oldid=1352664399"
Categories:
Density functional theory software
Computational chemistry software
Molecular modelling software
Physics software
Lists of software
Chemistry software
Hidden categories:
Articles with short description
Short description is different from Wikidata
Webarchive template wayback links
This page was last edited on 5 May 2026, at 15:07 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policy
About Wikipedia
Disclaimers
Contact Wikipedia
Legal & safety contacts
Code of Conduct
Developers
Statistics
Cookie statement
Mobile view
Search
Search [-]
Toggle the table of contents
List of quantum chemistry and solid-state physics software
8 languages Add topic 