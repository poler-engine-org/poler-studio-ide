> Source: https://vergil.chemistry.gatech.edu/notes/hf-intro.pdf

An Introduction to Hartree-Fock Molecular Orbital Theory 
C. David Sherrill School of Chemistry and Biochemistry 
Georgia Institute of Technology 
June 2000 
1 Introduction 
Hartree-Fock theory is fundamental to much of electronic structure theory. It is the basis of molecular orbital (MO) theory, which posits that each electron’s motion can be described by a single-particle function (orbital) which does not depend explicitly on the instantaneous motions of the other electrons. Many of you have probably learned about (and maybe even solved prob-lems with) Hückel MO theory, which takes Hartree-Fock MO theory as an implicit foundation and throws away most of the terms to make it tractable for simple calculations. The ubiquity of orbital concepts in chemistry is a testimony to the predictive power and intuitive appeal of Hartree-Fock MO theory. However, it is important to remember that these orbitals are mathematical constructs which only approximate reality. Only for the hydrogen atom (or other one-electron systems, like He+) are orbitals exact eigenfunctions of the full electronic Hamiltonian. As long as we are content to consider molecules near their equilibrium geometry, Hartree-Fock theory often provides a good starting point for more elaborate theoretical methods which are better approximations to the elec-tronic Schrödinger equation (e.g., many-body perturbation theory, single-reference configuration interaction). So...how do we calculate molecular orbitals using Hartree-Fock theory? That is the subject of these notes; we will explain Hartree-Fock theory at an introductory level. 
2 What Problem Are We Solving? 
It is always important to remember the context of a theory. Hartree-Fock theory was developed to solve the electronic Schrödinger equation that results from the time-independent Schrödinger equation after invoking the Born-Oppenheimer approximation. In atomic units, and with r de-noting electronic and R denoting nuclear degrees of freedom, the electronic Schrödinger equation 
1
is  
−1 
2 
∑ 
i 
∇2 
i − ∑ 
A,i 
ZA 
rAi 
+ ∑ 
A>B 
ZAZB 
RAB 
+ ∑ 
i>j 
1 
rij 
 
Ψ(r;R) = EelΨ(r;R), (1) 
or, in our previous more compact notation, [ 
T̂e(r) + V̂eN(r;R) + V̂NN(R) + V̂ee(r) ] 
Ψ(r;R) = EelΨ(r;R). (2) 
Recall from the Born-Oppenheimer approximation that Eel (plus or minus V̂NN(R), which we in-clude here) will give us the potential energy experienced by the nuclei. In other words, Eel(R) gives the potential energy surface (from which we can get, for example, the equilibrium geometry and vibrational frequencies). That’s one good reason why we want to solve the electronic Schrödinger equation. The other is that the electronic wavefunction Ψ(r;R) contains lots of useful information about molecular properties such as dipole (and multipole) moments, polarizability, etc. 
3 Motivation and the Hartree Product 
The basic idea of Hartree-Fock theory is as follows. We know how to solve the electronic problem for the simplest atom, hydrogen, which has only one electron. We imagine that perhaps if we added another electron to hydrogen, to obtain H−, then maybe it might be reasonable to start off pretending that the electrons don’t interact with each other (i.e., that V̂ee = 0). If that was true, then the Hamiltonian would be separable, and the total electronic wavefunction Ψ(r1, r2) describing the motions of the two electrons would just be the product of two hydrogen atom wavefunctions (orbitals), ΨH(r1)ΨH(r2) (you should be able to prove this easily). 
Obviously, pretending that the electrons ignore each other is a pretty serious approximation! Nevertheless, we have to start somewhere, and it seems plausible that it might be useful to start with a wavefunction of the general form 
ΨHP (r1, r2, · · · , rN) = φ1(r1)φ2(r2) · · ·φN(rN), (3) 
which is known as a Hartree Product. 
While this functional form is fairly convenient, it has at least one major shortcoming: it fails to satisfy the antisymmetry principle, which states that a wavefunction describing fermions should be antisymmetric with respect to the interchange of any set of space-spin coordinates. By space-spin coordinates, we mean that fermions have not only three spatial degrees of freedom, but also an intrinsic spin coordinate, which we will call α or β. We call a generic (either α or β) spin coordinate ω, and the set of space-spin coordinates x = {r, ω}. We will also change our notation for orbitals from φ(r), a spatial orbital, to χ(x), a spin orbital. Except in strange cases such as 
2
the so-called General Hartree Fock or Z-Averaged Perturbation Theory, usually the spin orbital is just the product of a spatial orbital and either the α or β spin function, i.e., χ(x) = φ(r)α. [Note: some textbooks write the spin function formally as a function of ω, i.e., α(ω)]. 
More properly, then, with the full set of coordinates, the Hartree Product becomes 
ΨHP (x1,x2, · · · ,xN) = χ1(x1)χ2(x2) · · ·χN(xN). (4) 
This wavefunction does not satisfy the antisymmetry principle! To see why, consider the case for only two electrons: 
ΨHP (x1,x2) = χ1(x1)χ2(x2). (5) 
What happens when we swap the coordinates of electron 1 with those of electron 2? 
ΨHP (x2,x1) = χ1(x2)χ2(x1). (6) 
The only way that we get the negative of the original wavefunction is if 
χ1(x2)χ2(x1) = −χ1(x1)χ2(x2), (7) 
which will not be true in general! So we can see the Hartree Product is actually very far from having the properties we require. 
4 Slater Determinants 
For our two electron problem, we can satisfy the antisymmetry principle by a wavefunction like: 
Ψ(x1,x2) = 1√ 2 
[χ1(x1)χ2(x2) − χ1(x2)χ2(x1)] . (8) 
This is very nice because it satisfies the antisymmetry requirement for any choice of orbitals χ1(x) and χ2(x). 
What if we have more than two electrons? We can generalize the above solution to N electrons by using determinants. In the two electron case, we can rewrite the above functional form as 
Ψ(x1,x2) = 1√ 2 
∣ 
∣ 
∣ 
∣ 
∣ 
χ1(x1) χ2(x1) χ1(x2) χ2(x2) 
∣ 
∣ 
∣ 
∣ 
∣ 
(9) 
Note a nice feature of this; if we try to put two electrons in the same orbital at the same time (i.e., set χ1 = χ2), then Ψ(x1,x2) = 0. This is just a more sophisticated statement of the Pauli 
exclusion principle, which is a consequence of the antisymmetry principle! 
3
Now the generalization to N electrons is then easy to see, it is just 
Ψ = 1√ N ! 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
χ1(x1) χ2(x1) · · · χN(x1) χ1(x2) χ2(x2) · · · χN(x2) 
... ... 
. . . ... 
χ1(xN) χ2(xN) · · · χN(xN) 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
∣ 
. (10) 
A determinant of spin orbitals is called a Slater determinant after John Slater. An interesting con-sequence of this functional form is that the electrons are all indistinguishable, consistent with the strange results of quantum mechanics. Each electron is associated with every orbital! This point is very easily forgotten, especially because it is cumbersome to write out the whole determinant which would remind us of this indistinguishability. Speaking of which, it is time to introduce a more compact notation. 
Since we can always construct a determinant (within a sign) if we just know the list of the occu-pied orbitals {χi(x), χj(x), · · ·χk(x)}, we can write it in shorthand in a ket symbol as |χiχj · · ·χk〉 or even more simply as |ij · · · k〉. Note that we have dropped the normalization factor. It’s still there, but now it’s just implied! 
It is not at all obvious at this point, but it turns out that the assumption that the electrons can be described by an antisymmetrized product (Slater determinant) is equivalent to the assumption that each electron moves independently of all the others except that it feels the Coulomb repulsion due to the average positions of all electrons (and it also experiences a strange “exchange” interac-tion due to antisymmetrization). Hence, Hatree-Fock theory is also referred to as an independent 
particle model or a mean field theory. (Many of these descriptions also apply to Kohn-Sham den-sity functional theory, which bears a striking resemblance to Hartree-Fock theory; one difference, however, is that the role of the Hamiltonian different in DFT). 
5 Simplified Notation for the Hamiltonian 
Now that we know the functional form for the wavefunction in Hartree-Fock theory, let’s re-examine the Hamiltonian to make it look as simple as possible. In the process, we will bury some complexity that would have to be taken care of later (in the evaluation of integrals). 
We will define a one-electron operator h as follows 
h(i) = −1 
2 ∇2 
i − ∑ 
A 
ZA 
riA 
, (11) 
and a two-electron operator v(i, j) as 
v(i, j) = 1 
rij 
. (12) 
4
Now we can write the electronic Hamiltonian much more simply, as 
Ĥel = ∑ 
i 
h(i) + ∑ 
i<j 
v(i, j) + VNN . (13) 
Since VNN is just a constant for the fixed set of nuclear coordinates {R}, we will ignore it for now (it doesn’t change the eigenfunctions, and only shifts the eigenvalues). 
6 Energy Expression 
Now that we have a form for the wavefunction and a simplified notation for the Hamiltonian, we have a good starting point to tackle the problem. Still, how do we obtain the molecular orbitals? 
We state that the Hartree-Fock wavefunction will have the form of a Slater determinant, and that the energy will be given by the usual quantum mechanical expression (assuming the wavefunction is normalized): 
Eel = 〈Ψ|Ĥel|Ψ〉. (14) 
For symmetric energy expressions, we can employ the variational theorem, which states that the energy is always an upper bound to the true energy. Hence, we can obtain better approximate wavefunctions Ψ by varying their parameters until we minimize the energy within the given func-tional space. Hence, the correct molecular orbitals are those which minimize the electronic energy Eel! The molecular orbitals can be obtained numerically using integration over a grid, or (much more commonly) as a linear combination of a set of given basis functions (so-called “atomic orbital” basis functions, usually atom-centered Gaussian type functions). 
Now, using some tricks we don’t have time to get into, we can re-write the Hartree-Fock energy Eel in terms of integrals of the one- and two-electron operators: 
EHF = ∑ 
i 
〈i|h|i〉 + 1 
2 
∑ 
ij 
[ii|jj] − [ij|ji], (15) 
where the one electron integral is 
〈i|h|j〉 = ∫ 
dx1χ ∗ i (x1)h(r1)χj(x1) (16) 
and a two-electron integral (Chemists’ notation) is 
[ij|kl] = ∫ 
dx1dx2χ ∗ i (x1)χj(x1) 
1 
r12 
χ∗ k(x2)χl(x2). (17) 
There exist efficient computer algorithms for computing such one- and two-electron integrals. 
5
7 The Hartree-Fock Equations 
Again, the Hartree-Fock method seeks to approximately solve the electronic Schrödinger equation, and it assumes that the wavefunction can be approximated by a single Slater determinant made up of one spin orbital per electron. Since the energy expression is symmetric, the variational theorem holds, and so we know that the Slater determinant with the lowest energy is as close as we can get to the true wavefunction for the assumed functional form of a single Slater determinant. The Hartree-Fock method determines the set of spin orbitals which minimize the energy and give us this “best single determinant.” 
So, we need to minimize the Hartree-Fock energy expression with respect to changes in the orbitals χi → χi + δχi. We have also been assuming that the orbitals χ are orthonormal, and we want to ensure that our variational procedure leaves them orthonormal. We can accomplish this by Lagrange’s method of undetermined multipliers, where we employ a functional L defined as 
L[{χi}] = EHF [{χi}] − ∑ 
ij 
εij(< i|j > −δij) (18) 
where εij are the undetermined Lagrange multipliers and < i|j > is the overlap between spin orbitals i and j, i.e., 
< i|j >= ∫ 
χ∗ i (x)χj(x)dx. (19) 
Setting the first variation δL = 0, and working through some algebra, we eventually arrive at the Hartree-Fock equations defining the orbitals: 
h(x1)χi(x1)+ ∑ 
j 6=i 
[ ∫ 
dx2|χj(x2)|2r−1 
12 
] 
χi(x1)− ∑ 
j 6=i 
[ ∫ 
dx2χ ∗ j(x2)χi(x2)r 
−1 
12 
] 
χj(x1) = εiχi(x1), (20) 
where εi is the energy eigenvalue associated with orbital χi. 
The Hartree-Fock equations can be solved numerically (exact Hartree-Fock), or they can be solved in the space spanned by a set of basis functions (Hartree-Fock-Roothan equations). In either case, note that the solutions depend on the orbitals. Hence, we need to guess some initial orbitals and then refine our guesses iteratively. For this reason, Hartree-Fock is called a self-consistent-field 
(SCF) approach. 
The first term above in square brackets, 
∑ 
j 6=i 
[ ∫ 
dx2|χj(x2)|2r−1 
12 
] 
χi(x1), (21) 
gives the Coulomb interaction of an electron in spin orbital χi with the average charge distribution of the other electrons. Here we see in what sense Hartree-Fock is a “mean field” theory. This is 
6
called the Coulomb term, and it is convenient to define a Coulomb operator as 
Jj(x1) = ∫ 
dx2|χj(x2)|2r−1 
12 , (22) 
which gives the average local potential at point x1 due to the charge distribution from the electron in orbital χj. 
The other term in brackets in eq. (20) is harder to explain and does not have a simple classical analog. It arises from the antisymmetry requirement of the wavefunction. It looks much like the Coulomb term, except that it switches or exchanges spin orbitals χi and χj. Hence, it is called the exchange term: 
∑ 
j 6=i 
[ ∫ 
dx2χ ∗ j(x2)χi(x2)r 
−1 
12 
] 
χj(x1). (23) 
We can define an exchange operator in terms of its action on an arbitrary spin orbital χi: 
Kj(x1)χi(x1) = [ ∫ 
dx2χ ∗ j(x2)r 
−1 
12 χi(x2) ] 
χj(x1). (24) 
In terms of these Coulomb and exchange operators, the Hartree-Fock equations become con-siderably more compact. 
 
h(x1) + ∑ 
j 6=i 
Jj(x1) − ∑ 
j 6=i 
Kj(x1) 
 
χi(x1) = εiχi(x1). (25) 
Perhaps now it is more clear that the Hartree-Fock equations are eigenvalue equations. If we realize that 
[Ji(x1) −Ki(x1)] χi(x1) = 0, (26) 
then it becomes clear that we can remove the restrictions j 6= i in the summations, and we can introduce a new operator, the Fock operator, as 
f(x1) = h(x1) + ∑ 
j 
Jj(x1) −Kj(x1). (27) 
And now the Hartree-Fock equations are just 
f(x1)χi(x1) = εiχi(x1). (28) 
Introducing a basis set transforms the Hartree-Fock equations into the Roothaan equations. Denoting the atomic orbital basis functions as χ̃, we have the expansion 
χi = K ∑ 
µ=1 
Cµiχ̃µ (29) 
7
for each spin orbital i. This leads to 
f(x1) ∑ 
ν 
Cνiχ̃ν(x1) = εi 
∑ 
ν 
Cνiχ̃ν(x1). (30) 
Left multiplying by χ̃∗ µ(x1) and integrating yields a matrix equation 
∑ 
ν 
Cνi 
∫ 
dx1χ̃ ∗ µ(x1)f(x1)χ̃ν(x1) = εi 
∑ 
ν 
Cνi 
∫ 
dx1χ̃ ∗ µ(x1)χ̃ν(x1). (31) 
This can be simplified by introducing the matrix element notation 
Sµν = ∫ 
dx1χ̃ ∗ µ(x1)χ̃ν(x1), (32) 
Fµν = ∫ 
dx1χ̃ ∗ µ(x1)f(x1)χ̃ν(x1). (33) 
Now the Hartree-Fock-Roothaan equations can be written in matrix form as 
∑ 
ν 
FµνCνi = εi 
∑ 
ν 
SµνCνi (34) 
or even more simply as matrices FC = SCε (35) 
where ε is a diagonal matrix of the orbital energies εi. This is like an eigenvalue equation except for the overlap matrix S. One performs a transformation of basis to go to an orthogonal basis to make S vanish. Then it’s just a matter of solving an eigenvalue equation (or, equivalently, diagonalizing F!). Well, not quite. Since F depends on it’s own solution (through the orbitals), the process must be done iteratively. This is why the solution of the Hartree-Fock-Roothaan equations are often called the self-consistent-field procedure. 
8