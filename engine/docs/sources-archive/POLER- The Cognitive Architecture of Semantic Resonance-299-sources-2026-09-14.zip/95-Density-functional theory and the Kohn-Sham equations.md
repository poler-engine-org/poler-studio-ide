> Source: http://web.cecs.pdx.edu/~greenwd/excellent_dft_intro.pdf

Density-functional theory and the 
Kohn-Sham equations 
Introduction 
The calculation of the many-body wave function of a system of interacting electrons is a formidable task which can only be carried out – and is only meaningful – for systems with a few tens of electrons [1]. If observables for larger systems are to be determined, the calculation of the many-body wave function has to be avoided. One possibility is to write the desired quantities as functionals of the electronic density, a function of just three variables, rx, ry, rz. A very early attempt along these lines is the Thomas-Fermi theory [2, 3, 4], a modern and theoretically rigorous approach is density-functional theory (DFT) [5]. Within DFT usually the Kohn-Sham (KS) equations are utilized which describe independent particles moving in an effective potential. Thus DFT provides with the KS equations a strict and theoretically sound procedure to map the real system of interacting electrons onto a fictitious system of non-interacting so-called Kohn-Sham electrons. In this way the KS equations provide a powerful tool for the numerical determination of the electronic ground state of many-electron systems. 
Short description 
Since the electron-electron interaction is known (Coulomb potential), the Hamilton oper-ator of a quantum-mechanical many-electron system is completely determined once the external potential vext(r) is specified in which the electrons move. From a very funda-mental point of view the problem is therefore solved, leaving only the “technical detail” of actually computing the solution of the Schrödinger equation. The theorem of Hohen-berg and Kohn (HK) [5], which is the foundation of density-functional theory, focuses on the relationship between vext(r) and the electronic density n(r) of the ground state. The theorem states that there exists a one-to-one mapping between vext(r) and n(r). In order to fully specify an electronic system it is therefore equivalent to determine either vext(r) or n(r). 
Theorem: Let vext(r) be an arbitrary external potential. It then holds: 
a) For a non-degenerate ground state |Ψ〉 of the system the external potential vext(r) is determined, within a trivial additive constant, as a functional of the electronic density n(r). 
b) Given an external potential vext(r), the correct ground-state density n(r) minimizes the ground-state energy E0, which is a functional uniquely determined by n(r). It holds, 
E0 ≤ Ev[ñ] , (1) 
where ñ(r) is any trial density fulfilling ñ(r) ≥ 0 and ∫ 
d3r ñ(r) = N , N being the number of electrons in the system. 
The theorem – which has a remarkable short proof – guarantees the existence of an energy functional E[n] that reaches its minimum for the correct density n(r) yet gives no explicit prescription for its construction. In order to determine E[n] it is useful to separate the various known contributions to the total energy, like Ts[n], the kinetic energy of a non-interacting electron gas, Eext[n], the classical Coulomb energy of the electrons moving in the external potential vext(r), and ECoul[n], the classical energy due to the mutual Coulomb interaction of the electrons: 
E[n(r)] = Ts[n(r)] + Eext[n(r)] + ECoul[n(r)] + Exc[n(r)] . (2) 
The last term Exc[n] contains the quantum-mechanical exchange and correlation energy and – in principle – the difference between the true kinetic energy, T [n], and Ts[n], the kinetic energy of the gas of non-interacting KS-electrons. But since this difference is very small it is typically neglected. 
Due to the second part of the HK theorem, namely that the total energy is minimized by the true ground-state density, the variational principle can now be utilized. With the standard functional derivatives and the additional definition of the so-called exchange-correlation potential, 
vxc(r) = δExc[ñ(r)] 
δñ(r) 
∣∣∣∣ ñ(r)=n(r) 
, (3) 
the following set of equations can be derived [6, 7, 8, 9]: 
[ − h̄2 
2m ∇2 + veff(r) 
] ϕi(r) = εi ϕi(r) , (4) 
where the effective potential – as a functional of the electronic density – is given by 
veff(r) = veff [n(r)] = vext(r) + e2 ∫ 
d3r′ n(r′) |r− r| + vxc[n(r)] (5) 
and the electronic density as 
n(r) = N∑ 
i=1 
|ϕi(r)|2 . (6) 
The set of equations (4) to (6) are the famous Kohn-Sham (KS) equations. They have to be solved self-consistently, i.e., starting from some initial density a potential veff [n(r)] is obtained for which the equations (4) are solved and a new electronic density (6) is determined. From the new density an updated effective potential can be calculated and this process is repeated until self-consistency is reached, i.e., until the new electronic density equals the previous one. 
 
Formally the KS equations describe a system of non-interacting particles. This makes the KS equations so easy to solve. However, since the KS electrons move in an effective potential which is set up by the other electrons, many-body correlation effects are consid-ered within the KS equation. In fact, the KS equations give an exact description of the many-electron system since up to this point no approximations have been made. 
The approximations enter in the expression for the unknown exchange-correlation func-tional Exc. A widely used approach is the local-density approximation (LDA). It is as-sumed that the density of an inhomogeneous system can be locally described by a homo-geneous electron gas [6]. A homogeneous electron gas is fully specified by its electronic particle density n which is often expressed in terms of the corresponding Wigner-Seitz radius rs, 
rs = ( 
3 
4π n 
)1/3 
. (7) 
Within the LDA the functional for the exchange-correlation energy, Exc, can be written as 
Exc[n] = ∫ 
d3r [ n(r) εxc[n(r)] 
] , (8) 
where εxc is the exchange-correlation energy per particle of a homogeneous electron gas of density n. From the last equation the exchange-correlation potential can be further evaluated. The functional derivative (3) can be simplified to an ordinary derivative, 
vxc = δExc 
δn = 
d 
dn 
[ n(r)εxc[n(r)] 
] . (9) 
In the next step, the exchange-correlation potential is split into its exchange part vx and a correlation part vc, 
vxc(rs) = vx(rs) + vc(rs) . (10) 
Wigner and Seitz [10] showed within the Thomas-Fermi model that vx can be approxi-mated by (here and in the following Hartree atomic units are used) 
vx(rs) = − ( 
9 
4π2 
) 1 3 1 
rs 
⇐⇒ vx(n) = − ( 
3 
π n 
) 1 3 
. (11) 
The situation is more difficult for the correlation part. However, there are accurate values for εc(n) available which stem from quantum Monte Carlo calculations by Ceperley and Alder [11]; a widely used parametrization of these data is due to Perdew and Zunger [12]. Finally, the resulting vc is 
vc(rs) = A ln rs + (B − 1 
3 A) + 
2 
3 C rs ln rs + 
1 
3 (2D − C) rs , rs < 1 (12) 
and 
vc(rs) = γ 
1 + β1 √ 
rs + β2 rs 
1 + 7 6 β1 √ 
rs + 4 3 β2 rs 
1 + β1 √ 
rs + β2 rs 
, rs ≥ 1 , (13) 
with numerical parameters 
γ = −0.1423 β1 = 1.0529 β2 = 0.3334 (14) 
A = 0.0311 B = −0.048 C = 0.0020 D = −0.0116 . (15) 
 
With the best functionals available today – which are much more complicated than the one presented above – the total energy can be calculated to within 2 kcal/mol (≈ 0.09 eV/atom). This value is about a factor of 2 worse than the accuracy achieved with quantum chemical calculations (configuration interaction, CI) and it is assumed that it will not be improved essentially in the future. However, geometries determined within DFT achieve an accuracy which is comparable to those of CI calculations (10−2 Å). 
References 
[1] W. Kohn, Rev. Mod. Phys. 71, 1253 (1999). 
[2] E. Fermi, Atti. Accad. Naz. Lincei, Cl. Sci. Fis. Mat. Nat. Rend. 6, 602 (1927). 
[3] L. H. Thomas, Proc. Cambrigde Philos. Soc. 23, 542 (1927). 
[4] B. H. Bransden and C. J. Joachain, Physics of atoms and molecules, Longman, London and New York, 1983. 
[5] P. Hohenberg and W. Kohn, Phys. Rev. 136, B864 (1964). 
[6] W. Kohn and L. J. Sham, Phys. Rev. 140, A1133 (1965). 
[7] S. Lundqvist and N. H. March, editors, Theory of the Inhomogeneous Electron Gas, Plenum Press, New York, 1983. 
[8] R. G. Parr and W. Yang, Density-Functional Theory of Atoms and Molecules, Oxford University Press, New York, 1989. 
[9] R. M. Dreizler and E. K. U. Gross, Density Functional Theory, Springer, Berlin, 1990. 
[10] E. P. Wigner and F. Seitz, Phys. Rev. 43, 804 (1933). 
[11] D. M. Ceperley and B. J. Alder, Phys. Rev. Lett. 45, 566 (1980). 
[12] J. P. Perdew and A. Zunger, Phys. Rev. B. 23, 5048 (1981). 
 