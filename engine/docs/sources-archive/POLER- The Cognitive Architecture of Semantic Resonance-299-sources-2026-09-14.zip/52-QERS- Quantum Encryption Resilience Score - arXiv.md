> Source: https://arxiv.org/html/2601.13399v1

QERS: Quantum Encryption Resilience Score
 Back to arXiv  
 Back to arXiv
This is experimental HTML to improve accessibility. We invite you to report rendering errors. Use Alt+Y to toggle on accessible reporting links and Alt+Shift+Y to toggle off. Learn more about this project and help improve conversions.
Why HTML? Report Issue Back to Abstract Download PDF 
Table of Contents
Abstract
I Introduction
I-A Research Problem
I-B Research Question
I-C Contributions
II Related Work & Background
II-A Post-Quantum Cryptography
II-B Constraints in Computing and IoT/IIoT Security
II-C Quantum & PQC Benchmarks
II-D Evaluation Metrics and Decision Models
III Methodology (QERS Formulation)
III-A Metrics Definition: Quantum Encryption Resilience Score (QERS)
III-B QERS Formulas with Normalized Metrics
III-B 1 Basic QERS
III-B 2 Fusion QERS
Performance Subscore:
Security Subscore:
Combined Fusion Score:
III-C QERS Interpretation
III-D QERS Evaluation: Basic, Tuned, and Fusion Metrics
III-E Machine Learning Support for Fusion QERS
IV Proposed Framework
IV-A Interpretation & Use Cases
IV-B Illustrative Validation / Methodology
V Results
V-A Heatmap Analysis
V-B Distribution of Scores
V-C Representative Scatter Analysis
V-D Distance Comparison
VI Discussion
VII Conclusion
References
License: arXiv.org perpetual non-exclusive license
arXiv:2601.13399v1 [cs.CR] 19 Jan 2026
QERS: Quantum Encryption Resilience Score
Report issue for preceding element
Jonatan Rassekhnia
Report issue for preceding element
Abstract
Report issue for preceding element
Post-quantum cryptography (PQC) is becoming essential for securing Computer Systems, IoT, and IIoT systems against future quantum threats. However, the operational cost of deploying PQC on resource-constrained devices is still poorly understood. This paper introduces the Quantum Encryption Resilience Score (QERS), a practical evaluation instrument designed to quantify the impact of PQC on computing, IoT, and IIoT communication systems. QERS integrates latency, packet reliability, CPU load, energy use, signal strength, and key size into a unified normalized score. Three complementary scoring formulas are introduced: (i) Basic, for rapid comparisons, (ii) Tuned, for environment-specific weighting, and (iii) Fusion, which combines normalized performance and security sub-scores into a composite indicator. An ESP32C6-Devkit testbed was used to evaluate five PQC algorithms (Kyber, Dilithium, Falcon, SPHINCS+, and NTRU) under different wireless conditions. The results show that QERS exposes performance–security trade-offs that are difficult to observe through isolated benchmarks, providing a reproducible instrument for assessing PQC readiness in resource-limited environments.
Report issue for preceding element
I Introduction
Report issue for preceding element
The rapid expansion of Traditional Computing, Internet of Things (IoT) and Industrial IoT (IIoT) has introduced billions of connected devices that operate under strict resource constraints, while simultaneously it relying on cryptographic mechanisms for secure communication. At the same time, advances in quantum computing threaten classical public-key cryptography, since algorithms such as RSA and ECC may become breakable once sufficiently large quantum systems emerge [ 31, 68] . As a result, the transition toward Post-Quantum Cryptography (PQC) has become a strategic and technical priority for future secure systems [ 45, 62, 51, 98, 48] .
Report issue for preceding element
Although several PQC algorithms that include Kyber, Dilithium, Falcon, SPHINCS+, and NTRU, have been standardized or are currently undergoing evaluation, their operational impact on constrained Traditional Computing and IoT/IIoT platforms remains insufficiently characterized. Existing research primarily focuses on micro-benchmarks such as computation time, memory footprint, or throughput. However, these metrics alone do not reflect how PQC could affects end-to-end system behavior, including network latency, packet reliability, CPU utilization, energy consumption, and wireless stability [ 63, 99, 57] . This lack of system-level visibility complicates PQC adoption decisions, particularly across diverse hardware and protocol environments [ 96] .
Report issue for preceding element
To address this gap, this paper introduces the Quantum Encryption Resilience Score (QERS), a multi-metric evaluation instrument designed to quantify the resilience of Traditional Computing and IoT/IIoT communication systems operating under PQC workloads. Rather than benchmarking cryptography in isolation, QERS integrates heterogeneous metrics, including latency, packet loss, CPU load, signal strength, energy usage, and cryptographic key parameters, into a normalized composite score. The framework provides three complementary scoring modes [ 15, 6] :
Report issue for preceding element
• Basic: rapid comparison of PQC impact across protocols. Report issue for preceding element
• Tuned: environment-aware weighting for specific deployment priorities. Report issue for preceding element
• Fusion: combined performance and security sub-scores producing a unified readiness indicator. Report issue for preceding element
An ESP32-based test is employed to evaluate five PQC algorithms across different wireless conditions. Experimental results demonstrate that QERS exposes performance and security trade-offs that remain hidden when metrics are analyzed individually, offering a reproducible means of assessing PQC readiness in constrained environments.
Report issue for preceding element
I-A Research Problem
Report issue for preceding element
Despite progress in PQC standardization, there is no unified, reproducible measurement instrument capable of evaluating PQC across multiple operational dimensions on real Computing, IoT, and IIoT platforms. As a result, engineers and manufacturers lack decision support when estimating feasibility and deployment cost at scale [ 4] .
Report issue for preceding element
I-B Research Question
Report issue for preceding element
• How can a unified and reproducible measurement instrument be designed to evaluate PQC algorithms across Computer Systems, IoT, and IIoT platforms while incorporating latency, memory usage, energy behavior, Key-Bytes, CPU usage, RSSI and packet-level communication characteristics? Report issue for preceding element
I-C Contributions
Report issue for preceding element
This research introduces the Quantum Encryption Resilience Score (QERS), a layered evaluation instrument designed to measure PQC impact under realistic operating constraints. The main contributions are:
Report issue for preceding element
A modular scoring instrument supporting Basic, Tuned, and Fusion modes for progressively deeper analysis. Report issue for preceding element
A normalization and weighting methodology integrating latency, CPU usage, signal reliability, key size, packet behavior, and energy metrics into performance and security sub-scores. Report issue for preceding element
A practical implementation on ESP32 hardware for real-world experimentation, avoiding purely simulated environments. Report issue for preceding element
An empirical evaluation of five PQC algorithms across different wireless scenarios. Report issue for preceding element
A reproducible and extensible framework designed to support future PQC testing, comparison, migration toward quantum-resilient systems, and deployment in resource-limited environments. Report issue for preceding element
II Related Work & Background
Report issue for preceding element
II-A Post-Quantum Cryptography
Report issue for preceding element
Post-Quantum Cryptography (PQC) aims to develop cryptographic schemes that remain secure against adversaries equipped with large-scale quantum computers [ 23] . The National Institute of Standards and Technology (NIST) is actively standardizing PQC algorithms to replace classical public-key systems that are vulnerable to Shor's algorithm [ 16] .
Report issue for preceding element
For constrained Computer Systems, IoT, and IIoT environments, the most relevant PQC families include Kyber, Dilithium, Falcon, SPHINCS+, and NTRU [ 11, 9] . These schemes differ significantly in underlying hardness assumptions, key sizes, ciphertext or signature sizes, and computational requirements. Table I summarizes representative trade-offs between efficiency and security levels.
Report issue for preceding element
TABLE I: Selected PQC Algorithms
Report issue for preceding element
II-B Constraints in Computing and IoT/IIoT Security
Report issue for preceding element
Computing systems operate on deterministic states and can only approximate quantum behavior through simulation [ 88] . They inherently lack the ability to natively represent quantum properties such as superposition and entanglement, which limits their ability to efficiently solve certain problem classes [ 73] . These architectural constraints are particularly relevant when deploying PQC on Computer Systems, IoT, and IIoT devices, which rely on classical processors with limited computational, memory, and energy resources [ 64] .
Report issue for preceding element
Computer Systems, IoT and IIoT devices are typically resource-constrained, often operating with tight memory budgets, limited CPU capacity, and restricted network bandwidth [ 75, 59, 14] . Intermittent connectivity and packet loss further complicate secure communication. Consequently, PQC algorithms with large keys or computational overhead can increase latency, degrade throughput, and accelerate battery depletion [ 2] .
Report issue for preceding element
II-C Quantum & PQC Benchmarks
Report issue for preceding element
Early studies primarily evaluated PQC on traditional compute platforms, CPUs, GPUs, and FPGAs primarily focusing on runtime performance, memory requirements, and throughput [ 2] . More recent research expands toward benchmarking methodologies, risk frameworks, and quantum-aware IoT evaluation models. Lall et al. [ 53] and Acuaviva et al. [ 3] survey performance metrics and benchmarking approaches for quantum computing platforms, while Soubra et al. [ 87] investigate measurement frameworks at both hardware and software layers. Quantum risk frameworks such as QARS address cryptographic exposure and migration readiness [ 37] .
Report issue for preceding element
In the IoT domain, Rehman and Alharbi [ 78] propose QESIF, integrating quantum key distribution with intrusion detection, and Hossain et al. [ 40] explore quantum-edge architectures for improved resilience. Ameyed et al. [ 6] emphasize evaluation models focusing on measurable security quality indicators.
Report issue for preceding element
Recent applied research demonstrates real deployment feasibility. QRoNS demonstrates PQC integration in high-performance networking, achieving near line-rate IPsec throughput using Kyber1024 and Dilithium5 on NVIDIA BlueField-3 DPUs [ 42] . Similarly, the QORE framework enables end-to-end PQC protection in 5G/B5G networks with minimal latency penalties [ 77] . EPQUIC evaluates PQC within TLS and QUIC stacks on embedded platforms, revealing significant differences across algorithms regarding latency overhead and protocol behavior [ 30] . Finally, the Quantum Approximate Optimization Algorithm (QAOA) is explored as a promising approach for combinatorial optimization on future quantum hardware [ 38] .
Report issue for preceding element
II-D Evaluation Metrics and Decision Models
Report issue for preceding element
Evaluating PQC in constrained environments requires metrics that extend beyond raw cryptographic execution time [ 60] . Relevant indicators include latency, jitter, throughput, packet loss, energy consumption, and memory usage [ 44, 49, 12] . Multi-Criteria Decision Analysis (MCDA) and Multi-Criteria Decision Making (MCDM) approaches are widely applied to rank cryptographic alternatives under competing system constraints [ 21, 93, 43] . Min–max normalization is frequently used to harmonize heterogeneous metrics, enabling meaningful comparisons across devices and protocols [ 65] .
Report issue for preceding element
Within MCDA, metrics can be organized into conceptual categories:
Report issue for preceding element
• Cost Criteria: Derived from classical cost–benefit analysis, cost criteria capture negative operational impacts such as latency, CPU usage, energy consumption, packet loss, and cryptographic overhead [ 66, 44, 7] . Higher values indicate performance penalties that should be minimized. Report issue for preceding element
• Benefit Criteria / Security Gain: Security gain metrics reflect improvements in robustness, reduced exposure, and proven resistance to attack, informed by frameworks such as SAEM [ 18, 19] . These metrics also incorporate organizational perspectives on information security value [ 28] . Parameters such as proven resistance ( P r P_{r} ), key size ( K K ), cryptographic robustness, and reliability directly contribute to overall security posture [ 36] . Report issue for preceding element
• Performance Criteria: Grounded in general systems theory [ 82] , performance criteria assess operational efficiency through metrics such as latency ( L L ), CPU usage ( C C ), energy consumption ( E E ), packet loss ( P l  o  s  s P_{loss} ), and signal strength ( R R ). These indicators support integrated evaluation of IoT/IIoT platforms across different deployments [ 27, 70, 50, 65] . Report issue for preceding element
Min–max normalization further enables consistent scoring across diverse measurement scales [ 71] , forming the basis for the Quantum Encryption Resilience Score (QERS) introduced in this study.
Report issue for preceding element
III Methodology (QERS Formulation)
Report issue for preceding element
The Quantum Encryption Resilience Score (QERS) framework provides a structured method for evaluating the operational resilience of computer systems, IoT, and IIoT platforms when post-quantum cryptography is applied. Instead of assessing cryptographic performance in isolation, QERS integrates multiple system-level metrics such as latency, packet reliability, CPU usage, energy consumption, signal strength, cryptographic overhead, and key size into a unified scoring process.
Report issue for preceding element
These raw metrics are first normalized to a common scale and then combined through three progressively detailed scoring models (Basic, Tuned, and Fusion). This layered design enables researchers and practitioners to compare algorithms and deployments consistently, quantify trade-offs between performance and security, and better understand how PQC affects real-world devices and networks.
Report issue for preceding element
QERS: Raw Metrics Input Latency (L) Crypto Overhead (O) Packet Loss ( P l  o  s  s P_{loss} ) CPU Usage (C) RSSI (R) Energy (E) Key Size (K) Min–Max Normalization Layer X norm = M  S ⋅ X − X min X max − X min X_{\text{norm}}=MS\cdot\dfrac{X-X_{\min}}{X_{\max}-X_{\min}} M  S ∈ [ 0 , 100 ] MS\in[0,100] Basic Formula QERS b  a  s  i  c = M  S − ( α  L n  o  r  m + β  O n  o  r  m + γ  P l  o  s  s , n  o  r  m ) \text{QERS}{basic}=MS-(\alpha L{norm}+\beta O_{norm}+\gamma P_{loss,norm}) Tuned Formula QERS t  u  n  e  d = M  S − ( α  L + β  O + γ  P + δ  C + ζ  E + η  K − ϵ  R ) \text{QERS}{tuned}=MS-(\alpha L+\beta O+\gamma P+\delta C+\zeta E+\eta K-\epsilon R) Fusion Formula P = ∑ w i  C i , S = ∑ w j  B j P=\sum w{i}C_{i},\quad S=\sum w_{j}B_{j} QERS f  u  s  i  o  n = α  ( M  S − P ) + β  S \text{QERS}_{fusion}=\alpha(MS-P)+\beta S Final Output Gauge 0 ⋯  ⋯  ⋯  ⋯  ⋯  ⋯  ⋯  ⋯ 100 0\quad\cdots\cdots\cdots\cdots\cdots\cdots\cdots\cdots\quad 100
Report issue for preceding element
Figure 1: Conceptual QERS framework showing metrics, normalization, score variants, and readiness interpretation. Report issue for preceding element
III-A Metrics Definition: Quantum Encryption Resilience Score (QERS)
Report issue for preceding element
The Quantum Encryption Resilience Score (QERS) primarily evaluates communication protocols operating under Post-Quantum Cryptography (PQC) by measuring key performance metrics such as latency ( L L ), packet reliability ( P l  o  s  s P_{loss} ), RSSI ( R R ), PQC key bytes ( K K ), and CPU usage ( C C ). Metrics are assessed under multiple protocol loads and cryptographic operations, including encryption and decryption scenarios with varying key sizes derived from PQC key size recommendations.
Report issue for preceding element
The proposed QERS framework follows a Multi-Criteria Decision Analysis (MCDA) methodology and implements a Multi-Criteria Decision Making (MCDM) model for score aggregation and ranking. MCDA is used to structure the evaluation problem and define performance and security criteria, while the MCDM formulation computes a composite resilience score through weighted normalization and aggregation [ 15, 13, 89] .
Report issue for preceding element
QERS is intended to help identify potential security and performance gaps, including protocol-specific weaknesses that fall outside the immediate scope of this research. The primary objective is to provide a reproducible instrument that reflects the operational stability and efficiency of multi-protocol IoT, IIoT, and computer system devices [ 25] .
Report issue for preceding element
The QERS computation employs a Multi-Criteria Decision Model (MCDM), where the parameters L , O , P l  o  s  s , C , R , E , L,O,P_{loss},C,R,E, and K K are weighted according to system priorities [ 50, 5] . Weighting allows QERS to adapt to specific scenarios such as real-time operation, energy-constrained deployments, or balanced general-purpose IoT systems. To refine these coefficients empirically, supervised learning techniques such as linear regression and random forest regression may be applied to experimental datasets or simulated environments, depending on the strategy used to observe performance behavior under varying encryption key sizes and QERS interoperability [ 35, 26] .
Report issue for preceding element
Each metric can be normalized using min–max scaling to ensure fair cross-protocol comparison:
Report issue for preceding element
X norm = M  S × X − X min X max − X min X_{\text{norm}}=MS\times\frac{X-X_{\text{min}}}{X_{\text{max}}-X_{\text{min}}}
[ 50, 65, 13]
Report issue for preceding element
In this study, the min–max bounds ( X min X_{\min} and X max X_{\max} ) were derived from the experimental dataset rather than theoretical limits, ensuring that normalization reflects realistic operating conditions.
Report issue for preceding element
Here, M  S MS represents the chosen maximum scale (e.g., 100), replacing the fixed percentage scale. This normalization approach supports consistency across heterogeneous metrics and helps reduce bias caused by large value disparities. QERS adopts an MCDA structure for evaluating complex decisions using multiple criteria and can also be applied in group-based decision systems where several evaluators independently contribute their judgment [ 90, 13] . The Handbook on Constructing Composite Indicators and User Guide presents the min–max normalization concept, where minimum and maximum values are determined across contexts to produce normalized indicators ranging from 0 to M  S MS [ 65] .
Report issue for preceding element
QERS can be structured hierarchically:
Report issue for preceding element
• Basic QERS: Evaluates core performance metrics ( L , O , P loss L,O,P_{\text{loss}} ) using a normalized score for quick PQC readiness comparison. Report issue for preceding element
• Tuned QERS: Incorporates CPU usage, RSSI, energy consumption, and key size ( C , R , E , K C,R,E,K ) with normalized scoring for more detailed analysis. Report issue for preceding element
• Fusion QERS: Combines normalized Performance and Security subscores ( P P and S S ) to generate a comprehensive score for IoT/IIoT devices. In Fusion QERS, M  S MS represents the maximum score on the chosen scale (e.g., 100) and serves as the reference for normalizing performance metrics. By subtracting the normalized performance subscore P P from M  S MS , higher QERS values indicate stronger protocol resilience while maintaining comparability across metrics and deployment environments. Report issue for preceding element
TABLE II: Mapping of MCDM Symbols to QERS Metrics
Sources: [ 50, 65, 13]
Report issue for preceding element
Report issue for preceding element
Weighting coefficients ( α , β , γ , δ , ϵ , ζ , η ) (\alpha,\beta,\gamma,\delta,\epsilon,\zeta,\eta) allow QERS to be tailored for real-time, energy-constrained, or balanced systems [ 50, 65] . Following approaches in data fusion for similarity coefficients, the QERS weighting scheme can be adapted using fixed-loss or learned weights, enabling machine learning techniques to optimize the relative importance of each performance and security metric under different IoT/IIoT operational conditions [ 69, 55, 22, 95] .
Report issue for preceding element
III-B QERS Formulas with Normalized Metrics
Report issue for preceding element
III-B 1 Basic QERS
Report issue for preceding element
QERS basic = M  S − ( α  L norm + β  O norm + γ  P loss,norm ) \text{QERS}{\text{basic}}=MS-(\alpha L{\text{norm}}+\beta O_{\text{norm}}+\gamma P_{\text{loss,norm}})
III-B 2 Fusion QERS
Report issue for preceding element
Performance Subscore:
Report issue for preceding element
P = ∑ i w i  C i norm , ∑ i w i = 1 P=\sum_{i}w_{i}C_{i}^{\text{norm}},\quad\sum_{i}w_{i}=1
Security Subscore:
Report issue for preceding element
S = ∑ j w j  B j norm , ∑ j w j = 1 S=\sum_{j}w_{j}B_{j}^{\text{norm}},\quad\sum_{j}w_{j}=1
Combined Fusion Score:
Report issue for preceding element
QERS fusion = α  ( M  S − P ) + β  S , α + β = 1 \text{QERS}_{\text{fusion}}=\alpha(MS-P)+\beta S,\quad\alpha+\beta=1
III-C QERS Interpretation
Report issue for preceding element TABLE III: QERS Readiness Levels
Report issue for preceding element
III-D QERS Evaluation: Basic, Tuned, and Fusion Metrics
Report issue for preceding element
Basic QERS Weighting Scenarios
Scenario α \alpha β \beta γ \gamma RT 0.55 0.20 0.15 EC 0.25 0.45 0.20 B 0.35 0.30 0.20
RT = Real-time, EC = Energy-constrained, B = Balanced; α \alpha = Latency, β \beta = Overhead, γ \gamma = Packet Loss.
Report issue for preceding element
Tuned QERS Weighting Scenarios (Core + Auxiliary Metrics)
Scenario α \alpha β \beta γ \gamma δ \delta ϵ \epsilon ζ \zeta η \eta RT 0.55 0.20 0.15 0.05 0.025 0.025 0.05 EC 0.25 0.45 0.20 0.025 0.025 0.05 0.05 B 0.35 0.30 0.20 0.05 0.05 0.05 0.05
α \alpha = Latency, β \beta = Overhead, γ \gamma = Packet Loss, δ \delta = CPU Usage, ϵ \epsilon = RSSI, ζ \zeta = Energy, η \eta = Key Size.
Report issue for preceding element
Fusion QERS – Performance Subscore
L L J J P l  o  s  s P_{loss} E E C C 0.3 0.1 0.2 0.2 0.2
Latency, Jitter, Packet Loss, Energy, CPU
Report issue for preceding element
Fusion QERS – Security Subscore
K K R R P r P_{r} C  o Co 0.25 0.35 0.25 0.15
Key size ( K K ), Algorithm robustness ( R R ), Proven resistance ( P r P_{r} ), Cryptographic overhead ( C  o Co ).
Report issue for preceding element
Report issue for preceding element
III-E Machine Learning Support for Fusion QERS
Report issue for preceding element
QERS also integrates a machine learning layer to assist in estimating the Fusion score under dynamic operating conditions [ 8] . A Random Forest regression model is used because it is robust to noise, handles nonlinear relationships, and performs well on small to medium datasets [ 86, 54] . The model is trained using historical measurements containing latency, CPU usage, RSSI, packet loss, energy values, and key-size data, together with their analytically computed QERS Fusion scores [ 47] .
Report issue for preceding element
Once trained, the model can predict an approximate Fusion value for new measurements, reducing sensitivity to short-term fluctuations [ 79, 97] . This enables trend-based assessment rather than relying strictly on single-point measurements [ 61] . Importantly, the machine learning component does not replace the QERS equations [ 29, 41] . Instead, it acts as a complementary estimator that enhances robustness when metrics are missing, unstable, or incomplete [ 20, 92] .
Report issue for preceding element
IV Proposed Framework
Report issue for preceding element
In this research, a multi-layer cybersecurity framework is proposed to measure, evaluate, and predict the quality and efficiency of post-quantum cryptography (PQC) algorithms on embedded processors representing typical Computer Systems, IoT, and IIoT devices. The framework consists of three main layers:
Report issue for preceding element
• Data Collection Layer: ESP32 and Raspberry Pi devices collect latency, CPU usage, RSSI, energy, and key-size metrics for different PQC algorithms. Report issue for preceding element
• Processing Layer: Collected metrics are normalized, smoothed using exponential smoothing, and processed by the QERS models and a Random Forest fusion layer. Report issue for preceding element
• Visualization Layer: Results are presented through a Flask-based dashboard using bar charts, heatmaps, and historical trends. Report issue for preceding element
QERS: Framework Overview Close Range (Near Wi-Fi AP) Far Range (5 m from AP) ESP32-C6 PQC Device Raspberry Pi CM4 QERS Server Wi-Fi Raw Metric Collection Layer Latency (L) Crypto Overhead (O) Packet Loss ( P l  o  s  s P_{loss} ) CPU Usage (C) RSSI (R) Energy (E) Key Size (K) Normalization Layer X n  o  r  m = M  S ⋅ X − X m  i  n X m  a  x − X m  i  n , M  S ∈ [ 0 , 100 ] X_{norm}=MS\cdot\dfrac{X-X_{min}}{X_{max}-X_{min}},;MS\in[0,100] QERS Computation Layer Basic QERS Tuned QERS Fusion QERS Visualization Layer Dashboard, Heatmaps, Trends, Final QERS Score Report issue for preceding element
Figure 2: Proposed QERS framework extended with ESP32-C6 PQC device, Raspberry Pi CM4 QERS server, and close-range and far-range wireless measurement contexts. Report issue for preceding element
To clarify how the abstract QERS framework is realized in practice, the experimental hardware and data flow are mapped onto the framework layers in Fig. 2. The ESP32-C6 executes post-quantum cryptographic algorithms and generates raw performance and wireless metrics, which are transmitted over Wi-Fi to a Raspberry Pi CM4 that performs QERS computation and visualization. Close-range and far-range wireless conditions are included to capture environmental effects on cryptographic and system behavior.
Report issue for preceding element
IV-A Interpretation & Use Cases
Report issue for preceding element
The hardware setup for the proposed framework includes:
Report issue for preceding element
• ESP32 devices: The ESP32C6-Devkit collect live metrics per PQC algorithm [ 10] . Report issue for preceding element
• Raspberry Pi devices: The Raspberry Pi CM4 aggregates data from multiple ESP32C6 units, processes metrics, and hosts the Flask dashboard [ 84] . Report issue for preceding element
• Protocols tested: Post-quantum cryptographic algorithms including Kyber, Dilithium, Falcon, SPHINCS+, and NTRU [ 24, 81] . Report issue for preceding element
• Metrics: Key size, latency, CPU utilization, RSSI, and energy, used to compute QERS Basic, Tuned, and Fusion scores with ML-predicted fusion intervals [ 34] . Report issue for preceding element
The use cases include of:
Report issue for preceding element
Real-time PQC performance monitoring in IoT networks [ 76, 32, 72] . Report issue for preceding element
Historical trend analysis for security evaluation [ 39, 74] . Report issue for preceding element
Identification of low-performing PQC algorithms in constrained devices [ 91] . Report issue for preceding element
IV-B Illustrative Validation / Methodology
Report issue for preceding element
To validate the proposed framework, we performed representative measurements on multiple PQC algorithms using an ESP32-C6 device. Metrics were collected continuously and smoothed to reduce fluctuations [ 33, 80] . A Random Forest model was used as a supplementary fusion layer to smooth, interpolate, and estimate QERS values from noisy or partially observed metric streams [ 100, 46] . Synthetic samples were generated to follow the same statistical distributions as the collected measurements in order to stabilize the learning process and prevent artificial bias.
Report issue for preceding element
V Results
Report issue for preceding element
A continuous 24-hour measurement campaign was conducted using an ESP32C6-DevKit in order to illustrate the behavior of the proposed QERS framework under realistic operating conditions. Five post-quantum cryptographic algorithms (Kyber, Dilithium, Falcon, SPHINCS+, and NTRU) were exercised repeatedly over Wi-Fi. Each iteration recorded latency, CPU utilization, RSSI, and three QERS variants (QERS Basic, QERS Tuned, and QERS Fusion), allowing observation of how QERS responds to varying system conditions.
Report issue for preceding element
Two representative wireless scenarios were considered:
Report issue for preceding element
• Scenario 1: ESP32 positioned close to the Wi-Fi access point. Report issue for preceding element
• Scenario 2: ESP32 positioned approximately 5 meters away. Report issue for preceding element
All measurements were recorded to CSV and processed through the QERS computation pipeline. All reported QERS scores were normalized to a 0–100 scale, enabling direct comparison of QERS behavior across different conditions.
Report issue for preceding element
V-A Heatmap Analysis
Report issue for preceding element
Figures 3 and 4 visualize the normalized multi-metric inputs and resulting QERS behavior for both wireless scenarios. The heatmaps illustrate how QERS integrates latency, CPU usage, RSSI, and key-related effects into a composite resilience indicator. Variations across algorithms demonstrate the sensitivity of QERS to changes in cryptographic and wireless conditions.
Report issue for preceding element 
Figure 3: Scenario 1: QERS multi-metric heatmap (normalized 0–100). Report issue for preceding element 
Figure 4: Scenario 2: QERS multi-metric heatmap (normalized 0–100). Report issue for preceding element
V-B Distribution of Scores
Report issue for preceding element
Figures 5 and 6 show the distribution of QERS scores over the 24-hour period. The reduced spread of QERS Fusion illustrates the stabilizing effect of the fusion and smoothing layers when compared with raw or single-metric inputs.
Report issue for preceding element 
Figure 5: Scenario 1: Distribution of normalized QERS scores. Report issue for preceding element 
Figure 6: Scenario 2: Distribution of normalized QERS scores. Report issue for preceding element
V-C Representative Scatter Analysis
Report issue for preceding element
Figures 7 and 8 provide representative scatter plots using median values per algorithm. These plots demonstrate how QERS varies in relation to latency while preserving the relative structure of the underlying measurements.
Report issue for preceding element 
Figure 7: Scenario 1: Representative scatter (QERS vs latency). Report issue for preceding element 
Figure 8: Scenario 2: Representative scatter (QERS vs latency). Report issue for preceding element TABLE IV: Average QERS Fusion scores for near and far communication scenarios.
Report issue for preceding element
V-D Distance Comparison
Report issue for preceding element
Table IV summarizes average QERS Fusion values across the two wireless scenarios. The reduction in QERS at increased distance illustrates that the proposed framework captures environmental stress in addition to cryptographic and computational effects.
Report issue for preceding element
VI Discussion
Report issue for preceding element
The experimental results demonstrate that PQC schemes behave differently when evaluated in a resource-constrained IoT environment using a multi-metric scoring model such as QERS [ 56] . Unlike traditional benchmarks that isolate individual parameters, QERS reveals how latency, CPU load, signal strength, and key size interact in practice [ 83, 17] .
Report issue for preceding element
Across both scenarios, Dilithium and NTRU achieved the highest QERS Fusion scores. These algorithms benefit from strong security properties and predictable execution behavior, which results in stable normalized scores even when wireless conditions vary [ 1] .
Report issue for preceding element
In contrast, Kyber and SPHINCS+ produced consistently lower QERS values. This outcome does not imply weaker cryptographic strength; rather, it reflects their design emphasis on reducing overhead, which lowers their contribution across certain QERS dimensions such as key size and computational weight [ 58, 67] .
Report issue for preceding element
The distance experiment provided additional insight. Increasing the ESP32's separation from the access point caused measurable reductions in QERS scores, particularly for algorithms that are more sensitive to retransmissions and signal fluctuations [ 85] . This indicates that QERS captures environmental stress in addition to purely computational factors, which is essential for IoT deployments operating under unstable connectivity [ 94, 101] .
Report issue for preceding element
Importantly, the Fusion layer did not eliminate variation entirely. Instead, it smoothed transient spikes while preserving real system behavior. This supports the interpretation of QERS as a decision-support indicator rather than a fixed or absolute performance rating [ 52] .
Report issue for preceding element
VII Conclusion
Report issue for preceding element
This work introduced QERS, a practical and dynamic evaluation framework for assessing post-quantum cryptography in constrained IoT environments. Unlike classical benchmarking approaches that treat performance metrics in isolation, QERS integrates latency, CPU load, signal quality, and key size into a unified, normalized resilience score. A real ESP32-based testbed was used to collect continuous measurements across multiple PQC algorithms and wireless distances, demonstrating that QERS exposes performance and reliability trade-offs that are difficult to observe using single-metric analysis.
Report issue for preceding element
Future work will extend QERS with additional real-world indicators such as packet loss, temperature, and latency variance, and will evaluate its behavior across diverse IoT platforms. Overall, QERS provides a reproducible, explainable, and hardware-aware methodology for selecting post-quantum cryptographic algorithms that balance security, efficiency, and operational stability in real IoT deployments.
Report issue for preceding element
References
Report issue for preceding element
[1] ↑ M. Abbasi, F. Cardoso, P. Váz, J. Silva, and P. Martins (2025) A practical performance benchmark of post-quantum cryptography across heterogeneous computing environments. Cryptography 9 ( 2), pp. 32. Cited by: §VI.
[2] ↑ M. Abbasi, F. Cardoso, P. Váz, J. Silva, and P. Martins (2025) A practical performance benchmark of post-quantum cryptography across heterogeneous computing environments. Cryptography 9 ( 2). External Links: Link, ISSN 2410-387X, Document Cited by: § II-B, § II-C.
[3] ↑ A. Acuaviva, D. Aguirre, R. Peña, and M. Sanz (2025) Benchmarking quantum computers: towards a standard performance evaluation approach. External Links: 2407.10941, Link Cited by: § II-C.
[4] ↑ S. Al-Sarawi, M. Anbar, R. Abdullah, and A. B. Al Hawari (2020) Internet of things market analysis forecasts, 2020–2030. In 2020 Fourth World Conference on smart trends in systems, security and sustainability (WorldS4), pp. 449–453. Cited by: § I-A.
[5] ↑ B. Alojaiman (2023) A multi-criteria decision-making process for the selection of an efficient and reliable iot application. Processes 11 ( 5). External Links: Link, ISSN 2227-9717, Document Cited by: § III-A.
[6] ↑ D. Ameyed, F. Jaafar, F. Petrillo, and M. Cheriet (2023-05) Quality and security frameworks for iot-architecture models evaluation. SN Computer Science 4 ( 4), pp. 394. External Links: Document, Link, ISSN 2661-8907 Cited by: §I, § II-C.
[7] ↑ A. Aslam (2025-06-04) Quantum computing threats to cryptography: a comprehensive analysis of vulnerabilities, countermeasures, and future-proofing strategies. Note: Preprint, Research SquareVersion 1, https://doi.org/10.21203/rs.3.rs-6795420/v1 Cited by: 1st item.
[8] ↑ F. Barbosa, A. Vidal, and F. Mello (2016) Machine learning for cryptographic algorithm identification. Journal of Information Security and Cryptography (Enigma) 3 ( 1), pp. 3–8. External Links: ISSN 2595-5217, Document, Link Cited by: § III-E.
[9] ↑ E. M. Barhoumi and Y. Charabi (2025-06) Quantum-secure cryptographic primitives for embedded ece systems. Electronics Communications, and Computing Summit 3 ( 2), pp. 98–109. Cited by: § II-A, TABLE I, TABLE I, TABLE I, TABLE I, TABLE I.
[10] ↑ V. Barral Vales, O. C. Fernández, T. Domínguez-Bolaño, C. J. Escudero, and J. A. García-Naya (2022) Fine time measurement for the internet of things: a practical approach using esp32. IEEE Internet of Things Journal 9 ( 19), pp. 18305–18318. External Links: Document Cited by: 1st item.
[11] ↑ R. Bavdekar, E. Jayant Chopde, A. Agrawal, A. Bhatia, and K. Tiwari (2023) Post quantum cryptography: a review of techniques, challenges and standardizations. In 2023 International Conference on Information Networking (ICOIN), Vol. , pp. 146–151. External Links: Document Cited by: § II-A.
[12] ↑ I. Behnke and H. Austad (2024) Real-time performance of industrial iot communication technologies: a review. IEEE Internet of Things Journal 11 ( 5), pp. 7399–7410. External Links: Document Cited by: § II-D.
[13] ↑ V. Belton and T. J. Stewart (2002) Multiple criteria decision analysis: an integrated approach. 1 edition, Springer, New York, NY. Note: Originally published by Kluwer Academic Publishers, 2002; Hardcover ISBN: 978-0-7923-7505-0; Softcover ISBN: 978-1-4613-5582-3 External Links: ISBN 978-1-4615-1495-4, Document Cited by: § III-A, § III-A, § III-A, TABLE II.
[14] ↑ M. Bennis, M. Debbah, and H. V. Poor (2018) Ultrareliable and low-latency wireless communication: tail, risk, and scale. Proceedings of the IEEE 106 ( 10), pp. 1834–1853. External Links: Document Cited by: § II-B.
[15] ↑ S. G. Bhol, J. R. Mohanty, and P. K. Pattnaik (2020) Cyber security metrics evaluation using multi-criteria decision-making approach. In Smart Intelligent Computing and Applications, S. C. Satapathy, V. Bhateja, J. R. Mohanty, and S. K. Udgata (Eds.), Singapore, pp. 665–675. External Links: ISBN 978-981-32-9690-9 Cited by: §I, § III-A.
[16] ↑ F. Borges, P. R. Reis, and D. Pereira (2020) A comparison of security and its performance for key agreements in post-quantum cryptography. IEEE Access 8, pp. 142413–142422. Cited by: § II-A.
[17] ↑ A. Bouramdane (2023) Cyberattacks in smart grids: challenges and solving the multi-criteria decision-making for cybersecurity options, including ones that incorporate artificial intelligence, using an analytical hierarchy process. Journal of Cybersecurity and Privacy 3 ( 4), pp. 662–705. Cited by: §VI.
[18] ↑ S.A. Butler (2002) Security attribute evaluation method: a cost-benefit approach. In Proceedings of the 24th International Conference on Software Engineering. ICSE 2002, Vol. , pp. 232–240. External Links: Document Cited by: 2nd item.
[19] ↑ S. A. Butler (2003) Security attribute evaluation method. Ph.D. Thesis, School of Computer Science, Carnegie Mellon University. Cited by: 2nd item.
[20] ↑ J. R. Carpenter and M. Smuk (2021) Missing data: a statistical framework for practice. Biometrical Journal 63 ( 5), pp. 915–947. External Links: Document, Link, https://onlinelibrary.wiley.com/doi/pdf/10.1002/bimj.202000196 Cited by: § III-E.
[21] ↑ A. Chakraborty (2024) Multi-criteria decision analysis framework for optimal combination of blockchain to determine scalability in iot. In 2024 IEEE International Conference on Communication, Computing and Signal Processing (IICCCS), Vol. , pp. 1–6. External Links: Document Cited by: § II-D.
[22] ↑ J. Chen, J. Holliday, and J. Bradshaw (2009) A machine learning approach to weighting schemes in the data fusion of similarity coefficients. Journal of Chemical Information and Modeling 49 ( 2), pp. 185–194. External Links: Document, Link Cited by: § III-A.
[23] ↑ L. Chen, L. Chen, S. Jordan, Y. Liu, D. Moody, R. Peralta, R. A. Perlner, and D. Smith-Tone (2016) Report on post-quantum cryptography. Vol. 12, US Department of Commerce, National Institute of Standards and Technology …. Cited by: § II-A.
[24] ↑ K. Cherkaoui Dekkaki, I. Tasic, and M. Cano (2024) Exploring post-quantum cryptography: review and directions for the transition process. Technologies 12 ( 12). External Links: Link, ISSN 2227-7080, Document Cited by: 3rd item.
[25] ↑ J. Choi and J. Lee (2024) Secure and scalable internet of things model using post-quantum macsec. Applied Sciences 14 ( 10). External Links: Link, ISSN 2076-3417, Document Cited by: § III-A.
[26] ↑ F. Chollet (2021) Deep learning with python. 2nd edition, Manning Publications, Shelter Island, NY, USA. External Links: ISBN 978-1-61729-686-4 Cited by: § III-A.
[27] ↑ E. D. Demir, B. Bilgin, and M. C. Onbasli (2025) Performance analysis and industry deployment of post-quantum cryptography algorithms. External Links: 2503.12952, Link Cited by: 3rd item.
[28] ↑ G. Dhillon and G. Torkzadeh (2006) Value-focused assessment of information system security in organizations. Information Systems Journal 16 ( 3), pp. 293–314. External Links: Document, Link, https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1365-2575.2006.00219.x Cited by: 2nd item.
[29] ↑ D. Didona and P. Romano (2015) Hybrid machine learning/analytical models for performance prediction: a tutorial. In Proceedings of the 6th acm/spec international conference on performance engineering, pp. 341–344. Cited by: § III-E.
[30] ↑ B. Dong and Q. Wang (2025) EPQUIC: efficient post-quantum cryptography for quic-enabled secure communication. In Proceedings of the Great Lakes Symposium on VLSI 2025, GLSVLSI '25, New York, NY, USA, pp. 141–146. External Links: ISBN 9798400714962, Link, Document Cited by: § II-C.
[31] ↑ A. Einstein, B. Podolsky, and N. Rosen (1935-05) Can quantum-mechanical description of physical reality be considered complete?. Phys. Rev. 47, pp. 777–780. External Links: Document, Link Cited by: §I.
[32] ↑ K. Fizza, P. P. Jayaraman, A. Banerjee, N. Auluck, and R. Ranjan (2023) IoT-qwatch: a novel framework to support the development of quality-aware autonomic iot applications. IEEE Internet of Things Journal 10 ( 20), pp. 17666–17679. External Links: Document Cited by: item 1.
[33] ↑ E. S. Gardner Jr (1985) Exponential smoothing: the state of the art. Journal of forecasting 4 ( 1), pp. 1–28. Cited by: § IV-B.
[34] ↑ A. F. Gentile, D. Macrì, D. L. Carnì, E. Greco, and F. Lamonaca (2024) A performance analysis of security protocols for distributed measurement systems based on internet of things with constrained hardware and open source infrastructures. Sensors 24 ( 9). External Links: Link, ISSN 1424-8220, Document Cited by: 4th item.
[35] ↑ A. Géron (2019) Hands-on machine learning with scikit-learn, keras, and tensorflow: concepts, tools, and techniques to build intelligent systems. 2nd edition, O'Reilly Media, Sebastopol, CA, USA. Note: Updated for TensorFlow 2, Early Release External Links: ISBN 978-1-492-03264-9 Cited by: § III-A.
[36] ↑ H. Gharavi, J. Granjal, and E. Monteiro (2024) Post-quantum blockchain security for the internet of things: survey and research directions. IEEE Communications Surveys & Tutorials 26 ( 3), pp. 1748–1774. External Links: Document Cited by: 2nd item.
[37] ↑ Š. Grigaliūnas and R. Brūzgienė (2025) Towards a unified quantum risk assessment. Electronics 14 ( 17), pp. 3338. External Links: Document, Link Cited by: § II-C.
[38] ↑ M. Gupta and M. J. Nene (2021) Quantum computing: a measurement and analysis review. Concurrency and Computation: Practice and Experience 33 ( 20), pp. e6344. External Links: Document, Link Cited by: § II-C.
[39] ↑ S. Halder and T. Newe (2022) Enabling secure time-series data sharing via homomorphic encryption in cloud-assisted iiot. Future Generation Computer Systems 133, pp. 351–363. External Links: ISSN 0167-739X, Document, Link Cited by: item 2.
[40] ↑ M. I. Hossain, S. A. Sumon, H. Md. Hasan, F. Akter, M. B. Badhon, and M. N. U. Islam (2024) Quantum-edge cloud computing: a future paradigm for iot applications. External Links: 2405.04824, Link Cited by: § II-C.
[41] ↑ H. Ibeid, S. Meng, O. Dobon, L. Olson, and W. Gropp (2019) Learning with analytical models. In 2019 IEEE International Parallel and Distributed Processing Symposium Workshops (IPDPSW), Vol. , pp. 778–786. External Links: Document Cited by: § III-E.
[42] ↑ D. Iliadis-Apostolidis, D. C. Lawo, S. Kosta, I. Tafur Monroy, and J. J. Vegas Olmos (2025) QRoNS: quantum resilience over ipsec tunnels for network slicing. Electronics 14 ( 21). External Links: Link, ISSN 2079-9292, Document Cited by: § II-C.
[43] ↑ A. Ishizaka and P. Nemery (2013) Multi-criteria decision analysis: methods and software. John Wiley & Sons. Cited by: § II-D.
[44] ↑ A. Jaddoa, H. Alharbi, A. Hommadi, and H. A. Ismael (2025) Toward scalable and sustainable detection systems: a behavioural taxonomy and utility-based framework for security detection in iot and iiot. IoT 6 ( 4). External Links: Link, ISSN 2624-831X, Document Cited by: 1st item, § II-D.
[45] ↑ H. Jaidka, N. Sharma, and R. Singh (2020-May 18) Evolution of iot to iiot: applications & challenges. In Proceedings of the International Conference on Innovative Computing & Communications (ICICC) 2020, Note: Available at SSRN External Links: Link, Document Cited by: §I.
[46] ↑ N. Kandhoul, S. K. Dhurandher, and I. Woungang (2021) Random forest classifier-based safe and reliable routing for opportunistic iot networks. International Journal of Communication Systems 34 ( 1), pp. e4646. External Links: Document, Link Cited by: § IV-B.
[47] ↑ A. Kaushik, L. S. S. Vadlamani, M. M. Hussain, M. Sahay, R. Singh, A. K. Singh, S. Indu, P. Goswami, and N. G. V. Kousik (2023) Post quantum public and private key cryptography optimized for iot security. Wireless Personal Communications 129 ( 2), pp. 893–909. External Links: Document, Link, ISSN 1572-834X Cited by: § III-E.
[48] ↑ M. A. Khan and M. A. Khan (2025) Securing iot in the post-quantum era: implementation, challenges and future directions. IEEE Communications Standards Magazine (), pp. 1–1. External Links: Document Cited by: §I.
[49] ↑ K. S. Kiangala and Z. Wang (2021) An effective communication prototype for time-critical iiot manufacturing factories using zero-loss redundancy protocols, time-sensitive networking, and edge-computing in an industry 4.0 environment. Processes 9 ( 11). External Links: Link, ISSN 2227-9717, Document Cited by: § II-D.
[50] ↑ A. Kulkarni (2022-02) Multiple criteria decision making. Springer. External Links: ISBN 978-981-16-7416-7, Document Cited by: 3rd item, § III-A, § III-A, § III-A, TABLE II.
[51] ↑ M. Kumar and P. Pattnaik (2020) Post quantum cryptography(pqc) - an overview: (invited paper). In 2020 IEEE High Performance Extreme Computing Conference (HPEC), Vol. , pp. 1–9. External Links: Document Cited by: §I.
[52] ↑ R. Kumar, P. Kumar, and Y. Kumar (2020) Time series data prediction using iot and machine learning technique. Procedia computer science 167, pp. 373–381. Cited by: §VI.
[53] ↑ D. Lall, A. Agarwal, W. Zhang, L. Lindoy, T. Lindström, S. Webster, S. Hall, N. Chancellor, P. Wallden, R. Garcia-Patron, E. Kashefi, V. Kendon, J. Pritchard, A. Rossi, A. Datta, T. Kapourniotis, K. Georgopoulos, and I. Rungger (2025) A review and collection of metrics and benchmarks for quantum computers: definitions, methodologies and software. External Links: 2502.06717, Link Cited by: § II-C.
[54] ↑ L. Langsetmo, J. T. Schousboe, B. C. Taylor, J. A. Cauley, H. A. Fink, P. M. Cawthon, D. M. Kado, K. E. Ensrud, and O. F. in Men (MrOS) Research Group (2023) Advantages and disadvantages of random forest models for prediction of hip fracture risk versus mortality risk in the oldest old. JBMR Plus 7 ( 8), pp. e10757. External Links: Document, Link Cited by: § III-E.
[55] ↑ B. K. Lee, J. Lessler, and E. A. Stuart (2010) Improving propensity score weighting using machine learning. Statistics in Medicine 29 ( 3), pp. 337–346. External Links: Document Cited by: § III-A.
[56] ↑ R. Leelavathi (2025) SMCRP-iot: secure multi-metric cooperative routing protocol for low-power internet of things networks. International Journal of Applied Mathematics 38 ( 12s), pp. 1775–1789. Cited by: §VI.
[57] ↑ T. Liu, G. Ramachandran, and R. Jurdak (2024) Post-quantum cryptography for internet of things: a survey on performance and optimization. arXiv abs/2401.17538. External Links: Document Cited by: §I.
[58] ↑ A. Magyari and Y. Chen (2025) Optimizing sphincs+ for low-power devices. Electronics 14 ( 17), pp. 3460. Cited by: §VI.
[59] ↑ W. Mao, Z. Zhao, Z. Chang, G. Min, and W. Gao (2021) Energy-efficient industrial internet of things: overview and open issues. IEEE Transactions on Industrial Informatics 17 ( 11), pp. 7225–7237. External Links: Document Cited by: § II-B.
[60] ↑ D. Marchsreiter (2025) Towards quantum-safe blockchain: exploration of pqc and public-key recovery on embedded systems. IET Blockchain 5 ( 1), pp. e12094. External Links: Document, Link Cited by: § II-D.
[61] ↑ R. P. Masini, M. C. Medeiros, and E. F. Mendes (2023) Machine learning advances for time series forecasting. Journal of Economic Surveys 37 ( 1), pp. 76–111. External Links: Document, Link, https://onlinelibrary.wiley.com/doi/pdf/10.1111/joes.12429 Cited by: § III-E.
[62] ↑ P. Mathur (2020) Overview of iot and iiot. In IoT Machine Learning Applications in Telecom, Energy, and Agriculture: With Raspberry Pi and Arduino Using Python, pp. 19–43. External Links: ISBN 978-1-4842-5549-0, Document, Link Cited by: §I.
[63] ↑ D. Moody (2021) Nist pqc standardization update. National Institute of Standards and Technology, pp. 2021–10. Cited by: §I.
[64] ↑ M. Nagy and S. G. Akl (2007) Quantum computing: beyond the limits of conventional computation†. International Journal of Parallel, Emergent and Distributed Systems 22 ( 2), pp. 123–135. External Links: Document, Link, https://doi.org/10.1080/13547500600899209 Cited by: § II-B.
[65] ↑ M. Nardo, M. Saisana, A. Saltelli, S. Tarantola, A. Hoffman, and E. Giovannini (2008-09) Handbook on constructing composite indicators and user guide. Vol. 2005, Organisation for Economic Co‑operation and Development / Joint Research Centre of the European Commission. External Links: ISBN 978-92-64-04345-9, Document Cited by: 3rd item, § II-D, § III-A, § III-A, § III-A, TABLE II.
[66] ↑ C. Nash, D. Pearce, and J. Stanley (1975) AN evaluation of cost-benefit analysis criteria. Scottish Journal of Political Economy 22 ( 2), pp. 121–134. External Links: Document, Link, https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1467-9485.1975.tb00054.x Cited by: 1st item.
[67] ↑ T. Nguyen, D. Dam, P. Duong, B. Kieu-Do-Nguyen, C. Pham, and T. Hoang (2024) Efficient hardware implementation of the lightweight crystals-kyber. IEEE Transactions on Circuits and Systems I: Regular Papers. Cited by: §VI.
[68] ↑ M. Nofer, K. Bauer, O. Hinz, W. van der Aalst, and C. Weinhardt (2023) Quantum computing. Business & Information Systems Engineering 65 ( 4), pp. 361–367. External Links: Document, Link, ISSN 1867-0202 Cited by: §I.
[69] ↑ D. Ocampo, D. Posso, R. Namakian, and W. Gao (2024) Adaptive loss weighting for machine learning interatomic potentials. Computational Materials Science 244, pp. 113155. External Links: ISSN 0927-0256, Document, Link Cited by: § III-A.
[70] ↑ F. Opiłka, M. Niemiec, M. Gagliardi, and M. A. Kourtis (2024) Performance analysis of post-quantum cryptography algorithms for digital signature. Applied Sciences 14 ( 12). External Links: Link, ISSN 2076-3417, Document Cited by: 3rd item.
[71] ↑ S. G. K. Patro and K. K. Sahu (2015) Normalization: a preprocessing stage. External Links: 1503.06462, Link Cited by: § II-D.
[72] ↑ R. Poler, A. Karakostas, S. Vrochidis, A. Marguglio, S. Gálvez-Settier, P. Figueiras, A. Gómez-González, B. Mandler, S. Wellsandt, R. Trevino, S. Bassoumi, and C. Agostinho (2021) An iot-based reliable industrial data services for manufacturing quality control. In 2021 IEEE International Conference on Engineering, Technology and Innovation (ICE/ITMC), Vol. , pp. 1–8. External Links: Document Cited by: item 1.
[73] ↑ J. Preskill (2012) Quantum computing and the entanglement frontier. External Links: 1203.5813, Link Cited by: § II-B.
[74] ↑ A. Protogerou, E. V. Kopsacheilis, A. Mpatziakas, K. Papachristou, T. I. Theodorou, S. Papadopoulos, A. Drosou, and D. Tzovaras (2022) Time series network data enabling distributed intelligence—a holistic iot security platform solution. Electronics 11 ( 4), pp. 529. External Links: Document, Link Cited by: item 2.
[75] ↑ T. Qiu, J. Chi, X. Zhou, Z. Ning, M. Atiquzzaman, and D. O. Wu (2020) Edge computing in industrial internet of things: architecture, advances and challenges. IEEE Communications Surveys & Tutorials 22 ( 4), pp. 2462–2488. External Links: Document Cited by: § II-B.
[76] ↑ M. Rahmati and N. Rahmati (2025) Lightweight post-quantum cryptographic frameworks for real-time secure communications in iot edge networks. Telecommunication Systems 88 ( 4), pp. 136. External Links: Document, Link, ISSN 1572-9451 Cited by: item 1.
[77] ↑ V. Rathi, L. Chopra, R. Rawal, N. Rajput, S. Valia, M. Aggarwal, and A. Gairola (2025) QORE : quantum secure 5g/b5g core. External Links: 2510.19982, Link Cited by: § II-C.
[78] ↑ A. Rehman and O. Alharbi (2025) QESIF: a lightweight quantum-enhanced iot security framework for smart cities. Smart Cities 8 ( 4). External Links: Link, ISSN 2624-6511, Document Cited by: § II-C.
[79] ↑ I. Reis, D. Baron, and S. Shahaf (2019) Probabilistic random forest: a machine learning algorithm for noisy data sets. The Astronomical Journal 157 ( 1), pp. 16. External Links: Document Cited by: § III-E.
[80] ↑ D. Risteski, A. Kulakov, and D. Davcev (2004) Single exponential smoothing method and neural network in one method for time series prediction. In IEEE Conference on Cybernetics and Intelligent Systems, 2004., Vol. 2, pp. 741–745. External Links: Document Cited by: § IV-B.
[81] ↑ A. Scrivano (2025) A comparative study of classical and post-quantum cryptographic algorithms in the era of quantum computing. External Links: 2508.00832, Link Cited by: 3rd item.
[82] ↑ E. H. Shaw (2009) A general theory of systems performance criteria. International Journal of General Systems 38 ( 8), pp. 851–869. External Links: Document, Link, https://doi.org/10.1080/03081070903270543 Cited by: 3rd item.
[83] ↑ N. B. Silva, D. F. Pigatto, P. S. Martins, and K. R. Branco (2016) Case studies of performance evaluation of cryptographic algorithms for an embedded system and a general purpose computer. Journal of Network and Computer Applications 60, pp. 130–143. Cited by: §VI.
[84] ↑ V. Simadiputra and N. Surantha (2021) Rasefiberry: secure and efficient raspberry-pi based gateway for smarthome iot architecture. Bulletin of Electrical Engineering and Informatics 10 ( 2), pp. 1035–1045. Cited by: 2nd item.
[85] ↑ N. Sklavos, M. Manninger, X. Zhang, O. Koufopavlou, V. Hassler, P. Kitsos, M. Mcloone, P. Hamalainen, A. P. Fournaris, V. Rijmen, et al. (2017) Wireless security and cryptography: specifications and implementations. CRC press. Cited by: §VI.
[86] ↑ K. Sooksatra and P. Rivas (2020) A review of machine learning and cryptography applications. In 2020 International Conference on Computational Science and Computational Intelligence (CSCI), Vol. , pp. 591–597. External Links: Document Cited by: § III-E.
[87] ↑ H. Soubra, H. Elsayed, Y. Elbrolosy, Y. Adel, and Z. Attia (2025) Comprehensive review of metrics and measurements of quantum systems. Metrics 2 ( 2). External Links: Link, ISSN 3042-5042, Document Cited by: § II-C.
[88] ↑ F. Tacchino, A. Chiesa, S. Carretta, and D. Gerace (2020) Quantum computers as universal quantum simulators: state-of-the-art and perspectives. Advanced Quantum Technologies 3 ( 3), pp. 1900052. External Links: Document, Link Cited by: § II-B.
[89] ↑ G. Tasopoulos, J. Li, A. P. Fournaris, R. K. Zhao, A. Sakzad, and R. Steinfeld (2022) Performance evaluation of post-quantum tls 1.3 on resource-constrained embedded systems. In Information Security Practice and Experience, C. Su, D. Gritzalis, and V. Piuri (Eds.), Cham, pp. 432–451. External Links: ISBN 978-3-031-21280-2 Cited by: § III-A.
[90] ↑ A. Tawakuli, D. Kaiser, and T. Engel (2023) Transforming iot data preprocessing: a holistic, normalized and distributed approach. In Proceedings of the 20th ACM Conference on Embedded Networked Sensor Systems, SenSys '22, New York, NY, USA, pp. 1083–1088. External Links: ISBN 9781450398862, Link, Document Cited by: § III-A.
[91] ↑ V. A. Thakor, M. A. Razzaque, and M. R. A. Khandaker (2021) Lightweight cryptography algorithms for resource-constrained iot devices: a review, comparison and research opportunities. IEEE Access 9 (), pp. 28177–28193. External Links: Document Cited by: item 3.
[92] ↑ T. Thomas and E. Rajabi (2021-04) A systematic review of machine learning-based missing value imputation techniques. Data Technologies and Applications 55 ( 4), pp. 558–585. External Links: ISSN 2514-9288, Document, Link, https://www.emerald.com/dta/article-pdf/55/4/558/556336/dta-12-2020-0298.pdf Cited by: § III-E.
[93] ↑ E. Triantaphyllou (2000) Multi-criteria decision making methods. In Multi-criteria Decision Making Methods: A Comparative Study, pp. 5–21. External Links: ISBN 978-1-4757-3157-6, Document, Link Cited by: § II-D.
[94] ↑ A. Ukil, J. Sen, and S. Koilakonda (2011) Embedded security for internet of things. In 2011 2nd National Conference on Emerging Trends and Applications in Computer Science, pp. 1–6. Cited by: §VI.
[95] ↑ P. Wang, H. Zhu, M. Wilamowska-Korsak, Z. Bi, and L. Li (2014) Determination of weights for multiobjective decision making or machine learning. IEEE Systems Journal 8 ( 1), pp. 63–72. External Links: Document Cited by: § III-A.
[96] ↑ A. Wiesmaier, N. Alnahawi, T. Grasmeyer, J. Geißler, A. Zeier, P. Bauspieß, and A. Heinemann (2021) On pqc migration and crypto-agility. External Links: 2106.09599, Link Cited by: §I.
[97] ↑ S. Xia, G. Wang, Z. Chen, Y. Duan, and Q. liu (2019) Complete random forest based class noise filtering learning for improving the generalizability of classifiers. IEEE Transactions on Knowledge and Data Engineering 31 ( 11), pp. 2063–2078. External Links: Document Cited by: § III-E.
[98] ↑ G. Yalamuri, P. Honnavalli, and S. Eswaran (2022) A review of the present cryptographic arsenal to deal with post-quantum threats. Procedia Computer Science 215, pp. 834–845. Note: 4th International Conference on Innovative Data Communication Technology and Application External Links: ISSN 1877-0509, Document, Link Cited by: §I.
[99] ↑ Yashika and L. Cai (2025-07) Security challenges and cryptographic solutions for iot devices. SSRN Working Paper Technical Report 5357821, Wilfrid Laurier University. Note: Posted: August 6, 2025. Date Written: July 11, 2025 External Links: Link Cited by: §I.
[100] ↑ J. Zhang, M. Zulkernine, and A. Haque (2008) Random-forests-based network intrusion detection systems. IEEE Transactions on Systems, Man, and Cybernetics, Part C (Applications and Reviews) 38 ( 5), pp. 649–659. External Links: Document Cited by: § IV-B.
[101] ↑ Z. Zlatev and I. Dimov (2006) Computational and numerical challenges in environmental modelling. Vol. 13, Elsevier. Cited by: §VI.
Report Issue
Report GitHub Issue
Title:
Content selection saved. Describe the issue below:
Description:
Submit without GitHub Submit in GitHub
Report Issue for Selection
Generated by L A T E xml
Instructions for reporting errors
We are continuing to improve HTML versions of papers, and your feedback helps enhance accessibility and mobile support. To report errors in the HTML that will help us improve conversion and rendering, choose any of the methods listed below:
Click the "Report Issue" button.
Open a report feedback form via keyboard, use " Ctrl + ?".
Make a text selection and click the "Report Issue for Selection" button near your cursor.
You can use Alt+Y to toggle on and Alt+Shift+Y to toggle off accessible reporting links at each section.
Our team has already identified the following issues. We appreciate your time reviewing and reporting rendering errors we may not have found yet. Your efforts will help us improve the HTML versions for all readers, because disability should not be a barrier to accessing research. Thank you for your continued support in championing open access for all.
Have a free development cycle? Help support accessibility at arXiv! Our collaborators at LaTeXML maintain a list of packages that need conversion, and welcome developer contributions.