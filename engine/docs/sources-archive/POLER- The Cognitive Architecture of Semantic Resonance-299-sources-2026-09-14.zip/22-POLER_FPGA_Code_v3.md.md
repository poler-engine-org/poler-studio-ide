POLER FPGA Cryptographic Engine — Code v3.0 (iverilog-verified)
Version History
Mathematical Foundation
Core Equations
Deformed Tensor Product: X ⊗_ε Y = (X·Y) + ε·(X⊙Y)
X·Y = matrix multiplication (linear interaction)
X⊙Y = Hadamard product (element-wise, NOT XOR)
ε = deformation/energy parameter (f64 in software, Q32.32 in hardware)
Dissipator: D = L·L^T (entropy burner, symmetric positive semi-definite)
Resonance: J = A - A^T (skew-symmetric temporal echo)
Logical Projector (EXACT in v3.0): Π_Λ = I - Jc^T·(Jc·Jc^T + δI)^{-1}·Jc
Computed via Newton-Schulz iterative matrix inversion (8 iterations)
Tikhonov regularization δ ensures invertibility
v2.x bug: used approximation Π_Λ ≈ I - α·Jc^T·Jc (WRONG)
POLER Cycle: P_new = p_t - η·Π_Λ(D·p_t + γ·J·p_t + ∇F)
Quantum Normalization (REAL CORDIC in v3.0): p_{t+1} = (1-mix)·P_new + mix·P_new/||P_new||
v2.x bug: inv_norm = 1 (placeholder, normalization did nothing)
v3.0: CORDIC Newton-Raphson 1/sqrt (4 iterations, Q32.32)
Priority Assessment
Zig Test Results (f64 reference)
All 10 unit tests pass:
Iverilog Verification Results (Q32.32 hardware)
tb_tensor.v — Tensor Product: 6/6 PASSED
tb_poler.v — POLER Cycle: 4/4 PASSED
Bugs Fixed During Iverilog Testing
tensor_product.v pipeline timing: stage3_valid was tied to valid_in, not pipelined. Fixed.
tensor_product.v input latching: X/Y inputs not latched in pipeline. Added pipeline regs.
iverilog inline variable declarations: Moved all temp vars to module scope.
signed/unsigned port mismatch: Made all ports consistently signed.
Convergence Note
POLER cycle doesn't fully converge in 512 iterations at Q32.32 because:
Q32.32 has ~9 decimal digits (vs f64's ~15)
Threshold 2^{-16} is tight for fixed-point
Cycle IS iterating correctly (final state sensible)
Production: tune eta, gamma, threshold for FPGA
--------------------------------------------------------------------------------
Zig Code (f64, software reference)
tensor.zig
main.zig
build.zig
Verilog Code (Q32.32, FPGA hardware, iverilog-verified)
newton_schulz_inv.v (NEW — Critical: Exact Projector)
cordic_inv_sqrt.v (NEW — High Priority: CORDIC Normalization)
poler_cycle.v (UPDATED v3.0 — Exact Projector + CORDIC)
tensor_product.v (FIXED — Pipeline + Hadamard)
top_level.v (UPDATED v3.0 — with delta parameter)
Testbenches (iverilog-compatible)
tb_tensor.v
tb_poler.v (NEW — POLER Cycle Verification)
RISC-V Assembly
startup.s
--------------------------------------------------------------------------------
Known Issues & Future Work
POLER convergence in Q32.32 — Needs parameter tuning (eta, gamma, threshold) for fixed-point
FPGA synthesis — Need Vivado/Quartus for actual bitstream generation
Newton-Schulz convergence verification — Should verify Π_Λ ≈ Π_Λ² in iverilog
CORDIC precision validation — Compare Q32.32 Newton 1/sqrt vs f64 reference
RISC-V assembly untested — Demo only, not critical for FPGA core
Archetype ε≠0 idempotency — Theoretical problem: a⊙a ≠ a for ε>0
Timing closure — Multi-cycle Newton-Schulz needs timing analysis
DSP48 resource estimation — Newton-Schulz: 32 DSPs; CORDIC: 3-4 DSPs