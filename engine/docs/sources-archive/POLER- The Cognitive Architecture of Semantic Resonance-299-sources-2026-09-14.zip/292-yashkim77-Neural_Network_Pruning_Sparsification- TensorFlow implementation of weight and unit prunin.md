> Source: https://github.com/yashkim77/Neural_Network_Pruning_Sparsification

GitHub - yashkim77/Neural_Network_Pruning_Sparsification: TensorFlow implementation of weight and unit pruning and sparsification
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert
yashkim77 / Neural_Network_Pruning_Sparsification Public
Notifications You must be signed in to change notification settings
Fork 0
Star 8
TensorFlow implementation of weight and unit pruning and sparsification
8 stars 0 forks Branches Tags Activity
Star
Notifications You must be signed in to change notification settings
Code
Issues 0
Pull requests 0
Actions
Projects 0
Security 0
Insights
Additional navigation options
Code
Issues
Pull requests
Actions
Projects
Security
Insights
yashkim77/Neural_Network_Pruning_Sparsification
master
1 Branch 0 Tags  
Go to file
Code
Open more actions menu
Folders and files
Repository files navigation
README
Weights-and-Unit-Neuron-Pruning
In this project, my aim is to train a large neural network and then prune it to understand how the accuracy of the NN is affected as more and more of it pruned. Pruning here effectively referes to increasing sparsity in the network, and given a neural network layer, pruning can be performed in 2 ways:
Weight pruning: set individual weights in the weight matrix to zero. This corresponds to deleting connections between the neurons of consecutive layers. Here, to achieve sparsity of k% we rank the individual weights in weight matrix W according to their magnitude (absolute value) |w(i,j)|, and then set to zero the smallest k%.
Unit/Neuron pruning: set entire columns in the weight matrix to zero, in effect deleting the corresponding output neuron. Here to achieve sparsity of k% we rank the the columns of a weight matrix according to their L2-norm & delete the neurons with smallest k% norms.
Naturally, as we increase the sparsity and delete more of the network, the task performance will progressively degrade.
In this project, I plotted the accuracy vs sparsity plots for both weight pruning and neuron pruning.
About
TensorFlow implementation of weight and unit pruning and sparsification
Topics
python neural-network tensorflow pruning model-compression weight-pruning sparsification weight-matrix unit-pruning
Resources
Readme
Uh oh!
There was an error while loading. Please reload this page.
Activity
Stars
8 stars
Watchers
0 watching
Forks
0 forks
Report repository
Releases
No releases published
Packages 0
No packages published
Languages
Jupyter Notebook 100.0%
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.