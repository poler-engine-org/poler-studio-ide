> Source: https://betterprogramming.pub/boosting-machine-learning-performance-with-rust-aab1f3ae1424

Boosting Machine Learning Performance With Rust | by Vince Vella | Better Programming
Sitemap
Open in app
Sign up
Sign in
Medium Logo
Get app
Write
Search
Sign up
Sign in 
[
Better Programming
](https://medium.com/better-programming?source=post_page---publication_nav-d0b105d10f0a-aab1f3ae1424---------------------------------------)
·
Follow publication
Advice for programmers.
Follow publication
Boosting Machine Learning Performance With Rust
Rust + LibTorch = 5.5x training speed improvement on Python + PyTorch
Vince Vella
Follow
11 min read
·
May 21, 2023 
326
5 
Listen
Share
Press enter or click to view image in full size 
Photo by Chris Liverani on Unsplash
In this article, I wish to share my experience of trying to create a little Machine Learning (ML) framework from scratch using Rust.
For my experiment, I had the following objectives in mind:
I wanted to investigate whether rather than using Python + PyTorch, shifting to Rust + LibTorch (the C++ backend library of PyTorch) would translate into tangible speed improvements, especially during the model training process. As we know, ML models are becoming bigger and hence requiring increasing (sometimes unfeasible for the common bloke) computational power to train. One way to mitigate increasing hardware requirements is to identify a way how to make algorithms more computationally efficient. Knowing that within PyTorch, Python just acts as a layer on top of LibTorch, my big question was whether replacing the top Python layer with Rust is worth the effort. The plan was to use the Tch-rs Rust crate to just expose me to the Tensors and Autograd functionality of the LibTorch DLL, hence acting as our “gradients calculator”, but then develop the rest from scratch in Rust.
I wanted to keep the code simple enough to permit a clear understanding of all the linear algebra being performed and allow me to easily extend it if required.
As much as possible my framework had to allow me to define ML models following a similar structure as per standard Python/PyTorch.
Ummm … for “rusty” fun and learning :)
The post is not intended to teach Rust per se, but rather to provide an appreciation of how Rust can be applied for ML and the benefits of that.
Jumping straight to the final result, my little framework allows me to create Neural Network models as per below:
Listing 1 — Defining my Neural Network model.
… and then instantiate and train the model like this:
Listing 2 — Instantiating and training my Neural Network model.
For PyTorch users, the above creates quite an intuitive similarity with how one would define and train a Neural Network in Python. The example above shows a Neural Network model, which is then used for classification (the model is applied on the Mnist dataset, which I shall be using as my benchmark dataset to compare the Rust — Python model versions).
In the first block of the code, a MyModel struct is created which holds two layers of type Linear.
The second block is the MyModel stuct implementation, which defines an associated function new. This function initializes the two layers and returns a new instance of the struct.
Finally, the third block implements the Compute trait for MyModel , which defines the forward method. In the main function I then load the Mnist dataset, initialize the memory, instantiate MyModel , and then train it using 100 Epochs, batch size of 128, Cross Entropy Loss, and a learning rate of 0.3.
Pretty intuitive huh? That is what would be required to create and train new models in Rust using my little framework. However, we now start looking a bit under the hood to see what makes the above possible.
Looking at the above code, an obvious question might pop up if you are used to building ML models in PyTorch — what is the Memory reference doing? I explain below.
The Forward Pass
From ML literature, we know that the Neural Network training mechanism happens by iteratively going through two steps for a number of epochs (and normally also for a number of batches), a forward pass, and a backward pass (backpropagation).
In the forward pass, we push the inputs and subsequent calculations along all the layers in the network, where for each layer we have: 
Equation 1 — Linear and Activation functions happening in each Neural Network layer (Goodfellow et. al., 2016)
where w provides the weights for the linear function, b the biases, and then this is passed through an activation function such as Sigmoid providing the non-linearity.
With that information, we can now create our Linear layer (Listing 3 below). As you can notice, the structure for defining a layer follows the same structure for defining our model (Listing 1 above) and implements the same functions and traits.
In the case of the Linear layer, the struct contains a field named params. The params field is a collection of type HashMap, where the key is of type String, which stores a parameter name, and the value is of type usize , which holds the location of the specific parameter (which is a PyTorch tensor) in our Memory, which in turn acts as our store for all our parameters.
Listing 3— Defining a Neural Network Layer, in this case, a Linear Layer.
In line with Equation 1, in our associated function new, we insert on our HashMap two parameters “W” and “ b” that are required for the Linear Layer.
The mem.new_push() method, presented later, creates their respective tensors in the required sizes, pushes them to the memory store, and returns their location. The boolean parameter in the insert method defines that we need to calculate the gradient for these parameters. In this way, each layer will contain the parameter names and their respective tensor store locations in our Memory structure.
Similar to the MyModel definition, we then implement the Compute trait for our Linear Layer. This requires defining the function forward, which is called during the forward pass of the training process.
In this function, we first obtain a reference to the two tensor parameters from our tensor store using the get method and then calculate our linear function (Equation 1). Similar to PyTorch, from our Neural Network we output the unnormalized predictions (logits) and perform the normalization (in this case Softmax) later during the error calculation.
One might ask, why take this approach to represent a Linear Layer rather than maybe hard-coding Equation 1 directly in one or two lines of code?
This approach was taken so that if additional Neural Network layer types need to be defined, e.g. a CNN or an LSTM layer, then it is just a question of copying exactly the above Linear Layer structure and injecting additional parameters and computations in the associated function new and forward method and it will immediately become available to include in your models (as per Listing 1).
In addition, this approach of pushing all tensors in a central store will become handy in the backpropagation step, as I will discuss below.
Error Calculation
At the end of the forward pass, we need to calculate the error between our predictions and the targets.
Get Vince Vella's stories in your inbox
Join Medium for free to get updates from this writer.
Subscribe
Subscribe
Below is the code for mean squared error calculation, which is typically applied for regression, and cross-entropy loss, which is typically applied for classification.
Listing 4 — Mean Squared Error and Cross Entropy Loss Functions.
And that completes the forward pass … we now kick off with the backward pass.
The Backward Pass
In the backward pass, we need to update the parameters of the model using the gradients, where each gradient is the derivative of the loss function with respect to each respective parameter. In the first step, we obtain the gradients: 
Equation 2 — Derivative of the loss function with respect to our model parameters (Goodfellow et. al., 2016)
where m' represents the size of the minibatch. For each minibatch, the parameters are then updated as follows:
Press enter or click to view image in full size 
Equation 3— Parameter update rule using the gradient (Goodfellow et. al., 2016)
where epsilon is the learning rate.
This is where I use the Autograd functionality from LibTorch to obtain my gradients. In PyTorch, we normally apply the backward method on the loss to calculate the derivatives, which is then followed by calling the step function from the optimizer to apply the gradients to the model parameters. The same process happens here, with the difference that we cannot apply the step function directly to apply the gradients because we are not extending our models from the nn.Module class and using PyTorch optimizers as we normally do in Python. Hence the step part we need to cater to it ourselves.
In the snippet below (Listing 5) we show our tensor Memory implementation, which also caters to the gradient step functionality. The tensor store is implemented as a struct with two fields, a size, which holds the current number of tensors stored, and values, which is a vector of tensors. In the implementation block, the new method handles the store intialiazation and the push , new_push and get methods handle the passing back and forth of the tensors (the latter two we utilized in the Linear Layer above).
Listing 5 — The tensor store — Memory.
The last two methods in the code above implement the basic gradient descent and the gradient descent with momentum algorithms. The methods assume that the backward step, which generates the gradients, was already called, so here we are handling what in PyTorch would be the step function call.
The process involves looping through each tensor on the store, obtain the calculated gradient using the grad method, and then by calling the set_data method we apply the parameter update rule. One can easily introduce other methods and implement other algorithms such as Rmsprop and Adam.
The Training Loop
In the training loop, we bring together everything discussed earlier for our learning process. As usual, we apply a loop for each epoch, in which we are then looping for each minibatch, and for each minibatch we do a forward pass, calculate the error, call the backward method on the error to generate the gradients, and then apply the gradients (Listing 6).
Listing 6— The training loop.
Whilst in PyTorch we have our Dataset and Dataloader classes which handle the data mini-batching mechanism, in my case I built my own batching mechanism.
The Rust function below (Listing 7) accepts a reference to the full dataset and then returns an iterator which allows the training function (Listing 6) to iterate over the mini-batches.
Listing 7— Mini-batching.
Final Helper Functions
The last two functions that you will need to run the full code, are just two helper functions (Listing 8).
The first function loads the dataset from a directory that I named data (you have to first download the Mnist dataset).
The second function calculates the accuracy of the model, accepting as parameters a reference to the target and predictions.
Listing 8 — Last two helper functions.
The only imports that you will need are:
Listing 9 — Required imports.
Before running the code you also need to download the LibTorch C++ Library from the PyTorch website.
Results and Opinions
To compare the above code with a Python-PyTorch equivalent, I tried to be as faithful as possible to get a fair comparison, mainly ensuring that I apply the same Neural Network hyper-parameters, training parameters, and training algorithms.
For my tests, I applied the Mnist dataset, which consists of 60K training examples with 28x28 features. I ran the tests on my laptop, a Surface Pro 8, i7, with 16G of RAM, hence no GPU. After running the tests multiple times, on average Rust training resulted in 5.5 times faster than the Python equivalent. Unfortunately, at this point I didn't pinpoint which areas in the training process generated the biggest gains in performance over and above a standard PyTorch approach (is it in the training loops?, in the error calculations?, in the gradient step?, etc), hence the gain I mention is an overall gain over the whole process.
As a concluding thought, developing the above in Rust definitely takes more time initially, especially for someone like me who I still consider a newbie in Rust, however, once you build all your library components and pipeline code and just need to test/create new models (like in Listing 1), then in my opinion it becomes as easy as working in Python.
The improvements in training speed that I experienced are in my opinion not to be ignored — it could literally save long hours, if not days, of training, especially with the increasing complexity of ML models, larger datasets, or huge iterative learning processes like in Reinforcement Learning.
Hope you found the article worth the read! In our Part 2 of the series we focus on Convolutional Neural Networks.
References
Ian Goodfellow, Yoshua Bengio and Aaron Courville, Deep Learning, MIT Press, 2016. http://www.deeplearningbook.org 
326
5 
Rust
AI
Machine Learning
Pytorch
Programming 
326 
326
5 
Follow
[
Published in Better Programming
](https://medium.com/better-programming?source=post_page---post_publication_info--aab1f3ae1424---------------------------------------)
223K followers
·
Last published Nov 10, 2023
Advice for programmers.
Follow
Follow
[
Written by Vince Vella
](https://betterprogramming.pub/@vincevella?source=post_page---post_author_info--aab1f3ae1424---------------------------------------)
126 followers
·
27 following
https://www.linkedin.com/in/vvella/
Follow
Responses (5)
 
Write a response
What are your thoughts?
Cancel
Respond
Akshay Ballal
Jun 12, 2023
11
1 reply
Reply
Mauricio Maroto
Jun 25, 2024
1
Reply
Rick Knowles
Dec 4, 2023
Reply
See all responses
More from Vince Vella and Better Programming
Vince Vella
[
Deep Q-Networks in Rust from scratch
In this experiment I explore Reinforcement Learning (RL), in particular Deep Q-Networks (DQNs), using Rust from scratch. Why? As you will…
](https://betterprogramming.pub/@vincevella/deep-q-networks-in-rust-from-scratch-7c89a7b6c893?source=post_page---author_recirc--aab1f3ae1424----0---------------------7189680f_afbc_4fef_bd1a_72fb5bdd9e55--------------)
Jul 25, 2023
A clap icon 15  
In
Better Programming
by
Lev Maximov
[
NumPy Illustrated: The Visual Guide to Numpy
Brush up your NumPy or learn it from scratch
](https://betterprogramming.pub/better-programming/numpy-illustrated-the-visual-guide-to-numpy-3b1d4976de1d?source=post_page---author_recirc--aab1f3ae1424----1---------------------7189680f_afbc_4fef_bd1a_72fb5bdd9e55--------------)
Dec 21, 2020
A clap icon 3.5K A response icon 23  
In
Better Programming
by
Jason Ngan
[
Understanding the Offset and Cursor Pagination
A quick look at the Pagination algorithms
](https://betterprogramming.pub/better-programming/understanding-the-offset-and-cursor-pagination-8ddc54d10d98?source=post_page---author_recirc--aab1f3ae1424----2---------------------7189680f_afbc_4fef_bd1a_72fb5bdd9e55--------------)
Dec 5, 2022
A clap icon 751 A response icon 6  
Vince Vella
[
Boosting Machine Learning Performance With Rust (Part 2)
Experimenting with Convolutional Neural Networks (CNNs) from scratch in Rust.
](https://betterprogramming.pub/@vincevella/boosting-machine-learning-performance-with-rust-part-2-5e4c2d0adf19?source=post_page---author_recirc--aab1f3ae1424----3---------------------7189680f_afbc_4fef_bd1a_72fb5bdd9e55--------------)
Jun 11, 2023
A clap icon 151 A response icon 2 
See all from Vince Vella
See all from Better Programming
Recommended from Medium
In
Towards Deep Learning
by
Sumit Pandey
[
Andrej Karpathy Just Built an Entire GPT in 243 Lines of Python
No PyTorch. No TensorFlow. Just pure Python and basic math.
](https://betterprogramming.pub/towards-deep-learning/andrej-karpathy-just-built-an-entire-gpt-in-243-lines-of-python-7d66cfdfa301?source=post_page---read_next_recirc--aab1f3ae1424----0---------------------74dec7ca_c135_418d_a60f_b065a1766d27--------------)
Feb 15
A clap icon 2.3K A response icon 34  
In
Rustaceans
by
Enzo Lombardi
[
Rapid GPUI: Component-Based Desktop Development — Part 4
Advanced Layouts
](https://betterprogramming.pub/rustaceans/rapid-gpui-component-based-desktop-development-part-4-e5d87408503c?source=post_page---read_next_recirc--aab1f3ae1424----1---------------------74dec7ca_c135_418d_a60f_b065a1766d27--------------)
Dec 2, 2025
A clap icon 19  
In
Activated Thinker
by
Shane Collins
[
Why the Smartest People in Tech Are Quietly Panicking Right Now
The water is rising fast, and your free version of ChatGPT is hiding the terrifying, exhilarating truth
](https://betterprogramming.pub/activated-thinker/why-the-smartest-people-in-tech-are-quietly-panicking-right-now-d2feb86e7e4b?source=post_page---read_next_recirc--aab1f3ae1424----0---------------------74dec7ca_c135_418d_a60f_b065a1766d27--------------)
Feb 12
A clap icon 10.3K A response icon 457  
In
CodeX
by
MayhemCode
[
Why Thousands Are Buying Mac Minis to Escape Big Tech AI Subscriptions Forever | Clawdbot
Something strange happened in early 2026. Apple stores started running low on Mac Minis. Tech forums exploded with setup guides. Developers…
](https://betterprogramming.pub/codex/why-thousands-are-buying-mac-minis-to-escape-big-tech-ai-subscriptions-forever-clawdbot-10c970c72404?source=post_page---read_next_recirc--aab1f3ae1424----1---------------------74dec7ca_c135_418d_a60f_b065a1766d27--------------)
Feb 15
A clap icon 1.96K A response icon 31  
Agent Native
[
Local LLMs That Can Replace Claude Code
Small team of engineers can easily burn >$2K/mo on Anthropic's Claude Code (Sonnet/Opus 4.5). As budgets are tight, you might be wondering…
](https://betterprogramming.pub/@agentnativedev/local-llms-that-can-replace-claude-code-6f5b6cac93bf?source=post_page---read_next_recirc--aab1f3ae1424----2---------------------74dec7ca_c135_418d_a60f_b065a1766d27--------------)
Jan 20
A clap icon 1.4K A response icon 40  
In
Level Up Coding
by
Teja Kusireddy
[
I Stopped Using ChatGPT for 30 Days. What Happened to My Brain Was Terrifying.
91% of you will abandon 2026 resolutions by January 10th. Here's how to be in the 9% who actually win.
](https://betterprogramming.pub/gitconnected/i-stopped-using-chatgpt-for-30-days-what-happened-to-my-brain-was-terrifying-70d2a62246c0?source=post_page---read_next_recirc--aab1f3ae1424----3---------------------74dec7ca_c135_418d_a60f_b065a1766d27--------------)
Dec 28, 2025
A clap icon 7.9K A response icon 302 
See more recommendations
Help
Status
About
Careers
Press
Blog
Privacy
Rules
Terms
Text to speech