> Source: https://rxinfer.com/

RxInfer.jl - Fast and Flexible Bayesian Inference
Get Started Documentation Examples Server Discussions Team GitHub 
Welcome to RxInfer.jl - a powerful Julia package for fast and flexible Bayesian inference. By combining message passing algorithms with model's graph structure, RxInfer makes probabilistic programming both efficient and accessible. Whether you're working on machine learning, signal processing, or complex statistical models, RxInfer provides the tools you need to solve real-world inference problems.
[
Documentation
Learn how to use RxInfer with our comprehensive guides and API reference](https://docs.rxinfer.com/)
[
Examples
Explore practical examples and tutorials to get started quickly](https://examples.rxinfer.com/)
RxInfer In Other Languages
Use RxInfer from your favorite programming language through our HTTP server
RxInferServer Python SDK TypeScript SDK
Why RxInfer?
Copied to your clipboard!
Discover the power of reactive Bayesian inference
User Friendly
Clean specification of probabilistic models and inference constraints.
Streaming Datasets
Reactive message passing-based inference for streaming datasets.
Hybrid Models
Support for hybrid models combining discrete and continuous latent variables.
Scalable
Scalability for large models with millions of parameters and observations.
Extensible
Designed to be extended with custom operations.
Community Driven
Join our vibrant community of developers and researchers.
Hello World with RxInfer
Copied to your clipboard!
Probabilistic programming made simple
RxInfer makes it easy to specify both generative models and variational constraints using familiar mathematical notation. The flexible design lets you control exactly how inference should be performed.
Generative Models
Define probabilistic models with intuitive syntax
Variational Constraints
Customize inference with flexible constraints
Graphical Models
Let RxInfer choose the best inference procedure
Explore more interactive examples and discover the full potential of reactive Bayesian inference.
View Examples
RxInfer is Fast
Copied to your clipboard!
Optimized for performance and scalability
Below is a benchmark comparison between RxInfer's message passing algorithm and Hamiltonian Monte Carlo (HMC) on a linear dynamical system. The benchmark measures time to convergence for inferring the posterior distribution. As shown, on this problem RxInfer's optimized message passing achieves over 300x faster inference results compared to traditional HMC sampling.
17000 34000 Milliseconds RxInfer 103.33ms HMC 33388.15ms
Smaller time is better
View benchmark details
Lightning Fast
Optimized message passing
Real-time Processing
Process data with minimal latency
Resource Efficient
Optimized CPU utilization
Solve Complex Problems
Copied to your clipboard!
See RxInfer in action with real-world applications
Track Hidden States in Real-time
Unveil real-time insights into dynamic systems with our software's prowess in tracking hidden states. By providing continuous monitoring and analysis, our tool empowers you to gain a deeper understanding of complex processes, enabling informed decision-making and proactive responses.
Dynamic Systems Real-time State Tracking
Your browser does not support the video tag. Please try viewing this page in a modern browser.
Smart Navigation & Collision Avoidance
Stay in control, prevent collisions, and streamline routes effortlessly with RxInfer. Streamline your navigation experience and enhance safety.
Navigation Safety Automation
Your browser does not support the video tag. Please try viewing this page in a modern browser.
Reactive Reasoning with Active Inference
Enhance your decision-making process with the Active Inference framework. Designed to help you analyze incoming information in real-time, this tool enables you to make well-informed choices and adapt to changing situations effectively.
Active Inference Decision Making Adaptive
Your browser does not support the video tag. Please try viewing this page in a modern browser.
Enhance Standard ML Techniques with Probabilistic Inference
Explore how RxInfer extends standard ML techniques with probabilistic inference, providing a more robust and flexible approach to handling complex problems that require uncertainty estimation.
Standard ML Probabilistic Inference Complex Problems
Your browser does not support the video tag. Please try viewing this page in a modern browser.
Discover more examples and see how RxInfer can help solve your inference problems.
Explore More Examples
Watch JuliaCon Talk
Copied to your clipboard!
Deep dive into RxInfer's architecture and capabilities
Learn about the core concepts behind RxInfer, its implementation, and how it enables reactive probabilistic programming with message passing-based inference. This talk from JuliaCon 2023 covers the fundamental principles and demonstrates real-world applications. 
The Julia Programming Language
89.5K subscribers
RxInfer.jl: A Package for Real-Time Bayesian Inference | Dmitry Bagaev | JuliaCon 2023
The Julia Programming Language
Search
Info
Shopping 
Tap to unmute
If playback doesn't begin shortly, try restarting your device.
Your browser can't play this video.
Learn more 
More videos on YouTube
Share [x]
Include playlist
An error occurred while retrieving sharing information. Please try again later.
Watch later
Share
Copy link
Watch on 
0:00
/
•
Live
• 
An error occurred.
Try watching this video on www.youtube.com, or enable JavaScript if it is disabled in your browser.
Community Videos
Join our growing community and explore more videos from Julia developers. Share your own experiences and connect with fellow RxInfer users!
Fast Bayesian Inference with RxInfer.jl
Intro to RxInfer by Doggo.jl
Variational inference with RxInfer
Active Inference Symposium
Bayesian Methods in Engineering Applications with RxInfer
Stable Ecosystem
Copied to your clipboard!
Unleash the power of Bayesian inference with our robust ecosystem of Julia packages
If you like what we're doing, consider giving us a star! ⭐
[
RxInferServer.jl
RESTful HTTP server for deploying RxInfer models as web services with OpenAPI support. GitHub repository](https://github.com/lazydynamics/RxInferServer)
[
RxInferClient.py
Python client for interacting with RxInferServer, providing a clean API for model deployment and inference. GitHub repository](https://github.com/lazydynamics/RxInferClient.py)
[
Rocket.jl
Enables reactive programming in Julia for processing of asynchronous data streams. GitHub repository](https://github.com/reactivebayes/Rocket.jl)
[
ReactiveMP.jl
Efficient, easily extensible and schedule-free reactive message passing-based inference engine. GitHub repository](https://github.com/reactivebayes/ReactiveMP.jl)
[
GraphPPL.jl
Powerful, user-friendly, graph-based specification of both model and inference constraints. GitHub repository](https://github.com/reactivebayes/GraphPPL.jl)
[
ExponentialFamily.jl
A package that implements the rich family of probability distributions. GitHub repository](https://github.com/reactivebayes/ExponentialFamily.jl)
[
BayesBase.jl
A package that serves as an umbrella, defining methods essential for Bayesian statistics. GitHub repository](https://github.com/reactivebayes/BayesBase.jl)
Julia Ecosystem
RxInfer is built upon the incredible Julia ecosystem - its powerful packages for statistics and scientific computing make RxInfer possible.
Explore Julia Packages
Thanks to Our Supporters
Copied to your clipboard!
We're grateful to these amazing organizations for their continued support and contributions
 Eindhoven University of Technology
 NWO
 GN Hearing
 Lazy Dynamics
 Active Inference Institute
Let's stay in touch!
Copied to your clipboard!
Here are some of the ways you can follow us:
YouTube
GitHub
ReactiveBayes
Discussions
Issues
Twitter / X
© BIASlab, 2022-2024, ReactiveBayes 2024-present
33388.15ms