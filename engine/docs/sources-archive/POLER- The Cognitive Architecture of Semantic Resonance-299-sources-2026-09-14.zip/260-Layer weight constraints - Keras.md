> Source: https://keras.io/2/api/layers/constraints/

Layer weight constraints
None 
Getting started Developer guides Code examples Keras 3 API documentation Keras 2 API documentation Models API Layers API The base Layer class Layer activations Layer weight initializers Layer weight regularizers Layer weight constraints Core layers Convolution layers Pooling layers Recurrent layers Preprocessing layers Normalization layers Regularization layers Attention layers Reshaping layers Merging layers Activation layers Callbacks API Optimizers Metrics Losses Data loading Built-in small datasets Keras Applications Mixed precision Utilities KerasTuner: Hyperparam Tuning KerasHub: Pretrained Models KerasRS
Get started
Guides
API
Examples
Keras Hub
Keras RS
Keras Tuner
Keras 3 API documentation Keras 2 API documentation
Models API Layers API The base Layer class Layer activations Layer weight initializers Layer weight regularizers Layer weight constraints Core layers Convolution layers Pooling layers Recurrent layers Preprocessing layers Normalization layers Regularization layers Attention layers Reshaping layers Merging layers Activation layers Callbacks API Optimizers Metrics Losses Data loading Built-in small datasets Keras Applications Mixed precision Utilities
► Keras 2 API documentation / Layers API / Layer weight constraints
Layer weight constraints
[source]
MaxNorm class
Copied!
MaxNorm weight constraint.
Constrains the weights incident to each hidden unit to have a norm less than or equal to a desired value.
Also available via the shortcut function tf.keras.constraints.max_norm .
Arguments
max_value: the maximum norm value for the incoming weights.
axis: integer, axis along which to calculate weight norms. For instance, in a Dense layer the weight matrix has shape (input_dim, output_dim) , set axis to 0 to constrain each weight vector of length (input_dim,) . In a Conv2D layer with data_format="channels_last" , the weight tensor has shape (rows, cols, input_depth, output_depth) , set axis to [0, 1, 2] to constrain the weights of each filter tensor of size (rows, cols, input_depth) .
[source]
MinMaxNorm class
Copied!
MinMaxNorm weight constraint.
Constrains the weights incident to each hidden unit to have the norm between a lower bound and an upper bound.
Also available via the shortcut function tf.keras.constraints.min_max_norm .
Arguments
min_value: the minimum norm for the incoming weights.
max_value: the maximum norm for the incoming weights.
rate: rate for enforcing the constraint: weights will be rescaled to yield (1 - rate) * norm + rate * norm.clip(min_value, max_value) . Effectively, this means that rate=1.0 stands for strict enforcement of the constraint, while rate<1.0 means that weights will be rescaled at each step to slowly move towards a value inside the desired interval.
axis: integer, axis along which to calculate weight norms. For instance, in a Dense layer the weight matrix has shape (input_dim, output_dim) , set axis to 0 to constrain each weight vector of length (input_dim,) . In a Conv2D layer with data_format="channels_last" , the weight tensor has shape (rows, cols, input_depth, output_depth) , set axis to [0, 1, 2] to constrain the weights of each filter tensor of size (rows, cols, input_depth) .
[source]
NonNeg class
Copied!
Constrains the weights to be non-negative.
Also available via the shortcut function tf.keras.constraints.non_neg .
[source]
UnitNorm class
Copied!
Constrains the weights incident to each hidden unit to have unit norm.
Also available via the shortcut function tf.keras.constraints.unit_norm .
Arguments
axis: integer, axis along which to calculate weight norms. For instance, in a Dense layer the weight matrix has shape (input_dim, output_dim) , set axis to 0 to constrain each weight vector of length (input_dim,) . In a Conv2D layer with data_format="channels_last" , the weight tensor has shape (rows, cols, input_depth, output_depth) , set axis to [0, 1, 2] to constrain the weights of each filter tensor of size (rows, cols, input_depth) .
[source]
RadialConstraint class
Copied!
Constrains Conv2D kernel weights to be the same for each radius.
Also available via the shortcut function tf.keras.constraints.radial_constraint .
For example, the desired output for the following 4-by-4 kernel:
Copied!
is this::
Copied!
This constraint can be applied to any Conv2D layer version, including Conv2DTranspose and SeparableConv2D , and with either "channels_last" or "channels_first" data format. The method assumes the weight tensor is of shape (rows, cols, input_depth, output_depth) .
Layer weight constraints
MaxNorm class
MinMaxNorm class
NonNeg class
UnitNorm class
RadialConstraint class
Terms
|
Privacy