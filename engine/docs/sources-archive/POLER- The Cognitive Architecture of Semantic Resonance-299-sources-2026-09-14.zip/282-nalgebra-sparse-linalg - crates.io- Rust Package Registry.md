> Source: https://crates.io/crates/nalgebra-sparse-linalg

nalgebra-sparse-linalg - crates.io: Rust Package Registry
For full functionality of this site it is necessary to enable JavaScript.
[
crates.io
](https://crates.io/)
The Rust community's crate registry
Submit
Change color scheme
light
dark
system
Browse All Crates | Log in with GitHub
Change color scheme
light
dark
system
Menu
Browse All Crates
Log in with GitHub
nalgebra-sparse-linalg v0.1.10
Sparse linear algebra library for Rust using nalgebra including linear solvers and SVD.
Readme
11 Versions
Dependencies
Dependents
Security
nalgebra-sparse-linalg
  
High-performance sparse linear algebra algorithms for Rust - Iterative solvers, matrix decompositions, and numerical methods for large-scale sparse matrices using nalgebra_sparse.
Overview
nalgebra-sparse-linalg provides efficient numerical algorithms for sparse linear algebra computations in Rust. Built on top of nalgebra_sparse , this library offers:
Fast iterative solvers for large sparse linear systems
Matrix decompositions including truncated SVD for dimensionality reduction
Memory-efficient algorithms optimized for sparse matrices
Generic implementations supporting multiple precision types ( f32 , f64 )
Production-ready with comprehensive test coverage
Perfect for scientific computing, machine learning, data analysis, and numerical simulation applications.
Features
Iterative Linear System Solvers
Jacobi - Simple and parallelizable iterative solver
Gauss-Seidel - Faster convergence for well-conditioned systems
Successive Over-Relaxation (SOR) - Accelerated convergence with relaxation parameter
Conjugate Gradient (CG) - Optimal for symmetric positive-definite matrices
BiConjugate Gradient (BiCG) - General solver for non-symmetric systems
Algebraic Multigrid (AMG) - Advanced multigrid solver for large-scale problems
Matrix Decompositions
Truncated SVD - Randomized algorithm for efficient singular value decomposition
Dimensionality reduction for large-scale data analysis
Low-rank approximations for matrix compression
⚡ Performance Features
CSR and CSC matrix support - Industry-standard sparse formats
Memory-efficient algorithms - Minimal memory footprint
Parallel computation - Multi-threaded where applicable
Generic scalar types - Support for f32 , f64 , and complex numbers
Zero-copy operations - Efficient memory usage
Quick Start
Add this to your Cargo.toml :
For advanced multigrid methods, enable the AMG feature:
Solving Linear Systems
Truncated SVD for Dimensionality Reduction
Examples
Linear System Solvers
Jacobi Method
Gauss-Seidel Method
Successive Over-Relaxation (SOR)
Conjugate Gradient
BiConjugate Gradient
Algebraic Multigrid (AMG)
Note: Requires the amg feature flag
Advanced AMG Usage
Note: Requires the amg feature flag
Matrix Decompositions
Truncated SVD for Large Matrices
Principal Component Analysis (PCA) Example
Use Cases
🔬 Scientific Computing
Finite element analysis
Computational fluid dynamics
Structural analysis
Physics simulations
Partial differential equations (PDEs) - AMG excels at discretized PDEs
🤖 Machine Learning & Data Science
Large-scale linear regression
Principal component analysis (PCA)
Recommendation systems
Natural language processing (LSA/LSI)
Image processing and computer vision
📈 Numerical Analysis
Solving partial differential equations
Optimization problems
Signal processing
Graph algorithms
Multigrid methods - AMG for hierarchical problem solving
Performance
This library is optimized for:
Large sparse matrices (>10,000 dimensions)
Memory efficiency - Minimal overhead beyond input data
Numerical stability - Robust algorithms with proven convergence
Parallel computation - Multi-threaded operations where beneficial
AMG Performance Characteristics
Optimal complexity - O(n) for many PDE problems
Scalable - Maintains efficiency as problem size increases
Memory efficient - Hierarchical structure reduces memory requirements
Grid-independent convergence - Performance doesn't degrade with mesh refinement
Algorithm Selection Guide
Documentation
See API Documentation - Complete API reference
Contributing
We welcome contributions! Please see our contributing guidelines for details on:
Bug reports and feature requests
Code contributions and pull requests
Documentation improvements
Performance optimizations
Roadmap
[-] Preconditioned iterative methods [-] Additional matrix decompositions (QR, LU) [-] GPU acceleration support [-] Distributed computing capabilities
License
Licensed under either of:
Apache License, Version 2.0
MIT License
at your option.
Related Crates
nalgebra - Dense linear algebra
nalgebra-sparse - Sparse matrix formats
Metadata
9 months ago
2024 edition
MIT
1.7K SLoC
28.6 KiB
pkg:cargo/nalgebra-sparse-linalg@0.1.10 
Install
Run the following Cargo command in your project directory:
cargo add nalgebra-sparse-linalg
Or add the following line to your Cargo.toml:
nalgebra-sparse-linalg = "0.1.10"
Documentation
docs.rs/nalgebra-sparse-linalg/0.1.10
Browse source
docs.rs/crate/nalgebra-sparse-linalg/0.1.10/source
Owners
 DimitriTimoz 🦀
Report crate
Stats Overview
5,210 Downloads all time
11 Versions published
Downloads over the last 90 days
Display as
Stacked
Stacked
Unstacked
Rust
rust-lang.org
Rust Foundation
The crates.io team
Get Help
The Cargo Book
Support
System Status
Report a bug
Policies
Usage Policy
Security
Privacy Policy
Code of Conduct
Data Access
Social
rust-lang/crates.io
#t-crates-io
@cratesiostatus