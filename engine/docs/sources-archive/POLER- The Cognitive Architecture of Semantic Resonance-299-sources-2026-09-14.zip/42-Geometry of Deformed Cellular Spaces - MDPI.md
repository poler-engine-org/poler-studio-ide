> Source: https://www.mdpi.com/2227-7390/14/11/1824

Geometry of Deformed Cellular Spaces
Loading web-font Gyre-Pagella/Normal/Regular
Next Article in Journal
Joint Optimization of UAV Communication and Time-Constrained Pickup Missions
Previous Article in Journal
Neuroadaptive Learning of Output-Constrained Magnetic Drive Transmission Systems with Disturbance Compensation
Journals
Active Journals Find a Journal Journal Proposal Proceedings Series
[
Topics
](https://www.mdpi.com/topics)
Information
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
Open Access Policy Institutional Open Access Program Special Issues Guidelines Editorial Process Research and Publication Ethics Article Processing Charges Awards Testimonials
[
Author Services
](https://www.mdpi.com/authors/english)
Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
About
Overview Contact Careers News Press Blog
Sign In / Sign Up
Notice
You can make submissions to other journals here.
clear
Notice
You are accessing a machine-readable page. In order to be human-readable, please install an RSS reader.
Continue Cancel
clear
All articles published by MDPI are made immediately available worldwide under an open access license. No special permission is required to reuse all or part of the article published by MDPI, including figures and tables. For articles published under an open access Creative Common CC BY license, any part of the article may be reused without permission provided that the original article is clearly cited. For more information, please refer to https://www.mdpi.com/openaccess.
Feature papers represent the most advanced research with significant potential for high impact in the field. A Feature Paper should be a substantial original Article that involves several techniques or approaches, provides an outlook for future research directions and describes possible research applications.
Feature papers are submitted upon individual invitation or recommendation by the scientific editors and must receive positive feedback from the reviewers.
Editor's Choice articles are based on recommendations by the scientific editors of MDPI journals from around the world. Editors select a small number of articles recently published in the journal that they believe will be particularly interesting to readers, or important in the respective research area. The aim is to provide a snapshot of some of the most exciting work published in the various research areas of the journal.
Original Submission Date Received: .
You seem to have javascript disabled. Please note that many of the page functionalities won't work as expected without javascript enabled. 
clear zoom_out_map search menu 
Journals
Active Journals
Find a Journal
Journal Proposal
Proceedings Series
Topics
Information
For Authors
For Reviewers
For Editors
For Librarians
For Publishers
For Societies
For Conference Organizers
Open Access Policy
Institutional Open Access Program
Special Issues Guidelines
Editorial Process
Research and Publication Ethics
Article Processing Charges
Awards
Testimonials
Author Services
Initiatives
Sciforum
MDPI Books
Preprints.org
Scilit
SciProfiles
Encyclopedia
JAMS
Proceedings Series
About
Overview
Contact
Careers
News
Press
Blog
Sign In / Sign Up Submit
Search for Articles:
Title / Keyword
Author / Affiliation / Email
Journal
All Journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica (AMH)
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine (ARM)
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation (ASI)
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing (BDCC)
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C (Journal of Carbon Research)
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies (Clean Technol.)
Climate
Clinical and Translational Neuroscience (CTN)
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation (CMD)
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction (CMTR)
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology (CIMB)
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation (DHI)
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates (DDC)
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications (ESA)
Eng
Engineering Proceedings
Entropic and Disordered Matter (EDM)
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal (EBJ)
European Journal of Investigation in Health, Psychology and Education (EJIHPE)
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional (Fractal Fract)
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums (FCLAM)
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease (GUCDD)
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences (IJCS)
International Journal of Environmental Medicine (IJEM)
International Journal of Environmental Research and Public Health (IJERPH)
International Journal of Financial Studies (IJFS)
International Journal of Medical Devices (IJMD)
International Journal of Molecular Sciences (IJMS)
International Journal of Neonatal Screening (IJNS)
International Journal of Orofacial Myology and Myofunctional Therapy (IJOM)
International Journal of Plant Biology (IJPB)
International Journal of Topology
International Journal of Translational Medicine (IJTM)
International Journal of Turbomachinery, Propulsion and Power (IJTPP)
International Medical Education (IME)
Inventions
IoT
ISPRS International Journal of Geo-Information (IJGI)
J
Journal of Aesthetic Medicine (J. Aesthetic Med.)
Journal of Ageing and Longevity (JAL)
Journal of CardioRenal Medicine (JCRM)
Journal of Cardiovascular Development and Disease (JCDD)
Journal of Clinical & Translational Ophthalmology (JCTO)
Journal of Clinical Medicine (JCM)
Journal of Composites Science (J. Compos. Sci.)
Journal of Cybersecurity and Privacy (JCP)
Journal of Dementia and Alzheimer's Disease (JDAD)
Journal of Developmental Biology (JDB)
Journal of Experimental and Theoretical Analyses (JETA)
Journal of Eye Movement Research (JEMR)
Journal of Functional Biomaterials (JFB)
Journal of Functional Morphology and Kinesiology (JFMK)
Journal of Fungi (JoF)
Journal of Genome Biotechnology and Genetics (JGBG)
Journal of Gerontology and Geriatrics (JGG)
Journal of Imaging (J. Imaging)
Journal of Innovation
Journal of Intelligence (J. Intell.)
Journal of Interdisciplinary Research Applied to Medicine (JDReAM)
Journal of Low Power Electronics and Applications (JLPEA)
Journal of Manufacturing and Materials Processing (JMMP)
Journal of Marine Science and Engineering (JMSE)
Journal of Market Access & Health Policy (JMAHP)
Journal of Mind and Medical Sciences (JMMS)
Journal of Molecular Pathology (JMP)
Journal of Nanotheranostics (JNT)
Journal of Nuclear Engineering (JNE)
Journal of Otorhinolaryngology, Hearing and Balance Medicine (JOHBM)
Journal of Parks
Journal of Personalized Medicine (JPM)
Journal of Pharmaceutical and BioTech Industry (JPBI)
Journal of Phytomedicine
Journal of Respiration (JoR)
Journal of Risk and Financial Management (JRFM)
Journal of Sensor and Actuator Networks (JSAN)
Journal of Superintelligence
Journal of the American Podiatric Medical Association (JAPMA)
Journal of the Oman Medical Association (JOMA)
Journal of Theoretical and Applied Electronic Commerce Research (JTAER)
Journal of Vascular Diseases (JVD)
Journal of Xenobiotics (JoX)
Journal of Zoological and Botanical Gardens (JZBG)
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction (MAKE)
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications (MCA)
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols (MPs)
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction (MTI)
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA (ncRNA)
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care (PHC)
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science (QuBS)
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics (RSEE)
Religions
Remote Sensing
Reports
Reproductive Medicine (Reprod. Med.)
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine (RJPM)
Ruminants
Safety
Sci
Scientia Pharmaceutica (Sci. Pharm.)
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal (SIUJ)
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy (SANPP)
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease (TropicalMed)
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal (WEVJ)
Youth
Zoonotic Diseases
Mathematics
Article Type
All Article Types
Article
Review
Communication
Editorial
Abstract
Book Review
Brief Communication
Brief Report
Case Report
Clinicopathological Challenge
Comment
Commentary
Concept Paper
Conference Report
Correction
Creative
Data Descriptor
Discussion
Entry
Essay
Expression of Concern
Extended Abstract
Field Guide
Giants in Urology
Guidelines
Hypothesis
Interesting Images
Letter
New Book Received
Obituary
Opinion
Patent Summary
Perspective
Proceeding Paper
Project Report
Protocol
Registered Report
Reply
Retraction
Short Note
Study Protocol
Systematic Review
Technical Note
Tutorial
Urology around the World
Viewpoint
All Article Types Search
Advanced Search
Section
All Sections
A: Algebra and Logic
B: Geometry and Topology
C: Mathematical Analysis
C1: Difference and Differential Equations
C2: Dynamical Systems
C3: Real Analysis
C4: Complex Analysis
D: Statistics and Operational Research
D1: Probability and Statistics
D2: Operations Research and Fuzzy Decision Making
E: Applied Mathematics
E1: Mathematics and Computer Science
E2: Control Theory and Mechanics
E3: Mathematical Biology
E4: Mathematical Physics
E5: Financial Mathematics
E6: Functional Interpolation
General
All Sections
Special Issue
All Special Issues
Mathematics: 10th Anniversary
Advance in Mathematical Methods for Space Dynamics and Spacecraft Systems Engineering
Advance in Modeling, Cooperative Control, and Decision-Making Method for the Collective Large-Scale Intelligent Systems
Advanced Applications with Mathematical Modeling in Operations and Supply Chain Management
Advanced Mathematical Methods in Intelligent Multimedia: Security and Applications, 2nd Edition
Advanced Mathematical Methods in Theoretical Physics
Advanced Mathematical Methods: Theory and Applications
Advanced Methods of Polynomial Ideal Computation
Advancements in Mathematical Modeling and Numerical Simulation for Civil Engineering Applications
Advances in Algebraic Structures: Representation Theory and Lie Groups
Advances in Behavioral Decision Analytics and Informatics
Advances in Convex Analysis and Inequalities
Advances in Differential and Difference Equations with Applications
Advances in Differential and Difference Equations with Applications 2019
Advances in Elliptic Equations and Their Applications
Advances in Machine Learning Applied to Intelligent Systems and Data Analytics, 2nd Edition
Advances in Mathematical Analysis with Applications
Advances in Mathematical Inequalities and Applications
Advances in Mathematical Methods for Economy and Sustainable Development Goals
Advances in Nonlinear Spectral Theory
Advances in Probability and Statistics: Emerging Trends and Real-World Applications
Advances in Proportional-Integral-Derivative-Based Control of Dynamic Systems: Theory and Applications
Advances in singularities throughout Mathematics: Algebra, Topology, Geometry, Analysis, Number Theory, Combinatorics and Cryptography
Advances in Study of Quantum Groups
Advances on Complex Analysis
Advances on Complex Analysis, 2nd Edition
AI-Augmented Software Engineering
Algebraic and Geometric Topology
Application of Artificial Intelligence and Control Theory
Application of Optimization in Production, Logistics, Inventory, Supply Chain Management and Block Chain
Applications of Algebra, Geometry, and Optimization to Control Theory, 2nd Edition
Applications of Modern Mathematical Methods in Geosciences
Applied Algebraic Methods in Cryptography
Applied Analysis of Ordinary Differential Equations 2018
Applied and Computational Statistics
Applied Cryptography and Information Security with Application
Applied Functional Analysis and Applications
Applied Functional Analysis and Its Applications
Applied Mathematics and Mechanics
Applied Mathematics and Mechanics 2017
Artificial Intelligence in Education
Bayesian Predictive Inference and Related Asymptotics—Festschrift for Eugenio Regazzini's 75th Birthday
Beyond Quantum Physics, and Computation
Bioinformatics and Computational Biology
Biologically Inspired Computing, 2nd Edition
Challenges in STEM Education
Chaos and Randomness of Discrete Dynamical Systems: Their Use in Applied Science
Cognitive, Behavioral and Affective Variables Involved in Mathematics Education: Learning and Competence Development
Combinatorial and Algebraic Structures in Words
Complex and Contact Manifolds II
Computational Methods and Application in Machine Learning
Computational Methods and Application in Machine Learning, 2nd Edition
Computational Methods in Analysis and Applications
Computational Methods in Analysis and Applications,
3rd Edition
Computational Multiscale Methods on Nanotechnology
Computational Spectroscopy
Computer Algebra in Scientific Computing
Control and Optimal Control Theory of Possibly Degenerate Differential Equations
Current Trends on Monomial and Binomial Ideals
Data Driven Decision-Making Under Uncertainty (D3U), 2nd Edition
Data Science Education: Recent Advances and Future Challenges
Data-Driven Artificial Intelligence and Optimization for Real-World Applications
Data-Driven or AI-Driven Optimization Algorithms and Their Applications
Decision Making and Its Applications
Decomposability of Tensors
Designing Tasks within Dynamic and Interactive Mathematics Learning Environments
Development of Multiphase Computational Fluid Dynamics
Difference Equations and Discrete Dynamical Systems: Theory and Applications
Differential Geometry
Differential Geometry of Special Mappings
Differential-Algebraic Equations: Stability, Control and Applications
Digital Transformation of Mathematics Education
Discrete Optimization: Theory, Algorithms, and Applications
Evolutionary Algorithms in Intelligent Systems
Evolutionary Computation
Examples and Counterexamples in Mathematical Sciences
Feature Papers in Functional Analysis and Applications
Fixed Point Theorems and Applications
Fixed Point Theory
Fractional Calculus in Natural and Social Sciences
Fractional Calculus: Theory and Applications
Fractional Differential and Difference Equations
Fractional Integrals and Derivatives: “True” versus “False” II
Fractional Order Systems
Fuzzy Mathematics
General Algebraic Structures 2020
Geometry of Numbers
Geometry, Representation Theory and Number Theory: Recent Applications in Physics
Harmonic Analysis
Highlights of Research in the Didactics of Mathematics: The Insider's Perspective
Homological and Homotopical Algebra and Category Theory
Human-Computer Interaction: New Horizons
Inequalities
Inequalities III
Information Security and Cloud Computing
Information Theory Applied in Scientific Computing
Intelligent Detection and Application
International Perspectives for Technology Applications in Mathematics Education
Iterative Methods for Solving Nonlinear Equations and Systems
Lie Theory and Its Applications
Machine Learning in Manufacturing: Digital Twins, Optimization and Control
Making AI Materially Better: Mathematics for Contemporary AI Needs
Mathematic Control and Artificial Intelligence
Mathematical Analysis and Analytic Number Theory 2019
Mathematical Analysis and Analytic Number Theory 2020
Mathematical Analysis and Boundary Value Problems II
Mathematical and Computational Intelligence Techniques in Decision Making Processes
Mathematical and Computational Methods for Image Processing and Pattern Recognition
Mathematical and Computational Modelling in Empirical and Applied Science
Mathematical Application of Heterogeneous Knowledge for Sustainable Planning Decisions
Mathematical Economics and Its Applications
Mathematical Finance
Mathematical Game Theory
Mathematical Inequalities with Applications
Mathematical Logic and Its Applications 2020
Mathematical Method and Application of Machine Learning
Mathematical Methods and Models in Epidemiology, 2nd Edition
Mathematical Methods and Models in Robust Nonlinear Control
Mathematical Methods and Models in Software Engineering
Mathematical Methods and Models in Software Engineering, 2nd Edition
Mathematical Methods in Network Security
Mathematical Methods on Intelligent Decision Support Systems
Mathematical Modelling and Control Strategies for System Biotechnology
Mathematical Optimization & Evolutionary Computing
Mathematical physics
Mathematical Physics and Quantum Information
Mathematical Prediction Models Applied to Health Management
Mathematical Sociology
Mathematical Strategy Theory
Mathematical Theories and Models in Environmental Science
Mathematics and Applications
Mathematics and Applications, 2nd Edition
Mathematics and Computer Science-Driven Innovations in Web3
Mathematics of Quantum Uncertainty
Mathematics on Automation Control Systems
Mathematics on Partial Differential Equations
Microlocal and Time-Frequency Analysis
Modern Finite Element Methods
Multi-Criteria Decision Making Methods and Their Applications
Multiple Criteria Decision Making
New Advance of Data Driven Optimization and AI—in Honor of Prof.Dr. Kai-Tai Fang
New Advances in Mathematical Analysis and Functional Analysis
New Advances in Stability Research of Nonlinear Systems: From Asymptotic Stability to Predefined-Time Stability
New Directions on Model Predictive Control
New Insights in Algebra, Discrete Mathematics and Number Theory II
New Paradigms and Trends in Quantitative Ecology
New Progress in General Topology and Its Applications
New Trends in Applications of Orthogonal Polynomials and Special Functions
New Trends in Complex Analysis Researches
New Trends in Computational Methods and Stochastic Modelling in Scientific Machine Learning
New Trends in Function Spaces and Partial Differential Equations: Theory and Applications to Physical Processes
Nonlinear Analysis Using Fuzzy Mathematics
Nonlinear Functional Analysis and Its Applications
Numerical Analysis and Computational Science
Numerical Linear Algebra with Applications
Numerical Methods
Numerical Methods for Partial Differential Equations
Numerical Optimization and Applications
Operators of Fractional Calculus and Their Applications
Optimal Control and Management of Infectious Diseases
Optimization for Decision Making
Optimization Methods in Engineering Mathematics
Optimization Theory, Method and Application
Optimization Theory, Variational Methods for Applied Mathematics
Optimization with Engineering Applications: Heuristics, Meta-Heuristics and Hyper-Heuristics
Probability, Statistics & Symmetry, 2nd edition
Progress in Mathematical Ecology
Quantitative Methods for Social Sciences
Quantitative Methods for Social Sciences, 2nd Edition
Recent Advances in Fixed Point Theory and Its Applications
Recent Advances in Fractional Calculus and Its Applications
Recent Advances in Functional Analysis and Matrix Theory
Recent Advances in Game and Decision Theory: Structures, Models, Applications and Software Implementation
Recent Advances in STEM Education
Recent Advances in the Theory, Numerical Analysis, and Applications of Fractional Calculus
Recent Developments in the Theory and Applications of Fractional Calculus
Recent Developments in Theoretical and Applied Mathematics
Recent Developments in Wavelet Transforms and Their Applications
Recent Developments of Function Spaces and Their Applications II
Recent Trends on Orthogonal Polynomials: Approximation Theory and Applications
Reviews in Mathematics and Applications
Selected Papers from the Innovative STEM Education
Selected Papers from the International Symposium on Computer, Consumer and Control (IS3C2020)
Set-Valued Analysis II
Set-Valued Analysis, 3rd Edition
Special Functions and Applications
Special Functions with Applications
Stability Analysis for Hybrid Systems
Stability Problems
State-of-the-Art Mathematical Applications in Asia-Pacific Area
State-of-the-Art Mathematical Applications in Europe
Statistical Methods in Economics
Statistical Simulation and Computation II
Stochastic Processes with Applications
Stochastic Processes: Theory and Applications
Theoretical Methods and Applications of the Large Language Models
Theoretical Modeling and Computational Aspects on Sustainability: Financial and Socio-Economic Implications
Theory and Application of Algebraic Combinatorics, 2nd Edition
Time and Time Dependence in Quantum Mechanics
Topological Modeling
Uncertainty Quantification Techniques in Statistics, Machine Learning and FinTech
Using Artificial Neural Networks to Address Complex Problems
All Special Issues
Volume 14
Issue 11
Number
Page
Logical Operator Operator
AND
OR
Search Text
Search Type
All fields
Title
Abstract
Keywords
Authors
Affiliations
Doi
Full Text
References
add_circle_outline
remove_circle_outline Search
Journals
Mathematics
Volume 14
Issue 11
10.3390/math14111824
Submit to this Journal Review for this Journal Propose a Special Issue
► ▼ Article Menu
Article Menu
Academic Editors Viktor Abramov Alvaro Anton-Sancho
Recommended Articles
Related Info Link
Google Scholar
More by Authors Links
on DOAJ
Barak, S.
Salman, G.
on Google Scholar
Barak, S.
Salman, G.
on PubMed
Barak, S.
Salman, G.
Article Views 275
Table of Contents
Abstract
Introduction
Intrinsic Metric from Counts and Geodesics
Metric–Measure Interface and Hypotheses
Excess Radius δ r and the Small-Circle Law
Unified Curvature Estimator from Counts
Local Versus Global Curvature; Density Interpretation and Interface with Smooth Geometry
Curvature Tensor from Directional Slices
Scalar Curvature from Counts Alone
Conclusions
Author Contributions
Funding
Institutional Review Board Statement
Informed Consent Statement
Data Availability Statement
Acknowledgments
Conflicts of Interest
Appendix A. Baseline Counts and Calibrations
Appendix B. Examples on Voronoi Complexes
Appendix C. Worked Toy: Conformal Bump via Density
Appendix D. Proof of the Measured GH Limit (Theorem 2)
References 
Altmetric share Share announcement Help format_quote Cite question_answer Discuss in SciProfiles
Need Help?
Support
Find support for a specific problem in the support section of our website.
Get Support
Feedback
Please let us know what you think of our products and services.
Give Feedback
Information
Visit our dedicated information section to learn more about MDPI.
Get Information
clear
JSmol Viewer
clear
first_page
Download PDF
settings
Order Article Reprints
Font Type:
Arial Georgia Verdana
Font Size:
Aa Aa Aa
Line Spacing:
  
Column Width:
  
Background:
Open Access Article
Geometry of Deformed Cellular Spaces
by
Shlomo Barak 
Shlomo Barak
SciProfiles Scilit Preprints.org Google Scholar 1 
and
George Salman 
George Salman
SciProfiles Scilit Preprints.org Google Scholar 2,*   1
Taga Innovations, 18 Yosef Karo St., Tel Aviv 6701422, Israel 2
School of Computer Science and Engineering, Edmond J. Safra Campus, The Hebrew University of Jerusalem, Jerusalem 9190401, Israel *
Author to whom correspondence should be addressed.
Mathematics 2026, 14(11), 1824; https://doi.org/10.3390/math14111824
Submission received: 30 April 2026 / Revised: 17 May 2026 / Accepted: 21 May 2026 / Published: 24 May 2026
(This article belongs to the Special Issue Differential Geometry and Its Applications in Theoretical Physics)
Download keyboard_arrow_down
Download PDF
Download PDF with Cover
Download XML
Download Epub
Browse Figures   
Versions Notes
Article Views
Citations -
Abstract
We develop an operational, measurement-first framework for the geometry of locally finite cell complexes, in which length is defined as a count of face crossings, and curvature is read off from the discrepancy between a measured radius and a radius reconstructed from boundary, area, or volume counts using the same yardstick. We prove that the count metric is geodesic on every locally finite complex, and we introduce a unified small-ball/small-sphere curvature estimator that is valid in dimensions two through four with a single closed-form expression. By comparison with the standard small-ball volume expansion of a smooth conformal metric g = e 2 u g 0 , we establish a quantitative identification theorem with explicit rate O ( a / r + r ) , which optimizes to O ( a ) at r ≍ a . We extend the construction to directional (sectional) estimators via Fermi tubes around geodesic two-slices, assemble the curvature operator, Ricci tensor, and scalar curvature in three dimensions, and prove a measured Gromov–Hausdorff convergence theorem for the rescaled count metric. All hypotheses are verified explicitly on Voronoi complexes of conformal metrics. Throughout, we are explicit that the discrete construction is interpreted via, and its asymptotic validity is established by comparison with, the smooth Riemannian theory; the contribution is the unified counts-only protocol with rigorous convergence rates, not a reformulation of curvature itself.
Keywords:
cellular complex; count metric; excess radius; small-ball curvature estimator; conformal metric; scalar curvature; sectional curvature; Ricci tensor; Gromov–Hausdorff convergence; discrete differential geometry; graph curvature; Ollivier–Ricci curvature; Forman–Ricci curvature
MSC:
53C20; 53C23; 53A30; 51F99; 52C99; 05C12
1. Introduction
This paper develops an operational, measurement-first framework for extracting geometric information from locally finite cell complexes, building on the cellular-medium program initiated in earlier work [ 1]. The viewpoint is intentionally minimal: distances are defined as shortest cell-crossing counts, curvature is inferred from the mismatch between a measured radius and a radius reconstructed from boundary, area, or volume counts, and no cell shape, angle, embedding, coordinate system, or smooth differential structure is presupposed in the definition of the count metric, the count quantities, or the resulting estimators. We are explicit, however, that the quantitative identification of these discrete estimators with classical Riemannian curvatures, and the convergence rates we prove, do use standard smooth-Riemannian apparatus throughout; the framework should be read as a counts-only protocol whose continuum-limit identification with Riemannian curvature is established by comparison with the smooth theory, not as a self-contained reformulation of curvature.
Relation to existing discrete-curvature frameworks.
Several well-developed frameworks already extract curvature-like invariants from discrete data, and we wish to position the present paper clearly with respect to them. Ollivier–Ricci curvature [ 2] assigns curvature to edges of a metric measure space via transport distances between balls and has been extensively studied on graphs and Markov chains, including recent extensions and applications in network analysis [ 3, 4, 5]. Forman–Ricci curvature [ 6] provides a combinatorial Bochner identity on cell complexes by associating curvature contributions to weighted adjacencies. The synthetic curvature–dimension theory of Sturm and Lott–Villani [ 7, 8] formulates Ricci lower bounds on metric measure spaces via optimal transport, leading to the modern RCD framework. Other approaches include resistance-based discrete curvatures [ 9] and the long-standing Regge calculus tradition [ 10] in which curvature lives on lower-dimensional skeleta.
More broadly, our construction sits within metric and coarse geometry [ 11, 12, 13]. The count metric d h on a cell complex is a discrete analog of the kinds of integer-valued metrics studied in coarse geometry, and the measured Gromov–Hausdorff framework we use to identify the discrete construction with its smooth conformal relaxation is the standard tool of metric-measure geometry. The use of small-ball/sphere volume asymptotics to read curvature is classical: it underlies, for instance, the Bishop–Gromov volume-comparison inequality and the small-ball expansion in Riemannian geometry [ 14], which is precisely the asymptotic we exploit and on which our identification rates rely. We therefore view the small-ball volume-growth method itself as classical input, not as a contribution.
The present work differs from these approaches in three respects. First, it works directly with the integer-valued count metric on a cell complex without introducing transport plans, edge weights, vertex measures, or Markov-chain structure; the only inputs are face adjacency and counting. Second, it defines curvature through a single small-ball comparison between the measured radius and the radius reconstructed from boundary/area/volume counts using the same yardstick, and packages this into one closed-form estimator valid uniformly in dimensions two through four. Third, it establishes an explicit identification rate O ( a / r + r ) with the standard Riemannian scalar curvature of a smooth conformal relaxation g = e 2 u g 0 , optimizing to O ( a ) , and verifies the underlying hypotheses on Voronoi complexes.
Acknowledgment of standard tools.
The small-ball volume expansion of a Riemannian manifold, the conformal scalar-curvature formula in dimension m, the use of geodesic polar coordinates and Jacobi-field expansions in two dimensions, the use of Fermi coordinates around totally geodesic surfaces, and the reconstruction of the curvature operator from sectional curvatures via polarization are all classical and well known [ 11, 14, 15]. We use these tools throughout to interpret the discrete construction and to prove its asymptotic validity. The mathematical contribution of this paper is therefore not the introduction of new differential-geometric identities, but the formulation of a unified, dimension-uniform, counts-only protocol on locally finite cell complexes, together with quantitative error bounds and a measured Gromov–Hausdorff convergence theorem connecting the discrete construction to the smooth setting. We also connect to the broader tradition of discrete differential geometry [ 16].
The framework is not autonomous from the smooth continuum.
We make this explicit because the counts-only style of the construction can suggest otherwise. The discrete metric d h , the count quantities, the reconstructed radii, and the estimators of Section 5, Section 6, Section 7 and Section 8 can be defined and computed without invoking any smooth structure: the only inputs are face adjacency and counting. But every theorem in this paper that identifies these counts-only quantities with a Riemannian curvature, or quantifies the rate at which they do so, is proved by comparison with the smooth conformal metric g = e 2 u g 0 : by hypothesis (H1)–(H5), we couple a count-ball to a g-ball, and then we invoke the classical small-ball volume expansion (Theorems 4, 5 and 8), Jacobi-field expansions in geodesic polar coordinates (Theorem 3), or Fermi coordinates around a geodesic two-slice (Lemma 2). The discrete construction therefore does not function as a fully independent geometric framework; it inherits the interpretation and asymptotic validity of curvature from smooth Riemannian geometry. We view this dependence as appropriate and intentional for the present paper: the constants in our error bounds depend on smooth quantities ( ∥ u ∥ C 2 ( K ) ), the conformal class g = e 2 u g 0 is taken from smooth geometry, and the limit object in the measured Gromov–Hausdorff theorem is a smooth Riemannian manifold. Any reader expecting an intrinsically discrete formulation of curvature in the sense that all proofs go through without smooth analysis will not find one here.
Setting and standing assumptions.
Throughout, “space” is modeled as a locally finite cell complex with face adjacency and an elastic interpretation: cell sizes may vary locally and shapes need not be specified. Intrinsic measurements use rulers and clocks that co-deform with the medium; ambient labels may be attached for visualization but play no role in intrinsic constructions. We adopt the following:
(A1) Cellularity: space is a locally finite cell complex with face adjacency.
(A2) Micro-agnosticism: cell sizes may vary and shapes need not be specified; neither angles nor an embedding are assumed.
(A3) Intrinsic yardstick: one cell crossing defines one unit of length, and distances are shortest crossing counts evaluated by a single, consistent protocol within any experiment.
(A4) Locality: all statements and guarantees are local; global unboundedness is a background assumption, not a technical requirement.
(A5) Local near-uniformity of cell scale: for every compact region K there is a constant Λ K ≥ 1 such that whenever two cells c , c ′ in K share a face,
Λ K − 1 ≤ ℓ ( c ′ ) ℓ ( c ) ≤ Λ K .
Equivalently, the intrinsic yardstick ℓ does not exhibit arbitrarily large discontinuous jumps between adjacent cells. This implies that in a sufficiently small neighborhood, one can assign a well-defined local step length ℓ i ( x ) in each principal direction (and, in isotropic patches, a single ℓ ( x ) = e u ( x ) ), which is what we use in Section 2.1 and in the conformal relaxation g = e 2 u g 0 .
Summary of formal results.
On any locally finite complex, the cell-crossing (count) metric admits length minimizers, so the intrinsic space is geodesic (Theorem 1). In two dimensions, the excess-radius diagnostic recovers Gaussian curvature via the small-circle law (Theorem 3). For m ∈ { 2 , 3 , 4 } we introduce a unified small-ball/sphere estimator
K h ( m ) ( r ) = 6 m r m − ( r c ( m ) ) m r m + 2
(Equation ( 32)); it has the correct sign of contraction/dilation, vanishes on uniform lattices, and—after Euclidean calibration—identifies the smooth scalar curvature to leading order (Theorem 5). By restricting counts to thin Fermi tubes around geodesic two-slices, we obtain directional estimators that converge to K g ( e i ∧ e j ) and assemble Ric and R (Theorems 6 and 7). Under mild regularity and mesh assumptions, the curvature estimator obeys the rate | R ^ m ( x ; r ) − R g ( x ) | ≤ C 1 a / r + C 2 r (Theorem 4), and the metric–measure spaces ( X a , a d h , ν a ) converge in the measured Gromov–Hausdorff sense to ( Ω , d g , vol g ) (Theorem 2). All hypotheses are verified on Voronoi complexes of conformal metrics (Proposition A1).
Scope.
The development is mathematical. The conformal class g = e 2 u g 0 used in the smooth relaxation is the canonical setting that an isotropic cell-density field induces; the paper does not claim that arbitrary Riemannian metrics arise this way, nor does it address Lorentzian signature or dynamics. Connections to physical models—in particular to gravitational settings—are deferred to separate work and are not part of the claims established here.
Heuristic versus rigorous content.
Throughout this paper, we distinguish two kinds of content. Rigorous statements are labeled as Theorem, Lemma, Proposition, or Corollary, and come with explicit hypotheses (chiefly (H1)–(H5)), explicit constants, and proofs. Operational descriptions and interpretive remarks appear in unlabeled paragraphs (often headed by short keywords such as “Operational protocol”, “Granularity, averaging, and gauge”, “Interpretation via line/space density”, or “Key point”) and are intended as motivation, not as formal claims. In particular, where a paragraph describes a procedure in physical language (rulers, clocks, yardsticks) or a calibration choice (baseline lattice constants α 1 , β m ), the formal content is captured in the corresponding numbered equation or in the hypotheses of the theorem statement that follows; the surrounding prose serves only to explain why the formal statement takes the form it does.
Roadmap.
Section 2 develops the intrinsic count metric and proves geodesic existence. Section 3 states the metric–measure hypotheses and the measured GH framework. Section 4 formalizes the excess radius and the small-circle law. Section 5 introduces the unified small-ball/sphere estimators, verifies flatness on uniform lattices, and gives quantitative rates. Section 6 explains the conformal relaxation g = e 2 u g 0 and the R-normalized identification, and makes explicit the dependence on classical smooth tools. Section 7 constructs directional estimators and assembles Ric and R. Section 8 expresses curvature directly in terms of the density field and provides an explicit algorithm (Algorithm 1). Appendices collect calibrations, Voronoi verifications, a worked toy example, and the proof of the measured GH limit.
Algorithm 1: Counts-only scalar curvature at a base cell.
Require: Locally finite cell complex X with face adjacency; base cell x; count radius r ∈ N ; ambient dimension m ∈ { 2 , 3 , 4 } ; Euclidean calibration β m = ω m .
Ensure: Counts-only scalar curvature estimate K h , R ( m ) ( x ; r ) at x.
1:
Initialize BFS frontier F 0 ← { x } , visited set V ← { x } , ball counter N ← 1 .
2:
for k = 1 to r do
3:
F k ← ⌀
4:
for each cell c ∈ F k − 1 do
5:
for each face-adjacent neighbor c ′ of c do
6:
if c ′ ∉ V then
7:
add c ′ to V
8:
add c ′ to F k
9:
N ← N + 1
10:
end if
11:
end for
12:
end for
13:
end for
14:
| B d h ( x , r ) | ← N
15:
ρ a ( x ; r ) ← | B d h ( x , r ) | β m r m
16:
K h , R ( m ) ( x ; r ) ← 6 ( m + 2 ) ( 1 − ρ a ( x ; r ) ) r 2
17:
return K h , R ( m ) ( x ; r )
2. Intrinsic Metric from Counts and Geodesics
Operational protocol (single yardstick).
All intrinsic measurements in this paper follow the same protocol:
(i)
Fix a base cell c 0 .
(ii)
Declare one face crossing to have a unit cost. This fixes a yardstick and a gauge for the experiment.
(iii)
For an integer r ≥ 0 , define the intrinsic (count) ball and sphere
B ( r ) : = { c : d h ( c 0 , c ) ≤ r } , S ( r ) : = { c : d h ( c 0 , c ) = r }
We call r the count radius: it is literally the minimum number of face crossings from c 0 .
(iv)
Record the raw counts on B ( r ) and S ( r ) :
C h ( r ) : = | S ( r ) | , A h ( r ) : = | B ( r ) |
and in higher dimensions, their 3D/4D analogs V h ( r ) , W h ( r ) .
(v)
Use undeformed baseline growth constants ( α 1 , β 2 , β 3 , β 4 ) for the chosen adjacency ( Appendix A) to reconstruct a radius r c from these counts, e.g.,
r c ( 1 ) = C h ( r ) α 1 , r c ( 2 ) = A h ( r ) β 2 , …
and compare r and r c .
No angles, embeddings, shapes, or coordinates are entered in steps (i)–(v); they involve only cell adjacency and counting with one fixed cost per crossing.
We work on a locally finite cellular complex with face adjacency. A (piecewise) path is a sequence of adjacent cells
γ : c 0 → c 1 → … → c k
and its length is the number of face crossings, L ( γ ) = k . The intrinsic (count) distance between cells u , v is
d h ( u , v ) : = min γ : u ⇝ v L ( γ )
(1)
namely, the fewest crossings needed to connect u to v. This defines an integer-valued metric.
Theorem 1
(Geodesics on locally finite complexes). If the adjacency graph is locally finite, then for every u , v there exists a path attaining d h ( u , v ) . In particular, ( Cells , d h ) is a geodesic metric space.
Proof.
Let G = ( C , E ) be the adjacency graph of cells; local finiteness means each c ∈ C has finite degree. Fix u ∈ C . Consider the breadth-first search (BFS) layers L 0 = { u } and, inductively,
L k + 1 : = { w ∈ C ∖ ( L 0 ∪ … ∪ L k ) : ∃ z ∈ L k with ( z , w ) ∈ E }
By local finiteness, each L k is finite. If v ∈ L L for the first time at level L, then any path from u to v has length at least L, while the BFS tree provides a path u → … → v of length exactly L. Hence, d h ( u , v ) = L and the minimizer exists. Therefore, ( C , d h ) is geodesic. □
Notation and measurement primitives.
Throughout, fix a base cell c 0 and write,
B ( r ) : = { c : d h ( c 0 , c ) ≤ r } , S ( r ) : = { c : d h ( c 0 , c ) = r }
so S ( r ) is precisely the r th BFS layer and B ( r ) the union of layers 0 , … , r . In 2D, we record the boundary and area counts C h ( r ) : = | S ( r ) | and A h ( r ) : = | B ( r ) | ; in 3D and 4D we analogously use the volume and hypervolume counts, V h ( r ) and W h ( r ) .
Calibrations (one yardstick).
To convert counts back into a “reconstructed” radius with the same instrument, we compare against the undeformed growth of the chosen adjacency and permanently fix the constants
C 0 ( r ) ∼ α 1 r , A 0 ( r ) ∼ β 2 r 2 , V 0 ( r ) ∼ β 3 r 3 , W 0 ( r ) ∼ β 4 r 4
These are not assumptions but reference values for the baseline lattice (exact examples are recorded in Appendix A); they serve only to define r c from C h , A h , V h , W h in the same gauge as the measured radius.
Gauge. A global rescaling of the yardstick (e.g., measuring each crossing as k units) rescales all lengths by k but leaves dimensionless statements (signs of diagnostics, ratios, normalized densities) invariant. All comparisons below are made in a fixed gauge per experiment.
2.1. Operational Line Element and Emergent Metric
The metric is not postulated a priori; it is manufactured from how many cells are crossed. Fix a point x and restrict attention to a small neighborhood in which adjacent cells are (to first order) the same size, so that motion can be decomposed into locally orthogonal principal directions i = 1 , 2 , 3 , … with a well-defined local linear size in each direction.
Let d n i be the (integer) number of cell crossings along direction i and let ℓ i ( x ) be the local linear size of a single cell in that direction at x. Equivalently, the local line density in that direction is ι i ( x ) : = 1 / ℓ i ( x ) . The physical length increment assigned to such an infinitesimal move is then
d s 2 = ∑ i ℓ i ( x ) d n i 2 = ∑ i d n i ι i ( x ) 2
(2)
In the local principal frame the metric tensor is diagonal,
g i j ( x ) = diag ℓ 1 ( x ) 2 , ℓ 2 ( x ) 2 , ℓ 3 ( x ) 2 , … , d s 2 = g i j ( x ) d n i d n j
(3)
In an isotropic patch, the neighborhood is not only locally uniform in size but also directionally uniform, so all local cell lengths agree:
ℓ 1 ( x ) = ℓ 2 ( x ) = … = ℓ ( x )
(4)
Then, ( 2) simplifies to
d s = ℓ ( x ) d n 1 2 + d n 2 2 + d n 3 2 + … , g i j ( x ) = ℓ ( x ) 2 δ i j
(5)
Writing ℓ ( x ) = e u ( x ) shows that this matches the conformal ansatz
g = e 2 u ( x ) g 0
(6)
used in the smooth relaxation. The function u ( x ) (equivalently ι ( x ) = e u ( x ) ) is the local yardstick: the linear size of one cell in an almost-uniform neighborhood. Thus, the smooth metric g here is not an additional assumption; it is the continuum encoding of the operational rule “count d n i cells along direction i and multiply by that cell's local linear size.”
3. Metric–Measure Interface and Hypotheses
Assume an open set Ω ⊂ R m and u ∈ C 2 ( Ω ) . Let g = e 2 u g 0 with g 0 Euclidean. For each mesh scale a > 0 , let X a be a locally finite cell complex with face adjacency and cell set C a . A realization Φ a : C a → Ω assigns, e.g., cell barycenters. Define d a ∗ : = a d h and, for a cell-measure μ a (counting or weighted), set
ν a : = a m μ a , if μ a counts cells , μ a , if μ a is already volumetric .
Let ω m be the Euclidean unit-ball volume and fix the calibration β m : = ω m .
Hypotheses on K ⋐ Ω (constants independent of a).
Hypothesis 1.
Local finiteness/degree bound: each cell has ≤ D face-adjacent neighbors.
Hypothesis 2.
Shape regularity/mesh size: diam g 0 ( c ) ∈ [ c 0 a , C 0 a ] whenever Φ a ( c ) ∈ K .
Hypothesis 3.
Coarse realization: Φ a ( C a ∩ K ) is C a -dense, and c ∼ c ′ ⇒ d g 0 ( Φ a ( c ) , Φ a ( c ′ ) ) ≤ C a .
Hypothesis 4.
Ball inclusions: for all x with Φ a ( x ) ∈ K and admissible r,
B g ( Φ a ( x ) , a r − c 1 a ) ⊆ Φ a ( B d h ( x , r ) ) ⊆ B g ( Φ a ( x ) , a r + c 2 a ) .
Hypothesis 5.
Weight comparability: there is Λ ≥ 1 with Λ − 1 a m e m u ( Φ a ( c ) ) ≤ μ a ( { c } ) ≤ Λ a m e m u ( Φ a ( c ) ) for Φ a ( c ) ∈ K .
Remark on uniformity of constants.
All constants C , C 1 , C 2 , c 1 , c 2 appearing in the hypotheses and the theorems below depend only on K, the shape/degree parameters in (H1) and (H2), the weight constant Λ in (H5), and the C 2 -bounds of u on K. In particular, they are independent of a and of the choice of x ∈ X a with Φ a ( x ) ∈ K , and of the admissible radius r. This uniformity is what permits us to take limits a → 0 , r → 0 , a / r → 0 in the statements that follow.
Lemma 1
(Cellwise quadrature against g-volume). Assume (H1)–(H5) on K ⋐ Ω . For every x ∈ X a with Φ a ( x ) ∈ K and every admissible r ≥ 1 , write E s : = Φ a ( B d h ( x , s ) ) where s = ⌊ r / a ⌋ and ρ : = a s ≍ a r . Then,
| ν a B d h ( x , s ) − Vol g ( E s ) | ≤ C K a ρ m − 1 ,
(7)
where C K depends only on Λ (H5), the shape/degree constants (H1) and (H2), and ∥ u ∥ C 1 ( K ) .
Proof.
Decompose
ν a ( B d h ( x , s ) ) − Vol g ( E s ) = ∑ c ∈ B d h ( x , s ) ν a ( { c } ) − Vol g ( Φ a ( c ) - cell ) ︸ = : T 1 ( interior mismatch ) + T 2 ( boundary ) ,
(8)
where the boundary term T 2 accounts for cells c that are not fully inside E s in the Riemannian sense (i.e., whose realization straddles ∂ E s ).
Interior term. By (H5), for each cell c with Φ a ( c ) ∈ K ,
Λ − 1 a m e m u ( Φ a ( c ) ) ≤ ν a ( { c } ) ≤ Λ a m e m u ( Φ a ( c ) ) .
(9)
The Riemannian volume of cell c is Vol g ( c ) = ∫ c e m u ( y ) d y 0 , and by (H2), diam g 0 ( c ) ≤ C 0 a , so | u ( y ) − u ( Φ a ( c ) ) | ≤ ∥ ∇ u ∥ C 0 ( K )
· C 0 a for y ∈ c . Expanding e m u ( y ) = e m u ( Φ a ( c ) ) 1 + O ( a ) uniformly on K and integrating,
Vol g ( c ) = e m u ( Φ a ( c ) ) Vol g 0 ( c ) 1 + O ( a ) ,
(10)
with implicit constant depending only on C 0 and ∥ ∇ u ∥ C 0 ( K ) . Combining ( 9) and ( 10) and using (H2) ( Vol g 0 ( c ) ≍ a m ) gives, per cell,
| ν a ( { c } ) − Vol g ( c ) | ≤ C K ( 1 ) a m + 1 ,
(11)
where C K ( 1 ) depends only on Λ , C 0 , ∥ ∇ u ∥ C 0 ( K ) .
By (H1) and (H4), the number of cells in B d h ( x , s ) is bounded by C K ( 2 ) ρ m / a m (volume packing of cells of diameter ≍ a inside a g-ball of radius ≍ ρ ). Summing the per-cell bound ( 11),
| T 1 | ≤ C K ( 2 ) ρ m a m
· C K ( 1 ) a m + 1 = C K ( 3 ) a ρ m .
(12)
Boundary term. The boundary ∂ E s has g-surface area bounded by C K ( 4 ) ρ m − 1 (the g-area of a g-sphere of radius ρ , controlled uniformly on K by Bishop–Gromov-type bounds, see §9 in [ 14]). Each cell crossed by ∂ E s has g 0 -diameter ≤ C 0 a and g-volume ≤ C K ( 5 ) a m . The number of such crossing cells is therefore at most C K ( 6 ) ρ m − 1 / a m − 1 . Each contributes at most C K ( 5 ) a m in absolute value (whether counted on the discrete or continuous side):
| T 2 | ≤ C K ( 6 ) ρ m − 1 a m − 1
· C K ( 5 ) a m = C K ( 7 ) a ρ m − 1 .
(13)
In the admissible regime ρ ≤ 1 (i.e., r bounded), the surface term T 2 dominates: a ρ m ≤ ρ
· a ρ m − 1 ≤ C K a ρ m − 1 . Combining,
| T 1 + T 2 | ≤ C K a ρ m − 1 ,
(14)
which is ( 7). □
Theorem 2
(Measured GH limit). Under (H1)–(H5), as a → 0 ,
X a , d a ∗ , ν a → mGH Ω , d g , vol g
4. Excess Radius δ r and the Small-Circle Law
With the intrinsic metric d h and balls/spheres B ( r ) , S ( r ) from Section 2, all measurements use a single yardstick: one face crossing has unit cost, and the same instrument is used to convert counts back into a reconstructed radius. See Figure 1 for an illustration. 
Figure 1. Operational meaning of δ r at base cell c 0 . The two radii are labeled with explicit braces to distinguish them: the solid outer disk has radius r (the measured count radius), and the dashed inner disk has radius r c (the radius reconstructed from the boundary count using the same yardstick). When the boundary at radius r carries more cells than the undeformed baseline (contraction), the reconstructed radius r c is smaller than r, giving δ r > 0 . The reverse case gives δ r < 0 .
At an intrinsic radius r ∈ N around a base cell c 0 , form the reconstructed radii with the undeformed calibrations ( α 1 , β 2 , β 3 , β 4 ) :
r c ( 1 ) = C h ( r ) α 1 , r c ( 2 ) = A h ( r ) β 2 , r c ( 3 ) = V h ( r ) β 3 3 , …
The excess radius compares two realizations of “radius” obtained with the same instrument:
δ r ( r ) : = r − r c ( r )
(15)
where r is the kinematic radius (graph distance) and r c is the combinatorial radius (counts inverted to radius). The sign encodes geometry: if, at fixed r, the perimeter carries more boundary cells than the undeformed baseline, then r c < r and δ r > 0 ( contraction); if it carries fewer, then r c > r and δ r < 0 ( dilation).
The classical small-circle law in two dimensions identifies the Gaussian curvature at the base point as the order- r 3 obstruction to reconciling the two radii:
K ( x ) = lim r ↓ 0 6 δ r ( r ) r 3 ⟺ δ r ( r ) = K ( x ) 6 r 3 + o ( r 3 )
(16)
No angles, embeddings, or cell shapes are invoked. In the smooth relaxation with line-density ι = e u and conformal metric g = e 2 u g 0 , the classical identity K g = − e − 2 u Δ u yields
δ r ( r ) = − e − 2 u ( x ) 6 Δ u ( x ) r 3 + o ( r 3 ) ,
so, a local increase in the yardstick (convex u) produces δ r > 0 and a positive signal in ( 16), consistent with the discrete reading.
Theorem 3
(Small-circle law in 2D). Let g be C 2 near x. Then, as r ↓ 0 :
Perimeter gauge.
L g ∂ B g ( x , r ) = 2 π r 1 − K ( x ) 6 r 2 + o ( r 2 ) , r c , per : = L g 2 π , δ r per = r − r c , per = K ( x ) 6 r 3 + o ( r 3 ) .
(17)
Area gauge.
Area g B g ( x , r ) = π r 2 1 − K ( x ) 12 r 2 + o ( r 2 ) , r c , area : = Area g π , δ r area = K ( x ) 24 r 3 + o ( r 3 )
(18)
In a conformal chart g = e 2 u g 0 , these become
δ r per = − e − 2 u 6 Δ u r 3 + o ( r 3 ) , δ r area = − e − 2 u 24 Δ u r 3 + o ( r 3 ) .
(19)
Proof.
The proof uses standard tools of two-dimensional Riemannian geometry: geodesic polar coordinates and Jacobi-field expansions [ 14, 15]. Let exp x be the exponential map and use geodesic polar coordinates ( r , θ ) . The metric takes the form
g = d r 2 + J ( r , θ ) 2 d θ 2
(20)
where J is the length of the orthogonal Jacobi field along the unit-speed geodesic γ θ from x. It satisfies
∂ r r J ( r , θ ) + K ( γ θ ( r ) ) J ( r , θ ) = 0 ,
(21)
J ( 0 , θ ) = 0 , ∂ r J ( 0 , θ ) = 1
(22)
Since K is continuous near x,
K ( γ θ ( r ) ) = K ( x ) + O ( r ) ( r ↓ 0 ) uniformly in θ .
(23)
A Taylor expansion of ( 21) and ( 22) at r = 0 , with the leading term J ( r , θ ) = r from the initial conditions and the order- r 3 correction obtained by substituting back, gives
J ( r , θ ) = r − K ( x ) 6 r 3 + o ( r 3 ) ( r ↓ 0 )
(24)
uniformly in θ .
Perimeter.
From ( 20) and ( 24),
L g ∂ B g ( x , r ) = ∫ 0 2 π J ( r , θ ) d θ = 2 π r 1 − K ( x ) 6 r 2 + o ( r 2 )
(25)
Hence,
r c , per : = L g 2 π = r 1 − K ( x ) 6 r 2 + o ( r 2 )
(26)
and therefore
δ r per = r − r c , per = K ( x ) 6 r 3 + o ( r 3 )
(27)
Area.
Using d A = J ( r , θ ) d r d θ and ( 24),
Area g B g ( x , r ) = ∫ 0 r ∫ 0 2 π J ( ρ , θ ) d θ d ρ = π r 2 1 − K ( x ) 12 r 2 + o ( r 2 )
(28)
Thus,
r c , area : = Area g π = r 1 − K ( x ) 24 r 2 + o ( r 2 )
(29)
and
δ r area = r − r c , area = K ( x ) 24 r 3 + o ( r 3 )
(30)
Conformal chart.
In a conformal chart g = e 2 u g 0 in 2D, the classical identity gives
K ( x ) = − e − 2 u ( x ) Δ u ( x ) .
(31)
Substituting ( 31) into ( 27)–( 30) yields the conformal-chart formulas claimed. □
Granularity, averaging, and gauge.
Pointwise fields in a granular setting are understood as local averages over intrinsic balls: 〈 f 〉 r ( x ) = | B x ( r ) | − 1 ∑ c ∈ B x ( r ) f ( c ) . A global rescaling of the yardstick (counts ↦ k
· counts, or ι ↦ c ι ) rescales lengths but leaves dimensionless quantities (signs of δ r , ratios r / r c , normalized densities) invariant. Continuous small-ball formulas are asymptotic and accurate when r is large relative to cell size and the lattice is near-uniform at that scale; where exact counts are available, they take precedence.
5. Unified Curvature Estimator from Counts
The unified curvature estimator, which connects excess-radius counts with curvature, is formulated below. Its geometric interpretation is illustrated in Figure 2. 
Figure 2. Excess radius δ r = r − r c at count-radius r. Each panel shows a wedge of the intrinsic ball; dots mark outward boundary points per cell. The dashed circle is the measured radius r; the reconstructed r c is inferred from the boundary/area count using the same yardstick. ( a) Positive curvature regime; ( b) negative curvature regime.
Let m ∈ { 1 , 2 , 3 , 4 } denote the ambient dimension and let r c ( m ) be the reconstructed radius obtained from the corresponding count with the same yardstick as in Section 2. Define the unified small-ball/sphere estimator
K h ( m ) ( r ) : = 6 m r m − r c ( m ) m r m + 2 , r ∈ N
(32)
Leading connection to the excess radius.
Write w = r − r c ( m ) . A binomial expansion gives
K h ( m ) ( r ) = 6 w r 3 + O w 2 r 4
(33)
In particular, in 2D and for symmetric neighborhoods, K h ( 2 ) ( r ) = 3 r 2 − ( r c ( 2 ) ) 2 / r 4 ≈ 6 δ r / r 3 , recovering the small-circle law of Section 4.
Sign and geometry.
At fixed r, if the boundary carries more cells than the undeformed baseline, then r c < r , w > 0 , and K h ( m ) ( r ) > 0 (contraction). If it carries fewer, then w < 0 and K h ( m ) ( r ) < 0 (dilation). Figure 2 illustrates both regimes.
Flatness on undeformed lattices.
On standard uniform lattices (square/hex in 2D; cubic/hypercubic in higher m) one has r c ( 1 ) = r exactly, hence K h ( 1 ) ≡ 0 , and for m ≥ 2
K h ( m ) ( r ) = O ( r − 3 ) ⟶ 0 ( r → ∞ )
so the estimator correctly registers flatness (exact formulas are tabulated in Appendix A).
Interpretation via line/space density.
In the smooth relaxation, a line-density (yardstick) field ι = e u induces the conformal metric g = e 2 u g 0 . The classical conformal scalar-curvature formula in dimension m [ 14] gives
R g = e − 2 u − 2 ( m − 1 ) Δ u − ( m − 1 ) ( m − 2 ) | ∇ u | 2
(34)
so the scalar curvature at a point depends on the local value of the density (via e − 2 u ) and its first/second derivatives. For near-uniform shapes, the space density satisfies ρ ∝ ι m (in 3D: ρ ∝ ι 3 ), hence u = 1 m log ρ .
Matching small-ball laws yields; for radii r, they are small compared with the curvature scale,
K h , R ( m ) ( r ) : = 6 ( m + 2 ) r m − r c ( m ) m r m + 2 = R g ( x ) + O ( r )
(35)
so to the leading order, the unified count estimate is equal to the smoothed scalar curvature signal calculated from the density field. Table 1 summarizes the small-ball coefficients and normalizations used in dimensions m = 2 , 3 , 4 .
Table 1. Small-ball coefficients and normalizations. 
Equations ( 32)–( 35) put the operational picture on precise footing: curvature around a point is the small-ball mismatch between measured and reconstructed radii with a single yardstick, and in the conformal relaxation, it is governed by the local density and its derivatives through ( 34).
Admissible radii.
Fix a compact K ⋐ Ω and set
r max ( x , a ) : = dist g ( Φ a ( x ) , ∂ K ) − C a a +
A radius r ∈ N is admissible if 1 ≤ r ≤ r max ( x , a ) and is in the regime r → 0 , a / r → 0 used for taking continuum limits.
Theorem 4
(Small-ball identification with rates). Assume (H1)–(H5) on K ⋐ Ω . Then, there exist C 1 , C 2 > 0 , depending only on bounds for u , ∇ u , ∇ 2 u on K and on the shape/degree constants in (H1) and (H2) (and not on a, on x, or on the admissible r), such that for all x with Φ a ( x ) ∈ K and all admissible r,
| R ^ m ( x ; r ) − R g ( Φ a ( x ) ) | ≤ C 1 a r + C 2 r
In particular, if a → 0 , r → 0 , and a / r → 0 , then R ^ m ( x ; r ) → R g ( Φ a ( x ) ) uniformly on K.
Proof.
The argument combines (i) the classical small-ball volume expansion for a smooth Riemannian metric, (ii) the inclusion (H4) of count-balls between g-balls of comparable radius, (iii) the weight comparability (H5) which makes ν a approximate g-volume cellwise, and (iv) a Taylor expansion of t ↦ t m around t = ρ : = a r . We provide the steps explicitly.
Fix x with Φ a ( x ) ∈ K and write y : = Φ a ( x ) . Let
s : = r / a , ρ : = a s , | r − ρ | ≤ a
(36)
Set E s : = Φ a B d h ( x , s ) . By (H4) there are c 1 , c 2 > 0 (uniform on K) such that
B g y , ρ − c 1 a ⊂ E s ⊂ B g y , ρ + c 2 a
(37)
Volume expansion and quadrature error.
On K the classical small-ball expansion is uniform [ 14]:
Vol g B g ( y , t ) = α m t m − α m R g ( y ) 6 ( m + 2 ) t m + 2 + O K ( t m + 3 ) ,
(38)
with α m = ω m . Lemma 1 (cellwise quadrature against g-volume) gives
| ν a B d h ( x , s ) − Vol g ( E s ) | ≤ C K a ρ m − 1
(39)
with C K depending only on the shape/degree constants and the C 1 -bounds of u on K.
Bounding the reconstructed radius.
Define
r c ( m ) m : = ν a B d h ( x , s ) α m
(40)
Combining ( 37)–( 39) and a first-order Taylor expansion of t ↦ t m and t ↦ t m + 2 around t = ρ gives
r c ( m ) m = ρ m − R g ( y ) 6 ( m + 2 ) ρ m + 2 + E 1 ( ρ , a ) , | E 1 ( ρ , a ) | ≤ C K a ρ m − 1 + ρ m + 3 .
(41)
Moreover, by ( 36),
r m = ρ m + O a r m − 1 , r m + 2 = ρ m + 2 + O a r m + 1 ,
(42)
with constants uniform on K.
Main difference bound.
Combining ( 41) and ( 42),
Δ : = r m − r c ( m ) m − R g ( y ) 6 ( m + 2 ) r m + 2 , | Δ | ≤ C K a r m − 1 + r m + 3 .
(43)
Conclusion.
Recall
R ^ m ( x ; r ) : = 6 ( m + 2 ) r m − r c ( m ) m r m + 2
(44)
By ( 43),
| R ^ m ( x ; r ) − R g ( y ) | = 6 ( m + 2 ) | Δ | r m + 2 ≤ C 1 a r + C 2 r
(45)
with C 1 , C 2 uniform on K as stated. In particular, if a → 0 , r → 0 , a / r → 0 , the right-hand side vanishes uniformly on K. □
Remark on the joint scaling regime a → 0 , r → 0 , a / r → 0 .
The rate of Theorem 4 is the sum of two competing terms:
| R ^ m ( x ; r ) − R g ( y ) | ≤ C 1 a r ︸ mesh - vs - radius error + C 2 r ︸ small - ball remainder .
(46)
The first term shrinks when one takes larger balls relative to the mesh ( r / a → ∞ ): a count-ball of g-radius ρ = a r probes the metric on a region that contains many cells and is therefore well-approximated by smooth Riemannian volume. The second term shrinks when one takes smaller balls in absolute terms ( r → 0 ): the small-ball expansion of Vol g has higher-order remainder O ( r m + 3 ) , which after division by r m + 2 becomes O ( r ) . These two requirements pull in opposite directions: small absolute r versus large r / a . Both can be satisfied simultaneously if and only if a → 0 along with r, in the regime a / r → 0 .
Minimizing the right-hand side of ( 46) over r for fixed a gives
d d r C 1 a r + C 2 r = − C 1 a r 2 + C 2 = 0 ⟺ r ∗ ( a ) = C 1 a C 2 ≍ a ,
(47)
and the minimum value is
min r C 1 a r + C 2 r = 2 C 1 C 2 a = O a .
(48)
This is the source of the O ( a ) rate at r ≍ a used throughout the paper. The same trade-off and optimization apply to the directional and counts-only estimators (Corollary 1 and Theorem 8), with the same conclusion.
6. Local Versus Global Curvature; Density Interpretation and Interface with Smooth Geometry
Curvature in the present framework is extracted locally, from measurements made with a single yardstick on a small intrinsic ball. The diagnostic depends only on data inside that ball and is insensitive to remote structure. One may also work in a global gauge in which the background is Euclidean while allowing localized deviations near sources. The purpose of this section is to formalize this local/global split, its reading through a smooth conformal relaxation, and—explicitly—the extent to which the discrete construction depends on standard tools from smooth Riemannian geometry.
What the discrete framework provides on its own.
The intrinsic count metric d h , the intrinsic balls B d h ( x , r ) , the count quantities | B d h ( x , r ) | and C h ( r ) , the reconstructed radii r c ( m ) , the unified estimator K h ( m ) , and the directional estimators of Section 7 are all defined and computable from cellular data alone—that is, their definition and numerical evaluation require no embedding, no coordinates, no derivatives, and no smooth structure. The geodesic existence statement (Theorem 1) is genuinely combinatorial, as is the sign/flatness behavior of the estimators on uniform lattices. It does not follow, however, that the discrete framework is autonomous from the smooth continuum: every assertion that these counts-only quantities converge to a Riemannian curvature, or that the convergence has a particular rate, is established by comparison with the smooth theory, as the next paragraph makes explicit.
Where smooth-geometric tools are used.
By contrast, every quantitative statement that identifies the discrete signal with a Riemannian curvature is established by comparing the count construction to the small-ball expansion of a smooth conformal metric g = e 2 u g 0 . Concretely, the proof of the small-circle law (Theorem 3) uses geodesic polar coordinates and Jacobi-field expansions; the rate theorem (Theorem 4) uses the classical small-ball volume expansion together with the ball-inclusion hypothesis (H4); the slice-coupling result (Lemma 2) uses Fermi coordinates around totally geodesic two-slices; and the reconstruction of Ric and R from sectional curvatures uses standard polarization identities. The framework should therefore be understood as a counts-only operational protocol whose asymptotic identification with smooth Riemannian curvature is proved by comparison with the smooth theory, not as an autonomous reformulation of curvature that bypasses Riemannian geometry. This dependence is intentional, and the explicit constants in the error bounds keep track of it.
Why “counts-only” is still meaningful.
Despite this dependence on smooth tools for proof, the unified estimator K h , R ( m ) is computable from cell counts alone, with no measurement of any smooth quantity. The smooth-geometric apparatus enters only when one wishes to assert that the discrete number computed converges to the scalar curvature R g of the conformal relaxation, and at what rate. This is closely analogous to how, in numerical analysis, an entirely discrete scheme is verified to approximate a continuum object via continuum-side analysis.
Gauge-safety.
A tempting alternative is to “just count cells” globally and infer curvature from growth rates. This is gauge-unsafe: a uniform rescaling of the yardstick (or a homogeneous change in cell density) alters all counts by the same factor and can mimic or mask curvature. The excess-radius protocol avoids this by comparing two radii measured with the same instrument: only their mismatch is geometrically meaningful, and the ratio r / r c is invariant under uniform rescaling.
Conformal relaxation and density field.
We interpret the discrete, measurement-first layer through a smooth conformal relaxation. A positive line-density (yardstick) field ι = e u on an open set U ⊂ R m induces
g : = e 2 u g 0 , R g = e − 2 u − 2 ( m − 1 ) Δ u − ( m − 1 ) ( m − 2 ) | ∇ u | 2
(49)
The conformal scalar-curvature identity ( 49) is classical [ 14].
R-normalized estimator.
For m ∈ { 2 , 3 , 4 } let r ∈ N be the intrinsic count-radius about x and let r c ( m ) ( x ; r ) be the radius reconstructed from the m-dimensional count. Fix baseline constants β m = α m = ω m (Euclidean unit-ball volume). Define
K h , R ( m ) ( x ; r ) : = 6 ( m + 2 ) r m − r c ( m ) ( x ; r ) m r m + 2
(50)
Theorem 5
(Local identification with scalar curvature). Assume g = e 2 u g 0 with u ∈ C 2 near x. Using ( 50) with β m = α m ,
lim r ↓ 0 K h , R ( m ) ( x ; r ) = R g ( x )
Proof.
The classical small-ball expansion [ 14] gives
Vol g B g ( x , r ) = α m r m − α m R g ( x ) 6 ( m + 2 ) r m + 2 + O ( r m + 3 )
By definition r c ( m ) m = Vol g ( B g ( x , r ) ) / β m . With β m = α m ,
r m − r c ( m ) m = R g ( x ) 6 ( m + 2 ) r m + 2 + O ( r m + 3 )
Multiplying by 6 ( m + 2 ) / r m + 2 gives K h , R ( m ) ( x ; r ) = R g ( x ) + O ( r ) . □
Proposition 1
(Discrete-to-smooth consistency). Let the cell complex be locally finite with mesh size a > 0 and bounded aspect ratio. Suppose the count ball B h ( x , r ) is sandwiched by metric balls B g ( x , r − c 1 a ) ⊆ B h ( x , r ) ⊆ B g ( x , r + c 2 a ) and that the per-cell g-volume is uniformly bounded above/below. Then, as a → 0 with r → 0 and a / r → 0 ,
K h , R ( m ) ( x ; r ) = R g ( x ) + o ( 1 ) .
Proof.
The inclusions give Vol g ( B g ( x , r − c 1 a ) ) ≤ | B h ( x , r ) | ≤ Vol g ( B g ( x , r + c 2 a ) ) . Apply the small-ball expansion at r ± c a with β m = α m and expand r m − r c ( m ) m ; scaling by 6 ( m + 2 ) / r m + 2 yields an error O ( a / r ) + O ( r ) , which vanishes under a / r → 0 and r → 0 . □
Proposition 2
(Local/global split in a fixed gauge). If u is constant on an open region Ω, then for every compact K ⋐ Ω ,
lim r ↓ 0 sup x ∈ K | K h , R ( m ) ( x ; r ) | = 0 .
Proof.
If u is constant, then R g ≡ 0 . Apply Theorem 5 uniformly on K. □
Manifold status and the discrete layer.
The measurement layer is a locally finite cell complex with the count metric d h ; no manifold hypothesis is required to define lengths, balls/spheres, or the estimators. When cells are quasi-uniform and links are manifold-like, ( B R , d h ) and ( B R , d g ) are ( 1 + δ ) quasi-isometric with δ = O ( osc B R u ) ; under refinement and controlled oscillation they converge in the Gromov–Hausdorff sense. Curvature is thus extracted operationally from counts and read geometrically via g = e 2 u g 0 .
Ricci and scalar curvature (compatibility).
Because the relaxation is the standard metric g = e 2 u g 0 , the Ricci tensor Ric ( g ) and scalar R g are exactly those of Riemannian geometry. Section 5 provides count-based local scalars consistent with R g by Theorem 5; directional slicing ( Section 7) assembles a discrete Ricci-like object that converges to Ric ( g ) under the same regularity/refinement assumptions.
7. Curvature Tensor from Directional Slices
Curvature in our framework is fundamentally a 2D diagnostic: on any small intrinsic disk one runs the same “one yardstick, two radii” protocol from Section 4 to obtain a curvature signal. In higher dimensions, sectional, Ricci, and scalar curvature are assembled from those 2D signals via standard polarization identities. This section makes that precise. The geometric configuration is illustrated in Figure 3. 
Figure 3. Fermi tube of thickness 2 τ a around the geodesic slice Σ i j . We sum per-cell weights inside this tube, divide by the tube thickness 2 τ a to recover an effective slice area, and obtain R c , i j ( x ; r , a ) and—via Equation ( 53)—the counts-only estimator K ^ i j , a ( x ; r ) for the sectional curvature K g ( e i ∧ e j ) .
Setup.
We continue under (H1)–(H5) on a compact set K ⋐ Ω . The discrete space at mesh size a > 0 is a locally finite cell complex X a with the intrinsic count metric d h ; Φ a : X a → Ω is the realization into ( Ω , g ) , g = e 2 u g 0 . The per-cell measure ν a is comparable to g-volume (H5). All measurements still use a single yardstick.
At a base cell x ∈ X a (with Φ a ( x ) ∈ K ), pick a g-orthonormal frame { e 1 , … , e m } in T Φ a ( x ) Ω . For each i < j , let Σ i j be the totally geodesic 2D surface through Φ a ( x ) tangent to span ( e i , e j ) . We restrict counting to a thin tube around Σ i j of thickness τ a (with τ ≥ 1 a fixed constant) and define
T i j ( x ; r , a ) : = c ∈ B d h ( x , r ) : dist g ( Φ a ( c ) , Σ i j ) ≤ τ a .
(51)
Directional estimator.
Consistent with the counts-only convention of Section 5 and Section 8, we define the reconstructed slice-radius from the cell count of the tube. Let | T i j ( x ; r , a ) | denote the number of cells in the tube. Define
R c , i j ( x ; r , a ) 2 : = | T i j ( x ; r , a ) | 2 τ α 2 ,
(52)
with α 2 = π (the Euclidean 2D unit-ball area). On an undeformed lattice with the standard adjacency, | T i j ( x ; r , a ) | ≈ 2 τ α 2 r 2 , so R c , i j ≈ r in the flat case (the count radius itself), in direct analogy with the flat-case reconstruction r c ( m ) ≈ r of Section 5, Section 6, Section 7 and Section 8. Then, define the directional curvature estimator
K ^ i j , a ( x ; r ) : = 12 r 2 − R c , i j ( x ; r , a ) 2 r 4 .
(53)
The prefactor 12 matches the small-disk expansion of Area g on a 2-surface (Theorem 3).
Lemma 2
(Slice-coupling). Under (H1)–(H5) on K, for any fixed τ > 0 , there is a constant C = C ( K , τ , shape / degree bounds o , ∥ u ∥ C 2 ( K ) ) , independent of a, x, and admissible r, such that
| r 2 − R c , i j ( x ; r , a ) 2 − 1 12 K g ( e i ∧ e j ) ( Φ a ( x ) ) r 4 | ≤ C a r 3 + r 5
(54)
Proof.
The proof uses Fermi coordinates around the totally geodesic surface Σ i j [ 14], the classical small-disk area expansion on Σ i j , and the quadrature estimate ( 39) adapted to the tube region. The four steps are as follows.
Step 1: Fermi coordinates and tube Jacobian. In Fermi coordinates ( p , t ) around the totally geodesic 2-surface Σ i j near Φ a ( x ) , with p ∈ Σ i j and t the signed geodesic normal distance, the metric takes the form §5 in [ 14]
g = g Σ i j ( p ) + d t 2 + G ( p , t ) , G ( p , 0 ) ≡ 0 ,
(55)
where the correction G vanishes at t = 0 . The key fact used in this paper is that Σ i j is totally geodesic: its second fundamental form II Σ i j vanishes identically. By the Gauss equation, the radial derivative of g Σ i j at t = 0 also vanishes:
∂ t g Σ i j | t = 0 = − 2 II Σ i j (
· ,
· ) = 0 ,
(56)
so the leading nontrivial term in G ( p , t ) is of order t 2 (the Riemann curvature contribution along the normal direction). Consequently, the volume Jacobian
d vol g = J ( p , t ) d A Σ i j ( p ) d t
(57)
has expansion
J ( p , t ) = 1 − 1 2 Ric g ( N , N ) ( p ) t 2 + O t 3 + t 2 ρ ,
(58)
where N is a unit normal to Σ i j at p and the implicit constant depends only on ∥ Riem g ∥ C 1 ( K ) , hence on ∥ u ∥ C 3 ( K ) . (For the present paper, we have u ∈ C 2 ; if needed, one can mollify u on a smaller compact K ′ ⋐ K to make u ∈ C ∞ with C k -bounds depending only on the original C 2 -bounds and the mollifier scale). Integration in t ∈ [ − τ a , τ a ] gives
∫ − τ a τ a J ( p , t ) d t = 2 τ a + O a 3 + O a 3 ρ ,
(59)
where the a 3 term comes from integrating t 2 over [ − τ a , τ a ] and the a 3 ρ term from the cross correction. In particular, in the admissible regime ρ ≤ 1 on K,
∫ − τ a τ a J ( p , t ) d t = 2 τ a + O a 3
(60)
uniformly in p along Σ i j at g-distance ≤ ρ from Φ a ( x ) , with implicit constants uniform on K.
Step 2: Cell count of the tube vs. geometric tube volume. Define the geometric g-tube Tube τ ( ρ ) of half-thickness τ a and in-slice radius ρ = a r . By (H1) and (H2) each cell has g-volume of order a m , so the cell count | T i j | approximates the g-volume of the tube up to the per-cell scaling factor a m : applying the count analog of Lemma 1 to the tube region,
| a m | T i j ( x ; r , a ) | − vol g Tube τ ( ρ ) | ≤ C 1 a ρ m − 1 ,
(61)
with C 1 uniform on K. (This follows by noting that each cell has g-volume in [ Λ − 1 a m , Λ a m ] and that the surface contribution at ∂ Tube τ ( ρ ) has g-area of order ρ m − 1 .)
Step 3: Factor the tube volume. Using ( 57) and ( 60),
vol g Tube τ ( ρ ) = 2 τ a Area g B Σ i j ( Φ a ( x ) , ρ ) + E tube ( ρ , a ) ,
(62)
with the explicit bound, using the O ( a 3 ) from ( 60) integrated over the in-slice disk of area O ( ρ 2 ) ,
| E tube ( ρ , a ) | ≤ C 2
· a 3
· ρ 2 = C 2 a 3 ρ 2 ,
(63)
with C 2 depending only on ∥ u ∥ C 2 ( K ) and the geometric data of Σ i j .
Combining ( 61) and ( 62), we have an explicit relation between the cell count and the smooth area of the slice disk; the error contributions from both steps combine into a single bound, dominated by the surface term, that propagates into Step 4 below.
Step 4: Extract R c , i j and compare radii. By definition ( 52), | T i j | = 2 τ α 2 ( R c , i j ) 2 . Substituting into ( 61),
2 τ α 2 a m R c , i j 2 = vol g ( Tube τ ( ρ ) ) + O ( a ρ m − 1 ) .
(64)
Using the factorization ( 62),
2 τ α 2 a m R c , i j 2 = 2 τ a Area g ( B Σ i j ( Φ a ( x ) , a r ) ) + E tube + O ( a ρ m − 1 ) .
(65)
The small-disk expansion on the totally geodesic Σ i j gives, after the conformal factorization on Σ i j (and the Euclidean calibration β m = ω m chosen in Section 5, Section 6, Section 7 and Section 8 so the discrete–smooth identification on undeformed cells is exact),
Area g B Σ i j ( Φ a ( x ) , a r ) = α 2 ( a r ) 2 − α 2 K g ( e i ∧ e j ) ( Φ a ( x ) ) 12 ( a r ) 4 + O ( a r ) 5 ,
(66)
uniformly on K. Substituting and dividing by 2 τ α 2 a m ,
R c , i j 2 = a ( a r ) 2 a m − K g ( e i ∧ e j ) 12
· a ( a r ) 4 a m + O a ( a r ) 5 a m + O a ρ m − 1 a m .
(67)
For m = 3 (the dimension of present interest for the directional reconstruction), a ( a r ) 2 / a 3 = r 2 and a ( a r ) 4 / a 3 = a 2 r 4 . To get the form claimed in ( 54) with a single dimensionless variable r, we adopt the standard m = 3 calibration in which a factor of a − 2 is absorbed into the curvature coefficient (this is the same convention by which | B d h | / β m ≈ r m in flat case for Algorithm 1, regardless of a). The result is
R c , i j 2 = r 2 − K g ( e i ∧ e j ) ( Φ a ( x ) ) 12 r 4 + O ( a r 3 + r 5 ) ,
(68)
which is ( 54). □
Corollary 1
(Directional estimator rate). Under the hypotheses of Lemma 2, there is C = C ( K , τ , shape / degree bounds , ∥ u ∥ C 2 ( K ) ) , uniform in a, x, and admissible r, such that
| K ^ i j , a ( x ; r ) − K g ( e i ∧ e j ) ( Φ a ( x ) ) | ≤ C a r + r
(69)
Choosing r ≃ a gives uniform error O ( a ) on K.
Proof.
By Lemma 2, | r 2 − R c , i j 2 − K g r 4 / 12 | ≤ C ( a r 3 + r 5 ) . Substituting into ( 53) and dividing by r 4 ,
| K ^ i j , a ( x ; r ) − K g ( e i ∧ e j ) | = 12
· | r 2 − R c , i j 2 − K g r 4 / 12 | r 4 ≤ 12 C a r + r .
Setting r ≃ a gives uniform error O ( a ) on K. □
Theorem 6
(Directional identification). Under (H1)–(H5), for any sequence of ( a , r ) with a → 0 , r → 0 , and a / r → 0 ,
lim a → 0 , r → 0 a / r → 0 K ^ i j , a ( x ; r ) = K g ( e i ∧ e j ) ( Φ a ( x ) )
(70)
Proof.
Immediate from Corollary 1. □
Reconstructing the full curvature operator, Ric , and R. Once each K g ( e i ∧ e j ) is approximated for each pair ( i , j ) , the full Riemann curvature operator and its contractions are reconstructed by the standard polarization identities of Riemannian geometry. Let R : Λ 2 T Φ a ( x ) Ω → Λ 2 T Φ a ( x ) Ω be the curvature operator of g. For any simple 2-form u ∧ v ≠ 0 ,
K g ( u ∧ v ) = 〈 R ( u ∧ v ) , u ∧ v 〉 ∥ u ∧ v ∥ 2
(71)
In m = 3 , with the orthonormal basis σ 1 = e 2 ∧ e 3 , σ 2 = e 3 ∧ e 1 , σ 3 = e 1 ∧ e 2 , the matrix M of R has diagonal entries
M 11 = K g ( e 2 ∧ e 3 ) , M 22 = K g ( e 3 ∧ e 1 ) , M 33 = K g ( e 1 ∧ e 2 ) .
(72)
The off-diagonal entries are determined by sectional curvatures via the standard polarization identity (Section 3.1 in [ 14]). Define the unnormalized quadratic form
Q ( u , v ) : = ∥ u ∧ v ∥ 2 K g ( u ∧ v ) .
(73)
Then, for any vectors u , v , w in T Φ a ( x ) Ω ,
2 R ( u , v ) v , w = Q ( u + w , v ) − Q ( u , v ) − Q ( w , v ) ,
(74)
obtained by expanding Q ( u + w , v ) = R ( u + w , v , v , u + w ) and using bilinearity. In particular, in the orthonormal frame { e 1 , e 2 , e 3 } , the off-diagonal entry M 12 is
M 12 = 〈 R ( e 2 ∧ e 3 ) , e 3 ∧ e 1 〉 = − 〈 R ( e 2 , e 3 ) e 3 , e 1 〉 ,
(75)
and applying ( 74) with u = e 2 , v = e 3 , w = e 1 ,
M 12 = − 1 2 ∥ ( e 1 + e 2 ) ∧ e 3 ∥ 2 K g ( e 1 + e 2 ) ∧ e 3 − K g ( e 2 ∧ e 3 ) − K g ( e 1 ∧ e 3 ) ,
(76)
so M 12 is a fixed linear combination of three sectional curvatures: those of the planes e 2 ∧ e 3 , e 1 ∧ e 3 , and ( e 1 + e 2 ) ∧ e 3 . The remaining off-diagonals M 13 and M 23 are obtained by the same identity with the indices cyclically permuted.
Discrete reconstruction.
Each sectional curvature appearing on the right-hand side of ( 76) (and its cyclic analogs) has an explicit counts-only estimator K ^ i j , a ( x ; r ) defined by ( 53): the directional estimator with the tube of ( 51) taken around the totally geodesic 2-surface tangent to the corresponding 2-plane. In particular, for the off-diagonal M 12 we use the directional estimator K ^ ( e 1 + e 2 ) , e 3 , a ( x ; r ) obtained by setting the in-slice frame to ( e 1 + e 2 ) / 2 , e 3 in ( 51). Replacing each smooth K g in ( 72) and ( 76) by its counts-only estimator yields the discrete matrix M ^ a ( x ; r ) .
Theorem 7
(Reconstruction of the curvature operator in 3D). Under (H1)–(H5), for any a → 0 , r → 0 with a / r → 0 ,
lim a → 0 , r → 0 a / r → 0 M ^ a ( x ; r ) = M ( Φ a ( x ) ) entrywise .
Proof.
Each entry of M ^ a ( x ; r ) is by construction a fixed linear combination (with coefficients independent of a , r , x ) of directional estimators K ^ ( ξ , η ) , a ( x ; r ) over a finite list of 2-planes ξ ∧ η . By Corollary 1 applied to each of these planes,
| K ^ ( ξ , η ) , a ( x ; r ) − K g ( ξ ∧ η ) | ≤ C a r + r ,
uniformly on K, with C independent of a , r , x . Linearly combining these bounds with the polarization coefficients of ( 76) (and its cyclic analogs) gives
| M ^ a ( x ; r ) α β − M α β ( Φ a ( x ) ) | ≤ C ′ a r + r ,
for each α , β , with C ′ depending only on the polarization coefficients (which are absolute constants) and C. As a → 0 , r → 0 , a / r → 0 , the right-hand side vanishes, giving entrywise convergence. □
Finally, Ric and R are obtained by standard contractions; in 3D for instance
Ric ( e 1 , e 1 ) = K g ( e 1 ∧ e 2 ) + K g ( e 1 ∧ e 3 ) ,
(77)
R = 2 K g ( e 1 ∧ e 2 ) + K g ( e 1 ∧ e 3 ) + K g ( e 2 ∧ e 3 ) .
(78)
The counts-only estimators
Ric ^ a ( e 1 , e 1 ; x ; r ) : = K ^ 12 , a ( x ; r ) + K ^ 13 , a ( x ; r ) , R ^ a ( x ; r ) : = 2 K ^ 12 , a ( x ; r ) + K ^ 13 , a ( x ; r ) + K ^ 23 , a ( x ; r )
(79)
then converge to Ric g and R g as a , r → 0 with a / r → 0 .
Key point. All raw inputs in K ^ i j , a , Ric ^ a , R ^ a come from counting cells in carefully chosen regions, using the same yardstick. The smooth metric g = e 2 u g 0 enters only to interpret the limit and to prove the rates.
8. Scalar Curvature from Counts Alone
Fix m ≥ 2 . Let X a be a locally finite cell complex with intrinsic (count) metric d h , one face crossing = 1 . For a base cell x and an intrinsic radius r ∈ N , write
B d h ( x , r ) : = { c : d h ( x , c ) ≤ r } , | B d h ( x , r ) | : = # B d h ( x , r )
(80)
Let β m > 0 be the m-dimensional calibration constant for the chosen baseline adjacency ( Appendix A). We define two operational quantities.
(i)
Reconstructed radius.
r c ( m ) ( x ; r ) m : = | B d h ( x , r ) | β m
(81)
(ii)
Local density.
ρ a ( x ; r ) : = | B d h ( x , r ) | β m r m = r c ( m ) ( x ; r ) m r m
(82)
Thus, ρ a ( x ; r ) = 1 on an undeformed baseline lattice, ρ a > 1 for local compression, ρ a < 1 for dilation.
Define the normalized small-ball estimator
K h , R ( m ) ( x ; r ) : = 6 ( m + 2 ) r m − r c ( m ) ( x ; r ) m r m + 2
(83)
Using ( 82),
K h , R ( m ) ( x ; r ) = 6 ( m + 2 ) 1 − ρ a ( x ; r ) r 2
(84)
Equation ( 84) is computable from counts alone, in the sense that no smooth quantity (no derivative of u, no measurement of g, no coordinate or embedding) appears on its right-hand side: for each x and scale r one (i) takes B d h ( x , r ) , (ii) counts its cells, (iii) computes ρ a from ( 82), (iv) inserts ρ a into ( 84). The assertion that the resulting number converges to R g ( Φ a ( x ) ) at rate O ( a / r + r ) is a separate statement (Theorem 8), and that statement is established by comparison with the smooth Riemannian small-ball expansion, not from counts alone.
Algorithm 1 is a literal translation of ( 84): it does a breadth-first traversal of the count-ball, counts cells, and applies the closed-form estimator. The cost is O ( | B d h ( x , r ) | ) in time and memory, dominated by the BFS. No coordinates, embeddings, angles, or derivatives are accessed.
We now state the convergence result. Let Ω ⊂ R m be open, u ∈ C 2 ( Ω ) , g = e 2 u g 0 . For each mesh scale a > 0 let X a have realization Φ a : X a → Ω and per-cell weight ν a satisfying (H1)–(H5) on K ⋐ Ω .
Theorem 8
(Counts-only scalar curvature). Let K ⋐ Ω and assume (H1)–(H5) hold on K, with β m = ω m . There exist C 1 , C 2 > 0 , depending only on the shape/degree bounds in (H1) and (H2) and ∥ u ∥ C 2 ( K ) (and not on a, x, or admissible r), such that for every x ∈ X a with Φ a ( x ) ∈ K and every admissible r,
K h , R ( m ) ( x ; r ) − R g Φ a ( x ) ≤ C 1 a r + C 2 r
(85)
In particular, if a → 0 , r → 0 , and a / r → 0 ,
K h , R ( m ) ( x ; r ) ⟶ R g Φ a ( x ) uniformly for Φ a ( x ) ∈ K .
(86)
Proof.
All steps are local on K and constants are uniform on K.
(1) Count ball vs. g-ball. By (H4),
B g Φ a ( x ) , a r − c 1 a ⊆ Φ a B d h ( x , r ) ⊆ B g Φ a ( x ) , a r + c 2 a
(87)
(2) Volume quadrature. By (H5), ν a ( { c } ) is uniformly comparable to the g-volume of cell c, so summing ν a over B d h ( x , r ) approximates Vol g ( B g ( Φ a ( x ) , ρ ) ) up to O ( a ρ m − 1 ) for ρ ≍ a r .
(3) Small-ball expansion.
Vol g B g ( y , ρ ) = ω m ρ m − ω m R g ( y ) 6 ( m + 2 ) ρ m + 2 + O ( ρ m + 3 ) , ρ ↓ 0 ,
uniformly on K. Taking ρ = a r and using ( 87) with step (2),
r c ( m ) ( x ; r ) m = r m − R g ( Φ a ( x ) ) 6 ( m + 2 ) r m + 2 + E ( x ; a , r ) , | E | ≤ C a r m − 1 + r m + 3 .
(88)
(4) Insert into the estimator and conclude. Multiplying r m − ( r c ( m ) ) m by 6 ( m + 2 ) / r m + 2 gives R g ( Φ a ( x ) ) + E ˜ , with | E ˜ | ≤ C 1 a / r + C 2 r uniformly on K. If a → 0 , r → 0 , a / r → 0 , the right-hand side of ( 85) vanishes, giving ( 86). □
In summary,
K h , R ( m ) ( x ; r ) = 6 ( m + 2 ) 1 − ρ a ( x ; r ) r 2 ⟶ R g ( Φ a ( x ) ) ,
and all inputs on the left are just counts of cells, as Algorithm 1 makes explicit.
9. Conclusions
We presented an operational, measurement-first protocol for extracting geometric information from locally finite cell complexes, in which length is a count and curvature is the coefficient in a small-ball/small-sphere mismatch. Distances are defined by shortest face-crossing counts, and this count metric is geodesic on every locally finite complex. The resulting excess-radius diagnostics are assembled into unified small-ball/small-sphere estimators that vanish on undeformed lattices, detect local contraction/dilation with the correct sign, and identify the smooth scalar curvature of a conformal relaxation in the continuum limit, with explicit error bounds.
The scalar estimator K h , R ( m ) ( x ; r ) , the directional estimators K ^ i j , a ( x ; r ) , and their Ricci/trace combinations are computable from cell counts alone—their numerical evaluation requires only face-adjacency queries and BFS traversal, with no measurement of any smooth quantity. Their identification with the Riemannian scalar, sectional, and Ricci curvatures of the conformal relaxation g = e 2 u g 0 , and the convergence rates, are established by comparison with classical Riemannian small-ball expansions, not from counts alone. The explicit pseudocode of Algorithm 1 makes the count side practical for implementation.
The smooth conformal metric g = e 2 u g 0 enters only to interpret the limiting object and to prove the error bounds. Under the mild regularity and mesh hypotheses (H1)–(H5), we obtain uniform rates O ( a / r + r ) , and in the joint limit a → 0 , r → 0 , a / r → 0 the discrete estimators converge to the Riemannian scalar curvature R g , the sectional curvatures K g ( e i ∧ e j ) , and to Ric g . All hypotheses are verified on Voronoi complexes ( Appendix B).
Several limitations are worth stating openly. First, all quantitative identifications use classical Riemannian apparatus (geodesic polar coordinates, Jacobi fields, Fermi coordinates, conformal scalar-curvature identities, polarization), and the framework should be read as a counts-only protocol whose asymptotic identification with smooth curvature is proved by comparison, not as an autonomous reformulation of curvature. Second, the smooth relaxation is taken in the conformal class g = e 2 u g 0 , which corresponds to an isotropic density field; arbitrary Riemannian metrics need not arise this way. Third, the development is purely spatial and does not treat Lorentzian signature or dynamics; questions of physical interpretation, including possible connections to gravitational settings, are out of scope here and are reserved for separate work.
The contribution is thus a unified, dimension-uniform, counts-only protocol on locally finite cell complexes, with rigorous convergence rates and a measured Gromov–Hausdorff limit identifying the discrete construction with the smooth Riemannian theory of the conformal relaxation.
Author Contributions
Conceptualization, S.B. and G.S.; methodology, S.B. and G.S.; formal analysis, S.B. and G.S.; investigation, S.B. and G.S.; writing—original draft preparation, S.B. and G.S.; writing—review and editing, S.B. and G.S. All authors have read and agreed to the published version of the manuscript.
Funding
This research received no external funding.
Institutional Review Board Statement
Not applicable.
Informed Consent Statement
Not applicable.
Data Availability Statement
No new data were created or analyzed in this study. Data sharing is not applicable to this article.
Acknowledgments
The authors thank the anonymous reviewers for their constructive comments, which improved the positioning of this work relative to existing discrete-curvature frameworks and led to several clarifications in the exposition.
Conflicts of Interest
Author Dr. Barak is affiliated with Taga Innovations. The remaining authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.
Appendix A. Baseline Counts and Calibrations
This appendix fixes notation and removes the potential ambiguity between (i) the adjacency-specific lattice calibrations used for discrete diagnostics, and (ii) the Euclidean calibration used in the R-normalized estimator.
Appendix A.1. Adjacency-Specific Baseline
For the ℓ 1 adjacency on Z m ,
| B m ( r ) | = ∑ k = 0 m 2 k m k r k , | S m ( r ) | = | B m ( r ) | − | B m ( r − 1 ) |
(A1)
with r 0 = 1 and r k = 0 for k > r . In particular:
m = 2 : | S 2 ( r ) | = 4 r , | B 2 ( r ) | = 2 r 2 + 2 r + 1 m = 3 : | B 3 ( r ) | = 4 3 r 3 + 2 r 2 + 8 3 r + 1 , | S 3 ( r ) | = 4 r 2 + 2 .
Adjacency calibrations used for discrete radius reconstruction:
α 1
□ = 4 , β 2
□ = 2 , β 3
□ = 4 3 , β 4
□ = 2 3 .
Lemma A1
(Derivation of ( A1)). For m ≥ 1 and r ∈ N , | B m ( r ) | = ∑ k = 0 m 2 k m k r k .
Proof.
An integer vector x ∈ Z m with ∥ x ∥ 1 ≤ r has exactly k nonzero coordinates ( 0 ≤ k ≤ min { m , r } ); choose them in m k ways, signs in 2 k ways, and distribute a sum ≤ r among k positive integers (i.e., compositions of an integer ≤ r into k parts, allowing 0, of which there are r k ). Sum over k. □
Appendix A.2. Euclidean Calibration
For identification with smooth R g , we normalize against the Euclidean volume α m = ω m and set β m = α m = ω m in the R-normalized estimator, so that K h , R ( m ) ( x ; r ) → R g ( x ) (Theorem 5).
Appendix B. Examples on Voronoi Complexes
Let Ω ⊂ R m be open, u ∈ C 2 ( Ω ) , and g = e 2 u g 0 . For h > 0 let P h ⊂ Ω be finite and quasi-uniform in g: there exist 0 < δ ≤ Δ < ∞ with
δ h ≤ dist g ( p , P h ∖ { p } ) ≤ sup x ∈ Ω dist g ( x , P h ) ≤ Δ h for all p ∈ P h .
(A2)
Let { V p } p ∈ P h be the Voronoi tessellation in the g-metric, X h the cell complex with face adjacency, Φ h ( V p ) : = p , and μ h ( { V p } ) = Vol g ( V p ) , ν h : = μ h .
Proposition A1
(Voronoi complexes satisfy (H1)–(H5)). Assume ( A2) and that u is C 2 with bounded derivatives on K ⋐ Ω . There exists h 0 = h 0 K , δ , Δ , ∥ u ∥ C 2 ( K ) > 0 such that for every h ∈ ( 0 , h 0 ] the cell complex X h satisfies (H1)–(H5) on K with mesh parameter a : = h , and all constants in those hypotheses depend only on K, δ, Δ, and the C 2 -bounds of u on K (and not on h).
Proof.
Fix K. From ( A2), g-balls of radius ≍ h are inscribed in and circumscribed around each Voronoi cell intersecting K; bi-Lipschitz equivalence of g and g 0 on K gives all five hypotheses with constants depending only on K , δ , Δ , and C 2 -bounds of u on K. The details—degree bound (H1) from outer-radius bound; shape regularity (H2) from inner/outer inclusions; coarse realization (H3) from neighbor g-distance bound; ball inclusions (H4) from estimating d h in terms of d g via the inradius/outradius; weight comparability (H5) from Vol g ( V p ) ≍ h m e m u ( p ) —are standard. □
Corollary A1
(Directional and scalar convergence on Voronoi). Under Proposition A1,
K ^ i j , h ( x ; r ) − K g ( e i ∧ e j ) ( x ) ≤ C h r + r R ^ m ( x ; r ) − R g ( Φ h ( x ) ) ≤ C h r + r
and r ≃ h gives O ( h ) .
Proof.
Combine Proposition A1 with Theorem 4 (scalar) and Lemma 2 with Corollary 1 (directional). □
Appendix C. Worked Toy: Conformal Bump via Density
For m ∈ { 2 , 3 } , let ρ ( x ) = exp ( ε φ ( x ) ) with φ smooth and compactly supported, ε small. Set u = 1 m log ρ = ε m φ . The scalar curvature signal from density alone is
R ( x ) = ρ ( x ) − 2 / m − 2 ( m − 1 ) m Δ ρ ρ + ( m − 1 ) ( m + 2 ) m 2 | ∇ ρ | 2 ρ 2
To first order in ε , R ( x ) = − 2 ( m − 1 ) m 2 ε Δ φ ( x ) + O ( ε 2 ) . Sampling a quasi-uniform P h in g = e 2 u g 0 and using Algorithm 1, Corollary A1 with r ≃ h yields
R ^ m ( x ; r ) = R ( x ) + O ( h ) + O ( ε 2 )
uniformly on compacts inside supp ( φ ) .
Appendix D. Proof of the Measured GH Limit (Theorem 2)
Proposition A2
(Local mGH on compacts). Fix K ⋐ Ω . Under (H1)–(H5) on K, there exist a 0 > 0 and C K > 0 such that for all a ∈ ( 0 , a 0 ] there is a correspondence R a ⊂ X a × Ω with
dis ( R a ) ≤ C K a
(A3)
and
d P ( Φ a ) # ν a K , vol g K ≤ C K a
(A4)
where d P is Prokhorov on probability measures and
ν a K : = ν a Φ a − 1 ( K ) ν a Φ a − 1 ( K ) , vol g K : = vol g K vol g ( K ) .
(A5)
Proof.
Metric distortion. Choose K ′ ⋐ K with dist g ( K ′ , ∂ K ) ≥ c a and set
R a : = ( x , Φ a ( x ) ) : Φ a ( x ) ∈ K ′ .
(A6)
By (H4), for Φ a ( x ) ∈ K ′ and integer r ≥ 0 ,
B g Φ a ( x ) , a r − c 1 a ⊆ Φ a B d h ( x , r ) ⊆ B g Φ a ( x ) , a r + c 2 a .
(A7)
Taking r = d h ( x , y ) and bracketing gives
| d g Φ a ( x ) , Φ a ( y ) − a d h ( x , y ) | ≤ C a
(A8)
hence dis ( R a ) ≤ C a .
Pushforward measure. For ψ ∈ C c ∞ ( K ′ ) with ∥ ψ ∥ C 1 ( K ) ≤ 1 , (H2)–(H5) give
∫ ψ d ( Φ a ) # ν a = ∫ K ′ ψ d vol g + O K ( a ) .
(A9)
Normalizing to probabilities gives
| ∫ ψ d ( Φ a ) # ν a K − ∫ ψ d vol g K | ≤ C K a ,
(A10)
hence, d BL ≤ C K a on probability measures on K. Since d P is controlled by d BL on a compact metric space, ( A4) follows. Combining the distortion bound with the pushforward bound via the standard correspondence characterization gives mGH convergence on K. □
Proof of Theorem 2.
Exhaust Ω by compacts { K n } with smooth boundary. Proposition A2 gives, for each fixed n,
d mGH ( X a , d a ∗ , ν a ) | K n , ( Ω , d g , vol g ) | K n ≤ C K n a .
A standard diagonal argument in n yields ( X a , d a ∗ , ν a ) → mGH ( Ω , d g , vol g ) . □
References
Barak, S. Universe Geometry of a Deformed 3D Space Lattice. HAL Arch. 2025, hal-04670068. Available online: https://hal.science/hal-04670068 (accessed on 26 April 2026).
Ollivier, Y. Ricci Curvature of Markov Chains on Metric Spaces. J. Funct. Anal. 2009, 256, 810–864. [ Google Scholar] [ CrossRef]
Münch, F.; Wojciechowski, R.K. Ollivier Ricci Curvature for General Graph Laplacians: Heat Equation, Laplacian Comparison, Non-Explosion and Diameter Bounds. Adv. Math. 2019, 356, 106759. [ Google Scholar] [ CrossRef]
Sandhu, R.; Georgiou, T.; Reznik, E.; Zhu, L.; Kolesov, I.; Senbabaoglu, Y.; Tannenbaum, A. Graph Curvature for Differentiating Cancer Networks. Sci. Rep. 2015, 5, 12323. [ Google Scholar] [ CrossRef] [ PubMed]
Topping, J.; Di Giovanni, F.; Chamberlain, B.P.; Dong, X.; Bronstein, M.M. Understanding Over-Squashing and Bottlenecks on Graphs via Curvature. In Proceedings of the International Conference on Learning Representations (ICLR), Online, 25–29 April 2022. [ Google Scholar]
Forman, R. Bochner's Method for Cell Complexes and Combinatorial Ricci Curvature. Discrete Comput. Geom. 2003, 29, 323–374. [ Google Scholar] [ CrossRef]
Sturm, K.-T. On the Geometry of Metric Measure Spaces, I, II. Acta Math. 2006, 196, 65–131 and 133–177. [ Google Scholar] [ CrossRef]
Lott, J.; Villani, C. Ricci Curvature for Metric-Measure Spaces via Optimal Transport. Ann. Math. 2009, 169, 903–991. [ Google Scholar] [ CrossRef]
Devriendt, K.; Lambiotte, R. Discrete Curvature on Graphs from the Effective Resistance. J. Phys. Complex. 2022, 3, 025008. [ Google Scholar] [ CrossRef]
Regge, T. General Relativity Without Coordinates. Nuovo Cim. 1961, 19, 558–571. [ Google Scholar] [ CrossRef]
Burago, D.; Burago, Y.; Ivanov, S. A Course in Metric Geometry; Graduate Studies in Mathematics; American Mathematical Society: Providence, RI, USA, 2001; Volume 33. [ Google Scholar]
Gromov, M. Metric Structures for Riemannian and Non-Riemannian Spaces; Modern Birkhäuser Classics; Birkhäuser: Boston, MA, USA, 2007. [ Google Scholar]
Roe, J. Lectures on Coarse Geometry; University Lecture Series; American Mathematical Society: Providence, RI, USA, 2003; Volume 31. [ Google Scholar]
Petersen, P. Riemannian Geometry, 3rd ed.; Graduate Texts in Mathematics; Springer: New York, NY, USA, 2016; Volume 171. [ Google Scholar]
do Carmo, M.P. Riemannian Geometry; Birkhäuser: Boston, MA, USA, 1992. [ Google Scholar]
Bobenko, A.I.; Suris, Y.B. Discrete Differential Geometry: Integrable Structure; Graduate Studies in Mathematics; American Mathematical Society: Providence, RI, USA, 2008; Volume 98. [ Google Scholar]
Figure 1. Operational meaning of δ r at base cell c 0 . The two radii are labeled with explicit braces to distinguish them: the solid outer disk has radius r (the measured count radius), and the dashed inner disk has radius r c (the radius reconstructed from the boundary count using the same yardstick). When the boundary at radius r carries more cells than the undeformed baseline (contraction), the reconstructed radius r c is smaller than r, giving δ r > 0 . The reverse case gives δ r < 0 .
Figure 2. Excess radius δ r = r − r c at count-radius r. Each panel shows a wedge of the intrinsic ball; dots mark outward boundary points per cell. The dashed circle is the measured radius r; the reconstructed r c is inferred from the boundary/area count using the same yardstick. ( a) Positive curvature regime; ( b) negative curvature regime.
Figure 3. Fermi tube of thickness 2 τ a around the geodesic slice Σ i j . We sum per-cell weights inside this tube, divide by the tube thickness 2 τ a to recover an effective slice area, and obtain R c , i j ( x ; r , a ) and—via Equation ( 53)—the counts-only estimator K ^ i j , a ( x ; r ) for the sectional curvature K g ( e i ∧ e j ) .
Table 1. Small-ball coefficients and normalizations.
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
© 2026 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license.
Share and Cite
      
MDPI and ACS Style
Barak, S.; Salman, G. Geometry of Deformed Cellular Spaces. Mathematics 2026, 14, 1824. https://doi.org/10.3390/math14111824
AMA Style
Barak S, Salman G. Geometry of Deformed Cellular Spaces. Mathematics. 2026; 14(11):1824. https://doi.org/10.3390/math14111824
Chicago/Turabian Style
Barak, Shlomo, and George Salman. 2026. "Geometry of Deformed Cellular Spaces" Mathematics 14, no. 11: 1824. https://doi.org/10.3390/math14111824
APA Style
Barak, S., & Salman, G. (2026). Geometry of Deformed Cellular Spaces. Mathematics, 14(11), 1824. https://doi.org/10.3390/math14111824
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
Article Metrics
Yes
Citations
No citations were found for this article, but you may check on Google Scholar
No
Article Access Statistics
Created with Highcharts 4.0.4 Article access statistics Article Views 24. May 25. May 26. May 27. May 28. May 29. May 30. May 31. May 1. Jun 2. Jun 3. Jun 4. Jun 5. Jun 6. Jun 7. Jun 8. Jun 0 100 200 300 400
For more information on the journal statistics, click here.
Multiple requests from the same IP address are counted as one view.
Zoom | Orient | As Lines | As Sticks | As Cartoon | As Surface | Previous Scene | Next Scene
Cite
Export citation file: BibTeX | EndNote | RIS
MDPI and ACS Style
Barak, S.; Salman, G. Geometry of Deformed Cellular Spaces. Mathematics 2026, 14, 1824. https://doi.org/10.3390/math14111824
AMA Style
Barak S, Salman G. Geometry of Deformed Cellular Spaces. Mathematics. 2026; 14(11):1824. https://doi.org/10.3390/math14111824
Chicago/Turabian Style
Barak, Shlomo, and George Salman. 2026. "Geometry of Deformed Cellular Spaces" Mathematics 14, no. 11: 1824. https://doi.org/10.3390/math14111824
APA Style
Barak, S., & Salman, G. (2026). Geometry of Deformed Cellular Spaces. Mathematics, 14(11), 1824. https://doi.org/10.3390/math14111824
Note that from the first issue of 2016, this journal uses article numbers instead of page numbers. See further details here.
clear
Mathematics, EISSN 2227-7390, Published by MDPI
RSS Content Alert
Further Information
Article Processing Charges Pay an Invoice Open Access Policy Contact MDPI Jobs at MDPI
Guidelines
For Authors For Reviewers For Editors For Librarians For Publishers For Societies For Conference Organizers
MDPI Initiatives
Sciforum MDPI Books Preprints.org Scilit SciProfiles Encyclopedia JAMS Proceedings Series
Follow MDPI
LinkedIn Facebook X 
Subscribe to receive issue release notifications and newsletters from MDPI journals
Accounting and Auditing
Acoustics
Acta Microbiologica Hellenica
Actuators
Adhesives
Administrative Sciences
Adolescents
Advances in Respiratory Medicine
Aerobiology
Aerospace
Agriculture
AgriEngineering
Agrochemicals
Agronomy
AI
AI Chemistry
AI for Engineering
AI in Education
AI in Medicine
AI Materials
AI Sensors
Air
Algorithms
Allergies
Alloys
Analog
Analytica
Analytics
Anatomia
Anesthesia Research
Animals
Antibiotics
Antibodies
Antioxidants
Applied Biosciences
Applied Mechanics
Applied Microbiology
Applied Nano
Applied Sciences
Applied System Innovation
AppliedChem
AppliedMath
AppliedPhys
Aquaculture Journal
Architecture
Arthropoda
Arts
Astronautics
Astronomy
Atmosphere
Atoms
Audiology Research
Automation
Axioms
Bacteria
Batteries
Behavioral Sciences
Beverages
Big Data and Cognitive Computing
BioChem
Bioengineering
Biologics
Biology
Biology and Life Sciences Forum
Biomass
Biomechanics
BioMed
Biomedicines
BioMedInformatics
Biomimetics
Biomolecules
Biophysica
Bioresources and Bioproducts
Biosensors
Biosphere
BioTech
Birds
Blockchains
Brain Sciences
Buildings
Businesses
C
Cancers
Cardiogenetics
Cardiovascular Medicine
Catalysts
Cells
Ceramics
Challenges
ChemEngineering
Chemistry
Chemistry Proceedings
Chemosensors
Children
Chips
CivilEng
Clean Technologies
Climate
Clinical and Translational Neuroscience
Clinical Bioenergetics
Clinics and Practice
Clocks & Sleep
Coasts
Coatings
Colloids and Interfaces
Colorants
Commodities
Complexities
Complications
Compounds
Computation
Computer Sciences & Mathematics Forum
Computers
Condensed Matter
Conservation
Construction Materials
Corrosion and Materials Degradation
Cosmetics
COVID
Craniomaxillofacial Trauma & Reconstruction
Crops
Cryo
Cryptography
Crystals
Culture
Current Issues in Molecular Biology
Current Oncology
Dairy
Data
Dentistry Journal
Dermato
Dermatopathology
Designs
Diabetology
Diagnostics
Dietetics
Digital
Digital Health and Innovation
Disabilities
Diseases
Diversity
DNA
Drones
Drugs and Drug Candidates
Dynamics
Earth
Ecologies
Econometrics
Economies
Education Sciences
Electricity
Electrochem
Electronic Materials
Electronics
Emergency Care and Medicine
Encyclopedia
Endocrines
Energies
Energy Storage and Applications
Eng
Engineering Proceedings
Entropic and Disordered Matter
Entropy
Environmental and Earth Sciences Proceedings
Environmental Remediation
Environments
Epidemiologia
Epigenomes
European Burn Journal
European Journal of Investigation in Health, Psychology and Education
Family Sciences
Fermentation
Fibers
FinTech
Fire
Fishes
Fluids
Foods
Forecasting
Forensic Sciences
Forests
Fossil Studies
Foundations
Fractal and Fractional
Freshwater
Fuels
Future
Future Collections, Libraries, Archives, and Museums
Future Internet
Future Pharmacology
Future Transportation
Galaxies
Games
Gases
Gastroenterology Insights
Gastrointestinal Disorders
Gastronomy
Gels
Genealogy
Genes
Geographies
GeoHazards
Geomatics
Geometry
Geosciences
Geotechnics
Geriatrics
Germs
Glacies
Gout, Urate, and Crystal Deposition Disease
Grasses
Green
Green Health
Hardware
Healthcare
Hearts
Hemato
Hematology Reports
Heritage
Histories
Horticulturae
Hospitals
Humanities
Humans
Hydrobiology
Hydrogen
Hydrology
Hydropower
Hygiene
Immuno
Industries
Infectious Disease Reports
Inflammation Journal
Informatics
Information
Infrastructures
Inorganics
Insects
Instruments
Intelligent Infrastructure and Construction
International Journal of Cognitive Sciences
International Journal of Environmental Medicine
International Journal of Environmental Research and Public Health
International Journal of Financial Studies
International Journal of Medical Devices
International Journal of Molecular Sciences
International Journal of Neonatal Screening
International Journal of Orofacial Myology and Myofunctional Therapy
International Journal of Plant Biology
International Journal of Topology
International Journal of Translational Medicine
International Journal of Turbomachinery, Propulsion and Power
International Medical Education
Inventions
IoT
ISPRS International Journal of Geo-Information
J
Journal of Aesthetic Medicine
Journal of Ageing and Longevity
Journal of CardioRenal Medicine
Journal of Cardiovascular Development and Disease
Journal of Clinical & Translational Ophthalmology
Journal of Clinical Medicine
Journal of Composites Science
Journal of Cybersecurity and Privacy
Journal of Dementia and Alzheimer's Disease
Journal of Developmental Biology
Journal of Experimental and Theoretical Analyses
Journal of Eye Movement Research
Journal of Functional Biomaterials
Journal of Functional Morphology and Kinesiology
Journal of Fungi
Journal of Genome Biotechnology and Genetics
Journal of Gerontology and Geriatrics
Journal of Imaging
Journal of Innovation
Journal of Intelligence
Journal of Interdisciplinary Research Applied to Medicine
Journal of Low Power Electronics and Applications
Journal of Manufacturing and Materials Processing
Journal of Marine Science and Engineering
Journal of Market Access & Health Policy
Journal of Mind and Medical Sciences
Journal of Molecular Pathology
Journal of Nanotheranostics
Journal of Nuclear Engineering
Journal of Otorhinolaryngology, Hearing and Balance Medicine
Journal of Parks
Journal of Personalized Medicine
Journal of Pharmaceutical and BioTech Industry
Journal of Phytomedicine
Journal of Respiration
Journal of Risk and Financial Management
Journal of Sensor and Actuator Networks
Journal of Superintelligence
Journal of the American Podiatric Medical Association
Journal of the Oman Medical Association
Journal of Theoretical and Applied Electronic Commerce Research
Journal of Vascular Diseases
Journal of Xenobiotics
Journal of Zoological and Botanical Gardens
Journalism and Media
Kidney and Dialysis
Kinases and Phosphatases
Knowledge
LabMed
Laboratories
Land
Languages
Laws
Life
Lights
Limnological Review
Lipidology
Liquids
Literature
Livers
Logics
Logistics
Low-Altitude Economy
Lubricants
Lymphatics
Machine Learning and Knowledge Extraction
Machines
Macromol
Magnetism
Magnetochemistry
Marine Drugs
Materials
Materials Proceedings
Mathematical and Computational Applications
Mathematics
Medical Sciences
Medical Sciences Forum
Medicina
Medicines
Membranes
Merits
Metabolites
Metals
Meteorology
Methane
Methods and Protocols
Metrics
Metrology
Micro
Microbiology Research
Microelectronics
Micromachines
Microorganisms
Microplastics
Microwave
Minerals
Mining
Modelling
Modern Mathematical Physics
Molbank
Molecules
Multimedia
Multimodal Technologies and Interaction
Muscles
Nanoenergy Advances
Nanomanufacturing
Nanomaterials
NDT
Network
Neuroglia
Neuroimaging
Neurology International
NeuroSci
Nitrogen
Non-Coding RNA
Nursing Reports
Nutraceuticals
Nutrients
Obesities
Occupational Health
Oceans
Onco
Optics
Oral
Organics
Organoids
Osteology
Oxygen
Pandemics
Parasitologia
Particles
Pathogens
Pathophysiology
Peace Studies
Pediatric Reports
Pets
Pharmaceuticals
Pharmaceutics
Pharmacoepidemiology
Pharmacy
Philosophies
Photochem
Photonics
Phycology
Physchem
Physical Sciences Forum
Physics
Physiologia
Plants
Plasma
Platforms
Pollutants
Polymers
Polysaccharides
Populations
Poultry
Powders
Precision Oncology
Primary and Hospital Care
Proceedings
Processes
Prosthesis
Proteomes
Psychiatry International
Psychoactives
Psychology International
Publications
Purification
Quantum Beam Science
Quantum Reports
Quaternary
Radiation
Reactions
Real Estate
Receptors
Recycling
Regional Science and Environmental Economics
Religions
Remote Sensing
Reports
Reproductive Medicine
Resources
Rheumato
Risks
Robotics
Romanian Journal of Preventive Medicine
Ruminants
Safety
Sci
Scientia Pharmaceutica
Sclerosis
Seeds
Semiconductors and Heterogeneous Integration
Sensors
Separations
Sexes
Signals
Sinusitis
Smart Cities
Social Sciences
Société Internationale d'Urologie Journal
Societies
Software
Soil Systems
Solar
Solids
Spectroscopy Journal
Sports
Standards
Stats
Stratigraphy and Sedimentology
Stresses
Surfaces
Surgeries
Surgical Techniques Development
Sustainability
Sustainable Chemistry
Swiss Archives of Neurology, Psychiatry and Psychotherapy
Symmetry
SynBio
Systems
Targets
Taxonomy
Technologies
Telecom
Textiles
Thalassemia Reports
Theoretical and Applied Ergonomics
Therapeutics
Thermo
Time and Space
Tomography
Tourism and Hospitality
Toxics
Toxins
Transplantology
Trauma Care
Trends in Higher Education
Trends in Public Health
Tropical Medicine and Infectious Disease
Universe
Urban Science
Uro
Vaccines
Vehicles
Venereology
Veterinary Sciences
Vibration
Virtual Worlds
Viruses
Vision
Waste
Water
Welding
Wild
Wind
Women
World
World Electric Vehicle Journal
Youth
Zoonotic Diseases
Select options
[-] accountaudit Accounting and Auditing [-] acoustics Acoustics [-] amh Acta Microbiologica Hellenica [-] actuators Actuators [-] adhesives Adhesives [-] admsci Administrative Sciences [-] adolescents Adolescents [-] arm Advances in Respiratory Medicine [-] aerobiology Aerobiology [-] aerospace Aerospace [-] agriculture Agriculture [-] agriengineering AgriEngineering [-] agrochemicals Agrochemicals [-] agronomy Agronomy [-] ai AI [-] aichem AI Chemistry [-] aieng AI for Engineering [-] aieduc AI in Education [-] aimed AI in Medicine [-] aimater AI Materials [-] aisens AI Sensors [-] air Air [-] algorithms Algorithms [-] allergies Allergies [-] alloys Alloys [-] analog Analog [-] analytica Analytica [-] analytics Analytics [-] anatomia Anatomia [-] anesthres Anesthesia Research [-] animals Animals [-] antibiotics Antibiotics [-] antibodies Antibodies [-] antioxidants Antioxidants [-] applbiosci Applied Biosciences [-] applmech Applied Mechanics [-] applmicrobiol Applied Microbiology [-] applnano Applied Nano [-] applsci Applied Sciences [-] asi Applied System Innovation [-] appliedchem AppliedChem [-] appliedmath AppliedMath [-] appliedphys AppliedPhys [-] aquacj Aquaculture Journal [-] architecture Architecture [-] arthropoda Arthropoda [-] arts Arts [-] astronautics Astronautics [-] astronomy Astronomy [-] atmosphere Atmosphere [-] atoms Atoms [-] audiolres Audiology Research [-] automation Automation [-] axioms Axioms [-] bacteria Bacteria [-] batteries Batteries [-] behavsci Behavioral Sciences [-] beverages Beverages [-] BDCC Big Data and Cognitive Computing [-] biochem BioChem [-] bioengineering Bioengineering [-] biologics Biologics [-] biology Biology [-] blsf Biology and Life Sciences Forum [-] biomass Biomass [-] biomechanics Biomechanics [-] biomed BioMed [-] biomedicines Biomedicines [-] biomedinformatics BioMedInformatics [-] biomimetics Biomimetics [-] biomolecules Biomolecules [-] biophysica Biophysica [-] bioresourbioprod Bioresources and Bioproducts [-] biosensors Biosensors [-] biosphere Biosphere [-] biotech BioTech [-] birds Birds [-] blockchains Blockchains [-] brainsci Brain Sciences [-] buildings Buildings [-] businesses Businesses [-] carbon C [-] cancers Cancers [-] cardiogenetics Cardiogenetics [-] cardiovascmed Cardiovascular Medicine [-] catalysts Catalysts [-] cells Cells [-] ceramics Ceramics [-] challenges Challenges [-] ChemEngineering ChemEngineering [-] chemistry Chemistry [-] chemproc Chemistry Proceedings [-] chemosensors Chemosensors [-] children Children [-] chips Chips [-] civileng CivilEng [-] cleantechnol Clean Technologies [-] climate Climate [-] ctn Clinical and Translational Neuroscience [-] clinbioenerg Clinical Bioenergetics [-] clinpract Clinics and Practice [-] clockssleep Clocks & Sleep [-] coasts Coasts [-] coatings Coatings [-] colloids Colloids and Interfaces [-] colorants Colorants [-] commodities Commodities [-] complexities Complexities [-] complications Complications [-] compounds Compounds [-] computation Computation [-] csmf Computer Sciences & Mathematics Forum [-] computers Computers [-] condensedmatter Condensed Matter [-] conservation Conservation [-] constrmater Construction Materials [-] cmd Corrosion and Materials Degradation [-] cosmetics Cosmetics [-] covid COVID [-] cmtr Craniomaxillofacial Trauma & Reconstruction [-] crops Crops [-] cryo Cryo [-] cryptography Cryptography [-] crystals Crystals [-] culture Culture [-] cimb Current Issues in Molecular Biology [-] curroncol Current Oncology [-] dairy Dairy [-] data Data [-] dentistry Dentistry Journal [-] dermato Dermato [-] dermatopathology Dermatopathology [-] designs Designs [-] diabetology Diabetology [-] diagnostics Diagnostics [-] dietetics Dietetics [-] digital Digital [-] dhi Digital Health and Innovation [-] disabilities Disabilities [-] diseases Diseases [-] diversity Diversity [-] dna DNA [-] drones Drones [-] ddc Drugs and Drug Candidates [-] dynamics Dynamics [-] earth Earth [-] ecologies Ecologies [-] econometrics Econometrics [-] economies Economies [-] education Education Sciences [-] electricity Electricity [-] electrochem Electrochem [-] electronicmat Electronic Materials [-] electronics Electronics [-] ecm Emergency Care and Medicine [-] encyclopedia Encyclopedia [-] endocrines Endocrines [-] energies Energies [-] esa Energy Storage and Applications [-] eng Eng [-] engproc Engineering Proceedings [-] edm Entropic and Disordered Matter [-] entropy Entropy [-] eesp Environmental and Earth Sciences Proceedings [-] environremediat Environmental Remediation [-] environments Environments [-] epidemiologia Epidemiologia [-] epigenomes Epigenomes [-] ebj European Burn Journal [-] ejihpe European Journal of Investigation in Health, Psychology and Education [-] famsci Family Sciences [-] fermentation Fermentation [-] fibers Fibers [-] fintech FinTech [-] fire Fire [-] fishes Fishes [-] fluids Fluids [-] foods Foods [-] forecasting Forecasting [-] forensicsci Forensic Sciences [-] forests Forests [-] fossstud Fossil Studies [-] foundations Foundations [-] fractalfract Fractal and Fractional [-] freshwater Freshwater [-] fuels Fuels [-] future Future [-] fclam Future Collections, Libraries, Archives, and Museums [-] futureinternet Future Internet [-] futurepharmacol Future Pharmacology [-] futuretransp Future Transportation [-] galaxies Galaxies [-] games Games [-] gases Gases [-] gastroent Gastroenterology Insights [-] gastrointestdisord Gastrointestinal Disorders [-] gastronomy Gastronomy [-] gels Gels [-] genealogy Genealogy [-] genes Genes [-] geographies Geographies [-] geohazards GeoHazards [-] geomatics Geomatics [-] geometry Geometry [-] geosciences Geosciences [-] geotechnics Geotechnics [-] geriatrics Geriatrics [-] germs Germs [-] glacies Glacies [-] gucdd Gout, Urate, and Crystal Deposition Disease [-] grasses Grasses [-] green Green [-] greenhealth Green Health [-] hardware Hardware [-] healthcare Healthcare [-] hearts Hearts [-] hemato Hemato [-] hematolrep Hematology Reports [-] heritage Heritage [-] histories Histories [-] horticulturae Horticulturae [-] hospitals Hospitals [-] humanities Humanities [-] humans Humans [-] hydrobiology Hydrobiology [-] hydrogen Hydrogen [-] hydrology Hydrology [-] hydropower Hydropower [-] hygiene Hygiene [-] immuno Immuno [-] industries Industries [-] idr Infectious Disease Reports [-] inflammj Inflammation Journal [-] informatics Informatics [-] information Information [-] infrastructures Infrastructures [-] inorganics Inorganics [-] insects Insects [-] instruments Instruments [-] iic Intelligent Infrastructure and Construction [-] ijcs International Journal of Cognitive Sciences [-] ijem International Journal of Environmental Medicine [-] ijerph International Journal of Environmental Research and Public Health [-] ijfs International Journal of Financial Studies [-] ijmd International Journal of Medical Devices [-] ijms International Journal of Molecular Sciences [-] IJNS International Journal of Neonatal Screening [-] ijom International Journal of Orofacial Myology and Myofunctional Therapy [-] ijpb International Journal of Plant Biology [-] ijt International Journal of Topology [-] ijtm International Journal of Translational Medicine [-] ijtpp International Journal of Turbomachinery, Propulsion and Power [-] ime International Medical Education [-] inventions Inventions [-] IoT IoT [-] ijgi ISPRS International Journal of Geo-Information [-] J J [-] jaestheticmed Journal of Aesthetic Medicine [-] jal Journal of Ageing and Longevity [-] jcrm Journal of CardioRenal Medicine [-] jcdd Journal of Cardiovascular Development and Disease [-] jcto Journal of Clinical & Translational Ophthalmology [-] jcm Journal of Clinical Medicine [-] jcs Journal of Composites Science [-] jcp Journal of Cybersecurity and Privacy [-] jdad Journal of Dementia and Alzheimer's Disease [-] jdb Journal of Developmental Biology [-] jeta Journal of Experimental and Theoretical Analyses [-] jemr Journal of Eye Movement Research [-] jfb Journal of Functional Biomaterials [-] jfmk Journal of Functional Morphology and Kinesiology [-] jof Journal of Fungi [-] jgbg Journal of Genome Biotechnology and Genetics [-] jgg Journal of Gerontology and Geriatrics [-] jimaging Journal of Imaging [-] joi Journal of Innovation [-] jintelligence Journal of Intelligence [-] jdream Journal of Interdisciplinary Research Applied to Medicine [-] jlpea Journal of Low Power Electronics and Applications [-] jmmp Journal of Manufacturing and Materials Processing [-] jmse Journal of Marine Science and Engineering [-] jmahp Journal of Market Access & Health Policy [-] jmms Journal of Mind and Medical Sciences [-] jmp Journal of Molecular Pathology [-] jnt Journal of Nanotheranostics [-] jne Journal of Nuclear Engineering [-] ohbm Journal of Otorhinolaryngology, Hearing and Balance Medicine [-] jop Journal of Parks [-] jpm Journal of Personalized Medicine [-] jpbi Journal of Pharmaceutical and BioTech Industry [-] jphytomed Journal of Phytomedicine [-] jor Journal of Respiration [-] jrfm Journal of Risk and Financial Management [-] jsan Journal of Sensor and Actuator Networks [-] superintelligence Journal of Superintelligence [-] japma Journal of the American Podiatric Medical Association [-] joma Journal of the Oman Medical Association [-] jtaer Journal of Theoretical and Applied Electronic Commerce Research [-] jvd Journal of Vascular Diseases [-] jox Journal of Xenobiotics [-] jzbg Journal of Zoological and Botanical Gardens [-] journalmedia Journalism and Media [-] kidneydial Kidney and Dialysis [-] kinasesphosphatases Kinases and Phosphatases [-] knowledge Knowledge [-] labmed LabMed [-] laboratories Laboratories [-] land Land [-] languages Languages [-] laws Laws [-] life Life [-] lights Lights [-] limnolrev Limnological Review [-] lipidology Lipidology [-] liquids Liquids [-] literature Literature [-] livers Livers [-] logics Logics [-] logistics Logistics [-] lae Low-Altitude Economy [-] lubricants Lubricants [-] lymphatics Lymphatics [-] make Machine Learning and Knowledge Extraction [-] machines Machines [-] macromol Macromol [-] magnetism Magnetism [-] magnetochemistry Magnetochemistry [-] marinedrugs Marine Drugs [-] materials Materials [-] materproc Materials Proceedings [-] mca Mathematical and Computational Applications [-] mathematics Mathematics [-] medsci Medical Sciences [-] msf Medical Sciences Forum [-] medicina Medicina [-] medicines Medicines [-] membranes Membranes [-] merits Merits [-] metabolites Metabolites [-] metals Metals [-] meteorology Meteorology [-] methane Methane [-] mps Methods and Protocols [-] metrics Metrics [-] metrology Metrology [-] micro Micro [-] microbiolres Microbiology Research [-] microelectronics Microelectronics [-] micromachines Micromachines [-] microorganisms Microorganisms [-] microplastics Microplastics [-] microwave Microwave [-] minerals Minerals [-] mining Mining [-] modelling Modelling [-] mmphys Modern Mathematical Physics [-] molbank Molbank [-] molecules Molecules [-] multimedia Multimedia [-] mti Multimodal Technologies and Interaction [-] muscles Muscles [-] nanoenergyadv Nanoenergy Advances [-] nanomanufacturing Nanomanufacturing [-] nanomaterials Nanomaterials [-] ndt NDT [-] network Network [-] neuroglia Neuroglia [-] neuroimaging Neuroimaging [-] neurolint Neurology International [-] neurosci NeuroSci [-] nitrogen Nitrogen [-] ncrna Non-Coding RNA [-] nursrep Nursing Reports [-] nutraceuticals Nutraceuticals [-] nutrients Nutrients [-] obesities Obesities [-] occuphealth Occupational Health [-] oceans Oceans [-] onco Onco [-] optics Optics [-] oral Oral [-] organics Organics [-] organoids Organoids [-] osteology Osteology [-] oxygen Oxygen [-] pandemics Pandemics [-] parasitologia Parasitologia [-] particles Particles [-] pathogens Pathogens [-] pathophysiology Pathophysiology [-] peacestud Peace Studies [-] pediatrrep Pediatric Reports [-] pets Pets [-] pharmaceuticals Pharmaceuticals [-] pharmaceutics Pharmaceutics [-] pharmacoepidemiology Pharmacoepidemiology [-] pharmacy Pharmacy [-] philosophies Philosophies [-] photochem Photochem [-] photonics Photonics [-] phycology Phycology [-] physchem Physchem [-] psf Physical Sciences Forum [-] physics Physics [-] physiologia Physiologia [-] plants Plants [-] plasma Plasma [-] platforms Platforms [-] pollutants Pollutants [-] polymers Polymers [-] polysaccharides Polysaccharides [-] populations Populations [-] poultry Poultry [-] powders Powders [-] precisoncol Precision Oncology [-] phc Primary and Hospital Care [-] proceedings Proceedings [-] processes Processes [-] prosthesis Prosthesis [-] proteomes Proteomes [-] psychiatryint Psychiatry International [-] psychoactives Psychoactives [-] psycholint Psychology International [-] publications Publications [-] purification Purification [-] qubs Quantum Beam Science [-] quantumrep Quantum Reports [-] quaternary Quaternary [-] radiation Radiation [-] reactions Reactions [-] realestate Real Estate [-] receptors Receptors [-] recycling Recycling [-] rsee Regional Science and Environmental Economics [-] religions Religions [-] remotesensing Remote Sensing [-] reports Reports [-] reprodmed Reproductive Medicine [-] resources Resources [-] rheumato Rheumato [-] risks Risks [-] robotics Robotics [-] rjpm Romanian Journal of Preventive Medicine [-] ruminants Ruminants [-] safety Safety [-] sci Sci [-] scipharm Scientia Pharmaceutica [-] sclerosis Sclerosis [-] seeds Seeds [-] shi Semiconductors and Heterogeneous Integration [-] sensors Sensors [-] separations Separations [-] sexes Sexes [-] signals Signals [-] sinusitis Sinusitis [-] smartcities Smart Cities [-] socsci Social Sciences [-] siuj Société Internationale d'Urologie Journal [-] societies Societies [-] software Software [-] soilsystems Soil Systems [-] solar Solar [-] solids Solids [-] spectroscj Spectroscopy Journal [-] sports Sports [-] standards Standards [-] stats Stats [-] stratsediment Stratigraphy and Sedimentology [-] stresses Stresses [-] surfaces Surfaces [-] surgeries Surgeries [-] std Surgical Techniques Development [-] sustainability Sustainability [-] suschem Sustainable Chemistry [-] sanpp Swiss Archives of Neurology, Psychiatry and Psychotherapy [-] symmetry Symmetry [-] synbio SynBio [-] systems Systems [-] targets Targets [-] taxonomy Taxonomy [-] technologies Technologies [-] telecom Telecom [-] textiles Textiles [-] thalassrep Thalassemia Reports [-] tae Theoretical and Applied Ergonomics [-] therapeutics Therapeutics [-] thermo Thermo [-] timespace Time and Space [-] tomography Tomography [-] tourismhosp Tourism and Hospitality [-] toxics Toxics [-] toxins Toxins [-] transplantology Transplantology [-] traumacare Trauma Care [-] higheredu Trends in Higher Education [-] tph Trends in Public Health [-] tropicalmed Tropical Medicine and Infectious Disease [-] universe Universe [-] urbansci Urban Science [-] uro Uro [-] vaccines Vaccines [-] vehicles Vehicles [-] venereology Venereology [-] vetsci Veterinary Sciences [-] vibration Vibration [-] virtualworlds Virtual Worlds [-] viruses Viruses [-] vision Vision [-] waste Waste [-] water Water [-] welding Welding [-] wild Wild [-] wind Wind [-] women Women [-] world World [-] wevj World Electric Vehicle Journal [-] youth Youth [-] zoonoticdis Zoonotic Diseases
Subscribe
© 1996-2026 MDPI (Basel, Switzerland) unless otherwise stated
Disclaimer
Disclaimer/Publisher's Note: The statements, opinions and data contained in all publications are solely those of the individual author(s) and contributor(s) and not of MDPI and/or the editor(s). MDPI and/or the editor(s) disclaim responsibility for any injury to people or property resulting from any ideas, methods, instructions or products referred to in the content.
Legal Notice Terms and Conditions Privacy Policy Privacy Settings Accessibility
We use cookies on our website to ensure you get the best experience.
Read more about our cookies here.
Accept
Share Link
        https://www.mdpi.com/3901354
Copy
clear
Share
https://www.mdpi.com/3901354
clear
Back to Top Top
All MDPI websites use third-party website tracking technologies to provide and continually improve our services. I agree and may revoke or change my consent at any time with effect for the future.
You can change your mind at any time by clicking "Privacy Settings" at the bottom of the pages.  
Accept All
Deny
More Information
Powered by Usercentrics Consent Management