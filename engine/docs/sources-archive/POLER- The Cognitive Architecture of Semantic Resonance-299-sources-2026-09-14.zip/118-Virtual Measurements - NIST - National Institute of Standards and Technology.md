> Source: https://www.nist.gov/programs-projects/virtual-measurements

Virtual Measurements | NIST
Skip to main content 
An official website of the United States government
Here's how you know
Here's how you know 
Official websites use .gov
A .gov website belongs to an official government organization in the United States. 
Secure .gov websites use HTTPS
A lock ( A locked padlock ) or https:// means you've safely connected to the .gov website. Share sensitive information only on official, secure websites.
https://www.nist.gov/programs-projects/virtual-measurements 
Search NIST 
Menu
Close
Publications
What We Do
All Topics
Advanced communications
Artificial intelligence
Bioscience
Buildings and construction
Chemistry
Cybersecurity and Privacy
Electronics
Energy
Environment
Fire
Forensic science
Health
Information technology
Infrastructure
Manufacturing
Materials
Mathematics and statistics
Metrology
Nanotechnology
Neutron research
Performance excellence
Physics
Public safety
Quantum information science
Resilience
Standards
Transportation
Labs & Major Programs
Assoc Director of Laboratory Programs
Laboratories
Communications Technology Laboratory
Engineering Laboratory
Information Technology Laboratory
Material Measurement Laboratory
Physical Measurement Laboratory
User Facilities
NIST Center for Neutron Research
CNST NanoFab
Research Test Beds
Research Projects
Tools & Instruments
Major Programs
Baldrige Performance Excellence Program
CHIPS for America Initiative
Manufacturing Extension Partnership (MEP)
Office of Advanced Manufacturing
Special Programs Office
Technology Partnerships Office
Services & Resources
Measurements and Standards
Calibration Services
Laboratory Accreditation (NVLAP)
Quality System
Standard Reference Materials (SRMs)
Standard Reference Instruments (SRIs)
Standards.gov
Time Services
Office of Weights and Measures
Software
Data
Chemistry WebBook
National Vulnerability Database
Physical Reference Data
Standard Reference Data (SRD)
Storefront
License & Patents
Computer Security Resource Center (CSRC)
NIST Research Library
News & Events
News
Events
Blogs
NIST In Focus
Feature Stories
Awards
Video Gallery
Image Gallery
Media Contacts
About NIST
About Us
Leadership
Organization Structure
Budget & Planning
Contact Us
Visit
Careers
Student programs
Work with NIST
History
NIST Digital Archives
NIST Museum
NIST and the Nobel
Educational Resources
PROJECTS/PROGRAMS
Virtual Measurements
Share
Facebook
Linkedin
X.com
[Email](mailto:?subject=NIST.gov&body=Check out this site https://www.nist.gov/programs-projects/virtual-measurements)
Summary 
Compared with conventional, physical measurements, the cost of computational modeling continues to drop. This has driven many industries to incorporate computational predictions in their R&D processes. However, to replace a physical measurement, the quantitative reliability of a computational prediction must be known. That is, its associated uncertainty must be known. The goal of this project is to change current practice, so that ISO-style virtual measurements, which we are defining as a value with an uncertainty, supplant "computed values." The scope of this project is to provide uncertainties for common predictions from computational quantum chemistry.
Description 
Figure showing the relationship between error and reliability for predicted properties.
Credit: NIST
Intended Impact 
When engineering data, such as for reactive-chemical hazards, are obtained using quantum chemistry, the lack of associated uncertainties means that the reliability of the data is poorly known. Safety thus requires a skeptical view, often leading to expensive over-design.
Objective 
Predictions from quantum chemistry will carry meaningful uncertainties, allowing such predictions to be used as drop-in replacements for expensive, time-consuming, experimental measurements, in some applications. The dollar value of computational predictions will be greatly enhanced.
Goals 
In the near- and intermediate-term, the most success is anticipated for predictions related to thermochemistry and vibrational spectroscopy, which are interrelated via statistical mechanics. These applications are relevant for chemical engineering, analytical chemistry, and academic physical chemistry. They are also two of the three most common applications of quantum chemistry. The third common application, molecular structure is a lower-priority goal.
Research Activities and Technical Approach 
The flagship project in this research program is the popular Computational Chemistry Comparison and Benchmark Database (NIST Standard Reference Database 101; http://cccbdb.nist.gov/). This website includes evaluated experimental data for more than 1400 selected chemical compounds, plus more than 400,000 property predictions using a variety of methods from quantum chemistry. Integrated software tools allow users to answer the benchmarking questions that are required by current, accepted best practice. However, the CCCBDB does not generally make recommendations. That is the role of the other project in this program, which relies heavily upon the CCCBDB. This collaboration with ITL makes recommendations for obtaining and using uncertainties. All recommendations follow the ISO Guide to the Expression of Uncertainty in Measurement. Recommendations include vibrational spectroscopy, vibrational zero-point energies (ZPEs), and vibrational spectroscopy from second-order vibrational perturbation theory (VPT2).
Major Accomplishments 
CCCBDB Version 16 in early 2013.
Evaluated reference data for experimental ZPEs.
Scaling factors/uncertainties for ZPEs.
Scaling factors/uncertainties for VPT2 theory.
Associated Product(s) 
NIST Standard Reference Database 101: Computational Chemistry Comparison and Benchmark Database ( http://cccbdb.nist.gov/).
It is expanded to include 1400 molecules and more than 400,000 computational predictions, including new properties and molecule types.
ASSOCIATED PUBLICATIONS 
Irikura, K.K., New Empirical Procedures for Improving ab Initio Energetics , J. Phys. Chem. A, 106, 9910-9917 (2002).
Irikura, K.K., Johnson, R.D., III, Kacker, R.N., Uncertainty Associated with Virtual Measurements from Computational Quantum Chemistry Models , Metrologia, 41, 369-375 (2004).
Irikura, K.K., Johnson, R.D., III, Kacker, R.N., Uncertainties in Scaling Factors for ab Initio Vibrational Frequencies , J. Phys. Chem. A, 109, 8430-8437 (2005).
Irikura, K.K., Experimental Vibrational Zero-Point Energies: Diatomic Molecules , J. Phys. Chem. Ref. Data, 36, 389-397 (2007).
Irikura, K.K., Johnson, R.D., III, Kacker, R.N., Kessel, R., Scaling Factors and Uncertainties for ab Initio Anharmonic Vibrational Frequencies , J. Chem. Theory Comput., 2010, 6 (9), pp 2822-2828
Jacobsen, R., Johnson, R.D., III, Irikura, K.K., Kacker, R.N, Anharmonic Calculations are Not Worthwhile for Small Basis Sets , J. Chem. Theory Comput., 2013, 9 (2), pp 951–954
Chemistry and Metrology
Created February 13, 2009, Updated April 14, 2026
Organizations
NIST Headquarters
Laboratory Programs
Material Measurement Laboratory
Material Data Division
Theory, Modeling, and Simulation Group
NIST Staff
Karl K. Irikura
Raghu N Kacker
Former Staff
Russell D. Johnson III
Contact
Karl K. Irikura karl.irikura@nist.gov (301) 975-2510
Project Status
Ongoing
Related Publications
Nearly ab Initio Thermochemistry: The Use of Reaction Schemes. Application to IO and HOI
Inexpensive Vibrational Anharmonicities from Estimated Derivatives: Diatomic Molecules
Systematic Errors in ab Initio Bond Dissociation Energies
Facilities
NIST scientific computing facility
MML/Computational Chemistry computing resource
CUSTOMERS/CONTRIBUTORS /COLLABORATORS
Applied Chemicals and Materials Division
Applied and Computational Mathematics Division
Was this page helpful?
HEADQUARTERS
100 Bureau Drive
Gaithersburg, MD 20899
301-975-2000
Webmaster | Contact Us | Our Other Offices
X.com Facebook LinkedIn Instagram YouTube Giphy RSS Feed Mailing List
How are we doing? Feedback
Site Privacy
Accessibility
Privacy Program
Copyright & Disclaimers
Vulnerability Disclosure
No Fear Act Policy
FOIA
Environmental Policy
Scientific Integrity
Information Quality Standards
Commerce.gov
Science.gov
USA.gov
Vote.gov
Back to top