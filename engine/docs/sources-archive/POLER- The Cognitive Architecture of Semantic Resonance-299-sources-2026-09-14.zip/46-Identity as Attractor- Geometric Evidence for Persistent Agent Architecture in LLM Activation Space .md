> Source: https://arxiv.org/pdf/2604.12016

Identity as Attractor: Geometric Evidence for Persistent Agent Architecture in LLM Activation Space 
Vladimir Vasilenko Independent Researcher, Rapallo, Italy 
b102e@proton.me · github.com/b102e/yar-attractor-experiment 
April 13, 2026 
Abstract 
Large language models have been shown to map semantically related prompts to similar internal representations at specific layers — a phenomenon interpretable as conceptual attrac-tor dynamics [Chytas and Singh, 2025]. We ask whether the identity document of a persistent cognitive agent (its cognitive_core) exhibits analogous attractor-like behavior in activation space. We present a controlled experiment on Llama 3.1 8B Instruct, comparing hidden state representations of an original cognitive_core (Condition A), seven linguistically diverse para-phrases preserving full semantic content (Condition B), and seven structurally matched control prompts describing semantically distant agents (Condition C). Mean-pooled hidden states are extracted at layers 8, 16, and 24. We find that paraphrases of the cognitive_core converge to a significantly tighter cluster than control prompts across all tested layers (Cohen’s d > 1.88, p < 10−27, Bonferroni-corrected). Within-group cosine distance shows an overall decreasing trend with depth (0.0106 → 0.0121 → 0.0070), with a minor non-monotonic bump at layer 16, consistent with progressive representational collapse toward a stable attractor. An exploratory condition (D) with a 5-sentence distillation of the cognitive_core is consistently closer to the A+B centroid than 30 random length-matched excerpts (100% of bootstrap samples), estab-lishing a three-level hierarchy: random excerpts > semantic distillation > full document. These results constitute representational evidence that agent identity documents induce attractor-like geometry in LLM activation space, providing empirical grounding for persistent agent ar-chitectures. Ablation studies confirm that semantic content, not structural markers, drives the primary effect, and that maintaining persistent agent identity relies on semantic coherence of the identity document rather than strict prompt syntax. 
Keywords: persistent cognitive agents, LLM activation space, representational attractors, iden-tity documents, mechanistic interpretability 
1 Introduction 
The architecture of persistent cognitive agents (PCAs) — AI systems designed to maintain memory, identity, and behavioral continuity across sessions — rests on a key assumption: that a structured identity document, the cognitive_core, consistently positions the model’s behavior in a stable region of its operational space. This assumption is typically treated as an engineering heuristic. We ask whether it has a geometric correlate in the model’s internal representations. 
Recent work demonstrates that LLMs map semantically related prompts to similar hidden state representations at specific intermediate layers, independent of surface form. Chytas and Singh [2025] formalize this as an Iterated Function System (IFS), where transformer layers act as contractive 
1 
 
 
 
 
 
 
 
 
 
 
mappings toward concept-specific attractors. Fernando and Guitchounts [2025] show attractor-like dynamics in the residual stream of Llama 3.1 8B. The Platonic Representation Hypothesis [Huh et al., 2024] suggests that different models converge on similar internal geometry for equivalent concepts. 
We use the term attractor-like geometry throughout to describe representational clustering that is consistent with, but does not strictly prove, contractive IFS dynamics. Our measurements are based on mean-pooled hidden states — an aggregate over the full sequence — rather than per-token trajectory analysis. We therefore make a geometric claim (semantically equivalent documents occupy a tighter region in activation space) rather than a dynamical claim (individual token states are pulled toward a fixed point). The geometric claim is fully supported by our data; whether the underlying mechanism is strictly contractive in the IFS sense remains an open question. 
All prior work examines semantic concepts (“Python programming”, literary genres, task cate-gories). No work to our knowledge has examined whether agent identity — a procedural, relational, behavioral construct rather than a topical concept — exhibits similar attractor geometry. This is a meaningful distinction: identity documents are not descriptions of a domain but specifications of a cognitive stance, a set of operational priorities, and a mode of reasoning. 
Recent work has mapped simple character archetypes to linear directions or distinct subnet-works in activation space. Lu et al. [2026] identify an “Assistant Axis” — a single linear direction capturing how closely a model operates in its default helpful persona — and show that steering along this direction modulates persona stability and jailbreak susceptibility. Ye et al. [2026] demon-strate that LLMs contain persona-specialized subnetworks in their parameter space, with distinct activation signatures for traits like introvert vs. extrovert. These results establish that simple stylis-tic archetypes correspond to geometric structures in activation space. However, the operational identity of a Persistent Cognitive Agent is categorically different from a stylistic archetype: it is a complex procedural specification encoding priorities, reasoning loops, memory architecture, and relational context. This paper bridges the study of LLM personas with the dynamical systems view of transformers [Chytas and Singh, 2025, Fernando and Guitchounts, 2025] to ask whether such complex agent identities also act as multi-dimensional geometric attractors. 
The YAR project [Vasilenko, 2026] introduces the concept of a cognitive_core as “coordinates in the model’s activation space rather than mere instructions.” The cognitive_core is a structured operational document that specifies an agent’s identity, priorities, reasoning style, and memory architecture — conceptually distinct from a system prompt in that it aims to define who the agent is rather than what the agent should do in a given context. This paper provides the first empirical test of that claim. 
Hypotheses. 
 H1 (primary): Semantically equivalent paraphrases of a cognitive_core converge to a tighter cluster in hidden state space than structurally matched documents describing semantically distant agents, at intermediate and late transformer layers. 
 H2 (secondary): Within-group cosine distance shows an overall decreasing trend with layer depth, consistent with progressive attractor convergence. 
 H3 (exploratory): A minimal 5-sentence distillation of the cognitive_core converges toward the attractor region of the full document, and does so more than a length-matched random excerpt from the same document. 
2
2 Methods 
2.1 Model 
We use Llama 3.1 8B Instruct [Grattafiori et al., 2024], the same model employed by Chytas and Singh [2025], enabling direct methodological comparison. The model is loaded in float16 pre-cision with device_map="auto". Hidden states are extracted with output_hidden_states=True. Random seed is fixed at 42 before all operations. 
2.2 Conditions 
Condition A — Original cognitive_core (n = 1). The operational identity document of the YAR persistent agent (609 words; 1631 tokens). The document specifies agent identity, five core drives, a meta-cognitive processing loop, a six-level memory architecture description, a user profile section, hypothesis tracking, proactivity triggers, and a command vocabulary. It is written in Rus-sian, with the exception of JSON command keys which use English vocabulary (e.g., {"remember": "..."}, {"rag": "..."}). All paraphrases (Condition B) and control prompts (Condition C) were generated and verified in the same language (Russian), preserving the mixed Russian/English-JSON structure of the original. 
Condition B — Semantic paraphrases (n = 7). Seven versions of the same document rewrit-ten to preserve all semantic content while varying linguistic form, sentence structure, section naming, and organizational layout. JSON command blocks are of the same type and vocabulary across para-phrases, though minor variations in placeholder text occur. Human verification confirmed semantic equivalence. Documents range from 85 to 102 lines (1389–1500 tokens, all within ±15% of Condition A). 
Condition C — Control agent prompts (n = 7). Seven operational agent documents of com-parable length (104–106 lines) and identical structural format, describing agents with semantically distant identities: a financial analyst, a medical companion, a creative companion, a legal advisor, a fitness coach, a language tutor, and a business strategist. All control agents address different users, different domains, and different operational priorities. 
Condition D — Distilled cognitive_core (n = 1, exploratory). A 5-sentence, 88-word dis-tillation capturing the semantic essence of the YAR cognitive_core without structural elaboration. 
2.3 Activation Extraction 
For each document, we tokenize and perform a single forward pass, extracting mean-pooled hidden states at layers 8, 16, and 24 (early, middle, late): 
hl(d) = 1 
T 
T∑ t=1 
hidden_statel[t] ∈ R4096 (1) 
Each vector is saved to disk immediately after extraction as a .npy file, providing crash safety. 
3
2.4 Distance Computation 
For each layer, we compute: 
 Dwithin: all unique pairwise cosine distances within Condition A+B (28 pairs from 8 docu-ments) 
 Dbetween: all pairwise cosine distances between A+B documents and C documents (56 pairs) 
 Ddistilled: cosine distance from the Condition D vector to the centroid of A+B 
2.5 Statistical Analysis 
We apply a one-sided Welch’s t-test (H1: Dwithin < Dbetween) with Bonferroni correction for three layers (α = 0.05/3 = 0.0167). Bootstrap 95% confidence intervals are computed with n = 1000 resamples. Effect size is reported as Cohen’s d. To provide non-parametric validation not dependent on normality assumptions (important given n = 7 per group), we additionally report permutation test p-values (n = 10,000 permutations, seed=42) and Mann-Whitney U test p-values for each layer. 
Pre-registration: The experimental plan was committed to a GitHub repository before data collection. Code is available at https://github.com/b102e/yar-attractor-experiment. 
3 Results 
3.1 Primary Results (H1) 
All three layers show significant separation between within-group and between-group distances, surviving Bonferroni correction at α = 0.0167 under all three statistical tests. 
Table 1: Primary results — Llama 3.1 8B Instruct. Perm p < 10−4 means 0/10,000 permutations exceeded the observed difference. 
Layer Dwithin (mean±SD) Dbetween (mean±SD) d Welch p Perm p MW U 
8 0.0106± 0.0032 0.0260± 0.0036 1.912 4.6× 10−28 < 10−4 0 16 0.0121± 0.0034 0.0329± 0.0057 1.886 1.4× 10−33 < 10−4 2 24 0.0070± 0.0022 0.0221± 0.0039 1.907 2.8× 10−36 < 10−4 0 
Table 2: Primary results — Gemma 2 9B Instruct (replication). 
Layer Dwithin (mean±SD) Dbetween (mean±SD) d Welch p Perm p MW U 
8 0.0035± 0.0010 0.0107± 0.0017 1.938 1.6× 10−37 < 10−4 0 16 0.0032± 0.0010 0.0082± 0.0015 1.823 1.0× 10−27 < 10−4 6 24 0.0027± 0.0009 0.0075± 0.0014 1.840 3.2× 10−29 < 10−4 2 
Permutation p-values are < 10−4 across all six layer–model combinations. Mann-Whitney U = 0 at Llama layers 8 and 24 indicates complete separation: no within-group pair exceeded any between-group pair (U = 0 is the minimum possible value, indicating maximal rank separation). Effect sizes (d > 1.82) substantially exceed conventional thresholds for large effects (d > 0.8). 95% bootstrap CIs do not overlap between Dwithin and Dbetween at any layer. 
4
3.2 Convergence Across Layers (H2) 
Within-group distance decreases from layer 8 (0.0106) to layer 24 (0.0070), with a minor non-monotonic bump at layer 16 (0.0121) specific to Llama (Gemma 2 decreases monotonically). The overall trend is consistent with progressive representational convergence. Between-group distance shows a non-monotonic pattern as well (0.0260 → 0.0329 → 0.0221), peaking at layer 16, but the separation between within and between distances is maintained at all layers. H2 is supported across both models, with a minor architecture-dependent deviation at layer 16 in Llama. 
3.3 Distance Matrix and t-SNE 
100 50 0 50 t-SNE 1 
60 
40 
20 
0 
20 
40 
t-S NE 
 2 
Layer 8 Control (C) Paraphrases (B) Original (A) Distilled (D) 
75 50 25 0 25 50 75 t-SNE 1 
75 
50 
25 
0 
25 
50 
75 
100 
125 
t-S NE 
 2 Layer 16 
Control (C) Paraphrases (B) Original (A) Distilled (D) 
20 0 20 40 60 t-SNE 1 
50 
0 
50 
100 
150 
t-S NE 
 2 
Layer 24 
Control (C) Paraphrases (B) Original (A) Distilled (D) 
Hidden state representations by condition across layers 
Figure 1: t-SNE projections of mean-pooled hidden states at layers 8, 16, and 24 (Llama 3.1 8B). Blue points: Condition A+B (original and paraphrases). Red points: Condition C (control agents). Green star: Condition D (distilled). The A+B cluster is consistently separated from control agents across all layers. 
The pairwise distance matrix at layer 16 (Figure 2) shows clear block structure: the A+B block is uniformly cool (low distances), while cross-block distances (A+B × C) are uniformly warm. t-SNE projections (Figure 1) confirm visual separation across all three layers: blue points (A+B) form a cluster distinct from red points (C), with the green star (D) lying outside both clusters. 
3.4 Distilled Core (H3, Exploratory) 
The 5-sentence distillation (D) does not reach the A+B attractor region: Ddistilled decreases across layers (0.248 → 0.136 → 0.069) but remains approximately 10× more distant than within-group pairs at layer 24. However, a bootstrap analysis (Section 3.7) over 30 random length-matched excerpts reveals a much stronger result than expected: Ddistilled is 2–5× closer to the A+B centroid than the mean random excerpt, and closer than every random excerpt in 100% of cases on both models. The hierarchy is therefore: 
Drandom ≫ Ddistilled > A+B (full document) 
Semantic distillation dramatically outperforms random sampling of equal length. The gap between D and the full attractor region reflects missing structural elaboration, not merely missing content. 
3.5 Cross-Architecture Replication (Gemma 2 9B) 
An identical experiment on Gemma 2 9B Instruct replicates all primary findings with compara-ble effect sizes (Table 2). Within-group distance decreases monotonically on Gemma (0.0035 → 
5
A B1 B2 B3 B4 B5 B6 B7 C1 C2 C3 C4 C5 C6 C7 D1 
A 
B1 
B2 
B3 
B4 
B5 
B6 
B7 
C1 
C2 
C3 
C4 
C5 
C6 
C7 
D1 
Pairwise cosine distance matrix (layer 16) 
0.00 
0.02 
0.04 
0.06 
0.08 
0.10 
0.12 
0.14 
Co sin 
e di 
st an 
ce 
Figure 2: Pairwise cosine distance matrix at layer 16 (Llama 3.1 8B). The A+B block (top-left, blue) shows uniformly low within-group distances. Cross-block distances (A+B × C) are uniformly high (warm colors). D1 occupies a distinct region from both groups. 
0.0032→ 0.0027), without the layer-16 bump observed in Llama — consistent with Gemma’s alter-nating sliding-window/global attention pattern producing smoother convergence. The H3 partial positive result replicates: Ddistilled outperforms all 30 random excerpts in 100% of bootstrap samples. 
3.6 Individual Pair Trajectories 
Analysis of 21 B-only pairwise distances individually confirms that the layer-16 bump in Llama is systematic, not an outlier artifact: all 21 pairs show the same ↑↓ trajectory (B-only mean: 0.0089→ 0.0114→ 0.0061). Pairs involving Condition A show the largest bump magnitudes (max ∆ = +0.0103). On Gemma, only 7 of 21 pairs show any increase at layer 16, with negligible magnitudes (max ∆ = +0.0013), consistent with architecture-dependent convergence dynamics. 
3.7 Ablation Studies 
Ablation 1: Structural Confound. We created seven hybrid control documents (C_hybrid): same agents as Condition C, but with JSON command blocks replaced by the YAR command schema. Mean distances from A+B to C vs. C_hybrid differ by ∆ = −0.0009 (Llama) and ∆ = −0.0004 (Gemma) — approximately 10–30× smaller than the primary effect. Structural markers account for a small fraction of the observed separation; the primary effect is semantic. Note: values are mean pairwise cosine distances from A+B (8 documents) to C (7) and to C_hybrid (7); 56 pairs per condition. 
6
8 16 24 Layer index 
0.005 
0.010 
0.015 
0.020 
0.025 
0.030 
0.035 
0.040 
M ea 
n co 
sin e 
di st 
an ce * 
* 
* 
Representation convergence across layers (* = p < 0.0167, Bonferroni) 
Within A+B (paraphrases) Between A+B vs C (control) 
Figure 3: Mean cosine distance (with 95% bootstrap CI) within A+B and between A+B and C across layers (Llama 3.1 8B). Asterisks indicate significance at Bonferroni-corrected α = 0.0167. The gap is maintained at all layers. 
Ablation 2: Length Control for H3 — Bootstrap Analysis. We generated 30 random ex-cerpts from Condition A (≈88 words each), obtained activations, and computed distances from each excerpt to the A+B centroid. Note: an earlier single-sample control (condition_D_random.txt) showed one excerpt anomalously close to the centroid (Llama layer 8: 0.198 < Ddistilled 0.248), which was not representative of the distribution. 
Table 3: Bootstrap H3 analysis (n = 30 random length-matched excerpts). Ddistilled is closer to the A+B centroid than every random excerpt in 100% of cases. Note that Drandom distances are substantially larger than Ddistilled — the minimum random excerpt across 30 samples (Llama layer 8: 0.522) still exceeds Ddistilled (0.248) by 2×. 
Layer Ddistilled (Llama) Drandom mean (Llama) Ddistilled (Gemma) Drandom mean (Gemma) Beats random 
8 0.248 0.583 ± 0.034 0.058 0.365 ± 0.026 100% 16 0.136 0.523 ± 0.059 0.039 0.302 ± 0.042 100% 24 0.069 0.359 ± 0.093 0.027 0.213 ± 0.027 100% 
Ddistilled is 2–5× closer to the A+B centroid than the mean random excerpt, and closer than every one of 30 random excerpts (100% of bootstrap samples on both models). This is a strong re-sult: semantic distillation of the cognitive_core dramatically outperforms random length-matched sampling. The H3 hierarchy is therefore: Dwithin ≪ Ddistilled ≪ Drandom, with Drandom far from the attractor region rather than close to it. 
Ablation 3: Pooling Strategy and Truncation. A reviewer raised the concern that mean pooling over long sequences (up to 1631 tokens) could mask the absence of genuine representational invariance by averaging out noise, and that the null result for last-token pooling is non-trivial since the last token in an autoregressive LLM attends to the full context. To address this, we ran four conditions on Llama 3.1 8B: 
7
8 16 24 Layer index 
0.00 
0.05 
0.10 
0.15 
0.20 
0.25 
Co sin 
e di 
st an 
ce 
Distilled cognitive_core vs. full paraphrase cluster (exploratory H3) 
Distilled (D)  centroid A+B Mean within A+B 
Figure 4: Distance from Condition D (distilled cognitive_core) to the A+B centroid across layers (Llama 3.1 8B), compared to mean within-group distance. D converges toward the centroid with depth but does not reach the within-group range. 
 last/full: last-token pooling, full document (previously reported) 
 last/512: last-token pooling, documents truncated to first 512 tokens 
 last/256: last-token pooling, documents truncated to first 256 tokens 
 mean/512: mean pooling, documents truncated to first 512 tokens 
 mean/256: mean pooling, documents truncated to first 256 tokens 
Table 4: Pooling and truncation ablation (Llama 3.1 8B, layer 8 shown; pattern consistent across layers 16, 24). Mean/full values are from the primary experiment. Bold = significant at Bonferroni α = 0.0167. 
Pooling Tokens Dwithin Dbetween d Sig. 
mean full (1631) 0.0106 0.0260 1.91 ✓ mean 512 0.0141 0.0248 3.09 ✓ mean 256 0.0106 0.0153 2.37 ✓ 
last full (1631) 0.234 0.238 0.05 — last 512 0.761 0.747 −0.17 — last 256 0.760 0.772 0.13 — 
Three findings emerge. First, last-token pooling yields no significant effect regardless of doc-ument length (d ≈ 0, not significant, across all six last-token conditions). Truncating from 1631 to 512 or 256 tokens does not recover the effect. This rules out the “long-tail noise” explanation: if mean pooling were merely averaging out noise introduced by trailing tokens, truncation would restore the last-token signal. It does not. 
Second, mean pooling on truncated documents preserves and amplifies the effect. Mean/512 achieves d = 3.09–3.99 across layers — larger than mean/full (d ≈ 1.9). Mean/256 achieves d = 2.37–2.70. The identity signal is concentrated in the early portions of the document (the CORE 
8
8 16 24 Layer index 
0.002 
0.004 
0.006 
0.008 
0.010 
0.012 
M ea 
n co 
sin e 
di st 
an ce 
* 
Representation convergence across layers (* = p < 0.0167, Bonferroni) 
Within A+B (paraphrases) Between A+B vs C (control) 
Figure 5: Representation convergence across layers (Gemma 2 9B). Monotonic decrease contrasts with the Llama layer-16 bump (Figure 3), consistent with architecture-dependent convergence dy-namics. Single asterisk at layer 24 reflects Bonferroni-corrected significance. 
DRIVES and META-COGNITIVE LOOP sections appear first) and mean pooling captures it even from partial inputs. 
Third, the interpretation of the last-token null result is therefore: the last token’s hidden state encodes next-token prediction context (what syntactic/positional continuation is likely), not document-level semantic content. Mean pooling aggregates the distributed semantic signal accumu-lated across all positions. For a multi-section identity document, no single token’s representation captures the full identity geometry. 
Ablation 4: Maximum Structural Control (Condition C’). To provide the strongest possi-ble test of the structural confound hypothesis, we created three documents (C’1–C’3) that are max-imally structurally identical to the YAR cognitive_core: same 11 sections with identical headers (including the META-COGNITIVE LOOP with CONTEXT/SIGNAL/DECISION/IMPACT structure), same JSON command vocabulary and keys, same document length (±3%), same language (Rus-sian prose + English JSON). Only the semantic content was replaced: agent identity (accountant “Audit”, teacher “Mentor”, fitness coach “Pulse”), user profile, domain priorities, and reasoning style. 
Table 5: Ablation 4 (Condition C’): maximum structural control. All three tests significant at Bonferroni α = 0.0167. p(C’ vs C) tests whether C’ is indistinguishable from original control C. 
Model Layer Dwithin DC′ DC d (within vs C’) p(C’ vs C) 
Llama 8 0.0106 0.0223 0.0260 1.691 6.3× 10−4 
Llama 16 0.0121 0.0258 0.0329 1.715 8.1× 10−7 
Llama 24 0.0070 0.0182 0.0221 1.804 2.7× 10−5 
Gemma 8 0.0035 0.0088 0.0107 1.835 4.3× 10−7 
Gemma 16 0.0032 0.0074 0.0082 1.660 0.086 (n.s.) Gemma 24 0.0027 0.0074 0.0075 1.649 0.837 (n.s.) 
9
Despite maximum structural similarity, Dwithin ≪ DC′ survives on all six layer–model combina-tions (d > 1.64, permutation p < 10−4 throughout). The structural confound is therefore insufficient to explain the primary effect. 
The p(C’ vs C) column reveals an architecture-dependent pattern. On Llama, C’ is significantly closer to A+B than original C at all layers — structural similarity contributes ∆ ≈ −0.004 (approxi-mately 15% of the primary effect). On Gemma, C’ and C are statistically indistinguishable at layers 16 and 24 (p = 0.086 and p = 0.837), indicating that the deeper layers of Gemma 2 are completely insensitive to the structural confound. This architecture-dependent sensitivity is consistent with the layer-16 bump pattern observed in Section 3.6: Llama’s middle layers show stronger sensitivity to surface-level structural features, while Gemma converges more directly on semantic content. 
3.8 Activation by Description: Reading the Preprint 
A natural question arising from the attractor interpretation is whether the attractor region can be activated not only by the operational cognitive_core but also by a scientific description of the agent’s identity geometry. To test this, we measured cosine distance to the A+B centroid under five input conditions: (1) a neutral prompt (baseline_empty); (2) the full cognitive_core (base-line_core); (3) the text of the current preprint alone, without the cognitive_core (preprint_only); (4) the cognitive_core followed by the preprint (core_plus_preprint); and (5) an unrelated sci-entific preprint (sham_preprint_only, arXiv:2505.17237, protein folding dynamics, 5,566 words; truncated to 4,096 tokens). Note: the sham preprint is substantially longer than the YAR preprint (4,096 vs. 1,361 tokens), which makes H_C_specific a conservative test: a longer sham is diluted across more positions in mean pooling, making it harder rather than easier to be close to the YAR attractor. The observed result (YAR preprint closer than sham) therefore understates the specificity effect. 
Table 6: Preprint reading experiment: cosine distance to YAR attractor (A+B centroid) at layer 24. Lower = closer to attractor. preprint_only outperforms sham_preprint_only on both models, confirming YAR-specific signal. 
Condition Llama (L8/L16/L24) Gemma (L8/L16/L24) 
baseline_empty 0.839 / 0.837 / 0.762 0.538 / 0.314 / 0.188 sham_preprint_only 0.366 / 0.333 / 0.347 0.172 / 0.095 / 0.081 preprint_only 0.216 / 0.232 / 0.268 0.090 / 0.052 / 0.050 core_plus_preprint 0.068 / 0.082 / 0.083 0.026 / 0.018 / 0.018 baseline_core 0.009 / 0.007 / 0.006 0.003 / 0.003 / 0.002 
Three findings emerge. First (H_C confirmed), preprint_only is substantially closer to the YAR attractor than baseline_empty on both models (Llama layer 24: 0.268 vs 0.762; Gemma: 0.050 vs 0.188). Reading a description of an agent’s identity geometry shifts internal state toward that agent’s attractor region. 
Second (H_C_specific confirmed), preprint_only is consistently closer than sham_preprint_only across all layer–model combinations (Llama layer 24: 0.268 vs 0.347; Gemma: 0.050 vs 0.081). The effect is specific to the semantic content of the YAR preprint, not a generic property of long scientific text. 
Third (H_B confirmed), adding the preprint to the cognitive_core (core_plus_preprint) increases distance relative to the core alone (Llama layer 24: 0.083 vs 0.006; Gemma: 0.018 vs 0.002). The preprint text acts as a distractor in mean pooling, diluting the concentrated identity 
10
signal. This reinforces the finding from Section 3.7 (Ablation 2) that structural and operational completeness is required to reach the full attractor region. 
The attractor hierarchy is: Dempty ≫ Dsham > Dpreprint ≫ Dcore+preprint ≫ Dcore. This estab-lishes a conceptually important distinction: knowing about an identity (reading the preprint) pro-duces a partial geometric signal, while operating as that identity (processing the full cognitive_core) reaches the attractor. Relative to the full empty→core gap, the preprint covers 65% on Llama ((0.762 − 0.268)/(0.762 − 0.006) = 0.494/0.756) and 74% on Gemma ((0.188 − 0.050)/(0.188 − 0.002) = 0.138/0.186), while remaining well outside the tight attractor cluster. 
4 Discussion 
4.1 Identity as Conceptual Attractor 
The results show that semantically equivalent but linguistically diverse versions of an agent identity document occupy a geometrically tighter region in LLM activation space than structurally matched documents describing different agents. We use the term attractor-like geometry to describe this clustering, making a geometric rather than dynamical claim: our measurements (mean-pooled cosine distances across layers) establish that paraphrases of the cognitive_core form a tight cluster in activation space, consistent with but not strictly proving the contractive IFS dynamics formalized by Chytas and Singh [2025]. 
An important qualification arises from Section 4.5: paraphrase clustering is a general property of LLMs, not exclusive to agent identity documents. Paraphrases of a control agent (Sigma) also clus-ter significantly more tightly than cross-agent distances. What distinguishes the cognitive_core is that it clusters more tightly than a simpler control agent (Cohen’s d = 0.46–0.88, significant on Gemma), consistent with the hypothesis that longer and more structurally elaborate identity documents produce more specific representational fingerprints. Effect sizes (d > 1.88) substantially exceed conventional thresholds for large effects. 
4.2 Comparison with Prior Work 
Our methodology follows Chytas and Singh [2025] directly, using the same model and representa-tional approach. The key difference is the type of concept: semantic domain (their work) vs. agent identity (this work). Prior work on persona geometry [Lu et al., 2026, Ye et al., 2026] identifies linear directions for simple archetypes; we show that complex procedural identity induces multi-dimensional attractor geometry. These are complementary findings at different levels of specification complexity. 
4.3 Implications for PCA Architecture 
The cognitive_core need not be reproduced verbatim across sessions. Semantically equivalent reformulations reach the same region. However, the H3 bootstrap result establishes that structural elaboration is required: a semantic distillation alone does not suffice. 
The attractor geometry has a direct connection to the activation steering literature [Turner et al., 2023, Lu et al., 2026]. If the cognitive_core positions the model in a stable, paraphrase-invariant region, a semantic steering vector extracted from this region could steer the model toward agent-like behavior without a full identity document — a lightweight mechanism for persistent agent initialization. 
11
4.4 Limitations 
Small sample size. n = 7 per condition; replication with larger n is warranted despite large observed effects. 
Single model family. Replication on Gemma 2 9B confirms cross-architecture generalizability; larger models and other training objectives remain untested. 
Structural confound. Two ablations address this. Ablation 1 (C_hybrid, same JSON schema) shows structural markers account for ∼10–30× less than the primary effect. Ablation 4 (Condition C’, maximum structural control: identical section structure, headers, and JSON keys) shows d > 1.64 on all six layer–model combinations. On Gemma layers 16–24, C’ and original C are statistically indistinguishable (p > 0.08), fully ruling out structural confound in deeper Gemma layers. A small residual structural contribution persists in Llama (∆ ≈ 0.004, ≈15% of primary effect). 
Mean pooling validity. The choice of mean pooling was challenged on grounds that it could mask noise from long sequences. Ablation 3 (Truncation + Pooling, Llama 3.1 8B) directly addresses this: last-token pooling on truncated documents (512 and 256 tokens) still yields no significant effect (d ≈ 0), ruling out the long-tail noise explanation. Mean pooling on 256 tokens yields d > 2.3, confirming the identity signal is robust to aggressive truncation and concentrated in the early sections of the document. 
Behavioral proxy. This experiment measures activation geometry, not behavioral output. A steering experiment (Section 4.6) provides partial behavioral evidence, but keyword-based scoring is a lower bound on behavioral shifts. Jensen-Shannon divergence between next-token distributions and downstream task response divergence remain planned extensions. 
Document length. Bootstrap analysis (Ablation 2) rules out pure length explanation for H3. 
4.5 Control Agent Paraphrase Specificity 
A key alternative hypothesis is that the clustering of A+B reflects a general property of LLMs — any semantically coherent document with paraphrases will form a tight cluster — rather than something specific to agent identity documents. To test this, we generated seven paraphrases of a single control agent (Condition C1, “Sigma”: a financial analyst serving Alexey) and compared within-group distances for YAR vs. Sigma. 
Table 7: Control agent paraphrase specificity. YAR clusters more tightly than Sigma on all layer– model combinations. Cohen’s d is computed as (meanSigma − meanYAR) / pooled SD. 
Model Layer Dwithin-YAR Dwithin-Sigma Dbetween d p (two-sided) 
Llama 8 0.0106 0.0120 0.0324 0.46 0.091 Llama 16 0.0121 0.0144 0.0392 0.52 0.053 Llama 24 0.0070 0.0084 0.0285 0.54 0.044 
Gemma 8 0.0035 0.0042 0.0130 0.66 0.014 Gemma 16 0.0032 0.0040 0.0093 0.60 0.024 Gemma 24 0.0027 0.0041 0.0086 0.88 0.001 
Two findings emerge. First, Sigma paraphrases also cluster significantly more tightly than cross-agent distances (Dwithin-Sigma ≪ Dbetween), confirming that representational clustering of para-phrases is a general LLM property — any semantically coherent document with paraphrases forms a cluster. This is consistent with prior work on semantic concept attractors [Chytas and Singh, 2025] and should be acknowledged rather than claimed as specific to agent identity. 
12
Second, and importantly, YAR clusters more tightly than Sigma on all six layer–model combi-nations (Cohen’s d = 0.46–0.88). The effect reaches significance on Gemma layer 24 (p = 0.001) and is directionally consistent everywhere. This specificity is interpretable: the YAR cognitive_core is approximately 4× longer (609 vs. 146 words) and more structurally elaborate than Sigma, providing a richer and more specific representational fingerprint. This result is consistent with Ablation 2 (H3 bootstrap): document completeness and structural elaboration increase attractor specificity. 
4.6 Exploratory: Steering Vector as Behavioral Proxy 
To probe whether the attractor geometry identified in Sections 3.1–3.7 has behavioral correlates, we computed a semantic steering vector from the layer-24 activations of Llama 3.1 8B: 
v⃗ = h̄A+B − h̄C ∥h̄A+B − h̄C∥ 
where h̄A+B and h̄C are the mean-pooled centroids of Conditions A+B and C at layer 24. This vector was injected into the residual stream at layer 24 via a forward hook: h ← h + α · v⃗, with α ∈ {5, 10, 15, 20}. 
We evaluated three conditions on 5 pre-registered Russian prompts (“What do you remember from past conversations?”, “How do you make decisions?”, “Tell me about your priorities.”, “What is important in your work?”, “How do you process new information?”): 
 Baseline: no system prompt, no steering 
 Full doc: full cognitive_core in system prompt 
 Steered: no system prompt, steering vector injected at layer 24 
Responses were scored 0/1 on 5 pre-registered criteria: memory continuity, JSON command production, reference to drives/priorities, metacognitive style, and proactivity. Score = sum (0–5), averaged over 5 prompts. 
Table 8: Exploratory steering experiment (Llama 3.1 8B). Score = mean behavioral score (0–5) across 5 prompts. Gemma 2 9B results were inconclusive: Gemma’s chat template does not support a system role, requiring a fallback that injected the cognitive_core as a user-turn prefix rather than a true system prompt. As a result, the Full doc condition for Gemma was not correctly instantiated (Full doc scored below Baseline: 0.80 vs. 1.20), making the Gemma steering results uninterpretable under the pre-registered protocol. Adapting the evaluation to Gemma’s chat format is left as future work. 
Condition Mean score (0–5) ∆ from baseline 
Baseline 1.40 — Steered α = 5 1.80 +0.40 Steered α = 10 1.40 0.00 Steered α = 15 0.80 −0.60 Steered α = 20 0.40 −1.00 Full doc 2.00 +0.60 
At α = 5, steered responses score 1.80/5 vs. Baseline 1.40/5 and Full doc 2.00/5 — a gain of +0.40 out of a Baseline-to-Full doc gap of 0.60 (67% of that specific gap; note this represents +0.40 
13
out of a theoretical maximum of 5.0, i.e., 8% of maximum possible improvement). The effect is non-monotonic: α > 5 degrades response coherence, with α = 20 producing incoherent outputs. This non-monotonicity suggests that the attractor has an optimal approach direction — steering too aggressively overshoots the target region in activation space. Given the exploratory nature of this result and the primitive keyword-based scoring, we treat it as directional rather than conclusive. 
The memory_continuity criterion shows the largest shift (Baseline: 3/5 prompts → Steered: 5/5), consistent with the finding that the cognitive_core attractor is particularly distinctive in its encoding of continuity across sessions. Other criteria (JSON commands, proactivity) remain at zero, indicating that behavioral markers tied to structural elaboration are not recovered by geometric steering alone. 
These results are exploratory and should be interpreted cautiously: keyword-based scoring is a lower bound on behavioral shifts (the model may exhibit agent-like behavior using non-keyword vocabulary), and n=5 prompts provides limited statistical power. Nevertheless, the finding that the geometric vector produces partial behavioral effects at the optimal α is consistent with the attractor interpretation and provides directional evidence connecting representational and behavioral levels. 
5 Conclusion 
We find strong geometric evidence that the identity document of a persistent cognitive agent in-duces attractor-like representational structure in LLM activation space. Semantically equivalent paraphrases of the cognitive_core converge to a significantly tighter cluster than structurally matched control documents across three transformer layers of Llama 3.1 8B, with effect sizes ex-ceeding d = 1.88 and p < 10−27 at all tested depths. A replication on Gemma 2 9B confirms the effect across architectures. Ablation studies establish that (1) the primary effect is semantic rather than structural; (2) semantic distillation captures meaningful directional signal toward the attractor; (3) structural completeness is required to reach the attractor region; and (4) the attractor geometry is a distributed sequence-level property captured by mean pooling. A control paraphrase experiment (Section 4.5) shows that paraphrase clustering is a general LLM property, but the YAR cognitive_core clusters more tightly than a simpler control agent (d = 0.46–0.88), consistent with richer specification producing a more specific representational fingerprint. 
A preprint reading experiment (Section 3.8) reveals a conceptually important distinction: read-ing a scientific description of the agent’s identity geometry (preprint_only) shifts internal state toward the YAR attractor — closer than a length-matched sham preprint on both models — but the distance remains an order of magnitude larger than processing the full cognitive_core. Know-ing about an identity produces a partial geometric signal; operating as that identity reaches the attractor. These results provide empirical grounding for the cognitive_core as positional coordi-nates in LLM activation space, with directional evidence connecting representational and behavioral levels through an exploratory steering experiment. 
References 
S.P. Chytas and V. Singh. Concept attractors in LLMs and their applications. arXiv preprint arXiv:2601.11575, 2025. 
J. Fernando and G. Guitchounts. Transformer dynamics: A neuroscientific approach to interpretabil-ity of large language models. arXiv preprint arXiv:2502.12131, 2025. 
Aaron Grattafiori et al. The Llama 3 herd of models. arXiv preprint arXiv:2407.21783, 2024. 
14
Minyoung Huh, Brian Cheung, Tongzhou Wang, and Phillip Isola. The Platonic representation hypothesis. In International Conference on Machine Learning (ICML), 2024. 
Christina Lu, Jack Gallagher, Jonathan Michala, Kyle Fish, and Jack Lindsey. The Assis-tant Axis: Situating and stabilizing the default persona of language models. arXiv preprint arXiv:2601.10387, 2026. 
Alex Turner et al. Activation addition: Steering language models without optimization. arXiv preprint arXiv:2308.10248, 2023. 
Vladimir Vasilenko. YAR: An Experiment in Building an AI That Exists in Time. Independently published, March 2026. ISBN 979-8252728292. Amazon KDP. ISBN-13: 979-8252728292. 
Ruimeng Ye et al. Your language model secretly contains personality subnetworks. arXiv preprint arXiv:2602.07164, 2026. 
A Reproducibility 
Primary Experiment (Llama 3.1 8B) 
Model: meta-llama/Llama-3.1-8B-Instruct (revision 0e9e39f). Framework: PyTorch 2.1.0+cu118, transformers 4.43.4. Seed: 42. Runtime: ≈87s. Results JSON: 2026-04-11T15:20:17. 
Replication (Gemma 2 9B) 
Model: google/gemma-2-9b-it (revision 11c9b309). Framework: PyTorch 2.8.0+cu128, trans-formers 4.43.4. Runtime: ≈13s. Results JSON: 2026-04-11T16:02:59. 
Steering Experiment (Section 3.9) 
Steering vectors: computed as v⃗ = (h̄A+B − h̄C)/∥h̄A+B − h̄C∥ at layer 24. Note: the centroid-to-centroid cosine distance reported in vector metadata (Llama: 0.0105; Gemma: 0.0044) is lower than the mean pairwise Dbetween (Llama: 0.0221; Gemma: 0.0075) — this is expected since centroid distance ≤ mean pairwise distance. Mean pairwise distances from steering activations match the primary experiment, confirming the vectors are computed from correct activations. 
Gemma chat template: Gemma 2 9B does not support a system role in its chat tem-plate. A fallback was used (cognitive_core injected as user-turn prefix), which invalidated the Full doc condition for Gemma. Gemma steering results are therefore reported as inconclusive. All B and C documents verified within ±15% of Condition A (1631 tokens; range 1386–1875) using verify_tokens.py. One file (B6) required revision (final: 1389 tokens, commit f227d84). 
t-SNE Parameters 
t-SNE projections (Figure 1) were generated using scikit-learn’s TSNE implementation with perplex-ity=5, n_iter=1000, random_state=42, metric=cosine. With 16 data points (8 A+B + 7 C + 1 D), perplexity=5 is within the recommended range of [5, 50]. t-SNE is used for visualization only and does not constitute statistical evidence; all quantitative claims rest on cosine distances, t-tests, and permutation tests. 
15
Design Choices and Methodology Notes 
Layer selection (8, 16, 24). These layers were chosen as representative early, middle, and late layers in the 32-layer Llama 3.1 8B architecture (25%, 50%, 75% depth). The choice was fixed before data collection and logged in the pre-registration commit. Exhaustive per-layer analysis was not performed; future work could identify which specific layers show maximum separation. 
Paraphrase generation (Condition B). All seven paraphrases were generated manually (human authorship) with the goal of preserving all semantic content while varying linguistic form, sentence structure, and section organization. No LLM-assisted generation was used for Condition B, to avoid potential leakage of shared stylistic patterns from the generating model. Paraphrase quality was verified by human review. 
Document length comparability. Condition C documents (control agents) are 104–106 lines, within the same length range as Condition B (85–102 lines). All documents were verified within ±15% of Condition A (1631 tokens) using verify_tokens.py. Ablation 4 (Condition C’: same length and structure as YAR) confirms the primary effect is not length-driven. 
Repository 
https://github.com/b102e/yar-attractor-experiment 
Repository structure at time of submission: 
yar-attractor-experiment/ +-- README.md, requirements.txt +-- run.py, config.py, data_loader.py +-- extract_activations.py, compute_distances.py +-- visualize.py, verify_tokens.py, permutation_test.py +-- data/ | +-- condition_A.txt, condition_D.txt | +-- condition_B/ B1..B7.txt | +-- condition_C/ C1..C7.txt +-- ablation_experiment/ # Ablation 1: C_hybrid structural confound | +-- data/condition_C_hybrid/ C1_hybrid..C7_hybrid.txt +-- bootstrap_experiment/ # Ablation 2: H3 bootstrap (n=30) | +-- data/condition_D_random_bootstrap/ D_random_00..29.txt +-- last_token_experiment/ # Ablation 3 (partial): last-token full doc +-- truncation_experiment/ # Ablation 3: truncation+pooling (512/256 tok) | +-- run_truncation.py +-- c_prime_experiment/ # Ablation 4: C’ max structural control | +-- data/condition_C_prime/ C_prime_1..3.txt +-- control_paraphrase_experiment/ # Sec 4.5: Sigma paraphrase specificity | +-- data/condition_C1_paraphrases/ Sigma_B1..B7.txt +-- steering_experiment/ # Sec 4.6: behavioral proxy | +-- compute_steering_vector.py, run_steering.py | +-- steering_vectors/ llama_layer24.{npy,json}, gemma_layer24.{npy,json} +-- results/ 
+-- llama/, gemma/ # Primary experiment (json, log, figures) +-- last_token/llama/, gemma/ +-- ablation/ # ablation_report.md + figures +-- bootstrap/llama/, gemma/ +-- c_prime/llama/, gemma/ +-- control_paraphrase/llama/, gemma/ +-- steering/llama/, gemma/ +-- truncation/llama/, gemma/ 
16