> Source: https://github.com/JoeyT1994

JoeyT1994 (Joseph Tindall) · GitHub
Skip to content
Navigation Menu
Toggle navigation 
Sign in
Appearance settings
Platform
AI CODE CREATION
GitHub Copilot Write better code with AI
GitHub Spark Build and deploy intelligent apps
GitHub Models Manage and compare prompts
MCP Registry New Integrate external tools
DEVELOPER WORKFLOWS
Actions Automate any workflow
Codespaces Instant dev environments
Issues Plan and track work
Code Review Manage code changes
APPLICATION SECURITY
GitHub Advanced Security Find and fix vulnerabilities
Code security Secure your code as you build
Secret protection Stop leaks before they start
EXPLORE
Why GitHub
Documentation
Blog
Changelog
Marketplace View all features
Solutions
BY COMPANY SIZE
Enterprises
Small and medium teams
Startups
Nonprofits
BY USE CASE
App Modernization
DevSecOps
DevOps
CI/CD
View all use cases
BY INDUSTRY
Healthcare
Financial services
Manufacturing
Government
View all industries View all solutions
Resources
EXPLORE BY TOPIC
AI
Software Development
DevOps
Security
View all topics
EXPLORE BY TYPE
Customer stories
Events & webinars
Ebooks & reports
Business insights
GitHub Skills
SUPPORT & SERVICES
Documentation
Customer support
Community forum
Trust center
Partners View all resources
Open Source
COMMUNITY
GitHub Sponsors Fund open source developers
PROGRAMS
Security Lab
Maintainer Community
Accelerator
GitHub Stars
Archive Program
REPOSITORIES
Topics
Trending
Collections
Enterprise
ENTERPRISE SOLUTIONS
Enterprise platform AI-powered developer platform
AVAILABLE ADD-ONS
GitHub Advanced Security Enterprise-grade security features
Copilot for Business Enterprise-grade AI features
Premium Support Enterprise-grade 24/7 support
Pricing
Search or jump to...
Search code, repositories, users, issues, pull requests...
Search
Clear
Search syntax tips
Provide feedback
We read every piece of feedback, and take your input very seriously. [-]
Include my email address so I can be contacted
Cancel Submit feedback
Saved searches
Use saved searches to filter your results more quickly
Name
Query
To see all available qualifiers, see our documentation.
Cancel Create saved search
Sign in
Sign up
Appearance settings
Resetting focus
You signed in with another tab or window. Reload to refresh your session. You signed out in another tab or window. Reload to refresh your session. You switched accounts on another tab or window. Reload to refresh your session. Dismiss alert 
JoeyT1994 Follow
Overview Repositories 12 Projects 0 Packages 0 Stars 9
More
Overview
Repositories
Projects
Packages
Stars 
JoeyT1994
Follow
Joseph Tindall JoeyT1994
Follow
Researcher @simonsfoundation working on the simulation of many-body quantum systems.
66 followers
· 36 following
Flatiron Institute
New York
Achievements
 x3
 x3
  
Achievements
 x3
 x3
  
Highlights
Pro
Block or report user
Block or report JoeyT1994
Block user
Prevent this user from interacting with your repositories and sending you notifications. Learn more about blocking users.
You must be logged in to block users.
Add an optional note
Maximum 250 characters. Please don't include any personal information such as legal names or email addresses. Markdown is supported. This note will only be visible to you.
Block user
Report abuse
Contact GitHub support about this user's behavior. Learn more about reporting abuse.
Report abuse
Overview Repositories 12 Projects 0 Packages 0 Stars 9
More
Overview
Repositories
Projects
Packages
Stars
Popular repositories Loading
TensorNetworkQuantumSimulator.jl TensorNetworkQuantumSimulator.jl Public Package built on top of ITensors.jl and NamedGraphs.jl for quantum simulation with tensor networks (TNs) of near-arbitrary geometry Julia 75 17
ITensorNumericalAnalysis.jl ITensorNumericalAnalysis.jl Public Julia 15 4
BP-TNS-Data BP-TNS-Data Public Repository for data generated via the BP-TNS Method 3
ITensorNetworks.jl ITensorNetworks.jl Public Forked from ITensor/ITensorNetworks.jl Belief Propagation Development Fork. Julia 1
NamedGraphs.jl NamedGraphs.jl Public Forked from ITensor/NamedGraphs.jl Building Extra Features Julia
GraphTikZ.jl GraphTikZ.jl Public Forked from mtfishman/GraphTikZ.jl A package for visualizing Graphs.jl-compatible graphs with TikZ. Julia
414 contributions in the last year
Skip to contributions year list
No contributions on May 25th. No contributions on June 1st. No contributions on June 8th. No contributions on June 15th. No contributions on June 22nd. No contributions on June 29th. No contributions on July 6th. No contributions on July 13th. No contributions on July 20th. No contributions on July 27th. No contributions on August 3rd. No contributions on August 10th. 1 contribution on August 17th. 1 contribution on August 24th. No contributions on August 31st. No contributions on September 7th. No contributions on September 14th. No contributions on September 21st. 2 contributions on September 28th. No contributions on October 5th. 5 contributions on October 12th. 2 contributions on October 19th. 3 contributions on October 26th. 13 contributions on November 2nd. No contributions on November 9th. 2 contributions on November 16th. 1 contribution on November 23rd. 5 contributions on November 30th. 1 contribution on December 7th. No contributions on December 14th. No contributions on December 21st. No contributions on December 28th. No contributions on January 4th. No contributions on January 11th. No contributions on January 18th. No contributions on January 25th. No contributions on February 1st. No contributions on February 8th. No contributions on February 15th. No contributions on February 22nd. No contributions on March 1st. No contributions on March 8th. No contributions on March 15th. No contributions on March 22nd. No contributions on March 29th. No contributions on April 5th. No contributions on April 12th. No contributions on April 19th. No contributions on April 26th. No contributions on May 3rd. No contributions on May 10th. No contributions on May 17th. No contributions on May 24th. No contributions on May 26th. 6 contributions on June 2nd. 1 contribution on June 9th. No contributions on June 16th. No contributions on June 23rd. No contributions on June 30th. No contributions on July 7th. 1 contribution on July 14th. 7 contributions on July 21st. No contributions on July 28th. No contributions on August 4th. No contributions on August 11th. No contributions on August 18th. 2 contributions on August 25th. No contributions on September 1st. No contributions on September 8th. 7 contributions on September 15th. 4 contributions on September 22nd. 5 contributions on September 29th. No contributions on October 6th. 10 contributions on October 13th. No contributions on October 20th. 4 contributions on October 27th. 8 contributions on November 3rd. No contributions on November 10th. 5 contributions on November 17th. 11 contributions on November 24th. 5 contributions on December 1st. 5 contributions on December 8th. No contributions on December 15th. 1 contribution on December 22nd. No contributions on December 29th. No contributions on January 5th. No contributions on January 12th. No contributions on January 19th. 4 contributions on January 26th. No contributions on February 2nd. No contributions on February 9th. No contributions on February 16th. No contributions on February 23rd. No contributions on March 2nd. No contributions on March 9th. 1 contribution on March 16th. No contributions on March 23rd. 10 contributions on March 30th. No contributions on April 6th. No contributions on April 13th. No contributions on April 20th. No contributions on April 27th. No contributions on May 4th. No contributions on May 11th. No contributions on May 18th. No contributions on May 25th. 1 contribution on May 27th. No contributions on June 3rd. No contributions on June 10th. No contributions on June 17th. No contributions on June 24th. No contributions on July 1st. 2 contributions on July 8th. No contributions on July 15th. 7 contributions on July 22nd. No contributions on July 29th. 1 contribution on August 5th. No contributions on August 12th. No contributions on August 19th. 4 contributions on August 26th. 2 contributions on September 2nd. 1 contribution on September 9th. 2 contributions on September 16th. No contributions on September 23rd. 1 contribution on September 30th. No contributions on October 7th. 7 contributions on October 14th. 2 contributions on October 21st. 14 contributions on October 28th. 13 contributions on November 4th. 1 contribution on November 11th. 9 contributions on November 18th. 1 contribution on November 25th. No contributions on December 2nd. No contributions on December 9th. No contributions on December 16th. No contributions on December 23rd. No contributions on December 30th. No contributions on January 6th. No contributions on January 13th. 1 contribution on January 20th. No contributions on January 27th. No contributions on February 3rd. No contributions on February 10th. No contributions on February 17th. No contributions on February 24th. No contributions on March 3rd. No contributions on March 10th. No contributions on March 17th. No contributions on March 24th. 6 contributions on March 31st. No contributions on April 7th. No contributions on April 14th. No contributions on April 21st. No contributions on April 28th. No contributions on May 5th. No contributions on May 12th. No contributions on May 19th. No contributions on May 26th. 1 contribution on May 28th. No contributions on June 4th. No contributions on June 11th. No contributions on June 18th. No contributions on June 25th. No contributions on July 2nd. No contributions on July 9th. 1 contribution on July 16th. 1 contribution on July 23rd. No contributions on July 30th. No contributions on August 6th. No contributions on August 13th. 2 contributions on August 20th. No contributions on August 27th. No contributions on September 3rd. No contributions on September 10th. 2 contributions on September 17th. 1 contribution on September 24th. No contributions on October 1st. No contributions on October 8th. 4 contributions on October 15th. 3 contributions on October 22nd. No contributions on October 29th. 2 contributions on November 5th. 2 contributions on November 12th. 11 contributions on November 19th. 1 contribution on November 26th. No contributions on December 3rd. 4 contributions on December 10th. No contributions on December 17th. No contributions on December 24th. No contributions on December 31st. No contributions on January 7th. No contributions on January 14th. No contributions on January 21st. 1 contribution on January 28th. No contributions on February 4th. No contributions on February 11th. No contributions on February 18th. No contributions on February 25th. No contributions on March 4th. No contributions on March 11th. No contributions on March 18th. No contributions on March 25th. 7 contributions on April 1st. No contributions on April 8th. No contributions on April 15th. No contributions on April 22nd. 1 contribution on April 29th. 1 contribution on May 6th. No contributions on May 13th. No contributions on May 20th. No contributions on May 27th. No contributions on May 29th. No contributions on June 5th. 1 contribution on June 12th. No contributions on June 19th. No contributions on June 26th. 1 contribution on July 3rd. No contributions on July 10th. 1 contribution on July 17th. No contributions on July 24th. No contributions on July 31st. No contributions on August 7th. No contributions on August 14th. 3 contributions on August 21st. 12 contributions on August 28th. No contributions on September 4th. 2 contributions on September 11th. No contributions on September 18th. No contributions on September 25th. 2 contributions on October 2nd. No contributions on October 9th. No contributions on October 16th. 4 contributions on October 23rd. 5 contributions on October 30th. 3 contributions on November 6th. No contributions on November 13th. 4 contributions on November 20th. No contributions on November 27th. 2 contributions on December 4th. 1 contribution on December 11th. No contributions on December 18th. No contributions on December 25th. No contributions on January 1st. No contributions on January 8th. No contributions on January 15th. No contributions on January 22nd. No contributions on January 29th. No contributions on February 5th. No contributions on February 12th. No contributions on February 19th. 2 contributions on February 26th. No contributions on March 5th. No contributions on March 12th. No contributions on March 19th. No contributions on March 26th. 1 contribution on April 2nd. No contributions on April 9th. 1 contribution on April 16th. No contributions on April 23rd. 1 contribution on April 30th. 2 contributions on May 7th. No contributions on May 14th. No contributions on May 21st. No contributions on May 28th. No contributions on May 30th. No contributions on June 6th. No contributions on June 13th. No contributions on June 20th. No contributions on June 27th. No contributions on July 4th. 2 contributions on July 11th. 1 contribution on July 18th. No contributions on July 25th. No contributions on August 1st. No contributions on August 8th. No contributions on August 15th. 2 contributions on August 22nd. 1 contribution on August 29th. No contributions on September 5th. 5 contributions on September 12th. 1 contribution on September 19th. 1 contribution on September 26th. 8 contributions on October 3rd. 4 contributions on October 10th. 7 contributions on October 17th. 13 contributions on October 24th. 11 contributions on October 31st. No contributions on November 7th. 5 contributions on November 14th. 3 contributions on November 21st. 3 contributions on November 28th. 7 contributions on December 5th. No contributions on December 12th. No contributions on December 19th. No contributions on December 26th. No contributions on January 2nd. No contributions on January 9th. No contributions on January 16th. No contributions on January 23rd. No contributions on January 30th. No contributions on February 6th. No contributions on February 13th. No contributions on February 20th. No contributions on February 27th. No contributions on March 6th. No contributions on March 13th. No contributions on March 20th. No contributions on March 27th. No contributions on April 3rd. No contributions on April 10th. 4 contributions on April 17th. No contributions on April 24th. 1 contribution on May 1st. 2 contributions on May 8th. No contributions on May 15th. 5 contributions on May 22nd. No contributions on May 29th. No contributions on May 31st. No contributions on June 7th. No contributions on June 14th. No contributions on June 21st. No contributions on June 28th. No contributions on July 5th. No contributions on July 12th. No contributions on July 19th. No contributions on July 26th. No contributions on August 2nd. No contributions on August 9th. No contributions on August 16th. No contributions on August 23rd. No contributions on August 30th. No contributions on September 6th. 1 contribution on September 13th. No contributions on September 20th. No contributions on September 27th. No contributions on October 4th. 3 contributions on October 11th. No contributions on October 18th. 8 contributions on October 25th. 3 contributions on November 1st. No contributions on November 8th. 3 contributions on November 15th. No contributions on November 22nd. 4 contributions on November 29th. 2 contributions on December 6th. No contributions on December 13th. No contributions on December 20th. No contributions on December 27th. No contributions on January 3rd. No contributions on January 10th. No contributions on January 17th. 3 contributions on January 24th. No contributions on January 31st. No contributions on February 7th. No contributions on February 14th. No contributions on February 21st. No contributions on February 28th. No contributions on March 7th. No contributions on March 14th. No contributions on March 21st. No contributions on March 28th. No contributions on April 4th. No contributions on April 11th. No contributions on April 18th. No contributions on April 25th. No contributions on May 2nd. No contributions on May 9th. No contributions on May 16th. No contributions on May 23rd. No contributions on May 30th.
Contribution Graph
| Day of Week | June Jun ||||| July Jul |||| August Aug ||||| September Sep |||| October Oct |||| November Nov ||||| December Dec |||| January Jan |||| February Feb |||| March Mar ||||| April Apr |||| May May |||| | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | Sunday Sun | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | Monday Mon | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | Tuesday Tue | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | Wednesday Wed | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | Thursday Thu | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | Friday Fri | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | Saturday Sat | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | |
Learn how we count contributions
Less
No contributions.
Low contributions.
Medium-low contributions.
Medium-high contributions.
High contributions.
More
@quantum-advantage-tracker @ITensor @qiskit-community
Activity overview
Contributed to JoeyT1994/TensorNetworkQuantumSimulator.jl, ITensor/ITensorCCQSchool, JoeyT1994/ITensorNumericalAnalysis.jl and 11 other repositories
Loading 5% Code review 1% Issues 12% Pull requests 82% Commits
Contribution activity
May 2026
Created 10 commits in 3 repositories
quantum-advantage-tracker/quantum-adv... 5 commits
JoeyT1994/TensorNetworkQuantumSimulat... 4 commits
ITensor/ITensorNetworksNext.jl 1 commit
Opened 1 pull request in 1 repository
JoeyT1994/TensorNetworkQuantumSimulator.jl 1 merged
Improvements This contribution was made on May 7 May 7
Loading Show more activity
2026
2025
2024
2023
2022
2021
2020
2019
Footer
© 2026 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Community
Docs
Contact
Manage cookies
Do not share my personal information
You can't perform that action at this time.