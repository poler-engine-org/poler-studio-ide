> Source: https://www.researchgate.net/publication/267323737_Modeling_of_asynchronous_cellular_automata_with_fixed-point_attractors_for_pattern_classification

ResearchGate - Temporarily Unavailable 
Access denied
You do not have access to www.researchgate.net.
The site owner may have set restrictions that prevent you from accessing the site.
Ray ID: a085897f3d57514c
Timestamp: 2026-06-08 05:36:07 UTC
Your IP address: 74.125.212.228
Requested URL: www.researchgate.net/publication/267323737_Modeling_of_asynchronous_cellular_automata_with_fixed-point_attractors_for_pattern_classification
Error reference number: 1020
Server ID: FL_960F9
User-Agent: Google-NotebookLM
Ray ID: a085897f3d57514c
Client IP: 74.125.212.228
© 2008-2026 ResearchGate GmbH. All rights reserved.