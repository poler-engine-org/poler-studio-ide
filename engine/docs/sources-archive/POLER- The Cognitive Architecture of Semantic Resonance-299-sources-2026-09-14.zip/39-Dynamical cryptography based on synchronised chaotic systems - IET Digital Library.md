> Source: https://digital-library.theiet.org/doi/pdf/10.1049/el%3A19990693?download=true

Skip to main contentSearch
All content
IET journals
Books
Conferences
Videos
Advanced searchCitation searchShopping cart with  0    item Login | Register  Login  
CONNECT  
Institutional  
Skip main navigation
Electronics Letters   Previous article Next articleRapid Communication 10 June 1999
Dynamical cryptography based on synchronised chaotic systems
Authors : Chu and ChangAuthors Info & AffiliationsPublication : Electronics LettersVolume  35 ,  Issue  12https://doi.org/10.1049/el:19990693Get access
Abstract
Dynamical cryptography based on synchronised chaotic systems Recently, a novel dynamical data encryption system based on synchronised chaotic systems was proposed for security communication. Based on the same synchronised chaotic systems, its dynamical cryptography is investigated. In this system, the ciphertext of each bit is mapped to one of two distinct chaotic dynamical equations. The ciphertext can be decrypted by its synchronised chaotic equation. This method can prevent intruders from recovering the information signals by statistical methods. To demonstrate its effectiveness, a 2 bit dynamical data cryptosystem based entirely on the Lorenz system is presented.
Get full access to this article
View all available purchase options and get full access to this article.
Get accessReferences
1. Chu Y.H. and Chang S. Dynamic data encryption system based on synchronised chaotic systems Electron. Lett. 35 4 271-273  1999Google Scholar2. Lorenz N. Deterministic nonperiodic flow J. Amos. Sci. 20 130-141  1963Google Scholar3. Parlitz U., Chua L.O., Kocarev L., Halle K.S., and Shang A. Transmission of digital signals by chaotic synchronization Int. J. Bifurc. Chaos 2 973-977  1992Google Scholar4. Chu Y.H., Chou J.H., and Chang S. Chaos from third-order phase-locked loops with a slowly varying parameter IEEE Trans. CAS-37 9 1104-1115  1990Google Scholar5. Chou J.H., Chu Y.H., and Chang S. Chaos in phase-locked loops Electron. Lett. 27 750-751  1991Google Scholar6. Perez G. and Cerdeira H.A. Extracting messages masked by chaos Phys. Rev. Lett. 74 1970-1973  1995Google Scholar7. Stojanovski T., Kocarev L., and Parlitz U. A simple method to reveal the parameters of the Lorenz system Int. J. Bifurc. Chaos 6 12B 2645-2652  1996Google Scholar8. Kocarev L. and Parlitz U. Generalized synchronization, predictability, and equivalence of unidirectionally coupled dynamical systems Phys. Rev. Lett. 76 11 1816-1819  1996Google Scholar9. Pecora M. and Carroll T.L. Synchronization in chaotic systems Phys. Rev. Lett. 64 821-824  1990Google Scholar10. Kocarev L. and Parlitz U. General approach for chaotic synchronization with application to communication Phys. Rev. Lett. 74 5028-5031  1995Google ScholarInformation and Authors
Information
Published in
Electronics LettersVolume  35  •  Issue  12  •  10 June 1999Pages :  974  -  975
Copyright
© IEE.
History
Published in print: 10 June 1999Published online: 14 March 2024
Inspec keywords
chaos
cryptography
synchronisation
Keywords
dynamical cryptography
synchronised chaotic system
data encryption
security communication
ciphertext
Lorenz system
Authors
Affiliations
Chu Department of Electrical Engineering, Nonlinear Dynamic Systems Laboratory, National Tsing Hua University, Hsin-Chu, Taiwan 300, Republic of ChinaView all articles by this authorChang Department of Electrical Engineering, Nonlinear Dynamic Systems Laboratory, National Tsing Hua University, Hsin-Chu, Taiwan 300, Republic of ChinaView all articles by this authorMetrics and Citations
Metrics
Citations
Download article citation data for:  Dynamical cryptography based on synchronised chaotic systemsChu  and  Chang  
 If you have the appropriate software installed, you can download article citation data to the citation manager of your choice. Simply select your manager software from the list below and click Download.
 Direct import  
View Options
 Access content 
 Please select your options to get access 
 Login options 
 Check if you have access through your login credentials or your institution to get full access on this article. 
Login or Register  Institutional  Purchase options
 Save for later  Item saved, go to cart 
Buy this article
Dynamical cryptography based on synchronised chaotic systems   $19.99  Add to cart  
 Buy this article  Checkout Knowledge pack (10 download credits)
Dynamical cryptography based on synchronised chaotic systems   $120.00  Add to cart  
 Knowledge pack (10 download credits)  Checkout View options
PDF
View PDFFigures
Tables
Media
Share
Share
Copy the content Link
Copied!
Copying failed.
Share on social media
FacebookX (formerly Twitter)LinkedInEmailDownload PDFNow Reading:Share
Previous article
Bootstrap and aggregating VQ classifier for speaker recognitionPreviousNext article
Efficient method for simulating time delays of distributed interconnections in VLSI circuits NextFigure title goes hereGo to figure location within the articleDownload figureShare on social mediaxrefBack.goTo
Request permissionsAuthors Info & Affiliations
Follow IET
About the IETOur history
Vision and Strategy
Governance
AGMs
Royal Charter and Bye-laws
Our offices
Our venues
Working for the IET
Adverstising and sponsorship
Membership & RegistrationJoin the IET
Benefits of memberships
Manage your membership
Member News
Communities
Professionalism and ethics
IET Library and Archives
E+T magazine
Career & LearningProfessional registration
Professional development
Career Manager
Accreditation
Courses and training
IET Academy
Support for employers
Routes to engineering
STEM education
Career support
Engineering jobs
Intelligence & ResearchPublishing with IET Journals
Publishing with IET Books
Inspec
Subscribe to our content
Bookshop
Wiring Regulations
Codes and guidance
IET.tv - video content and production
IET Library and Archives
IET EventsEvents
Search all events
Get InvolvedVolunteering for IET
Young Professionals
Partnerships
Collaboration
Support future generations
Online community
Impact & SocietySectors
Government policy and submissions
Thought leadership
Our impact in Scotland
Our impact in Northern Ireland
Factfiles
Awards and scholarships
Media HubCampaigns
Press releases
Media support for members
IET social media
© 2026 The Institution of Engineering and Technology   All rights, including for text and data mining, AI training, and similar technologies, are reserved   The Institution of Engineering and Technology is registered as a Charity in England and Wales (no 211014) and Scotland (no SC038698)   Brought to you by Atypon Systems  
Request Username
Can't sign in? Forgot your username?
Enter your email address below and we will send you your username
CloseIf the address matches an existing account you will receive an email with instructions to retrieve your username
Create a new account
 Returning user Change Password 
Too Short   Weak   Medium   Strong   Very Strong   Too Long  
 Your password must have 8 characters or more and contain 3 of the following: 
a lower case character, 
an upper case character, 
a special character 
or a digit  
Too Short  
Password Changed Successfully
Your password has been changed
Login to your account
Forgot password? New User Can't sign in? Forgot your password?
Enter your email address below and we will send you the reset instructions
CancelIf the address matches an existing account you will receive an email with instructions to reset your password
CloseVerify Phone
CancelCongrats!
Your Phone has been verified