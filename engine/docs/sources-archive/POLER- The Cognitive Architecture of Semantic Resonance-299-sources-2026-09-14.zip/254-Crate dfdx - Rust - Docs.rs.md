> Source: https://docs.rs/dfdx

dfdx - Rust
Docs.rs
dfdx-0.13.0
dfdx 0.13.0
Permalink
Docs.rs crate page
MIT OR Apache-2.0
Links
Homepage
Repository
crates.io
Source
Owners
coreylowman
Dependencies
cudarc ^0.9.13 normal
gemm ^0.15.4 normal
half ^2.3.1 normal
libm ^0.2.7 normal
memmap2 ^0.5 normal
no-std-compat ^0.4.1 normal
num-traits ^0.2.15 normal
rand ^0.8.5 normal
rand_distr ^0.4.3 normal
rayon ^1.7.0 normal
safetensors ^0.3 normal
spin ^0.9.8 normal
zip ^0.6.6 normal
indicatif ^0.17.3 dev
mnist ^0.5.0 dev
tempfile ^3.3.0 dev
glob ^0.3.1 build
Versions
60.38% of the crate is documented
Platform
i686-pc-windows-msvc
i686-unknown-linux-gnu
x86_64-apple-darwin
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
☰
Crate dfdx
Crate dfdx
Version 0.13.0
All Items
Modules
Functions
Crates
dfdx
?
Crate dfdx
source
· [−]
Expand description
dfdx
dfdx is a cuda accelerated tensor and neural network library, writtten entirely in rust!
Additionally, it can track compile time shapes across tensor operations, ensuring that all your neural networks are checked at compile time.
The following sections provide some high level core concepts & exmaples, and there is more detailed documentation in each of dfdx's submodules.
See feature_flags for details on feature flags.
Shapes & Tensors
See dtypes, shapes, and tensor for more information.
At its core a tensor::Tensor is just a nd-array. Just like rust arrays there are two parts:
Shape ( shapes)
Dtype ( dtypes)
dfdx represents shapes as tuples of dimensions ( shapes::Dim ), where a dimension can either be known at:
Compile time shapes::Const<M>
Run time usize
You can freely mix and match these dimensions together. Here are some example shapes:
() - unit shape
(usize,) - 1d shape with a runtime known dimension
(usize, Const<5>) - 2d shape with both types of dimensions
(Const<3>, usize, Const<5>) - 3d shape!
Rank3<3, 5, 7> - Equivalent to (Const<3>, Const<5>, Const<7>)
Here are some comparisons between representing nd arrays in rust vs dfdx:
The Rank1 , Rank2 shapes used above are actually type aliases for when all dimensions are compile time:
shapes::Rank0 is just () .
shapes::Rank1<M> is (Const<M>, )
shapes::Rank2<M, N> is (Const<M>, Const<N>)
Allocating tensors with Devices
See tensor for more information.
Devices are used to allocate tensors (and neural networks!). They are akin to std::alloc::GlobalAlloc in rust - they just allocate memory. They are also used to execute tensor ops, which we will get to later on.
There are two options for this currently, with more planned to be added in the future:
tensor::Cpu - for tensors stored on the heap
tensor::Cuda - for tensors stored in GPU memory
Both devices implement Default, you can also create them with a certain seed and ordinal.
Here's how you might use a device:
Tensor Operations (tip of the iceberg)
See tensor_ops for more information
Once you've instantiated tensors with a device, you can start doing operations on them! There are many many operations, here are a few core ones and how they related to things like numpy/pytorch:
and much much more!
Neural networks
See nn for more information.
Neural networks are composed of building blocks that you can chain together. In dfdx, sequential neural networks are represents by tuples! For example, the following two networks are identical:
To build a neural network, you of course need a device:
Note two things:
We are using nn::DeviceBuildExt to instantiate the model
We need to pass a dtype (in this case f32) to create the model.
You can then pass tensors into the model with nn::Module::forward():
Optimizers and Gradients
See optim for more information
dfdx supports a number of the standard optimizers:
You can use optimizers to optimize neural networks (or even tensors!). Here's a simple example of how to do this with nn::ZeroGrads:
Modules
data A collection of useful data utilities such as ExactSizeDataset, OneHotEncode, Arange, and iterator extension traits!
dtypes Module for data type related traits and structs. Contains things like Unit, Dtype, and AMP.
feature_flags Information about the available feature flags.
losses Standard loss functions such as mse_loss(), cross_entropy_with_logits_loss(), and more.
nn High level neural network building blocks such as modules::Linear, activations, and tuples as Module s. Also includes .save() & .load() for all Module s.
optim Optimizers such as Sgd, Adam, and RMSprop that can optimize neural networks.
prelude Contains subset of all public exports.
shapes Shape related traits/structes like Shape, Dtype, Dim, Axis, and Const
tensor The Tensor struct, Cpu & Cuda devices, and traits like ZerosTensor, OnesTensor, SampleTensor.
tensor_ops Operations on tensors like relu(), matmul(), softmax(), and more.
Functions
flush_denormals_to_zero Sets a CPU sse flag to flush denormal floating point numbers to zero. The opposite of this is keep_denormals().
keep_denormals Sets a CPU flag to keep denormal floating point numbers. The opposite of this is flush_denormals_to_zero().