> Source: https://www.researchgate.net/publication/262170316_Cellular_automata_encryption_method_description_evaluation_and_tests

ResearchGate - Temporarily Unavailable 
Access denied
You do not have access to www.researchgate.net.
The site owner may have set restrictions that prevent you from accessing the site.
Ray ID: a085897f48bc0ea2
Timestamp: 2026-06-08 05:36:07 UTC
Your IP address: 74.125.212.229
Requested URL: www.researchgate.net/publication/262170316_Cellular_automata_encryption_method_description_evaluation_and_tests
Error reference number: 1020
Server ID: FL_735F230
User-Agent: Google-NotebookLM
Ray ID: a085897f48bc0ea2
Client IP: 74.125.212.229
© 2008-2026 ResearchGate GmbH. All rights reserved.