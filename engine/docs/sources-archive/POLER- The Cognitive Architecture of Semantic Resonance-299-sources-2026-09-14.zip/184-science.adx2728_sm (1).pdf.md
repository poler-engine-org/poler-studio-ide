 
 
Supplementary Materials for 
 
Dynamics of disordered quantum systems with two- and three-dimensional tensor 
networks 
 Joseph Tindall et al. 
 Corresponding authors: Joseph Tindall, jtindall@flatironinstitute.org; Dries Sels, dsels@bu.edu 
 
Science 392, 868 (2026) 
DOI: 10.1126/science.adx2728 
 
The PDF file includes: 
 
Materials and Methods 
Supplementary Text 
Figs. S1 to S5 
References 
Tensor Network Methodology 
Here we outline our tensor network-based simulation approach in detail. We model the wavefunc-
tion under the time-dependent Hamiltonian 𝐻 (𝑠) in Eq. 1 as a tensor network of low-rank tensors 
whose structure mimics that of the underlying lattice geometry - i.e. for every pair of neighboring 
points in the lattice there exists a virtual edge or bond between the corresponding tensors in the 
tensor network. In the case of the dimerized cubic lattice, we pair the dimers together into a single 
tensor with two physical legs, effectively realizing a regular cubic tensor network. This removes 
the inherent loops that form from couplings in the 𝑧-direction between the spins in the dimers and 
thus make the structure more “tree-like”. 
Belief Propagation and Loop Corrections: In this work we use belief propagation (34, 35, 54) 
and extensions thereof to evolve the tensor network state |𝜓⟩ and compute observables. For evolving 
the state we use regular (non-corrected) belief propagation due to its efficiency and simplicity, which 
is equivalent to performing gate evolution with the standard simple update method (34, 35, 37, 55) 
but reformulated in a more generalizable framework. One method we use for computing observables 
is loop-corrected belief propagation (43) to improve the accuracy of our results beyond the belief 
propagation approximation. Both tasks rely on computing “message tensors” which form rank-one 
projectors to the virtual basis defined on the edges of a tensor network T whose vertices represent 
either individual tensors or groups of tensors. In fig. S1 we illustrate the belief propagation algorithm 
for an example network T where the vertices of the network T𝑣 may represent individual tensors 
or collections of tensors. In the case of a norm network, defined as T = ⟨𝜓 |𝜓⟩, the vertices 
represent uncontracted pairs of bra and ket tensors from |𝜓⟩, that is T𝑣 = 𝜓𝑣𝜓 ∗ 𝑣 . Message tensors are 
defined along the edges of the norm network whose indices match the virtual indices connecting 
the corresponding bra and ket tensors on each end of the edge. A self-consistent update rule is 
defined for each message tensor as 
𝑀𝑣→𝑣′ = ©­« 
∏ 𝑣′′∈{neighbors(𝑣)/𝑣′} 
𝑀𝑣′′→𝑣 ª®¬T𝑣 (S1) 
and this rule is iterated until convergence of the message tensors. Imposing the normalization 
condition 
S2
𝑀𝑣→𝑣′ · 𝑀𝑣′→𝑣 = 1 is helpful both for numerical stability and for later computations with the 
message tensors. For T = ⟨𝜓 |𝜓⟩, a single iteration that updates every message scales as O(𝑁𝜒𝑧+1) 
in time where 𝑁 is the number of tensors in |𝜓⟩, 𝑧 is the maximum coordination of the vertices 
of the graph, and 𝜒 is the maximum dimension of the virtual indices in |𝜓⟩. Convergence of the 
message tensors is typically exponentially fast in the number of iterations. 
The resulting message tensors can be used in a variety of ways. For instance, they can be used 
to perform a truncation following a two-site update with a gate �̂� on a neighboring pair of sites in 
|𝜓⟩ (35). This is the method we adopt in our time-evolution protocol due to its numerical efficiency 
and simplicity. Message tensors can also be used to compute local and non-local observables ⟨𝑂⟩. At 
the simplest, but most approximate, level one just places the message tensors obtained from ⟨𝜓 |𝜓⟩ 
incident to the region of support of 𝑂, inserts 𝑂, and contracts the tensors to obtain the expected 
value of 𝑂. If the network is unnormalized the result can be divided by the same contraction but 
without 𝑂 inserted. Alternatively, belief propagation can be run directly on the network ⟨𝜓 |𝑂 |𝜓⟩, 
grouping together the local bra, ket, and operator tensors, and then the resulting message tensors 
can be used to approximate the contraction of the whole network via the formula 
⟨𝜓 |𝑂 |𝜓⟩ = 
∏ 𝑣∈verts 
( ( 𝜓𝑣𝑂𝑣𝜓 
∗ 𝑣 
) ∏ 𝑣′∈neighbors(𝑣) 𝑀𝑣′→𝑣 
)∏ 𝑒∈edges 𝑀𝑒 · 𝑀reverse(𝑒) 
, (S2) 
which is more appropriate in the case of non-local observables with a large region of support. If 
the network is unnormalized an equivalent contraction should be done on the network ⟨𝜓 |𝜓⟩ and 
used as a divisor. 
Both of the above approaches, however, do not account for the loops in the lattice and thus make 
a fairly severe approximation for correlated states and tensor networks with a larger density of small 
loops. Nonetheless, the messages obtained from belief propagation can be used as a basis from 
which to expand the contraction of a tensor network as a multi-dimensional sum which contains 
“loop-corrected” terms (43). 
In the loop-corrected approach the contraction of the target tensor network T (with tensors or 
tensor groups 𝑇1, 𝑇2, ...𝑇𝑁 ) upon which message tensors have been computed is written as a sum 
over 2𝑁edges configurations involving the placement of either a rank-1 projector P𝑒 = 𝑀←−𝑒 ⊗ 𝑀−→𝑒 or 
an antiprojector I − P𝑒 on each of the edges 𝑒 of the network. Specifically, letting S denote some 
S3
subset of the set of edges 𝐸 , we can define the term 
𝑊S = 
( 𝐿∏ 
𝑣=1 𝑇𝑖 
) (∏ 𝑒∈S (I − P𝑒) 
) ©­« ∏ 
𝑒∈𝐸/S P𝑒ª®¬ , (S3) 
involving the placement of |S| antiprojectors in the specified configuration and 𝑁edges − |S| pro-
jectors on the remaining edges of the network. 
Then, the full contraction of the network is given by the sum 
T = 
𝑁edges∑︁ 𝑖=0 
∑︁ S∈(𝐸𝑖 ) 
𝑊S , (S4) 
where (𝐸 𝑖 
) denotes the set of all subsets of the edges of the tensor network of size 𝑖. It is helpful 
to note that, due to the fixed point condition on the converged message tensors (see Eq. S2), the 
term 𝑊S is zero if there exists any vertex 𝑣 for which only one antiprojector is incident. Since the 
magnitude of a single term 𝑊S should generically decay exponentially with |𝑆 |, an efficient, but 
potentially highly accurate, approximation for the contraction of the network can then be found by 
summing up all nonzero configurations with some maximum threshold number of 𝑙max ≪ 𝑁edges 
antiprojectors, that is 
T ≈ 𝑙max∑︁ 𝑖=0 
∑︁ S∈(𝐸𝑖 ) 
𝑊S . (S5) 
Supplementary Figure S1C shows the loop correction procedure for an example tensor network, 
illustrating all the nonzero 𝑊𝑠 terms that form the sum in Eq. S4. This is the approach we take for 
computing “loop-corrected” observables such as 
⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ = ⟨𝜓 |𝜎𝑧 
𝑖 𝜎𝑧 𝑗 |𝜓⟩ 
⟨𝜓 |𝜓⟩ , (S6) 
for any 𝑖, 𝑗 from the tensor networks |𝜓⟩ we obtain in this work. While ⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ can be computed 
via separate loop-corrected contractions of the numerator and denominator in Eq. S6, we find that 
finding BP fixed points of tensor networks such as ⟨𝜓 |𝜎𝑧 𝑖 𝜎𝑧 𝑗 |𝜓⟩ which are not positive-definite (i.e. 
they are not of the form 𝑂 = 𝑋𝑋†) can be difficult. Thus it is beneficial to first recast ⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ in 
terms of a combination of observables which are all positive-definite: 
⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ = ⟨𝜓 |𝑃↑ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ + ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↓ 𝑗 |𝜓⟩ − ⟨𝜓 |𝑃↑ 
𝑖 𝑃 ↓ 𝑗 |𝜓⟩ − ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ 
⟨𝜓 |𝑃↑ 𝑖 𝑃 ↑ 𝑗 |𝜓⟩ + ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↓ 𝑗 |𝜓⟩ + ⟨𝜓 |𝑃↑ 
𝑖 𝑃 ↓ 𝑗 |𝜓⟩ + ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ 
= ⟨𝜓 |𝑃↑ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ − ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ 
⟨𝜓 |𝑃↑ 𝑖 𝑃 ↑ 𝑗 |𝜓⟩ + ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ (S7) 
S4
where 𝑃 ↑ 𝑖 
and 𝑃 ↓ 𝑖 
are the projectors to spin up and spin down respectively on the given site and 
the last equality follows only due to the Z2 symmetry of the wavefunction ((i.e (∏ 
𝑖 𝜎 𝑥 𝑖 
) |𝜓⟩ = |𝜓⟩) 
which we find to be well preserved during our TN-based evolution despite no explicit encoding of 
symmetries into the tensors. We note that such symmetries could be encoded directly at the level 
of the individual tensors, and potentially improve the efficiency of our calculations—something we 
leave for future work. 
We thus compute ⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ by using loop corrections to contract the two positive definite tensor 
networks ⟨𝜓 |𝑃↑ 𝑖 𝑃 ↑ 𝑗 |𝜓⟩ and ⟨𝜓 |𝑃↓ 
𝑖 𝑃 ↑ 𝑗 |𝜓⟩ and substituting into Eq. S7. In the case the Z2 symmetry 
is not present, loop corrections can be used to approximate the contraction of the four networks 
from Eq. S7 instead. For each network, we group together tensors associated with each site and 
then run belief propagation over the resulting partitioned network (whose vertices represent the 
corresponding groups of tensors) to obtain converged message tensors. We use a well-established 
graphical loop counting algorithm (44, 45) to enumerate short loops in our networks and then 
compose the loops together to efficiently enumerate all configurations for which 𝑊𝑆 is nonzero 
and the number of antiprojectors is less than some amount 𝑙max. We contract these configurations, 
something which can be done in a fully parallelizable manner, and add them up to form a loop-
corrected approximation for ⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩. In the main text we show our results using different values of 
𝑙max. The computational scaling of this approach depends on 𝑙max and the coordination number 𝑧 of 
the underlying lattice. Evaluating T = ⟨𝜓 |𝑂 |𝜓⟩ (where 𝑂 is a product of local spin-1/2 operators 
and tensors sharing site indices are grouped together) with 𝑙max = 0, for instance, can be achieved 
in O(𝑁𝜒𝑧+1) time. Meanwhile, the next order correction will involve 𝑙max being set to the size of 
the shortest loop in the tensor network and its evaluation scales in time linearly in the loop length 
and as O(𝑁𝜒𝑧+2) + O(𝑁𝜒6) with the bond dimension and system size—although we remark that 
if the loop is sufficiently large, methods like randomized SVD or Krylov solvers can be used to 
accelerate the scaling to O(𝑚𝑁𝜒𝑧+1) where 𝑚 is the number of dominant eigenmodes targeted in 
the decomposition (56). 
While in this work we run loop-corrected belief propagation to obtain messages and contract the 
configurations in each network separately, Eq. S4 holds for arbitrary message tensors provided the 
normalization condition 𝑀𝑒 · 𝑀reverse(e) = 1 holds. More efficient ways to obtain multiple observ-
ables at once via loop corrections could be achieved by using a consistent set of message tensors 
S5
(say those from ⟨𝜓 |𝜓⟩ or ⟨𝜓 |𝑂′|𝜓⟩ where 𝑂′ is some subset of the local operators that make up the 
full operator 𝑂) across the expansion of the different observables {⟨𝜓 |𝑂1 |𝜓⟩, ⟨𝜓 |𝑂2 |𝜓⟩, ...} that 
need to be measured. Therefore, we could cache certain loop contractions which appear multiple 
times in the expansion of various observables. Care would need to be taken, however, to ensure the 
message tensors used still form a good basis for each of the individual networks ⟨𝜓 |𝑂𝑖 |𝜓⟩, which 
is likely to be the case only if the support of the relevant observable is small. 
Cylindrical MPS Message Passing: For the case of a cylindrical tensor network we find, for 
sufficiently large cylinder sizes, that cylindrical message passing is a more effective method than loop 
corrections for computing two-point observables in the network. This method can still be viewed 
as a variant of belief propagation (see also Ref. (57) which introduces a related hybridization of the 
boundary MPS and BP algorithms) where the network has been partitioned via its columns into a 
ring and MPS messages leaving a column are iteratively updated as the truncated product of the 
incoming message to that column and the column itself (see fig. S2A). Upon convergence the two 
MPS messages incident to a column form an approximation for the derivative of the network with 
respect to that column. The degree of the approximation depends on two factors: the maximum 
virtual bond dimension allowed in the MPS message tensors and the circumference of the cylinder. 
The latter is an error that occurs due to the periodic boundary in the system, with the MPS messages 
effectively ignoring the correlations which flow around the circumference of the cylinder. This error 
will generically decay exponentially in the circumference of the cylinder (see Fig. 3 of the main 
text), making the method highly effective for large cylinders. 
To compute a MPS message update, we take the outgoing message |𝑀𝑐→𝑐+1⟩ from a column of 
tensors T𝑐 to be the one with a fixed virtual dimension 𝑅 that maximizes the cost function 
𝐶 = ⟨𝑀𝑐−1→𝑐 |T𝑐 |𝑀𝑐→𝑐+1⟩√︁ ⟨𝑀𝑐→𝑐+1 |𝑀𝑐→𝑐+1⟩ 
. (S8) 
Assuming the incoming message is fixed, we set the orthogonality center of |𝑀𝑐→𝑐+1⟩ to the 
tensor on a given site 𝑠 and then differentiate the cost function with respect to that tensor. An 
update of that tensor that maximizes the cost function should then be equal to the contraction 
of ⟨𝑀𝑐−1→𝑐 |T𝑐 |𝑀𝑐→𝑐+1⟩ with the tensor removed (see fig. S2B). The fitting can thus be done by 
forming an initial guess for |𝑀𝑐→𝑐+1⟩, iteratively moving the orthogonality center up and down 
S6
the MPS, and replacing the tensor with the derivative of ⟨𝑀𝑐−1→𝑐 |T𝑐 |𝑀𝑐→𝑐+1⟩ with respect to that 
tensor. The cost function should then converge and the next MPS can be updated until they all 
converge. For the cylindrical tensor network T = ⟨𝜓 |𝑂 |𝜓⟩, where 𝑂 is a product of local spin-1/2 
operators, identifying the optimal contract order of the tensors leads to a computational scaling in 
time of O(𝑅3𝜒5) if 𝑅 ≤ 𝜒 and O(𝑅2𝜒6) + O(𝑅3𝜒4) if 𝑅 > 𝜒. In this work we set 𝑅 = 2𝜒 for 
our desired accuracy, giving a scaling of O(𝑁𝜒8). This approach generalizes immediately to any 
tensor network T which forms an open-boundary or half-periodic planar lattice, with the scaling 
increasing with the coordination number 𝑧 of the lattice. 
This MPS message passing method can be exploited further to efficiently compute multi-point 
correlators in the system and we do so in this work. Specifically, consider the goal of computing the 
set of 𝑁 two-point correlators {⟨𝜎𝑧 𝑖 𝜎𝑧 
1⟩, ⟨𝜎 𝑧 𝑖 𝜎𝑧 
2⟩, ⟨𝜎 𝑧 𝑖 𝜎𝑧 
3⟩ . . . ⟨𝜎 𝑧 𝑖 𝜎𝑧 𝑁 ⟩} between site 𝑖 and the remain-
ing sites in the lattice. By performing our correlated MPS message passing on the positive-definite 
network ⟨𝜓 |𝑃↑ 𝑖 |𝜓⟩, where 𝑃 
↑ 𝑖 
is the spin up projector on site 𝑖, and then systematically zig-zagging 
through the columns with the incident MPS messages inserted, we can extract all the one-site re-
duced density matrices, conditioned on the projection of site 𝑖 to spin up. In the system at hand the 
wavefunction is Z2 symmetric (i.e (∏ 
𝑖 𝜎 𝑥 𝑖 
) |𝜓⟩ = |𝜓⟩) and so this information is all that is required 
to compute the set {⟨𝜎𝑧 𝑖 𝜎𝑧 
1⟩, ⟨𝜎 𝑧 𝑖 𝜎𝑧 
2⟩, ⟨𝜎 𝑧 𝑖 𝜎𝑧 
3⟩ . . . ⟨𝜎 𝑧 𝑖 𝜎𝑧 𝑁 ⟩} in linear time. This method can then be 
reapplied for each site 𝑖 to compute all two-point correlators in O(𝑁2) time. This approach can be 
generalised to cases without theZ2 symmetry by insertion of the operator𝜎𝑧 𝑖 
instead of the projector. 
Gate evolution: The tensor network at renormalized time 𝑠 = 𝑡 𝑡𝑎 
is evolved by a discrete time 
step 𝛿𝑡 via the application of a series of one- and two-site gates which stem from a 2nd order Trotter 
decomposition of the full propagator 
𝑈 (𝑠) = exp(−i𝐻 (𝑠)𝛿𝑡) ≈ 𝑈X(𝑠)𝑈ZZ(𝑠)𝑈X(𝑠) (S9) 
with 
𝑈X(𝑠) = 𝐿∏ 𝑖=1 
exp ( −i 
𝛿𝑡 
2 Γ(𝑠)𝜎𝑥 
𝑖 
) (S10) 
and 
𝑈ZZ(𝑠) = ∏ ⟨𝑖, 𝑗⟩ 
exp(−i𝛿𝑡J (𝑠)𝜎𝑧 𝑖 𝜎𝑧 𝑗 ). (S11) 
S7
The time step 𝛿𝑡 = 0.01ns we use is enough for the Trotter error to remain sufficiently low for the 
accuracy needed in this work. 
The one-site gates in Eq. S10 can be applied directly to the tensor network without any loss 
of fidelity or change in the message tensors. Meanwhile, all the two site gates in Eq. S11 act on 
neighboring tensors in the network and thus we can efficiently use belief propagation-computed 
environments (see fig. S1B for an illustration on how to compute these environments) to truncate 
the virtual bond between the corresponding neighboring tensors upon applying the gate. This is 
equivalent to applying the gate using the standard simple update algorithm (34–37, 58). The total 
time complexity for the simulation of the dynamics is thus O ( 𝑁𝜒𝑧+1 𝑡𝑎 
𝛿𝑡 
) where 𝑁 is the number 
of qubits, 𝜒 is the maximum bond dimension allowed in the simulation, and 𝑧 is the maximum 
coordination number of the vertices in the underlying lattice (4 for cylindrical, 4 for diamond cubic, 
and 6 for the dimerized cubic). To initialize the system in the ground state of 𝐻 (0) we run imaginary 
time evolution with the same simple update procedure as we do for the dynamics. As the ground 
state has only very small correlations (J (0) ≫ Γ(0)) this is sufficient to obtain a highly accurate 
initial state. 
The final truncation that we perform in the cylindrical lattice case before measuring observables 
is done via belief propagation (35). Note that to obtain the highest accuracy truncation under the 
BP approximation, one can re-run belief propagation to obtain converged message tensors and use 
those to perform the truncation, though for small truncation errors and Trotter step sizes the final 
messages obtained from the evolution may be sufficiently converged already. 
System size scaling analysis for three-dimensional diamond simulations 
Here we provide extensive data and analysis for tensor network simulations on diamond lattices 
ranging in size from 18 qubits (𝐿𝑥 ×𝐿𝑦×𝐿𝑧 = 3×3×8) to 900 qubits (𝐿𝑥 ×𝐿𝑦×𝐿𝑧 = 12×12×24). 
Due to the linear scaling with system size of our simulations for a fixed annealing time and bond 
dimension, such system sizes are possible with moderate computational resources. Moreover, there 
are several metrics we can efficiently compute that attest to the “quality” of the simulation. 
The first of these is the average gate error 𝜖𝑔 which we compute following the time evolution of 
S8
the tensor network via 
𝜖𝑔 = ©­«1 − 
𝑛∏ 𝑔=1 (1 − 𝜖𝑔)ª®¬ 
1 𝑛 
(S12) 
where the product is over all 𝑛 two-qubit gates applied to the tensor network during the simulation 
and 𝜖𝑔 is defined as the individual gate error 
𝜖𝑔 = 
𝜒′∑︁ 𝑖=𝜒+1 
𝜎2 𝑖 , (S13) 
i.e. the sum of the square of the discarded singular values during the SVD performed following the 
application of a gate �̂� (where the normalization ∑𝜒′ 
𝑖=1 𝜎 2 𝑖 = 1 is enforced) to the tensor network 
representation of the state |𝜓𝑡−𝛿𝑡⟩. On a tree tensor network, 𝜖𝑔 is precisely the individual gate 
error (59), 1 − |⟨𝜓𝑡 |�̂� |𝜓𝑡−𝛿𝑡⟩|2 while on a loopy network it is a good approximation (31,60). 
Our second metric is based on the strength of the first order loop corrections in the tensor 
network following evolution. Specifically we take a random sample of 𝑁 two-point correlators 
⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ where the pair of sites 𝑖 and 𝑗 are separated by a fixed path length 𝑑 and compute 
𝜖BP(𝑑) = 100 · ∑ (𝑖, 𝑗) |⟨𝜎𝑧 
𝑖 𝜎𝑧 𝑗 ⟩𝑙max=6 − ⟨𝜎𝑧 
𝑖 𝜎𝑧 𝑗 ⟩𝑙max=0 |∑ 
(𝑖, 𝑗) |⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩𝑙max=6 | 
, dist(𝑖, 𝑗) = 𝑑 (S14) 
which is a relative measure (as a percentage) of how much the smallest loops in the lattice affect 
correlators at the given distance 𝑑. 
In fig. S3A we show how the average gate error scales with system size in 3D diamond lattices 
for several annealing times (𝑡𝑎 ∈ {4ns, 7ns, 15ns}) and bond dimensions (𝜒 ∈ {8, 16, 32}). In all 
cases increasing the bond dimension leads to systematically lower gate errors while increasing the 
annealing time leads to larger gate errors, which is also observed for the cylindrical lattice in fig. 2 
of the main text. Most notable, however, is the clear saturation of gate error for system sizes of∼ 100 
qubits and beyond. This data indicates that increasing system size beyond this point does not lead 
to lower accuracy in terms of gate errors or local fidelity of the tensor network. It should be noted 
that this saturation trend seems consistent with the saturation trend that appears to be emerging in 
the ground-truth-based errors plotted in Fig. 3B of the main text and thus provides strong evidence 
that fixed accuracy results can be obtained with linear resources for a fixed annealing time. 
In fig. S3B we show how the deviation between the BP and first-order loop-corrected results 
for third nearest neighbor correlators (𝑑 = 3) varies with system size. Again, after a short initial 
S9
increase with system size, the loop correlations appear to saturate with system size, suggesting that 
at fixed annealing times loop effects are stable with increasing system size. This means that we 
do not require increasing orders of loop corrections with system size to compute a correlator to a 
desired accuracy. 
Finally, in fig. S4 we provide walltimes for 3D diamond simulations as a function of system 
size. In fig. S4A we provide timings for CPU-based simulations of the BP-based time evolution, 
demonstrating clear linear scaling with system size for fixed bond dimension and annealing time. 
Meanwhile, in fig. S4B we provide timing data for measuring a single randomly selected 𝑧 − 𝑧 
correlator on both a CPU and GPU for several bond dimensions. Again, all results show clear 
linear scaling with system size. Notably, there is a dramatic speedup obtained by using a GPU to 
take the measurement at larger bond dimensions, reaching a 10× speedup for 𝜒 = 32 on the given 
diamond lattices. Both the contractions necessary to converge the BP message tensors and contract 
the necessary loops are performed on the respective hardware. 
Details of Kibble Zurek collapses 
In fig. 4B of the main text we show collapse of both the spin glass order parameter and distance-
dependent correlation function for diamond and cylindrical lattices respectively. Here we provide 
further details on the collapse performed and how we determine the Kibble-Zurek exponent 𝜇 and 
non-trivial fitting parameter 𝑟. 
In the cylindrical case, a cylindrical tensor network approach is used, with a belief propagation-
based time evolution protocol of the Trotterized circuit implemented with a maximum bond di-
mension 𝜒BP = 32. The final state is truncated down, with BP, to bond dimension 𝜒 = 8 and MPS 
message passing with a MPS rank of 𝑅 = 16 is used to calculate the relevant 𝑧 − 𝑧 correlators. 
We calculate the correlation function 
𝐶 (𝑑) = |⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ − ⟨𝜎𝑧 
𝑖 ⟩⟨𝜎𝑧 
𝑗 ⟩| 
dist(𝑖, 𝑗)=𝑑 , (S15) 
where the average is taken over ten disorder realizations and dist(𝑖, 𝑗) is defined as the length of the 
path (i.e. the Manhattan distance) between the qubits 𝑖 and 𝑗 . We only consider qubits that lie along 
the same column in the cylinder, ignore the qubits at the end of each column, and ensure one of the 
qubits in the correlator is in the center of the column to minimize boundary effects. We find that, 
S10
for a given annealing time and cylinder size, the correlation function fits a compressed exponential 
function (48,49) 𝐶 (𝑑) ∼ 𝑎0 exp(−𝑎1𝑑 𝛼) with 𝛼 > 1 over moderate distances (𝑑 < 10). We observe 
𝛼 ∼ 1.3. 
Upon rescaling the distance as 𝑑 = 𝑡 − 1 
𝜇 
𝑎 𝑑 where 𝜇 is the Kibble-Zurek exponent we then 
observe the anticipated collapse of the correlation function (3). The Kibble-Zurek exponent was 
very recently estimated in Ref. (50) with extensive Monte Carlo simulations of the corresponding 
classical model in 2 + 1D. A value of 𝜇 = 2.6± 0.3 was obtained for the finite-size systems studied 
while scaling arguments led to an estimation of 𝜇 = 3.17 ± 0.41 in the thermodynamic limit. 
Here we obtain a value for 𝜇 for a given cylinder size by finding the value where the data gives 
the best fit (in terms of the sum of the absolute values of the relative residuals) to the compressed 
exponential: 𝐶 (𝑑) ∼ 𝑎0 exp(−𝑎1𝑑 𝛼) where 𝑎0, 𝑎1, and 𝛼 are free fitting parameters determined 
from a least-squares fitting. We see a collapse over many orders of magnitude and the curve fitting 
the data excellently. For the largest cylinder (18×18) we obtain a best fit to the disorder-averaged data 
with 𝜇 ≈ 2.75 which is consistent with the finite-size prediction of Ref. (50) and from the collapse 
of the Binder cumulant for the three largest cylinders in Ref. (20) which yielded 𝜇 = 2.67 ± 0.29. 
In the diamond case, a diamond tensor network approach is used, with a belief propagation-based 
time evolution protocol of the Trotterized circuit implemented with a maximum bond dimension 
𝜒 = 16. Loop corrections with 𝑙max = 6 is used to calculate the relevant 𝑧 − 𝑧 correlators. 
For each annealing time and system size, the spin glass order parameter 
⟨𝑞2⟩ = 2 𝑁 (𝑁−1) 
∑ 𝑖< 𝑗 ⟨𝜎𝑧 
𝑖 𝜎𝑧 𝑗 ⟩2 is estimated from a random sample of 500 of the correlators. Data is 
then averaged over 5 independent disorder realizations. We consider the range of system sizes 
𝐿𝑥 , 𝐿𝑦, 𝐿𝑧 = (8, 8, 8), (8, 8, 12), (8, 8, 12), (10, 10, 16), with 𝐿 = 3 √︃ 
𝐿𝑥𝐿𝑦𝐿𝑧 
4 the cube root of the 
number of qubits. 
Collapse is then performed by rescaling ⟨𝑞2⟩ with 𝐿𝑟 and the annealing time 𝑡𝑎 with 𝐿−𝜇. We 
use a value of 𝜇 = 2.85 from the literature on 3D Ising Spin glasses (20, 47) and determine the 
non-trivial parameter 𝑟 ≈ 0.17 by identifying the value of 𝑟 which best collapses (i.e. minimizes the 
residual in a least-squares fitting) the data to a straight line in the (𝑥, 𝑦) = ( log(⟨𝑞2⟩𝐿𝑟), log(𝑡𝑎𝐿−𝜇) 
) plane. 
S11
Offsetting Truncations During Time Evolution 
In our simulations of the dynamics of Eq. 1 for the cylindrical spin-glass we use a bond dimension 
during the evolution of 𝜒BP = 32 before truncating to a lower bond dimension 𝜒 < 32 to enable the 
use of more accurate corrections of belief propagation to measure observables (whose computational 
scaling is higher than uncorrected belief propagation). We find this “overshooting” of the bond-
dimension with belief propagation based simple update highly effective in comparison to keeping the 
bond-dimension constant and lower throughout the simulation, i.e. identical for both the evolution 
and measurement phases of the simulation. 
This is shown explicitly in fig. S5 where we provide a comparison of the final error 𝜖𝑐 of the 
simulation for 𝜒BP = 32 and 𝜒BP = 𝜒, where 𝜒 is the bond dimension of the state at two different 
annealing times on the 8 × 8 cylindrical lattice. The effect of maintaining a larger value of 𝜒BP 
during the evolution is clear and leads to a large error reduction. This mode of simulation can be 
seen as “offsetting” significant truncations until the final state is obtained, where the truncation can 
then be done more faithfully with respect to the desired state. 
In the case of the three-dimensional lattices, the lowest orders of loop corrections are generally 
more affordable than MPS message passing with 𝑅 = O(𝜒) on the cylinder and thus we find we can 
obtain maintain a consistent, relatively high, bond dimension during the evolution and do not need 
to perform a final truncation to enable the use of loop corrections—although we still anticipate 
using a larger 𝜒BP may lead to an improvement in the error. 
Complementary Work 
Following the initial release of this paper, we became aware of a complementary effort which 
focussed on classically simulating the 𝑡𝑎 = 7ns quenches on 𝑁 ≤ 128 diamond lattices with 
time-dependent variational Monte Carlo (61). 
Software 
All of our simulations were performed using the TensorNetworkQuantumSimulator.jl (52) 
library, an open-source and publicly available Julia (62) package for quantum simulation with 
general tensor networks built on top of ITensors.jl (63). 
S12
Figure S1: (A) Tensor network on a simple 5-vertex graph. The vertices may represent individual 
tensors or groups of tensors. (B) Belief propagation involves defining message tensors along both 
directions of the edges of the norm network with the indices of the message tensors matching 
the virtual indices of the bra and ket tensors along that edge. An update rule is defined for every 
message tensor as the product of the messages incident to the vertex the message is leaving and the 
tensors on the vertex. This rule is iterated until all messages are converged, with a normalization 
rule imposed for numerical stability. (C) The outer product of the two message tensors on an 
edge of T form a projector P𝑒 to a rank-1 subspace. The full contraction of the network can then 
be written as a sum over all 2𝑁edges configurations involving either a projector or its antiprojector 
I − P𝑒. Only the nonzero terms are shown: any configuration where there exists a vertex where 
only one antiprojector is incident is zero. The contraction of the network can then be approximated 
by summing configurations up to a certain number of antiprojectors, with the term with zero 
antiprojectors corresponding to the uncorrected belief propagation result. 
S13
Figure S2: (A) Matrix product state message passing on a cylindrical tensor network. The tensors in 
the network could represent single tensors or groups of tensors. Matrix product states are repeatedly 
passed around the cylinder a finite number of times until they converge. (B) One-site optimization 
procedure for the matrix product state message passing. An initial matrix product state is used 
as a guess for the outgoing MPS from the product of an incoming matrix product state and the 
column. The tensor on the orthogonality center of the outgoing MPS can be updated with the 
derivative of the corresponding MPS-MPO-MPS network with respect to that tensor. By repeatedly 
sweeping up and down the MPS, moving the orthogonality center and caching contractions of the 
MPS-MPO-MPS structure, the sites of the outgoing MPS can be efficiently optimized one-by-one 
until convergence of the cost function. 
S14
Figure S3: Error metrics for tensor network simulations of 3D diamond inputs across a range of 
increasing system sizes. Each column shows a different annealing time. (A) Average two-qubit gate 
error (see Eq. S12) versus system size and for various bond dimensions. (B) Averaged relative 
difference (as a percentage) (see Eq. S14) between belief propagation (𝑙max = 0) and first order 
(𝑙max = 6) loop corrections for third nearest neighbor correlators. Given the fast saturation of 
the results with system size, we choose not to run the 𝜒 = 32 results for larger system sizes for 
environmental reasons, though we emphasize that the calculations scale only linearly with system 
size for a given bond dimension 
. 
S15
Figure S4: Walltimes for tensor network simulations of 3D diamond inputs across a range of 
increasing system sizes. Dotted lines represent linear fits. (A) Two different annealing times (left 
and right panel) and CPU walltime for BP-based time evolution for simulating the time-evolution 
(𝑠 = 0 to 𝑠 = 0.6). Walltimes are based on multi-threaded simulations using 8 cores of a single Intel 
Icelake CPU and averaged over 5 disorder instances. (B) Walltimes for measuring a single randomly 
chosen 𝑧 − 𝑧 correlator from 3D tensor networks of various bond dimensions (left, center, and right 
panel). In all cases 32-bit floating point precision is used and the tensor network is that obtained 
with BP-based simple update following an annealing protocol with 𝑡𝑎 = 7ns. CPU walltime is based 
on a multithreaded simulation using 8 cores of a single Intel Xeon Gold 6244 CPU. GPU walltime 
is based on a simulation using an Nvidia RTX A6000 GPU. For large bond dimensions we measure 
a tenfold speedup when using the GPU versus the CPU. 
S16
Figure S5: Error 𝜖𝑐—see Eq. 2—from two-dimensional tensor network simulations of a quantum 
annealing protocol for a disordered 8×8 cylindrical spin glass. The same 𝑁 = 20 disorder realization 
are used as in Ref. (20). Error bars correspond to double the standard error on the mean. We run a 
BP-based evolution protocol of the Trotterized circuit with a maximum bond dimension 𝜒BP and 
(in the case 𝜒BP > 𝜒) truncate down, with BP, to a final state of bond dimension 𝜒 before using 
cylindrical boundary MPS with a MPS rank of 𝑅 = 2𝜒 to calculate ⟨𝜎𝑧 𝑖 𝜎𝑧 𝑗 ⟩ ∀𝑖, 𝑗 . 
S17
References and notes 
1. X. Mi, M. Ippoliti, C. Quintana, A. Greene, Z. Chen, J. Gross, F. Arute, K. Arya, J. Atalaya, 
R. Babbush, J. C. Bardin, J. Basso, A. Bengtsson, A. Bilmes, A. Bourassa, L. Brill, M. 
Broughton, B. B. Buckley, D. A. Buell, B. Burkett, N. Bushnell, B. Chiaro, R. Collins, 
W. Courtney, D. Debroy, S. Demura, A. R. Derk, A. Dunsworth, D. Eppens, C. Erickson, 
E. Farhi, A. G. Fowler, B. Foxen, C. Gidney, M. Giustina, M. P. Harrigan, S. D. 
Harrington, J. Hilton, A. Ho, S. Hong, T. Huang, A. Huff, W. J. Huggins, L. B. Ioffe, S. 
V. Isakov, J. Iveland, E. Jeffrey, Z. Jiang, C. Jones, D. Kafri, T. Khattar, S. Kim, A. 
Kitaev, P. V. Klimov, A. N. Korotkov, F. Kostritsa, D. Landhuis, P. Laptev, J. Lee, K. 
Lee, A. Locharla, E. Lucero, O. Martin, J. R. McClean, T. McCourt, M. McEwen, K. C. 
Miao, M. Mohseni, S. Montazeri, W. Mruczkiewicz, O. Naaman, M. Neeley, C. Neill, M. 
Newman, M. Y. Niu, T. E. O’Brien, A. Opremcak, E. Ostby, B. Pato, A. Petukhov, N. C. 
Rubin, D. Sank, K. J. Satzinger, V. Shvarts, Y. Su, D. Strain, M. Szalay, M. D. 
Trevithick, B. Villalonga, T. White, Z. J. Yao, P. Yeh, J. Yoo, A. Zalcman, H. Neven, S. 
Boixo, V. Smelyanskiy, A. Megrant, J. Kelly, Y. Chen, S. L. Sondhi, R. Moessner, K. 
Kechedzhi, V. Khemani, P. Roushan, Time-crystalline eigenstate order on a quantum 
processor. Nature 601, 531–536 (2022). doi:10.1038/s41586-021-04257-w Medline 
2. M. Iqbal, N. Tantivasadakarn, T. M. Gatterman, J. A. Gerber, K. Gilmore, D. Gresh, A. 
Hankin, N. Hewitt, C. V. Horst, M. Matheny, T. Mengle, B. Neyenhuis, A. Vishwanath, 
M. Foss-Feig, R. Verresen, H. Dreyer, Topological order from measurements and feed-
forward on a trapped ion quantum computer. Commun. Phys. 7, 205 (2024). 
doi:10.1038/s42005-024-01698-3 
3. A. Keesling, A. Omran, H. Levine, H. Bernien, H. Pichler, S. Choi, R. Samajdar, S. Schwartz, 
P. Silvi, S. Sachdev, P. Zoller, M. Endres, M. Greiner, V. Vuletić, M. D. Lukin, Quantum 
Kibble-Zurek mechanism and critical dynamics on a programmable Rydberg simulator. 
Nature 568, 207–211 (2019). doi:10.1038/s41586-019-1070-1 Medline 
4. M. Buzzi, D. Nicoletti, M. Fechner, N. Tancogne-Dejean, M. A. Sentef, A. Georges, T. 
Biesner, E. Uykur, M. Dressel, A. Henderson, T. Siegrist, J. A. Schlueter, K. Miyagawa, 
K. Kanoda, M.-S. Nam, A. Ardavan, J. Coulthard, J. Tindall, F. Schlawin, D. Jaksch, A. 
Cavalleri, Photomolecular high-temperature superconductivity. Phys. Rev. X 10, 031028 
(2020). doi:10.1103/PhysRevX.10.031028 
5. P. Frey, S. Rachel, Realization of a discrete time crystal on 57 qubits of a quantum computer. 
Sci. Adv. 8, eabm7652 (2022). doi:10.1126/sciadv.abm7652 Medline 
6. Q. Guo, C. Cheng, H. Li, S. Xu, P. Zhang, Z. Wang, C. Song, W. Liu, W. Ren, H. Dong, R. 
Mondaini, H. Wang, Stark many-body localization on a superconducting quantum 
processor. Phys. Rev. Lett. 127, 240502 (2021). doi:10.1103/PhysRevLett.127.240502 
Medline 
7. J. Smith, A. Lee, P. Richerme, B. Neyenhuis, P. W. Hess, P. Hauke, M. Heyl, D. A. Huse, C. 
Monroe, Many-body localization in a quantum simulator with programmable random 
disorder. Nat. Phys. 12, 907–911 (2016). doi:10.1038/nphys3783 
8. M. Schiró, M. Fabrizio, Time-dependent mean field theory for quench dynamics in correlated 
electron systems. Phys. Rev. Lett. 105, 076401 (2010). 
doi:10.1103/PhysRevLett.105.076401 Medline 
9. K. Ido, T. Ohgoe, M. Imada, Time-dependent many-variable variational Monte Carlo method 
for nonequilibrium strongly correlated electron systems. Phys. Rev. B Condens. Matter 
Mater. Phys. 92, 245106 (2015). doi:10.1103/PhysRevB.92.245106 
10. M. Yang, S. R. White, Time-dependent variational principle with ancillary Krylov subspace. 
Phys. Rev. B 102, 094315 (2020). doi:10.1103/PhysRevB.102.094315 
11. K. Donatella, Z. Denis, A. Le Boité, C. Ciuti, Dynamics with autoregressive neural quantum 
states: Application to critical quench dynamics. Phys. Rev. A 108, 022210 (2023). 
doi:10.1103/PhysRevA.108.022210 
12. I. L. Gutiérrez, C. B. Mendl, Real time evolution with neural-network quantum states. 
Quantum) 6, 627 (2022). doi:10.22331/q-2022-01-20-627 
13. B. Kloss, D. R. Reichman, Y. Bar Lev, Studying dynamics in two-dimensional quantum 
lattices using tree tensor network states. SciPost Phys. 9, 070 (2020). 
doi:10.21468/SciPostPhys.9.5.070 
14. S. Paeckel, T. Köhler, A. Swoboda, S. R. Manmana, U. Schollwöck, C. Hubig, Time-
evolution methods for matrix-product states. Ann. Phys. 411, 167998 (2019). 
doi:10.1016/j.aop.2019.167998 
15. J. Wurtz, A. Polkovnikov, D. Sels, Cluster truncated Wigner approximation in strongly 
interacting systems. Ann. Phys. 395, 341–365 (2018). doi:10.1016/j.aop.2018.06.001 
16. R. Khasseh, A. Russomanno, M. Schmitt, M. Heyl, R. Fazio, Discrete truncated Wigner 
approach to dynamical phase transitions in Ising models after a quantum quench. Phys. 
Rev. B 102, 014303 (2020). doi:10.1103/PhysRevB.102.014303 
17. A. Sinibaldi, C. Giuliani, G. Carleo, F. Vicentini, Unbiasing time-dependent Variational 
Monte Carlo by projected quantum evolution. Quantum (Vienna) 7, 1131 (2023). 
doi:10.22331/q-2023-10-10-1131 
18. F. Arute, K. Arya, R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F. 
G. S. L. Brandao, D. A. Buell, B. Burkett, Y. Chen, Z. Chen, B. Chiaro, R. Collins, W. 
Courtney, A. Dunsworth, E. Farhi, B. Foxen, A. Fowler, C. Gidney, M. Giustina, R. 
Graff, K. Guerin, S. Habegger, M. P. Harrigan, M. J. Hartmann, A. Ho, M. Hoffmann, T. 
Huang, T. S. Humble, S. V. Isakov, E. Jeffrey, Z. Jiang, D. Kafri, K. Kechedzhi, J. Kelly, 
P. V. Klimov, S. Knysh, A. Korotkov, F. Kostritsa, D. Landhuis, M. Lindmark, E. 
Lucero, D. Lyakh, S. Mandrà, J. R. McClean, M. McEwen, A. Megrant, X. Mi, K. 
Michielsen, M. Mohseni, J. Mutus, O. Naaman, M. Neeley, C. Neill, M. Y. Niu, E. 
Ostby, A. Petukhov, J. C. Platt, C. Quintana, E. G. Rieffel, P. Roushan, N. C. Rubin, D. 
Sank, K. J. Satzinger, V. Smelyanskiy, K. J. Sung, M. D. Trevithick, A. Vainsencher, B. 
Villalonga, T. White, Z. J. Yao, P. Yeh, A. Zalcman, H. Neven, J. M. Martinis, Quantum 
supremacy using a programmable superconducting processor. Nature 574, 505–510 
(2019). doi:10.1038/s41586-019-1666-5 Medline 
19. A. Morvan, B. Villalonga, X. Mi, S. Mandrà, A. Bengtsson, P. V. Klimov, Z. Chen, S. Hong, 
C. Erickson, I. K. Drozdov, J. Chau, G. Laun, R. Movassagh, A. Asfaw, L. T. A. N. 
Brandão, R. Peralta, D. Abanin, R. Acharya, R. Allen, T. I. Andersen, K. Anderson, M. 
Ansmann, F. Arute, K. Arya, J. Atalaya, J. C. Bardin, A. Bilmes, G. Bortoli, A. Bourassa, 
J. Bovaird, L. Brill, M. Broughton, B. B. Buckley, D. A. Buell, T. Burger, B. Burkett, N. 
Bushnell, J. Campero, H.-S. Chang, B. Chiaro, D. Chik, C. Chou, J. Cogan, R. Collins, P. 
Conner, W. Courtney, A. L. Crook, B. Curtin, D. M. Debroy, A. D. T. Barba, S. Demura, 
A. D. Paolo, A. Dunsworth, L. Faoro, E. Farhi, R. Fatemi, V. S. Ferreira, L. F. Burgos, E. 
Forati, A. G. Fowler, B. Foxen, G. Garcia, É. Genois, W. Giang, C. Gidney, D. Gilboa, 
M. Giustina, R. Gosula, A. G. Dau, J. A. Gross, S. Habegger, M. C. Hamilton, M. 
Hansen, M. P. Harrigan, S. D. Harrington, P. Heu, M. R. Hoffmann, T. Huang, A. Huff, 
W. J. Huggins, L. B. Ioffe, S. V. Isakov, J. Iveland, E. Jeffrey, Z. Jiang, C. Jones, P. 
Juhas, D. Kafri, T. Khattar, M. Khezri, M. Kieferová, S. Kim, A. Kitaev, A. R. Klots, A. 
N. Korotkov, F. Kostritsa, J. M. Kreikebaum, D. Landhuis, P. Laptev, K.-M. Lau, L. 
Laws, J. Lee, K. W. Lee, Y. D. Lensky, B. J. Lester, A. T. Lill, W. Liu, W. P. Livingston, 
A. Locharla, F. D. Malone, O. Martin, S. Martin, J. R. McClean, M. McEwen, K. C. 
Miao, A. Mieszala, S. Montazeri, W. Mruczkiewicz, O. Naaman, M. Neeley, C. Neill, A. 
Nersisyan, M. Newman, J. H. Ng, A. Nguyen, M. Nguyen, M. Y. Niu, T. E. O’Brien, S. 
Omonije, A. Opremcak, A. Petukhov, R. Potter, L. P. Pryadko, C. Quintana, D. M. 
Rhodes, C. Rocque, E. Rosenberg, N. C. Rubin, N. Saei, D. Sank, K. Sankaragomathi, K. 
J. Satzinger, H. F. Schurkus, C. Schuster, M. J. Shearn, A. Shorter, N. Shutty, V. Shvarts, 
V. Sivak, J. Skruzny, W. C. Smith, R. D. Somma, G. Sterling, D. Strain, M. Szalay, D. 
Thor, A. Torres, G. Vidal, C. V. Heidweiller, T. White, B. W. K. Woo, C. Xing, Z. J. 
Yao, P. Yeh, J. Yoo, G. Young, A. Zalcman, Y. Zhang, N. Zhu, N. Zobrist, E. G. Rieffel, 
R. Biswas, R. Babbush, D. Bacon, J. Hilton, E. Lucero, H. Neven, A. Megrant, J. Kelly, 
P. Roushan, I. Aleiner, V. Smelyanskiy, K. Kechedzhi, Y. Chen, S. Boixo, Phase 
transitions in random circuit sampling. Nature 634, 328–333 (2024). doi:10.1038/s41586-
024-07998-6 Medline 
20. A. D. King, A. Nocera, M. M. Rams, J. Dziarmaga, R. Wiersema, W. Bernoudy, J. 
Raymond, N. Kaushal, N. Heinsdorf, R. Harris, K. Boothby, F. Altomare, M. Asad, A. J. 
Berkley, M. Boschnak, K. Chern, H. Christiani, S. Cibere, J. Connor, M. H. Dehn, R. 
Deshpande, S. Ejtemaee, P. Farre, K. Hamer, E. Hoskinson, S. Huang, M. W. Johnson, S. 
Kortas, E. Ladizinsky, T. Lanting, T. Lai, R. Li, A. J. R. MacDonald, G. Marsden, C. C. 
McGeoch, R. Molavi, T. Oh, R. Neufeld, M. Norouzpour, J. Pasvolsky, P. Poitras, G. 
Poulin-Lamarre, T. Prescott, M. Reis, C. Rich, M. Samani, B. Sheldan, A. Smirnov, E. 
Sterpka, B. Trullas Clavera, N. Tsai, M. Volkmann, A. M. Whiticar, J. D. Whittaker, W. 
Wilkinson, J. Yao, T. J. Yi, A. W. Sandvik, G. Alvarez, R. G. Melko, J. Carrasquilla, M. 
Franz, M. H. Amin, Beyond-classical computation in quantum simulation. Science 388, 
199–204 (2025). Medline 
21. S. Ebadi, T. T. Wang, H. Levine, A. Keesling, G. Semeghini, A. Omran, D. Bluvstein, R. 
Samajdar, H. Pichler, W. W. Ho, S. Choi, S. Sachdev, M. Greiner, V. Vuletić, M. D. 
Lukin, Quantum phases of matter on a 256-atom programmable quantum simulator. 
Nature 595, 227–232 (2021). doi:10.1038/s41586-021-03582-4 Medline 
22. Y. Kim, A. Eddins, S. Anand, K. X. Wei, E. van den Berg, S. Rosenblatt, H. Nayfeh, Y. Wu, 
M. Zaletel, K. Temme, A. Kandala, Evidence for the utility of quantum computing before 
fault tolerance. Nature 618, 500–505 (2023). doi:10.1038/s41586-023-06096-3 Medline 
23. F. Pan, P. Zhang, Simulation of quantum circuits using the big-batch tensor network method. 
Phys. Rev. Lett. 128, 030501 (2022). doi:10.1103/PhysRevLett.128.030501 Medline 
24. J. Gray, S. Kourtis, Hyper-optimized tensor network contraction. Quantum (Vienna) 5, 410 
(2021). doi:10.22331/q-2021-03-15-410 
25. T. Ayral, T. Louvet, Y. Zhou, C. Lambert, E. M. Stoudenmire, X. Waintal, Density-matrix 
renormalization group algorithm for simulating quantum circuits with a finite fidelity. 
PRX Quantum 4, 020304 (2023). doi:10.1103/PRXQuantum.4.020304 
26. T. Schuster, C. Yin, X. Gao, N. Y. Yao, A polynomial-time classical algorithm for noisy 
quantum circuits. Phys. Rev. X 15, 041018 (2025). doi:10.1103/xct1-7kf2 
27. J. Robledo-Moreno, M. Motta, H. Haas, A. Javadi-Abhari, P. Jurcevic, W. Kirby, S. Martiel, 
K. Sharma, S. Sharma, T. Shirakawa, I. Sitdikov, R.-Y. Sun, K. J. Sung, M. Takita, M. C. 
Tran, S. Yunoki, A. Mezzacapo, Chemistry beyond the scale of exact diagonalization on 
a quantum-centric supercomputer. Sci. Adv. 11, eadu9991 (2025). 
doi:10.1126/sciadv.adu9991 Medline 
28. J. Tindall, M. Fishman, E. M. Stoudenmire, D. Sels, Efficient tensor network simulation of 
IBM’s Eagle Kicked Ising experiment. PRX Quantum 5, 010308 (2024). 
doi:10.1103/PRXQuantum.5.010308 
29. T. Begušić, J. Gray, G. K.-L. Chan, Fast and converged classical simulations of evidence for 
the utility of quantum computing before fault tolerance. Sci. Adv. 10, eadk4321 (2024). 
doi:10.1126/sciadv.adk4321 Medline 
30. M. S. Rudolph, E. Fontana, Z. Holmes, L. Cincio, Classical surrogate simulation of quantum 
systems with LOWESA. arXiv:2308.09109 [quant-ph] (2023). 
31. M. S. Rudolph, J. Tindall, Simulating and sampling from quantum circuits with 2D tensor 
networks. arXiv:2507.11424 [quant-ph] (2025). 
32. N. Schuch, M. M. Wolf, F. Verstraete, J. I. Cirac, Computational complexity of projected 
entangled pair states. Phys. Rev. Lett. 98, 140506 (2007). 
doi:10.1103/PhysRevLett.98.140506 Medline 
33. J. Haferkamp, D. Hangleiter, J. Eisert, M. Gluza, Contracting projected entangled pair states 
is average-case hard. Phys. Rev. Res. 2, 013010 (2020). 
doi:10.1103/PhysRevResearch.2.013010 
34. R. Alkabetz, I. Arad, Tensor networks contraction and the belief propagation algorithm. 
Phys. Rev. Res. 3, 023073 (2021). doi:10.1103/PhysRevResearch.3.023073 
35. J. Tindall, M. Fishman, Gauging tensor networks with belief propagation. SciPost Phys. 15, 
222 (2023). doi:10.21468/SciPostPhys.15.6.222 
36. G. Vidal, Efficient simulation of one-dimensional quantum many-body systems. Phys. Rev. 
Lett. 93, 040502 (2004). doi:10.1103/PhysRevLett.93.040502 Medline 
37. H. C. Jiang, Z. Y. Weng, T. Xiang, Accurate determination of tensor network state of 
quantum lattice models in two dimensions. Phys. Rev. Lett. 101, 090603 (2008). 
doi:10.1103/PhysRevLett.101.090603 Medline 
38. M. Lubasch, J. I. Cirac, M.-C. Bañuls, Algorithms for finite projected entangled pair states. 
Phys. Rev. B Condens. Matter Mater. Phys. 90, 064425 (2014). 
doi:10.1103/PhysRevB.90.064425 
39. H. N. Phien, J. A. Bengua, H. D. Tuan, P. Corboz, R. Orús, Infinite projected entangled pair 
states algorithm improved: Fast full update and gauge fixing. Phys. Rev. B Condens. 
Matter Mater. Phys. 92, 035142 (2015). doi:10.1103/PhysRevB.92.035142 
40. Supplementary materials are available online. 
41. I. A. Luchnikov, E. S. Tiunov, T. Haug, L. Aolita, Large-scale quantum annealing simulation 
with tensor networks and belief propagation. arXiv:2409.12240 [quant-ph] (2024). 
42. F. Verstraete, J. I. Cirac, Renormalization algorithms for quantum-many body systems in two 
and higher dimensions. arXiv:cond-mat/0407066 [cond-mat.str-el] (2004). 
43. G. Evenbly, N. Pancotti, A. Milsted, J. Gray, G. K.-L. Chan, Loop series expansions for 
tensor networks. arXiv:2409.03108 [quant-ph] (2024). 
44. D. B. Johnson, Finding all the elementary circuits of a directed graph. SIAM J. Comput. 4, 
77–84 (1975). doi:10.1137/0204007 
45. J. Fairbanks, M. Besancon, S. Simon, J. Hoffiman, N. Eubank, S. Karpinski, 
“JuliaGraphs/Graphs.jl: An optimized graphs package for the Julia programming 
language” (2021); https://github.com/JuliaGraphs/Graphs.jl/. 
46. J. Haegeman, J. I. Cirac, T. J. Osborne, I. Pižorn, H. Verschelde, F. Verstraete, Time-
dependent variational principle for quantum lattices. Phys. Rev. Lett. 107, 070601 (2011). 
doi:10.1103/PhysRevLett.107.070601 Medline 
47. A. D. King, J. Raymond, T. Lanting, R. Harris, A. Zucca, F. Altomare, A. J. Berkley, K. 
Boothby, S. Ejtemaee, C. Enderud, E. Hoskinson, S. Huang, E. Ladizinsky, A. J. R. 
MacDonald, G. Marsden, R. Molavi, T. Oh, G. Poulin-Lamarre, M. Reis, C. Rich, Y. 
Sato, N. Tsai, M. Volkmann, J. D. Whittaker, J. Yao, A. W. Sandvik, M. H. Amin, 
Quantum critical dynamics in a 5,000-qubit programmable spin glass. Nature 617, 61–66 
(2023). doi:10.1038/s41586-023-05867-2 Medline 
48. K. Trachenko, A. Zaccone, Slow stretched-exponential and fast compressed-exponential 
relaxation from local event dynamics. J. Phys. Condens. Matter 33, 315101 (2021). 
doi:10.1088/1361-648X/ac04cd Medline 
49. Z. W. Wu, W. Kob, W.-H. Wang, L. Xu, Stretched and compressed exponentials in the 
relaxation dynamics of a metallic glass-forming melt. Nat. Commun. 9, 5334 (2018). 
doi:10.1038/s41467-018-07759-w Medline 
50. M. Bernaschi, I. González-Adalid Pemartín, V. Martín-Mayor, G. Parisi, The quantum 
transition of the two-dimensional Ising spin glass. Nature 631, 749–754 (2024). 
doi:10.1038/s41586-024-07647-y Medline 
51. Y. Kato, S. Onoda, Numerical evidence of quantum melting of spin ice: Quantum-to-
classical crossover. Phys. Rev. Lett. 115, 077202 (2015). 
doi:10.1103/PhysRevLett.115.077202 Medline 
52. J. Tindall, M. Rudolph, “TensorNetworkQuantumSimulator.jl” (2025); 
https://github.com/JoeyT1994/TensorNetworkQuantumSimulator. 
53. J. Tindall, A. Mello, M. Fishman, E. M. Stoudenmire, D. Sels, Data for: Dynamics of 
disordered quantum systems with two- and three-dimensional tensor networks, Dryad 
(2025); https://doi.org/10.5061/dryad.7d7wm388g. 
54. S. Sahu, B. Swingle, Efficient tensor network simulation of quantum many-body physics on 
sparse graphs. arXiv:2206.04701 [quant-ph] (2022). 
55. S. S. Jahromi, R. Orús, Universal tensor-network algorithm for any infinite lattice. Phys. Rev. 
B 99, 195105 (2019). doi:10.1103/PhysRevB.99.195105 
56. P. Pippan, S. R. White, H. G. Evertz, Efficient matrix-product state method for periodic 
boundary conditions. Phys. Rev. B Condens. Matter Mater. Phys. 81, 081103 (2010). 
doi:10.1103/PhysRevB.81.081103 
57. C. Guo, D. Poletti, I. Arad, Block belief propagation algorithm for two-dimensional tensor 
networks. Phys. Rev. B 108, 125111 (2023). doi:10.1103/PhysRevB.108.125111 
58. G. Vidal, Efficient classical simulation of slightly entangled quantum computations. Phys. 
Rev. Lett. 91, 147902 (2003). doi:10.1103/PhysRevLett.91.147902 Medline 
59. Y. Zhou, E. M. Stoudenmire, X. Waintal, What limits the simulation of quantum computers? 
Phys. Rev. X 10, 041038 (2020). doi:10.1103/PhysRevX.10.041038 
60. S.-B. B. Lee, H. R. Choi, D. D. Ohm, S.-S. B. Lee, Scalable projected entangled-pair state 
representation of random quantum circuit states. Phys. Rev. Res. 7, 033252 (2025). 
doi:10.1103/rzgm-cywf 
61. L. Mauron, G. Carleo, Challenging the quantum advantage frontier with large-scale classical 
simulations of annealing dynamics. arXiv:2503.08247 [quant-ph] (2025). 
62. J. Bezanson, A. Edelman, S. Karpinski, V. B. Shah, Julia: A Fresh Approach to Numerical 
Computing. SIAM Rev. 59, 65–98 (2017). doi:10.1137/141000671 
63. M. Fishman, S. R. White, E. M. Stoudenmire, The ITensor Software Library for tensor 
network calculations. arXiv:2007.14822 [cs.MS] (2022). 