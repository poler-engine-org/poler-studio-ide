> Source: https://docs.rs/torsh-nn/latest/torsh_nn/sparse/index.html

torsh_nn::sparse - Rust
Docs.rs
torsh-nn-0.1.0
torsh-nn 0.1.0
Permalink
Docs.rs crate page
Apache-2.0
Links
Homepage
Repository
crates.io
Source
Owners
cool-japan
Dependencies
anyhow ^1.0 normal
bytemuck ^1.25 normal
chrono ^0.4 normal optional
flate2 ^1.1 normal optional
hashbrown ^0.16 normal
indexmap ^2.11 normal
num-traits ^0.2 normal
num_cpus ^1.17 normal
oxicode ^0.1 normal optional
parking_lot ^0.12 normal
safetensors ^0.5.3 normal optional
scirs2-cluster ^0.2.0 normal
scirs2-core ^0.2.0 normal
scirs2-neural ^0.2.0 normal
serde ^1.0 normal optional
serde_json ^1.0 normal optional
sha2 ^0.10 normal
thiserror ^2.0 normal
torsh-autograd ^0.1.0 normal
torsh-core ^0.1.0 normal
torsh-linalg ^0.1.0 normal
torsh-tensor ^0.1.0 normal
approx ^0.5 dev
criterion ^0.8 dev
tempfile ^3.25 dev
Versions
78.88% of the crate is documented
Platform
aarch64-apple-darwin
aarch64-unknown-linux-gnu
x86_64-pc-windows-msvc
x86_64-unknown-linux-gnu
Feature flags
docs.rs
About docs.rs
Badges
Builds
Metadata
Shorthand URLs
Download
Rustdoc JSON
Build queue
Privacy policy
Rust
Rust website
The Book
Standard Library API Reference
Rust by Example
The Cargo Guide
Clippy Documentation
Skip to main content
Module sparse
Settings
Help
torsh_nn 0.1.0
Module sparse
Sections
Features
Example
Module Items
Structs
Enums
In crate torsh_nn
Modules
base
compile_time
composition
construction
container
conversion
core
cuda_kernels
diagnostics
export
functional
gradcheck
hardware_opts
hooks
init
layers
lazy
mixed_precision
model_zoo
modules
numerical_stability
optimization
parameter
parameter_updates
prelude
pruning
quantization
research
scirs2_neural_integration
sparse
summary
utils
visualization
Macros
func_error
impl_module_constructor
lazy_module
validate_inputs
Structs
SparseMatrix
Constants
VERSION
VERSION_MAJOR
VERSION_MINOR
VERSION_PATCH 
torsh_nn
Module sparse Copy item path
Source
Search
Settings
Help
Summary
Expand description
Sparse Neural Network Support
This module provides efficient implementations of sparse neural network layers and operations, enabling training and inference with sparse weights and activations.
§ Features
Sparse Linear Layers: Efficient linear transformations with sparse weight matrices
Sparse Convolutions: Convolutional layers with structured sparsity
Magnitude Pruning: Remove small-magnitude weights during training
Structured Sparsity: Block-wise or channel-wise sparsity patterns
Sparse Backpropagation: Efficient gradient computation for sparse parameters
§ Example
ⓘ
Structs §
GradualPruningScheduler
Gradual magnitude pruning scheduler
SparseConv2d
Sparse convolutional layer with structured sparsity
SparseLinear
Sparse linear layer with efficient sparse matrix operations
SparseMask
Sparse mask for weight matrices
SparseTrainingConfig
Sparse training configuration
Enums §
SparsityPattern
Sparsity pattern for sparse layers