> Source: https://mattermodeling.stackexchange.com/questions/3752/whats-the-physics-contained-in-the-exchange-correlation-functional-in-the-frame

ab initio calculations - What's the physics contained in the exchange-correlation functional in the framework of KS-DFT? - Matter Modeling Stack Exchange
By clicking “Sign up”, you agree to our terms of service and acknowledge you have read our privacy policy.
Sign up with Google
OR
Email
Password
Sign up
Already have an account? Log in
Skip to main content
1.
Stack Internal Stack Overflow for Teams is now called Stack Internal. Bring the best of human thought and AI automation together at your work. Try for free Learn more
Stack Internal
Bring the best of human thought and AI automation together at your work. Learn more
Stack Internal
Knowledge at work
Bring the best of human thought and AI automation together at your work.
Explore Stack Internal
Stack Exchange Network
Stack Exchange network consists of 183 Q&A communities including Stack Overflow, the largest, most trusted online community for developers to learn, share their knowledge, and build their careers.
Visit Stack Exchange
Loading…
Tour Start here for a quick overview of the site
Help Center Detailed answers to any questions you might have
Meta Discuss the workings and policies of this site
About Us Learn more about Stack Overflow the company, and our products
current community
Matter Modeling help chat
Matter Modeling Meta
your communities
Sign up or log in to customize your list.
more stack exchange communities
company blog 4. 5. Log in 6. Sign up
Matter Modeling
What's the physics contained in the exchange-correlation functional in the framework of KS-DFT?
Ask Question
Asked 5 years, 6 months ago
Modified 5 years, 6 months ago
Viewed 485 times
This question shows research effort; it is useful and clear
12
This question does not show any research effort; it is unclear or not useful
Save this question. 
Show activity on this post.
This question is inspired by this post. In the Kohn-Sham framework of density functional theory, the total energy is expressed as: E= E n o n k i n+ E e x t+ E H+ E x c
in which
The first term is the kinetic energy of the non-interacting system: E n o n k i n=− 1 2 n ∑ i ϕ ∗ i( → r) ∇ 2 ϕ i( → r)
The second term is the external energy: E e x t= ∫ ϕ ∗( → r) U e x t( → r) ϕ( → r) d → r= ∫ U e x t( → r) ρ( → r) d → r
The third term is the Hartree energy: E H= 1 2 ∫ ∫ ρ( → r) ρ( → r′)| → r− → r′| d → r d → r′
The last term is the exchange-correlation term needs to be approximated, such as LDA, which includes:
Exchange energy;
Correlation energy;
The kinetic energy difference between the interacting system and the non-interacting system;
The self-interaction error in the Hartree energy.
In this post, Phil Hasnip has claimed that including a Hubbard U potential within a Kohn-Sham density functional theory (DFT) calculation is to study a material for which you expect a significant self-interaction error.
So is there any other interesting physics contained in the exchange-correlation functional in the framework of KS-DFT?
density-functional-theory
ab-initio-calculations
kohn-sham
exchange-correlation
self-interaction
Share
Share a link to this question https://mattermodeling.stackexchange.com/q/3752
Copy link CC BY-SA 4.0
Short permalink to this question
Cite
Improve this question
Follow
Follow this question to receive notifications
edited Nov 15, 2020 at 1:06
asked Nov 14, 2020 at 14:13
Jack
15.7k 1 1 gold badge 43 43 silver badges 106 106 bronze badges
Add a comment |
1 Answer 1
Sorted by: Reset to default
Highest score (default)
Date modified (newest first)
Date created (oldest first)
This answer is useful
5
This answer is not useful
Save this answer.
Loading when this answer was accepted… 
Show activity on this post.
You have already detailed what the physics contained in the exchange-correlation functional is.
Self-interaction error is not physical; it is an artifact in density functional approximations that arises from imperfect cancellation of the Coulomb and exchange interactions. Although several schemes have been suggested to remove self-interaction error, the one by Perdew and Zunger being the most well-known, these schemes tend to be problematic in that they are
hideously expensive computationally
hard to minimize properly (e.g. the Perdew-Zunger functional requires complex orbitals even for a gas-phase atom without external fields)
may break molecular symmetries
Another failure of density functional approximations is in modeling systems with strong correlations, such as many transition metal complexes and multiple bond breaking.
Share
Share a link to this answer https://mattermodeling.stackexchange.com/a/3784
Copy link CC BY-SA 4.0
Short permalink to this answer
Cite
Improve this answer
Follow
Follow this answer to receive notifications
answered Nov 21, 2020 at 15:27
Susi Lehtola
20.8k 45 45 silver badges 105 105 bronze badges
Add a comment |
You must log in to answer this question.
Start asking to get answers
Find the answer to your question by asking.
Ask question
Explore related questions
density-functional-theory
ab-initio-calculations
kohn-sham
exchange-correlation
self-interaction
See similar questions with these tags.
Featured on Meta
Native Ads Coming To Comments
Linked
13
How to calculate the potential in Hubbard-U correction and when to apply it?
10
'Exchange' in Hartree-Fock and Kohn-Sham DFT
Related
32
Is there any DFT code or software that has the option to use this exact exchange-correlation energy functional?
18
What's the difference between spin-unpolarized, spin-polarized and non-colinear calculation?
10
'Exchange' in Hartree-Fock and Kohn-Sham DFT
14
How can we say that the KS equation is describing a noninteracting many-electron system?
7
Is the exchange-correlation term in Kohn-Sham equation always positive or negative?
5
Relationship between functional derivative and potential value at a position
8
Replacement from minimizing the energy to solving the KS equation (or eigenvalue problem)
9
Why Kohn-Sham equations are regarded as single-particle equations?
3
Synergy of Exchange and Correlation, Why are they Combined in the Term "Exchange-Correlation" Energy
8
What is the Hamiltonian in the adiabatic connection?
Hot Network Questions
Adding an "AI sentinel" license clause to detect LLM modifications
My new senior colleague self-invited himself to work on my research problem
Maxing Out 457(b) Alongside Employer + Employee 401(k)
Which famous composer made this piece?
unicode-math font character new mapping in \symsf
Is it normal to share genomics data with bioinformaticians without a formal agreement?
How could organisms be modified to be immune to the effects of asbestos
How do they determine the difficulty of puzzles on Chess dot com or other?
Confusion in understanding Euler's equations for rigid body
Resources or Platforms for Questions on Daf Yomi
Why is the practice of category theory such that size issues arise?
Prove a closed disc cannot intersect a 3-leaf fold
Stable norms of periodic graphs
Why can't lunar regolith support plant growth in the same way as Earth's soil?
Journalctl disk-usage vs Actual disk usage is wildly wrong
Is the rearranging operator continuous?
Airline is trying to send me to the wrong place - what do I do?
Is continuity in general just an illusion or does it exist and we're just aware of it?
In Genesis 1:1, do the Hebrew word בָּרָ֣א and/or the Latin word "creavit" intrinsically mean that the Elohim created "ex nihilo"?
How do we uniquely determine current density in classical electromagnetism and Maxwell's equations?
Should I use the protective cap of an EV charging cable under an unwarmed open-to-elements shelter?
Advice for chevrusa in Jerusalem looking for more students
A Simple Network Topology Failover Analysis and Question
How do temporary HP work with Animal Shapes in 5.5e?
Question feed
Subscribe to RSS
Question feed
To subscribe to this RSS feed, copy and paste this URL into your RSS reader. https://mattermodeling.stackexchange.com/feeds/question/3752 
default
Why are you flagging this comment?
[-] 20
It contains harassment, bigotry or abuse.
This comment attacks a person or group. Learn more in our Abusive behavior policy. [-] 40
It's unfriendly or unkind.
This comment is rude or condescending. Learn more in our Code of Conduct. [-] 39
Not needed.
This comment is not relevant to the post.
Enter at least 6 characters [-] 19
Something else.
A problem not listed above. Try to be as specific as possible.
Enter at least 6 characters
Flag comment Cancel
You have 0 flags left today
Hang on, you can't upvote just yet.
You'll need to complete a few actions and gain 15 reputation points before being able to upvote. Upvoting indicates when questions and answers are useful. What's reputation and how do I get it?
Instead, you can save this post to reference later.
Save this post for later Not now
Matter Modeling
Tour
Help
Chat
Contact
Feedback
Company
Stack Overflow
Stack Internal
Stack Data Licensing
Stack Ads
About
Press
Legal
Privacy Policy
Terms of Service
Your Privacy Choices
Cookie Policy
Stack Exchange Network
Technology
Culture & recreation
Life & arts
Science
Professional
Business
API
Data
Blog
Facebook
Twitter
LinkedIn
Instagram
Site design / logo © 2026 Stack Exchange Inc; user contributions licensed under CC BY-SA . rev 2026.6.2.43357
By continuing to use this website, you agree Stack Exchange can store cookies on your device and disclose information in accordance with our Cookie Policy. By exiting this window, default cookies will be accepted. To reject cookies, select an option from below.
Necessary cookies only
Customize settings 
Cookie consent preference center
When you visit any of our websites, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences, or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and manage your preferences. Please note, blocking some types of cookies may impact your experience of the site and the services we are able to offer.
Cookie policy
Accept all cookies
Manage consent preferences
Strictly Necessary Cookies
Always Active
These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.
Targeting Cookies
[x]
Targeting Cookies
These cookies are used to make advertising messages more relevant to you and may be set through our site by us or by our advertising partners. They may be used to build a profile of your interests and show you relevant advertising on our site or on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device.
Performance Cookies
[x]
Performance Cookies
These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.
Functional Cookies
[x]
Functional Cookies
These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.
Cookie List
Clear
[-] checkbox label label
Apply Cancel
Consent Leg.Interest [-]
checkbox label label [-]
checkbox label label [-]
checkbox label label
Necessary cookies only Confirm my choices