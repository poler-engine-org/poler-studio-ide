> Source: https://akrmys.com/links/pcdb.html.en

Links to Physical & Chemical Databases
Links to Physical & Chemical Databases
A. Miyoshi
Top 
Links to Physical and Chemical Databases
Physical Constants
Physical Constants and Conversion of Units
NIST Databases
NIST Online Databases
This is an entry to the online databases prepared by NIST (National Institute of Standards and Technology, former NBS) including two below.
The NIST WebBook
The NIST WebBook will provide access to the full array of data compiled and distributed by NIST under the Standard Reference Data Program. The NIST Chemistry WebBook contains:
Thermochemical data for organic and small inorganic compounds / Reaction thermochemistry data / IR spectra / Mass spectra / UV-Vis spectra / Electronic and vibrational spectra / Constants of diatomic molecules (spectroscopic data) / Ion energetics data / Thermophysical property data for fluids
The NIST Physical Reference Data
Distributed by the NIST Physical Laboratory. Containing:
Physical Constants / Atomic Spectroscopic Data / Molecular Spectroscopic Data / Ionization Data / etc.
Chemical Kinetics Databases
JPL-NASA
Chemical Kinetics and Photochemical Data for Stratospheric Modeling
IUPAC
Kinetic and photochemical data evaluated by the IUPAC Subcommittee for Gas Kinetic Data Evaluation.
NIST
NIST Chemical Kinetics Database.
Chemical Equilibrium and Thermodynamic Data
NASA-CEA
A Program Calculates Chemical Equilibrium and Thermodynamic Data Library
Spectroscopy Databases
The HITRAN Database
HITRAN is an acronym for high resolution transmission molecular absorption database. HITRAN is a compilation of spectroscopic parameters which a variety of computer simulation codes use to predict the transmission and emission of light in the atmosphere. Containing:
Mostly IR, but some UV absorption line / cross section data for 25 chemical species (H 2 O, CO 2, O 3, N 2 O, CO, CH 4, O 2, NO, SO 2, NO 2, NH 3, HNO 3, OH, etc.).
JPL Molecular Spectroscopy
Prepared by the JPL Molecular Spectroscopy Team supportiong NASA programs in Astrophysics, Atmospheric Science, and Planetary Science.