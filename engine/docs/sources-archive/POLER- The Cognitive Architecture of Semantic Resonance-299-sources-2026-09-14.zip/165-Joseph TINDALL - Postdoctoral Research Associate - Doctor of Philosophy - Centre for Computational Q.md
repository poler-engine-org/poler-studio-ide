> Source: https://www.researchgate.net/profile/Joseph-Tindall

ResearchGate - Temporarily Unavailable 
Access denied
You do not have access to www.researchgate.net.
The site owner may have set restrictions that prevent you from accessing the site.
Ray ID: a03fdde81db3f85e
Timestamp: 2026-05-30 18:40:21 UTC
Your IP address: 74.125.215.233
Requested URL: www.researchgate.net/profile/Joseph-Tindall
Error reference number: 1020
Server ID: FL_398F412
User-Agent: Google-NotebookLM
Ray ID: a03fdde81db3f85e
Client IP: 74.125.215.233
© 2008-2026 ResearchGate GmbH. All rights reserved.