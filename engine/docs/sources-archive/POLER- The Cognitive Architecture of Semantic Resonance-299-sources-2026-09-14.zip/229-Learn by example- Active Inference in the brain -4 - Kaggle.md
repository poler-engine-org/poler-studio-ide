> Source: https://www.kaggle.com/code/charel/learn-by-example-active-inference-in-the-brain-4

Learn by example: Active Inference in the brain -4
menu
Skip to content
Create
search
explore Home
emoji_events Competitions
table_chart Datasets
tenancy Models
leaderboard Benchmarks
smart_toy Game Arena
code Code
comment Discussions
school Learn
expand_more More
auto_awesome_motion
View Active Events
menu
Skip to content
search
Sign In
Register
Kaggle uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic.
Learn more
OK, Got it. 
Charel van Hoof
· 1y ago
· 7,041 views
more_vert
Learn by example: Active Inference in the brain -4
Copy & Edit
182
arrow_drop_up 56 
Learn by example: Active Inference in the brain -4
Notebook Input Output Logs Comments (17)
menu_open
Runtime
play_arrow
7s
history Version 162 of 162
Tags
Research Neuroscience Robotics Artificial Intelligence Learn
Language
Python
expand_more View Metadata
link code
How the brain might function - part 4 Improving perception ¶
Free Energy Principle tutorial without a PhD ¶
Image by Midjourney, directed by the author
Welcome to my notebook on Kaggle. I did record my notes with examples so it might help others in their journey to understand Active Inference minimizing the underlying Free Energy. Neuroscience has produced a candidate which suggests that several global brain theories might be unified within a free-energy framework: Free Energy Principle by Karl Fristion: The free-energy principle is an attempt to explain the structure and function of the brain, starting from the very fact that we exist. The Free Energy Principle is mathematically rigorous and both neurologically and evolutionary plausible.
This is the fourth notebook in a series of notebooks on the Free Energy Principle tutorial without a PhD. If you didn't read the first ones yet, please start with: part 1, followed by part 2 and part 3.
After 3 full notebooks of theory, I can imagine that you are curious if it really works, and yes it does, throughout this notebook you will find links to the first 3 notebooks with working code, each building more extensive examples. In order to do so, we need first to have an understanding of how lowering Free Energy will be done by gradient descent and will set-up a simulation environment so the theory is applied in an intuitive context. The focus of this notebook is on active inference for a non-hierarchical generative model. Let's start simple and understand the basics before the complexities of full deep/hierarchical models can be attempted to be understood.
A lot of research papers have been published on the Free energy Principle and understanding them has a steep learning curve. I did record my notes with examples so it might help others to get a better understanding. This to help catalyze knowledge and research on Active Inference and the Free Energy Principle in an engineering/robotics/data sciences/machine learning context. So, if you are interested please keep on reading and upvote top right, leave a comment or contact me directly.
link code
How the brain might function - part 3 recap ¶
As a reminder, we ended the previous notebook with the following summary:
Minimizing the Laplace encoded Free Energy with Active Inference boils down to minimizing a quadratic sum of prediction errors, mediated by the precisions (inverse variances) on each hierarchical level. It is an automatable optimization problem through prediction error minimization by iterately finding the lowest Free Energy.
˜ x is the continuous stream of trajectories of external hidden environment states the brain tries to infer. Shorthand notation for the vector → x h y p o t h e s e s( t) ∈ R n( p+ 1) with n number of states and generalised coordinates of motion embedding order p.
˜ v are the causal states, the hidden causes that link the functional hierarchical levels. The predictions that flow down the hierarchy and act as priors.
˜ y is the continuous stream of trajectories of sensory observations, the data from the available sensory set. Shorthand notation for the vector → y o b s e r v a t i o n( t) ∈ R q( p+ 1) with q number of sensors and generalised coordinates of motion embedding order p.
u is the continuous stream of actions that are performed on the environment, control signal. Shorthand notation for the vector → u( t) ∈ R l with l number of controls.
The brain infers the world in which it is immersed:
by a generative model encoding a probabilistic model of the environment/world in which it is immersed. D ˜ μ( i) x= ˜ f( ˜ μ( i) x, ˜ μ( i) v, μ( i) θ)+ ˜ w( i)( μ( i) λ) ˜ μ( i− 1) v= ˜ g( ˜ μ( i) x, ˜ μ( i) v, μ( i) θ)+ ˜ z( i)( μ( i) λ) ˜ y= ˜ μ( 0) v where Θ( i) are the parameters of the generative model and λ( i) the hyperparameters of the noise throughout the hierarchy
by estimating hidden causes μ={ ˜ μ( i) x, ˜ μ( i) v, μ( i) Θ, μ( i) λ}. Under the Laplace/mean-field approximations estimating hidden causes simplify to estimating mean μ instead of a full recognition density . ˜ μ( i) x is shorthand notation for the i'th vector in the hierarchy with ˜ → μ x( t) ∈ R n( p+ 1).
by finding ˜ μ( i) x, ˜ μ( i) v, μ( i) Θ, μ( i) λ, u with the lowest Free Energy and thus lowest surprise in sensory states on all hierarchical layers:
Improving perception: ˜ μ( i) x= A r g m i n ˜ μ( i) x F( ˜ y, μ) and ˜ μ( i) v= A r g m i n ˜ μ( i) v F( ˜ y, μ)
Acting on the environment: u= A r g m i n u F( ˜ y, μ)
Learning the generative model: μ( i) Θ= A r g m i n μ( i) Θ F( ˜ y, μ)
Attention or optimizing expected precision of uncertainty: μ( i) λ= A r g m i n μ( i) λ F( ˜ y, μ) 
link code
Table of Contents ¶
In this notebook we will further explore where we ended in the third notebook. How active inference minimizing the Free-energy can be accomplished by using a relatively simple gradient descent minimization algorithm making it biologically plausible, how minimizing the Free Energy corresponds to a predictive coding scheme, and showcasing it in first working code examples.
Optimizing Free energy using Gradient descent
Gradient descent
Inference by gradient descent
Acting by gradient descent
Learning the generative model by gradient descent
Optimizing expected precision of uncertainty by gradient descent
Dynamic Expectation Maximization (DEM)
Planning
Active Inference capsule
Inference by gradient descent for a single active inference capsule
Predictive Coding
Biological plausible predictive coding scheme
Simulation environment
Hydra (vulgaris) inspiration
Hydar
Code
Code example 1
Code example 2
Code example 3
Camp Improving perception
How the brain might function - part 5
Appendix
Prediction errors and precision weigthed prediction errors
Basic differentiation rules
PREDNET compared to active inference
Conventions and Symbols
It is a conscious choice to use as much as possible arguments and sentences from Friston's papers enriched with examples and insights for understanding. In the end these notebooks turned out to be longer than I anticipated, there is a lot to explain. Enjoy.
The articles of Karl Friston I used mainly for this notebook series are: A free energy principle for the brain , The free-energy principle: a rough guide to the brain?, Action and behavior: a free-energy formulation and Hierarchical Models in the Brain.
link code
Minimize Free energy using Gradient descent ¶
How to minimize free energy to make the recognition density a good posterior approximation, which is under the Laplace approximation (see the second notebook) equal to make the mean μ a good approximation of the hidden causes? Active inference minimizes the Free-energy by using a simple gradient descent minimization algorithm which requires a relatively simple neural implementation making it biologically plausible. It can be written down as differential equations that prescribe the dynamics of perception, action, learning, and attention as functions of the prediction error. The prediction error is the main learning signal.
Gradient descent ¶
Gradient descent is an iterative optimization algorithm for finding the minimum of a function. To find a (local) minimum of a function with respect to a variable x using gradient descent, we take steps proportional to the negative of the partial derivative (Differentiation is the process to determine the rate of change — or gradient — of a function.) of the function with respect to x at the current point. Gradient descent is e.g. the standard way neural networks learn. In the picture below a simple reminder, where the green line is the derivative of the red line and gradient descent is simply taking steps, following the green line down. 
link code
Inference by gradient descent ¶
Perceptual inference (how fast neural activity estimate hidden/causal states) by minimizing the Free Energy:
˜ μ( i) x= A r g m i n ˜ μ( i) x F( ˜ y, μ)
˜ μ( i) v= A r g m i n ˜ μ( i) v F( ˜ y, μ)
by iteratively taking steps proportional to the negative of the partial derivative of the Free Energy with respect to ˜ μ( i) x and ˜ μ( i) v. The gradient gradient descent can be written as a differential equation: ˙ ˜ μ( i) x= ˜ μ′( i) x− ∂ F( ˜ y, μ) ∂ ˜ μ( i) x= D ˜ μ( i) x− ∂ F( ˜ y, μ) ∂ ˜ μ( i) x
˙ ˜ μ( i) v= ˜ μ′( i) v− ∂ F( ˜ y, μ) ∂ ˜ μ( i) v= D ˜ μ( i) v− ∂ F( ˜ y, μ) ∂ ˜ μ( i) v
Where
˙ ˜ μ x resp ˙ ˜ μ v means the rate of change of ˜ μ x resp ˜ μ v, how these states develop taking small steps down to the Free Energy minimum.
Remember from the second notebook that the free energy is a convex function minimizing over ˜ μ x, ˜ μ v (quadratic product around a positive semi-definite matrix), so the gradient descent will nicely go down to the minimum, imagine it as "multidimensional bowl" where the motion is down towards the lowest point of the bowl.
Optionally α x resp. α v are introduced as learning rates of the gradient descent, e.g. ˙ ˜ μ x= D ˜ μ x− α x ∂ F( ˜ y, μ) ∂ ˜ μ x
The second term of the equation − ∂ F( ˜ y, μ) ∂ ˜ μ x is the negative of the partial derivative as discussed above.
The first term of the equation D ˜ μ x needs some explanation why it appears over here. As we saw in the previous notebook, active inference is equipped to estimate the instantaneous path or trajectory of a hidden cause (x) in motion (hence we write ˜ μ x i.s.o. μ x) . The Free Energy minimum is found when the gradient reaches zero ( ˙ ˜ μ x− D ˜ μ x=− ∂ F( ˜ y, μ) ∂ ˜ μ x= 0) resulting in ˙ ˜ μ x= D ˜ μ x, thus the true motion equals the belief of the motion. (Remember from the second notebook the definition of the derivative operator: D ˜ μ x = ˜ μ x′, where the symbol ' means the time derivative d/dt as estimated by the brain at point t). The first term D ˜ μ x is required to keep the belief of motion aligned with the real motion when the Free Energy gradient vanishes. Note that in generalized coordinates it is perfectly possible for ˙ ˜ μ x and ˜ μ′ x to differ, the estimation or belief of motion can be different from the actual motion in for example the timeframe for the brain to minimize the Free Energy to correctly estimate the motion. (e.g. the motion after-effect as was pointed out by Karl Friston in one of his papers, ever sat in a train watching out of the window, next pulled into a station and saw out of the same window another train just starting to move. Felt that strange sensation that you yourself were moving and needed to look around to get visual confirmation that you were actually not moving? If you ever experienced it, you know exactly what I mean.)
link code
Acting by gradient descent ¶
Acting upon the environment (how fast neural activity activates reflex arcs, the neural pathways that control muscle reflexes) by minimizing the Free Energy: u= A r g m i n u F( ˜ y, μ)
by iteratively taking steps proportional to the negative of the partial derivative of the Free Energy with respect to u. The gradient gradient descent can be written as a differential equation:
˙ u=− ∂ F( ˜ y, μ) ∂ u
As the Free Energy is not a direct function of u, the gradient descent with respect to u is defined through the chain rule (actions u can indirectly influence sensory observations y, e.g. when we turn our head it indirectly influences what we see, see first notebook). This can be expressed mathematically as:
˙ u=− ∂ F( ˜ y, μ) ∂ u=− ∂ ˜ y( u) ⊤ ∂ u ∂ F( ˜ y, μ) ∂ ˜ y
Where
˙ u means the rate of change of u, how the control signal develops taking small steps down to the Free Energy minimum.
The T-transpose appears due to matrix-notation form.
The partial derivative of the sensory input with respect to the control ∂ ˜ y( u) ∂ u allows to predict the consequences of actions (model of how sensory data changes with actions). In the next notebook we will unpack this further.
Like for estimating ˜ μ x resp. ˜ μ v the free energy is also a convex function minimizing over u (quadratic product around a positive semi-definite matrix) so the gradient descent will nicely go down to the minimum.
Optionally α u is introduced as learning rate of the gradient descent, e.g. ˙ u=− α u ∂ F( ˜ y, μ) ∂ u
As described in the first and second notebook, action is not modelled in the generative model (the equation of motion in the generative process depends on action, whereas the equation of motion in the generative model has no notion of action) because action is the result of lowering Free Energy, as you can see in the equation above.
Note that action u is not generalized.
Kind reminder not to mix up u and μ.
Note that in a hierarchical generative model that action is applicable on the lowest level (the model maps from sensory states to action, not from hidden states or causal states to action).
link code
Learning the generative model by gradient descent ¶
Learning the generative model (how the brain encodes the environment in the synaptic efficacy / neural connection strengths) by minimizing the Free Energy: μ( i) Θ= A r g m i n μ( i) Θ F( ˜ y, μ)
by iteratively taking steps proportional to the negative of the partial derivative of the Free Energy path integral with respect to μ Θ. The gradient descent on the parameters is second order because the parameters optimize not the free energy but its path-integral or time-integral (also called free Action, abbreviated as A). The neural connection strengths (representing the generative model parameters) adapt slowly over time and sustained exposure to sensory observations causes the internal structure of the brain to capture the causal structures of those inputs and thus the structure that exists in the real world.
The gradient descent can be written as a differential equation:
¨ μ( i) Θ=− ∂ F( ˜ y, μ) ∂ μ( i) Θ
Or in some papers written as: ˙ μ( i) Θ=− ∂ A ∂ μ( i) Θ a n d ˙ A= F( ˜ y, μ)
Where
¨ μ Θ means the slow rate of change of μ Θ, how the parameters change slowly to minimize the Free Energy.
It should be noted that the convexity of the Free energy does not apply when optimizing Θ. So, some more intricate math will follow when we deepdive how the learning of the generative model is done.
Optionally α Θ is introduced as learning rate of the gradient descent, e.g. ¨ μ Θ=− α Θ ∂ F( ˜ y, μ) ∂ μ Θ
Where A is the Free Action, the path integral of the Free Energy.
Optimizing expected precision of uncertainty by gradient descent ¶
Likewise learning the precision (how the brain regulates the synaptic gain by estimating the confidence of the sensory signals) by Minimizing Free Energy: μ( i) λ= A r g m i n μ( i) λ F( ˜ y, μ)
by iteratively taking steps proportional to the negative of the partial derivative of the Free Energy path-integral with respect to μ( i) λ.The gradient descent can be written as a differential equation:
¨ μ( i) λ=− ∂ F( ˜ y, μ) ∂ μ( i) λ
Or in some papers written as: ˙ μ( i) λ=− ∂ A ∂ μ( i) λ a n d ˙ A= F( ˜ y, μ)
Where
¨ μ λ means the slow rate of change of μ λ, how the noise hyper parameters change slowly to minimize the Free Energy.
It should be noted that the convexity of the Free energy does not apply when optimizing λ. So, some more intricate math will follow when we deepdive how the learning of the precision is done.
Optionally α λ is introduced as learning rate of the gradient descent, e.g. ¨ μ λ=− α λ ∂ F( ˜ y, μ) ∂ μ λ
Where A is the Free Action, the path integral of the Free Energy.
Dynamic Expectation Maximization (DEM) ¶
Hope that you noticed the interesting fact that all type of learning (including e.g. the generative model) is accomplished as gradient descent on the Free Energy. The integral approach to learning all the parameters of a dynamic system is referred to as Dynamic Expectation Maximization (DEM). The parameters (hidden causes μ={ ˜ μ( i) x, ˜ μ( i) v, μ( i) Θ, μ( i) λ}) are estimated in 3 steps:
D-step: Update expectation of hidden states ˜ μ( i) x, ˜ μ( i) v , by gradient descent on the Free Energy. Note: In the original DEM paper action was not yet included, rather DEM estimated the input signal. In later active inference papers the estimation of the input signal was cast as estimating the required input signal (= control signal) to get the expected sensory signals. Hence the term active inference was coined and action became an integral part of the Free Energy Principle.
E-step: Update model parameters μ( i) θ by gradient descent on the Free Action (or path-integral of the Free Energy)
M-step: Update hyperparameters μ( i) λ by gradient descent on the Free Action (or path-integral of the Free Energy)
In the scope of this notebook, we cover the D-step, improving perception.
link code
Planning ¶
The research field of Artificial Intelligence can be grouped into various tasks, the common major ones being inference, learning and planning. So far we did cover (active) inference and Learning (the generative model and uncertainty). I did not cover planning thus far in the notebook series, however they are covered by active inference research and have a close relation with reinforcement learning.
Planning/decision making is an inherently discrete process, in contrast to sensory information that enters your brain as continuous sensory signals. We make choices for discrete options (e.g. strawberry or banana ice cream) , we select among discrete alternative courses of actions (e.g. turn left or right), words we use are discrete, etc. The world is both continuous and discrete. As the brain avoids surprise by having a good model of the world, it is believed that both continuous and discrete processes are present/coexist in the generative model in the brain.
Interestingly, the Free Energy principle caters for both continuous and discrete domains. As we saw in the previous notebook active inference is fundamentally structured to enable different orders of abstraction due to the hierarchical nature of the generative model. Lower levels of the hierarchy operate on smaller spatial/temporal scales (e.g. continuous), whereas higher levels estimate at larger spatial/temporal scales (e.g. discrete). The idea being that the brain is able to abstract from continuous time to a more discrete, sequential, categorical manner at higher levels of the hierarchical structure. For example, continuous sound data-streams reaching your ears need to be processed to understand spoken sentences. These sentences are build from discrete words and understanding spoken sentences thus depends upon being able to infer discrete sequences of words.
In this article The Discrete and Continuous Brain: From Decisions to Movement—And Back Again Thomas Parr explains an interesting active inference use-case for the oculomotor system (you eyes) where the policies to determine where to look are discrete and the actual muscle eye movement is continuous. The short summary, selecting discrete policies where to look drive the target fixation represented by continuous prior (v) acting as an interface between the discrete planning process and the processing of the continuous oculomotor system represented by hidden states (x) as the eye-muscles. Note that in case you are wondering why your own eye muscles are hidden states, remember from the previous notebooks that the brain is skull-bound and everything outside the brain needs to be inferred.
Applying the Free Energy Principle for discrete planning processes is based on the concept to minimize the expected (future) Free Energy. Selecting a policy (denoted as π, course of action) is based on the Expected Free Energy (denoted as G( π)) of the future states pursuing that policy. Lowering the Expected Free Energy can be done by addressing information and goal seeking parts.
The goal seeking part by pursuing preferred policies with expected outcomes (exploitation, short term memory of the proximal future, prior beliefs about the proximal future outcomes, chunking of a problem into subgoals). For example, let's go to France on holidays, like last year when we had beautiful weather.
The information seeking part by driving reduction of uncertainty (exploration). Either by sampling the world to reduce uncertainty of the unknown (hidden state exploration). For example let's try holidays in Spain this year, never been there before and there should be great sunshine. Or by reducing uncertainty about what would happen "if I did that" (hidden state transitions exploration, not all state transitions are deterministic and have e.g. a 60% chance of reward). For example, let's try France for holidays like last years, and see if the weather will be good again.
I wanted to position active inference as discrete planning into the bigger picture to create awareness, but for now my first focus is on the application of active inference and learning in the continuous domain. Also because it gives the most intuitive understanding of the (complicated) concepts. If it spiked your interest and you want to learn more, I would like to recommend you to read the tutorials that Oleg Solopchuk published on medium [ 1][ 2][ 3].
link code
To summarize the progress in a picture including the minimization of the Free energy using Gradient descent and incorporating planning: 
link code
Active Inference capsule ¶
For the active inference architecture, I would like to use a "building blocks" concept. The analogy would be the neuron as a building block to stack into deep neural network architectures. So, the first focus will be on the equivalent building blocks for active inference, in that case, the simplest building block with 1 sensory observation (y), 1 prior (v), and 1 hidden state (x). Hope you noticed that active inference is quite suitable for such a concept because the free energy definition in its most extended hierarchical form is still a sum of precision weighted quadratic prediction errors but now on all hierarchical levels.
F( ˜ y, μ)= 1 2 ∞ ∑ i= 1 p ∑ j= 0 q ∑ k= 1( 1 σ 2 z( i, j, k) ε 2 v( i, j, k)+ l n( σ 2 z( i, j, k)))+ 1 2 ∞ ∑ i= 1 p ∑ j= 0 n ∑ k= 1( 1 2 σ 2 w( i, j, k) ε 2 x( i, j, k)+ l n( σ 2 w( i, j, k)))
Where i is the index of the hierarchical level, j the index of the generalized coordinates of motion, and k the index of the sensory/state vector. Moreover, the gradient descent of each layer is only dependent on itself, the layer above, and the layer below (for inference, learning, etc). In other words, it is possible to apply decomposition into "active inference building blocks" stacking them to deep hierarchical active inference network architectures minimizing the Free Energy.
In the code, I call such a building block an active inference capsule (or ai_capsule). I considered calling it a neuron but since most probably a group of neurons performs active inference it did not resonate. It could represent a (micro) column but by naming it a column I would probably trigger all kinds of other debates. So, decided to give it a more neutral name: active inference capsule
A second argument is to start simple and avoid for the first applications tedious math (like concurrent prediction-error cycles throughout the hierarchy) such that proper understanding of the basics is gained before the complexities of full hierarchical models can be attempted to understand. The analogy of the argument would be to first understand neurons, connection weights, and basic back-propagation / gradient descent in an artificial neural network before attempting to understand the working of a deep hierarchical network (this is actually what is happening last years, artificial Neural Networks were delivering amazing results and only later scientific research was able to (partly?) figure out why it actually worked beyond expectation. Different topic, but here an interesting video and notice the same information theory arguments as applied in the Free Energy Principle.)
In my mind, I keep playing with the concept that active inference building capsules stacked in deep hierarchical networks could be the basis for a next-generation artificial neural network with human-like intelligence capabilities. So, this is the cue for all the SW engineering/robotics/data sciences/machine data scientists to get your attention, a new building block for true artificial intelligence that is both mathematically rigorous and neurologically plausible. Some initial successes are available but far from the deep learning success stories yet, I vote opportunity!
For the scope of 1 active inference capsule the generic hierarchical generative model as defined in the previous notebook: D ˜ μ( i) x= ˜ f( ˜ μ( i) x, ˜ μ( i) v, μ( i) θ)+ ˜ w( i)( μ( i) λ)
˜ μ( i− 1) v= ˜ g( ˜ μ( i) x, ˜ μ( i) v, μ( i) θ)+ ˜ z( i)( μ( i) λ)
˜ y= ˜ μ( 0) v
simplifies to a non-hierarchical formulation (because only 1 capsule) with 1 sensory observation (y), 1 prior (v) and 1 hidden state (x): D ˜ μ x= ˜ f( ˜ μ x, ˜ μ v, μ Θ)+ ˜ w( μ λ)
˜ y= ˜ g( ˜ μ x, ˜ μ v, μ Θ)+ ˜ z( μ λ)
In this and next notebooks I will use the following structure to build the capabilities (working code) for a single active inference capsule step-by-step:
I will start in this notebook with Inference by gradient descent,
The next notebook will focus on Acting by gradient descent,
followed by learning the generative model,
etc
link code
Inference by gradient descent for a single active inference capsule ¶
Perceptual inference (how fast neural activity estimate hidden/causal states) by minimizing the Free Energy for a single active inference capsule: ˜ μ( i) x= A r g m i n ˜ μ( i) x F( ˜ y, μ)
˜ μ( i) v= A r g m i n ˜ μ( i) v F( ˜ y, μ)
by gradient descents that can be written as a differential equation: ˙ ˜ μ x= D ˜ μ x− ∂ F( ˜ y, μ) ∂ ˜ μ x
˙ ˜ μ v= D ˜ μ v− ∂ F( ˜ y, μ) ∂ ˜ μ v
Taking the partial derivative of the Free Energy is rather straightforward. To build the intuition look at the simplest example (single hidden state x and single sensory channel y, no generalised coordinates of motion or hierarchy) where the free energy has the following form: F( y, μ)= 1 2 σ 2 w ε 2 x+ 1 2 σ 2 z ε 2 y+ 1 2 l n( σ 2 z σ 2 w)
where the derivative with respect to μ x is: ∂ F( y, μ) ∂ μ x= ∂ ε x ∂ μ x 1 σ 2 w ε x+ ∂ ε y ∂ μ x 1 σ 2 z ε y
In case of a hierarchical dynamic model in generalised coordinates of motion the derivative with respect to μ x can be obtained with some basic rules of differentiation (see appendix): ˙ ˜ μ( i) x= D ˜ μ( i) x− ∂ F( ˜ y, μ) ∂ ˜ μ( i) x= D ˜ μ( i) x−(..+..+.. ∂ F( ˜ y, μ)( i− 1) ∂ ˜ μ( i) x+ ∂ F( ˜ y, μ)( i) ∂ ˜ μ( i) x+ ∂ F( ˜ y, μ)( i+ 1) ∂ ˜ μ( i) x+..+..)= D ˜ μ( i) x− ∂ F( ˜ y, μ)( i) ∂ ˜ μ( i) x= D ˜ μ( i) x−( ∂ ˜ ε( i) ⊤ x ∂ ˜ μ( i) x ˜ Π( i) w ˜ ε( i) x+ ∂ ˜ ε( i) ⊤ v ∂~ μ x( i) ˜ Π( i) z ˜ ε( i) v)
and thus gradient descent can be compactly written in matrix notation as: ˙ ˜ μ( i) x= D ˜ μ( i) x− ∂ ˜ ε( i) ⊤ ∂ ˜ μ( i) x ˜ ξ( i)
Likewise the the derivative with respect to μ v. ˙ ˜ μ( i) v= D ˜ μ( i) v− ∂ F( ˜ y, μ) ∂ ˜ μ( i) v= D ˜ μ( i) v−(..+..+.. ∂ F( ˜ y, μ)( i− 1) ∂ ˜ μ( i) v+ ∂ F( ˜ y, μ)( i) ∂ ˜ μ( i) v+ ∂ F( ˜ y, μ)( i+ 1) ∂ ˜ μ( i) v+..+..)= D ˜ μ( i) v− ∂ F( ˜ y, μ)( i) ∂ ˜ μ( i) v− ∂ F( ˜ y, μ)( i+ 1) ∂ ˜ μ( i) v= D ˜ μ( i) v−( ∂ ˜ ε( i) ⊤ x ∂ ˜ μ( i) v ˜ Π( i) w ˜ ε( i) x+ ∂ ˜ ε( i) ⊤ v ∂~ μ v( i) ˜ Π( i) z ˜ ε( i) v)−( ∂ ˜ ε( i+ 1) ⊤ x ∂ ˜ μ( i) v ˜ Π( i+ 1) w ˜ ε( i+ 1) x+ ∂ ˜ ε( i+ 1) ⊤ v ∂~ μ v( i) ˜ Π( i+ 1) z ˜ ε( i+ 1) v)= D ˜ μ( i) v−( ∂ ˜ ε( i) ⊤ x ∂ ˜ μ( i) v ˜ Π( i) w ˜ ε( i) x+ ∂ ˜ ε( i) ⊤ v ∂~ μ v( i) ˜ Π( i) z ˜ ε( i) v)−( ˜ Π( i+ 1) z ˜ ε( i+ 1) v)
and thus gradient descent can be compactly written in matrix notation as: ˙ ˜ μ( i) v= D ˜ μ( i) v− ∂ ˜ ε( i) ⊤ ∂ ˜ μ( i) v ˜ ξ( i)− ˜ ξ( i+ 1) v
Where
˜ ξ( i)= ˜ Π( i) ˜ ε( i) is the generalized precision weighted prediction error on the i'th level in the hierarchy
˜ ε( i) is the generalized prediction error on the i'th level in the hierarchy: n=[ ˜ ε( i) v ˜ ε( i) x]=[ ˜ μ( i− 1) v− ˜ g( ˜ μ( i) x, ˜ μ( i) v) D ˜ μ( i) x− ˜ f( ˜ μ( i) x, ˜ μ( i) v)]
The T-transpose appears due to matrix notation form
Note that the parameters of the generative model Θ and the hyperparameters of the noise λ are invariant during this process and for the examples given as input. Remember μ x and μ v are estimated by fast neuronal states while μ Θ and μ λ adapt on slower timescales (e.g. synaptic efficacy) so invariant during perceptual inference. We simply assume the generative model / noise estimation has already been learned and is known (so, function of motion and sensory mapping are given as input).
Different tye of formulations are used for above equations in various papers but they are all mathematically equivalent. For example the precision weighted prediction error can be expressed (see appendix) as ˜ ξ( i)= ε( i)− Λ( i) ˜ ξ( i) where an auxiliary variable is introduced Λ( i)= ˜ Σ( i)− I.
In the picture below you will find some examples of formulations used in various papers, all expressing the same gradient descent. 
link code
Predictive coding ¶
In 1999 Rao and Ballard published this paper on predictive coding in de visual cortex, where a 3 layer hierarchical predictive coding network was used for encoding natural images. In this predictive coding setup, each level of the hierarchical model attempts to predict responses at the next lower level (e.g. in the visual cortex from V2 to V1) and the error (subtracting the prediction from the actual response) is sent back to the higher level. Predictable and thus redundant information is removed from the input signal which optimizes the amount of data passed. The prediction and error correction cycles occur concurrently throughout the hierarchy, so top-down predictions influence lower-level estimates and bottom-up prediction errors influence higher-level estimates. The lower levels operate on a smaller spatial scale (only see part of the image) while higher levels predict at larger scales because a higher level module predicts responses of several low-level modules. By comparing the computer simulations with actual neurological measurements (eg brain activity in macaque monkeys) they were able to conclude remarkable similarities strengthening the hypothesis that the cortex is using a hierarchical and predictive strategy for encoding natural images in the visual cortex, suggesting it is a general structure and function of the cortex at large. For example, the network learned oriented edges or bars in images at level 1 like observed in visual cortex studies. Their method applied a minimization scheme of a single energy or cost function: two squared prediction errors (error in sensory observation and error in hidden causes) for each level, sounds familiar? Active inference is a form of predictive coding. See this article of Karl Friston where he builds upon the remarkable work done by Rao and Ballard and basically extends it with precision weighting to represent the reliability of signals (uncertainty).
link code
Biological plausible predictive coding scheme ¶
The idea is to constraint the executed computations in a biologically plausible manner, meaning it needs to respect the following criteria (as defined in this paper):
Local computation. A neuron performs computation only on the basis of the inputs it receives from other neurons weighted by the strengths of its synaptic connections.
Local plasticity. The amount of synaptic weight modification is dependent on only the activity of the two neurons the synapse connects (and possibly a neuromodulator).
Minimal external control. The neurons perform the computation autonomously with as little external control routing information in different ways at different times as possible.
Plausible architecture. The connectivity patterns in the model should be consistent with basic constraints of connectivity in the neocortex.
It starts to unfold quite nicely.
If we take the picture used in the third notebook explaining the neuronal architecture 
and map the gradient descent equations
˙ ˜ μ( i) x= D ˜ μ( i) x− ∂ ˜ ε( i) ⊤ ∂ ˜ μ( i) x ˜ ξ( i)
˙ ˜ μ( i) v= D ˜ μ( i) v− ∂ ˜ ε( i) ⊤ ∂ ˜ μ( i) v ˜ ξ( i)− ˜ ξ( i+ 1) v
and map the prediction errors as precision weighted prediction error equations (see appendix)
˜ ξ( i) v= ˜ μ( i− 1) v− ˜ g( ˜ μ( i) x, ˜ μ( i) v)− Λ( i) z ˜ ξ( i) v
˜ ξ( i) x= D ˜ μ( i) x− ˜ f( ˜ μ( i) x, ˜ μ( i) v)− Λ( i) w ˜ ξ( i) x
the shape of the neural circuitry starts to appear 
as presented in many active inference papers 
Where:
link code
Simulation environment ¶
In order to showcase the power of active inference, to bridge from theory to working code, I was looking for an intuitive simulation environment where readers can relate to the results. You probably noticed in my previous notebook(s) that I emphasized that the emergence of intelligence has to be seen in an evolutionary plausible manner. Hence would like to introduce you to Hydar. It is a fictional being, invented by myself to explain active inference. But the name was not chosen by coincidence, it is inspired by Hydra.
Hydra (vulgaris) inspiration ¶
According this paper, the Hydra vulgaris is a fresh-water organism that belongs to a group of earliest animals in evolution to have simple nervous systems, and thus could help discover the basic principles of neural circuits more easily. Interestingly, the Hydra is transparent, so every neuron can be imaged in isolation. Christophe Dupre and Rafael Yuste engineered the Hydras' neurons (calcium imaging) so they emit green light in proportion to how active a neuron is. They could record the activity of every neuron of Hydra simultaneously by just watching their videos to see how green it was. Very interesting research data because until now we have been able to scan activities of specific neurons in e.g. animal brains but not yet of all neurons simultaneously. The nervous system of Hydra is composed of a few hundred to a few thousand neurons, depending on the size of the animal. Two main types of neurons: sensory cells, exposed to the external environment, and ganglion cells, which form a two-dimensional lattice known as a nerve net. The research discovered the neurons are organized in a series of functional networks that are anatomically non-overlapping (any neuron belonging to one network did not belong to any of the other two networks) and are associated with specific behaviours.  
Images by Christophe Dupre and Rafael Yuste from their paper
Very interesting concept to understand the basic principles of how the brain might work by investigating the visible real-time neural network in the Hydra. Now you know why I was inspired by Hydra.
Hydar ¶
So, Hydar is an early evolutionary imaginary simplest ancestor that must preserve its physical integrity to survive. I saw an interview with Karl Friston where he explained that he had the simplest biological lifeforms in mind when he started to formulate the Free Energy principle. So, with Hydar simulations we go right into the roots of the Free Energy principle, the place where I want to be.
Hydar is an aquatic animal and to exist, it must preserve it's physical integrity to survive. For example, it has to keep its body temperature around 17 degrees. It will do so by minimizing the surprise associated with the occurrence of atypical events in it's sensory observations, or in other words use active inference minimizing the underlying Free Energy. As you hopefully remember from the first notebook: to make sure internal states are not in surprising ranges, better make sure the external environment stays within a certain ¨un-surprising¨ range. In the simulations Hydar needs to keep in a certain depth range for example to survive.
Long live Hydar!
Hydar has one sensor (y), in this case to measure the temperature in degrees Celsius (quite amazing if a primal ancestor would have the knowledge of degrees celcius, but for now let's use this example). Hydar has one hidden state it tries to infer (x) and one prior (v) representing its top-down hypotheses of the hidden state. The hidden state that is being inferred differs per example. Hydar has one control signal (u) it can activate, in this case can Hydra set its own speed x′= u. Hydar lives in a one-dimensional plane and it can go up-and-down.
In the overview below you see an example environment (generative process) of Hydar. The temperature is depending on the depth. In the first examples the water will be still and later examples a case with moving water (eg tides) is introduced. 
link code
Code ¶
You will find the code to run active inference as part of a free and open source software that is called SPM from the Wellcome Trust Centre for Neuroimaging. SPM is the abbreviation for Statistical Parametric Mapping that has been designed for the analysis of brain imaging data sequences (from e.g. fMRI, PET, SPECT, EEG and MEG), e.g. statistical processes used to test hypotheses about brain functions based on imaging data. The Wiki is also a useful reference.
But if you try to dig into the code immediately (like I did) be prepared to read MATLAB code like e.g. from spm_DEM_z.m below:
(in this case generate the noise with temporal smoothness, see notebook Learn by example: Active Inference & noise)
So, I needed to back-out and first understand the concepts much better in order to try to understand the code, hence my notebook series.
The objective of the notebooks series is to help catalyse knowledge and research on Active Inference by reaching a much broader audience. Hence I added Python code in the notebooks to give examples(e.g. can't even run proprietary Matlab code in Kaggle notebooks).
link code
Code example 1 ¶
The first example is a proof-of-concept that the very fundament works: minimize Free Energy for perceptual inference. One active inference capsule (single observation, single hidden state, single prior) without generalised coordinates of motion inferring the hidden state based on the sensory observations. The single prior is given as input. The example is set in the simulation environment where Hydar needs to infer the depth even when the sensor readings are not what is expected.
Please do visit the notebook active inference code by example-1 to experience/explore for yourself.
I created for myself the picture below to get the overview of the example. To the right you see the generative process, the simulation environment which generates the sensory observations (in this case a stationary depth causing Hydar to experience a certain temperature). To the left you see the generative model, the world as modelled by Hydar with a single active inference capsule learning to infer the true depth/temperature. The heart of perceptual inference by minimizing the free energy ( in this example F( y, μ)= 1 2 σ 2 w ε 2 x+ 1 2 σ 2 z ε 2 y+ 1 2 l n( σ 2 z σ 2 w)) iteratively by following steps:
First the 2 prediction errors are calculated: ε x= μ x− f( μ x, μ v)= μ x− μ v and ε y= y− g( μ x, μ v)
Next the motion of the hidden state ˙ μ x=− α x ∂ F( y, μ) ∂ μ x where ∂ F( y, μ) ∂ μ x)= 1 σ 2 w ε x− g′( μ x) 1 σ 2 z ε y. It basically boils down to moving/updating μ x to minimize the predictions errors by iteratively taking steps proportional to the negative of the partial derivative of the Free Energy 
Interesting to observe that the noise estimations in the experiments start to have a different interpretation
Code example 2 ¶
The second code example is the same use-case as the first code example but this time including generalised coordinates of motion. See notebook active inference code by example-2.
Active inference can make use of the information embedded in the higher order motions coordinates of motion (e.g. speed, acceleration, etc) and how much is controlled by the noise smoothness variance parameters ( s 2 w and s 2 z). They effectively determine how much the higher order coordinates of motion are weighted in the calculations (they are used to calculate the precision matrices ˜ Π w and ˜ Π z). The basic idea is that active inference makes use of the information available in the higher order coordinates of motion to make better predictions. But the experiments also make clear that estimating the correct noise smoothness is important, e.g. a (totally) wrong estimation can lead to Hydars extinction.
link code
Code example 3 ¶
The third code example is the same use-case as the first code example but following the approach of tutorial on the free-energy framework for modelling perception and learning from Rafal Bogacz where the prediction errors are also cast as motions with the argument it is more biologocal plausible, meaning "an extended version of the model in which the neurons only sum their inputs, and synaptic plasticity only depends on activity of pre-synaptic and post-synaptic neurons".
Please do visit the notebook active inference code by example-3 to experience/explore for yourself.
The key design change compared to the first example is to cast the prediction error also as a motion ˙ ε, just like we did for ˙ μ x, how the prediction error develops taking small steps down to convergence. The heart of predictive coding perceptual inference is iteratively taking following steps:
First the motion of the 2 prediction errors are calculated/executed:
˙ ε x= μ x− f( μ x, μ v)− σ 2 w ε x= μ x− μ v− σ 2 w ε x
˙ ε y= y− g( μ x, μ v)− σ 2 z ε y
Next the motion of the hidden state is calculated/executed: ˙ μ x=− α x( ε x− g′( μ x) ε y).
If you wonder how these equations relate to the equations of code example 1: once the predictions erros converge then ˙ ε=0. By setting ˙ ε=0 the prediction errors can be calculated (e.g. ε x= μ x− μ v σ 2 w and substituting those back into the motion of the hidden state you get exactly the same equation as code example 1: ˙ μ x=− α x( μ x− μ v σ 2 w− g′( μ x) y− g( μ x, μ v) σ 2 z).
Again I created for myself the picture below to capture the overview of the example. 
And if I rotate the inversion part of the picture 90 degrees to the right you see the neuronal architecture as presented in the earlier section biological plausible predictive coding scheme appearing 
link code
Camp improving perception ¶
You made it and reached camp improving perception!
To summarize the progress again in a picture:
Minimizing the Laplace encoded Free Energy with Active Inference boils down to minimizing a quadratic sum of prediction errors, mediated by the precision (inverse variances) on each hierarchical level. It is an automatable optimization problem through prediction error minimization by a gradient descent on the Free Energy.
˜ x is the continuous stream of trajectories of external hidden environment states the brain tries to infer. Shorthand notation for the vector → x h y p o t h e s e s( t) ∈ R n( p+ 1) with n number of states and generalised coordinates of motion embedding order p.
˜ v are the causal states, the hidden causes that link the functional hierarchical levels. The predictions that flow down the hierarchy and act as priors.
˜ y is the continuous stream of trajectories of sensory observations, the data from the available sensory set. Shorthand notation for the vector → y o b s e r v a t i o n( t) ∈ R q( p+ 1) with q number of sensors and generalised coordinates of motion embedding order p.
u is the continuous stream of actions that are performed on the environment, control signal. Shorthand notation for the vector → u( t) ∈ R l with l number of controls.
The brain infers the world in which it is immersed:
by a generative model encoding a probabilistic model of the environment/world in which it is immersed. D ˜ μ( i) x= ˜ f( ˜ μ( i) x, ˜ μ( i) v, μ( i) θ)+ ˜ w( i)( μ( i) λ) ˜ μ( i− 1) v= ˜ g( ˜ μ( i) x, ˜ μ( i) v, μ( i) θ)+ ˜ z( i)( μ( i) λ) ˜ y= ˜ μ( 0) v where Θ( i) are the parameters of the generative model and λ( i) the hyperparameters of the noise throughout the hierarchy
by estimating hidden causes μ={ ˜ μ( i) x, ˜ μ( i) v, μ( i) Θ, μ( i) λ}. Under the Laplace/mean-field approximations estimating hidden causes simplify to estimating mean μ instead of a full recognition density . ˜ μ( i) x is shorthand notation for the i'th vector in the hierarchy with ˜ → μ x( t) ∈ R n( p+ 1).
by gradient descents on the Free Energy with respect to the hidden causes ˜ μ( i) x, ˜ μ( i) v, μ( i) Θ, μ( i) λ, u and thus lowering surprise in sensory states on all hierarchical layers:
Improving perception: ˙ ˜ μ( i) x= D ˜ μ( i) x− ∂ F( ˜ y, μ) ∂ ˜ μ( i) x and ˙ ˜ μ( i) v= D ˜ μ( i) v− ∂ F( ˜ y, μ) ∂ ˜ μ( i) v
Acting on the environment: ˙ u=− ∂ F( ˜ y, μ) ∂ u
Learning the generative model: ¨ μ( i) Θ=− ∂ F( ˜ y, μ) ∂ μ( i) Θ
Attention or optimizing precision of uncertainty: ¨ μ( i) λ=− ∂ F( ˜ y, μ) ∂ μ( i) λ
Planning by optimizing the Expected Free Energy: A r g m i n π G( π) 
link code
How the brain might function- part 5 ¶
Now you reached camp active inference, you not only have theoretic understanding, but also have seen active inference working. Hope you will spend some time over here and try the code for yourself.
active inference code by example-1
active inference code by example-2
active inference code by example-3
In this notebook we have seen how active inference is minimizing the Free Energy by a gradient descent (the standard way neural networks learn) resulting in a form of enhanced predictive coding (prediction error minimization based on precision weighted prediction errors). Also for this notebook I end with an example in the hope it will inspire you to continue your journey understanding active inference. One of the predictive coding implementations that caught the attention of a broader public is called Prednet. Prednet is a deep Predictive Network that learns to predict the next frame of a video. It is inspired by the principles of predictive coding from neuroscience literature but note that it is not exactly the same as active inference (see here for a quick comparison). I highlight it to showcase the potential of predictive coding. Here you will find the paper and the code. Below some next frame predictions are shown on the Caltech Pedestrian dataset . Quite amazing to see the network can learn to predict a trajectory of a turning car, to fill in the background it leaves behind, to predict the appearance of shadows, etc. And in case you argue that the prediction can be quite simple, just predict the previous video frame. Prednet outperforms significantly a copy last frame approach. It can learn hidden or latent variables and is able to generalize over different video footage, e.g. the model was trained on KITTI dataset and sequences below are from the Pedestrian dataset. 
.
Video footage from: https://coxlab.github.io/prednet/
Next notebook we will extend the active inference capsule capabilities and investigate how action is integrated in the framework. So if you are interested to learn more about it please keep on reading in the next notebook: Learn by example: Active Inference in the brain -5
I hope you liked my notebook (upvote top right), my way to contribute back to this fantastic Kaggle platform and community. Let me know if these notes helped you to better understand active inference and the free energy principle. My intent is to help catalyze knowledge and research on Active Inference in an engineering/robotics/data sciences/machine learning context.
I would like to especially thank Sherin Grimbergen, I could build my understanding on his investigations and our dialogues helped me a lot understanding active inference. Also special thanks to Corrado Pezzato for proofreading and giving valuable feedback. And finally please remember, this notebook is just trying to make the brilliant work of Karl Friston more accessible, it might Hold the Key to True AI !
link code
Appendix ¶
Prediction errors and precision weigthed prediction errors ¶
In this notebook series I used the generalized prediction error in the summary equations
˜ ε( i)=[ ˜ ε( i) v ˜ ε( i) x]=[ ˜ μ( i− 1) v− ˜ g( ˜ μ( i) x, ˜ μ( i) v) D ˜ μ( i) x− ˜ f( ˜ μ( i) x, ˜ μ( i) v)]
with ˜ y= ˜ μ( 0) v
In some papers I noticed the prediction errors are expressed as generalized precision weighted prediction errors and the equations are expressed as
˜ ξ( i)=[ ˜ ξ( i) v ˜ ξ( i) x]=[ ˜ μ( i− 1) v− ˜ g( ˜ μ( i) x, ˜ μ( i) v)− Λ( i) z ˜ ξ( i) v D ˜ μ( i) x− ˜ f( ˜ μ( i) x, ˜ μ( i) v)− Λ( i) w ˜ ξ( i) x]
with ˜ y= ˜ μ( 0) v and an auxiliary variable is introduced Λ( i)= ˜ Σ( i)− I
It are mathematically equivalent expressions: ˜ ξ( i)= ˜ ε( i)− ˜ ε( i)+ ˜ ξ( i)= ε( i)− ˜ Σ( i) ˜ Π( i) ˜ ε( i)+ ˜ ξ( i)= ε( i)− ˜ Σ( i) ˜ ξ( i)+ ˜ ξ( i)= ε( i)−( ˜ Σ( i)− I) ˜ ξ( i)= ε( i)− Λ( i) ˜ ξ( i)
Basic differentiation rules ¶
Some basic differentiation rules reminder: the derivative of a sum of functions is the sum of their derivatives, the derivative of a difference of functions is the difference of their derivatives. The derivative of any constant function is always 0. 
Image by Khan Academy
PREDNET compared to active inference ¶
link code
Conventions and Symbols ¶
Below the symbols, functions and conventions used in this notebook
Symbols/functions
Description
Alternative
˜ x( i)
continuous stream of trajectories of external hidden environment states the brain tries to infer. Shorthand notation for the i'th vector in the hierarchy → x h y p o t h e s e s( t) ∈ R n( p+ 1) with n number of states and generalised coordinates of motion embedding order p.
˜ v( i)
the causal states, the hidden causes that link the functional hierarchical levels. The predictions that flow down the hierarchy and act as priors, and that up the hierarchy as sensory signals.
˜ y= ˜ v( 0)
continuous stream of trajectories of of sensory observations, the data from the available sensory set. Shorthand notation for the vector → y o b s e r v a t i o n( t) ∈ R q( p+ 1) with q number of sensors and generalised coordinates of motion embedding order p.
also sometimes noted ¨s¨ as of sensory states
u
actions, control signal, The action that can be performed on the environment. Shorthand notation for the vector → u( t) ∈ R l with l number of controls.
also noted as ¨a¨ or ¨ α ¨
F( ˜ y, μ)
The Free Energy
F( ˜ y, ζ) which simplifies under lapace assumption to F( ˜ y, μ)
q( ϑ; μ)
recognition density with sufficient statistics μ,
the brain to estimate the hidden causes given observations y
Ensemble density; q( ϑ; ζ) Simplifies under lapace assumption to q( ϑ; μ)= μ.
Where μ={ ˜ μ x, μ Θ, μ λ}.
Also written as q( x; μ) if only estimating the hidden state x.
p( ϑ, ˜ y)
Generative density: the brain encoding a probabilistic model
of the environment/world in which it is immersed.
ϑ
Union of ˜ x( i), ˜ v( i), θ( i), λ( i), the hidden causes
ζ
sufficient statistics (e.g. for a Gaussian distribution: mean 𝜇, variance 𝜎 2) for the recognition density
μ
(because under Laplace approximation sufficient statistics simplifies to mean μ),
in few papers noted as λ but λ more often used for hyperparameters for random noise)
μ
={ ˜ μ( i) x, ˜ μ( i) v, μ( i) Θ, μ( i) λ} Belief or estimation of the hidden causes.
˜ μ( i) x shorthand notation for the i'th vector in the hierarchy ˜ → μ x( t) ∈ R n.
sufficient statistics ζ for the recognition density under Laplace approximation simplifies to mean μ.
f( x) g( x)
Equation of motion (f) and sensory mapping (g) to encode a generative model of the environment.
f( x, θ) g( x, θ)
f g p( x, u) g g p( x)
Equation of motion and sensory mapping in the generative process:
generating the sensory observations in simulations.
sometimes donated in bold f(x,u)) g(x))
θ( i)
Parameters of the hierarchical generative model, eg f( x, θ) g( x, θ)
λ( i)
Hyperparameters defining noises, eg → w, → z
˜ w( i), ˜ Σ( i) w, ˜ Π( i) w
Noise on hidden state, covariance matrix and precision matrix
s 2 w, S( s 2 w)
The variance of the Gaussian filter and the temporal covariance matrix used to create the coloured noise ˜ w
˜ z( i), ˜ Σ( i) z, ˜ Π( i) z
Noise on observation, covariance matrix and precision matrix
s 2 z, S( s 2 z)
The variance of the Gaussian filter and the temporal covariance matrix used to create the coloured noise ˜ z
˜ ε( i)
Prediction error
˜ ξ( i)
Precision weighted prediction error ˜ ξ( i)= ˜ Π( i) ˜ ε( i)
Λ( i)
Auxiliary variable Λ( i)= ˜ Σ( i)− I
˜ ε( i) x
Prediction error between motion of belief and belief of motion
˜ ε( i) v
Prediction error between observation and expected observation
p
Embedding order of generative model. p ∈ Z+ is the number of derivatives. p= 6 means we have μ( 0) until μ( 6), which means the vector has 7 entries
i
the index of the hierarchical level
j
the index of the generalised coordinates of motion
k
the index of the sensory/state vector
| Convention | description | | --- | --- | --- | --- | | I n | Identity matrix of size R n × n | | ⊗ | The kronecker tensor product | | ˙ ∗ vs. ∗′ | Derivative (physical) vs. motion (belief) | | ∗( n) vs. ∗ n | n-th component vs. exponent ∗ n | | | | ˜ ∗ | Variable or matrix in generalised form |
License
This Notebook has been released under the Apache 2.0 open source license.
Continue exploring
Input 1 file arrow_right_alt
Output 0 files arrow_right_alt
Logs 7.0 second run - successful arrow_right_alt
Comments 17 comments arrow_right_alt