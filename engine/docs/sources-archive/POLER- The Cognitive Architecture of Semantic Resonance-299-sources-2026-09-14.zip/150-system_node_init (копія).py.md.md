#!/usr/bin/env python
Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
Author: Qiming Sun 
''' Hartree-Fock '''
import sys import tempfile import time
from functools import reduce import numpy import scipy.linalg import h5py from pyscf import gto from pyscf import lib from pyscf.lib import logger from pyscf.scf import diis from pyscf.scf import _vhf from pyscf.scf import chkfile from pyscf.scf import dispersion from pyscf.data import nist from pyscf import config
==========================================================
ИНТЕГРАЦИЯ POLER (DYNAMIS Layer Import)
==========================================================
try: from pyscf import poler _POLER_AVAILABLE = True except ImportError: _POLER_AVAILABLE = False
WITH_META_LOWDIN = getattr(config, 'scf_analyze_with_meta_lowdin', True) PRE_ORTH_METHOD = getattr(config, 'scf_analyze_pre_orth_method', 'ANO') MO_BASE = getattr(config, 'MO_BASE', 1) TIGHT_GRAD_CONV_TOL = getattr(config, 'scf_hf_kernel_tight_grad_conv_tol', True) MUTE_CHKFILE = getattr(config, 'scf_hf_SCF_mute_chkfile', False)
def kernel(mf, conv_tol=1e-10, conv_tol_grad=None, dump_chk=True, dm0=None, callback=None, conv_check=True, **kwargs): '''kernel: the SCF driver.
You see this error message because of the API updates in pyscf v0.11. Keyword argument "init_dm" is replaced by "dm0"''') cput0 = (logger.process_clock(), logger.perf_counter()) if conv_tol_grad is None: conv_tol_grad = numpy.sqrt(conv_tol) logger.info(mf, 'Set gradient conv threshold to %g', conv_tol_grad)
def energy_elec(mf, dm=None, h1e=None, vhf=None): r'''Electronic part of Hartree-Fock energy, for given core hamiltonian and HF potential
def energy_tot(mf, dm=None, h1e=None, vhf=None): r'''Total Hartree-Fock energy, electronic part plus nuclear repulsion See :func:scf.hf.energy_elec for the electron part
def get_hcore(mol): '''Core Hamiltonian
def get_ovlp(mol): '''Overlap matrix ''' return mol.intor_symmetric('int1e_ovlp')
def init_guess_by_minao(mol): '''Generate initial guess density matrix based on ANO basis, then project the density matrix to the basis set defined by mol
coreshl defines the core shells to be removed in the initial guess
Compared to ANO valence basis, to check whether the ECP basis set has
reasonable AO-character contraction.  The ANO valence AO should have
significant overlap to ECP basis if the ECP basis has AO-character.
normalize electron number
s = mol.intor_symmetric('int1e_ovlp')
dm = mol.nelectron / (dms).sum()
def init_guess_by_1e(mol): '''Generate initial guess density matrix from core hamiltonian
def init_guess_by_atom(mol): '''Generate initial guess density matrix from superposition of atomic HF density matrix.  The atomic HF is occupancy averaged RHF
def init_guess_by_huckel(mol): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def init_guess_by_mod_huckel(mol): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def Kgwh(Ei, Ej, updated_rule=False): '''Computes the generalized Wolfsberg-Helmholtz parameter'''
def _init_guess_huckel_orbitals(mol, updated_rule = False): '''Generate initial guess density matrix from a Huckel calculation based on occupancy averaged atomic RHF calculations, doi:10.1021/acs.jctc.8b01089
def init_guess_by_chkfile(mol, chkfile_name, project=None): '''Read the HF results from checkpoint file, then project it to the basis defined by mol
def init_guess_by_sap(mol, sap_basis, **kwargs): '''Generate initial guess density matrix from a superposition of atomic potentials (SAP), doi:10.1021/acs.jctc.8b01089. This is the Gaussian fit implementation, see doi:10.1063/5.0004046.
def get_init_guess(mol, key='minao', **kwargs): '''Generate density matrix for initial guess
eigenvalue of d is 1
def level_shift(s, d, f, factor): r'''Apply level shift :math:\Delta to virtual orbitals
def damping(f, f_prev, factor): return f*(1-factor) + f_prev*factor
def make_sap(mol, sap_basis): '''Superposition of atomic potentials (SAP) potential matrix
full density matrix for RHF
def make_rdm1(mo_coeff, mo_occ, **kwargs): '''One-particle density matrix in AO representation
def make_rdm2(mo_coeff, mo_occ, **kwargs): '''Two-particle density matrix in AO representation
################################################
for general DM
hermi = 0 : arbitrary
hermi = 1 : hermitian
hermi = 2 : anti-hermitian
################################################ def dot_eri_dm(eri, dm, hermi=0, with_j=True, with_k=True): '''Compute J, K matrices in terms of the given 2-electron integrals and density matrix:
def get_jk(mol, dm, hermi=1, vhfopt=None, with_j=True, with_k=True, omega=None): '''Compute J, K matrices for all input density matrices
def get_veff(mol, dm, dm_last=None, vhf_last=None, hermi=1, vhfopt=None): '''Hartree-Fock potential matrix for the given density matrix
def get_fock(mf, h1e=None, s1e=None, vhf=None, dm=None, cycle=-1, diis=None, diis_start_cycle=None, level_shift_factor=None, damp_factor=None, fock_last=None): '''F = h^{core} + V^{HF}
def get_occ(mf, mo_energy=None, mo_coeff=None): '''Label the occupancies for each orbital
def get_grad(mo_coeff, mo_occ, fock_ao): '''RHF orbital gradients
def analyze(mf, verbose=logger.DEBUG, with_meta_lowdin=WITH_META_LOWDIN, origin=None, **kwargs): '''Analyze the given SCF object:  print orbital energies, occupancies; print orbital coefficients; Mulliken population analysis; Diople moment. ''' from pyscf.lo import orth from pyscf.tools import dump_mat mo_energy = mf.mo_energy mo_occ = mf.mo_occ mo_coeff = mf.mo_coeff log = logger.new_logger(mf, verbose)
def dump_scf_summary(mf, verbose=logger.DEBUG): if not mf.scf_summary: return
def mulliken_pop(mol, dm, s=None, verbose=logger.DEBUG): r'''Mulliken population analysis
def mulliken_meta(mol, dm, verbose=logger.DEBUG, pre_orth_method=PRE_ORTH_METHOD, s=None): '''Mulliken population analysis, based on meta-Lowdin AOs. In the meta-lowdin, the AOs are grouped in three sets: core, valence and Rydberg, the orthogonalization are carried out within each subsets.
mulliken_pop_meta_lowdin_ao = mulliken_meta
def eig(h, s): '''Solver for generalized eigenvalue problem
def canonicalize(mf, mo_coeff, mo_occ, fock=None): '''Canonicalization diagonalizes the Fock matrix within occupied, open, virtual subspaces separatedly (without change occupancy). ''' if fock is None: dm = mf.make_rdm1(mo_coeff, mo_occ) fock = mf.get_fock(dm=dm) coreidx = mo_occ == 2 viridx = mo_occ == 0 openidx = ~(coreidx | viridx) mo = numpy.empty_like(mo_coeff) mo_e = numpy.empty(mo_occ.size) for idx in (coreidx, openidx, viridx): if numpy.count_nonzero(idx) > 0: orb = mo_coeff[:,idx] f1 = reduce(numpy.dot, (orb.conj().T, fock, orb)) e, c = scipy.linalg.eigh(f1) mo[:,idx] = numpy.dot(orb, c) mo_e[idx] = e return mo_e, mo
def dip_moment(mol, dm, unit='Debye', origin=None, verbose=logger.NOTE, **kwargs): r''' Dipole moment calculation
def quad_moment(mol, dm, unit='DebyeAngstrom', origin=None, verbose=logger.NOTE, **kwargs): r''' Calculates traceless quadrupole moment tensor.
def uniq_var_indices(mo_occ): ''' Indices of the unique variables for the orbital-gradients (or orbital-rotation) matrix. ''' occidxa = mo_occ>0 occidxb = mo_occ==2 viridxa = ~occidxa viridxb = ~occidxb mask = (viridxa[:,None] & occidxa) | (viridxb[:,None] & occidxb) return mask
def pack_uniq_var(x, mo_occ): ''' Extract the unique variables from the full orbital-gradients (or orbital-rotation) matrix ''' idx = uniq_var_indices(mo_occ) return x[idx]
def unpack_uniq_var(dx, mo_occ): ''' Fill the full orbital-gradients (or orbital-rotation) matrix with the unique variables. ''' nmo = len(mo_occ) idx = uniq_var_indices(mo_occ)
def as_scanner(mf): '''Generating a scanner/solver for HF PES.
class SCF_Scanner(lib.SinglePointScanner): def init(self, mf_obj): self.dict.update(mf_obj.dict) self._last_mol_fp = mf_obj.mol.ao_loc
class SCF(lib.StreamObject): '''SCF base class.   non-relativistic RHF.
##################################################
don't modify the following attributes, they are not input options
employing the updated GWH rule from doi:10.1021/ja00480a005.''') mo_energy, mo_coeff = _init_guess_huckel_orbitals(mol, updated_rule=True) mo_occ = self.get_occ(mo_energy, mo_coeff) return self.make_rdm1(mo_coeff, mo_occ)
This is the Gaussian fit version as described in doi:10.1063/5.0004046.''') if isinstance(sap_basis, str): atoms = [coord[0] for coord in mol._atom] sapbas = {} for atom in set(atoms): single_element_bs = load(sap_basis, atom) if isinstance(single_element_bs, dict): sapbas[atom] = numpy.asarray(single_element_bs[atom][0][1:], dtype=float) else: sapbas[atom] = numpy.asarray(single_element_bs[0][1:], dtype=float) logger.note(self, f'Found SAP basis {sap_basis.split("/")[-1]}') elif isinstance(sap_basis, dict): sapbas = {} for key in sap_basis: sapbas[key] = numpy.asarray(sap_basis[key][0][1:], dtype=float) else: logger.error(self, 'sap_basis is of an unexpected datatype.') return init_guess_by_sap(mol, sap_basis=sapbas, **kwargs)
class KohnShamDFT: '''A mock DFT base class
class RHF(SCF): doc = SCF.doc
def _hf1e_scf(mf, args):logger.info(mf, '\n')logger.info(mf, '******* 1 electron system ********') mf.converged = True h1e = mf.get_hcore(mf.mol) s1e = mf.get_ovlp(mf.mol) mf.mo_energy, mf.mo_coeff = mf.eig(h1e, s1e) mf.mo_occ = mf.get_occ(mf.mo_energy, mf.mo_coeff) mf.e_tot = mf.mo_energy[mf.mo_occ>0][0].real + mf.mol.energy_nuc() if mf.chkfile: mf.dump_chk(mf.chkfile) mf._finalize() return mf.e_tot
del (WITH_META_LOWDIN, PRE_ORTH_METHOD)