> Source: https://www.biomolecular-modeling.com/Software_Quantum_Chemistry.html

GAMESS, Gaussian - software for Quantum Chemistry
Home
Products
Gallery
Download
Contacts
Credits
Forum
Quantum Chemistry
ORCA - An ab initio, DFT and semiempirical SCF-MO package
orcaforum.cec.mpg.de
NWChem - Open Source High-Performance Computational Chemistry
www.nwchem-sw.org
GAMESS - the General Atomic and Molecular Electronic Structure System
The Gordon Research Group
Firefly freely available ab initio and DFT computational chemistry program
Laboratory of Chemical Cybernetics at Moscow State University
CP2K a quantum chemistry and solid state physics software package
www.cp2k.org
PSI an open-source suite of ab initio quantum chemistry programs
www.psicode.org
Gaussian electronic structure program
www.gaussian.com
Molcas quantum chemistry software developed by scientists to be used by scientists
www.molcas.org
ArgusLab molecular modeling, graphics, and drug design program
Theoretical and Computational Biophysics Group.
Q-Chem a comprehensive ab initio quantum chemistry package
Q-Chem, Inc.
Mopac general purpose semi-empirical molecular orbital program
Serena Software.
ADF Amsterdam Density Functional
Software for Chemistry & Materials (SCM)
CPMD - Car�Parrinello molecular dynamics
www.cpmd.org
Jaguar is an ab initio quantum chemistry package for both gas and solution phase calculations, with strength in treating metal-containing systems
Schrodinger
Spartan is a molecular modelling and computational chemistry application from Wavefunction
Wavefunction, Inc.
More software...
Software for
Molecular Design
Simulations
Abalone
Ascalaph
Packages
Documents
Tutor
Useful Links
Site map 
Copyright © 2006-2009 Agile Molecule. All rights reserved