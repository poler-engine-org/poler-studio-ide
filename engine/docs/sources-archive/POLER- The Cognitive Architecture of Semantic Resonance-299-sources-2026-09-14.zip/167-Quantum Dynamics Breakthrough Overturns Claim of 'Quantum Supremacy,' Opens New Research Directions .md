> Source: https://www.simonsfoundation.org/2026/05/21/quantum-dynamics-breakthrough-overturns-claim-of-quantum-supremacy-opens-new-research-directions/

Quantum Dynamics Breakthrough Overturns Claim of 'Quantum Supremacy' 
We value your privacy
We use cookies to provide you with the best online experience. You can decline our cookies by clicking on the Do Not Share My Information link. Visit our Privacy Policy to learn more about our use of cookies.
Do Not Share My Personal Information
Opt-out Preferences 
We use third-party cookies that help us analyze how you use this website, store your preferences, and provide the content that is relevant to you. However, you can opt out of these cookies by checking "Do Not Share My Personal Information" and clicking the "Save My Preferences" button. Once you opt out, you can opt in again at any time by unchecking "Do Not Share My Personal Information" and clicking the "Save My Preferences" button. [-]
Do Not Share My Personal Information
Cancel Save My Preferences
Your opt-out preference has been honored.
Banner closes automatically in s... 
Program Areas
Mathematics & Physical Sciences
Life Sciences
Autism Research Initiative
Neuroscience
Simons Collaborations
Flatiron Institute
Science, Society & Culture
Multidisciplinary Programs
Funding
Funding Opportunities
Policies and Procedures
Award Instructions
Simons Award Manager (SAM) FAQs and Videos
News
Announcements
Articles
Videos
What We're Reading
Events
Presidential Lectures
Presents
About
About Us
Annual Report
Leadership
Our History
Media Relations
Brand Portal
Careers
Summer at Simons
Visitor Information
Contact Us
Simons Foundation
CCQ
CCQ
Research
Dynamics and Control
Quantum Materials
Software Libraries
Theory and Methods
Publications
News
Events
2025-2026 DMFT-QE Symposium
New York City Condensed Matter Physics
Quantum Cafe
Workshop
Event Videos
Software
About
Careers
TRIQS Tutorial Videos
Graduate Scholars Program
Code of Conduct
Media Relations
Contact
People
Home
Flatiron Institute
Center for Computational Quantum Physics
News
Quantum Dynamics Breakthrough Overturns Claim of 'Quantum Supremacy,' Opens New Research Directions
By adapting an algorithm from the 1980s to the modern context of mathematical objects called tensor networks, researchers at the Flatiron Institute show that classical computers can tackle a class of problems previously claimed to be solvable only by quantum computers.
[](mailto:?subject=Simons Foundation - Quantum Dynamics Breakthrough Overturns Claim of ‘Quantum Supremacy,’ Opens New Research Directions&body=https://www.simonsfoundation.org/2026/05/21/quantum-dynamics-breakthrough-overturns-claim-of-quantum-supremacy-opens-new-research-directions/)
[](mailto:?subject=Simons Foundation - Quantum Dynamics Breakthrough Overturns Claim of ‘Quantum Supremacy,’ Opens New Research Directions&body=https://www.simonsfoundation.org/2026/05/21/quantum-dynamics-breakthrough-overturns-claim-of-quantum-supremacy-opens-new-research-directions/)
May 21, 2026 
Tensor networks enable researchers to tackle quantum physics problems previously thought to be solvable only by quantum computers. Lucy Reading-Ikkanda/Simons Foundation
Using a conventional computer and cutting-edge mathematical tools and code, physicists at the Center for Computational Quantum Physics (CCQ) at the Simons Foundation's Flatiron Institute and collaborators at Boston University have cracked a daunting quantum physics problem previously claimed to be solvable only by quantum computers.
The technique is so groundbreaking in its efficiency that the researchers were even able to use a personal laptop to solve the problem. By enabling scientists to squeeze extra problem-solving power from classical computers, the breakthrough methodology is opening new avenues for research on quantum dynamics and may be useful as a protocol for solving problems about finding the optimal solution amid an abundance of feasible ones.
The researchers report their work May 21 in Science.
The problem at hand involves simulating a quantum system composed of hundreds of interacting 'qubits' — the quantum computing equivalent of the bits used in classical computers — arranged in square, cubic or diamond lattices. While bits can have values of 0 or 1, qubits can exist in a superposition of multiple values, making it challenging for traditional computers to simulate their dynamics.
In a March 2025 article, also published in Science, a group of quantum computing researchers reported that they'd calculated the dynamics of a particularly intricate system of qubits using a quantum computer. They further claimed that their feat was impossible for classical computers to match.
“Whenever we [at the CCQ] see these kinds of claims, we're always a bit skeptical,” says Joseph Tindall, an associate research scientist at the CCQ and first author on the new Science paper. “Like, 'Did you try this? Did you try that?'”
The problem served as an opportunity to take their tools “out for a test drive,” says study co-author and CCQ research scientist Miles Stoudenmire. “We could have picked some more arbitrary target,” Stoudenmire says. “But it was like 'Why not pick this one that has a big claim attached to it?'”
The work was particularly challenging due to quantum entanglement, which means the qubits can't be treated individually, even when they're far apart. That entanglement requires sophisticated algorithms to tackle, Tindall says.
“When you have lots of particles that interact by quantum physics, you have this wave function that describes the state of the system,” Tindall says. “It's this huge object that rapidly gets bigger and bigger the more particles there are.”
As the wave function's size grows exponentially, “I just can't directly store it on my computer,” he says. Working with such massive wave functions is a common challenge in quantum physics, but it's required for tasks such as predicting the properties of quantum materials, like superconductors. 
Lucy Reading-Ikkanda/Simons Foundation
The CCQ team achieved their breakthrough by developing and implementing new tools based on tensor networks, which Tindall likens to “a zip file for the wave function where you've taken all this information, and you've compressed it into this mathematical data structure full of these small tables of numbers that are interconnected to each other.”
The tensor networks made the problem feasible for classical computers. Tindall performed many of the initial calculations on a laptop computer using code from a high-performance tensor network software library developed at the CCQ called ITensor. The recently published simulations exemplify how the ITensor team is discovering new ways to repurpose tensor methods for novel applications. Those simulations capture the three-dimensional dynamics using a 3D tensor network.
“It's this very powerful compression that can be very effective, but it's a pretty complex mathematical object,” Tindall says. “This really is a bit of a frontier, because working with these objects — especially in three dimensions — is very untrodden. You need sophisticated codes and algorithms to deal with them; it's a software engineering challenge in itself.”
The team ran many of their simulations using relatively modest computational resources. Tindall performed the initial calculations using an older type of algorithm — called belief propagation — from the 1980s that has been recently adapted for quantum systems. “It's a little more approximate than some of the other methods, but it's way cheaper, and we can run it much more directly on lots of harder problems,” Stoudenmire says. He contrasts that with “more sophisticated methods in the past of our field” that “wouldn't be able to even start going for some of these three-dimensional problems, because they're so big.”
Despite using only modest computational hardware, the researchers demonstrated that their simulations yielded state-of-the-art accuracies. The simulations converged on solutions that matched theoretical predictions and provided accurate results when applied to smaller test problems. The results also agreed with those reported by the quantum computing researchers — but with no quantum computer required.
While researchers in classical and quantum computing may seem to be at odds with each other about the limitations of their respective subfields, Tindall and Stoudenmire note that there's also shared knowledge and inspiration to be found between the two approaches.
“The good side of the classical versus quantum computing debate is that there's a lot of synergy between the kind of simulations we're interested in and the codes we write and what can be realized on these quantum computers,” Tindall says. “That can help guide us, and it can also help guide quantum computing researchers, because, obviously, the barrier for entry for us to simulate certain things is a lot easier than for them, because we don't have to build a quantum computer. I can just write some code and press 'run' on my personal computer.”
The team is pushing their work even further by developing tools for going beyond qubit systems to problems involving electrons that can move between sites — an even more daunting challenge that connects directly to simulating quantum materials. “They're really, quantitatively, a lot harder problems,” Stoudenmire says. “So that's one of our next big bars that we want to clear.”
Information for Press
For more information, please contact press@simonsfoundation.org.
Link to scientific paper
Link to high-resolution illustration
Link to high-resolution infographic
Recent Articles
Center for Computational Astrophysics
May 26, 2026
Black Hole Discoveries Abound in Newly Released LIGO-Virgo Catalog Mara Johnson-Groh
April 15, 2026
Gravity Follows Newton's and Einstein's Rules, Even at Cosmic Scales
Center for Computational Quantum Physics
April 15, 2026
Scientists Capture Superconductivity's 'Dancing Pairs' for First Time, Filling Gap in Decades-Old Theory By Mara Johnson-Groh
Recent Articles
Advancing Research in Basic Science and Mathematics Subscribe to Flatiron Institute announcements and other foundation updates
Continue 
About
About Us
Annual Report
Leadership
Contact Us
Career Opportunities
Funding
Funding Opportunities
Policies & Procedures
Simons Award Manager
Simons Foundation International
Programs
Life Sciences
Autism Research
Neuroscience Collaborations
Mathematics & Physical Sciences
Science, Society & Culture
Stay Connected
Newsletter
Events
Media Relations
Terms & Conditions
Privacy Policy
© Simons Foundation
Program Areas Program Areas
Mathematics & Physical Sciences Mathematics & Physical Sciences
Mathematics & Physical Sciences
Funding
Request for Applications
Programs
Policies and Procedures
Simons Award Manager (SAM) FAQ and Instructional Videos
News
Events
Events
Conferences
Symposia
About
About
About Us
Scientific Advisory Board
Life Sciences Life Sciences
Life Sciences
Research Areas
Ecology and Evolution
Plant Biology
Microbial Ecology & Evolution
Microbial Oceanography
Funding
Funding
Funding Opportunities
Life Sciences Awards
Project Awards
Funding Policies
Simons Award Manager (SAM) FAQ and Instructional Videos
News
About Us
Autism Research (SFARI)
Neuroscience Neuroscience
Neuroscience
Funding Funding
Funding
Fellows-to-Faculty
Fellows-to-Faculty
Apply
Fellows
Funding
Community
SURFiN Fellowship
SURFiN Fellowship
Apply Here
The SURFiN Community
About Us
Simons Collaborations Simons Collaborations
Simons Collaborations
Life Sciences Collaborations Life Sciences Collaborations
Life Sciences Collaborations
Research Areas
Ecology and Evolution
Plant Biology
Microbial Ecology & Evolution
Microbial Oceanography
Funding
Funding
Funding Opportunities
Life Sciences Awards
Project Awards
Funding Policies
Simons Award Manager (SAM) FAQ and Instructional Videos
News
About Us
Aging Brain Aging Brain
Aging Brain
Funding Funding
Funding
2020 Extension
Fellows-to-Faculty Award
Fellows-to-Faculty Award
Apply
Fellows
Funding
Community
Conferences and Courses Awards
Projects
Projects
Infographic
News
Publications
Events
About
About
Mission Statement
Executive Committee
Investigators
Fellows
Our Team
SCPAB Network
Global Brain Global Brain
Global Brain
Funding
Funding
Conferences and Courses Awards
Projects
News
News
Cosyne 2022
Cosyne 2020
Cosyne 2019
Cosyne 2018
Publications
Events
People
People
Executive Committee
Our Team
Investigators
Fellows
About
About
Scientific Mission
SCGB Network
SCGB-Sponsored Courses
Data Sharing Initiatives
Other Resources
MPS Collaborations MPS Collaborations
MPS Collaborations
Funding
Request for Applications
Programs
Policies and Procedures
Simons Award Manager (SAM) FAQ and Instructional Videos
News
Events
Events
Conferences
Symposia
About
About
About Us
Scientific Advisory Board
Flatiron Institute Flatiron Institute
Flatiron Institute
Our Centers Our Centers
Center for Computational Astrophysics Center for Computational Astrophysics
Center for Computational Astrophysics
Groups
Astronomical Data
Cosmology
Exoplanets
Galaxy Formation
Gravitational Wave Astronomy
Machine Learning X Astrophysics
Nearby Universe
Stars & Plasma Astrophysics (SPA)
Projects
News
News
Publications
Events
Events
CCA Colloquium
Event Videos
Software
Careers
About
About
Code of Conduct
Media Relations
Contact
People
Center for Computational Biology Center for Computational Biology
Center for Computational Biology
Research Areas
Biomolecular Design
Biophysical Modeling
Biological Transport Networks
CCBScope
Developmental Dynamics
Genomics
Statistical Biophysics
Structural and Molecular Biophysics
Publications
Software
News
Careers
About
About
Events
Code of Conduct
Media Relations
Contact
People
Center for Computational Mathematics Center for Computational Mathematics
Center for Computational Mathematics
Research
Image and Signal Processing
Numerical Analysis
Machine Learning
Publications
News
Software
People
Careers
About
About
Events
Code of Conduct
Media Relations
Contact
Center for Computational Neuroscience Center for Computational Neuroscience
Center for Computational Neuroscience
Research
Computational Vision
Neural Circuits and Algorithms
NeuroAI and Geometric Data Analysis
Statistical Analysis of Neural Data
People
Publications
Software
News
Events
Careers
About
About
Code of Conduct
Media Relations
Center for Computational Quantum Physics Center for Computational Quantum Physics
Center for Computational Quantum Physics
Research
Dynamics and Control
Quantum Materials
Software Libraries
Theory and Methods
Publications
News
Events
Events
2025-2026 DMFT-QE Symposium
New York City Condensed Matter Physics
Quantum Cafe
Workshop
Event Videos
Software
About
About
Careers
TRIQS Tutorial Videos
Graduate Scholars Program
Code of Conduct
Media Relations
Contact
People
Scientific Computing Core Scientific Computing Core
Scientific Computing Core
News
Events
Careers
People
About
About
Contact
Initiative for Computational Catalysis
Our Work
Research
Publications
Software
Machine Learning
News
Events
Events
Flatiron Wide Autumn Meeting
Flatiron Institute Seminar Series
ML@FI Seminar Series
Careers
About
About
Mission
People
Media Relations
Code of Conduct
Contact
Summer at Simons
Science, Society & Culture Science, Society & Culture
Science, Society & Culture
What We Do
Grantmaking
Media
National Initiatives
Events
Researcher Engagement
Who We Support
News
News
Stories of Impact
Who We Are
About
Staff
Advisory Board
Multidisciplinary Programs
Funding
Funding Opportunities
Policies and Procedures
Award Instructions
Simons Award Manager (SAM) FAQs and Videos
News
Announcements
Articles
Videos
What We're Reading
Events
Presidential Lectures
Presents
About
About Us
Annual Report
Leadership
Our History
Media Relations
Brand Portal
Careers
Summer at Simons
Visitor Information
Contact Us
© Simons Foundation
Terms and Conditions
Privacy Policy
Image Credits